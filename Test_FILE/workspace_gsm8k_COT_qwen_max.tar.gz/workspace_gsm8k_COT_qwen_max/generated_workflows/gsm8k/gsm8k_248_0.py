# Workflow ID: gsm8k_248_0
# Benchmark: gsm8k
# Data Indices: [280, 206]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all numerical values, units, relationships, and constraints from the problem. "
            "Organize the information in a structured format, such as a list or table, for easy reference. "
            "Include any implicit information that can be inferred from the context."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Construct a step-by-step solution plan
        solution_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Construct a step-by-step solution plan to solve the problem. "
            "Identify intermediate calculations, sequence the operations logically, "
            "and ensure unit consistency throughout. Provide explicit reasoning for each step."
        )
        solution_plan = await self.generate(instruction=solution_instruction, context=self.problem_text)

        # Step 3: Generate multiple solution approaches in parallel (optional for robustness)
        approach_1_instruction = (
            f"Solve the problem using the following solution plan:\n{solution_plan}\n"
            "Perform calculations step by step and provide the final answer."
        )
        approach_2_instruction = (
            f"Solve the problem independently without referencing the solution plan:\n{solution_plan}\n"
            "Use alternative reasoning or methods to arrive at the final answer."
        )
        results = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text)
        )

        # Step 4: Ensemble to select or synthesize the best solution
        ensemble_instruction = (
            "Evaluate the following candidate solutions and select the most accurate and logical one. "
            "If both solutions are valid, synthesize them into a single coherent answer. "
            "Provide justification for your choice."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 5: Validate and refine the final solution
        validation_instruction = (
            "Critique and refine the following solution:\n"
            f"{final_solution}\n"
            "Ensure the answer is mathematically correct, contextually appropriate, and formatted properly. "
            "Check for real-world constraints such as non-negative quantities or reasonable decimal precision."
        )
        refined_solution = await self.revise(instruction=validation_instruction, context=final_solution)

        # Step 6: Summarize the final answer
        summary_instruction = (
            "Summarize the following solution into a concise format that includes only the final numerical answer:\n"
            f"{refined_solution}\n"
            "Ensure the output is a single number (integer or decimal) without any additional text."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer