# Workflow ID: gsm8k_0_0
# Benchmark: gsm8k
# Data Indices: [25, 423]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract all numerical values, units, and relationships
        extraction_instruction = """
        Analyze the problem thoroughly and extract all numerical values, their associated units, 
        and any relationships or constraints mentioned in the text. Present the results in a 
        structured format, clearly labeling each value and its context.
        """
        extracted_values = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate a step-by-step solution
        solution_instruction = f"""
        Using the extracted values and relationships provided below, generate a step-by-step 
        solution to the problem. Ensure that each step logically follows from the previous one, 
        and include intermediate results where necessary. Pay close attention to units and 
        real-world constraints.

        Extracted Values and Relationships:
        {extracted_values}
        """
        draft_solution = await self.generate(instruction=solution_instruction, context=self.problem_text)

        # Step 3: Refine the solution for accuracy and clarity
        refinement_instruction = """
        Review the provided solution and refine it for accuracy, clarity, and completeness. 
        Check for logical consistency, proper handling of units, and adherence to the problem's 
        constraints. If any errors or ambiguities are found, correct them.
        """
        refined_solution = await self.revise(instruction=refinement_instruction, context=draft_solution)

        # Step 4: Extract the final numerical answer
        answer_extraction_instruction = """
        From the refined solution, extract the final numerical answer. Ensure that the answer 
        is presented as a single value, formatted appropriately (integer or decimal), and 
        includes any necessary units if applicable.
        """
        final_answer = await self.generate(instruction=answer_extraction_instruction, context=refined_solution)

        return final_answer