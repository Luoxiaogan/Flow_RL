# Workflow ID: gsm8k_68_0
# Benchmark: gsm8k
# Data Indices: [348, 4]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract knowns and unknowns
        extraction_instruction = """
        Carefully analyze the problem and extract all relevant numerical values, relationships, and the unknown(s) to be solved.
        Include units (e.g., miles, dollars, hours) and any constraints or conditions mentioned in the problem.
        Organize the information clearly and label each piece of data for easy reference.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a step-by-step plan
        plan_instruction = f"""
        Based on the extracted information: {extracted_info}
        Create a detailed step-by-step plan to solve the problem. Include:
        - The sequence of operations (e.g., addition, multiplication, unit conversions)
        - Intermediate calculations and their order
        - Any assumptions or logical reasoning required
        Ensure the plan is comprehensive and leaves no steps ambiguous.
        """
        plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute the plan step by step
        execution_instruction = f"""
        Follow the plan: {plan}
        Perform each step of the calculation carefully, showing all intermediate results.
        Ensure that units are consistent and that all constraints are satisfied.
        If there are multiple approaches, consider them separately and document the reasoning for each.
        """
        execution_results = await self.generate(instruction=execution_instruction, context=self.problem_text)

        # Step 4: Verify the solution
        verification_instruction = f"""
        Review the solution: {execution_results}
        Verify that the answer makes sense in the context of the problem. Check:
        - Units and their consistency
        - Reasonableness of the numerical value
        - Satisfaction of all constraints and conditions
        If any issues are found, revise the solution accordingly.
        """
        verified_solution = await self.revise(instruction=verification_instruction, context=execution_results)

        # Step 5: Summarize the answer
        summary_instruction = """
        Present the final answer clearly and concisely.
        Include the numerical value and its unit (if applicable).
        Ensure the answer is easy to understand and directly addresses the question.
        """
        final_answer = await self.summarize(instruction=summary_instruction, context=verified_solution)

        return final_answer