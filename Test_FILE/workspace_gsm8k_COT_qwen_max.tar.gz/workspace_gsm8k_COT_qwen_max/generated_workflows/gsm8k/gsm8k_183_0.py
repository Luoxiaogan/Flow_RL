# Workflow ID: gsm8k_183_0
# Benchmark: gsm8k
# Data Indices: [532, 165]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract known values and relationships
        extraction_instruction = (
            "Extract all numerical values, relationships, and constraints from the problem. "
            "Identify what is being asked for and list any intermediate steps required to solve the problem."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan the solution
        planning_instruction = (
            f"Based on the following extracted information: {extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. "
            "Include all necessary calculations, unit conversions, and logical reasoning."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Execute calculations (parallel execution for alternative paths)
        calculation_instruction_1 = (
            f"Follow this solution plan: {solution_plan}\n"
            "Perform the calculations step-by-step and provide intermediate results."
        )
        calculation_instruction_2 = (
            f"Follow this solution plan: {solution_plan}\n"
            "Verify the calculations using an alternative method if possible."
        )
        results = await asyncio.gather(
            self.generate(instruction=calculation_instruction_1, context=self.problem_text),
            self.generate(instruction=calculation_instruction_2, context=self.problem_text)
        )

        # Step 4: Validate and synthesize results
        ensemble_instruction = (
            f"Compare the following results: {results}\n"
            "Select the most robust and accurate solution. Ensure the final answer aligns with the problem's context."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 5: Summarize the final answer
        summarization_instruction = (
            "Condense the final solution into a single numerical value. "
            "Ensure the answer is clear, precise, and makes sense in the context of the problem."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=final_solution)

        return final_answer