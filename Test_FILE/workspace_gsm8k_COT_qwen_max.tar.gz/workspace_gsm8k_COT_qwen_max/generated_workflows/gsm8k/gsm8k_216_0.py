# Workflow ID: gsm8k_216_0
# Benchmark: gsm8k
# Data Indices: [256, 309]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract numerical values, relationships, and units
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, units, and relationships. "
            "Include any rates, percentages, or constraints mentioned in the text. "
            "Format the output as a structured list for clarity."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a solution plan
        solution_plan_instruction = (
            f"Based on the following extracted information: {extracted_info}\n"
            "Construct a detailed step-by-step plan to solve the problem. "
            "Identify the sequence of mathematical operations required, including any intermediate calculations. "
            "Ensure the plan accounts for unit consistency and real-world constraints."
        )
        solution_plan = await self.generate(instruction=solution_plan_instruction, context=self.problem_text)

        # Step 3: Execute intermediate calculations in parallel
        intermediate_steps = []
        for i, step in enumerate(solution_plan.split("\n")):
            if "calculate" in step.lower():
                intermediate_instruction = (
                    f"Perform the following calculation step from the solution plan: {step}\n"
                    "Ensure the result is accurate and include units if applicable."
                )
                intermediate_steps.append(self.generate(instruction=intermediate_instruction, context=self.problem_text))
        intermediate_results = await asyncio.gather(*intermediate_steps)

        # Step 4: Synthesize results into a final answer
        synthesis_instruction = (
            "Combine the following intermediate results into a final answer:\n"
            f"{intermediate_results}\n"
            "Ensure the final answer is consistent with the problem's requirements and units. "
            "If necessary, perform additional operations like summation or comparison."
        )
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=intermediate_results)

        # Step 5: Verify and refine the final answer
        refinement_instruction = (
            f"Verify the following answer for correctness and refine if necessary: {final_answer}\n"
            "Check that the answer makes sense in the context of the problem and adheres to real-world constraints. "
            "Provide the final, polished answer as a single numerical value."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        return refined_answer