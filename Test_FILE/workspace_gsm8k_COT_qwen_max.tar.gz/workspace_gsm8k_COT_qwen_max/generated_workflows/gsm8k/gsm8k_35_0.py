# Workflow ID: gsm8k_35_0
# Benchmark: gsm8k
# Data Indices: [158, 790]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information
        extraction_instruction = (
            "Extract all numerical values, relationships, and constraints from the problem. "
            "Include units, rates, and any implicit information. Format the output clearly."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Model the problem mathematically
        modeling_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Model the problem as a series of mathematical steps. Identify intermediate calculations, "
            "hidden steps, and the sequence of operations required to solve the problem. "
            "Ensure unit consistency and logical flow."
        )
        mathematical_model = await self.generate(instruction=modeling_instruction, context=self.problem_text)

        # Step 3: Solve step-by-step
        solving_instruction = (
            f"Using the mathematical model: {mathematical_model}\n"
            "Perform the calculations step-by-step. Include intermediate results and ensure "
            "unit consistency throughout. Provide the final answer with appropriate precision."
        )
        solution = await self.generate(instruction=solving_instruction, context=self.problem_text)

        # Step 4: Validate the solution
        validation_instruction = (
            f"Review the solution: {solution}\n"
            "Check for logical consistency, unit correctness, and whether the answer makes sense "
            "in the context of the problem. Refine the solution if necessary."
        )
        validated_solution = await self.revise(instruction=validation_instruction, context=solution)

        # Step 5: Summarize the result
        summarization_instruction = (
            f"Condense the validated solution: {validated_solution}\n"
            "Focus on the final answer and key reasoning steps. Present the result concisely."
        )
        final_summary = await self.summarize(instruction=summarization_instruction, context=validated_solution)

        return final_summary