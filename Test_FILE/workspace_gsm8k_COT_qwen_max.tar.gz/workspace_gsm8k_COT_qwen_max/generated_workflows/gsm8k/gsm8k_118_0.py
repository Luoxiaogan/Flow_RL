# Workflow ID: gsm8k_118_0
# Benchmark: gsm8k
# Data Indices: [657, 171]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information from the problem text
        extraction_instruction = (
            "Extract all numerical values, entities (e.g., people, objects), relationships, and constraints from the problem. "
            "Organize the information clearly and label each piece as either a 'known' or 'unknown'. "
            "Pay special attention to units, time-based sequences, and real-world constraints."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Identify knowns and unknowns, and outline the solution strategy
        strategy_instruction = (
            f"Using the extracted information: {extracted_info}, identify all known values and unknowns. "
            "Outline a step-by-step plan to solve the problem, specifying the order of operations and any intermediate calculations required. "
            "Ensure the plan accounts for all constraints and real-world considerations."
        )
        solution_strategy = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Generate potential solutions in parallel
        solution_instruction = (
            f"Based on the solution strategy: {solution_strategy}, calculate the answer step by step. "
            "Show all intermediate results and ensure the final answer is boxed. "
            "If there are multiple possible approaches, generate them independently."
        )
        approach1 = self.generate(instruction=solution_instruction, context=self.problem_text)
        approach2 = self.generate(instruction=solution_instruction, context=self.problem_text)
        approaches = await asyncio.gather(approach1, approach2)

        # Step 4: Validate and refine the solutions
        refinement_instruction = (
            "Critique the provided solution for accuracy, logical consistency, and adherence to the problem constraints. "
            "Refine the solution if necessary, ensuring all steps are correct and the final answer makes sense in context."
        )
        refined_solutions = [
            await self.revise(instruction=refinement_instruction, context=approach)
            for approach in approaches
        ]

        # Step 5: Summarize the refined solutions
        summary_instruction = (
            "Condense the refined solution into a concise summary, highlighting the key steps and the final answer. "
            "Ensure the summary is clear and includes all necessary details for verification."
        )
        summarized_solutions = [
            await self.summarize(instruction=summary_instruction, context=solution)
            for solution in refined_solutions
        ]

        # Step 6: Select the best solution using Ensemble
        ensemble_instruction = (
            "Evaluate the provided solutions and select the best one based on accuracy, clarity, and adherence to the problem context. "
            "If the solutions differ, resolve discrepancies and provide a final verdict."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=summarized_solutions)

        return final_answer