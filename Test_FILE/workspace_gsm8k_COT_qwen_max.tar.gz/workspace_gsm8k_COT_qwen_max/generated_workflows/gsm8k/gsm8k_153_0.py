# Workflow ID: gsm8k_153_0
# Benchmark: gsm8k
# Data Indices: [757, 356]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information (numerical values, units, relationships, and the question)
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, their associated units, "
            "and any relationships or constraints described in the text. Clearly identify what the "
            "question is asking for."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate intermediate calculation steps
        formulation_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Determine the sequence of calculations required to solve the problem. Include any "
            "necessary unit conversions, intermediate totals, or proportional reasoning steps."
        )
        calculation_steps = await self.generate(instruction=formulation_instruction, context=self.problem_text)

        # Step 3: Perform the calculations
        calculation_instruction = (
            f"Using the following sequence of steps:\n{calculation_steps}\n"
            "Perform all calculations step-by-step, showing intermediate results. Ensure arithmetic "
            "operations are carried out accurately and in the correct order."
        )
        calculated_result = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Validate and refine the solution
        refinement_instruction = (
            f"Review the following solution:\n{calculated_result}\n"
            "Check for any errors in calculation, unit inconsistencies, or logical flaws. Ensure the "
            "final answer makes sense in the context of the problem. Suggest improvements if necessary."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=calculated_result)

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"Condense the following solution into a concise summary:\n{refined_solution}\n"
            "Highlight the final numerical answer and ensure it is presented clearly and accurately."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_summary