# Workflow ID: gsm8k_146_0
# Benchmark: gsm8k
# Data Indices: [340, 560]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract known information
        extraction_instruction = """
        Extract all numerical values, relationships, and contextual clues from the problem.
        Clearly identify known quantities, unknowns, and any constraints or conditions.
        Format the output as a structured list for easy reference in subsequent steps.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a solution plan
        plan_instruction = f"""
        Based on the extracted information: {extracted_info}
        Create a step-by-step plan to solve the problem. Include:
        - Intermediate calculations (even if not explicitly stated in the problem)
        - Order of operations
        - Any unit conversions or contextual constraints
        Ensure the plan is comprehensive and leaves no ambiguity.
        """
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute calculations
        calculation_instruction_template = """
        Perform the following calculation step: {step}
        Ensure the result is accurate and includes appropriate units if applicable.
        """
        # Split the solution plan into individual steps
        steps = solution_plan.split("\n")
        calculation_tasks = [
            self.generate(instruction=calculation_instruction_template.format(step=step), context=self.problem_text)
            for step in steps if step.strip()
        ]
        calculation_results = await asyncio.gather(*calculation_tasks)

        # Step 4: Validate and refine results
        refinement_instruction = """
        Review the calculated results and ensure they are logically consistent with the problem context.
        Correct any errors, resolve ambiguities, and refine the results as needed.
        """
        refined_results = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction, context=result) for result in calculation_results]
        )

        # Step 5: Summarize final answer
        final_summary_instruction = """
        Condense the refined results into a single numerical answer.
        Ensure the answer is clear, concise, and formatted appropriately.
        """
        final_answer = await self.summarize(instruction=final_summary_instruction, context="\n".join(refined_results))

        return final_answer