# Workflow ID: gsm8k_31_0
# Benchmark: gsm8k
# Data Indices: [466, 386]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = """
        Analyze the problem thoroughly and extract all numerical values, relationships, and constraints. 
        Identify the known quantities, unknowns, and any conditions or operations mentioned explicitly or implicitly. 
        Present the extracted information in a structured format, such as a list or bullet points.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Model the problem mathematically
        modeling_instruction = f"""
        Based on the following extracted information: {extracted_info}
        Translate the word problem into a series of mathematical steps. 
        Identify the sequence of operations needed to solve the problem, including any intermediate calculations. 
        Clearly specify the final goal and how it will be achieved. 
        Provide a detailed plan for solving the problem step-by-step.
        """
        mathematical_model = await self.generate(instruction=modeling_instruction, context=self.problem_text)

        # Step 3: Perform calculations step-by-step
        calculation_instruction = f"""
        Using the following mathematical model: {mathematical_model}
        Execute the calculations step-by-step. 
        Show all intermediate results and ensure each step logically follows from the previous one. 
        Clearly state the final numerical answer at the end.
        """
        calculated_result = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Verify the solution for correctness
        verification_instruction = f"""
        Review the following solution: {calculated_result}
        Check for logical consistency, correct handling of units, and adherence to real-world constraints. 
        Ensure the answer makes sense in the context of the problem. 
        If any issues are found, suggest corrections or improvements.
        """
        verified_solution = await self.revise(instruction=verification_instruction, context=calculated_result)

        # Step 5: Summarize the final answer
        summarization_instruction = """
        Condense the solution into a single numerical value. 
        Ensure the answer is clear, concise, and formatted appropriately (integer or decimal). 
        Remove any extraneous information while preserving the final result.
        """
        final_answer = await self.summarize(instruction=summarization_instruction, context=verified_solution)

        return final_answer