# Workflow ID: gsm8k_348_0
# Benchmark: gsm8k
# Data Indices: [102, 430]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information
        extraction_instruction = (
            "Extract all numerical values, units, relationships, and constraints from the problem. "
            "Organize the information into categories such as 'known values', 'unknowns', 'operations', "
            "and 'contextual constraints'. Ensure units are explicitly noted."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan the solution approach
        planning_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Devise a step-by-step plan to solve the problem. Include intermediate calculations, "
            "unit conversions, and any contextual constraints. Clearly specify the order of operations."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Execute the plan
        execution_instruction_template = (
            "Perform the following calculation step:\n{{step}}\n"
            "Ensure the result is accurate and consistent with the problem's context. "
            "Include units and intermediate results explicitly."
        )

        # Split the solution plan into individual steps
        steps = solution_plan.split("\n")
        tasks = [
            self.generate(instruction=execution_instruction_template.format(step=step), context=self.problem_text)
            for step in steps if step.strip()
        ]
        intermediate_results = await asyncio.gather(*tasks)

        # Step 4: Validate intermediate results
        validation_instruction_template = (
            "Critique the following result:\n{{result}}\n"
            "Ensure it aligns with the problem's context and constraints. Suggest corrections if needed."
        )
        validation_tasks = [
            self.revise(instruction=validation_instruction_template.format(result=result), context=self.problem_text)
            for result in intermediate_results
        ]
        validated_results = await asyncio.gather(*validation_tasks)

        # Step 5: Synthesize the final answer
        synthesis_instruction = (
            "Combine the following validated results into a single coherent solution:\n"
            f"{validated_results}\n"
            "Ensure the final answer is a single numerical value with appropriate units."
        )
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=validated_results)

        # Step 6: Summarize the solution
        summary_instruction = (
            "Summarize the solution process and present the final answer. "
            "Include only the most essential information and ensure clarity."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=final_answer)

        return final_summary