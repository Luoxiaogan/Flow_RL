# Workflow ID: gsm8k_388_0
# Benchmark: gsm8k
# Data Indices: [81, 468]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all numerical values, relationships, and constraints
        extraction_instruction = (
            "Carefully read the problem and extract all numerical values, relationships, and constraints. "
            "Identify the known quantities and the unknowns. Highlight any dependencies or conditions "
            "that must be satisfied. Ensure that all units are explicitly noted."
        )
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the extracted information and plan the solution
        analysis_instruction = (
            f"Given the following extracted information: {extraction}\n"
            "Analyze the relationships between the known quantities and the unknowns. "
            "Determine the sequence of calculations required to solve the problem. "
            "Identify any intermediate steps or hidden operations that are not explicitly stated. "
            "Ensure that the plan accounts for all constraints and units."
        )
        analysis = await self.generate(instruction=analysis_instruction, context=self.problem_text)

        # Step 3: Perform the calculations step-by-step
        calculation_instruction = (
            f"Using the following analysis: {analysis}\n"
            "Perform the calculations step-by-step. Ensure that each step logically follows "
            "from the previous one. Handle all arithmetic operations, including addition, subtraction, "
            "multiplication, division, fractions, percentages, and unit conversions. Verify that the "
            "intermediate results are consistent with the problem context."
        )
        calculation = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Validate the computed result
        validation_instruction = (
            f"Validate the following computed result: {calculation}\n"
            "Check that the result makes sense in the context of the problem. Ensure that all units "
            "are consistent, and verify that the answer satisfies all constraints and conditions. "
            "If there are any discrepancies, refine the result accordingly."
        )
        validation = await self.revise(instruction=validation_instruction, context=calculation)

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"Summarize the following validated result: {validation}\n"
            "Condense the information into a single numerical value, which is the final answer. "
            "Ensure that the output is precise and formatted correctly."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=validation)

        return final_answer