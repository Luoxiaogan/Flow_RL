# Workflow ID: gsm8k_61_0
# Benchmark: gsm8k
# Data Indices: [717, 248]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract known information and relationships
        extraction_instruction = (
            "Thoroughly analyze the problem and extract all numerical values, units, "
            "and relationships described in the text. Identify entities and their associated quantities. "
            "Provide this information in a structured format."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Identify the unknown and plan the solution
        planning_instruction = (
            f"Based on the following extracted information: {extracted_info}\n"
            "Determine what the problem is asking for (the unknown) and outline a detailed step-by-step plan "
            "to solve it. Include all necessary calculations and reasoning."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Execute calculations
        calculation_instruction = (
            f"Follow this solution plan: {solution_plan}\n"
            "Perform all calculations step by step, showing intermediate results. Ensure proper handling of units."
        )
        calculations = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Verify and refine results
        refinement_instruction = (
            f"Review the following calculations: {calculations}\n"
            "Critique the results for accuracy and logical consistency. Refine any errors or ambiguities."
        )
        refined_results = await self.revise(instruction=refinement_instruction, context=calculations)

        # Step 5: Finalize and present the answer
        summarization_instruction = (
            f"Condense the following refined results: {refined_results}\n"
            "Present the final answer as a single numerical value, ensuring proper unit handling and formatting."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_results)

        return final_answer