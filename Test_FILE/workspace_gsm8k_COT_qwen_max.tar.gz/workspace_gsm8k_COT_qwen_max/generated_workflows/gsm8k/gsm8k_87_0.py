# Workflow ID: gsm8k_87_0
# Benchmark: gsm8k
# Data Indices: [318, 550]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key components from the problem
        extraction_instruction = (
            "Carefully analyze the problem statement. "
            "Extract all numerical values, relationships (such as ratios, rates, or proportions), "
            "and any constraints or conditions explicitly mentioned. "
            "Organize this information in a structured format for further processing."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Perform intermediate calculations
        calculation_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "perform the necessary arithmetic operations to solve the problem step by step. "
            "Ensure all intermediate results are clearly stated and logically follow from the previous steps. "
            "Pay attention to units, fractions, and any contextual constraints."
        )
        calculated_solution = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 3: Validate and refine the solution
        refinement_instruction = (
            "Review the calculated solution critically. "
            "Check for consistency with the problem context, including unit handling and logical constraints. "
            "Refine the solution if necessary, ensuring it aligns with the requirements of the problem."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=calculated_solution)

        # Step 4: Summarize the final answer
        summarization_instruction = (
            "Condense the refined solution into a single numerical value that directly answers the problem. "
            "Ensure the final answer is precise and formatted appropriately."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_solution)

        return final_answer