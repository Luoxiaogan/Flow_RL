# Workflow ID: gsm8k_369_0
# Benchmark: gsm8k
# Data Indices: [679, 406]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all numerical values, relationships, and contextual clues
        extraction_instruction = (
            "Extract all numerical values, units, relationships (e.g., 'twice as many'), "
            "and the target question from the problem. Organize the information clearly, "
            "listing known quantities and what needs to be calculated."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate a step-by-step solution plan
        solution_instruction = (
            f"Based on the following extracted information: {extracted_info}\n"
            "Generate a detailed, step-by-step solution plan. Include intermediate calculations, "
            "ensure units are consistent, and explain how each step leads to the final answer."
        )
        solution_plan = await self.generate(instruction=solution_instruction, context=self.problem_text)

        # Step 3: Verify and refine the solution
        refinement_instruction = (
            "Critique the following solution plan for logical consistency, correct handling of units, "
            "and adherence to the problem's requirements. Suggest improvements if necessary."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=solution_plan)

        # Step 4: Extract the final answer
        answer_extraction_instruction = (
            "From the following refined solution, extract the final numerical answer. "
            "Ensure the answer is a single number with appropriate precision."
        )
        final_answer = await self.generate(instruction=answer_extraction_instruction, context=refined_solution)

        return final_answer