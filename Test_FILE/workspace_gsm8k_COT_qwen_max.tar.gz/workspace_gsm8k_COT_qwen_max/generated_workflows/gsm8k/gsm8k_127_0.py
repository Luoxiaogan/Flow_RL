# Workflow ID: gsm8k_127_0
# Benchmark: gsm8k
# Data Indices: [676, 618]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key numerical values, units, and relationships
        extraction_instruction = (
            "Extract all numerical values, their units, and the relationships between them from the problem. "
            "Include any relevant contextual information such as time periods, rates, or constraints. "
            "Format the output as a structured list or explanation."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan the solution steps
        planning_instruction = (
            f"Based on the following extracted information: {extracted_info}\n"
            "Outline the sequence of mathematical operations needed to solve the problem. "
            "Include intermediate steps and ensure the plan is clear and logical. "
            "Format the output as a numbered list of steps."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Perform calculations in parallel
        calculation_instructions = []
        for i, step in enumerate(solution_plan.split("\n")):
            if step.strip():  # Ensure the step is not empty
                calculation_instructions.append(
                    f"Perform the following step: {step}. "
                    "Show all intermediate calculations and provide the result. "
                    "Ensure the result is accurate and consistent with the problem context."
                )
        calculation_tasks = [
            self.generate(instruction=instr, context=self.problem_text) for instr in calculation_instructions
        ]
        calculation_results = await asyncio.gather(*calculation_tasks)

        # Step 4: Summarize the results into a final answer
        summarization_instruction = (
            "Condense the following calculation results into a single final answer. "
            "Ensure the answer is clear, concise, and consistent with the problem context. "
            "Include the appropriate units if applicable."
        )
        final_answer = await self.summarize(
            instruction=summarization_instruction, context="\n".join(calculation_results)
        )

        # Step 5: Revise for accuracy and clarity
        revision_instruction = (
            "Critique and refine the following final answer to ensure it is accurate, complete, and makes sense in the context of the problem. "
            "Check for unit consistency, logical correctness, and adherence to real-world constraints."
        )
        revised_answer = await self.revise(instruction=revision_instruction, context=final_answer)

        return revised_answer