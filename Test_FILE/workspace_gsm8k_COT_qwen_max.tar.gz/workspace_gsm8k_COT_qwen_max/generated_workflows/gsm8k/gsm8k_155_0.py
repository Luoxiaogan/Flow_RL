# Workflow ID: gsm8k_155_0
# Benchmark: gsm8k
# Data Indices: [594, 722]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract numerical values and relationships
        extraction_instruction = (
            "Extract all numerical values, units, and relationships mentioned in the problem. "
            "Include percentages, ratios, and any other quantitative information. "
            "Also identify what the question is asking for."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan the solution strategy
        planning_instruction = (
            f"Based on the following extracted information: {extracted_info}. "
            "Plan a step-by-step solution strategy to solve the problem. "
            "Identify intermediate calculations, order of operations, and any constraints. "
            "Ensure the plan is detailed and accounts for all extracted information."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Execute calculations step-by-step
        calculation_instruction = (
            f"Using the following solution plan: {solution_plan}. "
            "Perform the calculations step-by-step. "
            "Clearly show all intermediate results and ensure unit consistency. "
            "Verify that each step logically follows from the previous one."
        )
        calculations = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Validate and refine the solution
        refinement_instruction = (
            f"Review the following calculations: {calculations}. "
            "Check for accuracy, logical consistency, and adherence to the problem context. "
            "Refine any steps that seem incorrect or unclear."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=calculations)

        # Step 5: Summarize the final answer
        summarization_instruction = (
            f"From the refined solution: {refined_solution}. "
            "Extract and clearly present the final numerical answer. "
            "Ensure the answer is boxed and presented as a single value."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_solution)

        return final_answer