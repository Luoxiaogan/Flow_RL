# Workflow ID: gsm8k_319_0
# Benchmark: gsm8k
# Data Indices: [447, 285]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all relevant numerical values, relationships, and constraints
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, units, "
            "and relationships between them. Identify any constraints or conditions "
            "that affect the calculations. Present the extracted information in a "
            "structured format for further processing."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan the step-by-step solution
        planning_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. Include all "
            "necessary intermediate calculations, the order of operations, and any "
            "real-world constraints that must be considered. Ensure the plan is "
            "logical and systematic."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Perform intermediate calculations in parallel
        calculation_instruction_template = (
            "Follow this step from the solution plan:\n{step}\n"
            "Perform the required calculation carefully, ensuring accuracy and "
            "consistency with the problem's context. If any assumptions are made, "
            "state them explicitly."
        )

        # Split the solution plan into individual steps
        steps = solution_plan.split("\n")
        calculation_tasks = [
            self.generate(instruction=calculation_instruction_template.format(step=step), context=self.problem_text)
            for step in steps if step.strip()
        ]
        intermediate_results = await asyncio.gather(*calculation_tasks)

        # Step 4: Validate and refine intermediate results
        refinement_instruction_template = (
            "Review the following calculation result:\n{result}\n"
            "Ensure it is accurate, makes sense in the context of the problem, and "
            "aligns with the solution plan. Revise the result if necessary, providing "
            "a corrected version."
        )
        refinement_tasks = [
            self.revise(instruction=refinement_instruction_template.format(result=result), context=self.problem_text)
            for result in intermediate_results
        ]
        refined_results = await asyncio.gather(*refinement_tasks)

        # Step 5: Synthesize the final answer
        synthesis_instruction = (
            "Combine the following refined intermediate results into a single final answer:\n"
            f"{refined_results}\n"
            "Ensure the final answer is a single numerical value (integer or decimal) "
            "and is consistent with the problem's requirements. If necessary, perform "
            "any final calculations to arrive at the answer."
        )
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=refined_results)

        return final_answer