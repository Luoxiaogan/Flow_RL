# Workflow ID: gsm8k_57_0
# Benchmark: gsm8k
# Data Indices: [606, 39]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract known information
        extract_instruction = """
        Extract all numerical values, units, relationships, and constraints from the problem. 
        Format the output as follows:
        - Numerical Values: List all numbers mentioned in the problem.
        - Units: Identify the units associated with each number (e.g., dollars, hours, items).
        - Relationships: Describe any mathematical relationships or operations implied in the problem (e.g., addition, multiplication, division).
        - Constraints: Note any real-world constraints (e.g., non-negative quantities, whole numbers only).
        """
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Identify problem type and solution strategy
        strategy_instruction = f"""
        Based on the extracted information: {extracted_info}
        Classify the problem type (e.g., sequential operations, proportional reasoning, rate problems) and outline a step-by-step solution strategy. 
        Ensure the strategy includes:
        - A clear identification of known values and unknowns.
        - The sequence of calculations required to solve the problem.
        - Any intermediate results needed to reach the final answer.
        """
        solution_strategy = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Solve step-by-step
        solve_instruction = f"""
        Using the extracted information: {extracted_info}
        And the solution strategy: {solution_strategy}
        Perform the calculations step-by-step. Include intermediate results and ensure all units are consistent throughout the process.
        Format the output as follows:
        - Step 1: [Description of the first calculation and its result]
        - Step 2: [Description of the second calculation and its result]
        - ...
        - Final Result: [The final numerical answer]
        """
        step_by_step_solution = await self.generate(instruction=solve_instruction, context=self.problem_text)

        # Step 4: Verify and refine the solution
        verify_instruction = f"""
        Critique the following solution: {step_by_step_solution}
        Ensure it adheres to the following criteria:
        - All calculations are correct and follow the outlined strategy.
        - Units are consistent and properly handled.
        - Real-world constraints are respected (e.g., no negative quantities, whole numbers where applicable).
        If any issues are found, suggest refinements to correct them.
        """
        refined_solution = await self.revise(instruction=verify_instruction, context=step_by_step_solution)

        # Step 5: Summarize the final answer
        summarize_instruction = """
        Extract the final numerical answer from the solution. Ensure the answer is clear, concise, and formatted as a single number (integer or decimal).
        """
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_answer