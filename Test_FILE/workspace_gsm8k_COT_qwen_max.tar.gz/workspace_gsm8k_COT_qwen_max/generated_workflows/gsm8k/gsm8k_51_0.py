# Workflow ID: gsm8k_51_0
# Benchmark: gsm8k
# Data Indices: [565, 38]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant numerical values, relationships, and units
        extraction_instruction = """
        Carefully read the problem and extract all numerical values, their associated units (if any), 
        and the relationships between them. Identify what is being asked and what information is given.
        Organize the extracted information into categories such as 'known values', 'unknowns', 
        'units', and 'operations'. Ensure nothing is missed.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate a step-by-step solution plan
        solution_instruction = f"""
        Based on the following extracted information: {extracted_info}
        Create a detailed step-by-step plan to solve the problem. Include all intermediate calculations,
        ensure proper sequencing of operations, and track units throughout. Clearly identify the final
        answer and its format. If there are multiple entities or steps, break them down systematically.
        """
        solution_plan = await self.generate(instruction=solution_instruction, context=self.problem_text)

        # Step 3: Revise and verify the solution plan
        revision_instruction = """
        Critically review the solution plan. Check for logical consistency, correct sequencing of operations,
        proper handling of units, and adherence to real-world constraints. If there are any errors or ambiguities,
        suggest improvements or corrections. Ensure the plan leads to the correct final answer.
        """
        revised_solution = await self.revise(instruction=revision_instruction, context=solution_plan)

        # Step 4: Extract and format the final answer
        final_answer_instruction = """
        From the revised solution plan, isolate the final numerical answer. Ensure it is formatted as a single
        numerical value (integer or decimal) without any additional text or explanation.
        """
        final_answer = await self.summarize(instruction=final_answer_instruction, context=revised_solution)

        return final_answer