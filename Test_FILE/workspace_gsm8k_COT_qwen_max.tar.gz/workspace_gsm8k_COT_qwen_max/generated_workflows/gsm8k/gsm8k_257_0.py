# Workflow ID: gsm8k_257_0
# Benchmark: gsm8k
# Data Indices: [159, 364]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all numerical values, relationships, and constraints
        extraction_instruction = (
            "Extract all numerical values, units, relationships, and constraints from the problem. "
            "Organize them into a structured format, such as a list or table, for easy reference. "
            "Ensure no important detail is missed."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate a step-by-step solution plan
        plan_instruction = (
            f"Using the following extracted information: {extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. "
            "Include all necessary intermediate calculations and ensure the sequence of operations is logical. "
            "If there are multiple possible approaches, outline them separately."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Explore multiple solution approaches in parallel
        approach_1_instruction = (
            f"Follow this solution plan: {solution_plan}\n"
            "Solve the problem step by step, showing all intermediate results. "
            "Ensure the solution is mathematically sound and adheres to the problem's constraints."
        )
        approach_2_instruction = (
            f"Explore an alternative solution path based on: {solution_plan}\n"
            "Consider breaking the problem into smaller subproblems or using a different sequence of operations. "
            "Ensure the solution is valid and consistent with the problem's context."
        )
        results = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text)
        )

        # Step 4: Select the best solution using Ensemble
        ensemble_instruction = (
            "Evaluate the following candidate solutions and select the best one:\n"
            f"Candidate 1: {results[0]}\n"
            f"Candidate 2: {results[1]}\n"
            "Criteria for selection: Correctness, simplicity, adherence to problem constraints, and logical consistency. "
            "Provide the selected solution."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 5: Extract the final numerical answer
        final_answer_instruction = (
            f"From the selected solution: {best_solution}\n"
            "Extract the final numerical answer. Ensure it is clearly stated and formatted as a single value. "
            "If units are involved, include them appropriately."
        )
        final_answer = await self.generate(instruction=final_answer_instruction, context=self.problem_text)

        return final_answer