# Workflow ID: gsm8k_265_0
# Benchmark: gsm8k
# Data Indices: [422, 425]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information from the problem
        extraction_instruction = (
            "Extract all numerical values, relationships, and units from the problem. "
            "List them in a structured format: Known Values, Unknowns, Relationships. "
            "Ensure units are clearly labeled and relationships are explicitly stated."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Create a step-by-step solution plan
        modeling_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. "
            "Include all intermediate calculations, handle unit conversions, and ensure hidden steps are addressed. "
            "Output the plan as a numbered list of operations."
        )
        solution_plan = await self.generate(instruction=modeling_instruction, context=self.problem_text)

        # Step 3: Generate multiple solution approaches in parallel
        approach_1_instruction = (
            f"Follow this solution plan: {solution_plan}\n"
            "Solve the problem step by step, showing all calculations and intermediate results. "
            "Ensure the final answer is clearly stated with appropriate units."
        )
        approach_2_instruction = (
            f"Develop an alternative solution approach based on: {extracted_info}\n"
            "Solve the problem differently, ensuring all steps are logically sound and consistent with the problem context."
        )
        results = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text)
        )

        # Step 4: Ensemble to select the best solution
        ensemble_instruction = (
            "Compare the following solutions and select the best one:\n"
            "Solution 1: {results[0]}\n"
            "Solution 2: {results[1]}\n"
            "Evaluate based on correctness, clarity, and adherence to the problem context. "
            "Provide a justification for your choice."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 5: Refine the final answer
        refinement_instruction = (
            f"Refine the following solution: {best_solution}\n"
            "Ensure the final answer is formatted correctly, makes sense in the problem's context, "
            "and adheres to any constraints (e.g., units, decimal places)."
        )
        final_answer = await self.revise(instruction=refinement_instruction, context=best_solution)

        return final_answer