# Workflow ID: gsm8k_302_0
# Benchmark: gsm8k
# Data Indices: [646, 47]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information
        extraction_instruction = (
            "Extract all numerical values, units, relationships, and the target question from the problem. "
            "Clearly identify known values, unknowns, and any constraints. "
            "Ensure the output is structured and easy to interpret."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a step-by-step solution plan
        planning_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. "
            "Include intermediate calculations, the order of operations, and unit handling. "
            "Ensure the plan is logical and accounts for all given data."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Execute calculations
        calculation_instruction = (
            f"Follow this solution plan:\n{solution_plan}\n"
            "Perform all calculations step-by-step. Validate each intermediate result before proceeding. "
            "Ensure the final answer is accurate and matches the question asked."
        )
        calculations = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Summarize the final answer
        summary_instruction = (
            "Condense the solution into a concise summary. "
            "Include only the final numerical answer and ensure it aligns with the question asked. "
            "Verify that the answer makes sense in the context of the problem."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=calculations)

        # Optional Step 5: Revise if needed
        revision_instruction = (
            "Critique the solution for potential errors or ambiguities. "
            "Refine the result if necessary, ensuring accuracy and clarity."
        )
        refined_answer = await self.revise(instruction=revision_instruction, context=final_answer)

        return refined_answer