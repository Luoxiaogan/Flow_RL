# Workflow ID: gsm8k_198_0
# Benchmark: gsm8k
# Data Indices: [748, 31]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio
        
        # Step 1: Extract all numerical values, relationships, and constraints
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, "
            "relationships between them, and any constraints or conditions. "
            "Present the extracted information in a structured format."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)
        
        # Step 2: Plan the solution approach
        planning_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Devise a detailed step-by-step plan to solve the problem. "
            "Include all necessary calculations, intermediate steps, and logical reasoning. "
            "Ensure the plan is clear and executable."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)
        
        # Step 3: Perform the calculations
        calculation_instruction = (
            f"Follow this plan:\n{solution_plan}\n"
            "Execute each step carefully, recording all intermediate results. "
            "Ensure all calculations are accurate and consistent with the problem context."
        )
        calculated_solution = await self.generate(instruction=calculation_instruction, context=self.problem_text)
        
        # Step 4: Verify the solution
        verification_instruction = (
            f"Review the following solution:\n{calculated_solution}\n"
            "Critique it for accuracy, logical consistency, and adherence to the problem's constraints. "
            "If there are any issues, suggest corrections and refine the solution."
        )
        verified_solution = await self.revise(instruction=verification_instruction, context=calculated_solution)
        
        # Step 5: Summarize the final answer
        summary_instruction = (
            f"Condense the following verified solution into a concise final answer:\n{verified_solution}\n"
            "Ensure the final output is a single numerical value, clearly presented."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=verified_solution)
        
        return final_answer