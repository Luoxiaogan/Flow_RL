# Workflow ID: gsm8k_163_0
# Benchmark: gsm8k
# Data Indices: [96, 709]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract known values, units, and relationships
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, units, and relationships. "
            "Identify what is given and what is being asked. Ensure you capture all constraints and conditions. "
            "Format the extracted information clearly for further processing."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Construct a step-by-step solution
        reasoning_instruction = (
            f"Using the extracted information: {extracted_info}, construct a step-by-step solution to the problem. "
            "Ensure all calculations are performed in the correct order, and track units consistently. "
            "If intermediate steps are implied but not explicitly stated, include them. "
            "Provide the reasoning behind each step and ensure the solution aligns with the problem's context."
        )
        solution_steps = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Validate and refine the solution
        validation_instruction = (
            "Review the provided solution steps and validate their correctness. "
            "Check for calculation errors, unit inconsistencies, or logical gaps. "
            "Refine the solution to address any issues and ensure clarity. "
            "Ensure the final result makes sense in the context of the problem."
        )
        refined_solution = await self.revise(instruction=validation_instruction, context=solution_steps)

        # Step 4: Extract the final answer
        final_answer_instruction = (
            "From the refined solution, extract the final numerical answer. "
            "Ensure the answer is presented as a single value without additional explanation. "
            "Verify that the answer satisfies the problem's requirements."
        )
        final_answer = await self.summarize(instruction=final_answer_instruction, context=refined_solution)

        return final_answer