# Workflow ID: gsm8k_10_0
# Benchmark: gsm8k
# Data Indices: [281, 484]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract known values and relationships
        extraction_instruction = (
            "Identify all numerical values, units, and relationships in the problem. "
            "For each number, describe its meaning and how it relates to other numbers. "
            "Include any implicit relationships (e.g., 'more than,' 'altogether')."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a step-by-step solution plan
        plan_instruction = (
            "Based on the extracted information, create a detailed step-by-step plan to solve the problem. "
            "Include the sequence of operations, intermediate calculations, and how to handle units. "
            "Ensure the plan accounts for all given information and leads to the final answer."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=extracted_info)

        # Step 3: Perform calculations
        calculation_instruction = (
            "Execute the solution plan step by step. Perform all arithmetic operations accurately, "
            "keeping track of units and intermediate results. Ensure the calculations align with the plan."
        )
        calculations = await self.generate(instruction=calculation_instruction, context=solution_plan)

        # Step 4: Verify and refine the solution
        refinement_instruction = (
            "Review the calculations and solution for correctness. Check for logical consistency, "
            "unit accuracy, and adherence to the problem's context. Identify and correct any errors."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=calculations)

        # Step 5: Summarize the final answer
        summary_instruction = (
            "Extract the final numerical answer from the refined solution. Ensure the answer is clear, "
            "concise, and matches the problem's requirements."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer