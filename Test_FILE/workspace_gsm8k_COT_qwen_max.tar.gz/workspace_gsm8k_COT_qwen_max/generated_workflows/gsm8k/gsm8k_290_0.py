# Workflow ID: gsm8k_290_0
# Benchmark: gsm8k
# Data Indices: [619, 183]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract key information
        extraction_instruction = (
            "Extract all numerical values, units, entities (e.g., people, objects), relationships, and constraints "
            "from the problem. Organize them into categories such as 'known values', 'unknowns', 'relationships', "
            "and 'units'. Provide this information in a structured format."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Identify problem type and plan solution
        planning_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Determine the type of problem (e.g., sequential operations, rate problems, proportional reasoning). "
            "Outline a step-by-step solution strategy, including all necessary calculations and their order. "
            "Ensure the plan accounts for units, constraints, and real-world considerations."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Execute calculations in parallel
        calculation_steps = []
        for i, step in enumerate(solution_plan.split("\n")):  # Assuming each line is a step
            if step.strip():  # Skip empty lines
                calculation_instruction = (
                    f"Perform the following calculation step: {step}. "
                    "Provide the result with appropriate units and precision."
                )
                calculation_steps.append(self.generate(instruction=calculation_instruction, context=self.problem_text))
        
        calculation_results = await asyncio.gather(*calculation_steps)

        # Step 4: Synthesize results
        synthesis_instruction = (
            "Combine the following intermediate results into a final answer:\n" +
            "\n".join(calculation_results) + "\n"
            "Ensure the final result is consistent with the problem requirements, respects units, and adheres to "
            "real-world constraints. Provide the answer as a single numerical value."
        )
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=calculation_results)

        # Step 5: Verify and refine
        verification_instruction = (
            f"Verify the following solution:\n{final_answer}\nagainst the original problem:\n{self.problem_text}.\n"
            "Ensure the answer makes sense in context, respects units, and adheres to real-world constraints. "
            "If necessary, suggest refinements."
        )
        refined_answer = await self.revise(instruction=verification_instruction, context=final_answer)

        return refined_answer