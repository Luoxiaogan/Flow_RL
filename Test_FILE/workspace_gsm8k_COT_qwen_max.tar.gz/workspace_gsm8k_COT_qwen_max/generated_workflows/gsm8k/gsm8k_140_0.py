# Workflow ID: gsm8k_140_0
# Benchmark: gsm8k
# Data Indices: [260, 544]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (numerical values, units, relationships)
        extract_instruction = (
            "Extract all numerical values, units, and relationships from the problem. "
            "Include explicit descriptions of what each number represents and how they relate to each other. "
            "Ensure the extraction is complete and accurate for solving the problem."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Plan solution steps (sequence of operations)
        plan_instruction = (
            f"Based on the extracted information: {extracted_info}, create a detailed step-by-step plan to solve the problem. "
            "Include the sequence of mathematical operations (e.g., addition, multiplication), intermediate results, "
            "and any necessary unit conversions. Ensure the plan accounts for real-world constraints and the problem's context."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute calculations sequentially
        execute_instruction = (
            f"Follow this solution plan: {solution_plan}. Perform the calculations step by step, "
            "ensuring each intermediate result is accurate and consistent with the problem's context. "
            "Provide the final numerical result at the end."
        )
        calculations = await self.generate(instruction=execute_instruction, context=self.problem_text)

        # Step 4: Validate and refine intermediate results
        refine_instruction = (
            f"Critique the following calculations: {calculations}. Check for accuracy, consistency, "
            "and alignment with the problem's context. Suggest refinements if necessary."
        )
        refined_result = await self.revise(instruction=refine_instruction, context=calculations)

        # Step 5: Summarize the final answer
        summarize_instruction = (
            f"Condense the refined result: {refined_result} into a single numerical value. "
            "Ensure the answer makes sense in the context of the problem and includes appropriate units if needed."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_result)

        return final_answer