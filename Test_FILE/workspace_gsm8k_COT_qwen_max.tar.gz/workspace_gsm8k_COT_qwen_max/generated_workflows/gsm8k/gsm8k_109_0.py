# Workflow ID: gsm8k_109_0
# Benchmark: gsm8k
# Data Indices: [405, 574]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key numerical values, relationships, and the question
        extraction_instruction = (
            "Extract all numerical values, relationships (e.g., addition, subtraction, multiplication, division), "
            "and the specific question being asked from the problem. Format the output clearly."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate a detailed solution plan
        solution_plan_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Create a step-by-step plan to solve the problem. Include intermediate calculations, "
            "the order of operations, and any necessary unit conversions. Ensure the plan is comprehensive."
        )
        solution_plan = await self.generate(instruction=solution_plan_instruction, context=self.problem_text)

        # Step 3: Perform calculations based on the solution plan
        calculation_instruction = (
            f"Follow this solution plan:\n{solution_plan}\n"
            "Perform the calculations step-by-step. Show all intermediate results and ensure accuracy."
        )
        calculations = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Revise the solution for accuracy and completeness
        revision_instruction = (
            f"Review the following solution:\n{calculations}\n"
            "Check for calculation errors, verify unit consistency, and ensure the final answer makes sense "
            "in the context of the problem. Provide suggestions for improvement if needed."
        )
        revised_solution = await self.revise(instruction=revision_instruction, context=calculations)

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"From the following solution:\n{revised_solution}\n"
            "Extract the final numerical answer. Ensure it is a single value (integer or decimal) "
            "and formatted appropriately."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=revised_solution)

        return final_answer