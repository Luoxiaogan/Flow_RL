# Workflow ID: gsm8k_23_0
# Benchmark: gsm8k
# Data Indices: [317, 373]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract known information
        extraction_instruction = (
            "Carefully analyze the problem statement and extract all numerical values, "
            "relationships, and constraints. Identify the unknowns and what needs to be solved. "
            "Format the extracted information clearly for further processing."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a solution strategy
        strategy_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Develop a step-by-step plan to solve the problem. Include any intermediate calculations, "
            "equations, or logical deductions required. Ensure the plan is comprehensive and systematic."
        )
        solution_strategy = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Perform calculations
        calculation_instruction = (
            f"Using the following solution strategy:\n{solution_strategy}\n"
            "Execute the calculations step-by-step. Document all intermediate results and ensure "
            "accuracy at each stage. Verify that units are consistent and that the final result "
            "is expressed as a single numerical value."
        )
        calculated_result = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Validate the solution
        validation_instruction = (
            f"Review the following calculated result:\n{calculated_result}\n"
            "Critique the solution for accuracy, logical consistency, and adherence to the problem's "
            "constraints. Identify and correct any errors or inconsistencies."
        )
        validated_result = await self.revise(instruction=validation_instruction, context=calculated_result)

        # Step 5: Summarize the answer
        summary_instruction = (
            f"Condense the following validated result into a concise format:\n{validated_result}\n"
            "Ensure the final output is a single numerical value that directly answers the problem."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=validated_result)

        return final_answer