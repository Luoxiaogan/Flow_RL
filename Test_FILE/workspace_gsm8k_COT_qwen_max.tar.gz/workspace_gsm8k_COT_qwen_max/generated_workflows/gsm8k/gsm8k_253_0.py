# Workflow ID: gsm8k_253_0
# Benchmark: gsm8k
# Data Indices: [508, 510]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract numerical values, units, and relationships
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, units, and relationships. "
            "List them clearly and explain their significance in the context of the problem."
        )
        extracted_data = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate a step-by-step solution plan
        plan_instruction = (
            f"Based on the extracted data: {extracted_data}, create a detailed step-by-step plan to solve the problem. "
            "Include all necessary calculations, unit conversions, and logical reasoning. Ensure the plan is chronological and complete."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute parallel solution approaches
        approach1_instruction = (
            f"Follow this plan strictly: {solution_plan}. Perform the calculations step by step and provide the final answer."
        )
        approach2_instruction = (
            f"Re-evaluate the problem using an alternative approach. Consider different interpretations or intermediate steps. "
            "Provide a second candidate solution based on this alternative reasoning."
        )
        results = await asyncio.gather(
            self.generate(instruction=approach1_instruction, context=self.problem_text),
            self.generate(instruction=approach2_instruction, context=self.problem_text)
        )

        # Step 4: Ensemble decision to select the best solution
        ensemble_instruction = (
            "Compare the following candidate solutions and select the most accurate and contextually appropriate one. "
            "Explain the reasoning behind your choice. If there are discrepancies, resolve them logically."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 5: Refine the final answer
        refinement_instruction = (
            "Review the selected solution and refine it for clarity, correctness, and formatting. "
            "Ensure the final answer is presented as a single numerical value with appropriate units if needed."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_solution)

        return refined_answer