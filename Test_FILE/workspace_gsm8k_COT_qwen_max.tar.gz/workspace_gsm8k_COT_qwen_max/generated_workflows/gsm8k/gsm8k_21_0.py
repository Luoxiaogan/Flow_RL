# Workflow ID: gsm8k_21_0
# Benchmark: gsm8k
# Data Indices: [225, 428]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information
        extraction_instruction = """
        Analyze the problem and extract all numerical values, relationships, and units.
        Include any implicit information or constraints mentioned in the problem.
        Format the output as a structured list of key-value pairs.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Create a step-by-step solution plan
        planning_instruction = f"""
        Based on the following extracted information:
        {extracted_info}
        
        Create a detailed step-by-step plan to solve the problem.
        Include all intermediate calculations and ensure the plan addresses any hidden steps.
        Format the plan as a numbered list of actions.
        """
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Generate multiple solution approaches in parallel
        approach_instruction_template = f"""
        Follow this step-by-step plan to solve the problem:
        {solution_plan}
        
        Perform the calculations carefully and document each step clearly.
        Ensure the solution adheres to the problem's context and constraints.
        """
        approach1 = self.generate(instruction=approach_instruction_template, context=self.problem_text)
        approach2 = self.generate(instruction=approach_instruction_template, context=self.problem_text)
        approach3 = self.generate(instruction=approach_instruction_template, context=self.problem_text)
        results = await asyncio.gather(approach1, approach2, approach3)

        # Step 4: Ensemble selection of the best solution
        ensemble_instruction = """
        Compare the following solutions and select the best one based on correctness, clarity, and adherence to the problem context.
        Provide a brief justification for your choice.
        """
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 5: Revise the selected solution
        revision_instruction = """
        Review the following solution and refine it for clarity, correctness, and conciseness.
        Ensure the solution maintains unit consistency and logical flow.
        """
        refined_solution = await self.revise(instruction=revision_instruction, context=best_solution)

        # Step 6: Summarize the final answer
        summarization_instruction = """
        Extract the final numerical answer from the solution.
        Ensure the answer is clear, concise, and formatted appropriately.
        """
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_solution)

        return final_answer