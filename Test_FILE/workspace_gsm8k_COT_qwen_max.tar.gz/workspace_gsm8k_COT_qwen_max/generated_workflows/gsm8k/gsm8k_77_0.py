# Workflow ID: gsm8k_77_0
# Benchmark: gsm8k
# Data Indices: [323, 540]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all numerical values, relationships, and constraints
        extraction_instruction = (
            "Extract all numerical values, units, and relationships from the problem. "
            "Identify known quantities, unknowns, and any constraints. "
            "Ensure the output is structured and easy to interpret."
        )
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Model the problem mathematically
        modeling_instruction = (
            f"Based on the extracted information: {extraction}\n"
            "Model the problem mathematically. Identify the sequence of operations needed to solve it. "
            "Include intermediate steps, handle units consistently, and account for real-world constraints."
        )
        model = await self.generate(instruction=modeling_instruction, context=self.problem_text)

        # Step 3: Execute the solution step by step
        execution_instruction = (
            f"Using the mathematical model: {model}\n"
            "Execute the solution step by step. Perform all necessary calculations, ensuring accuracy at each stage. "
            "Clearly document intermediate results and their significance."
        )
        execution = await self.generate(instruction=execution_instruction, context=self.problem_text)

        # Step 4: Revise and refine intermediate results
        refinement_instruction = (
            "Critique and refine the intermediate results. Ensure all calculations are accurate, "
            "units are consistent, and the solution aligns with the problem's constraints."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=execution)

        # Step 5: Summarize the final answer
        summarization_instruction = (
            "Condense the solution into a single numerical value. "
            "Ensure the answer is clear, correct, and makes sense in the context of the problem."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_solution)

        return final_answer