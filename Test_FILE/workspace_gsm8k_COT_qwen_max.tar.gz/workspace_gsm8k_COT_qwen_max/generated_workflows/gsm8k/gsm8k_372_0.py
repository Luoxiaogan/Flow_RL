# Workflow ID: gsm8k_372_0
# Benchmark: gsm8k
# Data Indices: [303, 592]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all numerical values, units, and relationships from the problem. "
            "Identify what is being asked and list any constraints or conditions explicitly stated. "
            "Organize the information in a structured format for further processing."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Perform intermediate calculations
        calculation_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "break the problem into intermediate steps. Solve each step sequentially, "
            "ensuring that units are consistent and all calculations are justified. "
            "Provide intermediate results clearly."
        )
        intermediate_results = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 3: Validate and refine results
        validation_instruction = (
            "Review the intermediate results for accuracy. Check for consistency in units, "
            "correct application of arithmetic operations, and adherence to problem constraints. "
            "Refine any incorrect or ambiguous steps."
        )
        refined_results = await self.revise(instruction=validation_instruction, context=intermediate_results)

        # Step 4: Summarize the final answer
        summary_instruction = (
            "Condense the reasoning process and present the final numerical answer. "
            "Ensure the answer is clearly stated and makes sense in the context of the problem."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_results)

        return final_answer