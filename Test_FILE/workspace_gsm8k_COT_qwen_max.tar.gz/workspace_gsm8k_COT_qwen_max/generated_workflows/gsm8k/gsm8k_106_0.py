# Workflow ID: gsm8k_106_0
# Benchmark: gsm8k
# Data Indices: [143, 195]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract known information
        extract_instruction = (
            "Carefully analyze the problem and extract all numerical values, relationships, and constraints. "
            "Identify what is given, what is asked, and any implicit assumptions or hidden steps. "
            "Format the extracted information clearly, labeling each piece of data."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Formulate a solution plan
        plan_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Create a step-by-step plan to solve the problem. "
            "Include the sequence of operations (e.g., addition, subtraction), intermediate calculations, "
            "and how to handle units and constraints. "
            "Ensure the plan is logically consistent and accounts for all given data."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute the solution
        execute_instruction = (
            f"Using the following solution plan:\n{solution_plan}\n"
            "Perform the calculations step by step. "
            "Show all intermediate results and verify their correctness. "
            "Ensure the final answer is clearly stated and makes sense in the context of the problem."
        )
        solution = await self.generate(instruction=execute_instruction, context=self.problem_text)

        # Step 4: Refine and validate the solution
        refine_instruction = (
            f"Review the following solution:\n{solution}\n"
            "Critique and refine it to ensure accuracy and clarity. "
            "Verify that the answer satisfies all constraints and makes sense in the problem's context. "
            "Correct any errors or omissions."
        )
        refined_solution = await self.revise(instruction=refine_instruction, context=solution)

        # Step 5: Summarize the final answer
        summarize_instruction = (
            f"Condense the following solution into a concise summary:\n{refined_solution}\n"
            "Highlight the final numerical answer and ensure it is presented clearly."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_answer