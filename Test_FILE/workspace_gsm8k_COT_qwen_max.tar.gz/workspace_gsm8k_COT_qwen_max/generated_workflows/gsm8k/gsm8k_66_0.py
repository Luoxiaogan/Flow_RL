# Workflow ID: gsm8k_66_0
# Benchmark: gsm8k
# Data Indices: [204, 730]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (numerical values, relationships, constraints)
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, "
            "relationships between quantities, and any constraints or conditions. "
            "Organize this information clearly and label each component."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Translate the problem into a mathematical model
        modeling_instruction = (
            f"Using the following extracted information: {extracted_info}\n"
            "Translate the word problem into a mathematical model. "
            "Clearly identify the unknowns, outline the necessary calculations, "
            "and specify the logical order of operations. Include units and ensure "
            "all constraints are incorporated."
        )
        mathematical_model = await self.generate(instruction=modeling_instruction, context=self.problem_text)

        # Step 3: Generate two independent solution approaches in parallel
        approach_1_instruction = (
            f"Based on the mathematical model: {mathematical_model}\n"
            "Solve the problem step by step. Clearly show all intermediate calculations, "
            "ensure proper unit handling, and verify that the solution satisfies all constraints."
        )
        approach_2_instruction = (
            f"Using the same mathematical model: {mathematical_model}\n"
            "Solve the problem step by step using a different reasoning path if possible. "
            "Ensure all intermediate steps are documented, and validate the solution against the problem's context."
        )
        approach_1, approach_2 = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text)
        )

        # Step 4: Compare and select the best solution
        ensemble_instruction = (
            "Evaluate the following two solutions and select the best one:\n"
            f"Solution 1: {approach_1}\n"
            f"Solution 2: {approach_2}\n"
            "Consider accuracy, logical consistency, adherence to constraints, and clarity. "
            "If both solutions are valid, choose the more straightforward or elegant one."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=[approach_1, approach_2])

        # Step 5: Refine the final solution
        refinement_instruction = (
            f"Refine the following solution to ensure it is clear, correct, and complete: {best_solution}\n"
            "Verify that all steps are justified, units are consistent, and the answer makes sense in the context of the problem. "
            "Format the final answer appropriately (e.g., as a single numerical value)."
        )
        final_answer = await self.revise(instruction=refinement_instruction, context=best_solution)

        return final_answer