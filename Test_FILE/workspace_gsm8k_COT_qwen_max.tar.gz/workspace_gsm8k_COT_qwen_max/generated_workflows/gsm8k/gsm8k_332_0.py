# Workflow ID: gsm8k_332_0
# Benchmark: gsm8k
# Data Indices: [113, 294]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information
        extraction_instruction = (
            "Analyze the problem thoroughly and extract all numerical values, relationships (e.g., 'twice the first number'), "
            "constraints (e.g., 'no reading on certain days'), and the specific question being asked. "
            "Format the output as a structured summary."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a solution plan
        plan_instruction = (
            f"Using the following extracted information: {extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. Ensure all steps are logically ordered, "
            "mathematically sound, and account for any unit conversions or contextual constraints."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute calculations
        calculation_instructions = []
        for step in solution_plan.split("\n"):  # Assuming plan steps are newline-separated
            calc_instruction = (
                f"Perform the following calculation step: {step}\n"
                "Ensure the result is accurate and formatted appropriately."
            )
            calculation_instructions.append(calc_instruction)
        
        calculation_tasks = [
            self.generate(instruction=instr, context=self.problem_text) for instr in calculation_instructions
        ]
        calculation_results = await asyncio.gather(*calculation_tasks)

        # Step 4: Verify and refine results
        refinement_instruction = (
            "Review the following calculation results and verify their correctness:\n"
            f"{calculation_results}\n"
            "Ensure all calculations align with the problem constraints, maintain unit consistency, and lead to a valid final answer. "
            "Refine any incorrect or ambiguous results."
        )
        refined_results = await self.revise(instruction=refinement_instruction, context="\n".join(calculation_results))

        # Step 5: Extract the final answer
        final_answer_instruction = (
            "From the following refined results, extract the final numerical answer:\n"
            f"{refined_results}\n"
            "Ensure the answer is a single numerical value (integer or decimal) and is clearly stated."
        )
        final_answer = await self.summarize(instruction=final_answer_instruction, context=refined_results)

        return final_answer