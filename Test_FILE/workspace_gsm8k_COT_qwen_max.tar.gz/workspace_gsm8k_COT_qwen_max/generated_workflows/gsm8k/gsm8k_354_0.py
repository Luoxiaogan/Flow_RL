# Workflow ID: gsm8k_354_0
# Benchmark: gsm8k
# Data Indices: [327, 714]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract known information
        extraction_instruction = (
            "Extract all numerical values, relationships, and key entities from the problem. "
            "Include units, if mentioned, and describe the relationships between the numbers. "
            "For example, indicate if a number represents an initial quantity, a change, or a final quantity. "
            "Ensure the extraction is complete and accurate."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        approach_instruction = (
            f"Based on the following extracted information: {extracted_info}\n"
            "Generate multiple possible solution approaches for the problem. "
            "Each approach should include a clear plan of action, specifying the sequence of calculations and any intermediate results needed. "
            "Consider different interpretations of the problem if applicable."
        )
        approaches = await asyncio.gather(
            self.generate(instruction=approach_instruction, context=self.problem_text),
            self.generate(instruction=approach_instruction, context=self.problem_text)
        )

        # Step 3: Select the best approach
        ensemble_instruction = (
            "Evaluate the following solution approaches and select the most promising one. "
            "Consider accuracy, clarity, and alignment with the problem's context. "
            "If both approaches are equally valid, choose the simpler one."
        )
        selected_approach = await self.ensemble(instruction=ensemble_instruction, contexts=approaches)

        # Step 4: Perform calculations
        calculation_instruction = (
            f"Using the selected approach: {selected_approach}\n"
            "Perform the calculations step by step. Include all intermediate results and ensure units are consistent. "
            "Clearly explain each step and how it contributes to solving the problem."
        )
        solution = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 5: Verify and refine the solution
        revision_instruction = (
            f"Review the following solution: {solution}\n"
            "Check for errors, inconsistencies, or missing steps. Ensure the solution makes sense in the context of the problem. "
            "Refine the solution if necessary, providing a corrected version."
        )
        refined_solution = await self.revise(instruction=revision_instruction, context=solution)

        # Step 6: Summarize the final answer
        summary_instruction = (
            f"Summarize the final solution: {refined_solution}\n"
            "Provide only the numerical answer with appropriate units, if applicable. "
            "Ensure the answer is concise and directly addresses the problem."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer