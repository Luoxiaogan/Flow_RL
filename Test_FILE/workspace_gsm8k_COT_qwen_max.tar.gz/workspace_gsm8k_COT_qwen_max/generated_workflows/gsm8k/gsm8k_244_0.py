# Workflow ID: gsm8k_244_0
# Benchmark: gsm8k
# Data Indices: [293, 611]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information (numerical values, relationships, entities)
        extraction_instruction = (
            "Extract all numerical values, relationships, and entities mentioned in the problem. "
            "Include any constraints or conditions explicitly stated. Format the output as a structured list."
        )
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Translate extracted information into intermediate steps
        intermediate_instruction = (
            f"Given the following extracted information: {extraction}\n"
            "Translate the relationships and constraints into mathematical expressions or logical steps. "
            "Ensure each step is clearly defined and computable."
        )
        intermediate_steps = await self.generate(instruction=intermediate_instruction, context=self.problem_text)

        # Step 3: Compute the solution step by step
        computation_instruction = (
            f"Using the following intermediate steps: {intermediate_steps}\n"
            "Perform the necessary calculations to arrive at the final solution. "
            "Show all steps explicitly and ensure units are consistent."
        )
        solution = await self.generate(instruction=computation_instruction, context=self.problem_text)

        # Step 4: Validate and refine the solution
        refinement_instruction = (
            f"Review the following solution: {solution}\n"
            "Check for consistency with the problem context, including units, constraints, and logical coherence. "
            "Refine the solution if necessary to ensure accuracy."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=solution)

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"From the following refined solution: {refined_solution}\n"
            "Extract and present the final numerical answer. Ensure the output is a single value."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer