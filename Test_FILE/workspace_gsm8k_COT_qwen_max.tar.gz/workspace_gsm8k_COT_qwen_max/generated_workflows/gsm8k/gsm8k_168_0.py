# Workflow ID: gsm8k_168_0
# Benchmark: gsm8k
# Data Indices: [240, 296]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract known information
        extract_instruction = (
            "Extract all numerical values, units, and relationships from the problem. "
            "Identify any implicit constraints or conditions. "
            "Organize the information clearly for subsequent reasoning."
        )
        extract_task = self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Formulate a solution plan
        plan_instruction = (
            "Based on the extracted information, create a step-by-step solution plan. "
            "Include all necessary calculations, intermediate steps, and unit conversions. "
            "Ensure the plan adheres to real-world constraints and chronological reasoning."
        )
        plan_task = self.generate(instruction=plan_instruction, context=self.problem_text)

        # Run extraction and planning in parallel
        extract_result, plan_result = await asyncio.gather(extract_task, plan_task)

        # Step 3: Perform calculations
        calculate_instruction = (
            f"Using the extracted information: {extract_result} "
            f"and the solution plan: {plan_result}, perform the calculations step by step. "
            "Track units consistently and validate intermediate results. "
            "Provide the final numerical answer with appropriate precision."
        )
        calculate_task = self.generate(instruction=calculate_instruction, context=self.problem_text)

        # Step 4: Revise and validate
        revise_instruction = (
            "Critique the calculated result for logical consistency, mathematical accuracy, and contextual validity. "
            "Check for calculation errors, missing steps, or violations of constraints. "
            "Suggest refinements if necessary."
        )
        revise_task = self.revise(instruction=revise_instruction, context=calculate_task)

        # Run calculation and revision in parallel
        calculate_result, revise_result = await asyncio.gather(calculate_task, revise_task)

        # Step 5: Summarize the final answer
        summarize_instruction = (
            "Condense the solution into a concise format that highlights the final numerical answer. "
            "Ensure clarity and readability of the output."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=revise_result)

        return final_answer