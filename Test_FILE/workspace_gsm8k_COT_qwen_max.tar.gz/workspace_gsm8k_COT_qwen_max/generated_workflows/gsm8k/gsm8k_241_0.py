# Workflow ID: gsm8k_241_0
# Benchmark: gsm8k
# Data Indices: [10, 103]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information (numerical values, relationships, unknowns)
        extract_instruction = (
            "Extract all numerical values, units, relationships, and constraints from the problem. "
            "Identify what is known and what is being asked. Ensure the output is structured and clear."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Formulate a step-by-step solution plan
        plan_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. Include intermediate calculations, "
            "unit handling, and logical sequencing of operations. Ensure the plan is clear and actionable."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Perform calculations and derive intermediate results
        calculate_instruction = (
            f"Follow this solution plan: {solution_plan}\n"
            "Perform all calculations step by step. Show all intermediate results explicitly. "
            "Ensure the final result is accurate and includes appropriate units."
        )
        calculated_results = await self.generate(instruction=calculate_instruction, context=self.problem_text)

        # Step 4: Validate the solution
        validate_instruction = (
            f"Review the calculated results: {calculated_results}\n"
            "Critique the solution for accuracy, unit consistency, and contextual relevance. "
            "Ensure the answer makes sense in the real-world scenario described in the problem."
        )
        validation = await self.revise(instruction=validate_instruction, context=calculated_results)

        # Step 5: Summarize the final answer
        summarize_instruction = (
            f"Condense the validated solution: {validation}\n"
            "Provide the final answer as a single numerical value, ensuring it is concise and clear."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=validation)

        return final_answer