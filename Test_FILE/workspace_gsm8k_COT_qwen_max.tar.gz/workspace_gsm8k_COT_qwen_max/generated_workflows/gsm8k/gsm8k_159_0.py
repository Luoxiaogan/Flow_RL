# Workflow ID: gsm8k_159_0
# Benchmark: gsm8k
# Data Indices: [85, 395]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (numerical values, relationships, question)
        extraction_instruction = """
        Extract all numerical values, units, and relationships mentioned in the problem. 
        Identify what the question is asking for and categorize the information into knowns and unknowns.
        Ensure that all units are explicitly noted and any implicit relationships are clarified.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate a step-by-step solution plan
        modeling_instruction = f"""
        Based on the following extracted information: {extracted_info}
        Create a detailed step-by-step plan to solve the problem. 
        Include all necessary calculations, intermediate steps, and unit conversions. 
        Ensure that the plan adheres to the correct order of operations and accounts for any hidden steps.
        """
        solution_plan = await self.generate(instruction=modeling_instruction, context=self.problem_text)

        # Step 3: Generate multiple solution approaches in parallel
        direct_calculation_instruction = f"""
        Solve the problem using direct calculations based on the following plan: {solution_plan}
        Focus on straightforward arithmetic operations and ensure all units are consistent.
        """
        proportional_reasoning_instruction = f"""
        Solve the problem using proportional reasoning or rate-based calculations based on the following plan: {solution_plan}
        Focus on identifying and applying ratios, percentages, or rates as needed.
        """
        direct_solution, proportional_solution = await asyncio.gather(
            self.generate(instruction=direct_calculation_instruction, context=self.problem_text),
            self.generate(instruction=proportional_reasoning_instruction, context=self.problem_text)
        )

        # Step 4: Select the best solution using Ensemble
        selection_instruction = """
        Evaluate the following solutions and select the best one based on correctness, clarity, and adherence to real-world constraints.
        Ensure that the chosen solution properly handles units and provides a single numerical answer.
        """
        final_solution = await self.ensemble(instruction=selection_instruction, contexts=[direct_solution, proportional_solution])

        # Step 5: Refine the final solution
        refinement_instruction = """
        Refine the following solution to ensure proper formatting, unit consistency, and clarity. 
        The final output should be a single numerical value with appropriate decimal places.
        """
        refined_solution = await self.revise(instruction=refinement_instruction, context=final_solution)

        return refined_solution