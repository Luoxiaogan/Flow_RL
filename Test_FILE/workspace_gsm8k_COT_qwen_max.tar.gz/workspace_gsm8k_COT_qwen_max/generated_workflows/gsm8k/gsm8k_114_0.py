# Workflow ID: gsm8k_114_0
# Benchmark: gsm8k
# Data Indices: [69, 161]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all known information (numerical values, relationships, constraints)
        extract_instruction = (
            "Carefully analyze the problem and extract all numerical values, relationships, and constraints. "
            "Include units (if any) and describe how these values relate to each other. "
            "Ensure completeness and clarity."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Identify unknowns and intermediate steps
        identify_instruction = (
            f"Based on the extracted information: {extracted_info}, "
            "identify what the problem is asking for (the unknown). "
            "List all intermediate steps required to solve the problem, including any hidden calculations. "
            "Ensure the steps are logically ordered and mathematically sound."
        )
        steps = await self.generate(instruction=identify_instruction, context=self.problem_text)

        # Step 3: Perform calculations step-by-step
        calculate_instruction = (
            f"Using the identified steps: {steps}, perform the calculations in sequence. "
            "Show all work explicitly, including intermediate results. "
            "Handle units consistently and ensure mathematical accuracy."
        )
        calculations = await self.generate(instruction=calculate_instruction, context=self.problem_text)

        # Step 4: Validate and refine the solution
        refine_instruction = (
            f"Review the calculations: {calculations}. "
            "Check for accuracy, logical consistency, and adherence to real-world constraints (e.g., no negative quantities). "
            "Refine the solution if necessary, providing corrections or clarifications."
        )
        refined_solution = await self.revise(instruction=refine_instruction, context=calculations)

        # Step 5: Summarize the final answer
        summarize_instruction = (
            f"Condense the refined solution: {refined_solution} into a single numerical value. "
            "Ensure the answer is clear, precise, and formatted correctly."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_answer