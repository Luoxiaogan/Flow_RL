# Workflow ID: gsm8k_175_0
# Benchmark: gsm8k
# Data Indices: [30, 605]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract known values and relationships
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, relationships (e.g., 'half as many,' '4 times the number'), "
            "and the specific question being asked. Format the output clearly with labels for each piece of information."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a detailed solution plan
        plan_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Create a step-by-step plan to solve the problem. Include all necessary calculations, intermediate steps, "
            "and ensure the sequence of operations is logical and consistent with the problem's context."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Perform calculations based on the plan
        calculation_instruction = (
            f"Follow this solution plan step by step:\n{solution_plan}\n"
            "Perform all required calculations, showing intermediate results. Ensure that units and constraints are respected, "
            "and provide the final numerical answer."
        )
        calculated_result = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Validate the solution
        validation_instruction = (
            f"Review the following solution:\n{calculated_result}\n"
            "Critique it for accuracy, logical consistency, and adherence to the problem's context. "
            "Ensure there are no calculation errors, unrealistic values (e.g., negative quantities), or missing steps. "
            "If necessary, suggest corrections."
        )
        validated_solution = await self.revise(instruction=validation_instruction, context=calculated_result)

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"From the validated solution:\n{validated_solution}\n"
            "Extract and present the final numerical answer. Ensure it is clear, concise, and directly addresses the problem's question."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=validated_solution)

        return final_answer