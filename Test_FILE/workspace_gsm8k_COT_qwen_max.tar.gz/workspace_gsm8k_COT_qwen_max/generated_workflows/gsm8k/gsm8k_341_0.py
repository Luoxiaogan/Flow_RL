# Workflow ID: gsm8k_341_0
# Benchmark: gsm8k
# Data Indices: [576, 372]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information from the problem
        extract_instruction = (
            "Extract all numerical values, units, relationships, and the question being asked from the problem. "
            "Organize the information clearly, labeling each part for easy reference."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Plan the solution strategy
        plan_instruction = (
            f"Based on the following extracted information: {extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. Include:\n"
            "- Sequence of operations (addition, subtraction, multiplication, division)\n"
            "- Handling of units and conversions\n"
            "- Any intermediate calculations required\n"
            "- Verification steps to ensure correctness\n"
            "Ensure the plan is clear and actionable."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute the solution plan
        execute_instruction = (
            f"Follow this solution plan step by step: {solution_plan}\n"
            "Perform the calculations sequentially, producing intermediate results at each step. "
            "Label each intermediate result clearly and verify its correctness before proceeding."
        )
        execution_result = await self.generate(instruction=execute_instruction, context=self.problem_text)

        # Step 4: Summarize the final result
        summarize_instruction = (
            "Condense the final result and any critical intermediate steps into a concise summary. "
            "Ensure the final answer is clearly stated and includes appropriate units."
        )
        final_summary = await self.summarize(instruction=summarize_instruction, context=execution_result)

        # Step 5: Verify the result for reasonableness
        verify_instruction = (
            f"Verify the following result: {final_summary}\n"
            "Check for:\n"
            "- Logical consistency with the problem context\n"
            "- Correct handling of units and magnitudes\n"
            "- Reasonableness of the final value\n"
            "If any issues are found, suggest corrections."
        )
        verification = await self.revise(instruction=verify_instruction, context=final_summary)

        # Step 6: Finalize the answer
        finalize_instruction = (
            f"Based on the verification: {verification}\n"
            "Finalize the answer, ensuring it is clear, correct, and formatted appropriately."
        )
        final_answer = await self.generate(instruction=finalize_instruction, context=verification)

        return final_answer