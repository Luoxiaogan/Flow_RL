# Workflow ID: gsm8k_212_0
# Benchmark: gsm8k
# Data Indices: [424, 72]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information
        extraction_instruction = (
            "Extract all numerical values, units, relationships, and constraints from the problem. "
            "Identify any implicit steps or intermediate calculations required. "
            "Provide the information in a structured format, labeling each piece clearly."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a step-by-step plan
        plan_instruction = (
            f"Based on the extracted information: {extracted_info}, formulate a step-by-step plan to solve the problem. "
            "Include all necessary calculations, their order, and any assumptions made. "
            "Ensure the plan is clear and follows a logical sequence."
        )
        plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute calculations in parallel
        execution_instruction_template = (
            "Perform the following calculation step: {step}. "
            "Ensure you show your work and provide the result with appropriate units."
        )
        steps = plan.split("\n")  # Assuming plan is formatted with steps separated by newlines
        calculation_tasks = [
            self.generate(instruction=execution_instruction_template.format(step=step), context=self.problem_text)
            for step in steps if step.strip()
        ]
        calculation_results = await asyncio.gather(*calculation_tasks)

        # Step 4: Validate and refine the solution
        validation_instruction = (
            f"Validate the following results: {calculation_results}. "
            "Check for consistency in units, adherence to problem constraints, and logical correctness. "
            "Refine the solution if necessary."
        )
        validated_solution = await self.revise(instruction=validation_instruction, context=self.problem_text)

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"Summarize the solution based on the validated results: {validated_solution}. "
            "Highlight the final numerical answer and ensure it is clear and concise."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=self.problem_text)

        return final_answer