# Workflow ID: gsm8k_364_0
# Benchmark: gsm8k
# Data Indices: [193, 257]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract known information
        extraction_instruction = (
            "Extract all numerical values, relationships, and constraints from the problem. "
            "Include units and contextual information. Format the output as a structured list."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a solution plan
        plan_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. "
            "Include intermediate calculations, their logical sequence, and any hidden steps. "
            "Ensure the plan accounts for unit consistency and real-world constraints."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute calculations
        calculation_instruction = (
            f"Follow this solution plan: {solution_plan}\n"
            "Perform each calculation step-by-step, producing intermediate results. "
            "Ensure units are consistent and calculations are accurate."
        )
        calculations = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Validate results
        validation_instruction = (
            f"Review the calculations: {calculations}\n"
            "Check for consistency, unit correctness, and adherence to the problem's constraints. "
            "If errors are found, provide detailed feedback for refinement."
        )
        validated_results = await self.revise(instruction=validation_instruction, context=calculations)

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"Condense the final result from the validated calculations: {validated_results}\n"
            "Provide the answer as a single numerical value, ensuring it aligns with the problem's requirements."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=validated_results)

        return final_answer