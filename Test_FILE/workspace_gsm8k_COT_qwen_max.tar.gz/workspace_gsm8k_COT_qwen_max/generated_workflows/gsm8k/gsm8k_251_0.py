# Workflow ID: gsm8k_251_0
# Benchmark: gsm8k
# Data Indices: [685, 429]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract known information
        extract_instruction = (
            "Carefully analyze the problem and extract all numerical values, relationships, "
            "and contextual clues. List them clearly and label each piece of information. "
            "Pay attention to units, constraints, and any hidden assumptions."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Identify unknowns and plan solution steps
        plan_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Determine what the problem is asking for (the unknown). Then, create a detailed, "
            "step-by-step plan to solve the problem. Include all necessary calculations, "
            "unit conversions, and logical reasoning. Ensure the plan is chronological and explicit."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Perform calculations
        calculate_instruction = (
            f"Follow this step-by-step plan:\n{solution_plan}\n"
            "Execute each calculation carefully, stating intermediate results explicitly. "
            "Ensure all units are consistent and verify each step logically."
        )
        calculations = await self.generate(instruction=calculate_instruction, context=self.problem_text)

        # Step 4: Validate and refine results
        refine_instruction = (
            f"Review the following calculations:\n{calculations}\n"
            "Critique the solution for accuracy, consistency, and logical correctness. "
            "Refine any steps that contain errors or ambiguities. Ensure the final result "
            "makes sense in the context of the problem."
        )
        refined_solution = await self.revise(instruction=refine_instruction, context=calculations)

        # Step 5: Summarize the final answer
        summarize_instruction = (
            f"Condense the following solution into a concise summary:\n{refined_solution}\n"
            "Highlight the final numerical answer, ensuring it is clear and unambiguous."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_answer