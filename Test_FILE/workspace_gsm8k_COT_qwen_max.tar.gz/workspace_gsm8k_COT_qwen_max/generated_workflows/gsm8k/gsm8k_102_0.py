# Workflow ID: gsm8k_102_0
# Benchmark: gsm8k
# Data Indices: [352, 793]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract Knowns and Unknowns
        extraction_instruction = (
            "Extract all numerical values, relationships, and constraints from the problem. "
            "Identify the known quantities, unknowns, and any dependencies or relationships between them. "
            "Present the information in a structured format."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan the Solution
        plan_instruction = (
            f"Based on the following extracted information: {extracted_info}\n"
            "Create a detailed plan to solve the problem. Outline the sequence of calculations, "
            "intermediate steps, and reasoning required to arrive at the solution. "
            "Ensure the plan is clear, logical, and accounts for all constraints."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute the Plan
        execution_instruction = (
            f"Follow this plan step by step: {solution_plan}\n"
            "Perform the calculations, ensuring units are consistent and intermediate results are verified. "
            "Provide the final result along with any necessary explanations."
        )
        executed_solution = await self.generate(instruction=execution_instruction, context=self.problem_text)

        # Step 4: Validate and Refine
        validation_instruction = (
            f"Review the following solution: {executed_solution}\n"
            "Check for calculation errors, logical inconsistencies, or overlooked constraints. "
            "Refine the solution if necessary to ensure accuracy and alignment with the problem context."
        )
        refined_solution = await self.revise(instruction=validation_instruction, context=executed_solution)

        # Step 5: Summarize the Final Answer
        summary_instruction = (
            f"Condense the following solution into a concise format: {refined_solution}\n"
            "Ensure the final answer is presented as a single numerical value (integer or decimal)."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer