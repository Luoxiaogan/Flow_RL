# Workflow ID: gsm8k_76_0
# Benchmark: gsm8k
# Data Indices: [541, 559]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract known values and relationships
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, units, and relationships. "
            "Identify actions such as addition, subtraction, multiplication, or division. "
            "Highlight any constraints or conditions (e.g., time-based sequences, proportional reasoning)."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Model the problem mathematically
        modeling_instruction = (
            f"Based on the extracted information: {extracted_info}, "
            "create a mathematical model of the problem. Define variables, equations, or sequences of operations. "
            "Ensure the model respects chronological order, unit consistency, and intermediate steps."
        )
        mathematical_model = await self.generate(instruction=modeling_instruction, context=self.problem_text)

        # Step 3: Solve step-by-step
        solving_instruction = (
            f"Using the mathematical model: {mathematical_model}, solve the problem step-by-step. "
            "Perform each calculation explicitly, stating intermediate results. "
            "Verify each step to ensure accuracy and consistency with the problem context."
        )
        step_by_step_solution = await self.generate(instruction=solving_instruction, context=self.problem_text)

        # Step 4: Refine and validate the solution
        refinement_instruction = (
            f"Review the solution: {step_by_step_solution}. "
            "Critique and refine it to ensure it makes sense in the context of the problem. "
            "Check for unit consistency, hidden steps, and real-world constraints (e.g., non-negative quantities)."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=step_by_step_solution)

        # Step 5: Summarize the final answer
        summarization_instruction = (
            f"Condense the refined solution: {refined_solution} into a concise format. "
            "Extract and highlight the final numerical answer while preserving its context."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_solution)

        return final_answer