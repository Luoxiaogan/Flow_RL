# Workflow ID: gsm8k_382_0
# Benchmark: gsm8k
# Data Indices: [595, 667]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, units, relationships, "
            "and constraints. Include any implicit information that can be inferred from the context. "
            "Format the output clearly, labeling each piece of information."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan the solution steps
        planning_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Plan the sequence of steps required to solve the problem. Identify any intermediate "
            "calculations, unit conversions, or logical reasoning needed. Ensure the steps are "
            "chronologically ordered and address all aspects of the problem."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Execute solution steps in parallel
        execution_instruction_template = (
            "Perform the following calculation or reasoning step:\n{{step}}\n"
            "Ensure the result is accurate and include any relevant units or intermediate values."
        )
        steps = solution_plan.split("\n")  # Assuming steps are separated by newlines
        tasks = [
            self.generate(instruction=execution_instruction_template.replace("{{step}}", step), context=self.problem_text)
            for step in steps if step.strip()
        ]
        step_results = await asyncio.gather(*tasks)

        # Step 4: Synthesize results
        synthesis_instruction = (
            "Combine the following results into a final answer:\n" + "\n".join(step_results) + "\n"
            "Ensure the final answer is consistent, addresses the original question, and includes "
            "appropriate units. Resolve any discrepancies or ambiguities."
        )
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=step_results)

        # Step 5: Verify and refine the solution
        verification_instruction = (
            "Review the following solution:\n" + final_answer + "\n"
            "Check for consistency in units, logical correctness, and alignment with the problem context. "
            "Refine the solution if necessary, providing a clear and accurate final answer."
        )
        refined_solution = await self.revise(instruction=verification_instruction, context=final_answer)

        return refined_solution