# Workflow ID: gsm8k_308_0
# Benchmark: gsm8k
# Data Indices: [552, 712]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract known information and problem structure
        extraction_instruction = """
        Extract all numerical values, units, and relationships from the problem. 
        Identify any hidden steps or intermediate calculations required to solve the problem. 
        Highlight any contextual constraints (e.g., non-negative quantities, real-world limitations). 
        Organize the information in a structured format for further processing.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a step-by-step solution plan
        plan_instruction = f"""
        Based on the extracted information: {extracted_info}
        Create a detailed step-by-step plan to solve the problem. 
        Include:
        - The sequence of calculations.
        - Handling of units and conversions if necessary.
        - Verification of intermediate results.
        - Consideration of any contextual constraints.
        Ensure the plan is comprehensive and leaves no ambiguity.
        """
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute the calculations
        calculation_instruction = f"""
        Using the extracted information: {extracted_info}
        And the solution plan: {solution_plan}
        Perform the calculations step by step. 
        Show all intermediate results and ensure unit consistency throughout. 
        Verify that the final answer makes sense in the context of the problem.
        """
        calculated_results = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Revise and validate the solution
        revision_instruction = f"""
        Critique and refine the following solution: {calculated_results}
        Check for:
        - Accuracy of calculations.
        - Consistency of units.
        - Reasonableness of the final answer in the problem's context.
        Address any errors or ambiguities.
        """
        revised_solution = await self.revise(instruction=revision_instruction, context=calculated_results)

        # Step 5: Summarize the final answer
        summary_instruction = """
        Condense the solution into a concise format that highlights the final numerical answer. 
        Ensure the summary is clear and directly addresses the question posed in the problem.
        """
        final_answer = await self.summarize(instruction=summary_instruction, context=revised_solution)

        return final_answer