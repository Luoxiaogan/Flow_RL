# Workflow ID: gsm8k_223_0
# Benchmark: gsm8k
# Data Indices: [549, 17]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract known values and relationships
        extraction_instruction = (
            "Extract all numerical values, units, and relationships from the problem. "
            "Identify what is given and what needs to be calculated. "
            "Ensure that all important information is captured clearly."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a step-by-step solution plan
        plan_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. "
            "Include intermediate calculations, order of operations, and any necessary unit conversions. "
            "Ensure the plan is logical and accounts for all given data."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Perform calculations
        calculation_instruction = (
            f"Follow this step-by-step plan to calculate the solution:\n{solution_plan}\n"
            "Perform each calculation explicitly, showing intermediate results. "
            "Ensure all units are consistent and verify the correctness of each step."
        )
        calculations = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Validate the solution
        validation_instruction = (
            f"Review the following calculations and solution:\n{calculations}\n"
            "Check for logical consistency, arithmetic accuracy, and proper handling of units. "
            "Ensure the solution makes sense in the context of the problem."
        )
        validated_solution = await self.revise(instruction=validation_instruction, context=calculations)

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"Summarize the problem-solving process and provide the final answer:\n{validated_solution}\n"
            "Include only the essential steps and the final numerical result."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=validated_solution)

        return final_summary