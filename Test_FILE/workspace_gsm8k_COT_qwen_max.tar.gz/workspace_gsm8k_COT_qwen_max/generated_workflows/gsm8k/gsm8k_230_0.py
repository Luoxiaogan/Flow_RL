# Workflow ID: gsm8k_230_0
# Benchmark: gsm8k
# Data Indices: [614, 310]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (numerical values, relationships, goal)
        extract_instruction = (
            "Carefully read the problem and extract all numerical values, relationships, "
            "and the specific goal to be achieved. Include units where applicable and "
            "clearly label each piece of information."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Break down the problem into logical steps
        breakdown_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Break the problem into a sequence of logical steps required to solve it. "
            "Include intermediate calculations and explain the purpose of each step."
        )
        breakdown = await self.generate(instruction=breakdown_instruction, context=self.problem_text)

        # Step 3: Perform calculations (parallelizable if multiple independent steps)
        calculation_instruction = (
            f"Using the breakdown: {breakdown}\n"
            "Perform all necessary calculations step by step. Show intermediate results "
            "and ensure all units are consistent. Clearly state the final answer."
        )
        calculations = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Validate the solution
        validation_instruction = (
            f"Review the calculations: {calculations}\n"
            "Ensure the solution adheres to the problem's constraints and makes sense "
            "in the real-world context. Check for unit consistency, logical coherence, "
            "and adherence to any stated conditions."
        )
        validated_solution = await self.revise(instruction=validation_instruction, context=calculations)

        # Return the final validated solution
        return validated_solution