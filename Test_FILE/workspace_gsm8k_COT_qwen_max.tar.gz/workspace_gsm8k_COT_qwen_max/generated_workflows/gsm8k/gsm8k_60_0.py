# Workflow ID: gsm8k_60_0
# Benchmark: gsm8k
# Data Indices: [106, 346]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract knowns and unknowns
        extraction_instruction = (
            "Carefully analyze the problem to identify all numerical values, units, relationships, "
            "and the specific question being asked. Format the output as follows:\n"
            "- Known Values: [list all numerical values with units]\n"
            "- Relationships: [describe relationships between values]\n"
            "- Question: [state what the problem is asking for]"
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate step-by-step solution
        solution_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Solve the problem step by step. Ensure each step is clearly explained and logically follows "
            "from the previous one. Include intermediate results and their units. If there are multiple "
            "steps, number them sequentially."
        )
        initial_solution = await self.generate(instruction=solution_instruction, context=self.problem_text)

        # Step 3: Refine the solution
        refinement_instruction = (
            "Critically review the following solution and refine it for accuracy, completeness, and clarity. "
            "Ensure the solution adheres to real-world constraints (e.g., no negative quantities). "
            "Correct any errors or ambiguities."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=initial_solution)

        # Step 4: Extract the final answer
        summarization_instruction = (
            "From the refined solution, extract the final numerical answer. Ensure the answer is clear, "
            "unambiguous, and includes the appropriate units if applicable."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_solution)

        return final_answer