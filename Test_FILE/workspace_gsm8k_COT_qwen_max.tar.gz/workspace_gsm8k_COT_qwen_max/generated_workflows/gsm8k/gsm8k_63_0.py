# Workflow ID: gsm8k_63_0
# Benchmark: gsm8k
# Data Indices: [516, 279]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (numerical values, units, relationships, target question)
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, units, and relationships. "
            "Identify the target question being asked and any intermediate steps required to solve it. "
            "Ensure all hidden steps or implicit calculations are explicitly stated."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a step-by-step solution plan
        planning_instruction = (
            f"Based on the extracted information: {extracted_info}, formulate a detailed step-by-step plan "
            "to solve the problem. Include all necessary calculations, unit conversions, and logical reasoning. "
            "Ensure the plan adheres to real-world constraints and produces a single numerical answer."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Execute calculations in parallel
        calculation_instruction_template = (
            "Perform the following calculation step: {step}. "
            "Ensure the result is accurate and includes appropriate units if applicable."
        )
        steps = solution_plan.split("\n")  # Assume steps are separated by newlines
        calculation_tasks = [
            self.generate(instruction=calculation_instruction_template.format(step=step), context=self.problem_text)
            for step in steps if step.strip()
        ]
        intermediate_results = await asyncio.gather(*calculation_tasks)

        # Step 4: Validate and refine results
        refinement_instruction = (
            "Review the intermediate results: {results}. "
            "Ensure they are consistent with the problem context and correct any errors or inconsistencies."
        )
        refined_results = await self.revise(
            instruction=refinement_instruction.format(results=intermediate_results),
            context=self.problem_text
        )

        # Step 5: Handle multiple solution paths (if applicable)
        ensemble_instruction = (
            "Compare the refined results: {results}. "
            "Select the most appropriate solution path and ensure it leads to a single numerical answer."
        )
        final_result = await self.ensemble(
            instruction=ensemble_instruction.format(results=refined_results),
            contexts=[refined_results]
        )

        # Step 6: Summarize the final answer
        summarization_instruction = (
            "Condense the final result into a single numerical value. "
            "Ensure the answer is clear, concise, and makes sense in the context of the problem."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=final_result)

        return final_answer