# Workflow ID: gsm8k_58_0
# Benchmark: gsm8k
# Data Indices: [298, 621]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract numerical values and relationships
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, their associated units, "
            "and any relationships or constraints mentioned explicitly or implicitly. "
            "Provide the extracted information in a structured format."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate a detailed solution plan
        plan_instruction = (
            f"Based on the following extracted information: {extracted_info}\n"
            "Create a step-by-step plan to solve the problem. Include all necessary calculations, "
            "intermediate steps, and unit conversions. Ensure the plan accounts for any hidden steps "
            "or implicit constraints."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Generate parallel solution attempts
        solution_instruction = (
            f"Follow this detailed plan to solve the problem: {solution_plan}\n"
            "Perform all calculations step by step and provide the final numerical answer. "
            "Ensure the solution is consistent with the problem context and units."
        )
        solution1, solution2 = await asyncio.gather(
            self.generate(instruction=solution_instruction, context=self.problem_text),
            self.generate(instruction=solution_instruction, context=self.problem_text)
        )

        # Step 4: Ensemble decision to select the best solution
        ensemble_instruction = (
            "Evaluate the following candidate solutions and determine the most accurate and logical answer. "
            "Ensure the chosen solution adheres to the problem context and real-world constraints. "
            "If discrepancies exist, resolve them through cross-validation."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=[solution1, solution2])

        # Step 5: Refine the final solution
        refinement_instruction = (
            "Critique and refine the following solution to ensure clarity, correctness, and proper formatting. "
            "Verify that the answer is a single numerical value (integer or decimal) and aligns with the problem requirements."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_solution)

        return refined_answer