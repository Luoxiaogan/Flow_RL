# Workflow ID: gsm8k_213_0
# Benchmark: gsm8k
# Data Indices: [59, 124]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract known values and relationships
        extract_instruction = (
            "Carefully analyze the problem and extract all numerical values, their units, "
            "and any relationships between them. Identify key entities (e.g., people, objects) "
            "and describe their interactions. Ensure that all extracted information is complete "
            "and unambiguous."
        )
        extract_task = self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Formulate a step-by-step solution plan
        plan_instruction = (
            "Based on the extracted information, create a detailed step-by-step plan to solve the problem. "
            "Include all intermediate calculations, handle unit conversions, and ensure chronological "
            "reasoning for time-based problems. Clearly outline the sequence of operations required."
        )
        plan_task = self.generate(instruction=plan_instruction, context=self.problem_text)

        # Execute Steps 1 and 2 in parallel
        extracted_info, solution_plan = await asyncio.gather(extract_task, plan_task)

        # Step 3: Execute the solution plan and compute the final answer
        execute_instruction = (
            f"Using the extracted information: {extracted_info} and the solution plan: {solution_plan}, "
            "perform all necessary calculations step by step. Ensure that units are consistent, "
            "intermediate results are verified, and the final answer is clearly stated as a single "
            "numerical value."
        )
        computed_solution = await self.generate(instruction=execute_instruction, context=self.problem_text)

        # Step 4: Validate the computed solution
        validate_instruction = (
            "Critique and refine the computed solution. Verify that all intermediate steps are correct, "
            "units are consistent, and the final answer satisfies the problem's requirements. "
            "Ensure that the solution makes sense in the context of the problem."
        )
        validated_solution = await self.revise(instruction=validate_instruction, context=computed_solution)

        # Step 5: Summarize the final answer
        summarize_instruction = (
            "Condense the validated solution into a single numerical value. Ensure that the output "
            "is clean, unambiguous, and matches the problem's requirement for a single numerical answer."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=validated_solution)

        return final_answer