# Workflow ID: gsm8k_394_0
# Benchmark: gsm8k
# Data Indices: [314, 777]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key numerical values and relationships
        extraction_instruction = """
        Carefully analyze the problem and extract all numerical values, units, and relationships.
        Identify the known quantities and their relationships, including any implicit constraints.
        Ensure that the output is structured and easy to interpret for subsequent steps.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate the solution plan
        plan_instruction = f"""
        Based on the following extracted information: {extracted_info}
        Formulate a step-by-step plan to solve the problem. Include:
        - The sequence of calculations required
        - Any intermediate results that need to be computed
        - How to combine the results to arrive at the final answer
        Ensure that the plan is comprehensive and accounts for all extracted values.
        """
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Perform independent calculations in parallel
        calculation_instruction_template = """
        Perform the following calculation based on the problem and extracted information:
        {calculation_description}
        Ensure that the result is accurate and includes appropriate units if applicable.
        """
        # Example: Dynamically construct instructions for each calculation
        calculations = [
            "Calculate the total number of sparklers and whistlers in Koby's boxes.",
            "Calculate the total number of sparklers and whistlers in Cherie's box."
        ]
        tasks = [
            self.generate(instruction=calculation_instruction_template.format(calculation_description=calc), context=self.problem_text)
            for calc in calculations
        ]
        calculation_results = await asyncio.gather(*tasks)

        # Step 4: Combine results to compute the final answer
        combine_instruction = f"""
        Given the following results from independent calculations: {calculation_results}
        Combine them according to the solution plan: {solution_plan}
        Compute the final answer, ensuring that it is consistent with the problem context and units.
        """
        final_answer = await self.ensemble(instruction=combine_instruction, contexts=calculation_results)

        # Step 5: Validate and refine the result if necessary
        validate_instruction = """
        Review the final answer and ensure it makes sense in the context of the problem.
        Check for consistency with the extracted information and solution plan.
        If necessary, refine the result to address any issues or ambiguities.
        """
        refined_answer = await self.revise(instruction=validate_instruction, context=final_answer)

        return refined_answer