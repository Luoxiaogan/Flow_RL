# Workflow ID: gsm8k_54_0
# Benchmark: gsm8k
# Data Indices: [772, 768]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio
        
        # Step 1: Extract numerical values and relationships
        extract_instruction = (
            "Carefully analyze the problem and extract all numerical values and their relationships. "
            "Include explicit numbers, implicit relationships (e.g., 'twice the number'), and any constraints. "
            "Format the output as a structured list."
        )
        extract_task = self.generate(instruction=extract_instruction, context=self.problem_text)
        
        # Step 2: Formulate intermediate steps for solving the problem
        formulate_instruction = (
            "Based on the extracted information, determine the sequence of operations needed to solve the problem. "
            "Include arithmetic operations, unit conversions, proportional reasoning, and any intermediate calculations. "
            "Provide a clear, step-by-step plan."
        )
        formulate_task = self.generate(instruction=formulate_instruction, context=self.problem_text)
        
        # Run extraction and formulation in parallel
        extracted_info, formulated_steps = await asyncio.gather(extract_task, formulate_task)
        
        # Step 3: Perform calculations based on the formulated steps
        calculate_instruction = (
            f"Using the following extracted information: {extracted_info}\n"
            f"And the formulated steps: {formulated_steps}\n"
            "Perform the necessary calculations step by step. Show all intermediate results and ensure accuracy."
        )
        calculated_results = await self.generate(instruction=calculate_instruction, context=self.problem_text)
        
        # Step 4: Revise the calculated results for accuracy
        revise_instruction = (
            "Review the calculated results for correctness. Check for calculation errors, logical inconsistencies, "
            "and adherence to the problem's constraints. Suggest improvements if needed."
        )
        revised_results = await self.revise(instruction=revise_instruction, context=calculated_results)
        
        # Step 5: Summarize the final answer
        summarize_instruction = (
            "Condense the revised results into a single, concise answer. Ensure the answer is a numerical value "
            "(integer or decimal) and makes sense in the context of the problem."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=revised_results)
        
        return final_answer