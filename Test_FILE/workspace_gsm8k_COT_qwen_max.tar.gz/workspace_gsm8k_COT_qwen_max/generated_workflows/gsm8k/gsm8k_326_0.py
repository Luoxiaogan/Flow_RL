# Workflow ID: gsm8k_326_0
# Benchmark: gsm8k
# Data Indices: [432, 575]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information
        extraction_instruction = (
            "Extract all numerical values, relationships, and the question being asked from the problem. "
            "Identify known quantities, unknowns, and any constraints. Ensure units are tracked explicitly."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Construct a step-by-step solution
        solution_instruction = (
            f"Using the extracted information: {extracted_info}, construct a step-by-step solution to the problem. "
            "Clearly outline each mathematical operation or reasoning step required to solve the problem. "
            "Ensure the solution is chronological and accounts for any hidden steps or intermediate calculations."
        )
        solution = await self.generate(instruction=solution_instruction, context=self.problem_text)

        # Step 3: Validate and refine the solution
        refinement_instruction = (
            "Critique the provided solution and refine it for accuracy and clarity. "
            "Check for calculation errors, logical inconsistencies, and adherence to real-world constraints. "
            "Ensure the solution makes sense in the context of the problem."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=solution)

        # Step 4: Extract the final numerical answer
        answer_instruction = (
            "From the refined solution, extract the final numerical answer. "
            "Ensure the answer is presented as a single value with appropriate units if applicable."
        )
        final_answer = await self.summarize(instruction=answer_instruction, context=refined_solution)

        return final_answer