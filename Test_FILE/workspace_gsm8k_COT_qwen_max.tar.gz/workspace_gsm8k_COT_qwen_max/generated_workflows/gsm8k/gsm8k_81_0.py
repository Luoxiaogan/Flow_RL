# Workflow ID: gsm8k_81_0
# Benchmark: gsm8k
# Data Indices: [694, 700]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio
        
        # Step 1: Extract known values and relationships
        extraction_instruction = (
            "Identify all numerical values in the problem along with their units and relationships. "
            "Extract any explicit or implicit mathematical operations such as addition, subtraction, "
            "multiplication, division, fractions, percentages, etc."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)
        
        # Step 2: Formulate intermediate steps
        formulation_instruction = (
            f"Using the extracted numerical values and relationships: {extracted_info}, "
            "formulate a step-by-step plan to solve the problem. Ensure each step logically "
            "follows from the previous one and accounts for all given data."
        )
        plan = await self.generate(instruction=formulation_instruction, context=self.problem_text)
        
        # Step 3: Perform calculations
        calculation_instruction = (
            f"Following the formulated plan: {plan}, perform each calculation step by step. "
            "Clearly state the operation being performed and the result obtained at each step."
        )
        calculations = await self.generate(instruction=calculation_instruction, context=self.problem_text)
        
        # Step 4: Verify solution consistency
        verification_instruction = (
            f"Review the calculated solution: {calculations} against the original problem. "
            "Ensure that the final answer is consistent with the problem's context, units, "
            "and any constraints mentioned."
        )
        verified_solution = await self.revise(instruction=verification_instruction, context=calculations)
        
        # Step 5: Summarize final answer
        summary_instruction = (
            f"Summarize the entire solution process: {verified_solution} and clearly state the final "
            "numerical answer. Ensure the summary is brief but includes all essential information."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=verified_solution)
        
        return final_summary