# Workflow ID: gsm8k_44_0
# Benchmark: gsm8k
# Data Indices: [122, 139]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all numerical values, relationships, and constraints
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, relationships, "
            "and constraints. Clearly label each piece of information and explain its significance "
            "in the context of the problem. Ensure that all units and contextual details are preserved."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a structured plan for solving the problem
        formulation_instruction = (
            f"Using the extracted information: {extracted_info}, formulate a step-by-step plan "
            "to solve the problem. Translate all relationships into mathematical equations or logical steps. "
            "Ensure the plan is clear, chronological, and accounts for all constraints."
        )
        plan = await self.generate(instruction=formulation_instruction, context=self.problem_text)

        # Step 3: Execute the plan to compute intermediate and final results
        execution_instruction = (
            f"Follow this plan step-by-step: {plan}. Perform all calculations explicitly, showing "
            "intermediate results at each stage. Ensure all units and contextual constraints are respected. "
            "Provide the final answer as a single numerical value."
        )
        solution = await self.generate(instruction=execution_instruction, context=self.problem_text)

        # Step 4: Validate and refine the solution
        validation_instruction = (
            f"Review the solution: {solution} against the original problem. Verify that all calculations "
            "are correct, the answer makes sense in context, and all constraints are satisfied. "
            "If necessary, suggest corrections or refinements."
        )
        refined_solution = await self.revise(instruction=validation_instruction, context=solution)

        return refined_solution