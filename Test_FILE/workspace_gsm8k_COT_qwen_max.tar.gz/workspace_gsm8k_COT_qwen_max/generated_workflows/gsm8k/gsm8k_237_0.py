# Workflow ID: gsm8k_237_0
# Benchmark: gsm8k
# Data Indices: [518, 751]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract numerical values, relationships, and constraints
        extraction_instruction = """
        Analyze the problem thoroughly and extract all numerical values, relationships, and constraints mentioned in the text. 
        Include any percentages, rates, or other quantitative data. Organize the extracted information clearly for further processing.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Perform intermediate calculations
        calculation_instruction = f"""
        Based on the following extracted information: {extracted_info}
        Perform all necessary intermediate calculations step by step. Ensure that each calculation logically follows from the previous one.
        If there are sequential operations, hidden steps, or dependencies between calculations, explicitly outline them.
        Provide the results of each step in a structured format.
        """
        intermediate_results = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 3: Verify and refine intermediate results
        refinement_instruction = f"""
        Review the following intermediate results: {intermediate_results}
        Check for logical consistency, unit correctness, and alignment with the problem's context. 
        Identify and correct any errors or inconsistencies. Provide a refined version of the calculations if needed.
        """
        refined_results = await self.revise(instruction=refinement_instruction, context=intermediate_results)

        # Step 4: Generate the final answer
        final_answer_instruction = f"""
        Using the refined results: {refined_results}
        Consolidate the calculations into a single numerical value that answers the question posed in the problem.
        Ensure the final answer is presented clearly and makes sense in the context of the problem.
        """
        final_answer = await self.generate(instruction=final_answer_instruction, context=self.problem_text)

        return final_answer