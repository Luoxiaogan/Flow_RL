# Workflow ID: gsm8k_324_0
# Benchmark: gsm8k
# Data Indices: [653, 648]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract Key Information
        extraction_instruction = (
            "Carefully analyze the problem and extract ALL numerical values, relationships (e.g., percentages, discounts), "
            "and units mentioned. Identify what is being asked and list the knowns and unknowns explicitly."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate Intermediate Steps
        step_instruction = (
            f"Based on the following extracted information: {extracted_info}\n"
            "Break the problem into clear, sequential calculation steps. Include all intermediate operations "
            "(e.g., addition, subtraction, percentage calculations) and specify how units should be handled."
        )
        steps = await self.generate(instruction=step_instruction, context=self.problem_text)

        # Step 3: Perform Calculations in Parallel
        calculation_instructions = [
            f"Perform this specific calculation step: '{step}' Ensure units are consistent and provide the result."
            for step in steps.split("\n") if step.strip()
        ]
        calculation_results = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in calculation_instructions]
        )

        # Step 4: Verify and Refine Results
        refinement_tasks = [
            self.revise(
                instruction="Review this calculation result for accuracy. Correct any errors and ensure the logic aligns with the problem statement.",
                context=result
            ) for result in calculation_results
        ]
        refined_results = await asyncio.gather(*refinement_tasks)

        # Step 5: Combine Results into Final Answer
        ensemble_instruction = (
            "Given the following refined calculation results, synthesize them into a single final answer. "
            "Resolve any inconsistencies and ensure the result makes sense in the context of the problem."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=refined_results)

        # Step 6: Summarize Final Answer
        summary_instruction = (
            "Condense the final answer into a single numerical value. Ensure it is precise and formatted appropriately."
        )
        summarized_answer = await self.summarize(instruction=summary_instruction, context=final_answer)

        return summarized_answer