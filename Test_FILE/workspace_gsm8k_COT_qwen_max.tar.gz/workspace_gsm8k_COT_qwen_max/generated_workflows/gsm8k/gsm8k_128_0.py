# Workflow ID: gsm8k_128_0
# Benchmark: gsm8k
# Data Indices: [591, 168]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all relevant numerical values, relationships, and units
        extraction_instruction = (
            "Extract all numerical values, relationships, and units from the problem. "
            "Include explicit descriptions of what each number represents and how they relate to each other. "
            "Ensure the output is structured and easy to parse."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan the sequence of calculations
        planning_instruction = (
            f"Based on the extracted information:\n{extracted_info}\n"
            "Outline the sequence of calculations needed to solve the problem. "
            "Include intermediate steps, expected outputs, and any necessary unit conversions. "
            "Ensure the plan is logical and accounts for all given data."
        )
        calculation_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Execute calculations and validate intermediate results
        execution_instruction = (
            f"Follow the calculation plan:\n{calculation_plan}\n"
            "Perform each step carefully, ensuring accuracy. "
            "Validate each intermediate result against the problem context to catch errors early."
        )
        intermediate_results = await self.revise(instruction=execution_instruction, context=calculation_plan)

        # Step 4: Synthesize the final answer
        synthesis_instruction = (
            f"Condense the following intermediate results into a final answer:\n{intermediate_results}\n"
            "Ensure the answer directly addresses the original question, includes proper units, and makes sense in context."
        )
        final_answer = await self.summarize(instruction=synthesis_instruction, context=intermediate_results)

        return final_answer