# Workflow ID: gsm8k_310_0
# Benchmark: gsm8k
# Data Indices: [502, 210]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all numerical values, units, relationships, and constraints from the problem. "
            "Identify what is being asked and list all given information explicitly. "
            "Ensure the extracted information is complete and unambiguous."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate a step-by-step solution
        solution_instruction = (
            f"Using the following extracted information: {extracted_info}\n"
            "Solve the problem step-by-step. Clearly show all intermediate calculations, "
            "including unit conversions and any necessary assumptions. "
            "Ensure the solution is logically consistent and addresses the question fully."
        )
        solution = await self.generate(instruction=solution_instruction, context=self.problem_text)

        # Step 3: Verify and refine the solution
        verification_instruction = (
            "Critique the provided solution for logical consistency, proper handling of units, "
            "and adherence to the problem constraints. Refine any steps that are unclear or incorrect. "
            "Provide a revised version of the solution if necessary."
        )
        refined_solution = await self.revise(instruction=verification_instruction, context=solution)

        # Step 4: Extract the final numerical answer
        final_answer_instruction = (
            "From the refined solution, extract the final numerical answer. "
            "Ensure the answer is a single value (integer or decimal) and includes appropriate units if needed."
        )
        final_answer = await self.summarize(instruction=final_answer_instruction, context=refined_solution)

        # Optional: Handle alternative approaches in parallel
        # Uncomment the following block if multiple solution paths are expected
        """
        async def alternative_approach(approach_instruction):
            return await self.generate(instruction=approach_instruction, context=self.problem_text)

        approach1_instruction = "Solve the problem using method A."
        approach2_instruction = "Solve the problem using method B."

        results = await asyncio.gather(
            alternative_approach(approach1_instruction),
            alternative_approach(approach2_instruction)
        )
        best_solution = await self.ensemble(
            instruction="Select the most accurate and logical solution.",
            contexts=results
        )
        """

        return final_answer