# Workflow ID: gsm8k_172_0
# Benchmark: gsm8k
# Data Indices: [132, 190]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract numerical values and relationships
        extraction_instruction = (
            "Extract all numerical values and their associated units or labels from the problem. "
            "Also identify any mathematical relationships, such as addition, subtraction, multiplication, division, ratios, or rates. "
            "Present the output in a structured format, clearly separating values from relationships."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate a step-by-step solution
        solution_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "solve the problem step by step. Ensure that each step logically follows from the previous one. "
            "Clearly show all intermediate calculations, including unit conversions if necessary. "
            "Verify that the solution adheres to the problem's constraints and makes sense in the given context."
        )
        initial_solution = await self.generate(instruction=solution_instruction, context=self.problem_text)

        # Step 3: Revise and refine the solution
        revision_instruction = (
            "Review the provided solution and check for correctness, clarity, and completeness. "
            "Ensure that all steps are justified and that the final answer aligns with the problem's requirements. "
            "If any errors or ambiguities are found, correct them and provide an improved version of the solution."
        )
        refined_solution = await self.revise(instruction=revision_instruction, context=initial_solution)

        # Step 4: Extract the final numerical answer
        answer_extraction_instruction = (
            "From the refined solution, extract the final numerical answer. "
            "Ensure that it is presented as a single value (integer or decimal) without any additional text. "
            "If the answer includes units, verify that they match the problem's requirements."
        )
        final_answer = await self.generate(instruction=answer_extraction_instruction, context=refined_solution)

        return final_answer