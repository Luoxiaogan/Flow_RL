# Workflow ID: gsm8k_29_0
# Benchmark: gsm8k
# Data Indices: [328, 203]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information (numerical values, relationships, constraints)
        extraction_instruction = (
            "Extract all numerical values, units, and relationships from the problem. "
            "Identify any implicit steps or constraints. Present the information in a structured format."
        )
        key_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the extracted information to determine the solution strategy
        analysis_instruction = (
            f"Based on the following extracted information: {key_info}\n"
            "Analyze the problem to determine the sequence of operations required to solve it. "
            "Identify whether the problem involves sequential steps, proportional reasoning, unit conversions, or other mathematical operations."
        )
        analysis = await self.generate(instruction=analysis_instruction, context=self.problem_text)

        # Step 3: Refine the analysis for clarity and correctness
        refinement_instruction = (
            "Review the analysis and refine it for clarity, logical consistency, and completeness. "
            "Ensure all steps and operations are explicitly stated."
        )
        refined_analysis = await self.revise(instruction=refinement_instruction, context=analysis)

        # Step 4: Generate multiple solution approaches in parallel
        solution_instruction_1 = (
            f"Using the refined analysis: {refined_analysis}\n"
            "Solve the problem using direct computation. Show all intermediate steps and calculations."
        )
        solution_instruction_2 = (
            f"Using the refined analysis: {refined_analysis}\n"
            "Solve the problem using algebraic reasoning. Define variables, set up equations, and solve step by step."
        )
        results = await asyncio.gather(
            self.generate(instruction=solution_instruction_1, context=self.problem_text),
            self.generate(instruction=solution_instruction_2, context=self.problem_text)
        )

        # Step 5: Ensemble decision-making to select the best solution
        ensemble_instruction = (
            "Evaluate the following candidate solutions and select the best one. "
            "Criteria for selection include logical consistency, adherence to constraints, and numerical accuracy."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 6: Extract the final numerical answer
        final_instruction = (
            "From the selected solution, extract the final numerical answer. "
            "Ensure the answer is presented as a single integer or decimal value."
        )
        final_answer = await self.summarize(instruction=final_instruction, context=best_solution)

        return final_answer