# Workflow ID: gsm8k_239_0
# Benchmark: gsm8k
# Data Indices: [778, 180]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract numerical values, relationships, and identify the unknown
        extract_instruction = (
            "Extract all numerical values, units, and relationships from the problem. "
            "Identify what the problem is asking for (the unknown)."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Generate a detailed breakdown of the problem into steps
        reasoning_instruction = (
            f"Based on the extracted information: {extracted_info}, "
            "generate a detailed breakdown of the problem into sequential steps. "
            "Include all necessary calculations, unit conversions, and intermediate results. "
            "Ensure the steps are logically ordered and address all constraints."
        )
        reasoning_steps = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Refine the reasoning steps for accuracy and completeness
        refine_instruction = (
            "Review the reasoning steps and ensure they are accurate, complete, and logically consistent. "
            "Correct any errors or ambiguities."
        )
        refined_steps = await self.revise(instruction=refine_instruction, context=reasoning_steps)

        # Step 4: Execute calculations step-by-step
        calculation_instruction = (
            f"Using the refined reasoning steps: {refined_steps}, "
            "perform the calculations step-by-step. Dynamically incorporate intermediate results into subsequent steps. "
            "Ensure all units are handled consistently and the final result is clearly stated."
        )
        calculations = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 5: Summarize the solution
        summarize_instruction = (
            f"Summarize the solution based on the calculations: {calculations}. "
            "Provide the final answer in the required format, ensuring it directly addresses the problem's question."
        )
        summary = await self.summarize(instruction=summarize_instruction, context=calculations)

        # Step 6: Validate the final result
        validation_instruction = (
            "Evaluate the final result to ensure it is logical, consistent with the problem's context, "
            "and satisfies all constraints. If multiple approaches were used, synthesize the best solution."
        )
        final_result = await self.ensemble(instruction=validation_instruction, contexts=[summary, calculations])

        return final_result