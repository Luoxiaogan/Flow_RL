# Workflow ID: gsm8k_18_0
# Benchmark: gsm8k
# Data Indices: [387, 464]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract numerical values, units, and relationships
        extraction_instruction = """
        Thoroughly analyze the problem and extract all relevant numerical values, units, and relationships. 
        Identify what is given and what is being asked. Explicitly state any constraints or conditions. 
        Format your response as a structured summary.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Translate the problem into a mathematical model
        modeling_instruction = f"""
        Based on the following extracted information: {extracted_info}
        Construct a mathematical model to represent the problem. 
        Clearly define variables, equations, and the sequence of operations needed to solve the problem. 
        Ensure all units are consistent and explicitly state intermediate steps.
        """
        mathematical_model = await self.generate(instruction=modeling_instruction, context=self.problem_text)

        # Step 3: Perform calculations and derive intermediate results
        calculation_instruction = f"""
        Using the mathematical model: {mathematical_model}
        Perform all necessary calculations step by step. 
        Clearly state each intermediate result and ensure all units are tracked throughout the process. 
        Provide the final numerical answer at the end.
        """
        calculation_result = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Validate the solution against the problem context
        validation_instruction = f"""
        Critique the following solution: {calculation_result}
        Verify that the answer makes sense in the context of the problem. 
        Check for consistency with the given information, realistic constraints, and proper handling of units. 
        Suggest refinements if necessary.
        """
        refined_solution = await self.revise(instruction=validation_instruction, context=calculation_result)

        # Step 5: Summarize the final result
        summary_instruction = f"""
        Condense the following solution into a concise summary: {refined_solution}
        Include only the final numerical answer and its interpretation in the problem context.
        """
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_summary