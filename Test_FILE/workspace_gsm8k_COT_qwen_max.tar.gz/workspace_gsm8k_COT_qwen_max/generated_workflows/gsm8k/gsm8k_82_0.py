# Workflow ID: gsm8k_82_0
# Benchmark: gsm8k
# Data Indices: [33, 579]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract key information (numerical values, relationships, units)
        extraction_instruction = """
        Analyze the problem and extract all numerical values, relationships, and units.
        Identify the known quantities and the unknowns. 
        Organize the information clearly, specifying what each value represents in the context of the problem.
        Ensure no relevant detail is missed.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a step-by-step plan to solve the problem
        plan_instruction = f"""
        Based on the extracted information: {extracted_info}
        Create a detailed step-by-step plan to solve the problem. 
        Include all necessary calculations, intermediate steps, and the sequence of operations.
        Ensure the plan accounts for units, constraints, and real-world considerations.
        """
        plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute the plan and compute the final answer
        execution_instruction = f"""
        Follow the plan step-by-step: {plan}
        Perform all calculations accurately, maintaining unit consistency.
        Verify each intermediate result to ensure correctness.
        Provide the final numerical answer at the end.
        """
        executed_solution = await self.generate(instruction=execution_instruction, context=self.problem_text)

        # Step 4: Validate the solution for correctness and reasonableness
        validation_instruction = f"""
        Critique the computed solution: {executed_solution}
        Check for logical correctness, unit consistency, and adherence to the problem's constraints.
        Ensure the answer makes sense in the context of the problem.
        Refine or correct the solution if necessary.
        """
        validated_solution = await self.revise(instruction=validation_instruction, context=executed_solution)

        # Step 5: Summarize the final result
        summary_instruction = """
        Condense the validated solution into a concise, final answer.
        Ensure the result is a single numerical value (integer or decimal).
        """
        final_answer = await self.summarize(instruction=summary_instruction, context=validated_solution)

        return final_answer