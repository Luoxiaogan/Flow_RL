# Workflow ID: gsm8k_365_0
# Benchmark: gsm8k
# Data Indices: [89, 13]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = """
        Carefully analyze the problem and extract all relevant numerical values, units, relationships, and constraints. 
        Identify what the question is asking for and list all given data points explicitly. 
        If there are percentages, fractions, or rates, clarify their meaning in the context of the problem. 
        Ensure no critical detail is missed.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate intermediate reasoning steps and calculations
        reasoning_instruction = f"""
        Based on the extracted information: {extracted_info}
        Develop a step-by-step plan to solve the problem. Include all intermediate calculations and logical reasoning. 
        If there are multiple steps, clearly outline their sequence and dependencies. 
        Ensure the plan adheres to mathematical principles and real-world constraints.
        """
        reasoning_steps = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Generate multiple solution approaches in parallel
        approach_1_instruction = f"""
        Solve the problem using a direct calculation approach. Follow these steps: {reasoning_steps}
        Ensure all calculations are accurate and consistent with the problem's context.
        """
        approach_2_instruction = f"""
        Solve the problem by breaking it into smaller sub-problems. Follow these steps: {reasoning_steps}
        Address each sub-problem independently before combining the results.
        """
        approaches = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text)
        )

        # Step 4: Validate and refine the candidate solutions
        refine_instruction = """
        Critique the provided solution and check for errors. Ensure:
        - All calculations are mathematically correct.
        - Units are consistent throughout.
        - The solution adheres to the problem's constraints and context.
        - Intermediate steps logically follow from the problem statement.
        Provide a revised version of the solution if necessary.
        """
        refined_solutions = await asyncio.gather(
            self.revise(instruction=refine_instruction, context=approaches[0]),
            self.revise(instruction=refine_instruction, context=approaches[1])
        )

        # Step 5: Select the best solution using Ensemble
        ensemble_instruction = """
        Compare the provided solutions and select the most accurate and reliable one. 
        Consider mathematical correctness, adherence to the problem's context, and clarity of reasoning. 
        If there are discrepancies, resolve them and provide a final answer.
        """
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_solutions)

        # Step 6: Summarize the final solution
        summary_instruction = """
        Summarize the solution in a clear and concise manner. Include:
        - The final numerical answer.
        - Key intermediate results if relevant.
        - Any important context or constraints.
        Ensure the summary is easy to understand and directly addresses the problem's question.
        """
        final_summary = await self.summarize(instruction=summary_instruction, context=final_solution)

        return final_summary