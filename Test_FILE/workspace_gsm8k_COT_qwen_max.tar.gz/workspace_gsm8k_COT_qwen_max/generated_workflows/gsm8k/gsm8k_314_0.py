# Workflow ID: gsm8k_314_0
# Benchmark: gsm8k
# Data Indices: [580, 507]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract knowns and unknowns
        extract_instruction = (
            "Carefully analyze the problem and extract all known numerical values, "
            "relationships, and constraints. Clearly identify what is being asked. "
            "Ensure that units and any implicit assumptions are explicitly stated."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Formulate a solution plan
        plan_instruction = (
            f"Based on the following extracted information: {extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. "
            "Include all necessary calculations, intermediate steps, and unit handling. "
            "Ensure the plan is logical and follows the problem's chronology."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute calculations
        calculate_instruction = (
            f"Follow this solution plan: {solution_plan}\n"
            "Perform each calculation step by step. Show all intermediate results and ensure "
            "units and decimal places are handled correctly. Provide the final numerical result."
        )
        calculations = await self.generate(instruction=calculate_instruction, context=self.problem_text)

        # Step 4: Validate and refine the solution
        refine_instruction = (
            f"Review the following calculations: {calculations}\n"
            "Check for any errors or inconsistencies. Ensure the result makes sense in the context "
            "of the problem. Refine the solution if necessary."
        )
        refined_solution = await self.revise(instruction=refine_instruction, context=calculations)

        # Step 5: Summarize the final answer
        summarize_instruction = (
            f"Condense the following solution: {refined_solution}\n"
            "Provide only the final numerical answer as a single value. Ensure it is clear and unambiguous."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_answer