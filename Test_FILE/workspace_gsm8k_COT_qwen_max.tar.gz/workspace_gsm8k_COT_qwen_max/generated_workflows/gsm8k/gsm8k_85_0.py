# Workflow ID: gsm8k_85_0
# Benchmark: gsm8k
# Data Indices: [268, 475]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract known values and relationships
        extract_instruction = (
            "Carefully analyze the problem and extract all numerical values, units, and relationships. "
            "Include explicit numbers as well as implicit information such as fractions, percentages, or rates. "
            "Format the output as a clear list of key-value pairs or statements."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Translate problem into mathematical steps
        translate_instruction = (
            f"Using the following extracted information: {extracted_info}\n"
            "Outline the sequence of mathematical operations required to solve the problem. "
            "Include intermediate steps, specify the order of operations, and note any constraints (e.g., unit consistency). "
            "If the problem involves multiple entities or time-based events, ensure the steps are chronological."
        )
        math_steps = await self.generate(instruction=translate_instruction, context=self.problem_text)

        # Step 3: Perform calculations
        calculate_instruction = (
            f"Following these outlined steps: {math_steps}\n"
            "Execute the calculations step by step. Ensure that all intermediate results are clearly stated and that the final answer is explicitly identified. "
            "Pay attention to units and real-world constraints (e.g., non-negative quantities, fractional values where appropriate)."
        )
        calculation_result = await self.generate(instruction=calculate_instruction, context=self.problem_text)

        # Step 4: Validate and refine the solution
        validate_instruction = (
            f"Review the following solution: {calculation_result}\n"
            "Critically evaluate whether the answer makes sense in the context of the problem. "
            "Check for unit consistency, adherence to constraints, and logical correctness. "
            "If necessary, suggest refinements or corrections."
        )
        refined_solution = await self.revise(instruction=validate_instruction, context=calculation_result)

        # Step 5: Summarize the final answer
        summarize_instruction = (
            f"Condense the following solution into a concise summary: {refined_solution}\n"
            "Ensure the final numerical answer is clearly stated and directly addresses the question. "
            "Remove any unnecessary intermediate steps or explanations."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_answer