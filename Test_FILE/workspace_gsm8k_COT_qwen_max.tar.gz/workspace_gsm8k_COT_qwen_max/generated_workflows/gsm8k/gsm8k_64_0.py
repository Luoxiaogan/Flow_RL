# Workflow ID: gsm8k_64_0
# Benchmark: gsm8k
# Data Indices: [453, 746]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract known values, units, and relationships
        extraction_instruction = (
            "Extract all numerical values, their associated units (if any), and relationships described in the problem. "
            "Identify known quantities, unknowns, and any implied operations (e.g., 'twice as many', 'percentage off'). "
            "Provide this information in a structured format."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan intermediate calculations
        planning_instruction = (
            f"Based on the extracted information: {extracted_info}, "
            "outline a step-by-step plan to solve the problem. "
            "Include all intermediate calculations, ensuring proper sequencing and unit consistency. "
            "If there are multiple independent calculations, identify them for parallel execution."
        )
        calculation_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Execute independent calculations in parallel
        # Parse the calculation plan to identify independent steps
        parallel_instructions = (
            f"Parse the calculation plan: {calculation_plan}. "
            "Identify independent calculation steps that can be executed in parallel. "
            "For each step, provide a detailed instruction for execution."
        )
        parallel_steps = await self.generate(instruction=parallel_instructions, context=self.problem_text)

        # Execute parallel steps (assuming they are returned as a list of instructions)
        parallel_results = await asyncio.gather(
            *[self.generate(instruction=step, context=self.problem_text) for step in parallel_steps.split("\n") if step.strip()]
        )

        # Step 4: Synthesize intermediate results
        synthesis_instruction = (
            f"Combine the following intermediate results into a coherent summary: {parallel_results}. "
            "Ensure that all results are integrated correctly and prepare for the final calculation."
        )
        synthesized_results = await self.ensemble(instruction=synthesis_instruction, contexts=parallel_results)

        # Step 5: Perform final calculation
        final_calculation_instruction = (
            f"Using the synthesized results: {synthesized_results}, perform the final calculation to determine the answer. "
            "Ensure the result is a single numerical value (integer or decimal) and verify that it makes sense in the context of the problem."
        )
        final_answer = await self.generate(instruction=final_calculation_instruction, context=self.problem_text)

        # Step 6: Return the final answer
        return final_answer