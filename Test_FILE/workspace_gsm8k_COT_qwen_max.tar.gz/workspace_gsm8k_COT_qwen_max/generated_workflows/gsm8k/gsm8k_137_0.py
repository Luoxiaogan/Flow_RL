# Workflow ID: gsm8k_137_0
# Benchmark: gsm8k
# Data Indices: [524, 23]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information (numerical values, relationships, target question)
        extraction_instruction = (
            "Extract all numerical values, relationships (e.g., proportions, rates), and the target question from the problem. "
            "Format the output as follows:\n"
            "- Known Values: [list numerical values]\n"
            "- Relationships: [describe relationships]\n"
            "- Target Question: [state the question]"
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Translate the extracted information into a mathematical model
        modeling_instruction = (
            f"Given the following extracted information:\n{extracted_info}\n"
            "Translate it into a mathematical model. Identify variables, relationships, and the sequence of operations needed to solve the problem. "
            "Ensure the model is complete and ready for step-by-step calculation."
        )
        mathematical_model = await self.generate(instruction=modeling_instruction, context=self.problem_text)

        # Step 3: Perform step-by-step calculations
        calculation_instruction = (
            f"Using the following mathematical model:\n{mathematical_model}\n"
            "Perform the calculations step-by-step. Show all intermediate results and ensure the final answer is clearly stated. "
            "Verify that units and decimal places are handled correctly."
        )
        calculations = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Verify the solution and refine if necessary
        verification_instruction = (
            f"Review the following solution:\n{calculations}\n"
            "Check if it satisfies the problem constraints and makes sense in context. Refine the solution if necessary, ensuring accuracy and clarity."
        )
        verified_solution = await self.revise(instruction=verification_instruction, context=calculations)

        # Step 5: Ensemble multiple approaches (if applicable)
        # Generate alternative solutions in parallel
        alternative_instruction_1 = (
            "Solve the problem using an alternative approach, such as working backward or using a different sequence of operations."
        )
        alternative_instruction_2 = (
            "Solve the problem using proportional reasoning or algebraic equations, depending on the problem type."
        )
        alternative_solutions = await asyncio.gather(
            self.generate(instruction=alternative_instruction_1, context=self.problem_text),
            self.generate(instruction=alternative_instruction_2, context=self.problem_text)
        )

        # Use ensemble to select the best solution
        ensemble_instruction = (
            "Compare the following solutions and select the best one based on correctness, clarity, and adherence to the problem constraints:\n"
            f"Solution 1: {verified_solution}\n"
            f"Solution 2: {alternative_solutions[0]}\n"
            f"Solution 3: {alternative_solutions[1]}"
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=[verified_solution, *alternative_solutions])

        return final_solution