# Workflow ID: gsm8k_220_0
# Benchmark: gsm8k
# Data Indices: [459, 242]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract all critical information from the problem
        extraction_instruction = """
        Analyze the problem thoroughly and extract all relevant information, including:
        - Numerical values and their associated units (e.g., hours, dollars, feet)
        - Relationships between quantities (e.g., percentages, rates, proportions)
        - The specific question being asked
        Ensure the output is structured and easy to interpret for further processing.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate a step-by-step solution using the extracted information
        solution_instruction = f"""
        Using the extracted information below, solve the problem step by step:
        {extracted_info}
        
        Follow these guidelines:
        - Translate the relationships into mathematical operations
        - Perform intermediate calculations explicitly
        - Keep track of units throughout the process
        - Ensure the solution is logical and consistent with the problem context
        Provide the full reasoning process and the final answer.
        """
        solution = await self.generate(instruction=solution_instruction, context=self.problem_text)

        # Step 3: Validate and refine the solution
        refinement_instruction = """
        Critically evaluate the solution provided and refine it if necessary. Focus on:
        - Verifying the correctness of all calculations
        - Ensuring unit consistency throughout
        - Confirming that the solution aligns with the problem context
        - Improving clarity and logical flow
        If any issues are found, correct them and provide an improved version.
        """
        refined_solution = await self.revise(instruction=refinement_instruction, context=solution)

        # Step 4: Extract the final answer
        answer_instruction = """
        From the refined solution, extract the final numerical answer. Ensure it is:
        - A single value (integer or decimal)
        - Clearly identified as the answer to the problem
        Remove any extraneous information and return only the answer.
        """
        final_answer = await self.summarize(instruction=answer_instruction, context=refined_solution)

        return final_answer