# Workflow ID: gsm8k_136_0
# Benchmark: gsm8k
# Data Indices: [577, 214]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract numerical values, relationships, and constraints
        extraction_instruction = (
            "Carefully analyze the problem text to extract all numerical values, "
            "relationships, and constraints. Clearly label each piece of information "
            "and organize them in a structured format. Ensure that units (if any) "
            "are preserved and noted explicitly."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate intermediate calculation steps
        intermediate_steps_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Generate a detailed sequence of intermediate calculation steps required "
            "to solve the problem. Each step should include the operation to be performed, "
            "the relevant values, and the expected result. Ensure that the steps are "
            "logically ordered and account for any hidden or implied calculations."
        )
        intermediate_steps = await self.generate(instruction=intermediate_steps_instruction, context=self.problem_text)

        # Step 3: Revise and refine the intermediate steps
        revise_instruction = (
            "Critically review the following intermediate calculation steps:\n"
            f"{intermediate_steps}\n"
            "Ensure that each step is mathematically sound, unit-consistent, and logically "
            "sequenced. Correct any errors, clarify ambiguities, and add missing steps if necessary."
        )
        refined_steps = await self.revise(instruction=revise_instruction, context=intermediate_steps)

        # Step 4: Summarize to compute the final answer
        summarize_instruction = (
            "Condense the following refined calculation steps into a single numerical answer:\n"
            f"{refined_steps}\n"
            "Ensure that the final result is clearly stated and makes sense in the context "
            "of the problem. Include appropriate units if applicable."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_steps)

        return final_answer