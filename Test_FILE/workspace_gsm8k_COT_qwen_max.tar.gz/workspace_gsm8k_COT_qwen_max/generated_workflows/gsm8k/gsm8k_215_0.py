# Workflow ID: gsm8k_215_0
# Benchmark: gsm8k
# Data Indices: [693, 341]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information
        extraction_instruction = """
        Extract all numerical values, relationships, and entities mentioned in the problem. 
        Note any implied operations (e.g., "twice the number" implies multiplication). 
        Identify what the question is asking for and list all knowns and unknowns.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a solution plan
        plan_instruction = f"""
        Based on the following extracted information: {extracted_info}
        Create a step-by-step solution plan to solve the problem. 
        Outline the sequence of calculations required, including any intermediate steps. 
        Ensure the plan handles unit consistency and contextual constraints.
        """
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Perform calculations in parallel
        calculation_instructions = []
        for step in solution_plan.split("\n"):  # Assuming solution_plan lists steps line by line
            if step.strip():  # Ignore empty lines
                calc_instruction = f"""
                Perform the following calculation step: {step}
                Use the extracted information: {extracted_info}
                Ensure intermediate results are accurate and contextually appropriate.
                """
                calculation_instructions.append(calc_instruction)

        # Execute calculations in parallel
        calculation_tasks = [
            self.generate(instruction=calc_instruction, context=self.problem_text)
            for calc_instruction in calculation_instructions
        ]
        intermediate_results = await asyncio.gather(*calculation_tasks)

        # Step 4: Combine results
        combine_instruction = f"""
        Combine the following intermediate results into a final answer: {intermediate_results}
        Ensure the final answer is consistent, accurate, and answers the original question.
        """
        final_answer = await self.ensemble(instruction=combine_instruction, contexts=intermediate_results)

        # Step 5: Verify and refine
        refine_instruction = f"""
        Critique the following final answer: {final_answer}
        Ensure it makes sense in the context of the problem. 
        Check for logical and arithmetic errors. Refine if necessary.
        """
        refined_answer = await self.revise(instruction=refine_instruction, context=final_answer)

        return refined_answer