# Workflow ID: gsm8k_33_0
# Benchmark: gsm8k
# Data Indices: [392, 628]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information from the problem
        extract_instruction = """
        Thoroughly analyze the problem and extract all numerical values, relationships, 
        units, and any other relevant details needed to solve the problem. Ensure that 
        you capture every piece of information explicitly mentioned in the text, including 
        implicit constraints or conditions. Provide the extracted information in a structured 
        format suitable for subsequent calculations.
        """
        extraction = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Generate a step-by-step solution plan
        solution_instruction = f"""
        Based on the following extracted information: {extraction}
        
        Create a detailed step-by-step plan to solve the problem. Include all calculations 
        required, specify the order of operations, and ensure that units are tracked consistently 
        throughout. If there are multiple steps, clearly outline each one and explain how they 
        build upon each other. Consider any intermediate results that need to be computed and 
        verify that the final answer addresses the question being asked.
        """
        solution_plan = await self.generate(instruction=solution_instruction, context=self.problem_text)

        # Step 3: Perform calculations and refine the solution
        refine_instruction = f"""
        Review the following solution plan: {solution_plan}
        
        Verify the correctness of each step, check for calculation errors, and ensure that 
        the final answer is consistent with the problem context. Refine the solution if 
        necessary, making adjustments to improve accuracy and clarity. Ensure that the 
        answer makes sense in the real-world scenario described by the problem.
        """
        refined_solution = await self.revise(instruction=refine_instruction, context=solution_plan)

        # Step 4: Summarize the final result and key steps
        summarize_instruction = f"""
        Condense the following refined solution into a concise summary: {refined_solution}
        
        Highlight the final answer and provide a brief overview of the key steps taken 
        to arrive at the solution. Ensure that the summary is clear, accurate, and includes 
        all essential information without unnecessary details.
        """
        final_summary = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_summary