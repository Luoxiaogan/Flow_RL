# Workflow ID: gsm8k_179_0
# Benchmark: gsm8k
# Data Indices: [410, 794]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information from the problem
        extraction_instruction = """
        Analyze the problem and extract all relevant numerical values, relationships, and constraints.
        Include:
        - All explicit and implicit numbers mentioned in the problem
        - Units of measurement (if any)
        - Relationships between quantities (e.g., rates, proportions, totals)
        - Any conditions or constraints (e.g., time-based, real-world limitations)
        Organize the extracted information clearly for further processing.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate the solution strategy
        strategy_instruction = f"""
        Based on the following extracted information:
        {extracted_info}
        Formulate a step-by-step solution strategy to solve the problem. Include:
        - The sequence of calculations required
        - Any intermediate steps or hidden calculations
        - How to handle units and ensure consistency
        - How to arrive at the final answer
        Provide a clear plan that can be executed programmatically.
        """
        solution_strategy = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Execute intermediate calculations in parallel
        intermediate_instructions = [
            "Perform the first intermediate calculation as described in the solution strategy.",
            "Perform the second intermediate calculation as described in the solution strategy.",
            "Perform the third intermediate calculation as described in the solution strategy."
        ]
        intermediate_results = await asyncio.gather(
            *[self.generate(instruction=instr, context=solution_strategy) for instr in intermediate_instructions]
        )

        # Step 4: Synthesize the final answer
        synthesis_instruction = """
        Combine the following intermediate results into a final answer:
        Results:
        - {results[0]}
        - {results[1]}
        - {results[2]}
        Ensure the final answer is consistent with the problem context and satisfies all constraints.
        """
        final_answer = await self.ensemble(
            instruction=synthesis_instruction.format(results=intermediate_results),
            contexts=intermediate_results
        )

        # Step 5: Validate and refine the solution
        validation_instruction = f"""
        Review the following solution:
        Final Answer: {final_answer}
        Problem Text: {self.problem_text}
        Check for:
        - Logical consistency
        - Numerical correctness
        - Compliance with problem constraints
        If any issues are found, suggest refinements.
        """
        refined_solution = await self.revise(instruction=validation_instruction, context=final_answer)

        return refined_solution