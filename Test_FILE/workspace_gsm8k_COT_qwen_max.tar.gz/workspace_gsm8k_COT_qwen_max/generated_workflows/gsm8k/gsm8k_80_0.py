# Workflow ID: gsm8k_80_0
# Benchmark: gsm8k
# Data Indices: [275, 449]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract known information (numerical values, units, relationships)
        extract_instruction = (
            "Thoroughly analyze the problem and extract all numerical values, units, and relationships between entities. "
            "Ensure the extraction is complete and accurate. Format the output as a structured list."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Model relationships and plan the solution
        model_instruction = f"""
        Based on the extracted information: {extracted_info}
        Analyze the relationships between the entities and determine the sequence of mathematical operations required to solve the problem. 
        Clearly outline the steps needed to calculate the final answer, including any intermediate results. 
        Ensure the plan accounts for all constraints and real-world considerations mentioned in the problem.
        """
        solution_plan = await self.generate(instruction=model_instruction, context=self.problem_text)

        # Step 3: Perform calculations step-by-step
        calculate_instruction = f"""
        Using the solution plan: {solution_plan}
        Perform the calculations step-by-step, showing all intermediate results. 
        Ensure each step is clearly explained and logically follows from the previous one. 
        Verify that the calculations align with the relationships and constraints identified earlier.
        """
        calculations = await self.generate(instruction=calculate_instruction, context=self.problem_text)

        # Step 4: Revise and refine the solution
        revise_instruction = f"""
        Critically evaluate the calculations: {calculations}
        Check for consistency, accuracy, and adherence to the problem's constraints. 
        If there are any errors or ambiguities, refine the solution to address them. 
        Ensure the final result is logical and makes sense in the context of the problem.
        """
        refined_solution = await self.revise(instruction=revise_instruction, context=calculations)

        # Step 5: Summarize the final answer
        summarize_instruction = f"""
        Condense the refined solution: {refined_solution}
        Present the final answer in a clear and concise format. 
        Ensure the answer directly addresses the question posed in the problem.
        """
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_answer