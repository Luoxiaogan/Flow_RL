# Workflow ID: gsm8k_43_0
# Benchmark: gsm8k
# Data Indices: [343, 84]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information
        extract_instruction = """
        Carefully analyze the problem and extract all relevant information. 
        Include numerical values, units, relationships, and constraints. 
        Organize the information in a structured format for clarity.
        """
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Formulate a solution plan
        plan_instruction = f"""
        Based on the following extracted information: {extracted_info}
        Create a detailed step-by-step plan to solve the problem. 
        Identify the sequence of operations required and any intermediate calculations needed. 
        Ensure the plan is logical and accounts for all constraints mentioned in the problem.
        """
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute calculations
        calculate_instruction = f"""
        Follow this solution plan: {solution_plan}
        Perform the calculations step by step, ensuring accuracy at each stage. 
        Include intermediate results and their interpretations. 
        Clearly state the final answer at the end.
        """
        calculations = await self.generate(instruction=calculate_instruction, context=self.problem_text)

        # Step 4: Verify and refine the solution
        refine_instruction = f"""
        Review the following calculations: {calculations}
        Critique the solution for accuracy, consistency, and adherence to the problem's constraints. 
        Refine the solution if necessary, ensuring the final answer makes sense in the context of the problem.
        """
        refined_solution = await self.revise(instruction=refine_instruction, context=calculations)

        # Step 5: Summarize the final answer
        summarize_instruction = f"""
        Based on the refined solution: {refined_solution}
        Summarize the entire reasoning process and provide the final answer in a concise format. 
        Ensure the answer is a single numerical value (integer or decimal) as required by the problem.
        """
        final_summary = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_summary