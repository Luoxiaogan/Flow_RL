# Workflow ID: gsm8k_86_0
# Benchmark: gsm8k
# Data Indices: [491, 246]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract known information
        extraction_instruction = (
            "Extract all numerical values, units, and relationships from the problem. "
            "Include any constraints or conditions mentioned explicitly or implicitly. "
            "Format the output as a structured list for clarity."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a solution plan
        planning_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Formulate a step-by-step plan to solve the problem. "
            "Identify intermediate calculations, specify the order of operations, "
            "and ensure unit consistency throughout. "
            "Highlight any assumptions or implicit steps required."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Execute the solution plan
        execution_instruction = (
            f"Follow this solution plan step by step:\n{solution_plan}\n"
            "Perform all calculations explicitly and show intermediate results. "
            "Ensure all units are consistent and properly converted if necessary. "
            "Provide the final result as a single numerical value."
        )
        execution_result = await self.generate(instruction=execution_instruction, context=self.problem_text)

        # Step 4: Validate and refine the solution
        validation_instruction = (
            f"Review the following solution:\n{execution_result}\n"
            "Check for logical consistency, unit correctness, and adherence to the problem context. "
            "Refine the solution if there are errors or inconsistencies. "
            "Ensure the final answer makes sense in the real-world scenario described."
        )
        refined_solution = await self.revise(instruction=validation_instruction, context=execution_result)

        # Step 5: Summarize the final answer
        summarization_instruction = (
            f"Condense the following solution into a concise statement:\n{refined_solution}\n"
            "Highlight the final numerical answer clearly. "
            "Ensure the summary is easy to understand and directly addresses the problem."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_solution)

        return final_answer