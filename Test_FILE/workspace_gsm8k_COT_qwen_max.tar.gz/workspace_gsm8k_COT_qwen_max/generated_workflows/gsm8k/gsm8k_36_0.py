# Workflow ID: gsm8k_36_0
# Benchmark: gsm8k
# Data Indices: [301, 162]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract numerical values, relationships, and units
        extraction_instruction = (
            "Extract all numerical values, units, and relationships from the problem. "
            "Categorize them as totals, percentages, rates, or other relevant types. "
            "Ensure the output is structured and easy to interpret."
        )
        extracted_data = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        approach_1_instruction = (
            f"Using the extracted data: {extracted_data}, solve the problem step by step. "
            "Focus on sequential calculations and ensure intermediate results are clearly stated."
        )
        approach_2_instruction = (
            f"Using the extracted data: {extracted_data}, solve the problem using proportional reasoning. "
            "Focus on ratios, fractions, or percentages if applicable."
        )
        approach_3_instruction = (
            f"Using the extracted data: {extracted_data}, solve the problem using algebraic methods. "
            "Define variables and equations to represent the relationships in the problem."
        )

        results = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text),
            self.generate(instruction=approach_3_instruction, context=self.problem_text)
        )

        # Step 3: Revise and critique each approach
        revised_results = await asyncio.gather(
            self.revise(instruction="Critique and refine this solution. Ensure all steps are mathematically correct and logically sound.", context=results[0]),
            self.revise(instruction="Critique and refine this solution. Ensure all steps are mathematically correct and logically sound.", context=results[1]),
            self.revise(instruction="Critique and refine this solution. Ensure all steps are mathematically correct and logically sound.", context=results[2])
        )

        # Step 4: Ensemble to select the best approach
        ensemble_instruction = (
            "Evaluate the following solutions and select the best one. "
            "Consider correctness, clarity, and alignment with the problem context. "
            "Provide the final numerical answer with appropriate units."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=revised_results)

        # Step 5: Summarize the final result
        summary_instruction = (
            "Condense the solution into a concise format. Focus on the final numerical answer and its context. "
            "Ensure the output is clear and directly addresses the problem question."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=final_solution)

        return final_answer