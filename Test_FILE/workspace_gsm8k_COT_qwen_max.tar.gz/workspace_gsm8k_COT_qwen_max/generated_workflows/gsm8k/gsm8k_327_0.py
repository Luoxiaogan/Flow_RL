# Workflow ID: gsm8k_327_0
# Benchmark: gsm8k
# Data Indices: [64, 745]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract known information
        extraction_instruction = (
            "Extract all numerical values, relationships, and constraints from the problem. "
            "Identify the entities involved, their quantities, and any operations (e.g., addition, multiplication). "
            "Include units and any contextual information that might affect the solution."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate the mathematical model
        model_instruction = (
            f"Based on the following extracted information: {extracted_info}\n"
            "Formulate a step-by-step plan to solve the problem. "
            "Clearly define the sequence of operations needed, including intermediate calculations. "
            "Ensure the plan accounts for units, constraints, and real-world considerations."
        )
        mathematical_model = await self.generate(instruction=model_instruction, context=self.problem_text)

        # Step 3: Perform calculations
        calculation_instruction = (
            f"Using the following plan: {mathematical_model}\n"
            "Execute the calculations step-by-step. "
            "Show all intermediate results and verify each step before proceeding to the next. "
            "Ensure the final result is expressed as a single numerical value."
        )
        calculations = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Verify consistency and units
        verification_instruction = (
            f"Review the following calculations: {calculations}\n"
            "Check for correctness, consistency, and adherence to real-world constraints. "
            "Ensure all units are properly handled and the result makes sense in the context of the problem."
        )
        verified_solution = await self.revise(instruction=verification_instruction, context=calculations)

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"Condense the following solution: {verified_solution}\n"
            "Provide the final answer as a single numerical value, ensuring it aligns with the problem's requirements."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=verified_solution)

        return final_answer