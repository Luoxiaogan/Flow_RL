# Workflow ID: gsm8k_343_0
# Benchmark: gsm8k
# Data Indices: [561, 460]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract known information (numerical values, units, relationships)
        extract_instruction = (
            "Thoroughly analyze the problem text to extract all numerical values, units, "
            "and relationships between quantities. Provide the results in a structured format, "
            "clearly labeling each piece of information."
        )
        extract_task = self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Identify the problem type and formulate a solution strategy
        strategy_instruction = (
            "Based on the problem text, determine the type of problem (e.g., sequential operations, "
            "rate problems, proportional reasoning) and outline a step-by-step strategy to solve it. "
            "Include details about the order of operations, intermediate calculations, and any "
            "constraints or contextual considerations."
        )
        strategy_task = self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Run extraction and strategy identification in parallel
        extracted_info, strategy = await asyncio.gather(extract_task, strategy_task)

        # Step 3: Perform calculations step-by-step
        calculation_instruction = (
            f"Using the extracted information:\n{extracted_info}\n"
            f"And the solution strategy:\n{strategy}\n"
            "Perform the calculations step-by-step. Clearly show all intermediate results and "
            "ensure the final answer is accurate and consistent with the problem context."
        )
        calculation_result = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Validate the solution
        validation_instruction = (
            "Critically review the calculated result to ensure it is logically consistent, "
            "respects the problem's constraints, and adheres to real-world limitations "
            "(e.g., no negative quantities, fractional people). Suggest corrections if needed."
        )
        validated_result = await self.revise(instruction=validation_instruction, context=calculation_result)

        # Step 5: Summarize the final answer
        summary_instruction = (
            "Condense the validated result into a single numerical value representing the final answer. "
            "Ensure the output is precise and formatted appropriately (integer or decimal)."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=validated_result)

        return final_answer