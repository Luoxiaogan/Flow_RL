# Workflow ID: gsm8k_321_0
# Benchmark: gsm8k
# Data Indices: [641, 58]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract numerical values, relationships, and the target unknown
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, "
            "relationships, and the specific quantity being asked for. "
            "Format your output as a structured list of key-value pairs, "
            "including units where applicable."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Model the problem mathematically and outline the solution steps
        modeling_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Model the problem mathematically. Identify the sequence of operations "
            "(addition, subtraction, multiplication, division, etc.) needed to compute "
            "the final answer. Include intermediate steps if necessary and specify "
            "any assumptions or constraints."
        )
        modeled_solution = await self.generate(instruction=modeling_instruction, context=self.problem_text)

        # Step 3: Refine the solution for accuracy and consistency
        refinement_instruction = (
            "Review the following solution:\n" + modeled_solution + "\n"
            "Ensure all calculations are correct, units are consistent, and real-world "
            "constraints are respected. If there are errors or ambiguities, revise the "
            "solution accordingly."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=modeled_solution)

        # Step 4: Summarize the final answer
        summarization_instruction = (
            "Condense the following solution into a single numerical value, which is "
            "the final answer to the problem:\n" + refined_solution + "\n"
            "Ensure the answer is clear, precise, and formatted correctly."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_solution)

        return final_answer