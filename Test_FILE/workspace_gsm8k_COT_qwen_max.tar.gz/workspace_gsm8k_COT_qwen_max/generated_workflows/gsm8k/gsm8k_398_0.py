# Workflow ID: gsm8k_398_0
# Benchmark: gsm8k
# Data Indices: [546, 305]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract known information (numerical values, units, relationships)
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, units, and relationships. "
            "List them clearly and explicitly, ensuring no information is missed. "
            "If there are implicit relationships or constraints, infer and include them."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate the mathematical model and solution strategy
        formulation_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Formulate a step-by-step solution strategy to solve the problem. "
            "Clearly specify the order of operations, intermediate calculations, and any unit conversions. "
            "Ensure the strategy accounts for all constraints and real-world considerations."
        )
        solution_strategy = await self.generate(instruction=formulation_instruction, context=self.problem_text)

        # Step 3: Perform calculations (sequential or parallel)
        calculation_instruction = (
            f"Execute the following solution strategy step by step:\n{solution_strategy}\n"
            "Perform all calculations accurately, showing intermediate results where necessary. "
            "Ensure unit consistency and logical flow throughout the process."
        )
        calculations = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Validate the solution
        validation_instruction = (
            f"Review the following solution:\n{calculations}\n"
            "Critique and validate the result. Ensure it satisfies all constraints and makes logical sense "
            "in the context of the problem. Check for unit consistency, reasonable magnitudes, and real-world feasibility."
        )
        validated_solution = await self.revise(instruction=validation_instruction, context=calculations)

        # Step 5: Summarize the final answer
        summarization_instruction = (
            f"From the following validated solution:\n{validated_solution}\n"
            "Extract and summarize the final numerical answer. Ensure the result is concise and formatted appropriately."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=validated_solution)

        return final_answer