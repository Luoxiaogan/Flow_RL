# Workflow ID: gsm8k_32_0
# Benchmark: gsm8k
# Data Indices: [439, 496]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract known values and relationships
        extraction_instruction = (
            "Extract all numerical values, units, and relationships from the problem. "
            "Include quantities, rates, costs, discounts, or any other relevant information. "
            "Organize the extracted data into a structured format for further processing."
        )
        extracted_values = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a mathematical model
        model_instruction = (
            f"Using the extracted information: {extracted_values}, formulate a step-by-step plan "
            "to solve the problem mathematically. Include all necessary operations (e.g., addition, subtraction, "
            "multiplication, division) and ensure the sequence of steps is logical and complete."
        )
        mathematical_model = await self.generate(instruction=model_instruction, context=self.problem_text)

        # Step 3: Perform calculations
        calculation_instruction = (
            f"Execute the following mathematical model step-by-step: {mathematical_model}. "
            "Perform all calculations accurately, keeping track of units and intermediate results."
        )
        raw_solution = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Revise the solution for accuracy
        revise_instruction = (
            "Review the calculations and intermediate results. Ensure all steps are correct, "
            "units are consistent, and the final result makes sense in the context of the problem. "
            "Flag any inconsistencies or errors."
        )
        revised_solution = await self.revise(instruction=revise_instruction, context=raw_solution)

        # Step 4: Summarize the final solution
        summarize_instruction = (
            "Condense the solution into a single numerical value. Ensure the answer is clear, "
            "accurate, and appropriately formatted (e.g., integer or decimal)."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=revised_solution)

        return final_answer