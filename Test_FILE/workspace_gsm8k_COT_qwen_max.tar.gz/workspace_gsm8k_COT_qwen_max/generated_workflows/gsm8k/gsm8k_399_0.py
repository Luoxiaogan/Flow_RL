# Workflow ID: gsm8k_399_0
# Benchmark: gsm8k
# Data Indices: [725, 743]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information
        extraction_instruction = (
            "Carefully analyze the problem statement and extract all numerical values, units, "
            "relationships (e.g., percentages, ratios, rates), and the specific question being asked. "
            "Ensure you capture all constraints and contextual details needed for solving the problem."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate a mathematical model
        modeling_instruction = (
            f"Using the extracted information: {extracted_info}, construct a step-by-step plan or "
            "mathematical model to solve the problem. Include all intermediate calculations, specify "
            "the order of operations, and ensure proper handling of units. Clearly state the final "
            "numerical value or expression required to answer the question."
        )
        model = await self.generate(instruction=modeling_instruction, context=self.problem_text)

        # Step 3: Parallel execution of solution approaches
        approach1_instruction = (
            f"Solve the problem using the following model: {model}. Perform the calculations step-by-step, "
            "ensuring each intermediate result is accurate and consistent with the problem context."
        )
        approach2_instruction = (
            f"Solve the problem using the following model: {model}. Use an alternative reasoning path, "
            "such as algebraic formulation or logical deduction, to verify the solution."
        )
        results = await asyncio.gather(
            self.generate(instruction=approach1_instruction, context=self.problem_text),
            self.generate(instruction=approach2_instruction, context=self.problem_text)
        )

        # Step 4: Ensemble to select the best solution
        ensemble_instruction = (
            "Compare the two solutions provided and select the most accurate and consistent one. "
            "If there are discrepancies, resolve them by analyzing the reasoning and calculations in each approach."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 5: Revise for clarity and correctness
        revise_instruction = (
            "Review the selected solution for clarity, correctness, and completeness. Ensure all steps "
            "are logically sound, properly sequenced, and aligned with the problem requirements."
        )
        refined_solution = await self.revise(instruction=revise_instruction, context=best_solution)

        # Step 6: Summarize to extract the final answer
        summarize_instruction = (
            "From the refined solution, extract and present the final numerical answer. Ensure it is "
            "clearly stated and formatted appropriately."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_answer