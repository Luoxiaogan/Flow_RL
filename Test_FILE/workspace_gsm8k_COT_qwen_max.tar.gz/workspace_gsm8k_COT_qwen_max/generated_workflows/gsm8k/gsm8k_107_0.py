# Workflow ID: gsm8k_107_0
# Benchmark: gsm8k
# Data Indices: [486, 588]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract key information (numerical values, relationships, entities)
        extraction_instruction = (
            "Extract all numerical values, relationships, and entities mentioned in the problem. "
            "Include units (if any) and describe how these elements are related. "
            "Organize the information in a structured format for further processing."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a solution plan
        plan_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Formulate a step-by-step plan to solve the problem. "
            "Identify intermediate calculations, hidden steps, and the final goal. "
            "Ensure the plan accounts for unit consistency and real-world constraints."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute calculations in parallel
        calculation_instruction = (
            f"Follow this solution plan: {solution_plan}\n"
            "Perform each calculation step independently. "
            "Provide intermediate results and ensure accuracy at each stage."
        )
        calculation_steps = solution_plan.split("\n")  # Split plan into individual steps
        calculation_tasks = [
            self.generate(instruction=calculation_instruction, context=step) for step in calculation_steps
        ]
        calculation_results = await asyncio.gather(*calculation_tasks)

        # Step 4: Validate and refine results
        validation_instruction = (
            f"Review the calculation results: {calculation_results}\n"
            "Check for consistency, accuracy, and adherence to the problem context. "
            "Refine any results that seem incorrect or incomplete."
        )
        refined_results = await self.revise(instruction=validation_instruction, context="\n".join(calculation_results))

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"Condense the refined results: {refined_results}\n"
            "Provide the final answer as a single numerical value. "
            "Ensure the answer makes sense in the context of the problem."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_results)

        return final_answer