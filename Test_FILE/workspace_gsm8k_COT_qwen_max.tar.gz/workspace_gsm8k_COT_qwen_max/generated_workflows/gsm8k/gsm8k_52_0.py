# Workflow ID: gsm8k_52_0
# Benchmark: gsm8k
# Data Indices: [134, 62]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract known information (numerical values, units, entities, relationships)
        extraction_instruction = """
        Extract all numerical values, units, entities, and relationships from the problem text.
        Include contextual details for each number (e.g., what it represents).
        Identify any constraints or conditions mentioned in the problem.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate intermediate steps and reasoning
        reasoning_instruction = f"""
        Based on the extracted information: {extracted_info}
        Outline the step-by-step reasoning process to solve the problem.
        Include any intermediate calculations or logical deductions required.
        Ensure the steps are ordered chronologically and account for hidden steps or constraints.
        """
        reasoning_steps = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Perform calculations step by step
        calculation_instruction = f"""
        Using the reasoning steps: {reasoning_steps}
        Perform the necessary calculations step by step.
        Handle units consistently and ensure the order of operations is correct.
        Provide intermediate results for each step.
        """
        calculations = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Revise and verify the solution
        revision_instruction = f"""
        Critique the following solution: {calculations}
        Check for logical consistency, unit correctness, and whether the answer makes sense in the problem's context.
        Identify and correct any errors or inconsistencies.
        """
        revised_solution = await self.revise(instruction=revision_instruction, context=calculations)

        # Step 5: Summarize the final answer
        summary_instruction = """
        Extract the final numerical answer from the revised solution.
        Ensure the answer is in the correct format (integer or decimal) and includes no extraneous information.
        """
        final_answer = await self.summarize(instruction=summary_instruction, context=revised_solution)

        return final_answer