# Workflow ID: gsm8k_289_0
# Benchmark: gsm8k
# Data Indices: [9, 324]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract known values and relationships
        extraction_instruction = """
        Extract all numerical values, units, and relationships from the problem. 
        Identify the quantities involved, their relationships (e.g., percentages, ratios, rates), 
        and any constraints or conditions mentioned. 
        Present the extracted information in a structured format, such as bullet points or a table.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a step-by-step plan
        plan_instruction = f"""
        Based on the extracted information below, formulate a detailed step-by-step plan to solve the problem. 
        Clearly outline the sequence of calculations, including any intermediate steps or hidden calculations. 
        Ensure the plan accounts for all relationships and constraints mentioned in the problem.

        Extracted Information:
        {extracted_info}
        """
        plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute the plan and perform calculations
        execution_instruction = f"""
        Follow the step-by-step plan below to solve the problem. 
        Perform each calculation explicitly, showing intermediate results where necessary. 
        Validate that each step logically follows from the previous one and leads toward the final answer. 
        Ensure the solution adheres to the problem's context and constraints.

        Step-by-Step Plan:
        {plan}
        """
        solution = await self.generate(instruction=execution_instruction, context=self.problem_text)

        # Step 4: Validate the solution
        validation_instruction = f"""
        Critique the solution below to ensure its correctness. 
        Check that all calculations are accurate, the order of operations is correct, 
        and the final answer makes sense in the context of the problem. 
        If there are any errors or ambiguities, refine the solution accordingly.

        Solution:
        {solution}
        """
        refined_solution = await self.revise(instruction=validation_instruction, context=solution)

        # Step 5: Summarize the final answer
        summary_instruction = """
        Summarize the final answer in the required format: a single numerical value (integer or decimal). 
        Ensure the answer is clear, concise, and ready for submission.
        """
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer