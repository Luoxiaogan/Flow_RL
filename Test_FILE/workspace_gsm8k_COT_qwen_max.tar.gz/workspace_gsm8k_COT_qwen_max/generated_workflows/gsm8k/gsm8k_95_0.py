# Workflow ID: gsm8k_95_0
# Benchmark: gsm8k
# Data Indices: [708, 625]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract key information
        extract_instruction = "Extract all numerical values, relationships, and constraints from the problem. Include units and any contextual information."
        extraction_task = self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Formulate a step-by-step solution plan
        plan_instruction = "Create a detailed step-by-step plan to solve the problem. Include intermediate calculations and logical sequencing."
        planning_task = self.generate(instruction=plan_instruction, context=self.problem_text)

        # Execute extraction and planning in parallel
        extraction, planning = await asyncio.gather(extraction_task, planning_task)

        # Step 3: Execute the solution plan
        execute_instruction = f"Execute the following solution plan step-by-step:\n{planning}\nUse the extracted information:\n{extraction}"
        execution = await self.generate(instruction=execute_instruction, context=self.problem_text)

        # Step 4: Validate the solution
        validate_instruction = "Critically evaluate the solution for correctness and consistency. Ensure all constraints are respected and the solution makes sense in context."
        validation = await self.revise(instruction=validate_instruction, context=execution)

        # Step 5: Summarize the final answer
        summarize_instruction = "Condense the solution into a concise final answer. Ensure clarity and readability."
        final_answer = await self.summarize(instruction=summarize_instruction, context=validation)

        return final_answer