# Workflow ID: gsm8k_311_0
# Benchmark: gsm8k
# Data Indices: [597, 86]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract numerical values and relationships
        extraction_instruction = (
            "Extract all numerical values, relationships, and key entities from the problem. "
            "Identify what is being asked and any constraints or conditions. "
            "Format the output as a structured list of key-value pairs."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Translate the problem into a mathematical model
        modeling_instruction = (
            f"Based on the extracted information: {extracted_info}, "
            "translate the word problem into a mathematical model. "
            "Identify the required operations (e.g., addition, multiplication), intermediate steps, "
            "and any constraints. Provide the model as a sequence of steps."
        )
        mathematical_model = await self.generate(instruction=modeling_instruction, context=self.problem_text)

        # Step 3: Perform step-by-step calculations
        calculation_instruction = (
            f"Using the mathematical model: {mathematical_model}, "
            "perform the calculations step-by-step. Ensure all intermediate results are explicitly stated. "
            "If there are independent sub-steps, calculate them in parallel."
        )
        # Parallelize independent calculations if applicable
        calculation_results = await asyncio.gather(
            self.generate(instruction=calculation_instruction, context=self.problem_text),
        )

        # Step 4: Validate and refine the solution
        validation_instruction = (
            f"Review the calculation results: {calculation_results}. "
            "Check if the solution makes sense in the context of the problem. "
            "Ensure units are consistent, constraints are satisfied, and the answer is logical. "
            "Suggest corrections if necessary."
        )
        validated_solution = await self.revise(instruction=validation_instruction, context=calculation_results[0])

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"Summarize the validated solution: {validated_solution}. "
            "Provide the final answer as a single numerical value, ensuring it is clear and concise."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=validated_solution)

        return final_answer