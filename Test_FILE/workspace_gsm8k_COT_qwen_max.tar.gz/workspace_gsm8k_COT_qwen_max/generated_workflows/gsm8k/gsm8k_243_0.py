# Workflow ID: gsm8k_243_0
# Benchmark: gsm8k
# Data Indices: [533, 315]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all numerical values, units, and relationships
        extraction_instruction = (
            "Carefully analyze the problem text to identify and extract all numerical values, "
            "units, and relationships between them. Organize the extracted information in a "
            "structured format, such as a list or table, for easy reference. Ensure that all "
            "relevant details are captured, including any implicit or hidden information."
        )
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate a step-by-step solution plan
        solution_instruction = (
            f"Using the extracted information: {extraction}, generate a detailed step-by-step "
            "solution plan for solving the problem. Include all intermediate calculations, "
            "ensure correct order of operations, and handle units consistently. Address any "
            "hidden steps or implicit calculations that are not explicitly stated in the problem."
        )
        solution_plan = await self.generate(instruction=solution_instruction, context=self.problem_text)

        # Step 3: Validate and refine the solution plan
        refinement_instruction = (
            "Critically review the generated solution plan. Check for correctness, consistency, "
            "and adherence to mathematical principles. Refine the plan if necessary to address "
            "any errors, inconsistencies, or missing steps. Ensure that the final plan is clear, "
            "accurate, and ready for execution."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=solution_plan)

        # Step 4: Extract the final numerical answer
        summary_instruction = (
            "From the refined solution plan, extract the final numerical answer. Ensure that "
            "the answer is presented in the required format (integer or decimal) and includes "
            "appropriate units if applicable. Provide only the final answer without additional "
            "explanation."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer