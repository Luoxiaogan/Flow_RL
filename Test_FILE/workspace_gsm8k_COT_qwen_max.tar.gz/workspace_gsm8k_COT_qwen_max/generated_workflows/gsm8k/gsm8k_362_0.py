# Workflow ID: gsm8k_362_0
# Benchmark: gsm8k
# Data Indices: [212, 706]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract known information
        extraction_instruction = (
            "Extract all numerical values, relationships, and key entities from the problem. "
            "Include units, rates, and any contextual constraints. Format the output clearly."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate a step-by-step solution plan
        planning_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Formulate a step-by-step plan to solve the problem. "
            "Identify the sequence of operations (e.g., addition, subtraction, multiplication, division) "
            "and specify any intermediate calculations needed. Ensure the plan is chronological and logical."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Execute calculations in parallel
        calculation_instructions = []
        for step in solution_plan.split("\n"):  # Assuming solution_plan lists steps line by line
            if step.strip():  # Ignore empty lines
                calculation_instructions.append(
                    f"Perform the following calculation: {step}. "
                    "Ensure the result is accurate and includes appropriate units."
                )
        calculation_tasks = [
            self.generate(instruction=instr, context=self.problem_text)
            for instr in calculation_instructions
        ]
        calculation_results = await asyncio.gather(*calculation_tasks)

        # Step 4: Verify intermediate results
        verification_tasks = [
            self.revise(
                instruction="Critique and refine the following result for accuracy and consistency. "
                            "Ensure it aligns with the problem's context and constraints.",
                context=result
            )
            for result in calculation_results
        ]
        verified_results = await asyncio.gather(*verification_tasks)

        # Step 5: Synthesize final answer
        synthesis_instruction = (
            "Combine the verified results into a single, coherent answer. "
            "Ensure the final output is a single numerical value (integer or decimal) "
            "that addresses the problem's question. Include units if applicable."
        )
        final_answer = await self.ensemble(
            instruction=synthesis_instruction,
            contexts=verified_results
        )

        return final_answer