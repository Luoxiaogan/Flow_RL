# Workflow ID: gsm8k_280_0
# Benchmark: gsm8k
# Data Indices: [586, 181]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (numerical values, units, relationships)
        extract_instruction = """
        Extract all numerical values, units, and relationships mentioned in the problem. 
        Identify entities (e.g., people, objects) and their associated quantities. 
        Clearly list these elements for further processing.
        """
        extract_task = self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Formulate a solution plan
        plan_instruction = """
        Based on the problem description, create a step-by-step solution plan. 
        Consider the problem type (e.g., sequential operations, rate problems, proportional reasoning). 
        Identify intermediate steps and the sequence of calculations needed to arrive at the final answer. 
        Ensure all units are consistent and accounted for.
        """
        plan_task = self.generate(instruction=plan_instruction, context=self.problem_text)

        # Run extraction and planning in parallel
        extracted_info, solution_plan = await asyncio.gather(extract_task, plan_task)

        # Step 3: Execute the solution plan
        execute_instruction = f"""
        Using the extracted information: {extracted_info}
        And the solution plan: {solution_plan}
        Perform the calculations step by step. 
        Compute intermediate results and the final answer. 
        Ensure all units are consistent and calculations are accurate.
        """
        executed_solution = await self.generate(instruction=execute_instruction, context=self.problem_text)

        # Step 4: Validate the answer
        validate_instruction = """
        Critique the computed answer to ensure it makes sense in the context of the problem. 
        Verify unit consistency, logical correctness, and alignment with the problem's constraints. 
        Identify any errors or inconsistencies and suggest corrections if needed.
        """
        validated_solution = await self.revise(instruction=validate_instruction, context=executed_solution)

        # Step 5: Summarize the final answer
        summarize_instruction = """
        Extract the final numerical answer from the validated solution. 
        Ensure the answer is clear, precise, and formatted as a single numerical value.
        """
        final_answer = await self.summarize(instruction=summarize_instruction, context=validated_solution)

        return final_answer