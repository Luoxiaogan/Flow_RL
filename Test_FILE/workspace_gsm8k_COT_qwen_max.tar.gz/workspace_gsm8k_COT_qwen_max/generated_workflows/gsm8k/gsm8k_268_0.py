# Workflow ID: gsm8k_268_0
# Benchmark: gsm8k
# Data Indices: [647, 144]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Carefully analyze the problem and extract all relevant information, including numerical values, "
            "relationships, units, and constraints. Clearly identify what is being asked and what is given. "
            "Organize the extracted information in a structured format."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Perform step-by-step reasoning to solve the problem
        reasoning_instruction = (
            f"Using the extracted information: {extracted_info}, reason through the problem step by step. "
            "Identify the sequence of mathematical operations required to solve the problem, such as addition, "
            "subtraction, multiplication, division, or percentage calculations. Ensure that all intermediate "
            "results are clearly stated and justified. Finally, calculate the final answer."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Validate and refine the solution
        validation_instruction = (
            "Review the solution provided and verify its correctness against the original problem. "
            "Check for consistency in units, logical flow, and adherence to the problem's constraints. "
            "If any issues are found, refine the solution to address them."
        )
        refined_solution = await self.revise(instruction=validation_instruction, context=reasoning_result)

        # Step 4: Parallel exploration of alternative solutions (if applicable)
        alternative_instruction_1 = (
            "Solve the problem using a direct calculation approach, focusing on the most straightforward "
            "sequence of operations."
        )
        alternative_instruction_2 = (
            "Solve the problem using a step-by-step breakdown, explicitly calculating each intermediate value."
        )
        alternative_results = await asyncio.gather(
            self.generate(instruction=alternative_instruction_1, context=self.problem_text),
            self.generate(instruction=alternative_instruction_2, context=self.problem_text)
        )
        final_instruction = (
            "Compare the two alternative solutions and select the one that is most accurate, complete, and "
            "consistent with the original problem. If both are valid, choose the one with the clearest reasoning."
        )
        final_solution = await self.ensemble(instruction=final_instruction, contexts=alternative_results)

        # Step 5: Summarize the final answer
        summary_instruction = (
            "Extract the final numerical answer from the solution, ensuring it is presented clearly and "
            "matches the requirements of the problem."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=final_solution)

        return final_answer