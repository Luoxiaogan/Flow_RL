# Workflow ID: gsm8k_396_0
# Benchmark: gsm8k
# Data Indices: [528, 167]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (numerical values, relationships, question)
        extract_instruction = """
        Analyze the problem thoroughly and extract all relevant numerical values, relationships, and the specific question being asked. 
        Ensure you capture any units (e.g., dollars, minutes, balloons) and contextual constraints (e.g., sharing half, weekly calls).
        Format the extracted information clearly for further processing.
        """
        extract_task = self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Plan the solution approach (sequence of operations, intermediate steps)
        plan_instruction = """
        Based on the extracted information, construct a detailed step-by-step plan to solve the problem. 
        Identify the sequence of mathematical operations required, including any intermediate calculations. 
        Ensure the plan accounts for unit consistency, real-world constraints, and logical flow.
        """
        plan_task = self.generate(instruction=plan_instruction, context=self.problem_text)

        # Execute extraction and planning in parallel
        extracted_info, solution_plan = await asyncio.gather(extract_task, plan_task)

        # Step 3: Execute the calculations based on the solution plan
        calculate_instruction = f"""
        Using the following extracted information:
        {extracted_info}
        And the solution plan:
        {solution_plan}
        Perform the calculations step by step. Ensure all intermediate results are accurate and properly tracked. 
        Verify that the final result answers the question posed in the problem.
        """
        calculated_result = await self.generate(instruction=calculate_instruction, context=self.problem_text)

        # Step 4: Revise and validate the solution
        revise_instruction = """
        Critique the provided solution to ensure correctness. Check for:
        - Logical consistency in the sequence of operations
        - Proper handling of units and decimal places
        - Adherence to real-world constraints (e.g., no negative quantities, fractional people)
        - Verification of intermediate results and the final answer
        Suggest improvements or corrections if necessary.
        """
        revised_solution = await self.revise(instruction=revise_instruction, context=calculated_result)

        # Step 5: Summarize the final answer
        summarize_instruction = """
        Condense the solution into a concise format that highlights the final numerical answer. 
        Ensure the output is a single numerical value (integer or decimal) that directly answers the problem.
        """
        final_answer = await self.summarize(instruction=summarize_instruction, context=revised_solution)

        return final_answer