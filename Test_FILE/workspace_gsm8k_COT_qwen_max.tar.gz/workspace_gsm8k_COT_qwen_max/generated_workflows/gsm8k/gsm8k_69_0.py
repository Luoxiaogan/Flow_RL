# Workflow ID: gsm8k_69_0
# Benchmark: gsm8k
# Data Indices: [505, 51]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, units, and relationships. "
            "Identify the known quantities and the unknowns. "
            "Describe the relationships between the quantities explicitly. "
            "Ensure all units are clearly stated and consistent where possible."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Translate problem into mathematical steps
        translation_instruction = (
            f"Based on the following extracted information: {extracted_info}\n"
            "Translate the problem into a sequence of mathematical operations. "
            "Clearly specify the order of operations, including any intermediate calculations. "
            "Ensure the steps account for unit conversions, proportions, and any constraints implied by the problem."
        )
        mathematical_steps = await self.generate(instruction=translation_instruction, context=self.problem_text)

        # Step 3: Perform calculations
        calculation_instruction = (
            f"Using the following mathematical steps: {mathematical_steps}\n"
            "Execute the calculations step by step. "
            "Show all intermediate results and ensure proper handling of units. "
            "Verify that the final result satisfies the problem's requirements."
        )
        calculated_result = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Validate and refine solution
        refinement_instruction = (
            f"Review the following calculated result: {calculated_result}\n"
            "Critique the solution for logical consistency and adherence to real-world constraints. "
            "Check for correct unit usage, reasonable decimal precision, and any overlooked contextual factors. "
            "Refine the solution if necessary to address any issues."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=calculated_result)

        # Step 5: Summarize final answer
        summary_instruction = (
            f"Condense the following refined solution: {refined_solution}\n"
            "Extract the final numerical answer, ensuring it is clear, concise, and makes sense in the context of the problem."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer