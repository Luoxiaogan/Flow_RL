# Workflow ID: gsm8k_96_0
# Benchmark: gsm8k
# Data Indices: [147, 536]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all relevant information from the problem
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, units, relationships, "
            "and the specific question being asked. Organize the information clearly and label each part."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Solve the problem step-by-step using the extracted information
        solution_instruction = (
            f"Using the following extracted information: {extracted_info}\n"
            "Solve the problem step-by-step, ensuring all calculations are shown explicitly. "
            "Handle units consistently and verify intermediate results. "
            "Provide a clear and logical explanation for each step."
        )
        initial_solution = await self.generate(instruction=solution_instruction, context=self.problem_text)

        # Step 3: Verify and refine the solution
        refinement_instruction = (
            "Critically review the provided solution. Check for calculation errors, logical inconsistencies, "
            "missing steps, or incorrect handling of units. Refine the solution to ensure it is accurate, "
            "complete, and makes sense in the context of the problem."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=initial_solution)

        # Step 4: Extract the final numerical answer
        summarization_instruction = (
            "From the refined solution, extract the final numerical answer. Ensure it is presented "
            "in the required format (integer or decimal) and includes appropriate units if necessary."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_solution)

        return final_answer