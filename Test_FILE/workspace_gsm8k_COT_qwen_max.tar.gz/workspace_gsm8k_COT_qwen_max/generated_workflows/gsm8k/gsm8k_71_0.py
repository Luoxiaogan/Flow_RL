# Workflow ID: gsm8k_71_0
# Benchmark: gsm8k
# Data Indices: [185, 217]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract known information (numerical values, relationships, units)
        extraction_instruction = (
            "Extract all numerical values, relationships, and units from the problem. "
            "Identify any implicit operations (e.g., doubling, halving, unit conversions). "
            "Organize the information clearly for subsequent steps."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a step-by-step plan to solve the problem
        plan_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. "
            "Include all intermediate calculations and ensure logical sequencing. "
            "Highlight any constraints or real-world considerations (e.g., non-negative quantities)."
        )
        plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Perform calculations and derive the final answer
        calculation_instruction = (
            f"Follow this plan step-by-step: {plan}\n"
            "Perform all calculations explicitly, showing intermediate results. "
            "Ensure unit consistency and verify that each step makes sense in context. "
            "Provide the final numerical answer at the end."
        )
        solution = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Validate the solution
        validation_instruction = (
            f"Critique this solution: {solution}\n"
            "Check the logic, verify calculations, and ensure the answer aligns with the problem context. "
            "Refine the solution if necessary, addressing any errors or inconsistencies."
        )
        validated_solution = await self.revise(instruction=validation_instruction, context=solution)

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"Condense this solution into a concise format: {validated_solution}\n"
            "Highlight the final numerical answer, ensuring it is clear and unambiguous."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=validated_solution)

        return final_answer