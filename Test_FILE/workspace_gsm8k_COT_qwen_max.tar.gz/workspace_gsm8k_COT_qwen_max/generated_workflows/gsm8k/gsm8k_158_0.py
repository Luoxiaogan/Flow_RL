# Workflow ID: gsm8k_158_0
# Benchmark: gsm8k
# Data Indices: [401, 382]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract key information
        extraction_instruction = (
            "Extract all numerical values, relationships, and constraints from the problem. "
            "Identify what is being asked and any intermediate steps required to solve the problem. "
            "Format the extracted information clearly for further processing."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a solution plan
        plan_instruction = (
            f"Based on the following extracted information: {extracted_info}\n"
            "Create a step-by-step plan to solve the problem. "
            "Include all necessary calculations and specify the order of operations. "
            "Ensure the plan accounts for any hidden steps or implicit relationships."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute intermediate calculations in parallel
        intermediate_calculations = []
        for i in range(1, 6):  # Assuming up to 5 intermediate steps
            calc_instruction = (
                f"Perform step {i} of the solution plan: {solution_plan}\n"
                "Carry out the required calculation and provide the result. "
                "If the step is not applicable, return 'N/A'."
            )
            intermediate_calculations.append(
                self.generate(instruction=calc_instruction, context=self.problem_text)
            )
        intermediate_results = await asyncio.gather(*intermediate_calculations)

        # Step 4: Synthesize results
        synthesis_instruction = (
            "Combine the following intermediate results into a final answer:\n"
            f"{intermediate_results}\n"
            "Ensure the final answer is consistent with the problem's requirements and units. "
            "Resolve any discrepancies or ambiguities."
        )
        synthesized_result = await self.ensemble(instruction=synthesis_instruction, contexts=intermediate_results)

        # Step 5: Refine the final answer
        refinement_instruction = (
            "Review the following result and ensure it is accurate and properly formatted:\n"
            f"{synthesized_result}\n"
            "Check for appropriate precision, units, and logical consistency. "
            "Make any necessary corrections."
        )
        final_answer = await self.revise(instruction=refinement_instruction, context=synthesized_result)

        return final_answer