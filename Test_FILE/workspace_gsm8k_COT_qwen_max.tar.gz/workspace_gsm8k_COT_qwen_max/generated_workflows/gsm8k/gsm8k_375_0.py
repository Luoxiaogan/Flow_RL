# Workflow ID: gsm8k_375_0
# Benchmark: gsm8k
# Data Indices: [361, 342]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract known information
        extract_instruction = (
            "Extract all numerical values, units, relationships, and constraints from the problem. "
            "List them clearly and label them appropriately. Ensure no detail is missed."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Identify problem type and unknowns
        identify_instruction = (
            "Analyze the extracted information to determine the type of problem (e.g., sequential operations, rate problems, proportional reasoning). "
            "Identify the unknown(s) the problem is asking us to solve for, as well as any intermediate steps required to reach the solution."
        )
        problem_analysis = await self.generate(instruction=identify_instruction, context=extracted_info)

        # Step 3: Plan the solution approach
        plan_instruction = (
            f"Based on the extracted information and problem analysis:\n{extracted_info}\n{problem_analysis}\n"
            "Create a detailed step-by-step plan for solving the problem. Include the sequence of operations, "
            "handling of units, and any logical constraints. Ensure the plan is comprehensive and executable."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=problem_analysis)

        # Step 4: Execute the plan
        execute_instruction = (
            f"Follow the solution plan step-by-step:\n{solution_plan}\n"
            "Perform all necessary calculations, apply formulas, and track units. Document intermediate results explicitly."
        )
        solution_execution = await self.generate(instruction=execute_instruction, context=solution_plan)

        # Step 5: Verify and refine the solution
        verify_instruction = (
            "Critique the solution to ensure it makes sense in the context of the problem. "
            "Check for logical consistency, adherence to real-world constraints, and proper handling of units. "
            "If any issues are found, suggest refinements."
        )
        refined_solution = await self.revise(instruction=verify_instruction, context=solution_execution)

        # Step 6: Summarize the final answer
        summarize_instruction = (
            "Condense the solution into a single numerical value. Ensure the answer is clear, concise, "
            "and formatted appropriately."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_answer