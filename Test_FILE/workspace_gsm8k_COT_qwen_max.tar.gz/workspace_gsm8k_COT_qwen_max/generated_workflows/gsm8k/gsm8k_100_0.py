# Workflow ID: gsm8k_100_0
# Benchmark: gsm8k
# Data Indices: [277, 233]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract known information (numerical values, relationships, constraints)
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, relationships, and constraints. "
            "Include units where applicable and describe how these values relate to each other. "
            "Ensure the extraction is complete and accurate."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Identify the question and plan the solution
        planning_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Identify what the problem is asking for and outline a step-by-step plan to solve it. "
            "Specify the mathematical operations needed (e.g., addition, subtraction, multiplication, division) "
            "and ensure that units are consistent throughout the plan."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Perform calculations
        calculation_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            f"And the solution plan: {solution_plan}\n"
            "Execute the calculations step by step. Show all intermediate results and ensure that each step "
            "is clearly explained. Maintain unit consistency and verify that the calculations make sense."
        )
        calculated_result = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Verify and refine the solution
        refinement_instruction = (
            f"Review the calculated result: {calculated_result}\n"
            "Critique the solution for correctness, ensuring that all steps are logically sound and consistent "
            "with the problem context. Check for unit consistency, proper handling of decimal places, and "
            "real-world constraints (e.g., no negative quantities, fractional people). Suggest refinements if needed."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=calculated_result)

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"Condense the refined solution: {refined_solution}\n"
            "Produce a concise, single numerical answer that directly addresses the problem. "
            "Ensure the final answer is clear and unambiguous."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer