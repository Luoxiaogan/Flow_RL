# Workflow ID: gsm8k_315_0
# Benchmark: gsm8k
# Data Indices: [634, 642]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract relevant information
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, relationships, "
            "and constraints. Identify any hidden steps, units, or contextual constraints. "
            "Organize the information clearly for subsequent reasoning."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Perform step-by-step reasoning and calculations
        reasoning_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem step by step. "
            "Sequence the calculations logically, verify intermediate results, and ensure unit consistency. "
            "Provide a detailed breakdown of the reasoning process."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Refine the solution
        refinement_instruction = (
            "Critique and refine the provided solution. Check for logical coherence, unit handling, "
            "and adherence to contextual constraints. Suggest improvements if necessary and ensure "
            "the reasoning aligns with the problem's requirements."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 4: Summarize the final answer
        summarization_instruction = (
            "Condense the refined solution into a single numerical answer. Ensure the answer is clear, "
            "precise, and formatted appropriately. Include the unit if applicable."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_solution)

        return final_answer