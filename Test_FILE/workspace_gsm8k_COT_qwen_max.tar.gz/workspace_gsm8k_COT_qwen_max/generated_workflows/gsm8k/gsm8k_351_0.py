# Workflow ID: gsm8k_351_0
# Benchmark: gsm8k
# Data Indices: [66, 456]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information from the problem text
        extraction_instruction = """
        Carefully analyze the provided problem text and extract all relevant information. 
        Include numerical values, relationships between quantities, units, and the specific question being asked. 
        Present the extracted information in a structured format, such as bullet points or key-value pairs.
        Ensure that no critical detail is omitted.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate a step-by-step solution based on the extracted information
        solution_instruction = f"""
        Using the following extracted information: {extracted_info}
        Create a detailed step-by-step solution to the problem. 
        Clearly identify each mathematical operation (addition, subtraction, multiplication, division, etc.) required to solve the problem. 
        Ensure that the order of operations is correct and that units are handled consistently throughout. 
        If intermediate calculations are needed, include them explicitly.
        """
        initial_solution = await self.generate(instruction=solution_instruction, context=self.problem_text)

        # Step 3: Validate and refine the solution
        refinement_instruction = """
        Critique the provided solution and refine it for accuracy and clarity. 
        Check for unit consistency, logical flow, and correctness of intermediate calculations. 
        If any errors or ambiguities are found, correct them and explain the changes made.
        """
        refined_solution = await self.revise(instruction=refinement_instruction, context=initial_solution)

        # Step 4: Compute the final answer
        final_answer_instruction = """
        From the refined solution, isolate and compute the final numerical answer. 
        Ensure that the answer is presented as a single value, either integer or decimal, without any additional text. 
        Verify that the answer makes sense in the context of the problem.
        """
        final_answer = await self.generate(instruction=final_answer_instruction, context=refined_solution)

        return final_answer