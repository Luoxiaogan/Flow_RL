# Workflow ID: gsm8k_371_0
# Benchmark: gsm8k
# Data Indices: [48, 556]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information (numerical values, relationships, constraints)
        extract_instruction = """
        Carefully analyze the problem and extract all relevant numerical values, relationships, and constraints. 
        Include percentages, totals, rates, and any other quantitative information explicitly mentioned or implied. 
        Ensure that the extracted information is complete and accurate for solving the problem.
        """
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Generate a step-by-step solution based on the extracted information
        solve_instruction = f"""
        Using the following extracted information: {extracted_info}
        Solve the problem step by step. Clearly show all intermediate calculations and reasoning. 
        Ensure that the solution adheres to the problem's context and constraints, such as unit consistency and real-world feasibility. 
        Provide the final numerical answer at the end.
        """
        solution = await self.generate(instruction=solve_instruction, context=self.problem_text)

        # Step 3: Revise the solution for accuracy and logical consistency
        revise_instruction = """
        Critique the provided solution. Check for logical consistency, correct order of operations, and adherence to contextual constraints. 
        Ensure that all steps are clearly explained and that the final answer makes sense in the context of the problem. 
        If there are any errors or ambiguities, provide corrections or clarifications.
        """
        refined_solution = await self.revise(instruction=revise_instruction, context=solution)

        # Step 4: Summarize the final answer
        summarize_instruction = """
        Extract the final numerical answer from the refined solution. Ensure that the answer is concise and directly addresses the question posed in the problem.
        """
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_answer