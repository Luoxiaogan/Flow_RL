# Workflow ID: gsm8k_292_0
# Benchmark: gsm8k
# Data Indices: [472, 419]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract known information
        extraction_instruction = """
        Extract all numerical values, units, relationships, and constraints from the problem text. 
        Organize the information in a structured format, such as a list or table, for easy reference. 
        Ensure that all extracted data is accurate and relevant to solving the problem.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate the solution strategy
        strategy_instruction = f"""
        Based on the extracted information: {extracted_info}
        Determine the sequence of operations required to solve the problem. 
        Identify any intermediate steps that are not explicitly stated but are necessary for the solution. 
        Provide a detailed plan for each step, including the arithmetic operations to be performed and the order in which they should be executed.
        """
        solution_strategy = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Perform calculations
        calculation_instruction = f"""
        Follow the solution strategy: {solution_strategy}
        Perform the necessary arithmetic operations step by step. 
        Ensure that each step is accurate and consistent with the problem context. 
        Include intermediate results and verify their correctness before proceeding to the next step.
        """
        calculations = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Validate the final answer
        validation_instruction = f"""
        Review the calculations: {calculations}
        Verify that the final result makes sense in the context of the problem. 
        Check the units, magnitude, and any constraints mentioned in the problem. 
        Ensure that the answer satisfies all requirements and is presented in the correct format.
        """
        validated_result = await self.revise(instruction=validation_instruction, context=calculations)

        # Step 5: Summarize the result
        summary_instruction = """
        Condense the final result into a single numerical value. 
        Ensure that the answer is clear, concise, and formatted appropriately for the problem type.
        """
        final_answer = await self.summarize(instruction=summary_instruction, context=validated_result)

        return final_answer