# Workflow ID: gsm8k_27_0
# Benchmark: gsm8k
# Data Indices: [578, 307]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = """
        Carefully analyze the problem and extract all relevant numerical values, relationships, and constraints. 
        Include any hidden assumptions or implied information. Format the output as follows:
        - Known Values: [list all numerical values and their units]
        - Relationships: [describe mathematical relationships or formulas]
        - Constraints: [list any conditions or limitations]
        - Unknowns: [identify what needs to be calculated]
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate a step-by-step solution
        solution_instruction = f"""
        Based on the following extracted information:
        {extracted_info}
        
        Solve the problem step by step. Clearly show each calculation and intermediate result. Ensure all units are consistent and properly tracked. 
        If there are multiple steps, explain the reasoning behind each step and how it contributes to solving the problem.
        """
        step_by_step_solution = await self.generate(instruction=solution_instruction, context=self.problem_text)

        # Step 3: Validate and refine the solution
        refinement_instruction = f"""
        Review the following solution:
        {step_by_step_solution}
        
        Critique the reasoning and calculations. Check for logical consistency, proper handling of units, and adherence to the problem constraints. 
        Suggest improvements or corrections if necessary. Ensure the solution makes sense in the context of the problem.
        """
        refined_solution = await self.revise(instruction=refinement_instruction, context=step_by_step_solution)

        # Step 4: Extract the final numerical answer
        final_answer_instruction = f"""
        From the following refined solution:
        {refined_solution}
        
        Extract the final numerical answer. Ensure the answer is clearly stated and includes appropriate units if applicable.
        """
        final_answer = await self.summarize(instruction=final_answer_instruction, context=refined_solution)

        return final_answer