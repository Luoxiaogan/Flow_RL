# Workflow ID: gsm8k_374_0
# Benchmark: gsm8k
# Data Indices: [88, 36]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, units, relationships, "
            "and constraints. Identify what the question is asking for and organize the information "
            "in a structured format. Ensure that all relevant details are captured."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Refine the extracted information into a clear intermediate representation
        refinement_instruction = (
            "Review the extracted information and refine it into a clear and concise intermediate "
            "representation. Ensure that all relationships and constraints are accurately captured. "
            "Organize the data in a way that facilitates step-by-step solution planning."
        )
        refined_representation = await self.revise(instruction=refinement_instruction, context=extracted_info)

        # Step 3: Formulate a detailed solution strategy
        strategy_instruction = (
            "Based on the refined representation, formulate a step-by-step solution strategy. "
            "Clearly outline the sequence of operations, including any intermediate calculations, "
            "unit conversions, or hidden steps. Ensure that the strategy addresses all aspects of the problem."
        )
        solution_strategy = await self.generate(instruction=strategy_instruction, context=refined_representation)

        # Step 4: Generate multiple solution approaches in parallel
        approach_1_instruction = (
            "Follow the solution strategy to compute the answer directly. Ensure that all steps "
            "are executed accurately and that the final result is consistent with the problem context."
        )
        approach_2_instruction = (
            "Verify the solution by using an alternative method, such as reverse engineering or "
            "cross-checking with different calculations. Ensure that the results align with the "
            "direct computation."
        )
        results = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=solution_strategy),
            self.generate(instruction=approach_2_instruction, context=solution_strategy)
        )

        # Step 5: Ensemble decision-making to select or synthesize the best solution
        ensemble_instruction = (
            "Evaluate the candidate solutions and determine the most accurate and consistent answer. "
            "If discrepancies exist, resolve them by synthesizing the best aspects of each solution. "
            "Ensure that the final answer satisfies all problem constraints."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 6: Summarize the final answer
        summary_instruction = (
            "Extract the single numerical answer from the final solution. Ensure that it is presented "
            "in the required format (integer or decimal) and that it makes sense in the context of the problem."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=final_solution)

        return final_answer