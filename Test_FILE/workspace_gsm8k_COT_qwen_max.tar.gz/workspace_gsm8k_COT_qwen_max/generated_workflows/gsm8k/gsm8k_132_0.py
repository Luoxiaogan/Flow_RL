# Workflow ID: gsm8k_132_0
# Benchmark: gsm8k
# Data Indices: [411, 749]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, relationships, units, "
            "and the specific question being asked. Organize this information clearly."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate intermediate reasoning steps
        reasoning_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Break the problem into logical steps, identifying intermediate calculations or transformations required. "
            "Ensure each step is clearly defined and logically follows from the previous one."
        )
        reasoning_steps = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Generate multiple solution approaches in parallel
        approach_1_instruction = (
            f"Using the reasoning steps: {reasoning_steps}\n"
            "Solve the problem step by step using a sequential approach. Show all calculations explicitly."
        )
        approach_2_instruction = (
            f"Using the reasoning steps: {reasoning_steps}\n"
            "Solve the problem algebraically, combining steps where possible. Ensure all transformations are valid."
        )
        approach_1, approach_2 = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text)
        )

        # Step 4: Synthesize and validate solutions
        synthesis_instruction = (
            "Compare the following two solutions and determine which one is correct. "
            "If both are correct, choose the most straightforward one. If neither is correct, identify the issues.\n"
            f"Solution 1: {approach_1}\nSolution 2: {approach_2}"
        )
        final_solution = await self.ensemble(instruction=synthesis_instruction, contexts=[approach_1, approach_2])

        # Step 5: Extract the final numerical answer
        answer_extraction_instruction = (
            f"From the final solution: {final_solution}\n"
            "Extract the single numerical answer (integer or decimal) that answers the original question."
        )
        final_answer = await self.generate(instruction=answer_extraction_instruction, context=self.problem_text)

        return final_answer