# Workflow ID: gsm8k_337_0
# Benchmark: gsm8k
# Data Indices: [247, 211]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (numerical values, relationships, units)
        extraction_instruction = (
            "Identify and list all numerical values, units, and relationships in the problem. "
            "Include any explicit or implicit arithmetic operations, comparisons, or constraints. "
            "Format the output as a structured summary."
        )
        key_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a step-by-step solution plan
        plan_instruction = (
            f"Based on the following extracted information:\n{key_info}\n"
            "Create a detailed step-by-step plan to solve the problem. "
            "Include all intermediate calculations, their order, and any necessary unit conversions. "
            "Ensure the plan is logical and accounts for real-world constraints."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute calculations in parallel
        steps = solution_plan.split("\n")  # Assume each step is on a new line
        calculation_tasks = []
        for step in steps:
            if step.strip():  # Ignore empty lines
                calculation_instruction = (
                    f"Perform the following calculation step: {step}\n"
                    "Provide the result with appropriate units and precision."
                )
                task = self.generate(instruction=calculation_instruction, context=self.problem_text)
                calculation_tasks.append(task)
        calculation_results = await asyncio.gather(*calculation_tasks)

        # Step 4: Synthesize results into a final answer
        synthesis_instruction = (
            "Combine the following calculation results into a coherent final answer. "
            "Ensure the result is consistent with the problem's context and constraints. "
            "If there are discrepancies, resolve them logically."
        )
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=calculation_results)

        # Step 5: Revise and validate the final answer
        revision_instruction = (
            f"Review the following final answer: {final_answer}\n"
            "Ensure it makes sense in the context of the problem. "
            "Check for unit consistency, realistic values, and adherence to constraints. "
            "Provide the revised answer if necessary."
        )
        validated_answer = await self.revise(instruction=revision_instruction, context=final_answer)

        return validated_answer