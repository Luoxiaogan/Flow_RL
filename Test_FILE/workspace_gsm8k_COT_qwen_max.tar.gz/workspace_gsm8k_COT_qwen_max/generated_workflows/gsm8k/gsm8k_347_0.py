# Workflow ID: gsm8k_347_0
# Benchmark: gsm8k
# Data Indices: [582, 652]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information
        extraction_instruction = (
            "Extract all numerical values, relationships, and constraints from the problem. "
            "Identify what is known and what needs to be solved. "
            "Include units and any relevant contextual information."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a solution plan
        plan_instruction = (
            f"Based on the following extracted information: {extracted_info} "
            "Create a detailed step-by-step plan to solve the problem. "
            "Include all necessary intermediate calculations and ensure hidden steps are explicitly addressed. "
            "Verify that the plan adheres to the problem's constraints and makes logical sense."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute calculations
        calculation_instruction = (
            f"Follow this solution plan: {solution_plan} "
            "Perform each calculation step by step. "
            "Use the results of previous steps as context for subsequent steps. "
            "Ensure all units are consistent and calculations are accurate."
        )
        calculations = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Verify and refine the solution
        refine_instruction = (
            f"Review the following calculations: {calculations} "
            "Critique and refine the solution to ensure accuracy and adherence to the problem's context. "
            "Correct any errors and ensure the solution makes logical sense."
        )
        refined_solution = await self.revise(instruction=refine_instruction, context=calculations)

        # Step 5: Summarize the final answer
        summarize_instruction = (
            "Condense the final solution into a single numerical value. "
            "Ensure the answer is clear, precise, and formatted appropriately."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_answer