# Workflow ID: gsm8k_166_0
# Benchmark: gsm8k
# Data Indices: [744, 719]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract numerical values, relationships, and units
        extraction_instruction = (
            "Extract all numerical values, relationships, and units from the problem. "
            "Include explicit and implicit information such as hidden steps, constraints, or conditions. "
            "Format the output as a structured list for clarity."
        )
        extracted_data = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Create a mathematical model
        modeling_instruction = (
            f"Using the extracted data: {extracted_data}, create a mathematical model to solve the problem. "
            "Identify variables, equations, and operations needed. Include intermediate steps if necessary. "
            "Format the model clearly and ensure it aligns with the problem's context."
        )
        mathematical_model = await self.generate(instruction=modeling_instruction, context=self.problem_text)

        # Step 3: Perform calculations step-by-step
        calculation_instruction = (
            f"Solve the mathematical model step-by-step: {mathematical_model}. "
            "Perform all calculations explicitly, stating intermediate results. "
            "Ensure unit consistency and verify each step logically."
        )
        solution_steps = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Verify and refine the solution
        verification_instruction = (
            f"Verify the solution: {solution_steps} against the original problem: {self.problem_text}. "
            "Check for unit consistency, logical constraints, and contextual appropriateness. "
            "Refine the solution if inconsistencies or ambiguities are found."
        )
        refined_solution = await self.revise(instruction=verification_instruction, context=solution_steps)

        # Step 5: Summarize the final answer
        summarization_instruction = (
            f"Summarize the final solution: {refined_solution} into a single numerical value. "
            "Ensure the answer is concise and matches the problem's requirements."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_solution)

        return final_answer