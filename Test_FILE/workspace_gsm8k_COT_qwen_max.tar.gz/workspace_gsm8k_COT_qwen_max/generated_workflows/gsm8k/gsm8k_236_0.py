# Workflow ID: gsm8k_236_0
# Benchmark: gsm8k
# Data Indices: [107, 251]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant numerical values, units, and relationships
        extraction_instruction = """
        Carefully analyze the problem and extract all numerical values, units, and relationships.
        Identify any constraints or conditions mentioned in the problem.
        Organize the extracted information in a structured format for further processing.
        """
        extracted_data = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Create a mathematical model and plan the solution
        modeling_instruction = f"""
        Based on the following extracted information: {extracted_data}
        Develop a step-by-step plan to solve the problem mathematically.
        Include all necessary intermediate steps, even if they are not explicitly stated in the problem.
        Ensure the plan accounts for proper order of operations, unit consistency, and real-world constraints.
        """
        solution_plan = await self.generate(instruction=modeling_instruction, context=self.problem_text)

        # Step 3: Perform sequential calculations
        calculation_instruction = f"""
        Execute the following solution plan step-by-step: {solution_plan}
        Perform all calculations carefully, showing intermediate results at each step.
        Ensure that units are tracked consistently throughout the process.
        """
        calculated_results = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Verify and refine the solution
        refinement_instruction = f"""
        Review the following calculated results: {calculated_results}
        Check for any errors, inconsistencies, or violations of real-world constraints.
        Refine the solution if necessary, ensuring it makes sense in the context of the problem.
        """
        refined_solution = await self.revise(instruction=refinement_instruction, context=calculated_results)

        # Step 5: Extract the final answer
        summarization_instruction = """
        Extract the final numerical answer from the refined solution.
        Ensure the answer is formatted as a single integer or decimal value.
        """
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_solution)

        return final_answer