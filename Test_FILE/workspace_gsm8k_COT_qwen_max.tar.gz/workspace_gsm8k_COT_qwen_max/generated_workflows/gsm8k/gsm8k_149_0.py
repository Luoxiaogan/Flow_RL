# Workflow ID: gsm8k_149_0
# Benchmark: gsm8k
# Data Indices: [49, 672]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract all numerical values, relationships, and constraints
        extraction_instruction = """
        Carefully analyze the problem and extract all numerical values, relationships, and constraints.
        Include any hidden steps or intermediate calculations implied by the problem.
        Format the output as a structured list of key-value pairs or equations.
        """
        extracted_data = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Perform step-by-step calculations based on the extracted data
        calculation_instruction = f"""
        Using the extracted information: {extracted_data}
        Perform step-by-step calculations to solve the problem.
        Clearly show all intermediate results and ensure they align with the problem's context.
        Handle units consistently and apply any necessary real-world constraints.
        """
        calculations = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 3: Validate and refine the solution
        refinement_instruction = """
        Review the calculations and ensure they align with the problem's context and constraints.
        Correct any errors, fill in missing steps, and verify the logical consistency of the solution.
        """
        refined_solution = await self.revise(instruction=refinement_instruction, context=calculations)

        # Step 4: Summarize the final answer
        summary_instruction = """
        Condense the solution into a single numerical value representing the final answer.
        Ensure the answer is clear, precise, and makes sense in the context of the problem.
        """
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer