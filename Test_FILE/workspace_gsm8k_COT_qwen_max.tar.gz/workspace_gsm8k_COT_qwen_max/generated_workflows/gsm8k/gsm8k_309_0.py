# Workflow ID: gsm8k_309_0
# Benchmark: gsm8k
# Data Indices: [187, 216]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract known values and relationships
        extraction_instruction = """
        Carefully analyze the problem and extract all numerical values, units, and relationships.
        Identify any explicit or implicit constraints and describe how they relate to each other.
        Provide the extracted information in a structured format, such as a list or bullet points.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Translate problem into mathematical steps
        translation_instruction = f"""
        Based on the following extracted information:
        {extracted_info}

        Translate the problem into a sequence of mathematical operations.
        Clearly specify the order of operations, intermediate calculations, and any unit conversions required.
        If there are multiple steps, describe them chronologically and explain how they build on each other.
        """
        steps = await self.generate(instruction=translation_instruction, context=self.problem_text)

        # Step 3: Perform calculations (parallelize where possible)
        calculation_instruction = f"""
        Using the following step-by-step breakdown:
        {steps}

        Perform the calculations required to solve the problem.
        Ensure that all intermediate results are explicitly stated and labeled.
        Pay close attention to units and ensure consistency throughout.
        """
        # Parallelize independent calculations if applicable
        calculation_results = await asyncio.gather(
            self.generate(instruction=calculation_instruction, context=self.problem_text),
            self.generate(instruction=calculation_instruction, context=self.problem_text)  # Additional parallel tasks if needed
        )

        # Step 4: Combine intermediate results using Ensemble
        ensemble_instruction = f"""
        Evaluate the following calculation results:
        {calculation_results}

        Combine them into a single coherent solution, ensuring consistency and correctness.
        Resolve any discrepancies between the results and provide the final calculated value.
        """
        combined_result = await self.ensemble(instruction=ensemble_instruction, contexts=calculation_results)

        # Step 5: Validate and refine the result
        refinement_instruction = f"""
        Critique the following result:
        {combined_result}

        Check for any errors, inconsistencies, or unrealistic values.
        Ensure the answer makes sense in the context of the problem and adheres to any constraints.
        Refine the result if necessary and provide the corrected value.
        """
        refined_result = await self.revise(instruction=refinement_instruction, context=combined_result)

        # Step 6: Summarize the final answer
        summary_instruction = f"""
        Condense the following refined result into a single numerical value:
        {refined_result}

        Ensure the final answer is clear, concise, and includes appropriate units if necessary.
        """
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_result)

        return final_answer