# Workflow ID: gsm8k_246_0
# Benchmark: gsm8k
# Data Indices: [732, 779]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem text
        extraction_instruction = (
            "Extract all numerical values, units, and relationships described in the problem. "
            "Identify what is being asked and list all relevant information explicitly. "
            "If there are implicit operations or hidden steps, infer and include them."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a step-by-step solution strategy
        strategy_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. "
            "Specify the order of operations, intermediate calculations, and how to handle units. "
            "Ensure the strategy accounts for all constraints and contextual factors."
        )
        solution_strategy = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Perform the calculations
        calculation_instruction = (
            f"Follow this solution strategy step by step:\n{solution_strategy}\n"
            "Perform all calculations explicitly, showing intermediate results. "
            "Track units throughout and ensure all operations are mathematically valid."
        )
        calculations = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Validate and refine the solution
        validation_instruction = (
            f"Review the following calculations and final result:\n{calculations}\n"
            "Check for correctness, unit consistency, and logical coherence. "
            "Refine the solution if necessary, correcting any errors or inconsistencies."
        )
        refined_solution = await self.revise(instruction=validation_instruction, context=calculations)

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"From the refined solution:\n{refined_solution}\n"
            "Extract and present the final numerical answer clearly. "
            "Ensure the answer is concise and matches the problem's requirements."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer