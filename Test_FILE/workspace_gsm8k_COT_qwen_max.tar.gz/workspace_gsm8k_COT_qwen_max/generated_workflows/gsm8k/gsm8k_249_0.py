# Workflow ID: gsm8k_249_0
# Benchmark: gsm8k
# Data Indices: [489, 192]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio
        
        # Step 1: Extract known information
        extraction_instruction = (
            "Extract all numerical values, units, and relationships from the problem. "
            "Include any explicit or implicit constraints. "
            "Format the output as a structured list of key-value pairs."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)
        
        # Step 2: Identify problem type and strategy
        strategy_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Identify the type of problem (e.g., sequential operations, rate problems, proportional reasoning). "
            "Describe the mathematical strategy required to solve the problem, including the order of operations. "
            "If there are multiple possible strategies, list them all."
        )
        strategy = await self.generate(instruction=strategy_instruction, context=self.problem_text)
        
        # Step 3: Perform step-by-step calculations
        calculation_instruction = (
            f"Using the extracted information:\n{extracted_info}\n"
            f"And the identified strategy:\n{strategy}\n"
            "Perform the calculations step by step. "
            "Ensure unit consistency and track intermediate results. "
            "If there are multiple strategies, calculate using each approach in parallel."
        )
        # Parallel execution for multiple strategies
        strategies = strategy.split("\n")  # Split strategies into a list
        calculation_tasks = [
            self.generate(instruction=f"{calculation_instruction}\nFocus on this strategy: {s}", context=self.problem_text)
            for s in strategies
        ]
        calculation_results = await asyncio.gather(*calculation_tasks)
        
        # Step 4: Validate intermediate results
        validation_instruction = (
            "Review the following calculations and validate their correctness. "
            "Flag any inconsistencies, such as negative numbers where they don't make sense or fractional units for discrete quantities. "
            "Provide corrections if necessary."
        )
        validation_tasks = [
            self.revise(instruction=validation_instruction, context=result)
            for result in calculation_results
        ]
        validated_results = await asyncio.gather(*validation_tasks)
        
        # Step 5: Select the best solution (if multiple approaches)
        if len(validated_results) > 1:
            ensemble_instruction = (
                "Compare the following solutions and select the best one based on accuracy, completeness, and adherence to the problem constraints. "
                "If solutions are equivalent, choose the most straightforward one."
            )
            final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=validated_results)
        else:
            final_solution = validated_results[0]
        
        # Step 6: Summarize the solution
        summary_instruction = (
            "Summarize the solution in a concise format. "
            "Include the final answer, intermediate results, and any key insights. "
            "Ensure the final answer is clearly labeled and formatted as a single numerical value."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=final_solution)
        
        return final_summary