# Workflow ID: gsm8k_320_0
# Benchmark: gsm8k
# Data Indices: [603, 782]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information (numerical values, relationships, question)
        extraction_instruction = (
            "Extract all numerical values, relationships (e.g., ratios, proportions), "
            "and the specific question being asked. Organize the information clearly."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Model the problem mathematically
        modeling_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Translate the problem into a mathematical representation. "
            "Identify variables, equations, and any intermediate steps required. "
            "Ensure units are consistent and all calculations are logically sequenced."
        )
        mathematical_model = await self.generate(instruction=modeling_instruction, context=self.problem_text)

        # Step 3: Perform calculations (parallel execution for efficiency)
        calculation_instruction_1 = (
            f"Based on the mathematical model: {mathematical_model}\n"
            "Perform the first set of calculations step-by-step. "
            "Show intermediate results and ensure accuracy."
        )
        calculation_instruction_2 = (
            f"Based on the mathematical model: {mathematical_model}\n"
            "Perform an alternative set of calculations step-by-step. "
            "Cross-check results for consistency."
        )
        calculation_results = await asyncio.gather(
            self.generate(instruction=calculation_instruction_1, context=self.problem_text),
            self.generate(instruction=calculation_instruction_2, context=self.problem_text)
        )

        # Step 4: Select the best result using Ensemble
        ensemble_instruction = (
            "Evaluate the two sets of calculations provided. "
            "Select the most accurate and consistent result. "
            "If discrepancies exist, resolve them and provide a final answer."
        )
        final_calculation = await self.ensemble(instruction=ensemble_instruction, contexts=calculation_results)

        # Step 5: Verify the solution
        verification_instruction = (
            f"Review the final calculation: {final_calculation}\n"
            "Ensure the solution is accurate, contextually valid, and adheres to real-world constraints. "
            "Critique any potential errors or inconsistencies."
        )
        verified_solution = await self.revise(instruction=verification_instruction, context=final_calculation)

        # Step 6: Summarize the final result
        summary_instruction = (
            f"Condense the verified solution: {verified_solution}\n"
            "Provide the final numerical answer in a clear and concise format."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=verified_solution)

        return final_answer