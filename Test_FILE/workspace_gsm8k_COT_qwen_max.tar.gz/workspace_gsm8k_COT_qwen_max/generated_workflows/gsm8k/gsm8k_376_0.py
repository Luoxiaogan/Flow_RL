# Workflow ID: gsm8k_376_0
# Benchmark: gsm8k
# Data Indices: [669, 156]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract numerical values, relationships, and problem type
        extraction_instruction = (
            "Extract all numerical values, relationships, and key details from the problem. "
            "Identify the type of problem (e.g., sequential operations, rate problems) and note any implicit steps required. "
            "Ensure units and constraints are clearly specified."
        )
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate a step-by-step solution
        solution_instruction = (
            f"Given the extracted information: {extraction}, "
            "solve the problem step by step. Follow mathematical rules, maintain unit consistency, and handle constraints like non-negative results. "
            "Provide intermediate results and ensure the final answer matches the question's requirements."
        )
        solution = await self.generate(instruction=solution_instruction, context=self.problem_text)

        # Step 3: Validate and refine the solution
        refinement_instruction = (
            "Critique and refine the provided solution. Verify calculations, ensure logical consistency, and check whether the final answer matches the question's requirements. "
            "If there are errors, correct them and provide an improved solution."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=solution)

        # Step 4: Extract the final numerical answer
        summarization_instruction = (
            "Extract the final numerical answer from the refined solution. Ensure the output is concise and formatted as a single number without additional text."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_solution)

        return final_answer