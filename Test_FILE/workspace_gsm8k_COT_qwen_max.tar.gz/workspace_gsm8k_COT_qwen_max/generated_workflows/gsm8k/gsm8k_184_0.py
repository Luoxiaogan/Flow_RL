# Workflow ID: gsm8k_184_0
# Benchmark: gsm8k
# Data Indices: [359, 130]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all numerical values, units, relationships, and constraints from the problem. "
            "Identify what is being asked and any intermediate steps required to solve the problem. "
            "Format the output as a structured list for clarity."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate a step-by-step solution
        solution_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem step by step. "
            "Ensure all calculations are shown, intermediate results are clearly stated, and units are consistent. "
            "Verify that the solution makes sense in the context of the problem. "
            "Provide the final answer as a single numerical value at the end."
        )
        solution = await self.generate(instruction=solution_instruction, context=self.problem_text)

        # Step 3: Validate and refine the solution
        refinement_instruction = (
            "Critique the provided solution. Check for logical consistency, calculation accuracy, "
            "and adherence to the problem's constraints. If there are errors or ambiguities, revise the solution accordingly."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=solution)

        # Step 4: Summarize the solution
        summary_instruction = (
            "Summarize the solution concisely while preserving all key details. "
            "Include the final numerical answer prominently."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_summary