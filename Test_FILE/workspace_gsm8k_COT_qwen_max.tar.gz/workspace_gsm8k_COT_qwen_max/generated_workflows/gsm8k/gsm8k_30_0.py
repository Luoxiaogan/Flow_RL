# Workflow ID: gsm8k_30_0
# Benchmark: gsm8k
# Data Indices: [375, 670]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem text
        extraction_instruction = (
            "Extract all numerical values, units, relationships, and constraints from the problem. "
            "Organize the information into categories such as 'given values', 'unknowns', 'units', "
            "and 'operations'. Ensure the extracted data is comprehensive and unambiguous."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Develop a step-by-step solution plan
        modeling_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Create a step-by-step plan to solve the problem. Include all intermediate calculations, "
            "unit conversions, and logical reasoning. Ensure the plan is chronological and accounts "
            "for all constraints and relationships."
        )
        solution_plan = await self.generate(instruction=modeling_instruction, context=self.problem_text)

        # Step 3: Execute intermediate calculations in parallel
        calculation_instruction_template = (
            "Perform the following calculation step:\n{{step}}\n"
            "Ensure the result is accurate and includes proper units if applicable."
        )
        steps = solution_plan.split("\n")  # Assuming steps are separated by newlines
        calculation_tasks = [
            self.generate(instruction=calculation_instruction_template.replace("{{step}}", step), context=self.problem_text)
            for step in steps if step.strip()
        ]
        intermediate_results = await asyncio.gather(*calculation_tasks)

        # Step 4: Validate and synthesize the final answer
        validation_instruction = (
            "Given the following intermediate results:\n" + "\n".join(intermediate_results) + "\n"
            "Validate the results against the problem context. Ensure all steps are consistent, "
            "units are correct, and the final answer makes sense. Synthesize the final numerical answer."
        )
        final_answer = await self.ensemble(instruction=validation_instruction, contexts=intermediate_results)

        # Step 5: Format the final output
        formatting_instruction = (
            "Condense the following result into a single numerical value (integer or decimal):\n" + final_answer
        )
        formatted_answer = await self.summarize(instruction=formatting_instruction, context=final_answer)

        return formatted_answer