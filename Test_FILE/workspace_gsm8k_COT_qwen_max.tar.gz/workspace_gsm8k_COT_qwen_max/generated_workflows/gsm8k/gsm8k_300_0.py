# Workflow ID: gsm8k_300_0
# Benchmark: gsm8k
# Data Indices: [3, 207]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract known information and problem structure
        extraction_instruction = (
            "Extract all numerical values, units, relationships, and constraints from the problem. "
            "Identify what is known and what needs to be calculated. "
            "Provide a detailed breakdown of the problem's components."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan the solution approach
        planning_instruction = (
            f"Based on the following extracted information: {extracted_info} "
            "Create a step-by-step plan to solve the problem. "
            "Include intermediate calculations, order of operations, and any hidden steps. "
            "Ensure the plan accounts for unit consistency and contextual constraints."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Execute the solution plan
        execution_instruction = (
            f"Follow this solution plan step by step: {solution_plan} "
            "Perform all calculations systematically. "
            "Verify each step against the original problem to ensure correctness."
        )
        executed_solution = await self.generate(instruction=execution_instruction, context=self.problem_text)

        # Step 4: Refine and verify the solution
        refinement_instruction = (
            f"Review the following solution: {executed_solution} "
            "Critique and refine it to address any errors or ambiguities. "
            "Ensure the final answer makes sense in the context of the problem."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=executed_solution)

        # Step 5: Summarize the final answer
        summarization_instruction = (
            "Condense the solution into a single numerical value. "
            "Ensure the answer is presented in the required format."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_solution)

        return final_answer