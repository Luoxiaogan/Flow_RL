# Workflow ID: gsm8k_8_0
# Benchmark: gsm8k
# Data Indices: [337, 120]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Thoroughly analyze the problem statement to extract all numerical values, "
            "relationships, constraints, and the specific question being asked. "
            "Format the output clearly and label each piece of information."
        )
        key_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan the solution based on the extracted information
        planning_instruction = (
            f"Based on the following extracted information:\n{key_info}\n"
            "Devise a detailed step-by-step plan to solve the problem. "
            "Include all necessary calculations, intermediate steps, and unit handling. "
            "Ensure the plan is logically ordered and accounts for any hidden steps."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Execute the calculations according to the plan
        execution_instruction = (
            f"Follow the solution plan below step by step to compute the final answer:\n{solution_plan}\n"
            "Perform each calculation carefully and document the intermediate results. "
            "Ensure consistency in units and logical progression."
        )
        calculations = await self.generate(instruction=execution_instruction, context=self.problem_text)

        # Step 4: Verify and refine the solution
        verification_instruction = (
            f"Review the following calculations and solution plan:\n{calculations}\n"
            "Critique the solution for accuracy, logical consistency, and alignment with the problem context. "
            "Refine the solution if necessary, providing corrections or clarifications."
        )
        refined_solution = await self.revise(instruction=verification_instruction, context=calculations)

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"Summarize the final result from the following refined solution:\n{refined_solution}\n"
            "Provide only the numerical answer to the problem, ensuring it is clear and concise."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer