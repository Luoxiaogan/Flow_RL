# Workflow ID: gsm8k_256_0
# Benchmark: gsm8k
# Data Indices: [22, 795]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract knowns, unknowns, relationships, and constraints
        extraction_instruction = (
            "Carefully analyze the problem and extract all relevant information. "
            "Provide the following sections explicitly:\n"
            "- Known Values: List all numerical values and their associated units.\n"
            "- Unknowns: Clearly state what needs to be solved or calculated.\n"
            "- Relationships: Describe any mathematical relationships or constraints mentioned in the problem.\n"
            "- Constraints: Note any real-world limitations or conditions that must be satisfied."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan the solution approach
        planning_instruction = (
            f"Based on the extracted information:\n{extracted_info}\n"
            "Devise a step-by-step plan to solve the problem. Include:\n"
            "- Intermediate calculations needed.\n"
            "- The order of operations.\n"
            "- Any assumptions or simplifications made.\n"
            "Ensure the plan is detailed and leaves no ambiguity."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Execute calculations in parallel
        # Parse the solution plan to identify independent steps
        execution_instruction_template = (
            "Perform the following calculation based on the problem and extracted information:\n"
            "{calculation_details}\n"
            "Provide the result with appropriate units and intermediate reasoning."
        )
        calculations = ["Step 1", "Step 2", "Step 3"]  # Placeholder for actual steps parsed from solution_plan
        tasks = [
            self.generate(instruction=execution_instruction_template.format(calculation_details=step), context=self.problem_text)
            for step in calculations
        ]
        results = await asyncio.gather(*tasks)

        # Step 4: Synthesize results
        synthesis_instruction = (
            "Combine the following results into a coherent final solution:\n"
            f"{results}\n"
            "Ensure consistency, resolve any conflicts, and verify unit correctness."
        )
        synthesized_result = await self.ensemble(instruction=synthesis_instruction, contexts=results)

        # Step 5: Validate and refine the solution
        validation_instruction = (
            "Critique the following solution and refine it if necessary:\n"
            f"{synthesized_result}\n"
            "Check for:\n"
            "- Reasonableness of the result in the problem's context.\n"
            "- Adherence to real-world constraints (e.g., non-negative quantities).\n"
            "- Correctness of units and decimal places."
        )
        refined_solution = await self.revise(instruction=validation_instruction, context=synthesized_result)

        # Step 6: Summarize the final answer
        summarization_instruction = (
            "Extract the final numerical answer from the following solution:\n"
            f"{refined_solution}\n"
            "Ensure the answer is presented as a single number with appropriate precision."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_solution)

        return final_answer