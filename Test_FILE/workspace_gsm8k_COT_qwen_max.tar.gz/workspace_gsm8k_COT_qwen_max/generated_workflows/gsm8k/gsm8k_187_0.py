# Workflow ID: gsm8k_187_0
# Benchmark: gsm8k
# Data Indices: [769, 34]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key numerical values, units, and contextual clues
        extraction_instruction = (
            "Extract all numerical values, units, and contextual clues from the problem. "
            "Organize them in a structured format, labeling each piece of information clearly. "
            "Ensure you capture time-based elements (e.g., 'a day', 'a week') and relationships (e.g., 'evenly split')."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a mathematical model
        model_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Translate the problem into a mathematical model. "
            "Identify the sequence of operations required to solve the problem, including any necessary unit conversions. "
            "Explain each step clearly and justify why it is needed."
        )
        mathematical_model = await self.generate(instruction=model_instruction, context=self.problem_text)

        # Step 3: Perform calculations step-by-step
        calculation_instruction = (
            f"Using the mathematical model below:\n{mathematical_model}\n"
            "Perform the calculations step-by-step. Show all intermediate results and verify their correctness. "
            "Ensure units are consistent throughout the process."
        )
        calculated_result = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Validate and refine the solution
        refinement_instruction = (
            f"Review the following solution:\n{calculated_result}\n"
            "Check if it satisfies the problem's constraints and makes sense in the real-world context. "
            "Refine the solution if necessary, ensuring no logical errors or inconsistencies exist."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=calculated_result)

        # Step 5: Summarize the final answer
        summary_instruction = (
            "Condense the final solution into a single numerical value with appropriate units. "
            "Ensure the answer is clear and concise."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer