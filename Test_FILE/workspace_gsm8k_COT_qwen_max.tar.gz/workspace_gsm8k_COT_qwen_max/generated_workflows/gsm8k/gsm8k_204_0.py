# Workflow ID: gsm8k_204_0
# Benchmark: gsm8k
# Data Indices: [380, 5]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information (numerical values, relationships, constraints)
        extraction_instruction = (
            "Extract all numerical values, units, and relationships from the problem. "
            "Identify what is being asked and any constraints (e.g., time-based, unit consistency). "
            "Format the output as a structured list of key-value pairs."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Compute intermediate results and solve step-by-step
        computation_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem step-by-step. "
            "Ensure all calculations are explicitly shown, including intermediate results. "
            "Handle units consistently and verify the logical sequence of operations."
        )
        solution = await self.generate(instruction=computation_instruction, context=self.problem_text)

        # Step 3: Verify and refine the solution
        refinement_instruction = (
            "Critique the provided solution for accuracy and adherence to the problem context. "
            "Check for unit consistency, logical correctness, and real-world constraints (e.g., no negative values). "
            "Suggest improvements if necessary."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=solution)

        # Step 4: Summarize the final answer
        summary_instruction = (
            "Summarize the final answer clearly and concisely. "
            "Ensure the output is a single numerical value (integer or decimal) that directly answers the question."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer