# Workflow ID: gsm8k_125_0
# Benchmark: gsm8k
# Data Indices: [686, 636]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract known information (numerical values, relationships, entities)
        extract_instruction = (
            "Extract all numerical values, relationships (e.g., 'heavier than', 'lighter than'), "
            "and entities mentioned in the problem. Organize them clearly, specifying units if applicable."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Formulate a step-by-step solution plan
        plan_instruction = (
            f"Based on the following extracted information: {extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. "
            "Include all necessary calculations, intermediate steps, and unit conversions."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Perform calculations step-by-step
        calculate_instruction = (
            f"Follow this solution plan: {solution_plan}\n"
            "Perform each calculation step-by-step, showing all intermediate results. "
            "Ensure unit consistency and verify each step logically follows from the previous one."
        )
        calculations = await self.generate(instruction=calculate_instruction, context=self.problem_text)

        # Step 4: Validate intermediate results
        validate_instruction = (
            f"Review the following calculations: {calculations}\n"
            "Critique and refine them to ensure accuracy and consistency with the problem's context. "
            "Correct any errors and explain your reasoning."
        )
        validated_calculations = await self.revise(instruction=validate_instruction, context=calculations)

        # Step 5: Compute the final answer
        final_instruction = (
            f"Using the validated calculations: {validated_calculations}\n"
            "Compute the final answer to the problem. Ensure the result is a single numerical value "
            "and makes sense in the context of the problem."
        )
        final_answer = await self.generate(instruction=final_instruction, context=self.problem_text)

        return final_answer