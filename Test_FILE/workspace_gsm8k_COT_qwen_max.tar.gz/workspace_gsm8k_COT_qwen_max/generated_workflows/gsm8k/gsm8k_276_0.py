# Workflow ID: gsm8k_276_0
# Benchmark: gsm8k
# Data Indices: [329, 644]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, units, and relationships. "
            "Identify what is being asked and list the known quantities and unknowns. "
            "Provide the extracted information in a structured format."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Translate the problem into mathematical steps
        translation_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Translate the problem into a series of mathematical operations. "
            "Clearly define each step required to solve the problem, including intermediate calculations. "
            "Ensure the steps are logically ordered and consistent with the problem context."
        )
        math_steps = await self.generate(instruction=translation_instruction, context=self.problem_text)

        # Step 3: Perform the calculations step-by-step
        calculation_instruction = (
            f"Given the mathematical steps: {math_steps}\n"
            "Perform the calculations step-by-step. Show all intermediate results and ensure accuracy. "
            "If there are multiple steps, proceed chronologically and verify each result before moving to the next step."
        )
        calculations = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Verify the solution for consistency and correctness
        verification_instruction = (
            f"Review the calculations: {calculations}\n"
            "Critically evaluate the solution to ensure it makes sense in the context of the problem. "
            "Check for unit consistency, adherence to constraints (e.g., no negative quantities), and logical coherence. "
            "If any issues are found, suggest corrections or improvements."
        )
        verified_solution = await self.revise(instruction=verification_instruction, context=calculations)

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"Condense the verified solution: {verified_solution}\n"
            "Provide a concise summary of the reasoning process and the final answer. "
            "Ensure the answer is a single numerical value (integer or decimal) and clearly state it."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=verified_solution)

        return final_answer