# Workflow ID: gsm8k_94_0
# Benchmark: gsm8k
# Data Indices: [331, 265]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key numerical values, relationships, and constraints
        extraction_instruction = (
            "Thoroughly analyze the problem and extract all numerical values, "
            "relationships between entities, and any constraints mentioned explicitly or implicitly. "
            "Label each extracted component clearly for reference in subsequent steps."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a step-by-step calculation plan
        plan_instruction = (
            f"Using the following extracted information: {extracted_info}, "
            "create a detailed step-by-step plan to solve the problem. "
            "Include all necessary intermediate calculations, specify the order of operations, "
            "and ensure all units and constraints are accounted for."
        )
        calculation_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Explore parallel solution paths
        path1_instruction = (
            f"Follow this calculation plan: {calculation_plan}. "
            "Solve the problem step by step, ensuring all reasoning is explicit and verifiable. "
            "Provide the final numerical answer at the end."
        )
        path2_instruction = (
            f"Analyze the problem independently of the given plan: {calculation_plan}. "
            "Identify any alternative approaches or interpretations, and solve the problem accordingly. "
            "Ensure the reasoning is logical and consistent with the problem context."
        )
        results = await asyncio.gather(
            self.generate(instruction=path1_instruction, context=self.problem_text),
            self.generate(instruction=path2_instruction, context=self.problem_text)
        )

        # Step 4: Synthesize the best solution
        synthesis_instruction = (
            "Evaluate the following candidate solutions and select the most accurate and robust one. "
            "If both solutions are valid, synthesize them into a single improved solution. "
            "Ensure the final result adheres to the problem constraints and provides a clear numerical answer."
        )
        best_solution = await self.ensemble(instruction=synthesis_instruction, contexts=results)

        # Step 5: Refine the selected solution
        refinement_instruction = (
            "Critically review the following solution and refine it for accuracy, clarity, and correctness. "
            "Verify that all calculations are precise, units are consistent, and the answer makes sense in context."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 6: Summarize the final answer
        summary_instruction = (
            "Condense the following solution into a concise statement containing only the final numerical answer. "
            "Ensure the output is a single number (integer or decimal) without additional explanations."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer