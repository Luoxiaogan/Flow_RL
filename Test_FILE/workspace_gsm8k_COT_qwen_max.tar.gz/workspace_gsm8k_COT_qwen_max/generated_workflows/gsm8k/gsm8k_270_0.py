# Workflow ID: gsm8k_270_0
# Benchmark: gsm8k
# Data Indices: [727, 215]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all numerical values, relationships, and key entities
        extraction_instruction = (
            "Extract all numerical values, relationships, and key entities from the problem. "
            "Include units (if any), relationships (e.g., 'fewer than', 'twice as many'), "
            "and any constraints (e.g., non-negative quantities). Format the output as a structured list."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Create a step-by-step solution plan
        planning_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. Include all calculations, "
            "intermediate results, and logical reasoning. Ensure the plan is chronological and handles units consistently."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Perform calculations in parallel where possible
        calculation_instruction_template = (
            "Perform the following calculation step: {step}. "
            "Ensure the result is accurate and includes appropriate units. "
            "If intermediate results are needed, use the provided context."
        )

        # Split the solution plan into individual steps
        steps = solution_plan.split("\n")
        calculation_tasks = [
            self.generate(instruction=calculation_instruction_template.format(step=step), context=self.problem_text)
            for step in steps if step.strip()
        ]
        intermediate_results = await asyncio.gather(*calculation_tasks)

        # Step 4: Validate and refine intermediate results
        refinement_instruction = (
            "Review the intermediate results and ensure they are accurate. "
            "Check for consistency in units, logical correctness, and adherence to constraints (e.g., non-negative values). "
            "Refine any incorrect or ambiguous results."
        )
        refined_results = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction, context=result) for result in intermediate_results]
        )

        # Step 5: Synthesize the final answer
        synthesis_instruction = (
            "Combine the refined intermediate results to compute the final answer. "
            "Ensure the answer is a single numerical value (integer or decimal) and makes sense in the context of the problem. "
            "Include a brief explanation of how the answer was derived."
        )
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=refined_results)

        return final_answer