# Workflow ID: gsm8k_291_0
# Benchmark: gsm8k
# Data Indices: [14, 598]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information
        extraction_instruction = (
            "Thoroughly analyze the problem and extract all relevant information. "
            "This includes known numerical values, relationships between quantities, "
            "constraints, and the specific question being asked. Format the output as follows:\n"
            "- Known Values: [list them]\n"
            "- Relationships: [describe them]\n"
            "- Constraints: [list them]\n"
            "- Question: [state the question]"
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Mathematical modeling
        modeling_instruction = (
            f"Based on the extracted information:\n{extracted_info}\n"
            "Translate the problem into a mathematical model. Identify all necessary equations, "
            "intermediate calculations, and steps required to solve the problem. Ensure that "
            "unit consistency is maintained throughout. Provide the model as a step-by-step plan."
        )
        mathematical_model = await self.generate(instruction=modeling_instruction, context=self.problem_text)

        # Step 3: Sequential calculation and refinement
        calculation_instruction = (
            f"Follow the mathematical model:\n{mathematical_model}\n"
            "Perform the calculations step by step. For each step, provide the intermediate result "
            "and ensure it is correct before proceeding to the next step. If there are multiple "
            "independent calculations, execute them in parallel."
        )
        calculations = await asyncio.gather(
            self.generate(instruction=calculation_instruction, context=self.problem_text),
            self.generate(instruction=calculation_instruction, context=self.problem_text)
        )
        refined_results = await asyncio.gather(
            self.revise(instruction="Critique and refine the following calculation:", context=calculations[0]),
            self.revise(instruction="Critique and refine the following calculation:", context=calculations[1])
        )

        # Step 4: Final answer and contextual validation
        final_instruction = (
            f"Given the refined results:\n{refined_results}\n"
            "Compute the final answer to the problem. Ensure that the answer makes sense in the "
            "context of the problem, adheres to any constraints, and is numerically plausible. "
            "Provide the final answer as a single numerical value."
        )
        final_answer = await self.generate(instruction=final_instruction, context=self.problem_text)

        # Summarize the solution
        summary_instruction = (
            f"Summarize the solution process and the final answer:\n{final_answer}\n"
            "Ensure the summary is clear, concise, and highlights the key steps and reasoning."
        )
        summary = await self.summarize(instruction=summary_instruction, context=self.problem_text)

        # Synthesize multiple approaches if needed
        ensemble_instruction = (
            "Evaluate the following approaches and select the best solution:\n"
            f"Approach 1: {refined_results[0]}\n"
            f"Approach 2: {refined_results[1]}"
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_results)

        return final_solution