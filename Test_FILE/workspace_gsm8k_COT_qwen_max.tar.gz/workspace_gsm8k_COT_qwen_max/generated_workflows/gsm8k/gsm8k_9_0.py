# Workflow ID: gsm8k_9_0
# Benchmark: gsm8k
# Data Indices: [572, 87]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all numerical values, units, and relationships
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, units, and relationships mentioned. "
            "Include any implied operations (e.g., multiplication, division) and ensure you capture all relevant details. "
            "Format the output as a structured list for clarity."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Perform intermediate calculations in parallel
        intermediate_instruction_template = (
            f"Given the extracted information: {extracted_info}, "
            "perform the necessary intermediate calculations to simplify the problem. "
            "Clearly show your work and include intermediate results. "
            "Ensure unit conversions are handled appropriately if needed."
        )
        # Generate multiple intermediate calculation paths
        calc1 = self.generate(instruction=intermediate_instruction_template + " Focus on addition and subtraction.", context=extracted_info)
        calc2 = self.generate(instruction=intermediate_instruction_template + " Focus on multiplication and division.", context=extracted_info)
        calc3 = self.generate(instruction=intermediate_instruction_template + " Handle unit conversions if applicable.", context=extracted_info)
        intermediate_results = await asyncio.gather(calc1, calc2, calc3)

        # Step 3: Combine intermediate results and compute the final answer
        combine_instruction = (
            f"Using the following intermediate results: {intermediate_results}, "
            "combine them to solve the original problem. Ensure the sequence of operations is correct and verify unit consistency. "
            "Provide the final answer as a single numerical value with appropriate units."
        )
        final_answer = await self.generate(instruction=combine_instruction, context=self.problem_text)

        # Step 4: Revise the solution for correctness and clarity
        revise_instruction = (
            f"Review the final solution: {final_answer}. "
            "Check for logical consistency, proper handling of units, and alignment with the problem's context. "
            "Make corrections if necessary and ensure the answer is clear and concise."
        )
        revised_solution = await self.revise(instruction=revise_instruction, context=final_answer)

        # Step 5: Summarize the solution
        summary_instruction = (
            "Condense the solution into a concise summary that includes the final numerical answer. "
            "Ensure the summary is easy to understand and highlights the key steps."
        )
        summary = await self.summarize(instruction=summary_instruction, context=revised_solution)

        return summary