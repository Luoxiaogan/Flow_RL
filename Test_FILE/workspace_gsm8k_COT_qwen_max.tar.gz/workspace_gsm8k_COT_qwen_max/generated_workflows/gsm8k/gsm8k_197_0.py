# Workflow ID: gsm8k_197_0
# Benchmark: gsm8k
# Data Indices: [63, 290]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information
        extraction_instruction = (
            "Extract all numerical values, relationships, and entities mentioned in the problem. "
            "Identify operations (addition, subtraction, multiplication, division), units, and constraints. "
            "Format the output as a structured summary."
        )
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Construct a mathematical model
        modeling_instruction = (
            f"Based on the following extracted information: {extraction}\n"
            "Construct a mathematical model to solve the problem. Identify the sequence of operations, "
            "intermediate calculations, and the final goal. Ensure units and constraints are handled correctly."
        )
        model = await self.generate(instruction=modeling_instruction, context=self.problem_text)

        # Step 3: Generate parallel solution approaches
        direct_calculation_instruction = (
            f"Using the mathematical model: {model}\n"
            "Solve the problem step-by-step using direct calculations. Show intermediate results and ensure "
            "logical consistency."
        )
        algebraic_reasoning_instruction = (
            f"Using the mathematical model: {model}\n"
            "Solve the problem using algebraic reasoning. Define variables, set up equations, and solve systematically."
        )
        results = await asyncio.gather(
            self.generate(instruction=direct_calculation_instruction, context=self.problem_text),
            self.generate(instruction=algebraic_reasoning_instruction, context=self.problem_text)
        )

        # Step 4: Select the best solution
        ensemble_instruction = (
            "Compare the following solutions and select the best one. Criteria include logical consistency, "
            "adherence to the problem context, and numerical accuracy. Provide the final answer."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 5: Verify the solution
        verification_instruction = (
            f"Verify the following solution against the original problem: {final_solution}\n"
            "Ensure the answer is correct, makes sense in context, and adheres to any constraints. "
            "Revise if necessary."
        )
        verified_solution = await self.revise(instruction=verification_instruction, context=self.problem_text)

        # Step 6: Summarize the final answer
        summarization_instruction = (
            f"Condense the following verified solution into a concise format: {verified_solution}\n"
            "Ensure clarity and precision in the final output."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=self.problem_text)

        return final_answer