# Workflow ID: gsm8k_368_0
# Benchmark: gsm8k
# Data Indices: [335, 783]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (numerical values, relationships, constraints)
        extraction_instruction = (
            "Identify all numerical values, relationships, and constraints in the problem. "
            "Format the output as a structured list or table for clarity."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a solution plan
        plan_instruction = (
            f"Based on the following extracted information: {extracted_info} "
            "Devise a step-by-step plan to solve the problem. Include all intermediate calculations "
            "and ensure logical consistency between steps."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute calculations
        calculation_instruction = (
            f"Follow this solution plan: {solution_plan} "
            "Perform the necessary calculations step by step. Ensure intermediate results are clearly stated."
        )
        calculations = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Validate and refine results
        validation_instruction = (
            f"Review the following calculations: {calculations} "
            "Check for accuracy, unit consistency, and logical coherence. Suggest improvements if necessary."
        )
        refined_results = await self.revise(instruction=validation_instruction, context=calculations)

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"Condense the following refined results: {refined_results} "
            "Provide the final numerical answer in a clear and concise format."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_results)

        return final_answer