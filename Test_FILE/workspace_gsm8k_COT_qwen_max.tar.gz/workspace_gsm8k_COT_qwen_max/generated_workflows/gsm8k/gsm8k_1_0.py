# Workflow ID: gsm8k_1_0
# Benchmark: gsm8k
# Data Indices: [635, 437]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract known information (numerical values, units, relationships)
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, units, "
            "relationships, and constraints. Organize the extracted information into "
            "a structured format, including any implicit information such as rates or totals."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a solution plan (sequence of calculations)
        planning_instruction = (
            f"Using the following extracted information: {extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. Include all intermediate "
            "calculations, specify the order of operations, and ensure unit consistency throughout. "
            "If there are multiple possible approaches, describe each one."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Execute calculations (parallelize independent steps if possible)
        calculation_instruction = (
            f"Follow this solution plan: {solution_plan}\n"
            "Perform the calculations step-by-step. For each step, clearly state the operation being performed, "
            "the result, and any units involved. Ensure intermediate results are accurate and consistent."
        )
        # Split the solution plan into independent steps if applicable
        steps = solution_plan.split("\n")  # Simplistic approach; assumes steps are newline-separated
        calculation_tasks = [
            self.generate(instruction=f"{calculation_instruction}\nFocus on this step: {step}", context=self.problem_text)
            for step in steps if step.strip()
        ]
        intermediate_results = await asyncio.gather(*calculation_tasks)

        # Step 4: Validate and refine results
        refinement_instruction = (
            "Review the following intermediate results and ensure they are accurate and consistent. "
            "Refine any calculations that appear incorrect or incomplete. Verify that units are handled properly."
        )
        refined_results = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction, context=result) for result in intermediate_results]
        )

        # Step 5: Summarize the final answer
        summarization_instruction = (
            "Based on the refined results, determine the final numerical answer to the problem. "
            "Ensure the answer is presented as a single value with appropriate units, if applicable."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context="\n".join(refined_results))

        return final_answer