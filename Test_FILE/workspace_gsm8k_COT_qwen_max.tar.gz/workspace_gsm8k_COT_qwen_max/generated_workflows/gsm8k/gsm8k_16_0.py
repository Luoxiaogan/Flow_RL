# Workflow ID: gsm8k_16_0
# Benchmark: gsm8k
# Data Indices: [654, 149]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant numerical values, relationships, and contextual information
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, "
            "relationships between entities, and any contextual constraints. "
            "Include units (e.g., dollars, hours, items) where applicable. "
            "Organize the information clearly for subsequent steps."
        )
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Construct a step-by-step solution based on the extracted information
        solution_instruction = (
            f"Using the following extracted information:\n{extraction}\n"
            "Construct a step-by-step solution to the problem. "
            "Ensure that each step is logically consistent, handles units correctly, "
            "and builds toward the final answer. Include intermediate results explicitly."
        )
        solution = await self.generate(instruction=solution_instruction, context=self.problem_text)

        # Step 3: Validate and refine the solution
        refinement_instruction = (
            "Review the following solution carefully:\n"
            f"{solution}\n"
            "Check for logical consistency, correct handling of units, and alignment with the problem's context. "
            "Revise any errors or ambiguities, and ensure the reasoning is clear and complete."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=solution)

        # Step 4: Extract the final numerical answer
        final_answer_instruction = (
            "Summarize the following refined solution to extract the final numerical answer:\n"
            f"{refined_solution}\n"
            "Ensure the answer is concise, includes the correct units if applicable, and directly addresses the question."
        )
        final_answer = await self.summarize(instruction=final_answer_instruction, context=refined_solution)

        return final_answer