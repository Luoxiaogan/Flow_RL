# Workflow ID: gsm8k_104_0
# Benchmark: gsm8k
# Data Indices: [396, 254]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (numerical values, relationships, question)
        extract_instruction = (
            "Carefully analyze the problem and extract all relevant information, including numerical values, "
            "relationships between entities, units of measurement, and the specific question being asked. "
            "Format the extracted information clearly and concisely."
        )
        extract_context = self.problem_text
        extracted_info = await self.generate(instruction=extract_instruction, context=extract_context)

        # Step 2: Generate a step-by-step solution
        solution_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Solve the problem step by step, showing all intermediate calculations and reasoning. "
            "Ensure that units are consistent throughout and explain each step clearly. "
            "If there are multiple stages or dependencies, explicitly state them and proceed chronologically. "
            "Conclude with the final numerical answer."
        )
        solution_context = self.problem_text
        solution = await self.generate(instruction=solution_instruction, context=solution_context)

        # Step 3: Validate and refine the solution
        refine_instruction = (
            "Critically review the following solution for correctness, completeness, and clarity. "
            "Check for any missing steps, calculation errors, or inconsistencies. "
            "Refine the solution if necessary, ensuring it is logically sound and easy to follow."
        )
        refined_solution = await self.revise(instruction=refine_instruction, context=solution)

        # Step 4: Extract the final numerical answer
        answer_instruction = (
            "From the following refined solution, extract the final numerical answer. "
            "Ensure the answer is precise and matches the question being asked."
        )
        final_answer = await self.summarize(instruction=answer_instruction, context=refined_solution)

        # Return the final answer
        return final_answer