# Workflow ID: gsm8k_165_0
# Benchmark: gsm8k
# Data Indices: [177, 416]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information
        extraction_instruction = (
            "Thoroughly analyze the problem and extract all numerical values, "
            "units, entities, relationships, and constraints. Identify any temporal "
            "dependencies (e.g., 'on Monday') or relational dependencies (e.g., 'after delivery'). "
            "Provide the extracted information in a structured format."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan solution steps
        planning_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. Include all necessary "
            "calculations, intermediate results, and unit conversions. Account for any hidden "
            "steps or contextual constraints (e.g., real-world feasibility). Ensure the plan "
            "is chronological if the problem involves time-based events."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Execute calculations
        execution_instruction = (
            f"Follow this solution plan step-by-step:\n{solution_plan}\n"
            "Perform all calculations accurately, keeping track of units and intermediate results. "
            "Ensure that the final result is consistent with the problem's context and constraints."
        )
        raw_solution = await self.generate(instruction=execution_instruction, context=self.problem_text)

        # Step 4: Verify and refine the solution
        refinement_instruction = (
            f"Review the following solution:\n{raw_solution}\n"
            "Verify its correctness by cross-checking against the problem's context and constraints. "
            "Ensure that the result makes sense (e.g., no negative quantities, reasonable magnitudes). "
            "Refine the solution if necessary, providing a corrected version."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=raw_solution)

        # Step 5: Summarize the final answer
        summarization_instruction = (
            f"Condense the following solution into a single numerical answer:\n{refined_solution}\n"
            "Ensure the answer is precise and formatted appropriately for the GSM8K benchmark."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_solution)

        return final_answer