# Workflow ID: gsm8k_120_0
# Benchmark: gsm8k
# Data Indices: [381, 662]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract known information (parallelizable)
        extraction_instruction = (
            "Identify all numerical values, units, relationships, and constraints in the problem. "
            "Include their context (e.g., '8 seasons had 15 episodes'). Ensure completeness."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a solution plan (parallelizable)
        plan_instruction = (
            f"Based on the extracted information: {extracted_info}, "
            "create a detailed step-by-step solution plan. Include intermediate calculations, "
            "order of operations, and unit consistency checks."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute calculations
        calculation_instruction = (
            f"Using the solution plan: {solution_plan}, perform all calculations step by step. "
            "Verify each step and ensure the final result makes sense in the context of the problem."
        )
        calculated_result = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Revise and validate the solution
        revision_instruction = (
            f"Critique the solution: {calculated_result}. Ensure it adheres to the problem's constraints, "
            "logical flow, and unit consistency. Correct any errors or inconsistencies."
        )
        revised_solution = await self.revise(instruction=revision_instruction, context=calculated_result)

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"Condense the solution: {revised_solution} into a concise format. Highlight the final numerical answer."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=revised_solution)

        return final_answer