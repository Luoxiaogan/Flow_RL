# Workflow ID: gsm8k_287_0
# Benchmark: gsm8k
# Data Indices: [747, 567]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all numerical values, relationships, and units
        extraction_instruction = (
            "Extract all numerical values, relationships, and units from the problem. "
            "Identify what is being asked and any constraints. "
            "Organize the information into a structured format."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Create a mathematical model and step-by-step plan
        modeling_instruction = (
            f"Based on the following extracted information: {extracted_info} "
            "Create a step-by-step plan to solve the problem. "
            "Include all intermediate calculations and ensure the sequence of operations is logical."
        )
        plan = await self.generate(instruction=modeling_instruction, context=self.problem_text)

        # Step 3: Perform intermediate calculations in parallel
        calculation_instruction = (
            f"Perform the intermediate calculations based on the plan: {plan}. "
            "Ensure each step is clearly documented and verified."
        )
        intermediate_results = await asyncio.gather(
            self.generate(instruction=calculation_instruction, context=self.problem_text),
            self.generate(instruction=calculation_instruction, context=self.problem_text)
        )

        # Step 4: Compute the final answer
        final_instruction = (
            f"Using the intermediate results: {intermediate_results}, compute the final answer. "
            "Ensure the result is consistent with the problem's requirements and units."
        )
        final_answer = await self.generate(instruction=final_instruction, context=self.problem_text)

        # Step 5: Validate and refine the final answer
        validation_instruction = (
            f"Validate the final answer: {final_answer}. "
            "Check for consistency, correctness, and adherence to the problem's constraints. "
            "Refine if necessary."
        )
        refined_answer = await self.revise(instruction=validation_instruction, context=final_answer)

        return refined_answer