# Workflow ID: gsm8k_247_0
# Benchmark: gsm8k
# Data Indices: [455, 128]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all numerical values and relationships
        extraction_instruction = (
            "Extract all numerical values, units, and relationships mentioned in the problem. "
            "For each value, specify its role in the problem (e.g., initial stock, rate, fraction). "
            "Also identify the question being asked and what needs to be calculated."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Solve the problem step-by-step
        solve_instruction = (
            f"Using the following extracted information: {extracted_info}\n"
            "Solve the problem step-by-step. Clearly show each calculation and intermediate result. "
            "Ensure all units are consistent and explain any conversions. "
            "Finally, compute the answer to the question being asked."
        )
        solution = await self.generate(instruction=solve_instruction, context=self.problem_text)

        # Step 3: Validate and refine the solution
        validation_instruction = (
            "Review the solution for correctness. Check that all calculations are accurate, "
            "units are consistent, and the final answer makes sense in the context of the problem. "
            "If there are any errors or ambiguities, revise the solution accordingly."
        )
        refined_solution = await self.revise(instruction=validation_instruction, context=solution)

        # Step 4: Summarize the final answer
        summary_instruction = (
            "Extract the final numerical answer from the solution. Ensure it is clearly stated "
            "and formatted as a single number (integer or decimal)."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer