# Workflow ID: gsm8k_274_0
# Benchmark: gsm8k
# Data Indices: [306, 378]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, units, "
            "relationships, and any other relevant information. Organize the extracted "
            "data into categories such as 'given values', 'unknowns', and 'relationships'."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a solution strategy
        strategy_instruction = (
            f"Based on the following extracted information: {extracted_info}\n"
            "Develop a step-by-step solution strategy. Identify all intermediate steps, "
            "specify the order of operations, and ensure proper handling of units. "
            "Include any necessary checks or validations to ensure the solution makes sense."
        )
        solution_strategy = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Execute calculations
        calculation_instruction_template = (
            "Perform the following calculation step: {step}\n"
            "Ensure all units are consistent and the result is accurate. If any assumptions "
            "are made, clearly state them."
        )

        # Split the solution strategy into individual steps
        steps = solution_strategy.split("\n")
        calculation_tasks = [
            self.generate(
                instruction=calculation_instruction_template.format(step=step),
                context=self.problem_text
            )
            for step in steps if step.strip()
        ]
        calculation_results = await asyncio.gather(*calculation_tasks)

        # Step 4: Verify and refine results
        verification_instruction = (
            "Review the following calculation results and ensure they are correct and consistent "
            "with the problem context. Check for any logical errors, unit mismatches, or missing steps. "
            "If necessary, suggest refinements."
        )
        refined_results = await self.revise(
            instruction=verification_instruction,
            context="\n".join(calculation_results)
        )

        # Step 5: Summarize the final answer
        summary_instruction = (
            "Summarize the solution process and provide the final answer as a single numerical value. "
            "Ensure the answer is clear, concise, and makes sense in the context of the problem."
        )
        final_answer = await self.summarize(
            instruction=summary_instruction,
            context=refined_results
        )

        return final_answer