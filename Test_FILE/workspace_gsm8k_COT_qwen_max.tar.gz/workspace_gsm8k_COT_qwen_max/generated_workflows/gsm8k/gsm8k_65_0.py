# Workflow ID: gsm8k_65_0
# Benchmark: gsm8k
# Data Indices: [613, 259]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract known information
        extraction_instruction = (
            "Extract all numerical values, relationships, and the question being asked from the problem. "
            "Ensure that you capture all relevant information needed to solve the problem, including any implicit relationships or constraints."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Identify intermediate steps
        intermediate_steps_instruction = (
            f"Based on the extracted information: {extracted_info}, identify any intermediate steps required to solve the problem. "
            "Consider any hidden calculations or logical deductions that need to be made before arriving at the final answer."
        )
        intermediate_steps = await self.generate(instruction=intermediate_steps_instruction, context=self.problem_text)

        # Step 3: Perform sequential calculations
        calculation_instruction = (
            f"Using the extracted information: {extracted_info} and the identified intermediate steps: {intermediate_steps}, "
            "perform the necessary calculations step-by-step. Ensure that each calculation is based on the results of the previous steps, "
            "and keep track of units and constraints throughout the process."
        )
        calculations = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Refine intermediate results
        refinement_instruction = (
            f"Review the calculations: {calculations} and refine any intermediate results. "
            "Ensure that each step is accurate and consistent with the problem's context and constraints. "
            "Correct any errors or inconsistencies in the calculations."
        )
        refined_results = await self.revise(instruction=refinement_instruction, context=calculations)

        # Step 5: Verify final answer
        verification_instruction = (
            f"Verify that the final answer: {refined_results} makes sense in the context of the problem. "
            "Ensure that it satisfies any real-world constraints and is consistent with the extracted information and intermediate steps. "
            "If necessary, perform additional checks to confirm the validity of the solution."
        )
        final_answer = await self.generate(instruction=verification_instruction, context=self.problem_text)

        return final_answer