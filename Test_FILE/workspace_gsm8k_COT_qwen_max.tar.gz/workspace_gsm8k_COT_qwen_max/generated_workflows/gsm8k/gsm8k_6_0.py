# Workflow ID: gsm8k_6_0
# Benchmark: gsm8k
# Data Indices: [765, 710]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract numerical values, relationships, and units
        extraction_instruction = """
        Carefully analyze the problem and extract all numerical values, relationships, and units. 
        Identify the known quantities, unknowns, and any constraints or conditions mentioned in the problem. 
        Organize the information clearly, specifying what each value represents and its associated units (if any). 
        Ensure that all implicit relationships (e.g., rates, proportions) are explicitly stated.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Solve the problem step by step
        solution_instruction = f"""
        Using the extracted information: {extracted_info}
        Solve the problem step by step. Begin by identifying the sequence of calculations required to find the unknown. 
        Perform each calculation explicitly, showing intermediate results. Ensure that units are consistent throughout. 
        If there are multiple steps, explain the reasoning behind each step and how it contributes to the final solution. 
        Verify that the solution aligns with the problem's context and constraints.
        """
        solution = await self.generate(instruction=solution_instruction, context=self.problem_text)

        # Step 3: Validate and refine the solution
        validation_instruction = """
        Critically review the provided solution. Check for any calculation errors, unit inconsistencies, or logical flaws. 
        Verify that each step follows naturally from the previous one and that the final answer makes sense in the context of the problem. 
        If any issues are found, revise the solution accordingly and provide a corrected version.
        """
        refined_solution = await self.revise(instruction=validation_instruction, context=solution)

        # Step 4: Extract the final numerical answer
        final_answer_instruction = """
        From the refined solution, extract the final numerical answer. Ensure that it is presented as a single value, 
        without any additional explanation or units. The answer should be precise and match the problem's requirements.
        """
        final_answer = await self.summarize(instruction=final_answer_instruction, context=refined_solution)

        return final_answer