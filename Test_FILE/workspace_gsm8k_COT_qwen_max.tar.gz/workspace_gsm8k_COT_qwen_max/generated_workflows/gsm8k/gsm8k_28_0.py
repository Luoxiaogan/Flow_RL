# Workflow ID: gsm8k_28_0
# Benchmark: gsm8k
# Data Indices: [218, 226]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all numerical values, relationships, and the question
        extraction_instruction = (
            "Extract all numerical values, units, and relationships described in the problem. "
            "Identify what the question is asking for and list it explicitly. "
            "Ensure all extracted information is clearly labeled and organized."
        )
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Perform intermediate reasoning and calculations
        reasoning_instruction = (
            f"Using the extracted information: {extraction}, "
            "identify the sequence of mathematical operations needed to solve the problem. "
            "Perform each calculation step-by-step, showing intermediate results. "
            "Ensure proper handling of units and real-world constraints. "
            "Clearly state the final answer at the end."
        )
        reasoning = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Validate and refine the solution
        refinement_instruction = (
            "Critique the following solution: {reasoning}. "
            "Check for logical consistency, correct order of operations, and proper handling of units. "
            "Refine the solution if necessary, ensuring it adheres to real-world constraints. "
            "Provide the final refined solution."
        )
        refinement = await self.revise(instruction=refinement_instruction, context=reasoning)

        # Step 4: Summarize the final answer
        summary_instruction = (
            "Summarize the final answer from the following refined solution: {refinement}. "
            "Ensure the answer is concise, clear, and explicitly states the numerical result."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refinement)

        return final_answer