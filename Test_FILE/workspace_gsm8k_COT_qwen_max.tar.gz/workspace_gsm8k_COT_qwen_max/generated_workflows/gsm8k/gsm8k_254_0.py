# Workflow ID: gsm8k_254_0
# Benchmark: gsm8k
# Data Indices: [696, 163]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract known information and relationships
        extract_instruction = (
            "Extract all numerical values, relationships, and contextual clues from the problem. "
            "Include units, entities, and any implicit operations (e.g., 'more than', 'fewer than'). "
            "Organize the information in a structured format."
        )
        known_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Identify unknowns and outline the solution approach
        approach_instruction = (
            f"Based on the extracted information: {known_info}, "
            "identify what the problem is asking for (the unknown). "
            "Propose a step-by-step plan to solve the problem, including intermediate calculations. "
            "Ensure the plan handles sequential operations, unit consistency, and real-world constraints."
        )
        solution_plan = await self.generate(instruction=approach_instruction, context=self.problem_text)

        # Step 3: Perform calculations and derive the final answer
        calculation_instruction = (
            f"Using the solution plan: {solution_plan}, perform all necessary calculations step by step. "
            "Include intermediate results and verify each step. "
            "Ensure the final answer is presented as a single numerical value with appropriate units."
        )
        raw_solution = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Validate and refine the solution
        refine_instruction = (
            f"Review the solution: {raw_solution}. "
            "Check for logical consistency, adherence to the problem's constraints, and correctness of calculations. "
            "Refine the solution if needed, ensuring it makes sense in the problem's context."
        )
        refined_solution = await self.revise(instruction=refine_instruction, context=raw_solution)

        # Step 5: Summarize the final answer
        summarize_instruction = (
            f"Extract the final numerical answer from the refined solution: {refined_solution}. "
            "Present it in a concise format, highlighting the result."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_answer