# Workflow ID: gsm8k_316_0
# Benchmark: gsm8k
# Data Indices: [160, 26]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio
        
        # Step 1: Extract all key information from the problem
        extraction_instruction = (
            "Extract all numerical values, relationships, and constraints from the problem. "
            "Include units, percentages, and any contextual details that affect calculations. "
            "Format the output as a structured list or description."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)
        
        # Step 2: Generate intermediate calculations
        calculation_instruction = f"""
        Based on the extracted information: {extracted_info}
        Perform all necessary intermediate calculations step by step. 
        Ensure each step is clearly labeled and justified. 
        Include unit conversions and handle fractions/percentages appropriately. 
        Format the output as a sequence of steps with intermediate results.
        """
        intermediate_results = await self.generate(instruction=calculation_instruction, context=self.problem_text)
        
        # Step 3: Validate and refine intermediate results
        refinement_instruction = """
        Review the intermediate calculations for accuracy and consistency. 
        Check for proper handling of units, realistic constraints (e.g., no negative quantities), 
        and correct application of mathematical operations. 
        Suggest corrections if needed.
        """
        refined_results = await self.revise(instruction=refinement_instruction, context=intermediate_results)
        
        # Step 4: Synthesize the final answer
        synthesis_instruction = f"""
        Using the refined intermediate results: {refined_results}
        Compute the final numerical answer to the problem. 
        Ensure the answer is expressed in the correct units and format. 
        Provide a concise summary of the final result.
        """
        final_answer = await self.summarize(instruction=synthesis_instruction, context=refined_results)
        
        return final_answer