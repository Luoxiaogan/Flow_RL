# Workflow ID: gsm8k_304_0
# Benchmark: gsm8k
# Data Indices: [433, 498]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all numerical values, relationships, and operations
        extraction_instruction = (
            "Thoroughly analyze the problem and extract all numerical values, "
            "relationships, and operations mentioned. Identify known quantities, "
            "unknowns, and any constraints. Organize the information clearly."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate a step-by-step solution using the extracted information
        solution_instruction = (
            f"Using the following extracted information: {extracted_info}\n"
            "Generate a step-by-step solution to the problem. Ensure the solution "
            "follows a logical sequence, maintains unit consistency, and includes "
            "all necessary intermediate calculations. Clearly state the final answer."
        )
        solution = await self.generate(instruction=solution_instruction, context=self.problem_text)

        # Step 3: Validate and refine the solution
        refinement_instruction = (
            "Critically evaluate the provided solution. Check for logical consistency, "
            "correctness of calculations, and adherence to real-world constraints. "
            "Refine the solution if needed, ensuring it makes sense in the context of the problem."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=solution)

        # Step 4: Extract the final numerical answer
        summarization_instruction = (
            "Condense the refined solution into a concise format. Extract and present "
            "the final numerical answer as a single value, ensuring it is clearly identifiable."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_solution)

        return final_answer