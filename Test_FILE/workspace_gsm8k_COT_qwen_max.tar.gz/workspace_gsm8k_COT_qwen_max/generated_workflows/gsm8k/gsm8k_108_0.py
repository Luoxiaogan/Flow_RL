# Workflow ID: gsm8k_108_0
# Benchmark: gsm8k
# Data Indices: [753, 610]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract numerical values, relationships, and constraints
        extraction_instruction = """
        Carefully analyze the problem and extract all numerical values, relationships, and constraints. 
        Identify what is being asked and list all known quantities and their relationships explicitly. 
        Ensure that units are tracked and clarified where necessary.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Perform intermediate calculations
        calculation_instruction = f"""
        Based on the extracted information: {extracted_info}
        Perform all necessary intermediate calculations step by step. 
        Include arithmetic operations, unit conversions, and any other required computations. 
        Clearly label each step and its result.
        """
        intermediate_results = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 3: Validate and refine intermediate results
        refinement_instruction = f"""
        Review the intermediate results: {intermediate_results}
        Check for accuracy, logical consistency, and adherence to the problem's constraints. 
        Revise any steps that appear incorrect or ambiguous.
        """
        refined_results = await self.revise(instruction=refinement_instruction, context=intermediate_results)

        # Step 4: Synthesize the final answer
        synthesis_instruction = f"""
        Using the refined results: {refined_results}
        Combine all the information to compute the final answer. 
        Ensure the answer is a single numerical value that directly addresses the problem. 
        Verify that the answer makes sense in the context of the problem.
        """
        final_answer = await self.generate(instruction=synthesis_instruction, context=self.problem_text)

        # Optional: Ensemble to decide on the best solution if multiple approaches were used
        ensemble_instruction = """
        Evaluate the provided solutions and select the most accurate and contextually appropriate answer.
        """
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=[final_answer])

        return final_solution