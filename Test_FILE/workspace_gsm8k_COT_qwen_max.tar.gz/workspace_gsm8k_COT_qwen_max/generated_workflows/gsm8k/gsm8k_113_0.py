# Workflow ID: gsm8k_113_0
# Benchmark: gsm8k
# Data Indices: [319, 347]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (numerical values, relationships, units)
        extraction_instruction = (
            "Extract all numerical values, relationships, and units from the problem. "
            "Identify the knowns and unknowns. Clearly state what the question is asking for."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Perform intermediate calculations
        calculation_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "perform the necessary calculations step by step. "
            "Include all intermediate results and ensure proper handling of units."
        )
        intermediate_results = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 3: Validate and refine the results
        refinement_instruction = (
            "Critique the intermediate results. Ensure they make sense in the context of the problem. "
            "Flag any unrealistic or incorrect values and suggest corrections."
        )
        refined_results = await self.revise(instruction=refinement_instruction, context=intermediate_results)

        # Step 4: Synthesize the final answer
        synthesis_instruction = (
            "Condense the refined results into a single numerical answer. "
            "Ensure the answer directly addresses the question and is formatted correctly."
        )
        final_answer = await self.summarize(instruction=synthesis_instruction, context=refined_results)

        return final_answer