# Workflow ID: gsm8k_192_0
# Benchmark: gsm8k
# Data Indices: [278, 590]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extract_instruction = (
            "Carefully analyze the given word problem. "
            "Identify and extract all numerical values, units, relationships, and constraints mentioned. "
            "Ensure you capture any implicit information such as intermediate steps or contextual constraints."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution strategies in parallel
        strategy_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Generate a detailed step-by-step solution strategy to solve the problem. "
            "Ensure all calculations are explicitly stated, including intermediate results. "
            "Handle units appropriately and consider real-world constraints."
        )
        strategy1 = self.generate(instruction=strategy_instruction, context=self.problem_text)
        strategy2 = self.generate(instruction=strategy_instruction, context=self.problem_text)
        strategy3 = self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Execute the strategies in parallel
        strategies = await asyncio.gather(strategy1, strategy2, strategy3)

        # Step 3: Use ensemble to select or synthesize the best solution
        ensemble_instruction = (
            "Evaluate the provided solution strategies. "
            "Select the most accurate and logical approach, or synthesize a new solution combining the best elements. "
            "Ensure the final solution satisfies all problem constraints and is mathematically sound."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=strategies)

        # Step 4: Verify and finalize the answer
        verification_instruction = (
            f"Verify the correctness of the solution: {final_solution}\n"
            "Ensure the answer makes sense in the context of the problem. "
            "Check for unit consistency, realistic values, and adherence to constraints. "
            "If necessary, revise the solution to correct any issues."
        )
        verified_solution = await self.revise(instruction=verification_instruction, context=final_solution)

        return verified_solution