# Workflow ID: gsm8k_148_0
# Benchmark: gsm8k
# Data Indices: [111, 184]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information from the problem
        extraction_instruction = (
            "Extract all numerical values, units, relationships, and the target question from the problem. "
            "Organize the information in a structured format, ensuring clarity and completeness."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Identify intermediate steps and outline the solution process
        planning_instruction = (
            f"Based on the extracted information: {extracted_info}, identify all intermediate steps required to solve the problem. "
            "Outline a logical sequence of operations, including any hidden calculations or conversions. "
            "Ensure the plan accounts for all constraints and real-world considerations."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Generate multiple solution attempts in parallel
        solution_attempts = await asyncio.gather(
            self.generate(
                instruction=f"Follow this plan: {solution_plan} to compute the final answer. Perform calculations step by step.",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"Follow this plan: {solution_plan} to compute the final answer. Double-check each step for accuracy.",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"Follow this plan: {solution_plan} to compute the final answer. Focus on unit consistency and precision.",
                context=self.problem_text
            )
        )

        # Step 4: Validate and select the best solution
        validation_instruction = (
            "Compare the following solution attempts and select the most accurate and consistent one. "
            "Consider adherence to the problem constraints, logical correctness, and reasonableness of the final answer."
        )
        best_solution = await self.ensemble(instruction=validation_instruction, contexts=solution_attempts)

        # Step 5: Refine the final answer if necessary
        refinement_instruction = (
            "Review the selected solution and ensure it is clear, correct, and properly formatted. "
            "Verify that the final answer is a single numerical value (integer or decimal) and makes sense in the problem context."
        )
        final_answer = await self.revise(instruction=refinement_instruction, context=best_solution)

        return final_answer