# Workflow ID: gsm8k_288_0
# Benchmark: gsm8k
# Data Indices: [60, 283]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information
        extraction_instruction = """
        Extract all numerical values, units, relationships, and constraints from the problem text.
        Organize the information clearly, labeling each piece of data for easy reference.
        For example, identify quantities like "48 ounces", percentages like "4% less", and relationships like "twice as expensive".
        Ensure that all extracted data is relevant to solving the problem.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan the solution approach
        planning_instruction = f"""
        Based on the extracted information below, create a detailed plan to solve the problem step-by-step.
        Clearly define the sequence of operations needed, including any hidden steps or intermediate calculations.
        Ensure that units are consistent throughout the calculations and that real-world constraints are respected.
        Extracted Information: {extracted_info}
        """
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Execute the plan in parallel
        execution_instruction_template = """
        Solve the following step from the solution plan accurately.
        Perform the calculation or reasoning required, showing all intermediate results.
        Ensure that the result is consistent with the problem context and units.
        Step: {step}
        """
        steps = solution_plan.split("\n")  # Assume each step is separated by a newline
        execution_tasks = [
            self.generate(instruction=execution_instruction_template.format(step=step), context=self.problem_text)
            for step in steps if step.strip()
        ]
        intermediate_results = await asyncio.gather(*execution_tasks)

        # Step 4: Verify intermediate results
        verification_instruction_template = """
        Critique and refine the following intermediate result to ensure accuracy and consistency.
        Check for calculation errors, unit mismatches, and logical inconsistencies.
        If necessary, correct the result and explain the reasoning behind the revision.
        Intermediate Result: {result}
        """
        verification_tasks = [
            self.revise(instruction=verification_instruction_template.format(result=result), context=self.problem_text)
            for result in intermediate_results
        ]
        verified_results = await asyncio.gather(*verification_tasks)

        # Step 5: Synthesize the final answer
        synthesis_instruction = """
        Combine the verified intermediate results into a coherent final solution.
        Ensure that the final answer is a single numerical value, adhering to the problem's requirements.
        Include any necessary unit conversions or rounding adjustments.
        Verified Results: {results}
        """
        final_answer = await self.ensemble(
            instruction=synthesis_instruction.format(results=verified_results),
            contexts=verified_results
        )

        # Step 6: Summarize the solution
        summary_instruction = """
        Summarize the entire reasoning process concisely, highlighting the key steps and the final answer.
        Ensure that the summary is clear and easy to follow, providing a complete overview of the solution.
        Final Answer: {answer}
        """
        solution_summary = await self.summarize(
            instruction=summary_instruction.format(answer=final_answer),
            context=self.problem_text
        )

        return solution_summary