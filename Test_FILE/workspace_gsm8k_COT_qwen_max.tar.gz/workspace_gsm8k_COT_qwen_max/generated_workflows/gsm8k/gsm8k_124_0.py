# Workflow ID: gsm8k_124_0
# Benchmark: gsm8k
# Data Indices: [792, 219]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (numerical values, relationships, entities)
        extract_instruction = (
            "Extract all numerical values, relationships, and entities mentioned in the problem. "
            "Include units (e.g., dollars, hours, items) and any constraints or conditions. "
            "Format the output as a structured list for clarity."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Formulate a step-by-step solution plan
        plan_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Create a step-by-step solution plan to solve the problem. "
            "Identify the mathematical operations needed (addition, subtraction, multiplication, division), "
            "the order of operations, and any intermediate calculations. "
            "Ensure the plan accounts for unit consistency and contextual constraints."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute the solution plan and perform calculations
        execute_instruction = (
            f"Follow this solution plan: {solution_plan}\n"
            "Perform each calculation step-by-step, showing all intermediate results. "
            "Ensure the calculations are accurate and consistent with the problem's context."
        )
        executed_solution = await self.generate(instruction=execute_instruction, context=self.problem_text)

        # Step 4: Verify and refine the solution
        revise_instruction = (
            f"Review the executed solution: {executed_solution}\n"
            "Check for accuracy, logical consistency, and adherence to real-world constraints. "
            "Refine the solution if necessary, correcting any errors or inconsistencies."
        )
        refined_solution = await self.revise(instruction=revise_instruction, context=executed_solution)

        # Step 5: Summarize the final answer
        summarize_instruction = (
            f"Condense the refined solution: {refined_solution}\n"
            "Provide the final answer as a single numerical value with appropriate units (if applicable). "
            "Ensure the output is concise and clear."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_answer