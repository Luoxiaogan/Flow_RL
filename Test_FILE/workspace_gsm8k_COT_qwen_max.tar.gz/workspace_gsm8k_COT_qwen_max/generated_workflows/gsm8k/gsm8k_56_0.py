# Workflow ID: gsm8k_56_0
# Benchmark: gsm8k
# Data Indices: [661, 617]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract known information
        extract_instruction = (
            "Extract all numerical values, relationships, and constraints from the problem. "
            "Include any implicit information (e.g., ratios, totals) and organize it clearly. "
            "Ensure units and variables are explicitly stated."
        )
        extract_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Formulate a solution plan
        plan_instruction = (
            f"Based on the extracted information: {extract_info}\n"
            "Devise a step-by-step plan to solve the problem. Include intermediate calculations, "
            "the order of operations, and any necessary unit conversions. Ensure the plan is "
            "logically consistent and accounts for all constraints."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute calculations
        execute_instruction = (
            f"Using the solution plan: {solution_plan}\n"
            "Perform the calculations step by step. Incorporate the results of each step into "
            "subsequent calculations. Ensure all intermediate results are clearly stated."
        )
        raw_solution = await self.generate(instruction=execute_instruction, context=self.problem_text)

        # Step 4: Verify and refine the solution
        refine_instruction = (
            f"Review the solution: {raw_solution}\n"
            "Check for logical consistency, correct order of operations, and adherence to constraints. "
            "Refine the solution if necessary, ensuring it is mathematically accurate and makes sense in context."
        )
        refined_solution = await self.revise(instruction=refine_instruction, context=raw_solution)

        # Step 5: Summarize the final answer
        summarize_instruction = (
            f"Summarize the refined solution: {refined_solution}\n"
            "Condense the result into a single numerical value or a brief statement that directly "
            "answers the question posed in the problem."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_answer