# Workflow ID: gsm8k_307_0
# Benchmark: gsm8k
# Data Indices: [44, 182]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract known information
        extract_instruction = (
            "Carefully analyze the problem and extract all relevant numerical values, relationships, "
            "and constraints. Identify what is given and what is being asked. Ensure that you capture "
            "all units (e.g., dollars, steps, degrees) and any implicit information."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Formulate a solution plan
        plan_instruction = (
            f"Based on the following extracted information: {extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. Include all intermediate "
            "calculations, relationships, and logical reasoning. Ensure that the plan is systematic "
            "and accounts for all constraints and units."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Perform calculations
        calculate_instruction = (
            f"Using the following solution plan: {solution_plan}\n"
            "Execute the calculations step by step. Show all intermediate results and ensure that "
            "each step logically follows from the previous one. Maintain unit consistency throughout."
        )
        calculated_result = await self.generate(instruction=calculate_instruction, context=self.problem_text)

        # Step 4: Verify the solution
        verify_instruction = (
            f"Review the following calculated result: {calculated_result}\n"
            "Critique and refine the solution to ensure accuracy. Check that the answer makes sense "
            "in the context of the problem, including units and logical consistency. Correct any errors."
        )
        verified_solution = await self.revise(instruction=verify_instruction, context=calculated_result)

        # Step 5: Summarize the result
        summarize_instruction = (
            "Condense the solution into a concise format. Present only the essential information "
            "and the final answer. Ensure clarity and precision."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=verified_solution)

        return final_answer