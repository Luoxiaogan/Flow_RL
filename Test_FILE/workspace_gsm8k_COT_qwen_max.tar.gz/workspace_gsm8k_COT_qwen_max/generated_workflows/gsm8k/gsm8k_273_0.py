# Workflow ID: gsm8k_273_0
# Benchmark: gsm8k
# Data Indices: [622, 773]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract numerical values, entities, relationships, and constraints
        extraction_instruction = (
            "Thoroughly analyze the problem and extract all numerical values, key entities (e.g., people, objects), "
            "relationships (e.g., proportions, rates), and constraints (e.g., time-based, unit-based). "
            "Organize the extracted information in a structured format for further processing."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Break the problem into intermediate steps
        intermediate_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Break the problem into intermediate calculation steps. "
            "Each step should explicitly describe the calculation being performed, including the relevant values and operations. "
            "Ensure the steps are sequenced logically and account for any hidden or implied calculations."
        )
        intermediate_steps = await self.generate(instruction=intermediate_instruction, context=self.problem_text)

        # Step 3: Perform intermediate calculations in parallel
        calculation_instruction = (
            f"Perform the following intermediate calculations step by step:\n{intermediate_steps}\n"
            "For each step, show the calculation process and the result. "
            "Ensure all units are consistent and the results are accurate."
        )
        calculations = await asyncio.gather(
            self.generate(instruction=calculation_instruction, context=self.problem_text),
            self.generate(instruction=calculation_instruction, context=self.problem_text)
        )

        # Step 4: Synthesize results using Ensemble
        synthesis_instruction = (
            "Compare the following calculation results and synthesize them into a single coherent solution:\n"
            f"Result 1: {calculations[0]}\nResult 2: {calculations[1]}\n"
            "Ensure the final solution is consistent, accurate, and addresses the original problem completely."
        )
        synthesized_result = await self.ensemble(instruction=synthesis_instruction, contexts=calculations)

        # Step 5: Final verification and refinement
        verification_instruction = (
            f"Verify the following solution:\n{synthesized_result}\n"
            "Check for consistency with the problem context, logical correctness, and numerical accuracy. "
            "Refine the solution if necessary, ensuring it makes sense in the real-world scenario described."
        )
        final_result = await self.revise(instruction=verification_instruction, context=synthesized_result)

        return final_result