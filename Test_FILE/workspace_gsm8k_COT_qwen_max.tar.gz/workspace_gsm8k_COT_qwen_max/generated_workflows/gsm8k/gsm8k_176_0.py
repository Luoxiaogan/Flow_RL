# Workflow ID: gsm8k_176_0
# Benchmark: gsm8k
# Data Indices: [673, 627]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract numerical values, units, and relationships
        extraction_instruction = (
            "Extract all numerical values, units, and relationships from the problem. "
            "Identify what is being asked and any constraints or conditions. "
            "Format the output as a structured summary."
        )
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan the solution
        planning_instruction = (
            f"Based on the following extracted information:\n{extraction}\n"
            "Plan the sequence of operations required to solve the problem. "
            "Include unit conversions, intermediate calculations, and the final goal. "
            "Format the plan as a step-by-step outline."
        )
        plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Execute calculations in parallel
        calculation_instruction_template = (
            "Perform the following calculation step:\n{{step}}\n"
            "Ensure all units are consistent and show intermediate results. "
            "Provide the result with appropriate precision."
        )

        # Split the plan into individual steps
        steps = plan.split("\n")
        calculation_tasks = [
            self.generate(
                instruction=calculation_instruction_template.replace("{{step}}", step),
                context=self.problem_text
            )
            for step in steps if step.strip()
        ]
        calculation_results = await asyncio.gather(*calculation_tasks)

        # Step 4: Refine intermediate results
        refinement_instruction_template = (
            "Review the following calculation result:\n{{result}}\n"
            "Check for correctness, consistency, and proper formatting. "
            "Suggest improvements if necessary."
        )
        refinement_tasks = [
            self.revise(
                instruction=refinement_instruction_template.replace("{{result}}", result),
                context=self.problem_text
            )
            for result in calculation_results
        ]
        refined_results = await asyncio.gather(*refinement_tasks)

        # Step 5: Synthesize the final answer
        synthesis_instruction = (
            "Combine the following refined results to determine the final answer:\n"
            f"{refined_results}\n"
            "Ensure the answer directly addresses the question and is formatted correctly. "
            "Include any necessary rounding or unit annotations."
        )
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=refined_results)

        return final_answer