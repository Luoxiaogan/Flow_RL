# Workflow ID: gsm8k_147_0
# Benchmark: gsm8k
# Data Indices: [480, 488]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (numerical values, units, relationships)
        extract_instruction = (
            "Thoroughly analyze the problem and extract all numerical values, units, and relationships. "
            "Include any implicit operations (e.g., percentages, rates) and constraints. "
            "Format the output clearly with labeled categories: Numerical Values, Units, Relationships, Constraints."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Plan the solution (step-by-step breakdown)
        plan_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. "
            "Include all necessary calculations, intermediate results, and their order of execution. "
            "Ensure the plan accounts for unit consistency and contextual constraints."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute calculations in parallel
        calculation_steps = solution_plan.split("\n")  # Assume each line is a calculation step
        calculation_tasks = [
            self.generate(
                instruction=f"Perform the following calculation step: {step}. "
                            "Show your work and provide the result with appropriate units.",
                context=self.problem_text
            )
            for step in calculation_steps if step.strip()
        ]
        raw_results = await asyncio.gather(*calculation_tasks)

        # Step 4: Validate and refine results
        refine_tasks = [
            self.revise(
                instruction=f"Review and refine the following calculation result: {result}. "
                            "Ensure accuracy, unit consistency, and alignment with the problem's context.",
                context=self.problem_text
            )
            for result in raw_results
        ]
        refined_results = await asyncio.gather(*refine_tasks)

        # Step 5: Synthesize the final answer
        ensemble_instruction = (
            "Evaluate the following refined results and synthesize them into a single coherent solution. "
            "Ensure the final answer is consistent with the problem's context and constraints. "
            "Clearly state the final numerical value and its justification."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=refined_results)

        # Step 6: Summarize the solution
        summarize_instruction = (
            "Condense the solution into a concise summary. "
            "Focus on the final answer and its justification. "
            "Ensure the summary is clear and easy to understand."
        )
        summary = await self.summarize(instruction=summarize_instruction, context=final_answer)

        return summary