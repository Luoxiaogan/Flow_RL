# Workflow ID: gsm8k_151_0
# Benchmark: gsm8k
# Data Indices: [65, 21]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract known information
        extraction_instruction = (
            "Extract all numerical values, their units, and any relationships or constraints mentioned in the problem. "
            "Include explicit details about what is given and any conditions that apply."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Identify the unknown and plan the solution
        planning_instruction = (
            f"Based on the extracted information: {extracted_info}, determine what the problem is asking for. "
            "Outline the sequence of steps required to solve the problem, including any intermediate calculations. "
            "Ensure all hidden steps are uncovered and maintain unit consistency throughout."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Perform calculations in parallel
        calculation_instruction_template = (
            "Perform the following calculation step-by-step: {step}. "
            "Ensure all units are consistent and include intermediate results."
        )
        steps = solution_plan.split("\n")  # Assume steps are separated by newlines
        calculation_tasks = [
            self.generate(instruction=calculation_instruction_template.format(step=step), context=self.problem_text)
            for step in steps if step.strip()
        ]
        intermediate_results = await asyncio.gather(*calculation_tasks)

        # Step 4: Combine results and validate
        ensemble_instruction = (
            "Combine the following intermediate results into a final answer: {results}. "
            "Ensure the final result aligns with the problem's requirements, maintains unit consistency, "
            "and makes sense in the context of the problem."
        )
        final_answer = await self.ensemble(
            instruction=ensemble_instruction.format(results="\n".join(intermediate_results)),
            contexts=intermediate_results
        )

        # Step 5: Refine and summarize
        refine_instruction = (
            "Critique and improve the clarity and correctness of the following solution: {solution}. "
            "Ensure all steps are logical, units are consistent, and the final answer is accurate."
        )
        refined_solution = await self.revise(instruction=refine_instruction.format(solution=final_answer), context=self.problem_text)

        summarize_instruction = (
            "Summarize the following solution into a concise format that highlights the key steps and the final answer: {solution}."
        )
        summary = await self.summarize(instruction=summarize_instruction.format(solution=refined_solution), context=self.problem_text)

        return summary