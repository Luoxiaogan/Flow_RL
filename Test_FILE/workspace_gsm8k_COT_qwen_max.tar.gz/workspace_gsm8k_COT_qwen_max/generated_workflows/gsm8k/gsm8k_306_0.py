# Workflow ID: gsm8k_306_0
# Benchmark: gsm8k
# Data Indices: [235, 53]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (numerical values, relationships, constraints)
        extraction_instruction = (
            "Thoroughly analyze the problem and extract all numerical values, relationships, "
            "and constraints. Include units where applicable and describe how these values "
            "relate to each other. Ensure the output is clear and unambiguous."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Perform intermediate calculations step-by-step
        calculation_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem step-by-step. "
            "Ensure all calculations are explicit and include intermediate results. Address any "
            "hidden steps or implicit calculations. Maintain unit consistency throughout."
        )
        intermediate_results = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 3: Verify and refine intermediate results
        refinement_instruction = (
            "Carefully review the intermediate results and verify their correctness. Identify "
            "any errors, inconsistencies, or missing steps. Provide corrections and improvements "
            "where necessary. Ensure the refined results are accurate and complete."
        )
        refined_results = await self.revise(instruction=refinement_instruction, context=intermediate_results)

        # Step 4: Synthesize the final answer
        synthesis_instruction = (
            "Condense the refined results into a single numerical value representing the final answer. "
            "Ensure the answer is consistent with the problem context and includes appropriate units. "
            "If necessary, explain how the answer was derived."
        )
        final_answer = await self.summarize(instruction=synthesis_instruction, context=refined_results)

        return final_answer