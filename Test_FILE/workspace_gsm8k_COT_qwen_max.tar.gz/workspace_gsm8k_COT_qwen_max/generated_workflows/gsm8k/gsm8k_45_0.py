# Workflow ID: gsm8k_45_0
# Benchmark: gsm8k
# Data Indices: [656, 273]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract relevant information (numerical values, relationships, constraints)
        extraction_instruction = (
            "Extract all numerical values, relationships, and constraints from the problem. "
            "Identify knowns, unknowns, and any hidden steps or intermediate calculations. "
            "Format the output as bullet points for clarity."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate step-by-step solutions in parallel
        solution_instruction = (
            f"Given the extracted information: {extracted_info}\n"
            "Solve the problem step by step. Ensure the correct order of operations, handle units consistently, "
            "and verify intermediate results. Provide a detailed explanation for each step."
        )
        approach_1 = self.generate(instruction=solution_instruction, context=self.problem_text)
        approach_2 = self.generate(instruction=solution_instruction, context=self.problem_text)
        solutions = await asyncio.gather(approach_1, approach_2)

        # Step 3: Revise and critique the solutions
        revision_instruction = (
            "Critique and refine the provided solution. Check for logical consistency, unit handling, "
            "and adherence to the problem's context. Correct any errors and improve clarity."
        )
        revised_solution_1 = await self.revise(instruction=revision_instruction, context=solutions[0])
        revised_solution_2 = await self.revise(instruction=revision_instruction, context=solutions[1])

        # Step 4: Ensemble to select the best solution
        ensemble_instruction = (
            "Compare the two revised solutions and select the best one. "
            "Consider correctness, clarity, and alignment with the problem's requirements."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=[revised_solution_1, revised_solution_2])

        # Step 5: Summarize to extract the final answer
        summary_instruction = (
            "Extract the final numerical answer from the solution. "
            "Ensure the output is a single value (integer or decimal)."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=best_solution)

        return final_answer