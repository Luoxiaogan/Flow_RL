# Workflow ID: gsm8k_333_0
# Benchmark: gsm8k
# Data Indices: [563, 70]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (numerical values, relationships, units)
        extraction_instruction = (
            "Extract all numerical values, relationships (e.g., 'more than', 'half of'), "
            "and units from the problem. Organize the information clearly and label each component."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan the solution
        planning_instruction = (
            f"Based on the extracted information: {extracted_info}, create a detailed step-by-step plan "
            "to solve the problem. Include intermediate calculations, equations, and any necessary "
            "validations. Ensure the plan is chronological and logical."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Execute the plan in parallel
        execution_instruction_template = (
            "Perform the following step from the solution plan: {step}. "
            "Show all calculations and provide the result. Ensure the result is labeled and clear."
        )
        steps = solution_plan.split("\n")  # Assuming steps are separated by newlines
        execution_tasks = [
            self.generate(instruction=execution_instruction_template.format(step=step), context=self.problem_text)
            for step in steps if step.strip()
        ]
        intermediate_results = await asyncio.gather(*execution_tasks)

        # Step 4: Synthesize results into a final solution
        synthesis_instruction = (
            "Combine the following intermediate results into a final solution: {results}. "
            "Ensure the final answer is consistent with the problem's context and constraints. "
            "Provide the final numerical answer only."
        )
        final_solution = await self.ensemble(
            instruction=synthesis_instruction.format(results=intermediate_results),
            contexts=intermediate_results
        )

        # Step 5: Validate the final solution
        validation_instruction = (
            f"Critique the final solution: {final_solution}. Ensure it aligns with the problem's context "
            "and constraints. If necessary, suggest refinements or corrections."
        )
        validated_solution = await self.revise(instruction=validation_instruction, context=final_solution)

        return validated_solution