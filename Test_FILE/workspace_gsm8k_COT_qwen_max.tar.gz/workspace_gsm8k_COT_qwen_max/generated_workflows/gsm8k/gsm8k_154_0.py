# Workflow ID: gsm8k_154_0
# Benchmark: gsm8k
# Data Indices: [213, 245]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information (numerical values, units, relationships)
        extraction_instruction = (
            "Extract all numerical values, units, relationships, and constraints from the problem. "
            "Include any implicit information (e.g., rates, proportions) and explicitly state what is being asked. "
            "Format the output as a structured list for clarity."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan the solution steps
        planning_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Plan a step-by-step solution to the problem. Identify intermediate calculations, "
            "order of operations, and any necessary unit conversions. "
            "Ensure the plan is comprehensive and leaves no steps ambiguous."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Execute sub-problems in parallel
        subproblem_instructions = [
            "Calculate the total number of servings required based on the number of guests and servings per guest.",
            "Determine how many bottles are needed given the total servings and servings per bottle.",
            "Verify unit consistency and ensure all calculations align with the problem context."
        ]
        subproblem_contexts = [solution_plan] * len(subproblem_instructions)  # Reuse solution plan as context
        subproblem_results = await asyncio.gather(
            *[self.generate(instruction=instr, context=ctx) for instr, ctx in zip(subproblem_instructions, subproblem_contexts)]
        )

        # Step 4: Synthesize results using Ensemble
        synthesis_instruction = (
            "Evaluate and combine the following candidate solutions into a single coherent answer. "
            "Ensure the final result is consistent with the problem context and constraints. "
            "If discrepancies exist, resolve them logically and provide the most accurate answer."
        )
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=subproblem_results)

        # Step 5: Validate and refine the final answer
        refinement_instruction = (
            "Critically review the following answer for accuracy, unit consistency, and contextual validity. "
            "Correct any errors, clarify ambiguities, and ensure the result is a single numerical value."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        return refined_answer