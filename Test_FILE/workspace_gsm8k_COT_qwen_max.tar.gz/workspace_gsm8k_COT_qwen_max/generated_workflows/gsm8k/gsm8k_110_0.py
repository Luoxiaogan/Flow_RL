# Workflow ID: gsm8k_110_0
# Benchmark: gsm8k
# Data Indices: [506, 227]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract Known Information
        extraction_instruction = """
        Extract all numerical values, relationships, and constraints from the problem text. 
        Include units, ratios, and any implicit information. 
        Format the output as a structured list for easy reference.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a Solution Plan
        plan_instruction = f"""
        Based on the following extracted information: {extracted_info}
        Create a step-by-step solution plan to solve the problem. 
        Address intermediate calculations, unit consistency, and contextual constraints. 
        Ensure the plan is chronological and logical.
        """
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute the Solution Plan
        execution_instruction = f"""
        Using the following solution plan: {solution_plan}
        Perform the necessary calculations to compute the final answer. 
        Verify each step and ensure the result makes sense in the context of the problem.
        """
        computed_result = await self.generate(instruction=execution_instruction, context=self.problem_text)

        # Step 4: Refine and Validate
        refinement_instruction = f"""
        Critique and refine the following computed result: {computed_result}
        Ensure the answer is accurate, contextually valid, and adheres to any constraints. 
        Improve clarity or precision if needed.
        """
        refined_result = await self.revise(instruction=refinement_instruction, context=computed_result)

        # Step 5: Summarize the Final Answer
        summary_instruction = """
        Condense the final result into a single numerical value. 
        Ensure the output is concise and directly answers the question.
        """
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_result)

        return final_answer