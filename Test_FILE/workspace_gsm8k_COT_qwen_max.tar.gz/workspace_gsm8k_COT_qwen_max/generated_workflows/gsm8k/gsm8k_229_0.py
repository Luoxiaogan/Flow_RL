# Workflow ID: gsm8k_229_0
# Benchmark: gsm8k
# Data Indices: [758, 599]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem text
        extraction_instruction = (
            "Carefully analyze the problem and extract all relevant numerical values, "
            "relationships, and constraints. Identify what is being asked and categorize "
            "the information into knowns and unknowns. Ensure you capture units, rates, "
            "and any implicit relationships."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate a step-by-step solution based on the extracted information
        solution_instruction = (
            f"Using the following extracted information: {extracted_info}\n"
            "Construct a detailed step-by-step solution to the problem. Ensure each step "
            "is logically connected to the previous one, and explicitly state any intermediate "
            "calculations. Handle units consistently and verify that the solution adheres to "
            "real-world constraints."
        )
        step_by_step_solution = await self.generate(instruction=solution_instruction, context=self.problem_text)

        # Step 3: Revise and refine the solution for accuracy and clarity
        revision_instruction = (
            "Critically evaluate the following solution and refine it if necessary. "
            "Check for logical consistency, correct handling of units, and adherence to "
            "real-world constraints. Ensure the solution makes sense in the context of the problem. "
            "If there are any errors or ambiguities, correct them."
        )
        refined_solution = await self.revise(instruction=revision_instruction, context=step_by_step_solution)

        # Step 4: Summarize the refined solution and extract the final answer
        summary_instruction = (
            "Condense the following solution into a concise summary that preserves the final "
            "numerical answer. Ensure the answer is clearly stated and formatted as a single "
            "number (integer or decimal)."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer