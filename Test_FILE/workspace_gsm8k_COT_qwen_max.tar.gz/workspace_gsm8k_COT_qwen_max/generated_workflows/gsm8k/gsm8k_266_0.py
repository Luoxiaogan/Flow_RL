# Workflow ID: gsm8k_266_0
# Benchmark: gsm8k
# Data Indices: [28, 787]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract known information
        extraction_instruction = (
            "Extract all numerical values, relationships, and contextual constraints from the problem. "
            "Include units, explicit operations (e.g., addition, subtraction), and any hidden assumptions. "
            "Format the extracted information clearly for further processing."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan solution steps
        planning_instruction = (
            f"Based on the extracted information: {extracted_info}, create a detailed step-by-step plan to solve the problem. "
            "Include all intermediate calculations, operations, and checks for consistency. Ensure the plan accounts for units, "
            "real-world constraints, and the order of operations."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Execute calculations
        execution_instruction = (
            f"Follow this plan step-by-step: {solution_plan}. Perform each calculation explicitly, stating the operation, "
            "inputs, and result. Ensure intermediate results are accurate and consistent with the problem context."
        )
        executed_steps = await self.generate(instruction=execution_instruction, context=self.problem_text)

        # Step 4: Verify intermediate results
        verification_instruction = (
            f"Review the executed steps: {executed_steps}. Check for accuracy, consistency, and alignment with the problem context. "
            "Refine any incorrect or ambiguous results. Provide clear reasoning for any revisions."
        )
        verified_results = await self.revise(instruction=verification_instruction, context=executed_steps)

        # Step 5: Summarize final answer
        summary_instruction = (
            f"From the verified results: {verified_results}, extract the final numerical answer. Ensure it is presented "
            "in the correct format and unit, and aligns with the problem's requirements."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=verified_results)

        return final_answer