# Workflow ID: gsm8k_121_0
# Benchmark: gsm8k
# Data Indices: [527, 687]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all numerical values, units, and relationships
        extraction_instruction = (
            "Extract all numerical values, their units, and any relationships or constraints from the problem. "
            "Include information about entities (e.g., people, objects) and their associated quantities. "
            "Present the extracted information in a structured format."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the problem and plan the solution steps
        analysis_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Analyze the problem and outline the steps required to solve it. "
            "Include details about the sequence of operations, intermediate calculations, and any contextual constraints. "
            "Ensure the plan accounts for unit consistency and real-world feasibility."
        )
        solution_plan = await self.generate(instruction=analysis_instruction, context=self.problem_text)

        # Step 3: Generate multiple solution approaches in parallel
        approach_1_instruction = (
            f"Follow this solution plan:\n{solution_plan}\n"
            "Perform the calculations step by step and provide the final answer. "
            "Ensure all intermediate results are clearly shown and labeled."
        )
        approach_2_instruction = (
            f"Follow this solution plan:\n{solution_plan}\n"
            "Solve the problem using an alternative method if possible. "
            "For example, use a different sequence of operations or represent quantities differently. "
            "Provide the final answer with clear justification."
        )
        results = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text)
        )

        # Step 4: Evaluate and select the best solution
        evaluation_instruction = (
            "Compare the following candidate solutions and select the best one:\n"
            f"Candidate 1:\n{results[0]}\nCandidate 2:\n{results[1]}\n"
            "The selection should be based on correctness, clarity, and adherence to the problem's context. "
            "If both solutions are equally valid, choose the one with the clearest explanation."
        )
        best_solution = await self.ensemble(instruction=evaluation_instruction, contexts=results)

        # Step 5: Refine the final solution
        refinement_instruction = (
            "Refine the following solution to ensure it is concise, accurate, and properly formatted:\n"
            f"{best_solution}\n"
            "Verify that the final answer makes sense in the context of the problem and is presented as a single numerical value."
        )
        final_answer = await self.revise(instruction=refinement_instruction, context=best_solution)

        return final_answer