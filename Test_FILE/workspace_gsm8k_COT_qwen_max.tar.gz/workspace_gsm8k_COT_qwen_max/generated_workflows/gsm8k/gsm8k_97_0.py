# Workflow ID: gsm8k_97_0
# Benchmark: gsm8k
# Data Indices: [175, 250]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (numerical values, relationships, units)
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, relationships, and units. "
            "Include any implicit information that can be inferred from the context. Format the output clearly."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a step-by-step solution plan
        planning_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. Include all necessary calculations, "
            "intermediate steps, and unit conversions. Ensure the plan is logically consistent and complete."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Perform calculations step by step
        calculation_instruction = (
            f"Follow this solution plan exactly:\n{solution_plan}\n"
            "Execute each step carefully, showing all intermediate results. Ensure calculations are accurate "
            "and units are consistent throughout. Provide the final result as a single numerical value."
        )
        calculated_result = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Validate and refine the solution
        refinement_instruction = (
            f"Review the following solution:\n{calculated_result}\n"
            "Check for logical consistency, unit correctness, and adherence to the problem's constraints. "
            "Refine the solution if necessary, ensuring it makes sense in the context of the problem."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=calculated_result)

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"Condense the following solution into a concise summary:\n{refined_solution}\n"
            "Focus on the final numerical answer and ensure it aligns with the problem's requirements."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer