# Workflow ID: gsm8k_345_0
# Benchmark: gsm8k
# Data Indices: [123, 754]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio
        
        # Step 1: Extract key information (numerical values, relationships, constraints, units)
        extraction_instruction = """
        Extract all numerical values, relationships, constraints, and units from the problem text. 
        Identify the question being asked and any hidden steps or intermediate calculations required. 
        Format the output clearly, labeling each piece of information.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)
        
        # Step 2: Formulate the solution strategy
        strategy_instruction = f"""
        Based on the following extracted information:
        {extracted_info}
        
        Create a step-by-step plan to solve the problem. Include:
        - The type of problem (e.g., sequential operations, rate problems)
        - The sequence of calculations required
        - Any intermediate steps or hidden calculations
        - How to handle units and ensure consistency
        
        Format the plan as a numbered list of actions.
        """
        solution_strategy = await self.generate(instruction=strategy_instruction, context=self.problem_text)
        
        # Step 3: Perform calculations
        calculation_instruction = f"""
        Execute the following solution strategy step by step:
        {solution_strategy}
        
        Perform each calculation carefully, showing intermediate results. Ensure that units are consistent and calculations are accurate.
        """
        calculations = await self.generate(instruction=calculation_instruction, context=self.problem_text)
        
        # Step 4: Verify and refine the solution
        refinement_instruction = f"""
        Critique the following solution:
        {calculations}
        
        Check for:
        - Mathematical correctness
        - Unit consistency
        - Logical coherence with the problem context
        - Any missed steps or errors
        
        Revise the solution if necessary, providing corrections and explanations.
        """
        refined_solution = await self.revise(instruction=refinement_instruction, context=calculations)
        
        # Step 5: Summarize the final answer
        summary_instruction = """
        Condense the final solution into a concise format. Highlight the numerical answer and ensure it is clear and unambiguous.
        """
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)
        
        return final_answer