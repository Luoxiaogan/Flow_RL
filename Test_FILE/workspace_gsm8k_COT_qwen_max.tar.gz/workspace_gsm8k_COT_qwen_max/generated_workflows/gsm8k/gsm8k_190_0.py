# Workflow ID: gsm8k_190_0
# Benchmark: gsm8k
# Data Indices: [176, 427]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract known information (numerical values, units, relationships)
        extraction_instruction = (
            "Extract all numerical values, units, and relationships from the problem. "
            "Include any constraints or conditions explicitly stated. "
            "Format the output as a structured list for clarity."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a detailed solution strategy
        strategy_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Create a step-by-step solution strategy to solve the problem. "
            "Clearly outline intermediate calculations, their order, and any necessary unit conversions. "
            "Ensure the strategy is comprehensive and adaptable to similar problems."
        )
        solution_strategy = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Perform calculations in parallel
        calculation_instruction_template = (
            f"Follow this solution strategy: {solution_strategy}\n"
            "Perform the calculations step by step. Ensure all intermediate results are clearly labeled. "
            "Include units and verify consistency throughout."
        )
        # Split the strategy into independent steps if possible
        steps = solution_strategy.split("\n")  # Simplistic splitting for illustration
        calculation_tasks = [
            self.generate(instruction=f"{calculation_instruction_template}\nFocus on: {step}", context=self.problem_text)
            for step in steps if step.strip()
        ]
        calculation_results = await asyncio.gather(*calculation_tasks)

        # Step 4: Validate intermediate results
        validation_instruction = (
            "Review the following calculations for correctness and consistency. "
            "Check for unit consistency, logical coherence, and adherence to the solution strategy. "
            "Provide revised results if necessary."
        )
        validated_results = await asyncio.gather(
            *[self.revise(instruction=validation_instruction, context=result) for result in calculation_results]
        )

        # Step 5: Synthesize results using Ensemble
        synthesis_instruction = (
            "Evaluate the following results and synthesize them into a single coherent solution. "
            "Ensure the final answer is consistent with the problem context and includes appropriate units."
        )
        final_solution = await self.ensemble(instruction=synthesis_instruction, contexts=validated_results)

        # Step 6: Summarize the final result
        summary_instruction = (
            "Condense the final solution into a concise statement. "
            "Include only the final numerical answer with its unit, ensuring it is clear and unambiguous."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=final_solution)

        return final_answer