# Workflow ID: gsm8k_301_0
# Benchmark: gsm8k
# Data Indices: [52, 360]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information
        extract_instruction = """
        Extract all numerical values, relationships, and units from the problem text. 
        Identify what is being asked for and list all knowns and unknowns. 
        Ensure the extracted information is complete and accurate.
        """
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Formulate a solution plan
        plan_instruction = f"""
        Based on the following extracted information: {extracted_info}
        Generate a step-by-step solution plan to solve the problem. 
        Include the sequence of operations required and any intermediate calculations.
        Ensure the plan is clear, logical, and accounts for all extracted information.
        """
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute calculations
        calculate_instruction = f"""
        Using the following solution plan: {solution_plan}
        Perform the calculations step by step. 
        Clearly show all intermediate results and ensure each step logically follows from the previous one.
        """
        calculations = await self.generate(instruction=calculate_instruction, context=self.problem_text)

        # Step 4: Validate intermediate results
        validate_instruction = f"""
        Review the following calculations: {calculations}
        Critique and refine them to ensure accuracy and consistency with the problem context. 
        Correct any errors and ensure all constraints are satisfied.
        """
        validated_results = await self.revise(instruction=validate_instruction, context=calculations)

        # Step 5: Summarize final answer
        summarize_instruction = f"""
        Based on the following validated results: {validated_results}
        Summarize the final answer in a concise format. 
        Ensure the answer is clear, makes sense in the context of the problem, and includes appropriate units if applicable.
        """
        final_answer = await self.summarize(instruction=summarize_instruction, context=validated_results)

        return final_answer