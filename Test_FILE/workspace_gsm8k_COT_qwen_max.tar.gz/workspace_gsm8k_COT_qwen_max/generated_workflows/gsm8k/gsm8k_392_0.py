# Workflow ID: gsm8k_392_0
# Benchmark: gsm8k
# Data Indices: [320, 788]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract and organize information
        extraction_instruction = (
            "Extract all numerical values, units, and relationships from the problem. "
            "Identify what is being asked and any constraints or conditions. "
            "Format the output as a structured list of key-value pairs."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan the solution
        plan_instruction = (
            f"Based on the following extracted information: {extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. "
            "Include all necessary calculations, unit conversions, and logical reasoning. "
            "Ensure the plan accounts for the problem's context and constraints."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute the plan in parallel
        execution_instruction_template = (
            "Perform the following calculation step: {step}\n"
            "Ensure the result is accurate and formatted appropriately."
        )
        steps = solution_plan.split("\n")  # Assume each line is a step
        execution_tasks = [
            self.generate(instruction=execution_instruction_template.format(step=step), context=self.problem_text)
            for step in steps if step.strip()
        ]
        intermediate_results = await asyncio.gather(*execution_tasks)

        # Step 4: Combine intermediate results into a final calculation
        combine_instruction = (
            f"Combine the following intermediate results: {intermediate_results}\n"
            "Perform any remaining calculations to arrive at the final answer. "
            "Ensure the result is a single numerical value."
        )
        final_result = await self.generate(instruction=combine_instruction, context=self.problem_text)

        # Step 5: Verify and refine the solution
        revise_instruction = (
            f"Validate the following solution: {final_result}\n"
            "Check that it makes sense in the context of the problem. "
            "Ensure all constraints are satisfied and the answer is realistic."
        )
        refined_solution = await self.revise(instruction=revise_instruction, context=self.problem_text)

        # Step 6: Summarize the final answer
        summarize_instruction = (
            f"Condense the following solution into a single numerical value: {refined_solution}\n"
            "Ensure the output is precise and formatted correctly."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=self.problem_text)

        return final_answer