# Workflow ID: gsm8k_261_0
# Benchmark: gsm8k
# Data Indices: [573, 478]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant numerical values, relationships, and constraints
        extraction_instruction = (
            "Thoroughly analyze the problem and extract all numerical values, relationships, "
            "and constraints. Include units where applicable and explicitly state what is being asked. "
            "Format the output as a structured list or table for clarity."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Construct a step-by-step solution plan
        solution_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Construct a detailed step-by-step solution plan. Identify all intermediate calculations, "
            "hidden steps, and the sequence of operations required to solve the problem. "
            "Ensure the plan is chronological and accounts for real-world constraints like units and feasibility."
        )
        solution_plan = await self.generate(instruction=solution_instruction, context=self.problem_text)

        # Step 3: Validate and refine the solution plan
        refinement_instruction = (
            "Critically evaluate the following solution plan for correctness, completeness, and clarity:\n"
            f"{solution_plan}\n"
            "Identify and correct any errors, ambiguities, or missing steps. Ensure all calculations are valid "
            "and consistent with the problem context. Format the revised solution clearly."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=solution_plan)

        # Step 4: Summarize the refined solution
        summary_instruction = (
            "Condense the following refined solution into a concise summary that highlights the key steps "
            "and the final answer:\n"
            f"{refined_solution}\n"
            "Ensure the summary is easy to follow and includes the numerical answer."
        )
        summarized_solution = await self.summarize(instruction=summary_instruction, context=refined_solution)

        # Step 5: Extract the final numerical answer
        answer_extraction_instruction = (
            "Extract the final numerical answer from the following summarized solution:\n"
            f"{summarized_solution}\n"
            "Ensure the answer is a single numerical value (integer or decimal) and matches the problem requirements."
        )
        final_answer = await self.generate(instruction=answer_extraction_instruction, context=summarized_solution)

        return final_answer