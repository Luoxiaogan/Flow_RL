# Workflow ID: gsm8k_360_0
# Benchmark: gsm8k
# Data Indices: [100, 83]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = """
        Carefully analyze the problem and extract all relevant information. 
        Identify all numerical values, units, relationships, and constraints. 
        Explicitly state what is known, what is unknown, and what needs to be calculated. 
        Ensure that all extracted information is clear and unambiguous.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan the solution approach
        planning_instruction = f"""
        Based on the extracted information: {extracted_info}
        Outline a step-by-step plan to solve the problem. 
        Identify any hidden steps or intermediate calculations required. 
        Specify the sequence of operations, ensuring unit consistency and logical flow. 
        Verify that the plan addresses all aspects of the problem.
        """
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Generate multiple solution approaches in parallel
        approach_1_instruction = f"""
        Follow this plan: {solution_plan}
        Solve the problem step by step, showing all calculations and intermediate results. 
        Ensure that each step logically follows from the previous one and adheres to the problem's constraints.
        """
        approach_2_instruction = f"""
        Follow this plan: {solution_plan}
        Solve the problem using an alternative reasoning path, if possible. 
        Focus on clarity and accuracy, ensuring that the solution is consistent with the problem's requirements.
        """
        results = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text)
        )

        # Step 4: Ensemble decision-making to select the best solution
        ensemble_instruction = """
        Evaluate the provided solutions and select the most accurate and contextually appropriate one. 
        Resolve any discrepancies between the solutions and ensure that the chosen solution is complete and correct. 
        Provide a justification for your selection.
        """
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 5: Refine the final solution
        refinement_instruction = """
        Review the selected solution for clarity, correctness, and completeness. 
        Ensure that the answer is formatted appropriately and makes sense in the context of the problem. 
        Verify that all calculations are accurate and that the solution addresses the original question.
        """
        refined_solution = await self.revise(instruction=refinement_instruction, context=final_solution)

        return refined_solution