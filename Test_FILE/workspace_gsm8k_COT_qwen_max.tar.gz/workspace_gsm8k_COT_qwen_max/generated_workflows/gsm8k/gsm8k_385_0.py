# Workflow ID: gsm8k_385_0
# Benchmark: gsm8k
# Data Indices: [208, 609]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key numerical values and relationships
        extraction_instruction = (
            "Carefully analyze the problem text and extract all numerical values, "
            "relationships, and units mentioned explicitly or implicitly. "
            "Include any fractions, percentages, ratios, or time-related information. "
            "Organize this information in a structured format for further processing."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate a step-by-step solution
        solution_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Construct a detailed step-by-step solution to solve the problem. "
            "Ensure that each step builds logically on the previous one, maintains unit consistency, "
            "and includes intermediate calculations where necessary. "
            "Clearly indicate the final answer at the end."
        )
        solution = await self.generate(instruction=solution_instruction, context=self.problem_text)

        # Step 3: Revise and refine the solution
        revision_instruction = (
            "Critically evaluate the provided solution for logical consistency, "
            "mathematical accuracy, and alignment with the problem's context. "
            "Suggest improvements or corrections if needed, and revise the solution accordingly."
        )
        refined_solution = await self.revise(instruction=revision_instruction, context=solution)

        # Step 4: Summarize and extract the final answer
        summary_instruction = (
            "Extract the final numerical answer from the refined solution. "
            "Ensure the answer is formatted appropriately as an integer or decimal, "
            "and remove any extraneous text or explanations."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer