# Workflow ID: gsm8k_312_0
# Benchmark: gsm8k
# Data Indices: [119, 763]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract known information
        extraction_instruction = """
        Analyze the problem and extract all relevant numerical values, relationships, and constraints.
        Clearly identify what is known and what is being asked.
        Ensure all units and contextual details are preserved.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate the mathematical model
        model_instruction = f"""
        Based on the following extracted information: {extracted_info}
        Translate the problem into a mathematical model or set of equations.
        Identify all unknowns, relationships, and operations needed to solve the problem.
        Ensure the model accurately reflects the problem's context and constraints.
        """
        mathematical_model = await self.generate(instruction=model_instruction, context=self.problem_text)

        # Step 3: Perform calculations step-by-step
        calculation_instruction = f"""
        Using the following mathematical model: {mathematical_model}
        Solve the problem step-by-step, showing all intermediate calculations.
        Ensure each step is clearly explained and logically follows from the previous one.
        Verify that the calculations align with the problem's context and constraints.
        """
        calculations = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Refine and verify the solution
        refinement_instruction = f"""
        Review the following solution: {calculations}
        Critique and refine it to ensure accuracy and alignment with the problem's context.
        Verify that the final answer makes sense in the real-world scenario described.
        Highlight any assumptions or simplifications made during the process.
        """
        refined_solution = await self.revise(instruction=refinement_instruction, context=calculations)

        # Step 5: Summarize the final answer
        summary_instruction = f"""
        Condense the following solution into a concise statement: {refined_solution}
        Include only the final numerical answer and any essential contextual details.
        Ensure the summary is clear, precise, and directly addresses the problem's question.
        """
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer