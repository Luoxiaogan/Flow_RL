# Workflow ID: gsm8k_143_0
# Benchmark: gsm8k
# Data Indices: [555, 136]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Carefully read the problem and extract all numerical values, relationships, and contextual clues. "
            "Identify what is being asked and categorize the information into knowns and unknowns. "
            "For example, note percentages, rates, quantities, units, and any constraints."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Construct a step-by-step solution
        solution_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "construct a step-by-step solution to the problem. "
            "Ensure each step is explicitly stated and logically follows from the previous one. "
            "Include intermediate calculations and verify unit consistency throughout."
        )
        step_by_step_solution = await self.generate(instruction=solution_instruction, context=self.problem_text)

        # Step 3: Validate and refine the solution
        refinement_instruction = (
            "Critique the following solution for logical consistency, arithmetic accuracy, and unit correctness. "
            "Refine it if necessary, providing corrections or improvements where needed."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=step_by_step_solution)

        # Step 4: Extract the final answer
        final_answer_instruction = (
            "From the refined solution, identify and summarize the final numerical answer. "
            "Ensure the answer is clearly stated and formatted correctly."
        )
        final_answer = await self.summarize(instruction=final_answer_instruction, context=refined_solution)

        return final_answer