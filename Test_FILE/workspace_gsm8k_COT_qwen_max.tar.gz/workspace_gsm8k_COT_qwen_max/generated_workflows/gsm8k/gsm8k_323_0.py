# Workflow ID: gsm8k_323_0
# Benchmark: gsm8k
# Data Indices: [370, 452]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract known values and relationships
        extraction_instruction = (
            "Extract all numerical values, units, and relationships from the problem. "
            "Include any constraints, conditions, or contextual information that might affect the solution. "
            "Format the output as a structured list for clarity."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate the solution plan
        plan_instruction = (
            f"Based on the following extracted information: {extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. "
            "Include intermediate calculations, the order of operations, and how to handle units consistently. "
            "Ensure the plan accounts for all constraints and contextual factors."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Perform calculations
        calculation_instruction = (
            f"Follow this solution plan: {solution_plan}\n"
            "Execute each step of the plan, performing all necessary calculations. "
            "Include intermediate results and ensure unit consistency throughout. "
            "If there are multiple valid approaches, explore them in parallel."
        )
        calculation_results = await asyncio.gather(
            self.generate(instruction=calculation_instruction, context=self.problem_text),
            self.generate(instruction=calculation_instruction, context=self.problem_text)  # Parallel exploration
        )

        # Step 4: Validate and refine the solution
        refinement_instruction = (
            "Critique the following calculated results: {results}\n"
            "Ensure they make sense in the context of the problem. Check for errors, inconsistencies, "
            "or unrealistic values. Suggest refinements if necessary."
        )
        refined_solution = await self.revise(
            instruction=refinement_instruction.format(results=calculation_results),
            context=self.problem_text
        )

        # Step 5: Summarize the final answer
        summary_instruction = (
            "Condense the following refined solution into a single numerical value with appropriate units: "
            "{solution}\nEnsure the final answer is clear, concise, and aligns with the problem's requirements."
        )
        final_answer = await self.summarize(
            instruction=summary_instruction.format(solution=refined_solution),
            context=self.problem_text
        )

        return final_answer