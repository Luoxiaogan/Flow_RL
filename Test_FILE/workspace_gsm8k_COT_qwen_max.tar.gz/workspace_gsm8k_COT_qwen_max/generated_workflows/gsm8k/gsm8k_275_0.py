# Workflow ID: gsm8k_275_0
# Benchmark: gsm8k
# Data Indices: [311, 336]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract known information
        extraction_instruction = (
            "Extract all numerical values, units, relationships, and constraints from the problem. "
            "Identify any implicit steps or intermediate calculations required to solve the problem. "
            "Ensure the extracted information is clear and organized."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Identify problem type and plan steps
        planning_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Determine the type of problem (e.g., sequential operations, rate problems, proportional reasoning). "
            "Outline the necessary steps to solve the problem, including any intermediate calculations. "
            "Ensure the plan is logical and accounts for all constraints."
        )
        problem_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Perform calculations in parallel
        calculation_instructions = []
        for step in ["Step 1", "Step 2", "Step 3"]:  # Placeholder for dynamic step generation
            calc_instruction = (
                f"Using the extracted information: {extracted_info}\n"
                f"and the problem plan: {problem_plan}\n"
                f"Perform the calculation for {step}. Ensure all units and constraints are respected."
            )
            calculation_instructions.append(calc_instruction)

        calculations = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in calculation_instructions]
        )

        # Step 4: Validate intermediate results
        revised_results = await asyncio.gather(
            *[self.revise(instruction="Critique and refine this result to ensure accuracy and consistency.", context=result)
              for result in calculations]
        )

        # Step 5: Combine results into a final answer
        ensemble_instruction = (
            "Synthesize the following results into a single coherent answer. "
            "Ensure the final answer satisfies the problem requirements and makes sense in context."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=revised_results)

        # Step 6: Summarize the solution
        summary_instruction = (
            "Summarize the entire reasoning process and the final answer. "
            "Ensure the summary is concise, clear, and verifies the correctness of the solution."
        )
        solution_summary = await self.summarize(instruction=summary_instruction, context=final_answer)

        return solution_summary