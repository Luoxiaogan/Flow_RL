# Workflow ID: gsm8k_281_0
# Benchmark: gsm8k
# Data Indices: [0, 271]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract numerical values, units, and relationships
        extraction_instruction = (
            "Extract all numerical values, their associated units, and any relationships or constraints "
            "mentioned in the problem. Clearly identify what the question is asking for and any intermediate "
            "steps that might be required to solve it."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Perform step-by-step reasoning
        reasoning_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem step by step. "
            "Ensure proper sequencing of operations, handle unit consistency, and include any hidden "
            "calculations or implicit steps. Provide intermediate results at each step."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Validate the reasoning
        validation_instruction = (
            "Critique the following reasoning: {reasoning_result}. Ensure that all steps are logically "
            "correct, align with the problem's context, and lead to a valid solution. Suggest improvements "
            "if necessary."
        )
        validated_reasoning = await self.revise(
            instruction=validation_instruction.format(reasoning_result=reasoning_result),
            context=reasoning_result
        )

        # Step 4: Extract the final answer
        summarization_instruction = (
            "Condense the following validated reasoning into a single numerical answer: {validated_reasoning}. "
            "Ensure the output explicitly states the final value and its unit, if applicable."
        )
        final_answer = await self.summarize(
            instruction=summarization_instruction.format(validated_reasoning=validated_reasoning),
            context=validated_reasoning
        )

        return final_answer