# Workflow ID: gsm8k_285_0
# Benchmark: gsm8k
# Data Indices: [698, 409]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = """
        Extract all numerical values, units, relationships, and constraints from the problem. 
        Organize them into categories: known values, unknowns, operations required, and any contextual constraints.
        Ensure that the output is structured and easy to use for subsequent steps.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate step-by-step reasoning plans in parallel
        reasoning_instruction = f"""
        Based on the following extracted information: {extracted_info}
        Create a detailed step-by-step reasoning plan to solve the problem. Include:
        - The sequence of mathematical operations
        - Intermediate calculations
        - Unit tracking and consistency
        - Any assumptions or logical deductions
        Ensure the plan is comprehensive and accounts for all aspects of the problem.
        """
        reasoning_paths = await asyncio.gather(
            self.generate(instruction=reasoning_instruction, context=self.problem_text),
            self.generate(instruction=reasoning_instruction, context=self.problem_text)
        )

        # Step 3: Validate and refine reasoning paths
        refinement_instruction = """
        Critique the provided reasoning plan. Check for:
        - Logical consistency
        - Correctness of calculations
        - Adherence to the problem context
        - Proper handling of units and constraints
        Provide suggestions for improvement if necessary.
        """
        refined_paths = await asyncio.gather(
            self.revise(instruction=refinement_instruction, context=reasoning_paths[0]),
            self.revise(instruction=refinement_instruction, context=reasoning_paths[1])
        )

        # Step 4: Select the best solution using Ensemble
        ensemble_instruction = """
        Evaluate the provided reasoning plans and select the most accurate and contextually appropriate solution. 
        Consider:
        - Completeness of the reasoning
        - Consistency with the problem constraints
        - Clarity and correctness of calculations
        If possible, synthesize parts of both plans to create an optimal solution.
        """
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_paths)

        return final_solution