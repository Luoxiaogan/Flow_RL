# Workflow ID: gsm8k_361_0
# Benchmark: gsm8k
# Data Indices: [138, 797]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all numerical values, units, and relationships
        extraction_instruction = (
            "Extract all numerical values, units, and relationships from the problem. "
            "Identify the known quantities and the unknowns explicitly. "
            "Organize the information in a structured format for further processing."
        )
        extracted_data = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Perform intermediate calculations
        calculation_instruction = (
            f"Based on the extracted data: {extracted_data}, perform all necessary intermediate calculations. "
            "Break the problem into smaller steps and solve each step systematically. "
            "Ensure that units are consistent throughout the calculations. "
            "If there are hidden steps not explicitly stated in the problem, identify and address them."
        )
        intermediate_results = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 3: Validate and refine the intermediate results
        refinement_instruction = (
            "Review the intermediate results for accuracy. "
            "Check for unit consistency, logical correctness, and adherence to the problem constraints. "
            "Refine the results if necessary, providing detailed reasoning for any changes."
        )
        refined_results = await self.revise(instruction=refinement_instruction, context=intermediate_results)

        # Step 4: Summarize the final answer
        summary_instruction = (
            "Condense the refined results into a single numerical answer. "
            "Ensure the output is in the required format (integer or decimal). "
            "Provide a brief explanation of how the final answer was derived."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_results)

        return final_answer