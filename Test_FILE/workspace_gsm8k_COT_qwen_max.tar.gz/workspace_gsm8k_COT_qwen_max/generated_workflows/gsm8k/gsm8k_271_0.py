# Workflow ID: gsm8k_271_0
# Benchmark: gsm8k
# Data Indices: [584, 304]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information (numbers, relationships, question)
        extraction_instruction = (
            "Extract all numerical values, relationships (e.g., 'three times more'), "
            "units (e.g., dollars, hours), and the specific question being asked. "
            "Format the output clearly, grouping related information together."
        )
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Construct a step-by-step solution plan
        solution_plan_instruction = (
            f"Based on the extracted information: {extraction} "
            "Construct a detailed step-by-step plan to solve the problem. "
            "Include all necessary calculations, intermediate steps, and unit conversions. "
            "Ensure the plan is chronological and logically consistent."
        )
        solution_plan = await self.generate(instruction=solution_plan_instruction, context=self.problem_text)

        # Step 3: Perform intermediate calculations in parallel
        calculation_steps = solution_plan.split("\n")  # Split into individual steps
        calculation_tasks = [
            self.generate(
                instruction=f"Perform the following calculation step: {step}. "
                            "Ensure the result is accurate and includes appropriate units.",
                context=self.problem_text
            )
            for step in calculation_steps if step.strip()
        ]
        intermediate_results = await asyncio.gather(*calculation_tasks)

        # Step 4: Revise intermediate results for accuracy
        revision_tasks = [
            self.revise(
                instruction="Critique and refine the following calculation result. "
                            "Check for arithmetic errors, unit consistency, and logical correctness.",
                context=result
            )
            for result in intermediate_results
        ]
        revised_results = await asyncio.gather(*revision_tasks)

        # Step 5: Synthesize the final answer
        synthesis_instruction = (
            f"Combine the following revised results: {revised_results}. "
            "Synthesize the final answer, ensuring it directly addresses the question. "
            "Include units and verify that the answer makes sense in the context of the problem."
        )
        final_answer = await self.summarize(instruction=synthesis_instruction, context=self.problem_text)

        return final_answer