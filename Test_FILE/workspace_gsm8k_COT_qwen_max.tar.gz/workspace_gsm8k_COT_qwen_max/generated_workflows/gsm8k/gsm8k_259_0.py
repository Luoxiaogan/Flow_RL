# Workflow ID: gsm8k_259_0
# Benchmark: gsm8k
# Data Indices: [150, 125]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information from the problem
        extraction_instruction = (
            "Extract all numerical values, units, relationships, and the final goal from the problem. "
            "Format the output as follows:\n"
            "- Numerical Values: List all numbers with their units.\n"
            "- Relationships: Describe how the numbers relate to each other.\n"
            "- Goal: Clearly state what the problem is asking for."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan the solution based on the extracted information
        planning_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Create a step-by-step plan to solve the problem. "
            "Include intermediate calculations, the order of operations, and how to handle units consistently. "
            "Ensure the plan is detailed and logical."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Execute intermediate calculations in parallel
        # Dynamically construct instructions for each step in the plan
        calculation_instructions = []
        for i, step in enumerate(solution_plan.split("\n")):
            if step.strip():  # Ignore empty lines
                calculation_instructions.append(
                    f"Perform the following step from the solution plan:\n{step}\n"
                    "Provide the result with appropriate units and reasoning."
                )

        # Execute calculations in parallel
        intermediate_results = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in calculation_instructions]
        )

        # Step 4: Synthesize the final answer
        synthesis_instruction = (
            "Combine the following intermediate results to compute the final answer:\n"
            + "\n".join(intermediate_results) + "\n"
            "Ensure the final answer is consistent with the problem's context and units. "
            "Verify that the answer makes sense logically."
        )
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=intermediate_results)

        # Step 5: Refine and validate the final solution
        refinement_instruction = (
            f"Critique and refine the following solution:\n{final_answer}\n"
            "Ensure the answer is accurate, well-reasoned, and formatted correctly. "
            "Check for consistency with the problem's context and units."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        return refined_answer