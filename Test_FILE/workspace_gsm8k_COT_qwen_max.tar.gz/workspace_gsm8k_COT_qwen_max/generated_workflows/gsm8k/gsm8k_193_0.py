# Workflow ID: gsm8k_193_0
# Benchmark: gsm8k
# Data Indices: [358, 689]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information (numerical values, relationships, constraints)
        extraction_instruction = """
        Analyze the problem and extract all numerical values, relationships, and constraints. 
        Clearly list each piece of information and explain its relevance to solving the problem. 
        Ensure you capture units (if any) and any implicit assumptions.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan the solution strategy
        planning_instruction = f"""
        Based on the extracted information: {extracted_info}
        Create a step-by-step plan to solve the problem. 
        Identify intermediate calculations, sequence operations logically, and ensure unit consistency. 
        Explicitly state any assumptions or simplifications made during planning.
        """
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Execute the calculations
        execution_instruction = f"""
        Follow the solution plan: {solution_plan}
        Perform each calculation step-by-step, recording intermediate results explicitly. 
        Ensure each step logically follows from the previous one and adheres to the problem's context.
        """
        calculation_results = await self.generate(instruction=execution_instruction, context=self.problem_text)

        # Step 4: Validate the solution
        validation_instruction = f"""
        Critique the solution: {calculation_results}
        Verify that the final result makes sense in the context of the problem. 
        Check for realism (e.g., no negative or fractional values where inappropriate), unit consistency, and logical coherence. 
        Refine the solution if necessary.
        """
        validated_solution = await self.revise(instruction=validation_instruction, context=calculation_results)

        # Step 5: Summarize the final answer
        summarization_instruction = f"""
        From the validated solution: {validated_solution}
        Extract and present the final numerical answer clearly and concisely. 
        Ensure the answer is formatted as a single number (integer or decimal) without additional explanations.
        """
        final_answer = await self.summarize(instruction=summarization_instruction, context=validated_solution)

        return final_answer