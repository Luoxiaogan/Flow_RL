# Workflow ID: gsm8k_178_0
# Benchmark: gsm8k
# Data Indices: [784, 545]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract key information
        extract_instruction = (
            "Carefully analyze the problem and extract all numerical values, relationships, "
            "and constraints. Include units (if any) and clearly label each piece of information."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Plan the solution
        plan_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Devise a step-by-step plan to solve the problem. Include all necessary calculations, "
            "intermediate steps, and unit conversions. Ensure the plan is clear and logically ordered."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute the plan
        execute_instruction = (
            f"Follow this solution plan step by step:\n{solution_plan}\n"
            "Perform all calculations and document intermediate results. Ensure the final answer "
            "is explicitly stated and includes appropriate units."
        )
        executed_solution = await self.generate(instruction=execute_instruction, context=self.problem_text)

        # Step 4: Verify the solution
        verify_instruction = (
            f"Review the following solution:\n{executed_solution}\n"
            "Check for correctness by verifying calculations, ensuring unit consistency, and confirming "
            "that the answer makes logical sense in the context of the problem. Suggest improvements if needed."
        )
        verified_solution = await self.revise(instruction=verify_instruction, context=executed_solution)

        # Step 5: Summarize the result
        summarize_instruction = (
            f"Summarize the following solution into a concise format:\n{verified_solution}\n"
            "Include the final answer and any key intermediate results. Ensure the summary is clear and easy to understand."
        )
        final_summary = await self.summarize(instruction=summarize_instruction, context=verified_solution)

        return final_summary