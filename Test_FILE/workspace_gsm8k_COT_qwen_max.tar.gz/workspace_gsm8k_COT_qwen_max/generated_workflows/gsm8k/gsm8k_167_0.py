# Workflow ID: gsm8k_167_0
# Benchmark: gsm8k
# Data Indices: [19, 249]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract numerical values, units, relationships, and constraints
        extraction_instruction = (
            "Thoroughly analyze the problem and extract all numerical values, units, "
            "relationships, and constraints. Organize them clearly, specifying their roles "
            "in the problem (e.g., rates, totals, differences)."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Create a structured plan for solving the problem
        planning_instruction = (
            f"Based on the following extracted information: {extracted_info}\n"
            "Create a step-by-step plan to solve the problem. Include all intermediate calculations, "
            "identify hidden steps, and ensure the sequence of operations is correct. "
            "Highlight any proportional relationships, rates, or conversions needed."
        )
        problem_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Execute the plan and compute the solution
        solution_instruction = (
            f"Using the following plan: {problem_plan}\n"
            "Perform the calculations step-by-step. Ensure all intermediate results are explicit, "
            "and verify that the units and constraints are consistent throughout. "
            "If there are multiple steps, execute them sequentially or in parallel as appropriate."
        )
        solution_result = await self.generate(instruction=solution_instruction, context=self.problem_text)

        # Optional Step 4: Revise the solution for accuracy and clarity
        revision_instruction = (
            "Review the following solution for accuracy, logical consistency, and clarity. "
            "Identify and correct any errors, ambiguities, or missing steps."
        )
        revised_solution = await self.revise(instruction=revision_instruction, context=solution_result)

        # Step 5: Summarize the final answer
        summarization_instruction = (
            "Condense the following solution into a single numerical value, ensuring it is "
            "accurate and makes sense in the context of the problem. Include the appropriate units if applicable."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=revised_solution)

        return final_answer