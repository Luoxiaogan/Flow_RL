# Workflow ID: gsm8k_134_0
# Benchmark: gsm8k
# Data Indices: [651, 74]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem text
        extraction_instruction = (
            "Extract all numerical values, units, and relationships from the problem. "
            "Identify what is being asked and list the knowns and unknowns. "
            "Format the output as a structured summary."
        )
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan the solution based on the extracted information
        planning_instruction = (
            f"Given the following extracted information: {extraction}\n"
            "Plan a step-by-step solution to calculate the final answer. "
            "Include all necessary operations, intermediate results, and unit conversions. "
            "Ensure the plan is clear and logical."
        )
        plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Execute the calculations and refine the solution
        execution_instruction = (
            f"Follow this plan: {plan}\n"
            "Perform the calculations step by step. Ensure accuracy and proper handling of units. "
            "If any errors or ambiguities arise, address them explicitly."
        )
        raw_solution = await self.generate(instruction=execution_instruction, context=self.problem_text)

        refinement_instruction = (
            "Review the following solution and refine it if necessary. "
            "Check for calculation errors, unit consistency, and logical coherence. "
            "Ensure the final result is a single numerical value."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=raw_solution)

        # Step 4: Summarize the final answer
        summarization_instruction = (
            "Extract the final numerical answer from the following solution. "
            "Ensure the answer is precise and formatted correctly."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_solution)

        return final_answer