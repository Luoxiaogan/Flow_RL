# Workflow ID: gsm8k_195_0
# Benchmark: gsm8k
# Data Indices: [691, 287]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Thoroughly analyze the problem to identify all numerical values, relationships, and constraints. "
            "Categorize the information into known values, unknowns, and operations needed. "
            "Include any units, fractions, percentages, or contextual details explicitly mentioned."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate a step-by-step solution plan
        plan_instruction = (
            f"Based on the extracted information: {extracted_info}, "
            "create a detailed step-by-step plan to solve the problem. "
            "Include intermediate calculations, hidden steps, and any necessary unit conversions. "
            "Ensure the plan is logically structured and accounts for all constraints."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Generate multiple solution approaches in parallel
        approach_1_instruction = (
            f"Follow this solution plan: {solution_plan}. "
            "Execute the calculations step by step, showing all intermediate results. "
            "Ensure the final answer is a single numerical value."
        )
        approach_2_instruction = (
            f"Reinterpret the problem and propose an alternative solution approach. "
            "Execute the calculations step by step, showing all intermediate results. "
            "Ensure the final answer is a single numerical value."
        )
        approaches = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text)
        )

        # Step 4: Ensemble to select the best solution
        ensemble_instruction = (
            "Evaluate the following candidate solutions and select the most accurate and logical one. "
            "If they are equivalent, choose either. If they differ, synthesize a new solution combining their strengths."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=approaches)

        # Step 5: Validate and refine the solution
        refinement_instruction = (
            "Critically review the solution for accuracy, logical consistency, and clarity. "
            "Ensure all steps are justified and the final answer makes sense in the problem context."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 6: Summarize the final answer
        summary_instruction = (
            "Extract the final numerical answer from the solution. "
            "Ensure it is presented as a single value without additional explanation."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer