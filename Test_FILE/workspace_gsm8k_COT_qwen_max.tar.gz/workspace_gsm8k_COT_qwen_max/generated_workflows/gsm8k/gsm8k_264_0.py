# Workflow ID: gsm8k_264_0
# Benchmark: gsm8k
# Data Indices: [67, 699]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (numerical values, relationships, constraints)
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, relationships, and constraints. "
            "Include any implicit information such as units, rates, or proportional relationships. "
            "Organize the extracted information into a structured format for further processing."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a solution strategy
        strategy_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Devise a step-by-step solution strategy to solve the problem. "
            "Clearly identify the sequence of operations (e.g., addition, multiplication, etc.) required. "
            "Ensure the strategy accounts for any constraints or conditions mentioned in the problem. "
            "Present the strategy in a logical and chronological order."
        )
        solution_strategy = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Execute calculations step by step
        calculation_instruction = (
            f"Using the following solution strategy:\n{solution_strategy}\n"
            "Perform the calculations step by step. Maintain intermediate results and ensure unit consistency. "
            "If any additional clarifications or assumptions are needed, state them explicitly. "
            "Provide the final result along with its context (e.g., units, interpretation)."
        )
        calculated_result = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Validate and refine the result
        validation_instruction = (
            f"Review the following result:\n{calculated_result}\n"
            "Critique and refine it based on the original problem context. "
            "Ensure the result is mathematically correct, logically consistent, and makes sense in the real-world scenario. "
            "If necessary, suggest corrections or improvements."
        )
        refined_result = await self.revise(instruction=validation_instruction, context=calculated_result)

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"Condense the following refined result into a concise answer:\n{refined_result}\n"
            "Ensure the summary includes the final numerical value and any relevant context (e.g., units, interpretation). "
            "The output should be clear and directly address the problem question."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_result)

        return final_answer