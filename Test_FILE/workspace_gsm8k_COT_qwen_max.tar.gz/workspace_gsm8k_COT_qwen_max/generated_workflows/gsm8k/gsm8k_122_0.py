# Workflow ID: gsm8k_122_0
# Benchmark: gsm8k
# Data Indices: [639, 665]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information
        extraction_instruction = """Extract all numerical values, units, entities, and relationships from the problem. 
        Clearly identify what is given and what is being asked. Include any implicit information or constraints."""
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate the solution approach
        planning_instruction = f"""Based on the following extracted information: {extracted_info}
        Create a detailed plan for solving the problem. Identify all intermediate steps, determine the order of operations, 
        and consider any contextual constraints such as unit consistency and real-world limitations."""
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Execute calculations in parallel
        calculation_instructions = []
        for step in solution_plan.split("\n"):
            if "Calculate" in step or "Compute" in step:
                calculation_instructions.append(
                    f"Perform the following calculation: {step}. Ensure all units are consistent."
                )

        calculations = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in calculation_instructions]
        )

        # Step 4: Synthesize results
        synthesis_instruction = f"""Combine the following results into a coherent final answer: {calculations}.
        Verify that the answer makes sense in the context of the problem and ensure all units are consistent."""
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=calculations)

        # Step 5: Refine and validate the final answer
        refinement_instruction = f"""Critique and refine the following answer: {final_answer}.
        Ensure it is accurate, well-justified, and adheres to any contextual constraints mentioned in the problem."""
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        return refined_answer