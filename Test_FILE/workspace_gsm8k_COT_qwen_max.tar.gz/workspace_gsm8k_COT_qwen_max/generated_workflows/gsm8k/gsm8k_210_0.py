# Workflow ID: gsm8k_210_0
# Benchmark: gsm8k
# Data Indices: [403, 222]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key numerical values and relationships
        extraction_instruction = (
            "Extract all numerical values, units, and relationships from the problem. "
            "Identify what is known and what needs to be calculated. "
            "Organize the information clearly, specifying quantities, units, and their roles in the problem."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate a step-by-step solution plan
        plan_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. "
            "Include intermediate calculations, unit conversions, and any necessary assumptions. "
            "Ensure the plan is chronological and logically consistent."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Perform calculations in sequence
        calculation_instruction = (
            f"Follow this solution plan: {solution_plan}\n"
            "Perform the calculations step-by-step, documenting intermediate results. "
            "Validate each result to ensure it makes sense in the context of the problem. "
            "If any step requires refinement, note it explicitly."
        )
        calculations = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Optional: Refine calculations if necessary
        refine_instruction = (
            f"Review the calculations: {calculations}\n"
            "Check for errors, inconsistencies, or missing steps. "
            "Refine the calculations to ensure accuracy and completeness."
        )
        refined_calculations = await self.revise(instruction=refine_instruction, context=calculations)

        # Step 4: Summarize the final answer
        summary_instruction = (
            f"Based on the refined calculations: {refined_calculations}\n"
            "Condense the solution into a concise final answer. "
            "Ensure the answer is a single numerical value (integer or decimal) and includes appropriate units if necessary."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_calculations)

        return final_answer