# Workflow ID: gsm8k_260_0
# Benchmark: gsm8k
# Data Indices: [596, 230]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract known information (numerical values, units, relationships)
        extraction_instruction = (
            "Thoroughly analyze the problem and extract all numerical values, units, and relationships. "
            "Include rates, totals, and any constraints mentioned in the problem. "
            "Organize the information clearly for subsequent steps."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a detailed solution plan
        plan_instruction = (
            f"Based on the extracted information: {extracted_info} "
            "Create a step-by-step plan to solve the problem. "
            "Ensure the plan accounts for all given data, handles units consistently, "
            "and sequences calculations logically. Include intermediate steps and checks."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute the solution plan and perform calculations
        execution_instruction = (
            f"Follow this solution plan: {solution_plan} "
            "Perform all calculations step by step. "
            "Clearly show intermediate results and ensure units are handled correctly. "
            "Verify that each step aligns with the problem's requirements."
        )
        raw_solution = await self.generate(instruction=execution_instruction, context=self.problem_text)

        # Step 4: Revise and validate the solution
        revision_instruction = (
            "Critically review the solution provided. "
            "Check for calculation errors, logical inconsistencies, and adherence to the problem's constraints. "
            "Ensure the final answer is reasonable and matches the expected format."
        )
        refined_solution = await self.revise(instruction=revision_instruction, context=raw_solution)

        # Step 5: Summarize the final answer
        summary_instruction = (
            "Condense the solution into a single numerical value representing the final answer. "
            "Ensure the answer is clear, precise, and formatted appropriately."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer