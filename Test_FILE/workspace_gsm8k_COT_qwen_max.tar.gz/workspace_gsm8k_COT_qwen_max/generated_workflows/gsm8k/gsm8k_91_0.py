# Workflow ID: gsm8k_91_0
# Benchmark: gsm8k
# Data Indices: [446, 302]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant numerical values, relationships, and constraints
        extract_instruction = (
            "Thoroughly analyze the problem and extract all numerical values, relationships, "
            "and constraints. Identify known quantities, unknowns, units, and any implicit or "
            "explicit relationships between entities. Present the extracted information in a "
            "structured format."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Model the problem mathematically
        model_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Construct a step-by-step mathematical model to solve the problem. Translate the "
            "textual description into a sequence of mathematical operations (addition, subtraction, "
            "multiplication, division, etc.). Ensure that the steps are logical, ordered, and "
            "account for all constraints."
        )
        mathematical_model = await self.generate(instruction=model_instruction, context=self.problem_text)

        # Step 3: Perform sequential calculations
        calculate_instruction = (
            f"Using the following mathematical model:\n{mathematical_model}\n"
            "Execute the calculations step by step. Clearly show all intermediate results and "
            "ensure that each step logically follows from the previous one. Verify that the "
            "calculations are consistent with the problem's constraints and units."
        )
        solution = await self.generate(instruction=calculate_instruction, context=self.problem_text)

        # Step 4: Validate and refine the solution
        validate_instruction = (
            "Critique and refine the following solution:\n"
            f"{solution}\n"
            "Check for logical consistency, unit correctness, and adherence to real-world constraints. "
            "Identify and correct any errors or inconsistencies. Ensure that the solution makes sense "
            "in the context of the problem."
        )
        refined_solution = await self.revise(instruction=validate_instruction, context=solution)

        # Step 5: Summarize the final answer
        summarize_instruction = (
            "Condense the following solution into a single numerical answer:\n"
            f"{refined_solution}\n"
            "Ensure that the final result is clear, unambiguous, and formatted appropriately."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_answer