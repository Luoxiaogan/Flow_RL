# Workflow ID: gsm8k_13_0
# Benchmark: gsm8k
# Data Indices: [349, 368]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = """
        Analyze the problem thoroughly and extract all relevant information, including:
        - Numerical values and their associated units (e.g., dollars, minutes, pages)
        - Relationships between quantities (e.g., rates, proportions, comparisons)
        - The specific question being asked and what needs to be calculated
        Ensure that all extracted information is presented clearly and concisely.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a step-by-step solution strategy
        strategy_instruction = f"""
        Based on the following extracted information:
        {extracted_info}
        
        Develop a detailed step-by-step plan to solve the problem. Include:
        - The sequence of mathematical operations required
        - Any intermediate calculations or hidden steps
        - How units will be handled throughout the process
        - Verification steps to ensure the solution is correct
        The plan should be comprehensive and leave no ambiguity.
        """
        solution_strategy = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Execute parallel solution approaches
        approach_1_instruction = f"""
        Solve the problem using the following strategy:
        {solution_strategy}
        
        Focus on direct calculation and ensure all steps are clearly documented.
        """
        approach_2_instruction = f"""
        Solve the problem using the following strategy:
        {solution_strategy}
        
        Focus on verification through proportional reasoning or unit analysis.
        """

        results = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text)
        )

        # Step 4: Validate and select the best solution
        ensemble_instruction = f"""
        Evaluate the following candidate solutions:
        - Solution 1: {results[0]}
        - Solution 2: {results[1]}
        
        Select the most accurate and well-reasoned solution. If there are discrepancies, resolve them by analyzing intermediate steps and ensuring consistency with the problem context.
        """
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 5: Refine the final answer
        refinement_instruction = f"""
        Refine the following solution to ensure clarity and correctness:
        {final_solution}
        
        Format the final answer properly, ensuring it adheres to any specific constraints mentioned in the problem (e.g., integer vs. decimal, units).
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_solution)

        return refined_answer