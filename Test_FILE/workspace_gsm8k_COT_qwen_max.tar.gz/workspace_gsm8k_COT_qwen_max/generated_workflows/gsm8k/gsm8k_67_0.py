# Workflow ID: gsm8k_67_0
# Benchmark: gsm8k
# Data Indices: [229, 92]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract known information (numerical values, relationships, constraints)
        extraction_instruction = (
            "Extract all numerical values, relationships, and constraints from the problem. "
            "Include any relevant units (e.g., dollars, minutes, people). "
            "Ensure the extracted information is complete and unambiguous."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Identify the unknown and plan the solution
        planning_instruction = (
            f"Using the extracted information: {extracted_info}, determine what the question is asking for. "
            "Outline a step-by-step plan to solve the problem, including intermediate calculations. "
            "Ensure the plan accounts for all constraints and units."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Perform calculations step-by-step
        calculation_instruction = (
            f"Execute the following plan step-by-step: {solution_plan}. "
            "Perform each calculation explicitly, showing intermediate results. "
            "Ensure all units are consistent and calculations are accurate."
        )
        calculations = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Verify the solution
        verification_instruction = (
            f"Review the calculations: {calculations}. "
            "Critique the solution to ensure it makes sense in the context of the problem. "
            "Check for unit consistency, real-world feasibility, and adherence to the problem's constraints."
        )
        verified_solution = await self.revise(instruction=verification_instruction, context=calculations)

        # Step 5: Summarize the final answer
        summarization_instruction = (
            f"Condense the verified solution: {verified_solution} into a single numerical value. "
            "Ensure the final answer is clear, concise, and formatted correctly."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=verified_solution)

        return final_answer