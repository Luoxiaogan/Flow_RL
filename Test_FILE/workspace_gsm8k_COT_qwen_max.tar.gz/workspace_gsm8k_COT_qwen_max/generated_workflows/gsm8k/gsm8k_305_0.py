# Workflow ID: gsm8k_305_0
# Benchmark: gsm8k
# Data Indices: [157, 316]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract numerical values and relationships
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, "
            "relationships, and constraints. Include fractions, percentages, "
            "and any other mathematical operations explicitly mentioned. "
            "Organize the extracted information clearly for further processing."
        )
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Perform intermediate calculations
        calculation_instruction = (
            f"Using the extracted information: {extraction}, "
            "perform all necessary intermediate calculations step-by-step. "
            "Ensure that each step logically follows from the previous one. "
            "Include fractions, percentages, and unit conversions as needed. "
            "Provide clear intermediate results for validation."
        )
        intermediate_results = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 3: Validate and refine intermediate results
        refinement_instruction = (
            "Review the intermediate calculations and ensure they are accurate and consistent "
            "with the problem requirements. Identify and correct any errors or inconsistencies. "
            "Refine the results to ensure they are ready for the final calculation."
        )
        refined_results = await self.revise(instruction=refinement_instruction, context=intermediate_results)

        # Step 4: Perform final calculation and extract the answer
        final_instruction = (
            f"Based on the refined intermediate results: {refined_results}, "
            "perform the final calculation to arrive at the answer. Ensure the result "
            "is consistent with the problem context, including units and constraints. "
            "Present the final answer as a single numerical value."
        )
        final_answer = await self.generate(instruction=final_instruction, context=self.problem_text)

        return final_answer