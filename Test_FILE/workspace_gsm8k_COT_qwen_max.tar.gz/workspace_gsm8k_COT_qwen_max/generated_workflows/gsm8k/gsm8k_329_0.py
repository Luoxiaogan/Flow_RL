# Workflow ID: gsm8k_329_0
# Benchmark: gsm8k
# Data Indices: [253, 723]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information (numerical values, units, relationships)
        extraction_instruction = (
            "Extract all numerical values, units, relationships, and constraints from the problem. "
            "Categorize them clearly (e.g., known values, unknowns, operations needed)."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan the solution steps
        planning_instruction = (
            f"Given the extracted information: {extracted_info}, "
            "outline the sequence of steps needed to solve the problem. "
            "Include intermediate calculations, unit conversions, and any hidden steps."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Perform calculations
        calculation_instruction = (
            f"Follow this plan step-by-step: {solution_plan}. "
            "Perform all calculations explicitly, showing intermediate results. "
            "Ensure unit consistency and proper handling of constraints."
        )
        calculations = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Verify and refine the solution
        refinement_instruction = (
            f"Review the calculations: {calculations}. "
            "Check for accuracy, unit consistency, and alignment with the problem context. "
            "Refine the solution if necessary."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=calculations)

        # Step 5: Summarize the final answer
        summarization_instruction = (
            f"Condense the refined solution: {refined_solution} into a single numerical value. "
            "Ensure the output is clear and matches the required format."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_solution)

        return final_answer