# Workflow ID: gsm8k_19_0
# Benchmark: gsm8k
# Data Indices: [705, 97]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information
        extraction_instruction = (
            "Extract all numerical values, units, relationships, and the core question from the problem. "
            "Organize the information clearly, labeling knowns and unknowns. "
            "Ensure units are explicitly stated and any implicit relationships are made explicit."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate a detailed solution plan
        plan_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Create a step-by-step plan to solve the problem. Include intermediate calculations, "
            "unit conversions, and any necessary contextual constraints. Ensure the plan is clear, "
            "logical, and accounts for all extracted information."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Generate two independent solutions
        solution_instruction = (
            f"Follow this plan:\n{solution_plan}\n"
            "Solve the problem step by step, showing all intermediate results. "
            "Ensure calculations are accurate, units are consistent, and the final answer is boxed."
        )
        solution1, solution2 = await asyncio.gather(
            self.generate(instruction=solution_instruction, context=self.problem_text),
            self.generate(instruction=solution_instruction, context=self.problem_text)
        )

        # Step 4: Ensemble decision to select or synthesize the best solution
        ensemble_instruction = (
            "Compare the following two solutions and determine which one is more accurate and complete. "
            "If both are valid, synthesize them into a single solution. Ensure the final solution "
            "is consistent with the problem's context and constraints."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=[solution1, solution2])

        # Step 5: Verify the final solution
        verification_instruction = (
            "Review the following solution against the original problem text. "
            "Ensure it makes sense in context, adheres to real-world constraints, and is mathematically correct. "
            "Revise if necessary to fix any inconsistencies or errors."
        )
        verified_solution = await self.revise(instruction=verification_instruction, context=final_solution)

        # Step 6: Summarize the final answer
        summary_instruction = (
            "Condense the following solution into a single numerical answer. "
            "Ensure the answer is precise, includes appropriate units if necessary, and is clearly presented."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=verified_solution)

        return final_answer