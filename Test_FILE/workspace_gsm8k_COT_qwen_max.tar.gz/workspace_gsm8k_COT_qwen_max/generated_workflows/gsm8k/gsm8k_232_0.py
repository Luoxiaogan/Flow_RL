# Workflow ID: gsm8k_232_0
# Benchmark: gsm8k
# Data Indices: [399, 90]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information (numerical values, units, relationships, and the question)
        extraction_instruction = (
            "Extract all numerical values, their associated units (if any), and relationships "
            "between them from the problem. Also, identify the specific question being asked."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a step-by-step solution plan
        plan_instruction = (
            f"Given the extracted information: {extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. Include all intermediate "
            "calculations, unit conversions (if needed), and the sequence of operations."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Perform calculations based on the solution plan
        calculation_instruction = (
            f"Follow this solution plan step-by-step: {solution_plan}\n"
            "Perform all required calculations, showing intermediate results at each step. "
            "Ensure units are consistent throughout the process."
        )
        calculated_solution = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Verify the solution for correctness and context alignment
        verification_instruction = (
            f"Review the following solution: {calculated_solution}\n"
            "Critique it for correctness, logical consistency, and alignment with the problem's context. "
            "Identify and correct any errors or inconsistencies."
        )
        verified_solution = await self.revise(instruction=verification_instruction, context=calculated_solution)

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"Condense the verified solution: {verified_solution}\n"
            "Provide the final answer as a single numerical value (integer or decimal). Ensure the format "
            "matches the problem's requirements."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=verified_solution)

        return final_answer