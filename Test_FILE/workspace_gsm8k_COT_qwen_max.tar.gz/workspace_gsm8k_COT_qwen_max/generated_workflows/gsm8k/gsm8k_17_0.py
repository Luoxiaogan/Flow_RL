# Workflow ID: gsm8k_17_0
# Benchmark: gsm8k
# Data Indices: [633, 282]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract numerical values, relationships, and constraints
        extraction_instruction = """
        Thoroughly analyze the problem text to extract all numerical values, relationships, and constraints. 
        Identify the known quantities, unknowns, and any implicit steps or assumptions. 
        Organize the extracted information in a structured format, such as a list or table, 
        and ensure units and contextual relationships are preserved.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Construct a step-by-step solution plan
        solution_instruction = f"""
        Based on the extracted information: {extracted_info}
        Construct a detailed step-by-step solution plan to solve the problem. 
        Include all necessary intermediate calculations, specify the order of operations, 
        and ensure unit consistency throughout. 
        If there are multiple entities or parallel computations, clearly outline each path separately.
        """
        solution_plan = await self.generate(instruction=solution_instruction, context=self.problem_text)

        # Step 3: Execute parallel computation paths (if applicable)
        # Split the solution plan into independent paths if necessary
        paths_instruction = f"""
        Analyze the solution plan: {solution_plan}
        Identify any independent computation paths that can be executed in parallel. 
        For each path, generate a concise instruction set that specifies the exact calculations to perform.
        """
        paths = await self.generate(instruction=paths_instruction, context=self.problem_text)

        # Execute parallel computations
        path_results = await asyncio.gather(
            self.generate(instruction="Compute the first path: " + paths, context=self.problem_text),
            self.generate(instruction="Compute the second path: " + paths, context=self.problem_text)
        )

        # Step 4: Verify and refine intermediate results
        refinement_instruction = f"""
        Critically review the intermediate results: {path_results}
        Check for calculation errors, unit inconsistencies, and logical flaws. 
        Refine the results to ensure accuracy and completeness. Provide a revised version of the results.
        """
        refined_results = await self.revise(instruction=refinement_instruction, context=path_results[0])

        # Step 5: Synthesize the final answer
        synthesis_instruction = f"""
        Evaluate the refined results: {refined_results}
        Synthesize the final answer by selecting or merging the most accurate and contextually appropriate result. 
        Ensure the answer is a single numerical value and makes sense in the problem's context.
        """
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=[refined_results])

        return final_answer