# Workflow ID: gsm8k_202_0
# Benchmark: gsm8k
# Data Indices: [750, 542]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, "
            "units, relationships, and key entities. Organize the extracted "
            "information in a structured format, such as a list or table. "
            "Ensure no important detail is missed."
        )
        extracted_data = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Perform intermediate reasoning and calculations
        reasoning_instruction = (
            f"Using the following extracted data: {extracted_data}\n"
            "Solve the problem step by step. Clearly outline each calculation, "
            "ensuring proper handling of units and intermediate results. "
            "If there are multiple steps, explain them chronologically. "
            "Provide the final result in a boxed format."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Verify and refine the solution
        refinement_instruction = (
            "Critique the provided solution for correctness and completeness. "
            "Check if all calculations are accurate, units are consistent, "
            "and the result makes sense in the context of the problem. "
            "If there are errors, correct them and provide an improved version."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 4: Summarize the final answer
        summary_instruction = (
            "Extract the final numerical answer from the provided solution. "
            "Ensure the answer is precise, includes appropriate units if necessary, "
            "and matches the requirements of the problem."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        # Optional Step 5: Ensemble evaluation for robustness
        # Generate alternative solutions for comparison
        alternative_instruction_1 = (
            "Solve the problem using a different approach or sequence of calculations. "
            "Provide a complete alternative solution."
        )
        alternative_instruction_2 = (
            "Reinterpret the problem and solve it using proportional reasoning or algebraic methods. "
            "Ensure the solution is distinct from previous attempts."
        )
        alternative_results = await asyncio.gather(
            self.generate(instruction=alternative_instruction_1, context=self.problem_text),
            self.generate(instruction=alternative_instruction_2, context=self.problem_text)
        )

        # Ensemble to select the best solution
        ensemble_instruction = (
            "Compare the provided solutions and select the most accurate and complete one. "
            "Ensure the chosen solution adheres to the problem constraints and real-world context."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=[final_answer] + alternative_results)

        return best_solution