# Workflow ID: gsm8k_295_0
# Benchmark: gsm8k
# Data Indices: [564, 445]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information from the problem text
        extraction_instruction = (
            "Thoroughly analyze the problem and extract all relevant numerical values, "
            "relationships, and constraints. Ensure that you capture any implicit information "
            "or hidden steps required to solve the problem. Present the extracted information "
            "in a structured format."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Perform intermediate calculations and reasoning
        calculation_instruction_template = (
            "Based on the following extracted information:\n\n{info}\n\n"
            "Perform the necessary calculations step by step. Clearly show each intermediate "
            "result and explain your reasoning. Ensure that you handle units consistently and "
            "account for any contextual constraints."
        )
        calculation_instruction = calculation_instruction_template.format(info=extracted_info)
        
        # Split calculations into parallel tasks if possible
        calculation_tasks = [
            self.generate(instruction=calculation_instruction, context=self.problem_text),
            self.generate(instruction=calculation_instruction, context=self.problem_text)
        ]
        intermediate_results = await asyncio.gather(*calculation_tasks)

        # Step 3: Determine the final answer by synthesizing intermediate results
        ensemble_instruction = (
            "Evaluate the following candidate solutions and determine the most accurate final answer. "
            "Ensure that the selected answer is consistent with the problem's requirements and makes "
            "sense in context. If necessary, perform additional calculations to resolve discrepancies."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=intermediate_results)

        # Step 4: Validate and refine the final answer
        validation_instruction = (
            "Critique the following solution and verify that it accurately addresses the problem. "
            "Check for any errors in calculation, unit handling, or logical reasoning. Provide suggestions "
            "for improvement if necessary."
        )
        refined_answer = await self.revise(instruction=validation_instruction, context=final_answer)

        return refined_answer