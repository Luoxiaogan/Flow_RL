# Workflow ID: gsm8k_62_0
# Benchmark: gsm8k
# Data Indices: [704, 377]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all numerical values, relationships, and units
        extraction_instruction = (
            "Carefully analyze the problem text to extract all numerical values, "
            "relationships between entities, and units (e.g., dollars, hours, items). "
            "Identify what is being asked (the unknown) and any intermediate steps needed. "
            "Format the output as a structured list for clarity."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Break down the problem into smaller steps
        breakdown_instruction = (
            f"Given the extracted information: {extracted_info}, "
            "decompose the problem into a series of smaller, sequential calculations. "
            "Identify any hidden steps or implicit operations that are not explicitly stated. "
            "Provide a clear plan for solving the problem step by step."
        )
        breakdown_plan = await self.generate(instruction=breakdown_instruction, context=self.problem_text)

        # Step 3: Perform calculations in parallel where possible
        calculation_instruction = (
            "Using the breakdown plan, perform each calculation step-by-step. "
            "Ensure intermediate results are accurate and consistent with the problem context. "
            "Track units throughout the calculations to maintain consistency."
        )
        # Split the breakdown plan into individual steps
        steps = breakdown_plan.split("\n")  # Assuming each step is on a new line
        calculation_tasks = [
            self.generate(instruction=f"{calculation_instruction} Focus on this step: {step}", context=self.problem_text)
            for step in steps if step.strip()
        ]
        intermediate_results = await asyncio.gather(*calculation_tasks)

        # Step 4: Refine intermediate results for accuracy
        refined_results = await asyncio.gather(
            *[self.revise(instruction="Critically review and refine this result for accuracy.", context=result)
              for result in intermediate_results]
        )

        # Step 5: Combine results to compute the final answer
        synthesis_instruction = (
            "Combine all refined intermediate results to compute the final answer. "
            "Ensure the answer is consistent with the problem context and makes logical sense. "
            "Include appropriate units in the final result."
        )
        final_answer = await self.ensemble(
            instruction=synthesis_instruction,
            contexts=refined_results
        )

        # Step 6: Summarize the solution for clarity
        summary_instruction = (
            "Summarize the entire solution process, including key steps, intermediate results, "
            "and the final answer. Format the summary clearly and concisely."
        )
        solution_summary = await self.summarize(instruction=summary_instruction, context=final_answer)

        return solution_summary