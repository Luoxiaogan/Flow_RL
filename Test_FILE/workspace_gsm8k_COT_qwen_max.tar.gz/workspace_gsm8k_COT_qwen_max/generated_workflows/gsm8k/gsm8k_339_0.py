# Workflow ID: gsm8k_339_0
# Benchmark: gsm8k
# Data Indices: [713, 61]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (numerical values, units, relationships)
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, units, and relationships mentioned. "
            "Include any constraints or conditions that affect how these values interact. "
            "Present the extracted information in a structured format."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a step-by-step solution plan
        plan_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "create a detailed step-by-step plan to solve the problem. "
            "Clearly specify the sequence of calculations and any intermediate results required. "
            "Ensure the plan accounts for all constraints and relationships described in the problem."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Perform calculations using parallel approaches
        calculation_instruction_direct = (
            f"Follow this solution plan: {solution_plan}. "
            "Perform the calculations directly, step-by-step, and provide the final result."
        )
        calculation_instruction_algebraic = (
            f"Follow this solution plan: {solution_plan}. "
            "Use algebraic reasoning to solve the problem, defining variables and equations as needed. "
            "Provide the final result."
        )

        # Parallel execution for independent calculation methods
        results = await asyncio.gather(
            self.generate(instruction=calculation_instruction_direct, context=self.problem_text),
            self.generate(instruction=calculation_instruction_algebraic, context=self.problem_text)
        )

        # Step 4: Ensemble to select the best result
        ensemble_instruction = (
            "Evaluate the following candidate solutions and select the most accurate one. "
            "If both are valid, choose the simpler or more straightforward approach. "
            "Ensure the selected result aligns with the problem's context and constraints."
        )
        final_result = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 5: Validate and refine the result
        validation_instruction = (
            f"Review this solution: {final_result}. "
            "Check if it makes sense in the context of the problem. "
            "Verify that all calculations are correct and that the answer satisfies all constraints. "
            "Refine the solution if necessary."
        )
        refined_result = await self.revise(instruction=validation_instruction, context=final_result)

        # Step 6: Summarize the final answer
        summary_instruction = (
            f"Condense the following solution into a concise final answer: {refined_result}. "
            "Ensure the answer is clear, precise, and directly addresses the question posed in the problem."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_result)

        return final_answer