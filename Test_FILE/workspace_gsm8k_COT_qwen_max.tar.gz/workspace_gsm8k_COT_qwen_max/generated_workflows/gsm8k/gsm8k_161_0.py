# Workflow ID: gsm8k_161_0
# Benchmark: gsm8k
# Data Indices: [12, 118]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract relevant information from the problem
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, "
            "relationships, and contextual information. Include units, if any, "
            "and describe what each value represents in the problem."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a step-by-step solution strategy
        strategy_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Devise a detailed step-by-step plan to solve the problem. Include "
            "all necessary calculations, intermediate steps, and reasoning. Ensure "
            "the plan accounts for any hidden steps or implicit operations."
        )
        solution_strategy = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Execute the solution strategy
        execution_instruction = (
            f"Follow this solution strategy step by step:\n{solution_strategy}\n"
            "Perform all calculations explicitly and document intermediate results. "
            "Ensure the final result answers the question posed in the problem."
        )
        executed_solution = await self.generate(instruction=execution_instruction, context=self.problem_text)

        # Step 4: Verify and refine the solution
        verification_instruction = (
            "Review the executed solution for correctness and consistency. Check "
            "that all steps logically follow from the previous ones and that the "
            "final result makes sense in the context of the problem. Suggest "
            "improvements if necessary."
        )
        refined_solution = await self.revise(instruction=verification_instruction, context=executed_solution)

        # Step 5: Summarize the final answer
        summary_instruction = (
            "Condense the solution into a concise summary. Clearly state the "
            "final numerical answer to the problem, ensuring it is accurate and "
            "contextually appropriate."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer