# Workflow ID: gsm8k_206_0
# Benchmark: gsm8k
# Data Indices: [462, 202]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all relevant numerical values, units, and relationships
        extraction_instruction = """
        Carefully analyze the problem and extract all numerical values, units, and relationships mentioned in the text. 
        List them explicitly, ensuring no information is missed. For example:
        - Numerical values: 7.2 kilowatts, 8 hours, etc.
        - Units: kilowatts, hours, dollars, etc.
        - Relationships: consumption rate, percentage discounts, ratios, etc.
        Ensure the extracted information is complete and accurate.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Perform step-by-step reasoning to solve the problem
        reasoning_instruction = f"""
        Using the extracted information below, solve the problem step by step. Clearly show all intermediate calculations and reasoning.
        Ensure the solution adheres to mathematical principles and maintains unit consistency.
        Extracted Information:
        {extracted_info}
        Problem-Solving Steps:
        1. Identify what is being asked in the problem.
        2. Break the problem into smaller sub-problems.
        3. Solve each sub-problem sequentially, showing all calculations.
        4. Combine the results to arrive at the final answer.
        Ensure the reasoning is clear, logical, and reproducible.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Validate and refine the solution
        validation_instruction = """
        Critique the provided solution and refine it if necessary. Ensure:
        - All calculations are mathematically correct.
        - Units are consistent throughout.
        - The reasoning process is logical and follows the problem's constraints.
        - The final answer makes sense in the context of the problem.
        If any issues are found, revise the solution accordingly.
        """
        refined_solution = await self.revise(instruction=validation_instruction, context=reasoning_result)

        # Step 4: Extract the final numerical answer
        summarization_instruction = """
        From the refined solution, extract the final numerical answer. Ensure the answer:
        - Is a single numerical value (integer or decimal).
        - Includes appropriate units if necessary.
        - Matches the problem's requirements.
        Provide only the final answer without additional explanation.
        """
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_solution)

        return final_answer