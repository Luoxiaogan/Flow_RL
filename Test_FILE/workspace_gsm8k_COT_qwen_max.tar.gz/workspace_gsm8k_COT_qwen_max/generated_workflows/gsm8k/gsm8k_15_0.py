# Workflow ID: gsm8k_15_0
# Benchmark: gsm8k
# Data Indices: [583, 666]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (numerical values, relationships, constraints)
        extraction_instruction = (
            "Thoroughly analyze the problem and extract all numerical values, "
            "relationships, and constraints. Clearly label each piece of information "
            "and explain how they relate to the problem. Ensure no detail is missed."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate a step-by-step solution based on the extracted information
        solution_instruction = (
            f"Using the following extracted information: {extracted_info}\n"
            "Solve the problem step by step. Clearly show all calculations and reasoning. "
            "Ensure each step logically follows from the previous one and aligns with the problem's context. "
            "If intermediate results are needed, compute them explicitly."
        )
        initial_solution = await self.generate(instruction=solution_instruction, context=self.problem_text)

        # Step 3: Revise and validate the solution for accuracy and consistency
        revision_instruction = (
            "Critically review the following solution: {initial_solution}\n"
            "Check for any errors, inconsistencies, or missing steps. Ensure all calculations "
            "are correct and align with the problem's context. Provide suggestions for improvement "
            "if necessary."
        )
        revised_solution = await self.revise(instruction=revision_instruction, context=initial_solution)

        # Step 4: Summarize the final answer
        summarization_instruction = (
            "From the following solution: {revised_solution}\n"
            "Extract the final numerical answer. Ensure it is clearly stated and matches the problem's requirements. "
            "Include units if applicable."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=revised_solution)

        return final_answer