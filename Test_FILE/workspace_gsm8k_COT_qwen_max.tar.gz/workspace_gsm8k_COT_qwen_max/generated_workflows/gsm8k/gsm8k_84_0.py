# Workflow ID: gsm8k_84_0
# Benchmark: gsm8k
# Data Indices: [493, 440]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant numerical values, relationships, and constraints
        extraction_instruction = (
            "Thoroughly analyze the problem and extract all numerical values, relationships, and constraints. "
            "Include units, rates, and any implicit information that can be deduced. "
            "Organize the extracted data in a structured format for further processing."
        )
        extracted_data = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Model the problem mathematically and outline the solution steps
        modeling_instruction = (
            f"Based on the extracted data: {extracted_data}, "
            "create a step-by-step plan to solve the problem mathematically. "
            "Identify the sequence of operations required, including any intermediate calculations. "
            "Ensure that the plan explicitly accounts for units, constraints, and real-world feasibility."
        )
        solution_plan = await self.generate(instruction=modeling_instruction, context=self.problem_text)

        # Step 3: Perform intermediate calculations and derive the solution
        calculation_instruction = (
            f"Using the solution plan: {solution_plan}, "
            "execute the outlined steps to perform intermediate calculations. "
            "Provide explicit reasoning for each step and ensure that the results are logically consistent. "
            "Present the intermediate results in a clear and organized manner."
        )
        intermediate_solution = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Verify and refine the solution
        refinement_instruction = (
            f"Review the intermediate solution: {intermediate_solution}. "
            "Verify that the calculations are accurate and consistent with the problem's context. "
            "Check for unit consistency, logical coherence, and real-world feasibility. "
            "Refine the solution if necessary and provide the corrected version."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=intermediate_solution)

        # Step 5: Extract the final numerical answer
        final_answer_instruction = (
            "Condense the refined solution into a single numerical value representing the final answer. "
            "Ensure that the answer is presented in the correct format (integer or decimal) and includes appropriate units if necessary."
        )
        final_answer = await self.summarize(instruction=final_answer_instruction, context=refined_solution)

        return final_answer