# Workflow ID: gsm8k_384_0
# Benchmark: gsm8k
# Data Indices: [334, 141]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information from the problem text
        extraction_instruction = """
        Carefully analyze the problem and extract all numerical values, units, entities, and relationships. 
        Identify what is given (knowns) and what is being asked (unknowns). 
        Organize the extracted information in a structured format for further processing.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate a step-by-step solution based on the extracted information
        reasoning_instruction = f"""
        Using the extracted information: {extracted_info}, solve the problem step by step. 
        Clearly outline each calculation or logical step required to arrive at the final answer. 
        Ensure that all units are consistent and that the solution makes sense in the context of the problem. 
        Provide intermediate results where necessary.
        """
        step_by_step_solution = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Validate and refine the solution
        refinement_instruction = """
        Critically evaluate the provided solution. Check for any errors in calculations, unit consistency, or logical reasoning. 
        Refine the solution if necessary, ensuring it aligns with the problem's requirements and constraints.
        """
        refined_solution = await self.revise(instruction=refinement_instruction, context=step_by_step_solution)

        # Step 4: Extract the final numerical answer
        summarization_instruction = """
        From the refined solution, extract the final numerical answer. 
        Ensure the answer is presented as a single value without any additional explanation.
        """
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_solution)

        return final_answer