# Workflow ID: gsm8k_338_0
# Benchmark: gsm8k
# Data Indices: [780, 389]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract known information and unknowns
        extraction_instruction = (
            "Extract all numerical values, relationships, and constraints from the problem. "
            "Identify known quantities and unknowns explicitly. "
            "Include units and any mathematical relationships described in the text."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a step-by-step solution plan
        plan_instruction = (
            f"Based on the following extracted information: {extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. "
            "Include intermediate calculations, hidden steps, and unit tracking. "
            "Ensure the plan is chronological and accounts for all relationships."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute the solution plan
        execution_instruction = (
            f"Follow this solution plan: {solution_plan}\n"
            "Perform the calculations step by step. "
            "Explicitly state intermediate results and verify their correctness. "
            "Ensure all units are consistent and properly handled."
        )
        # Split the solution plan into independent steps if possible
        steps = solution_plan.split("\n")
        step_results = await asyncio.gather(
            *[self.generate(instruction=f"{execution_instruction}\nFocus on: {step}", context=self.problem_text) for step in steps]
        )

        # Combine step results into a full solution
        full_solution = "\n".join(step_results)

        # Step 4: Validate and refine the solution
        refinement_instruction = (
            f"Review the following solution: {full_solution}\n"
            "Critique and refine it to ensure accuracy. "
            "Check that all calculations are correct, units are consistent, and the answer makes sense in context. "
            "Address any real-world constraints (e.g., no negative quantities)."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=full_solution)

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"Summarize the following solution: {refined_solution}\n"
            "Highlight the final numerical answer and its unit (if applicable). "
            "Ensure the summary is concise and clear."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer