# Workflow ID: gsm8k_322_0
# Benchmark: gsm8k
# Data Indices: [189, 179]

```python
class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract known information
        extraction_instruction = """
        Extract all numerical values, relationships, and constraints from the problem text.
        Categorize them as follows:
        - Known quantities (e.g., earnings per day, number of items sold)
        - Relationships (e.g., overtime pay rate, total days worked)
        - Constraints (e.g., non-negative values, unit consistency)
        Ensure the output is structured and easy to reference.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a solution strategy
        strategy_instruction = f"""
        Based on the extracted information:
        {extracted_info}
        Outline a step-by-step solution strategy to solve the problem. Include:
        - The sequence of operations required
        - Any intermediate calculations needed
        - How to handle units and ensure consistency
        - Validation checks to ensure correctness
        Provide a clear and detailed plan.
        """
        solution_strategy = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Perform calculations
        calculation_instruction = f"""
        Execute the solution strategy outlined below:
        {solution_strategy}
        Perform all necessary calculations step by step. For each step:
        - Clearly state the operation being performed
        - Show the intermediate result
        - Ensure units are consistent and constraints are respected
        Dynamically incorporate extracted information as needed.
        """
        calculations = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Validate intermediate results
        validation_instruction = f"""
        Review the calculations performed below:
        {calculations}
        Check for:
        - Accuracy of intermediate results
        - Consistency with the problem's constraints
        - Logical flow between steps
        Suggest revisions if necessary.
        """
        validated_results = await self.revise(instruction=validation_instruction, context=calculations)

        # Step 5: Summarize the final answer
        summary_instruction = f"""
        From the validated results below:
        {validated_results}
        Extract and summarize the final numerical answer. Ensure:
        - The answer is clearly stated
        - Units are included if applicable
        - The result makes sense in the context of the problem
        """
        final_answer = await self.summarize(instruction=summary_instruction, context=validated_results)

        return final_answer
```