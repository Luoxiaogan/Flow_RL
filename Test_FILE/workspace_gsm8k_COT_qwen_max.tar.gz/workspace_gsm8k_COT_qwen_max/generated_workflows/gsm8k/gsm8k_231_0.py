# Workflow ID: gsm8k_231_0
# Benchmark: gsm8k
# Data Indices: [530, 796]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract known information (numerical values, relationships, units)
        extraction_instruction = """
        Extract all numerical values, units, and relationships mentioned in the problem. 
        Identify the quantities involved, their relationships, and any constraints. 
        Ensure you capture all relevant information needed to solve the problem.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate the problem model (step-by-step plan)
        model_instruction = f"""
        Based on the following extracted information:
        {extracted_info}

        Create a step-by-step plan to solve the problem. 
        Identify the mathematical operations required (e.g., addition, multiplication) and the sequence in which they should be applied. 
        Ensure the plan accounts for any hidden steps or intermediate calculations.
        """
        problem_model = await self.generate(instruction=model_instruction, context=self.problem_text)

        # Step 3: Perform calculations
        calculation_instruction = f"""
        Execute the following plan step by step:
        {problem_model}

        Perform all necessary calculations, showing intermediate results where appropriate. 
        Ensure you maintain unit consistency throughout and handle any real-world constraints (e.g., no negative quantities).
        """
        calculations = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Validate and refine the solution
        refinement_instruction = f"""
        Review the following solution:
        {calculations}

        Check for correctness, ensuring the solution makes sense in the context of the problem. 
        Verify unit consistency and address any potential errors or ambiguities. 
        Refine the solution if necessary to ensure accuracy and clarity.
        """
        refined_solution = await self.revise(instruction=refinement_instruction, context=calculations)

        # Step 5: Summarize the final answer
        summary_instruction = """
        Summarize the final solution into a single numerical value or concise statement. 
        Ensure the answer is clear, precise, and directly addresses the question posed in the problem.
        """
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer