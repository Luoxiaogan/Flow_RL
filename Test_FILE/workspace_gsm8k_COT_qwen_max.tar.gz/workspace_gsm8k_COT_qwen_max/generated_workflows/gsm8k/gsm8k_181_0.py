# Workflow ID: gsm8k_181_0
# Benchmark: gsm8k
# Data Indices: [2, 522]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract known information and unknowns
        extraction_instruction = (
            "Extract all numerical values, relationships, and constraints from the problem. "
            "Identify what is known and what needs to be calculated. "
            "Format the output as a structured list."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Derive mathematical steps
        derivation_instruction = (
            f"Based on the following extracted information: {extracted_info}\n"
            "Translate the problem into a sequence of mathematical steps. "
            "Include all necessary intermediate calculations and ensure units are consistent. "
            "Format the output as a step-by-step plan."
        )
        steps = await self.generate(instruction=derivation_instruction, context=self.problem_text)

        # Step 3: Perform calculations and validate intermediate results
        calculation_instruction = (
            f"Execute the following steps: {steps}\n"
            "Perform each calculation carefully and verify the results. "
            "If any step seems ambiguous or incorrect, refine it."
        )
        raw_results = await self.generate(instruction=calculation_instruction, context=self.problem_text)
        refined_results = await self.revise(instruction="Critique and refine the calculations to ensure accuracy.", context=raw_results)

        # Step 4: Combine results and compute final answer
        summarization_instruction = (
            f"Based on the following refined results: {refined_results}\n"
            "Combine the results to compute the final answer. "
            "Ensure the answer makes sense in the context of the problem and is formatted appropriately."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_results)

        # Step 5: Handle ambiguities or multiple approaches (if needed)
        # If there are multiple valid solutions, use Ensemble to select the best one
        alternative_approach = await self.generate(
            instruction="Propose an alternative approach to solving the problem.", context=self.problem_text
        )
        if alternative_approach.strip():
            ensemble_instruction = (
                "Compare the primary solution and the alternative approach. "
                "Select the most accurate and contextually appropriate solution."
            )
            final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[final_answer, alternative_approach])

        return final_answer