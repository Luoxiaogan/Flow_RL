# Workflow ID: gsm8k_211_0
# Benchmark: gsm8k
# Data Indices: [675, 695]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information from the problem
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, relationships, and constraints. "
            "Include units, rates, and any implicit or explicit mathematical relationships. "
            "Format the extracted information in a structured way for easy reference."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Solve the problem step by step using the extracted information
        analysis_instruction = (
            f"Using the following extracted information:\n{extracted_info}\n"
            "Solve the problem step by step. Clearly show all intermediate calculations and reasoning. "
            "Ensure that the solution adheres to the problem's context and constraints. "
            "If there are multiple steps, explain each one in detail."
        )
        solution = await self.generate(instruction=analysis_instruction, context=self.problem_text)

        # Step 3: Verify and refine the solution
        refinement_instruction = (
            "Critique the following solution and refine it if necessary:\n"
            f"{solution}\n"
            "Ensure that all calculations are correct, units are consistent, and the solution makes sense in the problem's context. "
            "Highlight and fix any errors or inconsistencies."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=solution)

        # Step 4: Extract the final numerical answer
        summary_instruction = (
            "Summarize the following refined solution and extract the final numerical answer:\n"
            f"{refined_solution}\n"
            "The answer should be a single numerical value (integer or decimal) without any additional explanation."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer