# Workflow ID: gsm8k_201_0
# Benchmark: gsm8k
# Data Indices: [18, 292]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = """
        Analyze the problem thoroughly and extract all relevant numerical values, units, and relationships. 
        Identify any implicit constraints, such as chronological order, unit consistency, or real-world limitations. 
        Present the extracted information in a structured format for further processing.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate step-by-step solution plans
        solution_plan_instruction = f"""
        Based on the following extracted information: {extracted_info}
        Develop a detailed step-by-step plan to solve the problem. 
        Ensure that all intermediate calculations are explicitly stated, including any hidden steps. 
        Handle unit conversions and verify the logical consistency of the plan.
        """
        solution_plan = await self.generate(instruction=solution_plan_instruction, context=self.problem_text)

        # Step 3: Generate two independent solutions in parallel
        solution_instruction_1 = f"""
        Solve the problem using the following plan: {solution_plan}
        Follow each step meticulously and document all intermediate results. 
        Ensure that the final answer is clearly stated and makes sense in the context of the problem.
        """
        solution_instruction_2 = f"""
        Solve the problem independently using a different reasoning strategy. 
        You may reorganize the steps or approach the problem from an alternative perspective. 
        Ensure that the final answer is consistent with the problem's context and constraints.
        """
        solutions = await asyncio.gather(
            self.generate(instruction=solution_instruction_1, context=self.problem_text),
            self.generate(instruction=solution_instruction_2, context=self.problem_text)
        )

        # Step 4: Use Ensemble to select the best solution
        ensemble_instruction = """
        Compare the two solutions provided and determine which one is more accurate, consistent, and logically sound. 
        If there are discrepancies, resolve them by referring back to the problem statement and extracted information. 
        Synthesize the best aspects of both solutions if necessary.
        """
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=solutions)

        # Step 5: Refine the final solution for clarity and correctness
        refinement_instruction = """
        Review the solution and refine it for clarity, correctness, and formatting. 
        Ensure that the final answer is presented as a single numerical value (integer or decimal) with appropriate precision. 
        Verify that the solution aligns with the problem's context and constraints.
        """
        refined_solution = await self.revise(instruction=refinement_instruction, context=final_solution)

        return refined_solution