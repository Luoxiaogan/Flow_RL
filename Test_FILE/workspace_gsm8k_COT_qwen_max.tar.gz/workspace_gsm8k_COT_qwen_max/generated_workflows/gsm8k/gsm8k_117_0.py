# Workflow ID: gsm8k_117_0
# Benchmark: gsm8k
# Data Indices: [41, 760]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all relevant information (numerical values, relationships, constraints)
        extraction_instruction = (
            "Extract all numerical values, relationships, and constraints from the problem. "
            "Organize the information into a structured format, such as key-value pairs or lists. "
            "Ensure that all units and contextual details are preserved."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Outline the sequence of operations needed to solve the problem
        reasoning_instruction = (
            f"Given the extracted information: {extracted_info}, outline the sequence of operations "
            "required to solve the problem. Include intermediate steps, such as calculations, conversions, "
            "and logical deductions. Ensure that the steps are ordered chronologically and build toward "
            "the final solution."
        )
        reasoning_steps = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Execute intermediate calculations in parallel where possible
        # Parse reasoning_steps into individual tasks
        tasks = []
        for step in reasoning_steps.split("\n"):  # Assuming steps are separated by newlines
            if step.strip():  # Skip empty lines
                task_instruction = (
                    f"Perform the following calculation or deduction: {step}. "
                    "Ensure that the result is accurate and consistent with the problem context."
                )
                tasks.append(self.generate(instruction=task_instruction, context=self.problem_text))

        intermediate_results = await asyncio.gather(*tasks)

        # Step 4: Combine intermediate results to compute the final answer
        final_instruction = (
            f"Combine the following intermediate results: {intermediate_results}. "
            "Perform any remaining calculations to arrive at the final answer. "
            "Validate that the solution makes sense in the context of the problem."
        )
        final_result = await self.generate(instruction=final_instruction, context=self.problem_text)

        # Step 5: Revise and refine the final result for accuracy
        revision_instruction = (
            f"Review the final result: {final_result}. "
            "Check for accuracy, consistency, and adherence to the problem context. "
            "Refine the result if necessary."
        )
        refined_result = await self.revise(instruction=revision_instruction, context=final_result)

        # Step 6: Summarize the solution process and present the final answer
        summary_instruction = (
            f"Summarize the solution process based on the following: {refined_result}. "
            "Present the final answer in a clear and concise format."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_result)

        return final_summary