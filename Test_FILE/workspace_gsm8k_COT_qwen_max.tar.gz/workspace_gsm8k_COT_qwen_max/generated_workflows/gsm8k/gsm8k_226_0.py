# Workflow ID: gsm8k_226_0
# Benchmark: gsm8k
# Data Indices: [770, 313]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant numerical values and relationships
        extraction_instruction = (
            "Extract all numerical values, relationships, and constraints from the problem. "
            "Identify the known quantities and the unknown(s) to be solved. "
            "Format the output as a structured list for clarity."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan the step-by-step solution
        planning_instruction = (
            f"Based on the extracted information: {extracted_info}, "
            "create a detailed step-by-step plan to solve the problem. "
            "Include all necessary calculations and ensure the sequence of operations is logical. "
            "Format the plan as a numbered list for clarity."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Execute parallel computation paths
        computation_instruction_1 = (
            f"Follow this solution plan: {solution_plan}. "
            "Perform the calculations step by step and provide the final numerical answer. "
            "Ensure all intermediate results are clearly shown."
        )
        computation_instruction_2 = (
            f"Verify the solution plan: {solution_plan}. "
            "Recompute the results independently, checking for consistency and accuracy. "
            "Highlight any discrepancies or alternative approaches."
        )
        results = await asyncio.gather(
            self.generate(instruction=computation_instruction_1, context=self.problem_text),
            self.generate(instruction=computation_instruction_2, context=self.problem_text)
        )

        # Step 4: Synthesize and validate results
        synthesis_instruction = (
            "Evaluate the following candidate solutions: {results}. "
            "Select the most consistent and accurate solution based on the problem's context. "
            "Validate that the final answer satisfies all constraints and makes sense in the real-world scenario. "
            "Provide the final numerical answer with appropriate units if applicable."
        ).format(results=results)
        final_solution = await self.ensemble(instruction=synthesis_instruction, contexts=results)

        # Step 5: Refine the final output (if necessary)
        refinement_instruction = (
            "Refine the final solution: {final_solution}. "
            "Ensure clarity, correctness, and proper formatting. "
            "Remove any unnecessary details while preserving the key result."
        ).format(final_solution=final_solution)
        refined_output = await self.revise(instruction=refinement_instruction, context=final_solution)

        return refined_output