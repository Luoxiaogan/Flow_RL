# Workflow ID: gsm8k_75_0
# Benchmark: gsm8k
# Data Indices: [443, 42]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem text
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, relationships, and the target question. "
            "Include units (e.g., dollars, hours) and clearly identify what is being asked."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan the step-by-step solution
        planning_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Plan a step-by-step solution to the problem. Identify intermediate calculations, ensure unit consistency, "
            "and outline the sequence of operations required to reach the final answer."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Perform intermediate calculations in parallel
        calculation_instructions = []
        for step in ["first", "second", "third"]:  # Dynamically adjust based on solution_plan
            calc_instruction = (
                f"Perform the {step} step of the solution plan:\n{solution_plan}\n"
                "Compute the result explicitly, showing all intermediate steps and maintaining unit consistency."
            )
            calculation_instructions.append(calc_instruction)

        # Execute calculations in parallel
        intermediate_results = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in calculation_instructions]
        )

        # Step 4: Synthesize intermediate results into a final answer
        synthesis_instruction = (
            "Combine the following intermediate results into a single coherent answer:\n"
            f"{intermediate_results}\n"
            "Ensure the final result answers the original question and adheres to the problem's context."
        )
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=intermediate_results)

        # Step 5: Validate and refine the final answer
        validation_instruction = (
            f"Review the following answer:\n{final_answer}\n"
            "Check for logical consistency, unit correctness, and adherence to the problem's context. "
            "Suggest improvements if necessary."
        )
        refined_answer = await self.revise(instruction=validation_instruction, context=final_answer)

        return refined_answer