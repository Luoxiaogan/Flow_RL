# Workflow ID: gsm8k_282_0
# Benchmark: gsm8k
# Data Indices: [291, 752]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (numerical values, relationships, constraints)
        extract_instruction = (
            "Carefully analyze the problem and extract all numerical values, units, and relationships. "
            "Identify what is given and what is being asked. Organize the information in a structured format."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Formulate a solution plan
        plan_instruction = (
            f"Based on the extracted information: {extracted_info}, formulate a step-by-step plan to solve the problem. "
            "Include the sequence of operations, intermediate calculations, and any necessary unit conversions. "
            "Ensure the plan is logical and addresses all aspects of the problem."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute calculations
        calculate_instruction = (
            f"Follow this solution plan: {solution_plan}. Perform the calculations step by step. "
            "Explicitly show intermediate results and ensure all operations are accurate. "
            "If there are independent sub-problems, solve them in parallel."
        )
        calculation_results = await self.generate(instruction=calculate_instruction, context=self.problem_text)

        # Step 4: Validate and refine the solution
        validate_instruction = (
            f"Review the following calculations: {calculation_results}. "
            "Check for errors, inconsistencies, or unrealistic values. Ensure the solution aligns with the problem context. "
            "Refine the solution if necessary."
        )
        refined_solution = await self.revise(instruction=validate_instruction, context=calculation_results)

        # Step 5: Summarize the final answer
        summarize_instruction = (
            f"Condense the refined solution: {refined_solution} into a single numerical value. "
            "Ensure the answer is precise and formatted correctly."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_answer