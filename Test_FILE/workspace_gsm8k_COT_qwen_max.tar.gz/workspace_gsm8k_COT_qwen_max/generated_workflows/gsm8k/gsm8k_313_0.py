# Workflow ID: gsm8k_313_0
# Benchmark: gsm8k
# Data Indices: [135, 105]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (numerical values, relationships, units)
        extract_instruction = """
        Extract all numerical values, units, and relationships from the problem. 
        Identify any constraints or conditions that affect the calculations. 
        Pay special attention to hidden steps or intermediate calculations that may be required.
        Format the extracted information clearly for further processing.
        """
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Formulate a step-by-step solution plan
        plan_instruction = f"""
        Based on the following extracted information:
        {extracted_info}
        Create a detailed step-by-step plan to solve the problem. 
        Include all necessary calculations, specify the order of operations, and ensure unit consistency. 
        Highlight any assumptions or clarifications needed for ambiguous cases.
        """
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute the calculations
        calculate_instruction = f"""
        Using the following solution plan:
        {solution_plan}
        Perform the calculations step by step. 
        Track intermediate results and ensure they are consistent with the problem context. 
        Verify that each step logically follows from the previous one.
        Provide the final numerical result at the end.
        """
        calculated_result = await self.generate(instruction=calculate_instruction, context=self.problem_text)

        # Step 4: Validate and refine the solution
        validate_instruction = f"""
        Review the following calculated result:
        {calculated_result}
        Critique its correctness and reasonableness in the context of the problem. 
        Ensure it adheres to real-world constraints (e.g., no negative quantities, fractional people). 
        Refine any inconsistencies or errors.
        """
        validated_result = await self.revise(instruction=validate_instruction, context=calculated_result)

        # Step 5: Summarize the final answer
        summarize_instruction = """
        Condense the solution into a concise final answer. 
        Ensure the output is a single numerical value (integer or decimal) that directly answers the problem.
        """
        final_answer = await self.summarize(instruction=summarize_instruction, context=validated_result)

        return final_answer