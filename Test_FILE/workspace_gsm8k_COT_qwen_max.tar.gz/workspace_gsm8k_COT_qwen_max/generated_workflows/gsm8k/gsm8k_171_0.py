# Workflow ID: gsm8k_171_0
# Benchmark: gsm8k
# Data Indices: [199, 463]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all numerical values, units, and relationships
        extraction_instruction = (
            "Extract all numerical values, their associated units, and any relationships "
            "or constraints mentioned in the problem. Organize them into a structured format."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Identify intermediate steps and outline the solution approach
        planning_instruction = (
            f"Based on the extracted information: {extracted_info}, "
            "identify all intermediate steps required to solve the problem. "
            "Outline a step-by-step plan, including any hidden calculations."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Perform parallel computations for independent subtasks
        computation_instruction_template = (
            "Perform the following calculation based on the problem context: {task}. "
            "Ensure the result is accurate and includes appropriate units."
        )
        tasks = ["Calculate total resources available", "Determine resource usage per unit", "Compute intermediate totals"]
        computation_tasks = [
            self.generate(instruction=computation_instruction_template.format(task=task), context=self.problem_text)
            for task in tasks
        ]
        intermediate_results = await asyncio.gather(*computation_tasks)

        # Step 4: Combine intermediate results to compute the final answer
        final_calculation_instruction = (
            f"Combine the following intermediate results: {intermediate_results}. "
            "Perform the necessary calculations to arrive at the final answer. "
            "Ensure the solution is consistent with the problem context and units."
        )
        final_answer = await self.generate(instruction=final_calculation_instruction, context=self.problem_text)

        # Step 5: Validate and refine the solution
        validation_instruction = (
            f"Review the final answer: {final_answer}. "
            "Check for mathematical accuracy, unit consistency, and contextual validity. "
            "Revise if necessary to ensure correctness."
        )
        refined_answer = await self.revise(instruction=validation_instruction, context=final_answer)

        return refined_answer