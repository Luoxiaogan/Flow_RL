# Workflow ID: gsm8k_115_0
# Benchmark: gsm8k
# Data Indices: [589, 357]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant numerical values, relationships, and constraints
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, relationships, "
            "and constraints. Clearly identify what is given and what is being asked. "
            "Ensure that units and contextual constraints are noted."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a solution strategy based on the extracted information
        strategy_instruction = (
            f"Based on the following extracted information: {extracted_info}\n"
            "Determine the sequence of operations required to solve the problem. Identify any hidden steps, "
            "ensure unit consistency, and verify that all constraints are addressed. Provide a step-by-step plan."
        )
        solution_strategy = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Generate multiple solution approaches in parallel
        approach_1_instruction = (
            f"Using the following solution strategy: {solution_strategy}\n"
            "Solve the problem step by step using direct calculation methods. Show all intermediate results."
        )
        approach_2_instruction = (
            f"Using the following solution strategy: {solution_strategy}\n"
            "Solve the problem step by step using algebraic reasoning. Define variables and equations as needed."
        )
        approach_1, approach_2 = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text)
        )

        # Step 4: Evaluate and select the best solution
        evaluation_instruction = (
            "Compare the following two solutions and determine which one is correct, consistent, "
            "and adheres to the problem constraints. If both are valid, synthesize a final answer."
        )
        best_solution = await self.ensemble(instruction=evaluation_instruction, contexts=[approach_1, approach_2])

        # Step 5: Refine the final solution for clarity and correctness
        refinement_instruction = (
            "Critique and refine the following solution to ensure clarity, correctness, and proper formatting. "
            "Verify that the final answer makes sense in the context of the problem."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 6: Summarize the key results and present the final answer
        summary_instruction = (
            "Condense the following solution into a concise summary. Present the final numerical answer clearly."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer