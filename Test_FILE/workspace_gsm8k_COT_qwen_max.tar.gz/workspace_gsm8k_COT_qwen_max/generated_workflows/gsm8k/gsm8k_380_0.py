# Workflow ID: gsm8k_380_0
# Benchmark: gsm8k
# Data Indices: [789, 32]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract known information and relationships
        extraction_instruction = (
            "Thoroughly analyze the problem and extract all numerical values, units, "
            "and relationships described in the text. Include any constraints, rates, "
            "proportions, or sequential dependencies mentioned. Format the output clearly."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a step-by-step solution plan
        plan_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. Include all necessary calculations, "
            "intermediate steps, and ensure the order of operations is correct. Highlight any unit conversions "
            "or contextual constraints that need to be considered."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute the calculations
        calculation_instruction = (
            f"Using the following solution plan:\n{solution_plan}\n"
            "Perform the calculations step by step. Clearly show all intermediate results and ensure "
            "unit consistency throughout. Provide the final numerical answer at the end."
        )
        calculated_result = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Verify and refine the solution
        refine_instruction = (
            f"Review the following calculated result:\n{calculated_result}\n"
            "Check for accuracy, unit consistency, and logical correctness. Ensure the solution aligns with the "
            "problem's context and constraints. Refine the result if necessary, providing a corrected version."
        )
        refined_solution = await self.revise(instruction=refine_instruction, context=calculated_result)

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"From the following refined solution:\n{refined_solution}\n"
            "Extract and summarize the final numerical answer. Ensure the output is a single number (integer or decimal) "
            "without any additional text or explanation."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer