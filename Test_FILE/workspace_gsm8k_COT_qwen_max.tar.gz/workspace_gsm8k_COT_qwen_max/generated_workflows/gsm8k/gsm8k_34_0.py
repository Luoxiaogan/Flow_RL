# Workflow ID: gsm8k_34_0
# Benchmark: gsm8k
# Data Indices: [547, 740]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information (numerical values, relationships, units)
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, "
            "their associated units, and any relationships between them. "
            "Include explicit mention of rates, totals, constraints, and any "
            "hidden assumptions or intermediate steps required."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a step-by-step solution plan
        plan_instruction = (
            f"Based on the following extracted information: {extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. "
            "Include intermediate calculations, unit conversions, and checks "
            "for logical consistency. Ensure the plan is chronological and "
            "respects all constraints mentioned in the problem."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute the solution plan (parallelize independent steps)
        execution_instruction_template = (
            "Follow this part of the solution plan: {step}\n"
            "Perform the calculation or reasoning described, ensuring all "
            "units and constraints are respected. Provide the result clearly."
        )

        # Split the solution plan into individual steps
        steps = solution_plan.split("\n")
        execution_tasks = [
            self.generate(instruction=execution_instruction_template.format(step=step), context=self.problem_text)
            for step in steps if step.strip()
        ]
        step_results = await asyncio.gather(*execution_tasks)

        # Combine step results into a coherent solution
        combined_solution = "\n".join(step_results)

        # Step 4: Revise the solution for accuracy and consistency
        revision_instruction = (
            "Critically evaluate the following solution: {solution}\n"
            "Check for logical consistency, adherence to the problem's "
            "constraints, and proper handling of units. Suggest corrections "
            "if necessary and provide the final revised answer."
        )
        final_solution = await self.revise(
            instruction=revision_instruction.format(solution=combined_solution),
            context=self.problem_text
        )

        # Step 5: Ensemble for final answer (if multiple interpretations exist)
        ensemble_instruction = (
            "Given the following solution: {solution}\n"
            "Ensure it represents the most accurate and robust answer. "
            "If there are ambiguities or alternative interpretations, resolve "
            "them and provide the single best answer."
        )
        final_answer = await self.ensemble(
            instruction=ensemble_instruction.format(solution=final_solution),
            contexts=[final_solution]
        )

        return final_answer