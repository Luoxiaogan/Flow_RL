# Workflow ID: gsm8k_37_0
# Benchmark: gsm8k
# Data Indices: [234, 365]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, relationships, "
            "and the final question being asked. Format the output clearly, separating known values, "
            "relationships, and the unknown to be solved."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan the solution steps
        planning_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. Include all arithmetic operations, "
            "intermediate calculations, and any necessary unit conversions. Ensure the plan is sequential "
            "and accounts for all constraints mentioned in the problem."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Execute solution steps in parallel
        execution_instruction_template = (
            "Perform the following calculation step as part of solving the problem:\n"
            "{step}\n"
            "Ensure the result is accurate and formatted appropriately."
        )
        # Parse the solution plan into individual steps (this assumes the plan is well-structured)
        steps = solution_plan.split("\n")
        execution_tasks = [
            self.generate(instruction=execution_instruction_template.format(step=step), context=self.problem_text)
            for step in steps if step.strip()
        ]
        intermediate_results = await asyncio.gather(*execution_tasks)

        # Step 4: Synthesize intermediate results into the final answer
        ensemble_instruction = (
            "Combine the following intermediate results into the final answer:\n"
            f"{intermediate_results}\n"
            "Ensure the final answer is consistent with the problem's context and constraints. "
            "If any discrepancies exist, resolve them logically."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=intermediate_results)

        # Step 5: Verify and refine the final answer
        refinement_instruction = (
            f"Review the final answer: {final_answer}\n"
            "Verify that it makes sense in the context of the problem. Check for any calculation errors, "
            "unit inconsistencies, or logical flaws. Refine the answer if necessary."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        return refined_answer