# Workflow ID: gsm8k_20_0
# Benchmark: gsm8k
# Data Indices: [500, 15]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract known information (numerical values, units, relationships)
        extraction_instruction = """
        Extract all numerical values, units, and relationships from the problem. 
        Categorize the information into known values, unknowns, and constraints. 
        Include any implicit information that can be inferred from the context. 
        Format the output as a structured list for clarity.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a solution plan
        plan_instruction = f"""
        Based on the extracted information: {extracted_info}
        Determine the sequence of operations required to solve the problem. 
        Identify any hidden steps, unit conversions, or intermediate calculations. 
        Provide a step-by-step plan that outlines how to arrive at the final answer.
        """
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Perform calculations
        calculation_instruction = f"""
        Using the solution plan: {solution_plan}
        Perform the necessary arithmetic operations to calculate intermediate and final results. 
        Ensure that all calculations are consistent with the problem's units and constraints. 
        Format the results clearly, showing each step of the computation.
        """
        calculations = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Verify and refine results
        refinement_instruction = f"""
        Review the calculations: {calculations}
        Verify their correctness by cross-checking against the problem context. 
        Refine any ambiguous or incorrect results to ensure accuracy. 
        Highlight any assumptions or adjustments made during the refinement process.
        """
        refined_results = await self.revise(instruction=refinement_instruction, context=calculations)

        # Step 5: Summarize the final answer
        summary_instruction = f"""
        From the refined results: {refined_results}
        Extract the final numerical answer. 
        Ensure that the answer is consistent with the problem's constraints and units. 
        Format the output as a single value without additional explanation.
        """
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_results)

        return final_answer