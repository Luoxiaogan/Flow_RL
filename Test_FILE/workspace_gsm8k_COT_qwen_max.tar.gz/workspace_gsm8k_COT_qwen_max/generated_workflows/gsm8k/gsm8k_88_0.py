# Workflow ID: gsm8k_88_0
# Benchmark: gsm8k
# Data Indices: [485, 515]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information (numerical values, relationships, constraints)
        extract_instruction = """
        Extract all numerical values, relationships, and constraints from the problem.
        Clearly identify what is known and what needs to be determined.
        Ensure the output is structured and easy to interpret.
        """
        extraction = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Translate the problem into mathematical formulation
        formulate_instruction = f"""
        Using the extracted information: {extraction}
        Translate the problem into mathematical equations or logical statements.
        Clearly define variables, relationships, and the final goal.
        Ensure the formulation is precise and ready for computation.
        """
        formulation = await self.generate(instruction=formulate_instruction, context=self.problem_text)

        # Step 3: Solve the problem step-by-step
        solve_instruction = f"""
        Given the mathematical formulation: {formulation}
        Solve the problem step-by-step, showing all intermediate calculations.
        Ensure units are consistent, and explain each step clearly.
        Provide the final numerical answer at the end.
        """
        solution = await self.generate(instruction=solve_instruction, context=self.problem_text)

        # Step 4: Validate and refine the solution
        validate_instruction = f"""
        Review the solution: {solution}
        Check for accuracy, consistency with the problem's context, and logical correctness.
        Suggest improvements if necessary.
        """
        refined_solution = await self.revise(instruction=validate_instruction, context=solution)

        # Step 5: Summarize the final answer
        summarize_instruction = f"""
        From the refined solution: {refined_solution}
        Extract and present the final numerical answer.
        Ensure the result is clear, concise, and meets the problem's requirements.
        """
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_answer