# Workflow ID: gsm8k_386_0
# Benchmark: gsm8k
# Data Indices: [332, 117]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information from the problem
        extraction_instruction = """
        Carefully analyze the problem and extract all relevant information, including:
        - Numerical values and their units (e.g., dollars, hours, items)
        - Relationships between quantities (e.g., discounts, ratios, rates)
        - Operations required (e.g., addition, subtraction, multiplication, division)
        - Any constraints or conditions (e.g., time-based, real-world limitations)
        Organize the extracted information in a structured format for further processing.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate a step-by-step solution
        solution_instruction = f"""
        Using the extracted information: {extracted_info}
        Solve the problem step by step, ensuring the following:
        - Clearly define each step and its purpose
        - Perform intermediate calculations explicitly
        - Maintain unit consistency throughout
        - Sequence operations logically based on the problem's context
        - Verify that each step aligns with the problem's requirements
        Provide a detailed explanation of the reasoning process.
        """
        initial_solution = await self.generate(instruction=solution_instruction, context=self.problem_text)

        # Step 3: Validate and refine the solution
        refinement_instruction = """
        Critique the provided solution and refine it as needed. Focus on:
        - Ensuring all calculations are correct and consistent
        - Addressing any ambiguities or missing steps
        - Clarifying the reasoning process where necessary
        - Ensuring the solution makes sense in the context of the problem
        Return the improved solution.
        """
        refined_solution = await self.revise(instruction=refinement_instruction, context=initial_solution)

        # Step 4: Extract the final numerical answer
        summarization_instruction = """
        From the refined solution, extract the final numerical answer. Ensure:
        - The answer is a single number (integer or decimal)
        - The answer is clearly labeled and matches the problem's requirements
        """
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_solution)

        return final_answer