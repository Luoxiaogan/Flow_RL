# Workflow ID: gsm8k_152_0
# Benchmark: gsm8k
# Data Indices: [198, 513]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant numerical values, units, relationships, and the final question
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, units, relationships, "
            "and the specific question being asked. Identify any implicit or intermediate steps required "
            "to solve the problem. Format the output clearly with labels for each extracted component."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Create a step-by-step plan to solve the problem
        plan_instruction = (
            f"Using the following extracted information: {extracted_info}, create a detailed step-by-step plan "
            "to solve the problem. Include all intermediate calculations, unit conversions, and logical reasoning. "
            "Ensure the plan is chronological and addresses all parts of the question."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute intermediate calculations in parallel
        # Split the solution plan into individual steps
        steps = solution_plan.split("\n")
        calculation_tasks = []
        for step in steps:
            if step.strip():  # Ignore empty lines
                calc_instruction = (
                    f"Perform the following calculation or reasoning step: {step}. "
                    "Ensure all units are consistent and show your work explicitly. "
                    "Provide the result as a clear, labeled output."
                )
                calculation_tasks.append(self.generate(instruction=calc_instruction, context=self.problem_text))
        
        intermediate_results = await asyncio.gather(*calculation_tasks)

        # Step 4: Synthesize intermediate results into a coherent solution
        synthesis_instruction = (
            "Combine the following intermediate results into a coherent solution. "
            "Ensure consistency between steps, resolve any conflicts, and verify that the final answer "
            "addresses the original question. Provide the final answer as a single numerical value."
        )
        final_solution = await self.ensemble(instruction=synthesis_instruction, contexts=intermediate_results)

        # Step 5: Verify and refine the final solution
        verification_instruction = (
            "Critically review the following solution: {final_solution}. "
            "Check for logical correctness, unit consistency, and contextual validity. "
            "Refine the solution if necessary and ensure the final answer is a single numerical value."
        ).format(final_solution=final_solution)
        refined_solution = await self.revise(instruction=verification_instruction, context=self.problem_text)

        return refined_solution