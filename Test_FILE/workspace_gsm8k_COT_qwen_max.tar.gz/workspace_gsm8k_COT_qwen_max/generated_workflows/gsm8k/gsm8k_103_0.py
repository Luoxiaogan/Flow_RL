# Workflow ID: gsm8k_103_0
# Benchmark: gsm8k
# Data Indices: [415, 209]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract known information and unknowns
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, relationships, and constraints. "
            "Identify what is given and what is being asked. Include units and any relevant context."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a step-by-step solution plan
        plan_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. "
            "Specify the sequence of operations (e.g., addition, subtraction, multiplication, division) "
            "and how intermediate results will be calculated. Ensure units are consistent throughout."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Perform calculations
        calculation_instruction = (
            f"Follow this solution plan: {solution_plan}\n"
            "Execute the calculations step by step. Show all intermediate results and track units carefully. "
            "Ensure the final result answers the question posed in the problem."
        )
        raw_solution = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Validate and refine the solution
        validation_instruction = (
            f"Review this solution: {raw_solution}\n"
            "Check if the answer makes sense in the context of the problem. "
            "Look for issues such as inconsistent units, unrealistic values (e.g., negative quantities), "
            "or logical errors. Refine the solution if necessary."
        )
        refined_solution = await self.revise(instruction=validation_instruction, context=raw_solution)

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"Condense this solution: {refined_solution}\n"
            "Provide a concise summary that highlights the key steps and the final answer. "
            "Ensure the answer is a single numerical value (integer or decimal) and include units if applicable."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_summary