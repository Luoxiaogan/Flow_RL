# Workflow ID: gsm8k_74_0
# Benchmark: gsm8k
# Data Indices: [8, 737]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key numerical values, relationships, and units
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, their associated units, "
            "and any relationships or operations described between them. Ensure you capture all "
            "relevant information needed to solve the problem."
        )
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Normalize units (e.g., convert feet to inches, hours to minutes, etc.)
        normalization_instruction = (
            f"Given the extracted information: {extraction}, normalize all units into a consistent system. "
            "For example, convert all measurements to either metric or imperial units as appropriate. "
            "Provide the normalized values along with their units."
        )
        normalized_units = await self.generate(instruction=normalization_instruction, context=self.problem_text)

        # Step 3: Perform intermediate calculations in parallel
        intermediate_calc_instruction = (
            f"Using the normalized values: {normalized_units}, perform all necessary intermediate calculations. "
            "For example, calculate areas, volumes, totals, or proportions as described in the problem. "
            "Show each step clearly and provide the results of these calculations."
        )
        final_answer_instruction = (
            f"Using the normalized values: {normalized_units}, directly derive the final answer to the problem. "
            "Ensure the answer is a single numerical value and includes appropriate units if necessary."
        )

        # Run intermediate calculations and final answer derivation in parallel
        intermediate_results, final_answer = await asyncio.gather(
            self.generate(instruction=intermediate_calc_instruction, context=self.problem_text),
            self.generate(instruction=final_answer_instruction, context=self.problem_text)
        )

        # Step 4: Summarize the results to ensure clarity and correctness
        summary_instruction = (
            f"Summarize the following information: {intermediate_results}. "
            "Condense the key points and ensure the final answer is clear and well-supported. "
            "The summary should include the final numerical answer and its context."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=final_answer)

        return final_summary