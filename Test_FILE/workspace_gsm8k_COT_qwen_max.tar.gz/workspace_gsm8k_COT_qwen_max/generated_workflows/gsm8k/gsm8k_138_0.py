# Workflow ID: gsm8k_138_0
# Benchmark: gsm8k
# Data Indices: [77, 272]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio
        
        # Step 1: Extract key information (numerical values, relationships, constraints)
        extraction_instruction = (
            "Thoroughly analyze the problem and extract all numerical values, relationships, and constraints. "
            "Include units, percentages, rates, and any other relevant details. Format the output clearly."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)
        
        # Step 2: Perform intermediate calculations and logical reasoning
        calculation_instruction = (
            f"Using the following extracted information: {extracted_info}\n"
            "Perform all necessary calculations step-by-step. Include intermediate results and ensure proper handling of units. "
            "If there are multiple steps, clearly outline each one and their dependencies."
        )
        calculations = await self.generate(instruction=calculation_instruction, context=self.problem_text)
        
        # Step 3: Validate and refine the results
        refinement_instruction = (
            "Review the provided calculations and results. Identify any errors, inconsistencies, or missing steps. "
            "Refine the solution to ensure accuracy, unit consistency, and alignment with the problem's context."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=calculations)
        
        # Step 4: Synthesize the final answer
        synthesis_instruction = (
            "Condense the refined solution into a single numerical answer. Ensure the result is clear, precise, "
            "and includes appropriate units if applicable."
        )
        final_answer = await self.summarize(instruction=synthesis_instruction, context=refined_solution)
        
        return final_answer