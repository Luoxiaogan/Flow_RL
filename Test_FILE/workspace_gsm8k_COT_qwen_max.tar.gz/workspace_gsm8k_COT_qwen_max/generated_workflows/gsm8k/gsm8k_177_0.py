# Workflow ID: gsm8k_177_0
# Benchmark: gsm8k
# Data Indices: [553, 517]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all numerical values, relationships, and contextual information
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, units, "
            "relationships, and any constraints provided. Clearly identify what the question "
            "is asking for and list all known and unknown quantities."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan the solution approach
        planning_instruction = (
            f"Given the following extracted information: {extracted_info}\n"
            "Plan the sequence of steps required to solve the problem. Identify the arithmetic "
            "operations (addition, subtraction, multiplication, division), unit conversions, or "
            "proportional reasoning needed. Ensure the plan addresses all parts of the question."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Generate multiple solution approaches in parallel
        approach1_instruction = (
            f"Using the extracted information and the solution plan: {solution_plan}\n"
            "Solve the problem step by step using a direct calculation approach. Show all intermediate "
            "results and ensure unit consistency."
        )
        approach2_instruction = (
            f"Using the extracted information and the solution plan: {solution_plan}\n"
            "Solve the problem step by step using an algebraic or proportional reasoning approach. "
            "Show all intermediate results and ensure logical consistency."
        )
        results = await asyncio.gather(
            self.generate(instruction=approach1_instruction, context=self.problem_text),
            self.generate(instruction=approach2_instruction, context=self.problem_text)
        )

        # Step 4: Synthesize the best solution using Ensemble
        ensemble_instruction = (
            "Compare the following two solutions and select the most accurate and logically consistent one. "
            "Ensure the final answer makes sense in the context of the problem and adheres to any "
            "constraints provided."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 5: Refine the final solution for clarity and correctness
        refinement_instruction = (
            "Review the following solution and refine it for clarity, accuracy, and proper formatting. "
            "Ensure the final answer is a single numerical value (integer or decimal) and includes "
            "appropriate units if necessary."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=final_solution)

        return refined_solution