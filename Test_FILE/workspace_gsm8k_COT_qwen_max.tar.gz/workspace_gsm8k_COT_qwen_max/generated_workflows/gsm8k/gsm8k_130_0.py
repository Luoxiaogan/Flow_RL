# Workflow ID: gsm8k_130_0
# Benchmark: gsm8k
# Data Indices: [448, 607]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract numerical values, units, and relationships
        extract_instruction = """
        Analyze the problem carefully and extract all numerical values, units, and relationships between them.
        Categorize the extracted information into known values, unknowns, and constraints.
        Ensure that all monetary values are identified (e.g., dollars, cents), along with any time-based or quantity-based units.
        If there are implicit relationships or hidden steps, explicitly state them.
        """
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Generate a step-by-step solution plan
        plan_instruction = f"""
        Based on the following extracted information: {extracted_info}
        Create a detailed step-by-step plan to solve the problem.
        Include intermediate calculations, ensure unit consistency, and specify the order of operations.
        Identify any hidden steps or assumptions required to solve the problem.
        """
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Generate multiple solution approaches in parallel
        approach_1_instruction = f"""
        Solve the problem using the following plan: {solution_plan}
        Focus on clarity and correctness, and ensure all steps are explicitly shown.
        """
        approach_2_instruction = f"""
        Solve the problem using the following plan: {solution_plan}
        Explore an alternative interpretation or sequence of operations if applicable.
        Ensure all steps are mathematically valid and consistent with the problem context.
        """
        results = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text)
        )

        # Step 4: Evaluate and select the best solution
        ensemble_instruction = f"""
        Compare the following candidate solutions and select the most accurate and complete one:
        Ensure the chosen solution adheres to the problem's constraints, maintains unit consistency, and provides a clear final answer.
        """
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 5: Refine the final solution
        refine_instruction = """
        Review the selected solution and ensure it is concise, accurate, and properly formatted.
        Convert monetary values to the required units (e.g., dollars to cents) if specified in the problem.
        Verify that the final answer is a single numerical value and makes sense in the problem's context.
        """
        final_answer = await self.revise(instruction=refine_instruction, context=best_solution)

        return final_answer