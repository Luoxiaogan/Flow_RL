# Workflow ID: gsm8k_208_0
# Benchmark: gsm8k
# Data Indices: [243, 616]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information
        extraction_instruction = (
            "Extract all numerical values, units, relationships, and constraints from the problem. "
            "Identify what is being asked and what information is given explicitly or implicitly. "
            "Format the output as a structured list for clarity."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a solution plan
        plan_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Create a step-by-step plan to solve the problem. Include all intermediate calculations, "
            "unit conversions, and logical reasoning. Ensure the plan is chronological and mathematically sound."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute the solution plan
        execution_instruction = (
            f"Follow this solution plan:\n{solution_plan}\n"
            "Perform all calculations step by step, showing intermediate results. "
            "Track units consistently and ensure the final answer is clearly stated."
        )
        executed_solution = await self.generate(instruction=execution_instruction, context=self.problem_text)

        # Step 4: Validate and refine the solution
        refinement_instruction = (
            "Critique the following solution for mathematical accuracy and logical consistency:\n"
            f"{executed_solution}\n"
            "Identify any errors, inconsistencies, or missing steps. Refine the solution if necessary."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=executed_solution)

        # Step 5: Summarize the final answer
        summary_instruction = (
            "Condense the following solution into a concise summary, extracting the final numerical answer:\n"
            f"{refined_solution}\n"
            "Ensure the summary includes only the essential information and the final result."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer