# Workflow ID: gsm8k_245_0
# Benchmark: gsm8k
# Data Indices: [266, 638]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant numerical values, units, and relationships
        extraction_instruction = """
        Carefully analyze the problem text to extract all numerical values, units, and relationships between them.
        Include explicit labels for each extracted piece of information (e.g., "number of candles", "weight per candle").
        Ensure you capture implicit relationships or constraints mentioned in the text.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan the solution approach
        planning_instruction = f"""
        Based on the following extracted information:
        {extracted_info}

        Devise a step-by-step plan to solve the problem. Clearly specify the sequence of operations (e.g., addition, subtraction, multiplication, division) required to compute the final answer.
        Include intermediate steps and ensure unit consistency throughout.
        If there are multiple possible approaches, choose the most straightforward one.
        """
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Execute calculations based on the plan
        calculation_instruction = f"""
        Follow this plan step-by-step to calculate the final answer:
        {solution_plan}

        Perform each operation carefully, preserving intermediate results. Ensure that units are consistent and that all constraints from the problem are respected.
        """
        calculation_result = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Verify and refine the result
        refinement_instruction = f"""
        Review the following calculation result:
        {calculation_result}

        Check for correctness by verifying against the original problem constraints. Ensure that units are consistent and that the result makes sense in the context of the problem.
        Suggest improvements or corrections if necessary.
        """
        refined_result = await self.revise(instruction=refinement_instruction, context=calculation_result)

        # Step 5: Summarize the final answer
        summary_instruction = f"""
        Summarize the following refined result into a concise format:
        {refined_result}

        Present the final answer as a single numerical value, clearly labeled and formatted appropriately.
        """
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_result)

        return final_answer