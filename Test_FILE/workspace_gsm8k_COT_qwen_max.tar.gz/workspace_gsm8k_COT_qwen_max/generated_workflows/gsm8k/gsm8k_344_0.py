# Workflow ID: gsm8k_344_0
# Benchmark: gsm8k
# Data Indices: [681, 436]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract all numerical values and relationships
        extraction_instruction = (
            "Carefully analyze the problem statement and extract all numerical values, relationships, "
            "and constraints. Clearly identify what is being asked and list all known quantities. "
            "Pay attention to units, ratios, percentages, and any mathematical relationships described."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a step-by-step solution strategy
        planning_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. Identify the sequence of operations "
            "(addition, subtraction, multiplication, division, etc.) required to reach the solution. "
            "Ensure that the plan accounts for all constraints and relationships described in the problem."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Perform intermediate calculations in parallel
        calculation_instruction_template = (
            "Perform the following calculation step exactly as described: {step}. "
            "Ensure that all units are consistent and that the result is accurate. "
            "Provide the result with appropriate precision (integer or decimal)."
        )

        # Split the solution plan into individual steps
        steps = solution_plan.split("\n")
        calculation_tasks = [
            self.generate(
                instruction=calculation_instruction_template.format(step=step.strip()),
                context=self.problem_text
            )
            for step in steps if step.strip()
        ]

        intermediate_results = await asyncio.gather(*calculation_tasks)

        # Step 4: Synthesize the final answer
        synthesis_instruction = (
            "Given the following intermediate results: {results}\n"
            "Combine them appropriately to produce the final answer. Ensure that the answer satisfies "
            "the original question and makes sense in the context of the problem. Provide the final "
            "answer as a single numerical value (integer or decimal)."
        )
        final_answer = await self.ensemble(
            instruction=synthesis_instruction.format(results=", ".join(intermediate_results)),
            contexts=intermediate_results
        )

        # Step 5: Verify and refine the solution
        verification_instruction = (
            f"Verify that the final answer: {final_answer} is correct and makes sense in the context "
            "of the problem. Check for consistency with the extracted information and the solution plan. "
            "If any issues are found, refine the answer accordingly."
        )
        refined_answer = await self.revise(instruction=verification_instruction, context=final_answer)

        return refined_answer