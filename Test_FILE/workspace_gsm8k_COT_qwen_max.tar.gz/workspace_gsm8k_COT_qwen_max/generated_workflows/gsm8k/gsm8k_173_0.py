# Workflow ID: gsm8k_173_0
# Benchmark: gsm8k
# Data Indices: [37, 140]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, relationships, and constraints. "
            "List them clearly and label them appropriately (e.g., knowns, unknowns, units)."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a solution plan
        plan_instruction = (
            f"Using the extracted information: {extracted_info}, formulate a step-by-step plan to solve the problem. "
            "Identify intermediate calculations, ensure unit consistency, and outline the logical flow of operations."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Perform calculations
        calculation_instruction = (
            f"Follow this solution plan: {solution_plan}. Execute the calculations step by step, showing all work. "
            "Ensure that each step logically follows from the previous one and that units are handled correctly."
        )
        calculated_result = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Verify and refine the result
        verification_instruction = (
            f"Review the calculated result: {calculated_result}. Verify its correctness by checking unit consistency, "
            "logical coherence, and contextual relevance. Suggest refinements if necessary."
        )
        refined_result = await self.revise(instruction=verification_instruction, context=calculated_result)

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"Condense the problem-solving process and the refined result: {refined_result} into a concise summary. "
            "Highlight the final numerical answer and ensure it is clear and unambiguous."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_result)

        return final_summary