# Workflow ID: gsm8k_41_0
# Benchmark: gsm8k
# Data Indices: [509, 526]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract numerical values, units, and relationships
        extraction_instruction = (
            "Extract all numerical values, units, relationships, and constraints from the problem. "
            "Provide them in a structured format, such as a list or bullet points, for easy reference."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Model the problem mathematically
        modeling_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Model the problem mathematically by identifying the sequence of operations needed to solve it. "
            "Include intermediate steps and specify how each operation relates to the problem context."
        )
        mathematical_model = await self.generate(instruction=modeling_instruction, context=self.problem_text)

        # Step 3: Generate multiple solution approaches in parallel
        solution_instruction_template = (
            f"Using the extracted information: {extracted_info}\n"
            f"And the mathematical model: {mathematical_model}\n"
            "Solve the problem step by step. Ensure all calculations are explicit and justified. "
            "Handle units consistently and verify that the solution makes sense in the problem context."
        )
        solution_approaches = await asyncio.gather(
            self.generate(instruction=f"{solution_instruction_template} Approach 1: Use direct calculation.", context=self.problem_text),
            self.generate(instruction=f"{solution_instruction_template} Approach 2: Use proportional reasoning.", context=self.problem_text),
            self.generate(instruction=f"{solution_instruction_template} Approach 3: Use algebraic equations.", context=self.problem_text)
        )

        # Step 4: Ensemble to determine the best solution
        ensemble_instruction = (
            "Evaluate and synthesize the following candidate solutions. "
            "Ensure the final answer is consistent, handles units correctly, and satisfies all problem constraints. "
            "If there are discrepancies, resolve them and provide the most accurate solution."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=solution_approaches)

        # Step 5: Extract the final numerical answer
        answer_extraction_instruction = (
            f"From the final solution: {final_solution}\n"
            "Extract the single numerical answer. Ensure it is presented as an integer or decimal without additional text."
        )
        final_answer = await self.generate(instruction=answer_extraction_instruction, context=self.problem_text)

        return final_answer