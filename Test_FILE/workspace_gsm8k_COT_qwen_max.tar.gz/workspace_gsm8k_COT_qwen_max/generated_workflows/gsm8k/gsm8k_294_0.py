# Workflow ID: gsm8k_294_0
# Benchmark: gsm8k
# Data Indices: [640, 461]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio
        
        # Step 1: Extract known values, relationships, and the question
        extraction = await self.generate(
            instruction="Extract all numerical values, units, relationships (e.g., addition, subtraction), and the specific question being asked from the problem. Organize this information clearly.",
            context=self.problem_text
        )
        
        # Step 2: Create a detailed step-by-step solution plan
        plan = await self.generate(
            instruction=f"Based on the extracted information: {extraction}, create a detailed step-by-step plan to solve the problem. Include intermediate calculations, ensure the correct order of operations, and verify real-world constraints.",
            context=self.problem_text
        )
        
        # Step 3: Perform calculations in parallel
        # Dynamically split the plan into independent steps
        calculation_steps = plan.split("\n")  # Assuming each step is on a new line
        parallel_tasks = [
            self.generate(
                instruction=f"Perform this specific calculation step: {step}. Ensure accuracy and maintain unit consistency.",
                context=self.problem_text
            )
            for step in calculation_steps if step.strip()
        ]
        calculation_results = await asyncio.gather(*parallel_tasks)
        
        # Step 4: Synthesize results using Ensemble
        synthesis = await self.ensemble(
            instruction="Combine these calculation results into a coherent final answer. Ensure the solution adheres to the original problem's context and constraints.",
            contexts=calculation_results
        )
        
        # Step 5: Revise the synthesized result for accuracy
        revised_result = await self.revise(
            instruction="Critique and refine this result to ensure it makes sense in the context of the problem. Check for potential errors or inconsistencies.",
            context=synthesis
        )
        
        # Step 6: Summarize the final answer
        final_answer = await self.summarize(
            instruction="Condense this result into a single numerical value. Ensure clarity and correctness.",
            context=revised_result
        )
        
        return final_answer