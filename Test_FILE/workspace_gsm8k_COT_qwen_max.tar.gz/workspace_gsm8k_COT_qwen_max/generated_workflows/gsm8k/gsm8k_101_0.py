# Workflow ID: gsm8k_101_0
# Benchmark: gsm8k
# Data Indices: [414, 178]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract knowns and unknowns
        extract_instruction = (
            "Identify all numerical values, relationships, and the specific question being asked. "
            "List them in a structured format with labels such as 'Known Values', 'Unknowns', and 'Question'."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Plan the solution
        plan_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Outline a step-by-step plan to solve the problem. Include the sequence of operations, "
            "any intermediate calculations, and how to handle units or constraints."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Perform calculations
        calculate_instruction = (
            f"Using the solution plan: {solution_plan}\n"
            "Perform the calculations step by step. Show all intermediate results and ensure accuracy."
        )
        calculations = await self.generate(instruction=calculate_instruction, context=self.problem_text)

        # Step 4: Verify the answer
        verify_instruction = (
            f"Review the calculations: {calculations}\n"
            "Check for correctness, unit consistency, and real-world constraints. "
            "Refine the results if necessary."
        )
        verified_answer = await self.revise(instruction=verify_instruction, context=calculations)

        # Step 5: Summarize the final answer
        summarize_instruction = (
            f"Condense the verified results: {verified_answer}\n"
            "Extract the final numerical answer as a single value. Ensure it is clear and unambiguous."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=verified_answer)

        return final_answer