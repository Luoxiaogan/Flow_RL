# Workflow ID: gsm8k_70_0
# Benchmark: gsm8k
# Data Indices: [476, 56]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract known information
        extraction_instruction = """
        Analyze the problem and extract all numerical values, units, relationships, and key entities. 
        Identify any hidden constraints or intermediate steps required to solve the problem. 
        Format the extracted information as a structured list for clarity.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan the solution approach
        planning_instruction = f"""
        Based on the following extracted information: {extracted_info}
        Create a detailed step-by-step plan to solve the problem. 
        Include all necessary calculations, ensuring proper handling of units and order of operations. 
        Highlight any contextual constraints or real-world considerations.
        """
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Perform calculations
        calculation_instruction = f"""
        Execute the following step-by-step plan: {solution_plan}
        Perform all calculations explicitly, showing intermediate results. 
        Ensure all units are consistent and track them throughout the process. 
        Provide the final numerical answer at the end.
        """
        calculated_result = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Verify the solution
        verification_instruction = """
        Critique the following solution for logical consistency, unit correctness, and adherence to the problem's constraints. 
        Check if the final answer makes sense in the context of the problem. 
        Suggest revisions if necessary.
        """
        verification_task = self.revise(instruction=verification_instruction, context=calculated_result)

        # Step 5: Summarize the result
        summarization_instruction = """
        Condense the following solution into a concise format. 
        Extract and present only the final numerical answer, ensuring it is clear and unambiguous.
        """
        summarization_task = self.summarize(instruction=summarization_instruction, context=calculated_result)

        # Run verification and summarization in parallel
        verified_result, final_answer = await asyncio.gather(verification_task, summarization_task)

        # Return the final answer
        return final_answer