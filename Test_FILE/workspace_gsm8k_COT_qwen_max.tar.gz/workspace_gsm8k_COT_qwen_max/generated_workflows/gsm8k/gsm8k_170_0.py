# Workflow ID: gsm8k_170_0
# Benchmark: gsm8k
# Data Indices: [465, 697]

```python
class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract known information
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, relationships, "
            "and constraints. Include units where applicable and organize the information "
            "in a structured format."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Identify the unknown and plan the solution
        planning_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Determine what the problem is asking for (the unknown) and outline a step-by-step "
            "plan to solve it. Include all necessary calculations and their logical sequence."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Perform sequential calculations
        calculation_instruction = (
            f"Follow this solution plan: {solution_plan}\n"
            "Execute each step of the calculation carefully, producing intermediate results. "
            "Ensure that all units are consistent and that the calculations make sense in context."
        )
        calculations = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Optional: Validate intermediate results
        validation_instruction = (
            f"Review these calculations: {calculations}\n"
            "Check for any errors or inconsistencies. Revise if necessary to ensure accuracy."
        )
        validated_results = await self.revise(instruction=validation_instruction, context=calculations)

        # Step 4: Summarize the final answer
        summary_instruction = (
            f"Based on the validated results: {validated_results}\n"
            "Summarize the final answer in a clear and concise manner. Ensure that it directly "
            "addresses the problem's question and includes appropriate units."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=validated_results)

        return final_answer
```