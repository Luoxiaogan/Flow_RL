# Workflow ID: gsm8k_335_0
# Benchmark: gsm8k
# Data Indices: [205, 108]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information
        extraction_instruction = (
            "Carefully analyze the problem and extract all relevant information. "
            "Identify all numerical values, entities, relationships, and units. "
            "Clearly list the knowns and unknowns. Ensure no detail is missed."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a solution plan
        plan_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. "
            "Outline the sequence of calculations required, including intermediate steps. "
            "Ensure unit consistency and consider real-world constraints. "
            "Clearly specify how to arrive at the final answer."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute calculations
        calculation_instruction = (
            f"Following this solution plan: {solution_plan}\n"
            "Perform all calculations step by step. Show intermediate results and ensure accuracy. "
            "Handle fractions, decimals, and units appropriately. "
            "Verify that each step logically follows from the previous one."
        )
        calculations = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Validate the solution
        validation_instruction = (
            f"Review the calculations: {calculations}\n"
            "Critique the solution for logical consistency, adherence to constraints, and reasonableness. "
            "Check for potential errors, overlooked details, or miscalculations. "
            "Ensure the final answer makes sense in the context of the problem."
        )
        validated_solution = await self.revise(instruction=validation_instruction, context=calculations)

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"Condense the validated solution: {validated_solution}\n"
            "Highlight the final numerical answer and include only the essential information. "
            "Ensure the response is clear, concise, and directly addresses the problem."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=validated_solution)

        return final_answer