# Workflow ID: gsm8k_359_0
# Benchmark: gsm8k
# Data Indices: [412, 435]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (numerical values, units, relationships)
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, units, and relationships. "
            "Organize the information into categories such as 'known values', 'unknowns', and 'relationships'. "
            "Ensure that all units are explicitly noted and any implicit information is clarified."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a step-by-step solution plan
        plan_instruction = (
            f"Based on the extracted information: {extracted_info}, "
            "create a detailed step-by-step plan to solve the problem. "
            "Include the sequence of mathematical operations (e.g., addition, multiplication, division), "
            "any necessary unit conversions, and how intermediate results will be used to compute the final answer."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute calculations in parallel
        # Parse the solution plan to identify independent steps
        calculation_instruction_template = (
            "Perform the following calculation step: {step}. "
            "Ensure that all units are consistent and show your work clearly."
        )
        steps = ["Step 1", "Step 2", "Step 3"]  # Placeholder; parse solution_plan dynamically in practice
        calculation_tasks = [
            self.generate(instruction=calculation_instruction_template.format(step=step), context=self.problem_text)
            for step in steps
        ]
        calculation_results = await asyncio.gather(*calculation_tasks)

        # Step 4: Synthesize results into a unified solution
        synthesis_instruction = (
            "Combine the following intermediate results into a coherent solution: {results}. "
            "Ensure that the final answer is clearly stated and includes appropriate units."
        ).format(results=", ".join(calculation_results))
        final_solution = await self.ensemble(instruction=synthesis_instruction, contexts=calculation_results)

        # Step 5: Verify and refine the solution
        refinement_instruction = (
            "Review the following solution for accuracy and consistency: {solution}. "
            "Check for unit consistency, logical correctness, and contextual relevance. "
            "Suggest improvements if necessary."
        ).format(solution=final_solution)
        refined_solution = await self.revise(instruction=refinement_instruction, context=final_solution)

        return refined_solution