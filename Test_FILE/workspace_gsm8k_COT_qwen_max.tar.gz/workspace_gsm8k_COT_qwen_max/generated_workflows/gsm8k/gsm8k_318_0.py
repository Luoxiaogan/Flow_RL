# Workflow ID: gsm8k_318_0
# Benchmark: gsm8k
# Data Indices: [391, 264]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information from the problem
        extraction_instruction = (
            "Carefully analyze the problem statement and extract all numerical values, "
            "relationships, and key details. Include units (if any), descriptions of actions "
            "(e.g., 'damaged', 'not used'), and the specific question being asked. "
            "Organize the extracted information clearly for further processing."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan the solution strategy
        planning_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Outline a step-by-step plan to solve the problem. Include intermediate calculations, "
            "hidden steps, and logical sequencing of operations. Ensure the plan accounts for all "
            "relevant details and constraints mentioned in the problem."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Execute parallel solution approaches
        approach_1_instruction = (
            f"Using the extracted information:\n{extracted_info}\nand the solution plan:\n{solution_plan}\n"
            "Solve the problem using a direct calculation approach. Show all intermediate steps and "
            "ensure the answer is consistent with the problem context."
        )
        approach_2_instruction = (
            f"Using the extracted information:\n{extracted_info}\nand the solution plan:\n{solution_plan}\n"
            "Solve the problem using an alternative method, such as validating through unit consistency "
            "or cross-checking with proportional reasoning. Highlight any discrepancies with the first approach."
        )
        results = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text)
        )

        # Step 4: Ensemble decision-making to select or synthesize the best solution
        ensemble_instruction = (
            "Evaluate the following candidate solutions and determine the best answer. "
            "If both solutions agree, return the common result. If they differ, analyze the reasoning "
            "behind each approach and synthesize a final answer that resolves any discrepancies.\n"
            f"Candidate Solution 1:\n{results[0]}\nCandidate Solution 2:\n{results[1]}"
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 5: Verify and refine the final output
        verification_instruction = (
            f"Verify the following solution:\n{final_answer}\nagainst the original problem statement. "
            "Ensure the answer is reasonable, consistent with the context, and formatted correctly. "
            "Refine the output if necessary to improve clarity or correctness."
        )
        refined_answer = await self.revise(instruction=verification_instruction, context=final_answer)

        return refined_answer