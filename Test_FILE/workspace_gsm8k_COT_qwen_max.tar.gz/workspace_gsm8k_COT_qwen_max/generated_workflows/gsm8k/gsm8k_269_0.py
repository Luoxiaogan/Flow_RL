# Workflow ID: gsm8k_269_0
# Benchmark: gsm8k
# Data Indices: [677, 774]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (numerical values, relationships, entities)
        extraction_instruction = (
            "Extract all numerical values, relationships, and key entities (e.g., people, objects) "
            "from the problem. Explicitly state what is known and what needs to be determined. "
            "Organize the information clearly for subsequent reasoning steps."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Perform intermediate reasoning and calculations
        reasoning_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Break the problem into intermediate steps. Perform sequential calculations to determine "
            "the unknowns. Clearly show each step and its result. Ensure units and relationships are "
            "consistent throughout."
        )
        intermediate_results = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Validate and refine intermediate results
        validation_instruction = (
            "Critique the intermediate results for correctness and consistency. Check for unit coherence, "
            "logical alignment with the problem's constraints, and proper handling of relationships. "
            "Refine any errors or ambiguities."
        )
        refined_results = await self.revise(instruction=validation_instruction, context=intermediate_results)

        # Step 4: Synthesize the final answer
        synthesis_instruction = (
            f"Using the refined results: {refined_results}\n"
            "Synthesize the final answer. Combine all calculated values and ensure the result makes sense "
            "in the problem's context. Explicitly state the reasoning behind the final answer."
        )
        final_answer = await self.generate(instruction=synthesis_instruction, context=self.problem_text)

        return final_answer