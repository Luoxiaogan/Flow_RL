# Workflow ID: gsm8k_133_0
# Benchmark: gsm8k
# Data Indices: [680, 442]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (numerical values, relationships, units)
        extraction_instruction = (
            "Extract all numerical values, relationships, and constraints from the problem. "
            "Identify the question being asked and any intermediate steps required to solve it. "
            "Ensure units are preserved and clearly stated."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Construct a step-by-step solution
        solution_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "construct a step-by-step solution to the problem. "
            "Clearly state each calculation, ensure proper sequencing of operations, "
            "and maintain unit consistency throughout. "
            "Include intermediate results and verify their correctness."
        )
        step_by_step_solution = await self.generate(instruction=solution_instruction, context=self.problem_text)

        # Step 3: Validate and refine the solution
        refinement_instruction = (
            "Critique the provided solution for logical consistency, accuracy, and completeness. "
            "Check for calculation errors, missing steps, or incorrect assumptions. "
            "Refine the solution to ensure it is correct and easy to follow."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=step_by_step_solution)

        # Step 4: Extract the final answer
        summarization_instruction = (
            "From the refined solution, extract the final numerical answer. "
            "Ensure the answer is clearly stated and includes appropriate units if necessary."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_solution)

        return final_answer