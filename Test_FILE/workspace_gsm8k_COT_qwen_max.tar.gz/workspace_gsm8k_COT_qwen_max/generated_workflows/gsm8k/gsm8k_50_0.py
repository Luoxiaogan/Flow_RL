# Workflow ID: gsm8k_50_0
# Benchmark: gsm8k
# Data Indices: [731, 537]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key numerical values and relationships
        extraction_instruction = (
            "Thoroughly analyze the problem text and extract all numerical values, units, "
            "and relationships between them. Include any constraints or conditions mentioned. "
            "Format the output as a structured list of key-value pairs."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a step-by-step solution plan
        plan_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "create a detailed step-by-step plan to solve the problem. "
            "Include all necessary calculations, ensure unit consistency, and specify the order of operations."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Perform calculations based on the plan
        calculation_instruction = (
            f"Execute the following solution plan step by step: {solution_plan}. "
            "Perform all calculations explicitly and provide intermediate results. "
            "Ensure the final result is a single numerical value with appropriate units."
        )
        calculated_result = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Revise and verify the solution
        revision_instruction = (
            "Review the calculated result for accuracy and consistency with the problem's context. "
            "Check for any errors in calculations, unit conversions, or logical reasoning. "
            "Provide suggestions for improvement if necessary."
        )
        revised_result = await self.revise(instruction=revision_instruction, context=calculated_result)

        # Step 5: Summarize the final answer
        summary_instruction = (
            "Condense the final result into a concise format. "
            "Ensure the output is a single numerical value without any additional text."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=revised_result)

        return final_answer