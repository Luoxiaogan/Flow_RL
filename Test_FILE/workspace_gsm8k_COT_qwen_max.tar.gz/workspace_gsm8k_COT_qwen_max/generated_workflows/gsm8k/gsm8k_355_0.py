# Workflow ID: gsm8k_355_0
# Benchmark: gsm8k
# Data Indices: [68, 482]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information from the problem text
        extraction_instruction = (
            "Thoroughly analyze the problem statement to extract all numerical values, "
            "relationships, and constraints. Identify known quantities, unknowns, and any "
            "implicit information. Present the extracted information in a structured format."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a step-by-step solution plan
        solution_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. Ensure that all intermediate "
            "calculations are explicitly stated, units are consistent, and the sequence of operations "
            "is logically ordered. Include any necessary checks for real-world constraints."
        )
        solution_plan = await self.generate(instruction=solution_instruction, context=self.problem_text)

        # Step 3: Validate and refine the solution plan
        validation_instruction = (
            "Critically review the provided solution plan. Check for logical consistency, unit accuracy, "
            "and adherence to the problem constraints. Suggest improvements or corrections if necessary."
        )
        refined_solution = await self.revise(instruction=validation_instruction, context=solution_plan)

        # Step 4: Extract the final numerical answer
        extraction_instruction_final = (
            "From the refined solution, extract the final numerical answer. Ensure that the answer "
            "is presented as a single value without any additional text or explanations."
        )
        final_answer = await self.summarize(instruction=extraction_instruction_final, context=refined_solution)

        return final_answer