# Workflow ID: gsm8k_349_0
# Benchmark: gsm8k
# Data Indices: [93, 255]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract numerical values and relationships
        extraction_instruction = (
            "Extract all numerical values, units, and relationships from the problem. "
            "Include any constraints, conditions, or contextual information that might affect the solution. "
            "Organize the extracted information clearly."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Identify the unknown and solution requirements
        unknown_instruction = (
            f"Based on the extracted information: {extracted_info}, "
            "identify what the problem is asking for. "
            "Clearly state the unknown value or quantity that needs to be determined. "
            "Also, specify any additional requirements, such as unit conversions or rounding rules."
        )
        unknown = await self.generate(instruction=unknown_instruction, context=self.problem_text)

        # Step 3: Plan the solution strategy
        plan_instruction = (
            f"Given the extracted information: {extracted_info}, and the unknown: {unknown}, "
            "create a detailed step-by-step plan to solve the problem. "
            "Include all calculations, intermediate results, and logical reasoning. "
            "Ensure the plan accounts for any constraints or contextual factors."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 4: Execute calculations
        execution_instruction = (
            f"Follow this plan: {solution_plan} to perform the calculations. "
            "Execute each step carefully, maintaining unit consistency and precision. "
            "Provide the final result along with any intermediate results for verification."
        )
        raw_solution = await self.generate(instruction=execution_instruction, context=self.problem_text)

        # Step 5: Verify and refine the solution
        verification_instruction = (
            f"Review the solution: {raw_solution} against the problem context: {self.problem_text}. "
            "Check for logical consistency, unit correctness, and adherence to constraints. "
            "If errors or ambiguities are found, suggest refinements."
        )
        refined_solution = await self.revise(instruction=verification_instruction, context=raw_solution)

        # Step 6: Summarize the final answer
        summary_instruction = (
            f"From the refined solution: {refined_solution}, "
            "extract and present the final numerical answer. "
            "Ensure the answer is clear, concise, and formatted correctly."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer