# Workflow ID: gsm8k_242_0
# Benchmark: gsm8k
# Data Indices: [289, 534]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all numerical values and relationships
        extraction_instruction = """
        From the given problem, extract all numerical values, units, and relationships between them. 
        Identify any constraints or conditions that affect the calculations. 
        Present the extracted information in a structured format, clearly separating values, units, and relationships.
        """
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate step-by-step solution plans
        solution_instruction = f"""
        Using the extracted information: {extraction}
        Formulate a step-by-step plan to solve the problem. 
        Clearly outline each calculation step, including any intermediate results needed. 
        Ensure that the plan accounts for all constraints and conditions mentioned in the problem.
        """
        solution_plan = await self.generate(instruction=solution_instruction, context=self.problem_text)

        # Step 3: Generate multiple solution approaches in parallel
        approach1_instruction = f"""
        Solve the problem using the following plan: {solution_plan}
        Focus on clarity and precision in each step. Provide intermediate results and explain your reasoning.
        """
        approach2_instruction = f"""
        Solve the problem using the following plan: {solution_plan}
        Explore an alternative method or sequence of steps if possible. Provide intermediate results and explain your reasoning.
        """

        results = await asyncio.gather(
            self.generate(instruction=approach1_instruction, context=self.problem_text),
            self.generate(instruction=approach2_instruction, context=self.problem_text)
        )

        # Step 4: Ensemble decision-making to select the best solution
        ensemble_instruction = """
        Compare the provided solutions and select the most accurate and contextually appropriate one.
        Consider the clarity of reasoning, adherence to the problem constraints, and correctness of calculations.
        If both solutions are equally valid, choose one and justify your selection.
        """
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 5: Extract the final numerical answer
        answer_instruction = """
        From the selected solution, extract the final numerical answer. 
        Ensure that the answer is presented clearly and is appropriately formatted according to the problem's requirements.
        """
        final_answer = await self.generate(instruction=answer_instruction, context=final_solution)

        return final_answer