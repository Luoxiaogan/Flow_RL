# Workflow ID: gsm8k_105_0
# Benchmark: gsm8k
# Data Indices: [239, 585]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract and Understand the Problem
        extraction_instruction = (
            "Carefully analyze the problem and extract all relevant information, including: "
            "- Numerical values and their units (e.g., dollars, hours, miles). "
            "- Relationships between quantities (e.g., rates, ratios, proportions). "
            "- Implicit constraints or conditions (e.g., time-based sequences, real-world limitations). "
            "Provide a structured summary of the problem's components."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Break Down the Problem into Steps and Solve
        reasoning_instruction = (
            f"Given the extracted information: {extracted_info} "
            "Break the problem into sequential steps and solve each step systematically. "
            "Include intermediate calculations and ensure all units are handled consistently. "
            "If there are multiple stages or dependencies, clearly outline them and compute results iteratively."
        )
        intermediate_solution = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Verify and Refine the Solution
        refinement_instruction = (
            "Critically evaluate the following solution for correctness and completeness: "
            f"{intermediate_solution} "
            "Check for: "
            "- Logical consistency in calculations. "
            "- Proper handling of units and decimal places. "
            "- Real-world constraints (e.g., no negative quantities, realistic rounding). "
            "Refine the solution if necessary, providing a corrected version."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=intermediate_solution)

        # Step 4: Extract the Final Numerical Answer
        summarization_instruction = (
            "From the refined solution: "
            f"{refined_solution} "
            "Extract the final numerical answer as a single value. "
            "Ensure the result is clear, unambiguous, and formatted appropriately (integer or decimal)."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_solution)

        return final_answer