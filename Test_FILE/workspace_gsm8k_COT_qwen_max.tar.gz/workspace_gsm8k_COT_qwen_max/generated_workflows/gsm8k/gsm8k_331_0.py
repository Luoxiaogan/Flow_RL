# Workflow ID: gsm8k_331_0
# Benchmark: gsm8k
# Data Indices: [742, 612]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information
        extraction_instruction = (
            "Extract all numerical values, units, relationships, and constraints from the problem. "
            "Identify what is known and what needs to be calculated. Ensure you capture all relevant details."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate the solution plan
        plan_instruction = (
            f"Based on the following extracted information: {extracted_info} "
            "Create a detailed, step-by-step plan to solve the problem. Include all necessary calculations, "
            "intermediate steps, and ensure unit consistency throughout."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute calculations in parallel
        calculation_instructions = []
        for step in solution_plan.split("\n"):  # Assuming each step is on a new line
            if step.strip():  # Ignore empty lines
                calculation_instructions.append(
                    f"Perform the following calculation step: {step}. Ensure accuracy and include units."
                )
        
        calculation_tasks = [
            self.generate(instruction=instr, context=self.problem_text) for instr in calculation_instructions
        ]
        calculation_results = await asyncio.gather(*calculation_tasks)

        # Step 4: Synthesize results
        synthesis_instruction = (
            "Combine the following calculation results into a coherent final answer. "
            "Ensure the synthesis respects the problem's context and constraints. Resolve any discrepancies."
        )
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=calculation_results)

        # Step 5: Validate and refine
        validation_instruction = (
            f"Validate the final answer: {final_answer} against the problem's context. "
            "Check unit consistency, verify intermediate steps, and ensure the answer makes sense in the real-world scenario. "
            "Refine the answer if necessary."
        )
        refined_answer = await self.revise(instruction=validation_instruction, context=final_answer)

        return refined_answer