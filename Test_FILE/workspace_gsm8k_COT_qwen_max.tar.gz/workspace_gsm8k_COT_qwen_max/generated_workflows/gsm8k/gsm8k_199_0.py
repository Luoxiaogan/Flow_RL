# Workflow ID: gsm8k_199_0
# Benchmark: gsm8k
# Data Indices: [394, 333]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract numerical values, relationships, and units
        extraction_instruction = (
            "Extract all numerical values, their associated units, and relationships between them from the problem. "
            "Include any implicit information such as rates, percentages, or constraints. "
            "Format the output as a structured list for clarity."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Perform step-by-step calculations
        calculation_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "solve the problem step-by-step. Include all intermediate calculations and explicitly state the reasoning behind each step. "
            "Ensure that units are consistent throughout and that the solution adheres to the problem's constraints."
        )
        initial_solution = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 3: Verify and refine the solution
        refinement_instruction = (
            "Critique the provided solution. Check for unit consistency, logical coherence, and adherence to the problem's constraints. "
            "Refine the solution if necessary, providing corrections or improvements. Ensure the final result makes sense in the context of the problem."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=initial_solution)

        # Step 4: Summarize the final answer
        summarization_instruction = (
            "Extract the final numerical answer from the refined solution. "
            "Ensure the answer is presented as a single numerical value (integer or decimal) without additional text."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_solution)

        return final_answer