# Workflow ID: gsm8k_188_0
# Benchmark: gsm8k
# Data Indices: [80, 569]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract known information
        extraction_instruction = (
            "Extract all numerical values, units, relationships, and constraints from the problem. "
            "Identify what is being asked and any intermediate steps required to solve the problem."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate the problem mathematically
        formulation_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Translate the problem into a mathematical model. Identify the operations needed (e.g., addition, multiplication) "
            "and sequence them correctly. Include units and ensure consistency throughout."
        )
        mathematical_model = await self.generate(instruction=formulation_instruction, context=self.problem_text)

        # Step 3: Perform calculations
        calculation_instruction_template = (
            f"Using the mathematical model: {mathematical_model}\n"
            "Perform the specified calculations step by step. Ensure intermediate results are accurate and labeled with units."
        )
        # Parallelize independent calculations
        calculation_tasks = [
            self.generate(instruction=calculation_instruction_template, context=self.problem_text),
            self.generate(instruction=calculation_instruction_template, context=self.problem_text)
        ]
        intermediate_results = await asyncio.gather(*calculation_tasks)

        # Step 4: Verify the solution
        verification_instruction = (
            f"Review the following results: {intermediate_results}\n"
            "Ensure they align with the problem's context and constraints. Check for unit consistency, logical coherence, "
            "and real-world feasibility. Suggest corrections if necessary."
        )
        verified_solution = await self.revise(instruction=verification_instruction, context=self.problem_text)

        # Step 5: Synthesize the final answer
        summarization_instruction = (
            f"Condense the reasoning and results into a single final answer. The verified solution is: {verified_solution}\n"
            "Present only the numerical value as the final output."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=self.problem_text)

        return final_answer