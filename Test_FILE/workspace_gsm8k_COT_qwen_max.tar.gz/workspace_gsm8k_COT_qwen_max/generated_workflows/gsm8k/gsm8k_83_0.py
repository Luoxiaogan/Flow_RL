# Workflow ID: gsm8k_83_0
# Benchmark: gsm8k
# Data Indices: [154, 649]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1 & 2: Extract known information and identify the unknown (parallel execution)
        extract_instruction = """
        Extract all numerical values, their associated units (if any), and any relationships or constraints mentioned in the problem.
        Ensure you capture every piece of quantitative information provided in the problem statement.
        """
        identify_instruction = """
        Identify what the problem is asking for. Determine the unknown value(s) that need to be calculated.
        Outline any intermediate steps required to reach the solution.
        """
        extract_task = self.generate(instruction=extract_instruction, context=self.problem_text)
        identify_task = self.generate(instruction=identify_instruction, context=self.problem_text)
        extracted_info, identified_unknown = await asyncio.gather(extract_task, identify_task)

        # Step 3: Plan the solution
        plan_instruction = f"""
        Based on the following extracted information: {extracted_info}
        And the identified unknown: {identified_unknown}
        Create a step-by-step plan to solve the problem. Include the sequence of operations (addition, subtraction, multiplication, division, etc.)
        and specify how to handle units consistently. Emphasize the importance of order of operations, unit consistency, and verifying that the solution makes sense in context.
        """
        plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 4: Execute calculations
        execute_instruction = f"""
        Following this plan: {plan}
        Perform the calculations step by step. Keep track of intermediate results and ensure that each operation is executed correctly.
        Handle any necessary unit conversions or contextual constraints as specified in the plan.
        """
        calculations = await self.generate(instruction=execute_instruction, context=self.problem_text)

        # Step 5: Verify and refine
        verify_instruction = f"""
        Review the following calculations: {calculations}
        Check each step for accuracy, verify the order of operations, and ensure that the final result makes sense in the context of the problem.
        Refine the solution if necessary, correcting any errors or inconsistencies.
        """
        refined_solution = await self.revise(instruction=verify_instruction, context=calculations)

        # Step 6: Summarize the answer
        summarize_instruction = """
        Condense the final result into a single numerical value. Ensure that it is clearly presented and formatted correctly.
        The output should be the final answer, stripped of any extraneous information.
        """
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_answer