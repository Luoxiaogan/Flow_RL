# Workflow ID: gsm8k_39_0
# Benchmark: gsm8k
# Data Indices: [11, 350]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract known information and relationships
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, relationships, "
            "and constraints. Explicitly state any implicit relationships or assumptions. "
            "Ensure the extracted information is comprehensive and accurate."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a mathematical model
        model_instruction = (
            f"Based on the following extracted information: {extracted_info}\n"
            "Formulate a mathematical model to solve the problem. Identify variables, equations, "
            "or operations needed. Ensure the model is precise and accounts for all constraints."
        )
        mathematical_model = await self.generate(instruction=model_instruction, context=self.problem_text)

        # Step 3: Solve the problem step-by-step
        solve_instruction = (
            f"Using the mathematical model: {mathematical_model}\n"
            "Perform the calculations step-by-step. Clearly show intermediate results and ensure "
            "unit consistency and logical correctness. Verify that the solution satisfies all constraints."
        )
        solution_attempts = await asyncio.gather(
            self.generate(instruction=solve_instruction, context=self.problem_text),
            self.generate(instruction=solve_instruction, context=self.problem_text)
        )

        # Step 4: Validate and refine the solution
        refine_instruction = (
            "Critique the following solution and ensure it aligns with the problem context and constraints. "
            "Verify that the final answer makes sense and is free of errors. Suggest improvements if necessary."
        )
        refined_solutions = await asyncio.gather(
            self.revise(instruction=refine_instruction, context=solution_attempts[0]),
            self.revise(instruction=refine_instruction, context=solution_attempts[1])
        )

        # Step 5: Select the best solution using Ensemble
        ensemble_instruction = (
            "Compare the following solutions and select the most accurate and contextually valid one. "
            "If both solutions are valid, synthesize a refined solution that combines their strengths."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_solutions)

        # Step 6: Summarize the final answer
        summarize_instruction = (
            "Condense the following solution into a concise, clear format. Present only the final answer "
            "and ensure it is easy to understand."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=final_solution)

        return final_answer