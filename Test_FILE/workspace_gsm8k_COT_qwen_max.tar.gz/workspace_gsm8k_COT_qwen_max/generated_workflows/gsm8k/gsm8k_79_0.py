# Workflow ID: gsm8k_79_0
# Benchmark: gsm8k
# Data Indices: [45, 408]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract known information
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, relationships, and contextual details. "
            "Ensure you capture units, constraints, and any implicit information. "
            "Format the extracted information clearly for further processing."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a solution plan
        planning_instruction = (
            f"Based on the following extracted information: {extracted_info} "
            "Create a detailed step-by-step plan to solve the problem. "
            "Identify intermediate calculations, ensure unit consistency, and account for any hidden steps. "
            "Clearly outline the sequence of operations needed to arrive at the final answer."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Execute calculations
        calculation_instruction = (
            f"Follow this solution plan: {solution_plan} "
            "Perform all required calculations step by step. "
            "Ensure accuracy in arithmetic operations, handle units properly, and document intermediate results. "
            "Provide the final numerical result at the end."
        )
        calculated_result = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Verify and refine the result
        refinement_instruction = (
            f"Review the following calculated result: {calculated_result} "
            "Check for logical consistency, real-world constraints, and proper formatting. "
            "Refine the result if necessary to ensure it is accurate and well-presented."
        )
        refined_result = await self.revise(instruction=refinement_instruction, context=calculated_result)

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"Condense the following refined result: {refined_result} "
            "Ensure the summary directly answers the question posed in the problem. "
            "Present the final answer as a single numerical value with appropriate precision."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_result)

        return final_answer