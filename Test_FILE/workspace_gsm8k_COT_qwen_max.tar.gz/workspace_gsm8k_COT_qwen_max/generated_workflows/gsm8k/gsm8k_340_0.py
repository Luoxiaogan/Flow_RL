# Workflow ID: gsm8k_340_0
# Benchmark: gsm8k
# Data Indices: [261, 655]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant numerical values, relationships, and units
        extraction_instruction = (
            "Extract all numerical values, relationships, and units from the problem. "
            "Clearly identify what is given and what is being asked. Ensure that all units "
            "are explicitly stated and consistent. Format the output as a structured list."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate a step-by-step plan for solving the problem
        plan_instruction = (
            f"Based on the following extracted information: {extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. Include all necessary "
            "calculations, intermediate results, and any hidden steps that may not be explicitly "
            "stated in the problem. Ensure that the plan accounts for unit consistency and "
            "real-world constraints."
        )
        plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute independent calculations in parallel
        # Parse the plan into individual steps dynamically
        steps = plan.split("\n")  # Assuming each step is on a new line
        tasks = []
        for step in steps:
            if step.strip():  # Ignore empty lines
                step_instruction = (
                    f"Perform the following calculation: {step}\n"
                    "Ensure that all intermediate results are clearly stated and that units "
                    "are consistent. Provide the result in a structured format."
                )
                task = self.generate(instruction=step_instruction, context=self.problem_text)
                tasks.append(task)
        intermediate_results = await asyncio.gather(*tasks)

        # Step 4: Synthesize intermediate results into a final answer
        synthesis_instruction = (
            "Combine the following intermediate results into a final answer. "
            "Ensure that all calculations are accounted for and that the final result "
            "makes sense in the context of the problem. Format the output as a single "
            "numerical value with appropriate units."
        )
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=intermediate_results)

        # Step 5: Validate and refine the final answer
        refinement_instruction = (
            f"Validate the following answer: {final_answer}\n"
            "Check it against the problem constraints and ensure that it adheres to real-world "
            "constraints (e.g., no negative items, fractional people). If necessary, refine the "
            "answer to ensure correctness."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        return refined_answer