# Workflow ID: gsm8k_238_0
# Benchmark: gsm8k
# Data Indices: [645, 495]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (numerical values, relationships, units)
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, their associated units, "
            "and any relationships or constraints mentioned. For example, identify quantities like '5 bouquets', "
            "'7 table decorations', or rates like '12 white roses per table decoration'. Ensure the extracted "
            "information is complete and accurate for solving the problem."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate a step-by-step solution
        solution_instruction = (
            f"Using the extracted information: {extracted_info}, construct a step-by-step solution to the problem. "
            "Clearly outline each calculation, including intermediate results and their units. Ensure the solution "
            "follows the correct order of operations and accounts for any real-world constraints (e.g., non-negative "
            "quantities, fractional values where appropriate). Provide the final answer as a single numerical value."
        )
        solution = await self.generate(instruction=solution_instruction, context=self.problem_text)

        # Step 3: Revise and refine the solution
        revision_instruction = (
            "Critique the provided solution for logical consistency, correct order of operations, and adherence "
            "to real-world constraints. Check for any missing steps, incorrect calculations, or inconsistencies "
            "in unit handling. Refine the solution to ensure it is accurate and complete."
        )
        refined_solution = await self.revise(instruction=revision_instruction, context=solution)

        # Step 4: Summarize the final answer
        summary_instruction = (
            "Extract the final numerical answer from the refined solution. Ensure the answer is concise, "
            "accurate, and directly addresses the question posed in the problem."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer