# Workflow ID: gsm8k_4_0
# Benchmark: gsm8k
# Data Indices: [587, 707]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract knowns and unknowns
        extract_instruction = (
            "Extract all numerical values, units, and relationships from the problem. "
            "Identify what is known and what needs to be solved. "
            "Ensure you capture all relevant details necessary for solving the problem."
        )
        knowns_unknowns = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Plan the solution strategy
        strategy_instruction = (
            f"Based on the following extracted information: {knowns_unknowns} "
            "Create a detailed step-by-step plan to solve the problem. "
            "Specify the sequence of operations, intermediate calculations, and any constraints. "
            "Ensure the plan is logical and accounts for all aspects of the problem."
        )
        solution_strategy = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Perform calculations
        calculation_instruction = (
            f"Using the following solution strategy: {solution_strategy} "
            "Execute the calculations step-by-step. "
            "Ensure proper handling of units, order of operations, and intermediate results. "
            "Provide the final answer along with a justification of each step."
        )
        calculations = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Validate the result
        validation_instruction = (
            f"Review the following calculations and final answer: {calculations} "
            "Critique the result to ensure it is correct and makes sense in the context of the problem. "
            "Flag any inconsistencies, unrealistic values, or errors in reasoning."
        )
        validated_result = await self.revise(instruction=validation_instruction, context=calculations)

        # Step 5: Summarize the answer
        summary_instruction = (
            f"Condense the following validated result into a concise summary: {validated_result} "
            "Include the final answer and key steps of the reasoning process. "
            "Ensure the summary is clear and easy to understand."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=validated_result)

        return final_summary