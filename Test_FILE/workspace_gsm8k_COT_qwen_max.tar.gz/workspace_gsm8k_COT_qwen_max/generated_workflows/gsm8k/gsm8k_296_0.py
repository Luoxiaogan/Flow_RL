# Workflow ID: gsm8k_296_0
# Benchmark: gsm8k
# Data Indices: [238, 776]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all numerical values, relationships, and constraints
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, relationships, "
            "and constraints. Organize them in a structured format, clearly labeling each piece "
            "of information. Pay attention to units, implicit relationships, and any hidden steps."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan the step-by-step solution
        planning_instruction = (
            f"Using the following extracted information: {extracted_info}\n"
            "Plan the sequence of operations required to solve the problem. Identify intermediate "
            "calculations, handle units consistently, and ensure the order of operations is correct. "
            "Provide a detailed step-by-step breakdown of the solution process."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Explore multiple solution approaches in parallel
        approach1_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Solve the problem using direct calculation. Perform each step explicitly, showing all "
            "intermediate results. Ensure the final answer is clearly stated and makes sense in the context."
        )
        approach2_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Solve the problem using algebraic reasoning. Define variables, set up equations, and solve "
            "them step by step. Verify that the solution satisfies all constraints."
        )
        approach1, approach2 = await asyncio.gather(
            self.generate(instruction=approach1_instruction, context=self.problem_text),
            self.generate(instruction=approach2_instruction, context=self.problem_text)
        )

        # Step 4: Synthesize and validate the results
        synthesis_instruction = (
            "Compare the following two solutions:\n"
            f"Solution 1: {approach1}\n"
            f"Solution 2: {approach2}\n"
            "Evaluate their logical consistency, correctness, and adherence to the problem's constraints. "
            "Synthesize a final solution that combines the strengths of both approaches."
        )
        final_solution = await self.ensemble(instruction=synthesis_instruction, contexts=[approach1, approach2])

        # Step 5: Extract the final numerical answer
        answer_extraction_instruction = (
            f"From the final solution: {final_solution}\n"
            "Extract the final numerical answer. Ensure it is clearly stated and formatted appropriately."
        )
        final_answer = await self.generate(instruction=answer_extraction_instruction, context=self.problem_text)

        return final_answer