# Workflow ID: gsm8k_174_0
# Benchmark: gsm8k
# Data Indices: [764, 55]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all numerical values, relationships, units, and the specific question being asked. "
            "Identify any implicit intermediate steps or constraints. Provide the output in a structured format."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan the solution based on the extracted information
        planning_instruction = (
            f"Based on the following extracted information: {extracted_info}\n"
            "Outline a step-by-step plan to solve the problem. Include all necessary calculations, "
            "intermediate steps, and unit conversions. Ensure the plan is clear and logical."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Generate two independent solutions in parallel
        solution_instruction = (
            f"Follow this solution plan: {solution_plan}\n"
            "Solve the problem step by step, showing all intermediate calculations and reasoning. "
            "Ensure the final answer is a single numerical value."
        )
        solution1, solution2 = await asyncio.gather(
            self.generate(instruction=solution_instruction, context=self.problem_text),
            self.generate(instruction=solution_instruction, context=self.problem_text)
        )

        # Step 4: Revise and refine each solution
        revise_instruction = (
            "Critique and refine the following solution. Check for logical consistency, unit correctness, "
            "and adherence to the problem's constraints. Suggest improvements if necessary."
        )
        refined_solution1 = await self.revise(instruction=revise_instruction, context=solution1)
        refined_solution2 = await self.revise(instruction=revise_instruction, context=solution2)

        # Step 5: Ensemble decision-making to select the best solution
        ensemble_instruction = (
            "Compare the following solutions and select the best one. Evaluate based on correctness, "
            "clarity, and alignment with the problem's requirements. Provide the final answer as a single numerical value."
        )
        final_answer = await self.ensemble(
            instruction=ensemble_instruction,
            contexts=[refined_solution1, refined_solution2]
        )

        return final_answer