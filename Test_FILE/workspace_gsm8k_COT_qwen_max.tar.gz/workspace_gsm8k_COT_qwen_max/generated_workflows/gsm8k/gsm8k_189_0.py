# Workflow ID: gsm8k_189_0
# Benchmark: gsm8k
# Data Indices: [548, 220]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, units, "
            "relationships, and constraints. Clearly identify what is being asked. "
            "Provide the extracted information in a structured format."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Perform intermediate calculations
        calculation_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "perform all necessary intermediate calculations step by step. "
            "Ensure that each step is clearly explained and logically follows from the previous one. "
            "Include unit conversions and track constraints throughout."
        )
        intermediate_results = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 3: Derive the final solution
        final_solution_instruction = (
            f"Based on the intermediate results: {intermediate_results}, "
            "derive the final solution to the problem. Ensure that the answer is consistent with the context, "
            "adheres to any constraints, and makes sense in the real-world scenario described. "
            "Provide the final answer as a single numerical value with appropriate units if applicable."
        )
        final_solution = await self.generate(instruction=final_solution_instruction, context=self.problem_text)

        # Step 4: Validate and refine the solution
        validation_instruction = (
            f"Review the final solution: {final_solution} against the original problem. "
            "Check for any errors, inconsistencies, or missed steps in the reasoning process. "
            "If necessary, refine the solution to ensure accuracy and clarity."
        )
        refined_solution = await self.revise(instruction=validation_instruction, context=final_solution)

        return refined_solution