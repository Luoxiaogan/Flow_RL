# Workflow ID: gsm8k_353_0
# Benchmark: gsm8k
# Data Indices: [383, 57]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract relevant numerical values and relationships
        extraction_instruction = """
        Carefully analyze the problem and extract all numerical values, relationships, and constraints. 
        Identify what is given and what is being asked. Format the extracted information clearly and concisely.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Perform intermediate reasoning and calculations
        reasoning_instruction = f"""
        Using the extracted information: {extracted_info}
        Solve the problem step by step. Clearly show all intermediate calculations and reasoning steps. 
        Ensure that units are consistent and real-world constraints are respected. 
        Provide a detailed breakdown of how the final answer is derived.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Validate and refine the solution
        refinement_instruction = """
        Critique the provided solution for logical consistency, unit correctness, and adherence to real-world constraints. 
        Refine the solution if necessary, ensuring all steps are accurate and well-justified. 
        Highlight any assumptions or clarifications made during refinement.
        """
        refined_solution = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 4: Extract the final numerical answer
        final_answer_instruction = """
        From the refined solution, extract the final numerical answer. 
        Ensure the answer is a single number (integer or decimal) without any additional text or explanation.
        """
        final_answer = await self.generate(instruction=final_answer_instruction, context=refined_solution)

        return final_answer