# Workflow ID: gsm8k_119_0
# Benchmark: gsm8k
# Data Indices: [703, 363]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information
        extraction_instruction = (
            "Extract all numerical values, units, relationships, and constraints from the problem. "
            "Identify what is known and what needs to be calculated. "
            "Ensure you capture any hidden steps or implicit operations."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Model the problem mathematically
        modeling_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Translate the problem into a mathematical model or sequence of operations. "
            "Clearly identify intermediate steps, hidden calculations, and the order of operations. "
            "Include any necessary unit conversions or contextual constraints."
        )
        mathematical_model = await self.generate(instruction=modeling_instruction, context=self.problem_text)

        # Step 3: Perform calculations
        calculation_instruction = (
            f"Using the mathematical model: {mathematical_model}\n"
            "Perform the required calculations step-by-step. "
            "Ensure each step is logically sound and contextually valid. "
            "Include intermediate results and the final answer."
        )
        calculations = await asyncio.gather(
            self.generate(instruction=calculation_instruction, context=self.problem_text),
            self.generate(instruction=calculation_instruction, context=self.problem_text)  # Parallel execution
        )

        # Step 4: Validate and refine
        refinement_instruction = (
            f"Critique the following calculations: {calculations}\n"
            "Ensure they align with the problem's context. "
            "Check for unit consistency, logical correctness, and real-world feasibility. "
            "Refine any steps that are ambiguous or incorrect."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=calculations[0])

        # Step 5: Summarize the solution
        summary_instruction = (
            f"Condense the reasoning and calculations: {refined_solution}\n"
            "Present the final answer in a concise format, including units if applicable."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer