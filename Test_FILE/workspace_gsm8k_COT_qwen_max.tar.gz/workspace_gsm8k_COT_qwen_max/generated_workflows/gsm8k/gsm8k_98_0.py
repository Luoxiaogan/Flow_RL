# Workflow ID: gsm8k_98_0
# Benchmark: gsm8k
# Data Indices: [501, 354]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (numerical values, units, relationships, question)
        extract_instruction = """
        Extract all numerical values, units, relationships, and the specific question being asked from the problem text. 
        Organize the information clearly, labeling each piece of data (e.g., "Number of members: 4", "Slices per loaf: 12").
        Ensure that you capture all relevant details needed to solve the problem.
        """
        extract_task = self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Formulate a detailed solution plan
        plan_instruction = """
        Based on the extracted information, create a detailed, step-by-step plan to solve the problem. 
        Include all necessary calculations, intermediate steps, order of operations, unit conversions, and any contextual constraints. 
        Explain how each step contributes to solving the problem and arriving at the final answer.
        """
        plan_task = self.generate(instruction=plan_instruction, context=self.problem_text)

        # Execute extraction and planning in parallel
        extract_result, plan_result = await asyncio.gather(extract_task, plan_task)

        # Step 3: Execute the calculations
        calculation_instruction = f"""
        Using the extracted information: {extract_result}
        And the solution plan: {plan_result}
        Perform all calculations step by step as outlined in the plan. 
        Show all intermediate results and ensure that units are handled correctly throughout the process. 
        Arrive at the final numerical answer.
        """
        calculation_result = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Verify and refine the solution
        revise_instruction = """
        Critique the solution provided. Ensure that:
        - All calculations are correct and follow the proper order of operations
        - Units are consistent and appropriately handled
        - The final answer makes sense in the context of the problem
        - Any real-world constraints (e.g., non-negative quantities) are respected
        If any issues are found, refine the solution accordingly.
        """
        refined_solution = await self.revise(instruction=revise_instruction, context=calculation_result)

        # Step 5: Summarize the final answer
        summarize_instruction = """
        Condense the solution into a concise statement that includes:
        - The final numerical answer
        - Any relevant units or context
        Ensure that the summary is clear and directly addresses the question asked in the problem.
        """
        final_summary = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_summary