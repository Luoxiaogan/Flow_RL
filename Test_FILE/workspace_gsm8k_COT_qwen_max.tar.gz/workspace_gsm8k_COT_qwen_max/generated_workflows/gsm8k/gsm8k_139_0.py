# Workflow ID: gsm8k_139_0
# Benchmark: gsm8k
# Data Indices: [581, 374]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information
        extraction = await self.generate(
            instruction="Extract all numerical values, units, entities, relationships, and constraints from the problem. "
                        "Identify what is known and what needs to be calculated. "
                        "Organize the information in a structured format.",
            context=self.problem_text
        )

        # Step 2: Model the problem mathematically
        model = await self.generate(
            instruction=f"Based on the extracted information: {extraction}, "
                        "create a mathematical model of the problem. "
                        "Identify the unknowns, intermediate steps, and the sequence of operations required to solve the problem. "
                        "Include instructions for handling units, hidden steps, and real-world constraints.",
            context=self.problem_text
        )

        # Step 3: Solve step-by-step in parallel
        intermediate_results = await asyncio.gather(
            self.generate(
                instruction=f"From the mathematical model: {model}, "
                            "compute the result for the first step. "
                            "Ensure calculations are accurate and units are consistent.",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"From the mathematical model: {model}, "
                            "compute the result for the second step. "
                            "Ensure calculations are accurate and units are consistent.",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"From the mathematical model: {model}, "
                            "compute the result for the third step. "
                            "Ensure calculations are accurate and units are consistent.",
                context=self.problem_text
            )
        )

        # Step 4: Synthesize results
        final_solution = await self.ensemble(
            instruction="Combine the intermediate results into a final solution. "
                        "Ensure all partial solutions are consistent and correctly integrated. "
                        "Verify that the final answer makes sense in the context of the problem.",
            contexts=intermediate_results
        )

        # Step 5: Refine and validate
        refined_solution = await self.revise(
            instruction="Critique and refine the final solution. "
                        "Check for errors, inconsistencies, or ambiguities. "
                        "Ensure the solution is complete and adheres to the problem's requirements.",
            context=final_solution
        )

        return refined_solution