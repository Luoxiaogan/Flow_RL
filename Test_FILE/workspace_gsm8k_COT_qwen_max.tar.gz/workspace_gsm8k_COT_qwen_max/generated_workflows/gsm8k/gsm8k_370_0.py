# Workflow ID: gsm8k_370_0
# Benchmark: gsm8k
# Data Indices: [494, 191]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (numbers, relationships, constraints)
        extraction_instruction = (
            "Extract all numerical values, relationships, and constraints from the problem. "
            "Clearly identify what is given and what needs to be calculated. "
            "Format the output as a structured list for easy reference."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a step-by-step solution strategy
        strategy_instruction = (
            f"Based on the extracted information: {extracted_info}, "
            "create a detailed step-by-step plan to solve the problem. "
            "Include the sequence of operations, intermediate calculations, and how to arrive at the final answer. "
            "Ensure the plan is clear and unambiguous."
        )
        solution_strategy = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Perform intermediate calculations in parallel
        intermediate_instructions = [
            "Calculate the total number of pencils Anika has, given that she has 4 more than twice Reeta's pencils.",
            "Calculate the combined total cost of toilet paper and paper towels.",
            "Determine the cost per box of tissues based on the total cost and other items purchased."
        ]
        intermediate_results = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in intermediate_instructions]
        )

        # Step 4: Synthesize intermediate results into the final answer
        ensemble_instruction = (
            "Combine the intermediate results to compute the final answer. "
            "Ensure all calculations are consistent and account for all constraints. "
            "Provide the final numerical value as the result."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=intermediate_results)

        # Step 5: Verify and refine the final answer
        refinement_instruction = (
            f"Review the final answer: {final_answer}. "
            "Ensure it aligns with the problem context and constraints. "
            "Refine the result if necessary to improve accuracy or clarity."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        return refined_answer