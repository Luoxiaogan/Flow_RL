# Workflow ID: gsm8k_317_0
# Benchmark: gsm8k
# Data Indices: [420, 418]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract problem components
        extraction_instruction = (
            "Analyze the problem and extract all numerical values, units, relationships, and the specific question being asked. "
            "Ensure the output is structured and includes any implicit information or constraints."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Create a detailed calculation plan
        plan_instruction = (
            f"Using the extracted information: {extracted_info}, create a detailed step-by-step calculation plan. "
            "Include all necessary intermediate steps, unit conversions, and arithmetic operations required to solve the problem. "
            "Ensure the plan is logical and accounts for real-world constraints."
        )
        calculation_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Generate two independent solutions in parallel
        solution_instruction = (
            f"Follow this calculation plan: {calculation_plan} to solve the problem. "
            "Provide a detailed breakdown of each step, including intermediate results and their units. "
            "Ensure the final answer is a single numerical value that directly answers the question."
        )
        solution1, solution2 = await asyncio.gather(
            self.generate(instruction=solution_instruction, context=self.problem_text),
            self.generate(instruction=solution_instruction, context=self.problem_text)
        )

        # Step 4: Validate and select the best solution
        ensemble_instruction = (
            "Evaluate the two solutions provided. Check for consistency in intermediate steps and final answers. "
            "If discrepancies exist, identify the source and synthesize a corrected solution. "
            "Ensure the final answer is accurate and makes sense in the context of the problem."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[solution1, solution2])

        return final_answer