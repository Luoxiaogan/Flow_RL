# Workflow ID: gsm8k_26_0
# Benchmark: gsm8k
# Data Indices: [129, 369]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract known information and unknowns
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, relationships, "
            "and contextual clues. Identify what is explicitly given and what needs to be calculated. "
            "Provide the results in a structured format."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a solution plan
        plan_instruction = (
            f"Based on the following extracted information: {extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. Include all necessary calculations, "
            "intermediate steps, and any constraints or conditions mentioned in the problem. Ensure the plan "
            "is logically ordered and mathematically sound."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute the solution plan
        execution_instruction = (
            f"Follow this solution plan step by step: {solution_plan}\n"
            "Perform all calculations carefully, keeping track of units and intermediate results. "
            "If there are multiple approaches, compute them in parallel. Provide the final result(s)."
        )
        # Parallel execution for multiple approaches if needed
        execution_results = await asyncio.gather(
            self.generate(instruction=execution_instruction, context=self.problem_text),
            self.generate(instruction=execution_instruction, context=self.problem_text)
        )

        # Step 4: Ensemble to select the best result
        ensemble_instruction = (
            "Evaluate the following candidate solutions and select the most accurate and contextually "
            "appropriate one. If there are discrepancies, resolve them by analyzing the problem again."
        )
        final_result = await self.ensemble(instruction=ensemble_instruction, contexts=execution_results)

        # Step 5: Verify and refine the result
        verification_instruction = (
            f"Review the final result: {final_result}\n"
            "Ensure it is mathematically correct, consistent with the problem's context, and properly formatted. "
            "If any issues are found, revise the result accordingly."
        )
        refined_result = await self.revise(instruction=verification_instruction, context=final_result)

        # Step 6: Summarize the solution
        summary_instruction = (
            f"Condense the following solution into a concise answer: {refined_result}\n"
            "Include only the final numerical value and any essential units or clarifications."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_result)

        return final_answer