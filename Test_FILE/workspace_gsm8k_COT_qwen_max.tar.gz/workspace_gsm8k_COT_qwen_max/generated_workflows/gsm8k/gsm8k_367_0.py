# Workflow ID: gsm8k_367_0
# Benchmark: gsm8k
# Data Indices: [467, 112]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (numerical values, relationships, etc.)
        extraction_instruction = (
            "Thoroughly analyze the problem and extract all numerical values, units, "
            "relationships, and contextual clues. Organize the information in a structured format, "
            "clearly labeling each piece of data. Ensure no detail is overlooked."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate a step-by-step solution
        solution_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem step by step. "
            "Clearly explain each calculation, including intermediate results. Ensure all units are consistent "
            "and track them throughout the solution. Provide the final answer as a single numerical value."
        )
        initial_solution = await self.generate(instruction=solution_instruction, context=self.problem_text)

        # Step 3: Verify and refine the solution
        verification_instruction = (
            "Critically evaluate the provided solution. Check for logical consistency, unit correctness, "
            "and adherence to real-world constraints. Identify any errors or ambiguities and suggest corrections."
        )
        refinement_feedback = await self.revise(instruction=verification_instruction, context=initial_solution)

        # Optional refinement step if significant issues are identified
        refined_solution = await self.generate(
            instruction=f"Incorporate the following feedback to refine the solution: {refinement_feedback}",
            context=initial_solution
        )

        # Step 4: Summarize the final answer
        summarization_instruction = (
            "Extract the final numerical answer from the solution. Ensure the answer is clear, concise, "
            "and formatted as a single number (integer or decimal)."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_solution)

        return final_answer