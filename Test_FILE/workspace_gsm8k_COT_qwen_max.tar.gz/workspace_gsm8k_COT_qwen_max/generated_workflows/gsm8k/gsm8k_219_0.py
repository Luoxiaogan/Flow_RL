# Workflow ID: gsm8k_219_0
# Benchmark: gsm8k
# Data Indices: [344, 236]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract numerical values, relationships, and constraints
        extraction_instruction = (
            "Extract all numerical values, relationships, and constraints from the problem. "
            "Identify what is known, what is unknown, and what operations are required to solve the problem. "
            "Format the output as a structured breakdown of the problem."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Break down the problem into solvable steps
        breakdown_instruction = (
            f"Based on the extracted information: {extracted_info}, "
            "break the problem into smaller, sequential steps. Each step should represent a single calculation or logical deduction. "
            "Ensure the steps are ordered correctly and include all necessary intermediate calculations."
        )
        steps = await self.generate(instruction=breakdown_instruction, context=self.problem_text)

        # Step 3: Perform calculations for each step
        calculation_instruction = (
            f"Given the following steps: {steps}, "
            "perform the calculations step-by-step. Ensure all intermediate results are explicitly computed and validated. "
            "If there are multiple approaches to solving a step, consider them all and provide the results."
        )
        calculations = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Select the best approach if multiple exist
        ensemble_instruction = (
            "Evaluate the provided calculations and select the most accurate and contextually valid solution. "
            "If multiple approaches yield the same result, confirm consistency. "
            "If discrepancies exist, resolve them by considering the problem constraints."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=[calculations])

        # Step 5: Validate and refine the solution
        validation_instruction = (
            f"Critique the solution: {final_solution}. "
            "Ensure it makes sense in the context of the problem (e.g., non-negative quantities, reasonable units). "
            "Refine the solution if necessary to address any inconsistencies or errors."
        )
        refined_solution = await self.revise(instruction=validation_instruction, context=final_solution)

        # Step 6: Summarize the final result
        summary_instruction = (
            f"Summarize the refined solution: {refined_solution}. "
            "Extract the final numerical answer and ensure it is in the required format (integer or decimal)."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer