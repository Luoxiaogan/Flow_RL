# Workflow ID: gsm8k_11_0
# Benchmark: gsm8k
# Data Indices: [152, 1]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract known values and relationships
        extraction_instruction = (
            "Extract all numerical values, units, and relationships from the problem. "
            "Include any explicit or implicit information that will be needed to solve the problem. "
            "Format the output as a structured list."
        )
        extracted_values = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan the solution steps
        planning_instruction = (
            f"Using the extracted information: {extracted_values}, "
            "create a step-by-step plan to solve the problem. "
            "Include all necessary calculations, intermediate steps, and unit conversions. "
            "Ensure the plan is logically ordered and accounts for all constraints."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Execute calculations
        calculation_instruction = (
            f"Follow this plan: {solution_plan} to perform the calculations. "
            "Show all intermediate results and ensure the final answer is clearly stated. "
            "Double-check the calculations for accuracy."
        )
        calculated_result = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Validate the solution
        validation_instruction = (
            "Review the following solution: {calculated_result}. "
            "Check for any errors or inconsistencies. "
            "Ensure the answer makes sense in the context of the problem and adheres to all constraints."
        )
        validated_result = await self.revise(instruction=validation_instruction, context=calculated_result)

        # Step 5: Summarize the final answer
        summarization_instruction = (
            "Extract the final numerical answer from the following solution: {validated_result}. "
            "Ensure the answer is presented as a single number without any additional text."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=validated_result)

        return final_answer