# Workflow ID: gsm8k_112_0
# Benchmark: gsm8k
# Data Indices: [172, 759]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all numerical values, relationships, and units from the problem. "
            "Identify what is being asked and list all known quantities explicitly. "
            "Ensure the output is structured and easy to interpret."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Construct a step-by-step solution plan
        solution_plan_instruction = (
            f"Based on the following extracted information: {extracted_info} "
            "Construct a detailed step-by-step plan to solve the problem. "
            "Include all intermediate calculations, unit conversions, and logical reasoning. "
            "Ensure the plan is chronological and accounts for all constraints."
        )
        solution_plan = await self.generate(instruction=solution_plan_instruction, context=self.problem_text)

        # Step 3: Generate multiple solution approaches in parallel
        approach_1_instruction = (
            f"Using the following solution plan: {solution_plan} "
            "Solve the problem using direct arithmetic calculations. "
            "Show all intermediate steps and ensure the final answer is clearly stated."
        )
        approach_2_instruction = (
            f"Using the following solution plan: {solution_plan} "
            "Solve the problem using algebraic reasoning. "
            "Define variables, set up equations, and solve systematically. "
            "Ensure the final answer is clearly stated."
        )
        results = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text)
        )

        # Step 4: Evaluate and synthesize the best solution
        ensemble_instruction = (
            "Compare the following solutions and select the most accurate and complete one. "
            "Ensure the chosen solution adheres to all problem constraints and is logically consistent. "
            "If there are discrepancies, resolve them and provide the final answer."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 5: Refine the final solution
        refinement_instruction = (
            "Critique and refine the following solution to ensure clarity, correctness, and proper formatting. "
            "Verify that the final answer is a single numerical value and makes sense in the problem context."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=final_solution)

        return refined_solution