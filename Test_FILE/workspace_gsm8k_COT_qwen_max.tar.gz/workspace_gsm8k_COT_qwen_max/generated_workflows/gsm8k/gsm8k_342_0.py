# Workflow ID: gsm8k_342_0
# Benchmark: gsm8k
# Data Indices: [799, 94]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract known information
        extract_instruction = (
            "Carefully analyze the problem and extract all numerical values, "
            "relationships, and contextual clues. Organize them in a structured format, "
            "including units and any constraints mentioned."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Identify the core problem type
        identify_instruction = (
            f"Based on the extracted information: {extracted_info}, "
            "determine the type of problem being presented. Common types include sequential operations, "
            "rate problems, proportional reasoning, distribution problems, comparison problems, and multi-entity tracking. "
            "Provide a brief explanation of why this classification fits the problem."
        )
        problem_type = await self.generate(instruction=identify_instruction, context=self.problem_text)

        # Step 3: Plan the solution steps
        plan_instruction = (
            f"Given the extracted information: {extracted_info} and the identified problem type: {problem_type}, "
            "create a detailed step-by-step plan to solve the problem. Include all intermediate calculations, "
            "unit tracking, and any real-world constraints. Ensure the plan is logical and chronological."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 4: Execute the calculations
        execute_instruction = (
            f"Follow the solution plan: {solution_plan} to perform the calculations step-by-step. "
            "Ensure each step is accurate and validated before proceeding to the next."
        )
        calculations = await self.generate(instruction=execute_instruction, context=self.problem_text)

        # Validate and refine intermediate results
        refine_instruction = (
            "Review the calculations performed so far and check for accuracy, unit consistency, "
            "and adherence to the problem's constraints. Correct any errors and refine the results."
        )
        refined_results = await self.revise(instruction=refine_instruction, context=calculations)

        # Step 5: Summarize the final answer
        summarize_instruction = (
            f"Condense the refined results: {refined_results} into a single numerical answer. "
            "Ensure the answer makes sense in the context of the problem and includes appropriate units if necessary."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_results)

        return final_answer