# Workflow ID: gsm8k_255_0
# Benchmark: gsm8k
# Data Indices: [702, 121]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, relationships, and constraints. "
            "Include units, rates, proportions, and any other relevant details. "
            "Format the output as a structured list for clarity."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a solution plan
        plan_instruction = (
            f"Using the extracted information: {extracted_info}, formulate a step-by-step solution plan. "
            "Clearly specify the sequence of operations (e.g., addition, multiplication) and any intermediate calculations. "
            "Ensure that units and constraints are explicitly addressed in the plan."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute the solution plan
        execution_instruction = (
            f"Follow this solution plan step-by-step: {solution_plan}. "
            "Perform each calculation explicitly, showing intermediate results. "
            "Ensure that all units and constraints are respected throughout the process."
        )
        executed_solution = await self.generate(instruction=execution_instruction, context=self.problem_text)

        # Step 4: Verify and refine the solution
        verification_instruction = (
            f"Review the executed solution: {executed_solution}. "
            "Check if the result satisfies the problem's constraints and makes sense in the given context. "
            "If necessary, refine the solution to ensure accuracy and correctness."
        )
        refined_solution = await self.revise(instruction=verification_instruction, context=executed_solution)

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"Condense the refined solution: {refined_solution} into a single numerical value. "
            "Ensure that the answer is presented clearly and matches the problem's requirements."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer