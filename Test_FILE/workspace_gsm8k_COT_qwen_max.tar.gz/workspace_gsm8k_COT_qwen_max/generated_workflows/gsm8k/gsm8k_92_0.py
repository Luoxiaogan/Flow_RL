# Workflow ID: gsm8k_92_0
# Benchmark: gsm8k
# Data Indices: [683, 43]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (numerical values, units, relationships)
        extract_instruction = (
            "Carefully analyze the problem and extract all numerical values, their associated units, "
            "and any relationships or operations described between them. Format the output as a structured list."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Plan the solution steps
        plan_instruction = (
            f"Based on the extracted information: {extracted_info}, create a detailed step-by-step plan "
            "to solve the problem. Include intermediate calculations, ensure unit consistency, and specify "
            "the order of operations."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute calculations in parallel where possible
        calculate_instruction = (
            f"Follow this plan step-by-step: {solution_plan}. Perform each calculation explicitly, "
            "stating intermediate results clearly. Ensure all units are consistent and verify each step."
        )
        calculations = await self.generate(instruction=calculate_instruction, context=self.problem_text)

        # Step 4: Refine results to handle ambiguities or errors
        refine_instruction = (
            "Review the calculations and refine any ambiguous or incorrect steps. Ensure all intermediate "
            "results are accurate and consistent with the problem context."
        )
        refined_results = await self.revise(instruction=refine_instruction, context=calculations)

        # Step 5: Summarize to extract the final answer
        summarize_instruction = (
            "Condense the refined results into a single numerical answer. Ensure the answer is presented "
            "with appropriate units and precision as required by the problem."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_results)

        return final_answer