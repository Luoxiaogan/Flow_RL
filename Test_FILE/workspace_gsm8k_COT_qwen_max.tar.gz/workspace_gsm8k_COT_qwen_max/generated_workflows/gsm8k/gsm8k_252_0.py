# Workflow ID: gsm8k_252_0
# Benchmark: gsm8k
# Data Indices: [362, 330]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant numerical values, units, and relationships
        extraction_instruction = (
            "Thoroughly analyze the problem and extract all numerical values, units, "
            "and mathematical relationships described in the text. Clearly list each item "
            "and explain its role in the problem. If there are any rates, ratios, or "
            "proportions, explicitly state them."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Perform step-by-step calculations based on the extracted information
        calculation_instruction = (
            f"Using the following extracted information: {extracted_info}\n"
            "Perform all necessary calculations step-by-step to solve the problem. "
            "Include intermediate results and ensure each step logically follows from the previous one. "
            "Pay attention to units and ensure they are consistent throughout. "
            "If there are multiple steps, clearly label each one."
        )
        initial_solution = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 3: Revise the solution for accuracy and contextual appropriateness
        revision_instruction = (
            "Carefully review the following solution:\n"
            f"{initial_solution}\n"
            "Check for any calculation errors, unit inconsistencies, or logical flaws. "
            "Ensure the solution makes sense in the context of the problem. "
            "If any issues are found, correct them and provide an improved version of the solution."
        )
        refined_solution = await self.revise(instruction=revision_instruction, context=initial_solution)

        # Step 4: Summarize to extract the final numerical answer
        summary_instruction = (
            "From the following refined solution:\n"
            f"{refined_solution}\n"
            "Extract and present ONLY the final numerical answer. Ensure it is clear, precise, "
            "and formatted appropriately (e.g., as an integer or decimal)."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer