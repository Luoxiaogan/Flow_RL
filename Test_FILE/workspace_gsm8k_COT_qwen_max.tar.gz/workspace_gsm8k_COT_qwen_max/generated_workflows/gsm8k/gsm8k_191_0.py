# Workflow ID: gsm8k_191_0
# Benchmark: gsm8k
# Data Indices: [170, 593]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract known information and relationships
        extraction_instruction = """
        Extract all numerical values, units, and relationships from the problem. 
        Identify what is being asked and any constraints or conditions provided. 
        Format the output as a structured list of key-value pairs, including:
        - Known quantities and their units
        - Relationships between quantities (e.g., ratios, percentages)
        - The target unknown value(s)
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Determine the problem type and strategy
        strategy_instruction = f"""
        Based on the extracted information: {extracted_info}
        Identify the type of problem (e.g., sequential operations, rate problems, proportional reasoning).
        Outline a step-by-step strategy to solve the problem, including:
        - Intermediate calculations required
        - Order of operations
        - Any unit conversions or contextual constraints
        """
        strategy = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Perform calculations step-by-step
        steps_instruction = f"""
        Using the strategy outlined here: {strategy}
        Perform the calculations step-by-step. Record intermediate results explicitly and verify their correctness.
        Ensure that units are tracked consistently throughout.
        """
        calculations = await self.generate(instruction=steps_instruction, context=self.problem_text)

        # Step 4: Refine results if necessary
        refinement_instruction = """
        Review the calculations performed so far. Identify and correct any errors or inconsistencies.
        Ensure that the intermediate results align with the problem's requirements and constraints.
        """
        refined_results = await self.revise(instruction=refinement_instruction, context=calculations)

        # Step 5: Extract the final answer
        final_answer_instruction = f"""
        From the refined results: {refined_results}
        Extract the final answer to the problem. Ensure that it is expressed in the correct units and format.
        Validate that the answer makes sense in the context of the problem.
        """
        final_answer = await self.generate(instruction=final_answer_instruction, context=self.problem_text)

        # Step 6: Summarize the reasoning process
        summary_instruction = f"""
        Summarize the entire reasoning process, including:
        - Extracted information
        - Strategy used
        - Key calculations and intermediate results
        - Final answer and its validation
        """
        summary = await self.summarize(instruction=summary_instruction, context=self.problem_text)

        return {
            "final_answer": final_answer,
            "summary": summary
        }