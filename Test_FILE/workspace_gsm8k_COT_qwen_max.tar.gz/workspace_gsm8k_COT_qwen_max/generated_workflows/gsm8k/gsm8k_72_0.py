# Workflow ID: gsm8k_72_0
# Benchmark: gsm8k
# Data Indices: [186, 434]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract known information (numbers, units, relationships)
        extraction_instruction = (
            "Extract all numerical values, units, and relationships from the problem. "
            "Categorize them as knowns and unknowns. Clearly identify what the question is asking for."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a step-by-step solution plan
        plan_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Devise a detailed step-by-step plan to solve the problem. "
            "Include all intermediate calculations and specify the order of operations."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute the calculations
        execution_instruction = (
            f"Follow this plan step by step:\n{solution_plan}\n"
            "Perform all calculations explicitly and show intermediate results. "
            "Ensure all units are consistent and track them throughout."
        )
        raw_solution = await self.generate(instruction=execution_instruction, context=self.problem_text)

        # Step 4: Validate and refine the solution
        validation_instruction = (
            "Review the following solution:\n{raw_solution}\n"
            "Check for logical consistency, contextual validity (e.g., no negative or fractional people), "
            "and unit correctness. Refine the solution if necessary."
        )
        refined_solution = await self.revise(instruction=validation_instruction, context=raw_solution)

        # Step 5: Summarize the final answer
        summary_instruction = (
            "Condense the following solution into a single numerical value that directly answers the question:\n"
            "{refined_solution}\n"
            "Ensure the final answer is clear, concise, and includes appropriate units if applicable."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer