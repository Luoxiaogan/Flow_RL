# Workflow ID: gsm8k_352_0
# Benchmark: gsm8k
# Data Indices: [27, 371]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract known information (numerical values, units, relationships)
        extract_instruction = (
            "Carefully analyze the problem and extract all numerical values, units, and relationships. "
            "List them explicitly and describe their context within the problem. "
            "Ensure no relevant information is missed."
        )
        known_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Identify the unknown and plan the solution
        plan_instruction = (
            f"Based on the following extracted information:\n{known_info}\n"
            "Determine what the problem is asking for (the unknown). "
            "Create a detailed step-by-step plan to calculate the unknown, including all intermediate steps. "
            "Ensure the plan accounts for units and real-world constraints."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Perform calculations (execute the plan)
        calculate_instruction = (
            f"Follow this step-by-step plan to solve the problem:\n{solution_plan}\n"
            "Perform each calculation sequentially, documenting intermediate results. "
            "Ensure all steps are followed accurately and consistently."
        )
        raw_solution = await self.generate(instruction=calculate_instruction, context=self.problem_text)

        # Step 4: Verify and refine the solution
        refine_instruction = (
            f"Review the following solution:\n{raw_solution}\n"
            "Check for accuracy, consistency with the problem's context, and adherence to constraints. "
            "Refine the solution if necessary, ensuring it is correct and complete."
        )
        refined_solution = await self.revise(instruction=refine_instruction, context=raw_solution)

        # Step 5: Summarize the final answer
        summarize_instruction = (
            f"Condense the following solution into a concise format:\n{refined_solution}\n"
            "Present the final answer as a single numerical value, ensuring it is clear and unambiguous."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_answer