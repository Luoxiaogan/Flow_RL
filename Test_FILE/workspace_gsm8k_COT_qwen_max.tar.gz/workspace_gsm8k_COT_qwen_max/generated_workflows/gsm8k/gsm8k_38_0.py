# Workflow ID: gsm8k_38_0
# Benchmark: gsm8k
# Data Indices: [237, 35]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (numerical values, entities, relationships)
        extraction_instruction = (
            "Extract all numerical values, entities, and relationships mentioned in the problem. "
            "Identify what is being asked and list the knowns and unknowns. "
            "Ensure that units (if any) are explicitly noted. "
            "Organize the information in a structured format suitable for solving the problem."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate intermediate steps to solve the problem
        solution_instruction = (
            f"Based on the extracted information: {extracted_info} "
            "Break the problem into sequential steps. "
            "For each step, calculate the required value and show the reasoning process. "
            "Ensure that intermediate results are clearly labeled and justified. "
            "If multiple calculations are needed, perform them in logical order."
        )
        intermediate_steps = await self.generate(instruction=solution_instruction, context=self.problem_text)

        # Step 3: Validate and refine intermediate results
        refinement_instruction = (
            "Review the intermediate steps and results. "
            "Check for calculation errors, logical inconsistencies, or missing steps. "
            "Refine the solution to ensure accuracy and completeness. "
            "Provide corrected or improved versions of any steps if necessary."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=intermediate_steps)

        # Step 4: Consolidate the final answer
        final_instruction = (
            "From the refined solution, extract the final numerical answer. "
            "Ensure that the answer is concise, accurate, and includes appropriate units (if applicable). "
            "Verify that the answer makes sense in the context of the problem."
        )
        final_answer = await self.summarize(instruction=final_instruction, context=refined_solution)

        return final_answer