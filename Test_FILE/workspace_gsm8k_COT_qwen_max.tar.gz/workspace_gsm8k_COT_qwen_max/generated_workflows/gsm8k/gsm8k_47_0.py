# Workflow ID: gsm8k_47_0
# Benchmark: gsm8k
# Data Indices: [631, 379]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract knowns and unknowns
        extraction_instruction = (
            "Extract all numerical values, units, entities, and relationships from the problem. "
            "Organize them in a structured format, such as 'entity: value, unit'. "
            "Ensure all relevant information is captured for solving the problem."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a solution plan
        plan_instruction = (
            f"Based on the extracted information: {extracted_info}, "
            "create a step-by-step plan to solve the problem. "
            "Include intermediate calculations, specify the order of operations, "
            "and ensure all units are consistent. Address any hidden steps or assumptions."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute calculations (parallel execution for efficiency)
        calculation_instruction = (
            f"Follow this plan step-by-step: {solution_plan}. "
            "Perform all calculations accurately, keeping track of units and intermediate results. "
            "Ensure the final result answers the question posed in the problem."
        )
        # Generate multiple approaches if applicable
        approach_1 = self.generate(instruction=calculation_instruction, context=self.problem_text)
        approach_2 = self.generate(instruction=calculation_instruction, context=self.problem_text)
        results = await asyncio.gather(approach_1, approach_2)

        # Step 4: Validate and refine results
        validation_instruction = (
            "Critique the following results for accuracy and contextual validity. "
            "Ensure the calculations make sense in the real-world scenario described in the problem. "
            "Refine the results if necessary."
        )
        refined_results = [
            await self.revise(instruction=validation_instruction, context=result)
            for result in results
        ]

        # Step 5: Final answer extraction
        final_instruction = (
            "Condense the following results into a single numerical value that answers the problem's question. "
            "Ensure the final answer is precise and includes appropriate units if necessary."
        )
        final_answer = await self.ensemble(
            instruction=final_instruction,
            contexts=refined_results
        )

        return final_answer