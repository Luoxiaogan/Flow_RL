# Workflow ID: gsm8k_267_0
# Benchmark: gsm8k
# Data Indices: [75, 404]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all numerical values, units, relationships, and the specific question from the problem. "
            "Format the output as follows:\n"
            "- Numerical values: List all numbers mentioned.\n"
            "- Relationships: Describe any mathematical relationships (e.g., '12 more green apples than red apples').\n"
            "- Question: Clearly state what the problem is asking for."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan the step-by-step solution
        planning_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Create a step-by-step plan to solve the problem. Include:\n"
            "- Intermediate calculations needed.\n"
            "- The order of operations.\n"
            "- Any unit conversions or contextual constraints.\n"
            "- How to arrive at the final answer."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Perform intermediate calculations in parallel
        # Dynamically construct instructions for each step in the plan
        steps = solution_plan.split("\n")  # Assume each line is a step
        intermediate_tasks = []
        for step in steps:
            if step.strip():  # Ignore empty lines
                task_instruction = (
                    f"Perform the following step: {step}\n"
                    "Ensure calculations are accurate and include units where applicable."
                )
                intermediate_tasks.append(self.generate(instruction=task_instruction, context=self.problem_text))
        
        intermediate_results = await asyncio.gather(*intermediate_tasks)

        # Step 4: Synthesize the final answer
        synthesis_instruction = (
            "Given the following intermediate results:\n"
            f"{intermediate_results}\n"
            "Synthesize the final answer to the problem. Ensure the answer:\n"
            "- Is a single numerical value (integer or decimal).\n"
            "- Makes sense in the context of the problem.\n"
            "- Respects any constraints or units mentioned."
        )
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=intermediate_results)

        # Step 5: Verify and refine the solution
        refinement_instruction = (
            f"Review the final answer: {final_answer}\n"
            "Critique and refine it based on the following criteria:\n"
            "- Accuracy of calculations.\n"
            "- Consistency with the problem's context and constraints.\n"
            "- Proper formatting (e.g., correct number of decimal places)."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        return refined_answer