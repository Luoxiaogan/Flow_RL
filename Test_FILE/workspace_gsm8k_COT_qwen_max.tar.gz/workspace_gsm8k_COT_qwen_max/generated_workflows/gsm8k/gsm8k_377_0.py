# Workflow ID: gsm8k_377_0
# Benchmark: gsm8k
# Data Indices: [127, 126]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, "
            "relationships, and constraints. Clearly identify what is known and what needs to be solved. "
            "Ensure the extraction includes units (if any) and describes how the values relate to each other."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Perform intermediate reasoning and calculations
        reasoning_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "perform the necessary calculations step by step. Include intermediate results and explain "
            "the reasoning behind each step. Ensure all operations are logically consistent and adhere "
            "to real-world constraints (e.g., no negative quantities, fractional people, etc.)."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Validate and refine the reasoning
        refinement_instruction = (
            "Critique the provided reasoning and calculations. Identify any errors, inconsistencies, "
            "or missing steps. Suggest improvements and ensure the solution is logically sound and accurate."
        )
        refined_result = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 4: Synthesize the final answer
        synthesis_instruction = (
            "Condense the refined reasoning into a concise summary. "
            "Clearly state the final numerical answer, ensuring it is presented as a single value "
            "(integer or decimal). Include units if applicable."
        )
        final_answer = await self.summarize(instruction=synthesis_instruction, context=refined_result)

        return final_answer