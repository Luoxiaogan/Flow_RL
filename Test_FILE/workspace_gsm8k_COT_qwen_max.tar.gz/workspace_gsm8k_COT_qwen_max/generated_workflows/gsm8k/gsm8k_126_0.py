# Workflow ID: gsm8k_126_0
# Benchmark: gsm8k
# Data Indices: [736, 487]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract known information and relationships
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, units, "
            "relationships, and constraints. Clearly identify what is given and what is being asked. "
            "Ensure you capture all relevant details needed to solve the problem."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Model the problem mathematically
        modeling_instruction = (
            f"Based on the following extracted information: {extracted_info}\n"
            "Translate the problem into a sequence of mathematical operations or equations. "
            "Break down the problem into clear intermediate steps, such as calculating individual components, "
            "scaling quantities, or summing totals. Ensure the steps are logically ordered and consistent."
        )
        mathematical_model = await self.generate(instruction=modeling_instruction, context=self.problem_text)

        # Step 3: Perform calculations
        calculation_instruction = (
            f"Using the mathematical model: {mathematical_model}\n"
            "Perform the necessary calculations step by step. Ensure you handle units consistently and "
            "perform operations in the correct order. Provide intermediate results where appropriate."
        )
        calculations = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Validate the solution
        validation_instruction = (
            f"Review the following calculations: {calculations}\n"
            "Critique and refine the solution to ensure it aligns with the problem's context and constraints. "
            "Check for logical consistency, unit correctness, and adherence to real-world constraints."
        )
        validated_solution = await self.revise(instruction=validation_instruction, context=calculations)

        # Step 5: Summarize the final answer
        summarization_instruction = (
            f"Condense the following validated solution: {validated_solution}\n"
            "Provide the final answer as a single numerical value, ensuring it meets the GSM8K benchmark requirements."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=validated_solution)

        return final_answer