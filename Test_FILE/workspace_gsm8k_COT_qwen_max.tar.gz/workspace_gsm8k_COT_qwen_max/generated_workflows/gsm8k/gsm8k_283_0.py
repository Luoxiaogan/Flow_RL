# Workflow ID: gsm8k_283_0
# Benchmark: gsm8k
# Data Indices: [658, 632]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all numerical values, units, relationships, and entities mentioned in the problem. "
            "Identify what is known and what needs to be calculated. "
            "Organize the information into a structured format for further analysis."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a mathematical strategy
        strategy_instruction = (
            f"Based on the following extracted information: {extracted_info} "
            "Formulate a step-by-step strategy to solve the problem. "
            "Determine the sequence of operations required and any intermediate calculations needed. "
            "Ensure that the strategy accounts for units, real-world constraints, and hidden steps."
        )
        strategy = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Execute calculations step-by-step
        calculation_instruction = (
            f"Using the following strategy: {strategy} "
            "Perform the calculations step-by-step. "
            "Explicitly state intermediate results and ensure they are consistent with the problem context. "
            "Verify each step before proceeding to the next."
        )
        calculations = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Verify and refine the solution
        refinement_instruction = (
            "Critique the following solution to ensure accuracy and clarity: "
            f"{calculations} "
            "Check for unit consistency, real-world constraints, and logical correctness. "
            "Refine the solution if necessary, providing a revised version."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=calculations)

        # Step 5: Summarize the final answer
        summary_instruction = (
            "Condense the following solution into a concise summary: "
            f"{refined_solution} "
            "Ensure the final answer is presented as a single numerical value. "
            "Include any relevant units or context."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer