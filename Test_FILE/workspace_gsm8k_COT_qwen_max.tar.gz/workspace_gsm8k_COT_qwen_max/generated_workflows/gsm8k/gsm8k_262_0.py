# Workflow ID: gsm8k_262_0
# Benchmark: gsm8k
# Data Indices: [99, 274]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, units, entities, "
            "and relationships. For each number, include its context (e.g., 'Josh has $20'). "
            "Identify any rates, totals, or proportional relationships. Ensure all extracted "
            "information is relevant to solving the problem."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a step-by-step solution plan
        plan_instruction = (
            f"Using the following extracted information: {extracted_info}\n"
            "Create a detailed, step-by-step plan to solve the problem. Include all intermediate "
            "calculations, handle units consistently, and ensure logical sequencing of steps. "
            "Explicitly address any hidden or implied calculations."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute the solution based on the plan
        execution_instruction = (
            f"Follow this solution plan step by step: {solution_plan}\n"
            "Perform all required calculations precisely, ensuring unit consistency and contextual "
            "validation. Derive intermediate results and document them clearly. Conclude with the "
            "final numerical answer."
        )
        executed_solution = await self.generate(instruction=execution_instruction, context=self.problem_text)

        # Step 4: Verify and refine the solution
        refinement_instruction = (
            f"Review the following solution: {executed_solution}\n"
            "Critique it for accuracy, unit consistency, and contextual validity. Identify and "
            "correct any errors. Ensure the solution adheres to real-world constraints and makes "
            "sense in the context of the problem."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=executed_solution)

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"From the refined solution: {refined_solution}\n"
            "Extract and present only the final numerical answer. Ensure the output is concise "
            "and includes no additional explanations."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer