# Workflow ID: gsm8k_298_0
# Benchmark: gsm8k
# Data Indices: [629, 393]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract Key Information
        extraction_instruction = (
            "Extract all numerical values, units, and relationships described in the problem. "
            "Include any relevant contextual information that could affect the calculations."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a Solution Plan
        plan_instruction = (
            f"Given the following extracted information: {extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. "
            "Ensure that each step logically follows from the previous one and leads towards the final answer. "
            "Include any necessary intermediate calculations and specify the order of operations."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute Calculations
        execution_instruction = (
            f"Following this plan: {solution_plan}\n"
            "Perform the calculations step by step. "
            "Clearly show each intermediate result and ensure that units are consistent throughout. "
            "If there are multiple independent steps, perform them in parallel."
        )
        # Assuming the plan outlines sequential steps; adjust if parallelization is feasible
        calculation_results = await self.generate(instruction=execution_instruction, context=self.problem_text)

        # Step 4: Validate Intermediate Results
        validation_instruction = (
            f"Review the following calculation results: {calculation_results}\n"
            "Validate each intermediate result to ensure accuracy. "
            "Correct any errors and refine the calculations as needed. "
            "Ensure that each step logically leads to the next and that units are handled correctly."
        )
        validated_results = await self.revise(instruction=validation_instruction, context=calculation_results)

        # Step 5: Synthesize Final Answer
        synthesis_instruction = (
            f"Given the following validated results: {validated_results}\n"
            "Combine all information into a coherent final solution. "
            "Ensure that the final answer is clearly stated and makes sense in the context of the problem. "
            "Include a brief sanity check to verify the reasonableness of the answer."
        )
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=[validated_results])

        # Step 6: Summarize the Solution
        summary_instruction = (
            f"Summarize the entire solution process based on the following final answer: {final_answer}\n"
            "Highlight the key steps taken, the reasoning behind each calculation, and the final result. "
            "Ensure the summary is concise yet comprehensive enough to understand the solution without reading the entire workflow."
        )
        solution_summary = await self.summarize(instruction=summary_instruction, context=final_answer)

        return solution_summary