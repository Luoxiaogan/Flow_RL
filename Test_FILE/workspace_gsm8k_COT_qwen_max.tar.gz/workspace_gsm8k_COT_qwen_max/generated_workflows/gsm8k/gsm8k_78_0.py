# Workflow ID: gsm8k_78_0
# Benchmark: gsm8k
# Data Indices: [325, 131]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information (numerical values, units, relationships, constraints)
        extraction_instruction = (
            "Extract all numerical values, units, relationships, and constraints from the problem. "
            "Identify what is known and what needs to be determined. Format the output as a structured list."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Create a step-by-step solution plan
        modeling_instruction = (
            f"Based on the following extracted information: {extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. Include intermediate calculations, "
            "order of operations, and unit handling. Ensure the plan is logical and complete."
        )
        solution_plan = await self.generate(instruction=modeling_instruction, context=self.problem_text)

        # Step 3: Generate multiple candidate solutions in parallel
        candidate_instructions = [
            f"Solve the problem using the following plan: {solution_plan}\n"
            "Approach 1: Focus on sequential calculations and explicitly state each step.",
            f"Solve the problem using the following plan: {solution_plan}\n"
            "Approach 2: Use algebraic reasoning to derive the solution.",
            f"Solve the problem using the following plan: {solution_plan}\n"
            "Approach 3: Verify the solution by working backwards from the expected answer."
        ]
        candidate_solutions = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in candidate_instructions]
        )

        # Step 4: Evaluate and synthesize the best solution
        ensemble_instruction = (
            "Evaluate the following candidate solutions and select the best one. "
            "Ensure the chosen solution is mathematically correct, contextually relevant, and consistent with the problem. "
            "If discrepancies exist, resolve them and provide a synthesized solution."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=candidate_solutions)

        # Step 5: Refine the solution if necessary
        refinement_instruction = (
            "Review the following solution for clarity, accuracy, and completeness. "
            "Make improvements if needed, ensuring the final answer is properly formatted and makes sense in context."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 6: Extract the final numerical answer
        answer_extraction_instruction = (
            "Extract the final numerical answer from the following solution. "
            "Ensure the result is a single number (integer or decimal) and formatted correctly."
        )
        final_answer = await self.generate(instruction=answer_extraction_instruction, context=refined_solution)

        return final_answer