# Workflow ID: gsm8k_250_0
# Benchmark: gsm8k
# Data Indices: [718, 626]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information (numerical values, units, relationships, question)
        extraction_instruction = (
            "Extract all numerical values, units, relationships, and the final question from the problem. "
            "Format the output as a structured summary, clearly labeling each piece of information. "
            "Ensure all extracted data is relevant to solving the problem."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate a step-by-step solution
        solution_instruction = (
            f"Using the following extracted information: {extracted_info}\n"
            "Solve the problem step by step. Clearly show all intermediate calculations, including unit conversions "
            "and any hidden steps not explicitly stated in the problem. Ensure the solution is logically consistent "
            "and adheres to real-world constraints (e.g., no negative quantities). Format the solution as a numbered list."
        )
        solution = await self.generate(instruction=solution_instruction, context=self.problem_text)

        # Step 3: Revise and refine the solution
        revision_instruction = (
            "Critique and refine the following solution. Check for calculation errors, logical inconsistencies, "
            "and adherence to the problem's context. Ensure the solution is complete and makes sense in the real world. "
            "Provide a revised version of the solution with any necessary corrections."
        )
        refined_solution = await self.revise(instruction=revision_instruction, context=solution)

        # Step 4: Extract the final numerical answer
        summarization_instruction = (
            "Extract the final numerical answer from the following solution. "
            "Return only the numerical value (integer or decimal) without any additional text or explanation."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_solution)

        return final_answer