# Workflow ID: gsm8k_162_0
# Benchmark: gsm8k
# Data Indices: [269, 224]

```python
class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all numerical values, units, and relationships
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, units, "
            "and relationships between them. Include any constraints or conditions "
            "mentioned in the problem. Ensure that the extracted information is "
            "complete and accurate."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Model the problem mathematically
        modeling_instruction = (
            f"Based on the following extracted information: {extracted_info}\n"
            "Construct a mathematical model to solve the problem. Identify the sequence "
            "of operations needed (e.g., addition, multiplication) and any intermediate "
            "steps required. Ensure that the model accounts for all constraints and "
            "real-world conditions described in the problem."
        )
        mathematical_model = await self.generate(instruction=modeling_instruction, context=self.problem_text)

        # Step 3: Execute the calculations step by step
        execution_instruction = (
            f"Using the mathematical model: {mathematical_model}\n"
            "Execute the calculations step by step. Track all intermediate results and "
            "ensure unit consistency throughout. Provide the final result as a single "
            "numerical value, along with any relevant units."
        )
        solution = await self.generate(instruction=execution_instruction, context=self.problem_text)

        # Step 4: Validate and refine the solution
        validation_instruction = (
            f"Review the following solution: {solution}\n"
            "Check whether it makes sense in the context of the problem. Verify that "
            "all calculations are correct and that the final answer satisfies the "
            "problem's requirements. If necessary, suggest improvements or corrections."
        )
        refined_solution = await self.revise(instruction=validation_instruction, context=solution)

        # Step 5: Summarize the final answer
        summarization_instruction = (
            f"Condense the following solution into a concise final answer: {refined_solution}\n"
            "Ensure that the answer is a single numerical value, along with any "
            "relevant units. Remove any unnecessary details while preserving the "
            "essential information."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_solution)

        return final_answer
```