# Workflow ID: gsm8k_150_0
# Benchmark: gsm8k
# Data Indices: [221, 417]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem text
        extraction_instruction = (
            "Extract all numerical values, relationships, and constraints from the problem. "
            "Identify what is given and what needs to be solved. "
            "Format the output as a structured summary."
        )
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Perform intermediate calculations
        calculation_instruction = (
            f"Based on the extracted information: {extraction}, "
            "perform any necessary intermediate calculations. "
            "For example, calculate rates, totals, or differences. "
            "Document each step clearly and provide intermediate results."
        )
        calculations = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 3: Solve for the unknowns
        solution_instruction = (
            f"Using the intermediate results: {calculations}, "
            "solve for the unknowns in the problem. "
            "Apply appropriate mathematical operations and ensure the solution is logically consistent. "
            "Provide the final answer with units if applicable."
        )
        solution = await self.generate(instruction=solution_instruction, context=self.problem_text)

        # Step 4: Validate the solution
        validation_instruction = (
            f"Validate the solution: {solution} against the problem context: {self.problem_text}. "
            "Check if the answer makes sense in terms of units, logical constraints, and real-world applicability. "
            "If there are inconsistencies, suggest corrections."
        )
        validation = await self.revise(instruction=validation_instruction, context=solution)

        # Step 5: Summarize the final result
        summary_instruction = (
            "Summarize the problem-solving process and the final answer. "
            "Include key steps, intermediate results, and the validated solution. "
            "Ensure the summary is concise but comprehensive."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=validation)

        return final_summary