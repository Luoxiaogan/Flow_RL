# Workflow ID: gsm8k_391_0
# Benchmark: gsm8k
# Data Indices: [228, 397]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all relevant information from the problem text
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, units, relationships, "
            "and constraints. Organize the information in a structured format, including what is "
            "given and what is being asked. Ensure that all units are explicitly noted."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate a step-by-step solution plan
        modeling_instruction = (
            f"Using the following extracted information:\n{extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. Include all necessary calculations, "
            "intermediate results, and unit conversions. Ensure the plan is logically ordered and accounts "
            "for any hidden steps or real-world constraints."
        )
        solution_plan = await self.generate(instruction=modeling_instruction, context=self.problem_text)

        # Step 3: Generate multiple solution approaches in parallel
        approach_instruction_template = (
            f"Based on the following solution plan:\n{solution_plan}\n"
            "Solve the problem step by step, ensuring all calculations are accurate and clearly explained. "
            "Provide the final answer as a single numerical value at the end."
        )
        approach_1 = self.generate(instruction=approach_instruction_template, context=self.problem_text)
        approach_2 = self.generate(instruction=approach_instruction_template, context=self.problem_text)
        approach_3 = self.generate(instruction=approach_instruction_template, context=self.problem_text)
        solutions = await asyncio.gather(approach_1, approach_2, approach_3)

        # Step 4: Use Ensemble to select the best solution
        ensemble_instruction = (
            "Evaluate the following solutions and select the best one based on correctness, clarity, "
            "and adherence to the problem constraints. If there are discrepancies, resolve them by "
            "analyzing the intermediate steps and calculations."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=solutions)

        # Step 5: Extract the final numerical answer
        answer_extraction_instruction = (
            "From the following solution, extract the final numerical answer. Ensure it is a single "
            "number (integer or decimal) without any additional text or explanation."
        )
        final_answer = await self.generate(instruction=answer_extraction_instruction, context=best_solution)

        return final_answer