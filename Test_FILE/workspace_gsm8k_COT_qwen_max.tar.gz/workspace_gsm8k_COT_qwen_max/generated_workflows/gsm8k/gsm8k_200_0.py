# Workflow ID: gsm8k_200_0
# Benchmark: gsm8k
# Data Indices: [98, 766]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract numerical values, relationships, and constraints
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, "
            "relationships, and constraints. Clearly label each piece of information "
            "and explain its relevance to solving the problem."
        )
        extraction_result = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate intermediate reasoning steps
        reasoning_instruction = (
            f"Using the extracted information: {extraction_result}, "
            "break down the problem into clear, sequential steps. "
            "Include all necessary calculations, handle units consistently, "
            "and ensure logical flow from one step to the next."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Revise and refine intermediate reasoning
        revision_instruction = (
            "Critically review the reasoning steps provided. "
            "Identify and correct any errors, inconsistencies, or missing details. "
            "Ensure the steps are mathematically sound and logically coherent."
        )
        refined_reasoning = await self.revise(instruction=revision_instruction, context=reasoning_result)

        # Step 4: Summarize the final answer
        summarization_instruction = (
            "From the refined reasoning steps, extract and summarize the final answer. "
            "Ensure the answer is a single numerical value and makes sense in the context "
            "of the original problem."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_reasoning)

        return final_answer