# Workflow ID: gsm8k_25_0
# Benchmark: gsm8k
# Data Indices: [781, 469]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract known information
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, relationships, "
            "and constraints. List them in a structured format, including units where applicable. "
            "Ensure no detail is missed."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Identify unknowns and plan solution steps
        planning_instruction = (
            f"Based on the extracted information: {extracted_info}, determine what the question "
            "is asking for (the unknown). Outline the steps needed to compute the answer, including "
            "any intermediate calculations. Ensure the plan is clear and logical."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Perform sequential calculations in parallel
        calculation_instructions = [
            (
                f"Using the extracted information: {extracted_info} and the solution plan: {solution_plan}, "
                "perform the following calculation: [insert specific calculation here]. Show your work step-by-step."
            )
            for _ in range(3)  # Adjust based on typical problem complexity
        ]
        calculation_results = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in calculation_instructions]
        )

        # Step 4: Synthesize results
        synthesis_instruction = (
            "Combine the following intermediate results into a single coherent answer. "
            "Resolve any discrepancies logically and ensure the final result is consistent with the problem context. "
            "If necessary, recompute or verify the steps."
        )
        final_answer = await self.ensemble(
            instruction=synthesis_instruction,
            contexts=calculation_results
        )

        # Step 5: Validate and format final answer
        validation_instruction = (
            "Review the final answer to ensure it is correct, formatted appropriately, and makes sense "
            "in the context of the problem. Address any issues such as incorrect units, illogical values, "
            "or missing steps."
        )
        validated_answer = await self.revise(instruction=validation_instruction, context=final_answer)

        return validated_answer