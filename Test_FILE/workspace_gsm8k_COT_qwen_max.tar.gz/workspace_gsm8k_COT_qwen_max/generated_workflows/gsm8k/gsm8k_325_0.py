# Workflow ID: gsm8k_325_0
# Benchmark: gsm8k
# Data Indices: [50, 351]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all numerical values, relationships, and units
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, "
            "relationships (e.g., percentages, fractions, rates), and units (e.g., dollars, apples). "
            "Organize the information clearly and label each piece of data."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Create a step-by-step mathematical plan
        modeling_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. Include all necessary calculations, "
            "intermediate steps, and unit conversions. Ensure the plan is chronological and logical."
        )
        solution_plan = await self.generate(instruction=modeling_instruction, context=self.problem_text)

        # Step 3: Generate multiple solution approaches in parallel
        approach_1_instruction = (
            f"Using the following plan:\n{solution_plan}\n"
            "Solve the problem directly, performing all calculations explicitly. "
            "Show all intermediate results and ensure the final answer is a single numerical value."
        )
        approach_2_instruction = (
            f"Using the following plan:\n{solution_plan}\n"
            "Break the problem into smaller sub-problems, solve each sub-problem independently, "
            "and then combine the results to arrive at the final answer."
        )
        approach_1, approach_2 = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text)
        )

        # Step 4: Ensemble decision-making to select the best solution
        ensemble_instruction = (
            "Evaluate the following two solutions and select the best one:\n"
            f"Solution 1:\n{approach_1}\n\nSolution 2:\n{approach_2}\n"
            "Consider accuracy, logical consistency, and adherence to the problem context. "
            "Provide the final answer as a single numerical value."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=[approach_1, approach_2])

        # Step 5: Refine the final solution to extract the numerical answer
        refinement_instruction = (
            f"From the following solution:\n{final_solution}\n"
            "Extract the final numerical answer. Ensure it is a single number (integer or decimal) "
            "and remove any extraneous text or units."
        )
        final_answer = await self.revise(instruction=refinement_instruction, context=final_solution)

        return final_answer