# Workflow ID: gsm8k_395_0
# Benchmark: gsm8k
# Data Indices: [258, 76]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract known values and relationships
        extraction_instruction = (
            "Extract all numerical values, units, and relationships from the problem. "
            "Identify any constraints or conditions that affect the calculations. "
            "Format the output as a structured summary."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan the solution
        planning_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Create a step-by-step plan to solve the problem. Include all intermediate calculations "
            "and specify the order of operations. Format the plan as a numbered list."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Execute the plan in parallel
        execution_instruction_template = (
            "Perform the following calculation step:\n{step}\n"
            "Ensure the result is accurate and includes appropriate units. "
            "If additional context is needed, refer to the original problem."
        )
        # Split the solution plan into individual steps
        steps = solution_plan.split("\n")
        execution_tasks = [
            self.generate(instruction=execution_instruction_template.format(step=step), context=self.problem_text)
            for step in steps if step.strip()
        ]
        intermediate_results = await asyncio.gather(*execution_tasks)

        # Step 4: Synthesize results using Ensemble
        synthesis_instruction = (
            "Evaluate and synthesize the following intermediate results to compute the final answer. "
            "Ensure the solution is consistent with the problem context and constraints."
        )
        final_result = await self.ensemble(instruction=synthesis_instruction, contexts=intermediate_results)

        # Step 5: Validate and finalize the result
        validation_instruction = (
            f"Review the following solution:\n{final_result}\n"
            "Ensure it is accurate, contextually valid, and adheres to real-world constraints. "
            "Revise if necessary to improve clarity or correctness."
        )
        validated_result = await self.revise(instruction=validation_instruction, context=final_result)

        return validated_result