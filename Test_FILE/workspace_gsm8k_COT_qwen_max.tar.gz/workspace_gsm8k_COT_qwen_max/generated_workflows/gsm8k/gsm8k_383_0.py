# Workflow ID: gsm8k_383_0
# Benchmark: gsm8k
# Data Indices: [353, 390]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all numerical values, relationships, and the question
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, relationships, "
            "and the specific question being asked. Clearly label each piece of information "
            "and organize it in a structured format for further processing."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Perform step-by-step reasoning to derive intermediate results
        reasoning_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem step by step. "
            "Identify any hidden calculations, ensure unit consistency, and sequence operations "
            "in the correct order. Provide intermediate results and explain each step clearly."
        )
        intermediate_reasoning = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Refine the intermediate reasoning to ensure accuracy
        refinement_instruction = (
            "Critically review the following reasoning and calculations: "
            f"{intermediate_reasoning}. Identify and correct any errors, ambiguities, "
            "or inconsistencies. Ensure the solution aligns with the problem's context."
        )
        refined_reasoning = await self.revise(instruction=refinement_instruction, context=intermediate_reasoning)

        # Step 4: Generate multiple reasoning paths for robustness
        path_1_instruction = (
            "Solve the problem using a direct calculation approach. Focus on clarity and precision."
        )
        path_2_instruction = (
            "Solve the problem using an alternative method, such as working backwards or "
            "using proportional reasoning. Ensure the solution is consistent with the problem's context."
        )
        paths = await asyncio.gather(
            self.generate(instruction=path_1_instruction, context=self.problem_text),
            self.generate(instruction=path_2_instruction, context=self.problem_text)
        )

        # Step 5: Select the best solution using ensemble
        ensemble_instruction = (
            "Compare the following solutions and select the most accurate and well-reasoned one: "
            f"{paths[0]} and {paths[1]}. Ensure the chosen solution addresses the problem's question "
            "and provides a single numerical answer."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=paths)

        # Step 6: Compute the final answer
        final_answer_instruction = (
            f"Extract the final numerical answer from the following solution: {final_solution}. "
            "Ensure the answer is precise, makes sense in the problem's context, and is expressed "
            "as a single number (integer or decimal)."
        )
        final_answer = await self.generate(instruction=final_answer_instruction, context=final_solution)

        return final_answer