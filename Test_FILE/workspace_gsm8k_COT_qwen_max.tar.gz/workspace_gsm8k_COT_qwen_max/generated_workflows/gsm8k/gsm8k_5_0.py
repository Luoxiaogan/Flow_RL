# Workflow ID: gsm8k_5_0
# Benchmark: gsm8k
# Data Indices: [543, 288]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant numerical values, relationships, and units
        extraction_instruction = (
            "Extract all numerical values, relationships, and units from the problem. "
            "Identify the known quantities and what is being asked. Ensure that you capture "
            "any constraints or conditions mentioned in the problem."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate a step-by-step solution based on the extracted information
        solution_instruction = (
            f"Given the following extracted information: {extracted_info}\n"
            "Reason through the problem step by step. Identify the sequence of calculations "
            "required to solve the problem. Ensure that all intermediate steps are clearly "
            "stated and that the solution adheres to the constraints provided in the problem. "
            "Include unit conversions and checks for consistency where applicable."
        )
        solution_steps = await self.generate(instruction=solution_instruction, context=self.problem_text)

        # Optional Step 3: Generate multiple solution approaches in parallel
        approach_1_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Solve the problem using a direct calculation approach. Ensure all steps are clear "
            "and logical."
        )
        approach_2_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Solve the problem using an alternative method or interpretation if applicable. "
            "Ensure all steps are clear and logical."
        )
        approaches = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text)
        )

        # Step 4: Ensemble to select or synthesize the best solution
        ensemble_instruction = (
            "Evaluate the following solution approaches and select the most accurate and "
            "logical one. If both approaches are valid, synthesize them into a single solution."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=approaches)

        # Step 5: Summarize the final answer
        summary_instruction = (
            "Condense the solution into a concise final answer. Ensure that the answer is "
            "presented as a single numerical value (integer or decimal) and includes the "
            "appropriate units if applicable."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=final_solution)

        return final_answer