# Workflow ID: gsm8k_279_0
# Benchmark: gsm8k
# Data Indices: [194, 402]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all numerical values, relationships, and constraints
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, "
            "relationships, and constraints. Include units (e.g., dollars, hours, items) "
            "and any implicit information (e.g., rates, proportions). Present the "
            "extracted information in a structured format for further processing."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate a step-by-step solution
        solution_instruction = (
            f"Given the following extracted information: {extracted_info}\n"
            "Solve the problem step-by-step. Clearly show all calculations, intermediate "
            "results, and reasoning. Ensure the order of operations is correct and units "
            "are handled consistently. If there are multiple steps, explain each one "
            "in detail."
        )
        solution = await self.generate(instruction=solution_instruction, context=self.problem_text)

        # Step 3: Revise and refine the solution
        revision_instruction = (
            "Review the following solution carefully. Check for logical consistency, "
            "correct order of operations, and proper handling of units. Identify any errors "
            "or areas for improvement. If necessary, suggest corrections or refinements. "
            "Ensure the solution is complete and accurate."
        )
        refined_solution = await self.revise(instruction=revision_instruction, context=solution)

        # Step 4: Extract the final numerical answer
        summarization_instruction = (
            "From the following refined solution, extract the final numerical answer. "
            "Ensure the answer is presented as a single integer or decimal value, "
            "without any additional text. Verify that the answer makes sense in the "
            "context of the problem."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_solution)

        return final_answer