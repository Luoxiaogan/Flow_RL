# Workflow ID: gsm8k_40_0
# Benchmark: gsm8k
# Data Indices: [308, 454]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract numerical values, units, and relationships
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, units, and relationships. "
            "Identify the known quantities and any constraints or conditions mentioned in the problem. "
            "Organize the information clearly for further processing."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate a step-by-step solution plan
        solution_plan_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "create a detailed step-by-step plan to solve the problem. "
            "Include all necessary calculations, intermediate results, and logical reasoning. "
            "Ensure the plan follows the correct order of operations and respects any contextual constraints."
        )
        solution_plan = await self.generate(instruction=solution_plan_instruction, context=self.problem_text)

        # Step 3: Refine the solution plan if necessary
        refinement_instruction = (
            "Review the solution plan and ensure it is logically sound and mathematically accurate. "
            "Check for any missing steps, incorrect assumptions, or calculation errors. "
            "Improve the plan if needed to ensure correctness and clarity."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=solution_plan)

        # Step 4: Execute the solution plan and calculate intermediate results
        execution_instruction = (
            f"Follow the refined solution plan: {refined_solution} "
            "and perform all calculations step by step. "
            "Record all intermediate results and validate them against the problem context. "
            "Ensure the final result is a single numerical value (integer or decimal)."
        )
        executed_solution = await self.generate(instruction=execution_instruction, context=self.problem_text)

        # Step 5: Extract and summarize the final answer
        summarization_instruction = (
            "From the executed solution, extract the final numerical answer. "
            "Ensure it is presented as a single value without any additional explanation or context."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=executed_solution)

        return final_answer