# Workflow ID: gsm8k_233_0
# Benchmark: gsm8k
# Data Indices: [738, 398]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract knowns and unknowns
        extraction_instruction = (
            "Extract all numerical values, relationships, units, and constraints from the problem. "
            "Include any implicit information (e.g., growth rates, time dependencies). "
            "Organize the extracted information clearly for subsequent reasoning."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan the solution approach
        planning_instruction = (
            f"Based on the following extracted information: {extracted_info} "
            "Create a step-by-step plan to solve the problem. Include intermediate calculations, "
            "hidden steps, and unit handling. Ensure the plan accounts for all constraints "
            "and real-world considerations."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Execute the calculations
        calculation_instruction = (
            f"Follow this solution plan: {solution_plan} "
            "Perform all calculations step by step. Ensure proper sequencing and unit consistency. "
            "Provide the final answer along with any intermediate results."
        )
        calculated_result = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Validate and refine the answer
        validation_instruction = (
            "Critique the following calculated result: {calculated_result}. "
            "Ensure the answer makes sense in the context of the problem. Check for unit consistency, "
            "real-world constraints (e.g., no negative quantities), and logical coherence. "
            "Refine the answer if necessary."
        )
        refined_answer = await self.revise(instruction=validation_instruction, context=calculated_result)

        # Step 5: Summarize the final answer
        summarization_instruction = (
            "Extract the final numerical answer from the following text: {refined_answer}. "
            "Ensure the output is a single number (integer or decimal) without any additional text."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_answer)

        return final_answer