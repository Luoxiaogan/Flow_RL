# Workflow ID: gsm8k_160_0
# Benchmark: gsm8k
# Data Indices: [490, 166]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information (numbers, units, relationships, question)
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, their associated units, "
            "any relationships or constraints mentioned (e.g., ratios, percentages, comparisons), "
            "and the specific question being asked. Format the output as follows:\n"
            "- Numerical Values: [list]\n"
            "- Units: [list]\n"
            "- Relationships/Constraints: [list]\n"
            "- Question: [text]"
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan the solution (sequence of operations)
        planning_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Devise a detailed step-by-step plan to solve the problem. Include all necessary calculations, "
            "intermediate results, and ensure proper handling of units. If there are multiple steps, "
            "clearly specify the order of operations."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Execute the calculations
        execution_instruction = (
            f"Using the following solution plan:\n{solution_plan}\n"
            "Perform all calculations step by step. Show intermediate results and ensure accuracy. "
            "If there are any ambiguities or missing details, make reasonable assumptions and proceed."
        )
        calculated_result = await self.generate(instruction=execution_instruction, context=self.problem_text)

        # Step 4: Validate the solution
        validation_instruction = (
            f"Review the following result:\n{calculated_result}\n"
            "Critique its correctness and ensure it makes sense in the context of the problem. "
            "Check for unit consistency, realistic values (e.g., no negative quantities for physical items), "
            "and appropriate precision (decimal places). If any issues are found, revise the solution accordingly."
        )
        validated_result = await self.revise(instruction=validation_instruction, context=calculated_result)

        # Step 5: Summarize the final answer
        summarization_instruction = (
            f"From the following validated result:\n{validated_result}\n"
            "Extract and present the final answer in a concise format that directly answers the question. "
            "Ensure the output is clear, precise, and includes appropriate units if applicable."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=validated_result)

        return final_answer