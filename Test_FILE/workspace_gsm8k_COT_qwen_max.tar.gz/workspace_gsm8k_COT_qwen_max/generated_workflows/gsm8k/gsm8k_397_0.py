# Workflow ID: gsm8k_397_0
# Benchmark: gsm8k
# Data Indices: [148, 688]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract known information
        extraction_instruction = (
            "Carefully read the problem and extract all numerical values, relationships, and constraints. "
            "Identify the unknown(s) to be solved. Ensure all units are explicitly noted. "
            "Format the output as a structured summary."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a solution plan
        plan_instruction = (
            f"Based on the following extracted information: {extracted_info} "
            "Create a detailed step-by-step plan to solve the problem. "
            "Include intermediate calculations, order of operations, and any necessary unit conversions. "
            "Ensure the plan is mathematically sound and accounts for all constraints."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute calculations
        calculation_instruction = (
            f"Using the following solution plan: {solution_plan} "
            "Perform all calculations step by step. Clearly show intermediate results and ensure proper handling of units. "
            "Produce the final numerical result at the end."
        )
        calculated_result = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Validate the result
        validation_instruction = (
            f"Review the following result: {calculated_result} "
            "Verify its correctness by checking for logical consistency, unit correctness, and adherence to the problem's context. "
            "If errors are found, refine the result accordingly."
        )
        validated_result = await self.revise(instruction=validation_instruction, context=calculated_result)

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"From the following validated result: {validated_result} "
            "Extract and present only the final numerical answer. Ensure the output is concise and unambiguous."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=validated_result)

        return final_answer