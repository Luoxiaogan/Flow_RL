# Workflow ID: gsm8k_218_0
# Benchmark: gsm8k
# Data Indices: [499, 715]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information (numerical values, units, relationships)
        extraction_instruction = """
        Extract all numerical values, units, and relationships from the problem text. 
        Identify what is being asked and list all given data points explicitly. 
        Ensure you capture any constraints or conditions mentioned in the problem.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a solution plan
        plan_instruction = f"""
        Based on the extracted information: {extracted_info}
        Formulate a detailed step-by-step plan to solve the problem. 
        Identify the sequence of operations required (e.g., addition, multiplication, unit conversions). 
        Clearly state any intermediate calculations needed and how they relate to the final answer.
        """
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Perform calculations
        calculation_instruction = f"""
        Execute the solution plan step-by-step: {solution_plan}
        Perform all calculations explicitly, showing intermediate results. 
        Ensure units are consistent throughout and verify each step logically follows from the previous one.
        """
        calculations = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Validate the solution
        validation_instruction = f"""
        Review the calculations: {calculations}
        Verify that the solution makes sense in the context of the problem. 
        Check for logical consistency, unit correctness, and adherence to any constraints mentioned in the problem.
        Suggest corrections if necessary.
        """
        validated_solution = await self.revise(instruction=validation_instruction, context=calculations)

        # Step 5: Summarize the final answer
        summary_instruction = """
        Condense the validated solution into a single numerical value. 
        Ensure the answer is clear, concise, and formatted appropriately.
        """
        final_answer = await self.summarize(instruction=summary_instruction, context=validated_solution)

        return final_answer