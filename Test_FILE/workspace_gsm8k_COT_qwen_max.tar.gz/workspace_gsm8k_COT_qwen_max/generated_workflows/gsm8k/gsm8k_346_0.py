# Workflow ID: gsm8k_346_0
# Benchmark: gsm8k
# Data Indices: [511, 200]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (numerical values, relationships, constraints)
        extraction_instruction = (
            "Extract all numerical values, relationships, and constraints from the problem. "
            "Include units (e.g., dollars, minutes) and describe how the values relate to each other. "
            "Highlight any implicit constraints (e.g., non-negative quantities)."
        )
        key_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan the solution (step-by-step breakdown)
        plan_instruction = (
            f"Based on the extracted information: {key_info}\n"
            "Create a detailed step-by-step plan to solve the problem. "
            "Identify the unknown(s) to solve for, break the problem into smaller operations, "
            "and ensure proper handling of units and constraints."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Perform calculations (execute the plan)
        calculation_instruction = (
            f"Follow this plan step-by-step: {solution_plan}\n"
            "Perform all necessary calculations, documenting each step and its result. "
            "Ensure intermediate results are correct and consistent with the problem context."
        )
        calculations = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Verify the solution (validate correctness)
        verification_instruction = (
            f"Review the calculations: {calculations}\n"
            "Verify that the solution satisfies all constraints and makes sense in the problem context. "
            "Check for unit consistency, reasonable scale, and logical correctness."
        )
        verified_solution = await self.revise(instruction=verification_instruction, context=calculations)

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"Condense the verified solution: {verified_solution}\n"
            "Provide a concise summary that highlights the final numerical answer. "
            "Ensure the answer is clear and directly addresses the problem question."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=verified_solution)

        return final_answer