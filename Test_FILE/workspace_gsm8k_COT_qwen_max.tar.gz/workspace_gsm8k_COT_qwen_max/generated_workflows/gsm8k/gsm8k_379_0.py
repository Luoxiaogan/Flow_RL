# Workflow ID: gsm8k_379_0
# Benchmark: gsm8k
# Data Indices: [71, 692]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract known information and unknowns
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, relationships, "
            "and units. Identify what is given and what needs to be calculated. "
            "Include any constraints or conditions mentioned in the problem."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a solution plan
        plan_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. "
            "Include intermediate calculations, order of operations, and unit tracking. "
            "Ensure the plan addresses all parts of the question."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute calculations
        calculation_instruction = (
            f"Follow this solution plan:\n{solution_plan}\n"
            "Perform all calculations step by step. Show intermediate results and ensure "
            "they are logically sequenced. Verify that the calculations align with the problem's context."
        )
        calculations = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Validate and refine results
        refinement_instruction = (
            f"Review the following calculations:\n{calculations}\n"
            "Check for accuracy, consistency, and adherence to the problem's constraints. "
            "Refine any errors or inconsistencies. Ensure the final result makes sense in the context of the problem."
        )
        refined_results = await self.revise(instruction=refinement_instruction, context=calculations)

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"Condense the following refined results into a concise statement:\n{refined_results}\n"
            "Include only the final numerical answer with appropriate units if applicable."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_results)

        return final_answer