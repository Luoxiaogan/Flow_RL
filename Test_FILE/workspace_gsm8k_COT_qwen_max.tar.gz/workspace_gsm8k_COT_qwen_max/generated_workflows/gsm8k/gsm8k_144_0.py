# Workflow ID: gsm8k_144_0
# Benchmark: gsm8k
# Data Indices: [267, 450]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract Key Information
        extraction_instruction = (
            "Extract all numerical values, relationships, and entities from the problem. "
            "Identify what is being asked and any constraints or conditions provided."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a Plan
        plan_instruction = (
            f"Based on the extracted information: {extracted_info}, "
            "create a step-by-step plan to solve the problem. "
            "Include all necessary calculations and intermediate steps."
        )
        plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute Calculations
        calculation_instruction = (
            f"Follow this plan: {plan} to perform the calculations. "
            "Ensure each step is clearly documented and verified for correctness."
        )
        calculations = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Verify and Revise
        verify_instruction = (
            f"Review the calculations: {calculations}. "
            "Check for any errors or inconsistencies and refine the solution if necessary."
        )
        verified_solution = await self.revise(instruction=verify_instruction, context=calculations)

        # Step 5: Summarize the Final Answer
        summarize_instruction = (
            f"Summarize the final result from the verified solution: {verified_solution}. "
            "Present the answer in a clear and concise manner."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=verified_solution)

        return final_answer