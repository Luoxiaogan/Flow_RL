# Workflow ID: gsm8k_363_0
# Benchmark: gsm8k
# Data Indices: [6, 116]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract relevant information from the problem
        extraction_instruction = (
            "Extract all numerical values, relationships, and units from the problem. "
            "Identify what is being asked and list any constraints or conditions explicitly."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Create a step-by-step solution plan
        modeling_instruction = (
            f"Based on the following extracted information: {extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. Include intermediate calculations, "
            "identify the sequence of operations, and specify how the final answer will be determined."
        )
        solution_plan = await self.generate(instruction=modeling_instruction, context=self.problem_text)

        # Step 3: Generate multiple potential solutions in parallel
        solution_instructions = [
            f"Follow this plan: {solution_plan}\nSolve the problem step by step.",
            f"Consider alternative interpretations of the relationships in: {solution_plan}\nSolve the problem step by step.",
            f"Double-check calculations in: {solution_plan}\nSolve the problem step by step."
        ]
        solutions = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in solution_instructions]
        )

        # Step 4: Evaluate and select the best solution
        ensemble_instruction = (
            "Compare the following solutions and select the most accurate and complete one. "
            "Ensure the chosen solution adheres to the problem's context and constraints."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=solutions)

        # Step 5: Refine the selected solution
        refinement_instruction = (
            "Improve the clarity and correctness of the solution. Verify that all steps are logically sound, "
            "units are consistent, and the final answer makes sense in the problem's context."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 6: Summarize the final answer
        summarization_instruction = (
            "Condense the solution into a concise final answer. Ensure the result is clear, precise, "
            "and includes the numerical value with appropriate units if applicable."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_solution)

        return final_answer