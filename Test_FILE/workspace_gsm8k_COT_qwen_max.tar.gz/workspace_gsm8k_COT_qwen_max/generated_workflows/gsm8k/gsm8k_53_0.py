# Workflow ID: gsm8k_53_0
# Benchmark: gsm8k
# Data Indices: [54, 232]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information (numerical values, relationships, question)
        extraction_instruction = (
            "Extract all numerical values, their units (if any), and the relationships between them from the problem. "
            "Also, identify the specific question being asked. Format the output as follows:\n"
            "- Numerical Values: [list]\n"
            "- Units: [list]\n"
            "- Relationships: [descriptions]\n"
            "- Question: [question]"
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate a step-by-step solution
        solution_instruction = (
            f"Using the following extracted information:\n{extracted_info}\n"
            "Generate a step-by-step solution to the problem. Ensure that each step is clearly explained and includes "
            "intermediate results. Format the output as follows:\n"
            "- Step 1: [description and calculation]\n"
            "- Step 2: [description and calculation]\n"
            "- ...\n"
            "- Final Answer: [value]"
        )
        solution = await self.generate(instruction=solution_instruction, context=self.problem_text)

        # Step 3: Verify and refine the solution
        refinement_instruction = (
            "Review the following solution and check for errors or inconsistencies. "
            "Ensure that the calculations are correct, the units are consistent, and the answer makes sense in the context of the problem. "
            "If any issues are found, provide a revised version of the solution."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=solution)

        # Step 4: Extract the final answer
        final_answer_instruction = (
            "Extract the final numerical answer from the following solution. "
            "Ensure that the answer is a single numerical value (integer or decimal)."
        )
        final_answer = await self.summarize(instruction=final_answer_instruction, context=refined_solution)

        return final_answer