# Workflow ID: gsm8k_3_0
# Benchmark: gsm8k
# Data Indices: [734, 523]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio
        
        # Step 1: Extract key information
        extraction_instruction = (
            "Extract all numerical values, units, relationships, and constraints from the problem. "
            "Format the output as a structured list, clearly labeling each element. "
            "Ensure no relevant detail is omitted."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)
        
        # Step 2: Formulate a solution plan
        plan_instruction = (
            f"Using the extracted information: {extracted_info}, formulate a step-by-step solution plan. "
            "Include all necessary calculations, intermediate steps, and unit conversions. "
            "Highlight any hidden steps or assumptions. Ensure the plan is logically consistent."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)
        
        # Step 3: Execute the solution plan
        execution_instruction = (
            f"Follow this solution plan: {solution_plan}. Perform all calculations step-by-step. "
            "Track units consistently and document intermediate results. "
            "Ensure the final result is a single numerical value."
        )
        execution_result = await self.generate(instruction=execution_instruction, context=self.problem_text)
        
        # Step 4: Validate intermediate results
        validation_instruction = (
            "Review the calculations and intermediate results for logical consistency, unit correctness, "
            "and contextual relevance. Highlight any errors or inconsistencies."
        )
        validated_result = await self.revise(instruction=validation_instruction, context=execution_result)
        
        # Step 5: Summarize the final answer
        summary_instruction = (
            "Condense the validated result into a concise final answer. "
            "Ensure the answer is a single numerical value and makes sense in the context of the problem."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=validated_result)
        
        return final_answer