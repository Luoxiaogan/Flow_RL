# Workflow ID: gsm8k_358_0
# Benchmark: gsm8k
# Data Indices: [739, 223]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information (numbers, units, relationships)
        extract_instruction = (
            "Extract all numerical values, units, and relationships mentioned in the problem. "
            "Clearly identify known quantities and unknowns. "
            "Include any constraints or conditions specified in the problem."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Model the problem mathematically
        model_instruction = (
            f"Based on the following extracted information: {extracted_info}\n"
            "Translate the problem into a mathematical model or sequence of operations. "
            "Identify the operations needed (addition, subtraction, multiplication, division) and their order. "
            "Include intermediate steps if necessary. Ensure unit consistency throughout."
        )
        mathematical_model = await self.generate(instruction=model_instruction, context=self.problem_text)

        # Step 3: Perform calculations (explore multiple paths if needed)
        calculate_instruction = (
            f"Using the mathematical model: {mathematical_model}\n"
            "Perform the calculations step by step. Ensure all intermediate results are explicitly stated. "
            "If there are multiple interpretations or solution paths, compute results for each path."
        )
        calculation_results = await asyncio.gather(
            self.generate(instruction=calculate_instruction, context=self.problem_text),
            self.generate(instruction=calculate_instruction, context=self.problem_text)  # Optional second path
        )

        # Step 4: Decide on the best solution (if multiple paths exist)
        ensemble_instruction = (
            "Compare the following candidate solutions and select the best one. "
            "Ensure the chosen solution adheres to the problem's context and constraints."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=calculation_results)

        # Step 5: Validate and refine the solution
        revise_instruction = (
            f"Critique the following solution: {final_solution}\n"
            "Ensure it is logically consistent, adheres to the problem's context, and satisfies all constraints. "
            "Refine the solution if necessary."
        )
        refined_solution = await self.revise(instruction=revise_instruction, context=final_solution)

        # Step 6: Summarize the final result
        summarize_instruction = (
            f"Condense the following solution into a single numerical value: {refined_solution}\n"
            "Ensure the final answer is clear, concise, and includes appropriate units if necessary."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_answer