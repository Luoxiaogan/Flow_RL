# Workflow ID: gsm8k_185_0
# Benchmark: gsm8k
# Data Indices: [145, 519]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract Key Information
        extraction_instruction = """
        Carefully analyze the problem text and extract all relevant numerical values, relationships, and constraints.
        Identify what is being asked and any conditions that apply. Pay attention to units, rates, and proportional relationships.
        Format the output as a structured summary of the extracted information.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Mathematical Modeling and Calculations
        modeling_instruction = f"""
        Based on the following extracted information: {extracted_info}
        Translate the textual relationships into mathematical equations or logical steps.
        Perform all necessary calculations step-by-step, ensuring intermediate results are clearly stated.
        If there are multiple steps, solve them sequentially and verify each step before proceeding.
        Ensure the final result answers the question posed in the problem.
        """
        calculations = await self.generate(instruction=modeling_instruction, context=self.problem_text)

        # Step 3: Refine Intermediate Results (if necessary)
        refinement_instruction = """
        Review the intermediate calculations and results. Check for any errors, inconsistencies, or missing steps.
        Adjust the results if necessary to ensure they make sense in the context of the problem.
        Pay special attention to unit consistency, rounding, and real-world constraints.
        """
        refined_results = await self.revise(instruction=refinement_instruction, context=calculations)

        # Step 4: Final Answer Synthesis
        summarization_instruction = """
        Summarize the final result of the calculations into a single numerical value.
        Ensure the answer is presented in the correct format (integer or decimal) and includes appropriate units if applicable.
        Verify that the answer makes sense in the context of the problem.
        """
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_results)

        return final_answer