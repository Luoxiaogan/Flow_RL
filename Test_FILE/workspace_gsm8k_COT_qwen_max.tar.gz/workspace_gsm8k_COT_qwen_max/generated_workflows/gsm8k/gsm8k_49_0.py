# Workflow ID: gsm8k_49_0
# Benchmark: gsm8k
# Data Indices: [615, 608]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, units, relationships, and constraints. "
            "List them clearly and categorize them as knowns or unknowns. Ensure no detail is missed."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan the solution strategy
        planning_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "outline a step-by-step plan to solve the problem. Identify any intermediate steps or hidden calculations. "
            "Ensure the plan is logical, sequential, and accounts for all constraints."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Generate multiple solution approaches in parallel
        approach_1_instruction = (
            f"Follow this plan: {solution_plan}. Perform the calculations step by step and provide the final answer. "
            "Ensure all units are consistent and the result is verified."
        )
        approach_2_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem independently. "
            "Consider alternative methods or perspectives if applicable."
        )
        approach_3_instruction = (
            f"Reinterpret the problem and solve it differently. Focus on clarity and correctness."
        )

        results = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text),
            self.generate(instruction=approach_3_instruction, context=self.problem_text)
        )

        # Step 4: Ensemble decision-making to select the best solution
        ensemble_instruction = (
            "Evaluate the following candidate solutions and select the most accurate and consistent one. "
            "Resolve any discrepancies and ensure the chosen solution adheres to the problem's context and constraints."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 5: Refine and verify the final solution
        refinement_instruction = (
            "Critique the following solution and refine it if necessary. "
            "Ensure the answer is accurate, makes sense in context, and adheres to all constraints. "
            "Verify unit consistency and logical coherence."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=final_solution)

        return refined_solution