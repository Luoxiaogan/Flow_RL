# Workflow ID: gsm8k_328_0
# Benchmark: gsm8k
# Data Indices: [407, 276]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (numerical values, relationships, constraints)
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, relationships, "
            "and constraints. Identify the knowns and unknowns. Ensure that units and context "
            "are preserved. Present the information in a structured format."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a step-by-step solution plan
        plan_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Formulate a detailed step-by-step plan to solve the problem. Include all necessary "
            "calculations, intermediate steps, and unit conversions. Ensure the plan is logically "
            "consistent and accounts for real-world constraints."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Generate multiple solution approaches in parallel
        approach_1_instruction = (
            f"Follow this solution plan strictly:\n{solution_plan}\n"
            "Perform the calculations step by step and provide the final numerical answer. "
            "Ensure all intermediate results are clearly documented."
        )
        approach_2_instruction = (
            f"Analyze the problem independently and propose an alternative solution approach:\n{extracted_info}\n"
            "Perform the calculations step by step and provide the final numerical answer. "
            "Ensure all intermediate results are clearly documented."
        )
        results = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text)
        )

        # Step 4: Select the best solution using Ensemble
        ensemble_instruction = (
            "Evaluate the following two solutions and select the best one:\n"
            "1. First solution: {}\n"
            "2. Second solution: {}\n"
            "Consider correctness, logical consistency, adherence to the problem context, and clarity. "
            "If both solutions are valid, synthesize them into a single improved solution."
        ).format(results[0], results[1])
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 5: Extract the final numerical answer
        answer_extraction_instruction = (
            f"Extract the final numerical answer from the following solution:\n{final_solution}\n"
            "Ensure the answer is a single numerical value (integer or decimal). Include units if applicable."
        )
        final_answer = await self.generate(instruction=answer_extraction_instruction, context=self.problem_text)

        return final_answer