# Workflow ID: gsm8k_24_0
# Benchmark: gsm8k
# Data Indices: [16, 284]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract numerical values, relationships, and contextual information
        extraction_instruction = (
            "Extract all numerical values, units, and relationships from the problem. "
            "Organize them in a structured format, including any implicit information or constraints. "
            "Ensure the output is comprehensive and ready for step-by-step reasoning."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate step-by-step solution
        reasoning_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "solve the problem step by step. Include all intermediate calculations, "
            "ensure correct sequencing of operations, and maintain unit consistency. "
            "Provide a clear explanation for each step and verify that the solution makes sense in context."
        )
        step_by_step_solution = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Revise and refine the solution
        revision_instruction = (
            "Critically review the provided solution. Check for logical consistency, "
            "correctness of calculations, and adherence to real-world constraints. "
            "Refine the solution if necessary, ensuring it is accurate and complete."
        )
        refined_solution = await self.revise(instruction=revision_instruction, context=step_by_step_solution)

        # Step 4: Extract and format the final answer
        summarization_instruction = (
            "From the refined solution, identify and extract the final numerical answer. "
            "Ensure it is formatted as a single value (integer or decimal) without additional text."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_solution)

        return final_answer