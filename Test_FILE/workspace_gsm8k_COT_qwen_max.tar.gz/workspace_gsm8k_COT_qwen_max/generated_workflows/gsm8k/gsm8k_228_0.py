# Workflow ID: gsm8k_228_0
# Benchmark: gsm8k
# Data Indices: [785, 142]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (numbers, relationships, units)
        extract_instruction = (
            "Carefully analyze the problem and extract all numerical values, "
            "relationships, and units mentioned in the text. "
            "Include any implicit information (e.g., rates, proportions) and "
            "clearly label each piece of information for reference."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Formulate a solution plan
        plan_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "create a step-by-step plan to solve the problem. "
            "Clearly specify the order of operations, intermediate calculations, "
            "and how units will be handled throughout the process."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Perform calculations
        calculate_instruction = (
            f"Following this solution plan: {solution_plan}, "
            "execute the calculations step by step. "
            "Show all intermediate results and ensure that units are consistent. "
            "Provide the final result with appropriate precision."
        )
        calculated_result = await self.generate(instruction=calculate_instruction, context=self.problem_text)

        # Step 4: Verify the result
        verify_instruction = (
            f"Review the calculated result: {calculated_result}. "
            "Ensure that it aligns with the problem's context and constraints. "
            "Check for calculation errors, unit consistency, and logical coherence."
        )
        verified_result = await self.revise(instruction=verify_instruction, context=calculated_result)

        # Step 5: Summarize the final answer
        summarize_instruction = (
            f"Condense the verified result: {verified_result} into a concise format. "
            "Present only the final numerical answer, ensuring it is clear and unambiguous."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=verified_result)

        return final_answer