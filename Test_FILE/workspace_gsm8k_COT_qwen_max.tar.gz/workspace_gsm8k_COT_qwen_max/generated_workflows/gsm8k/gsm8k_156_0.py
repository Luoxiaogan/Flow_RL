# Workflow ID: gsm8k_156_0
# Benchmark: gsm8k
# Data Indices: [201, 557]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information (numerical values, relationships, constraints)
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, "
            "relationships, and contextual constraints. Clearly label each piece of "
            "information and organize it logically for further processing."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a solution plan
        planning_instruction = (
            f"Using the extracted information: {extracted_info}, create a detailed "
            "step-by-step plan to solve the problem. Include all necessary calculations, "
            "intermediate steps, and unit conversions. Ensure the plan addresses any "
            "hidden steps or implicit relationships in the problem."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Execute calculations
        calculation_instruction = (
            f"Follow this solution plan: {solution_plan}. Perform all calculations "
            "step by step, keeping track of intermediate results and units. Ensure "
            "that each step is clearly documented and justified."
        )
        calculated_result = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Validate and refine results
        validation_instruction = (
            f"Review the calculated result: {calculated_result}. Verify that it makes "
            "sense in the context of the problem. Check for real-world constraints, "
            "unit consistency, and logical coherence. If any issues are found, refine "
            "the result accordingly."
        )
        refined_result = await self.revise(instruction=validation_instruction, context=calculated_result)

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"Extract the final numerical answer from the refined result: {refined_result}. "
            "Ensure the answer is concise, accurate, and formatted as a single number."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_result)

        return final_answer