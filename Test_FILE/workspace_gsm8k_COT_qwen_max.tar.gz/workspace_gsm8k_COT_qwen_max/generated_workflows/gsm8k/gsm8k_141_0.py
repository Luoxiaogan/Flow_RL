# Workflow ID: gsm8k_141_0
# Benchmark: gsm8k
# Data Indices: [29, 535]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Thoroughly analyze the problem and extract all relevant information, including:\n"
            "- Numerical values and their associated units\n"
            "- Relationships between quantities (e.g., ratios, rates)\n"
            "- The specific question being asked\n"
            "- Any implicit constraints or conditions\n"
            "Format the extracted information clearly and concisely."
        )
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Identify intermediate calculation steps
        intermediate_instruction = (
            f"Based on the following extracted information:\n{extraction}\n"
            "Determine all intermediate calculation steps required to solve the problem. Include:\n"
            "- Conversions between units (if necessary)\n"
            "- Partial calculations (e.g., totals, differences)\n"
            "- Logical sequencing of operations\n"
            "Provide a detailed breakdown of each step."
        )
        intermediate_steps = await self.generate(instruction=intermediate_instruction, context=self.problem_text)

        # Step 3: Synthesize the final solution
        synthesis_instruction = (
            f"Using the extracted information:\n{extraction}\n"
            f"And the intermediate calculation steps:\n{intermediate_steps}\n"
            "Perform all necessary calculations and synthesize the final solution. Ensure:\n"
            "- The answer is a single numerical value\n"
            "- Units are consistent and correctly applied\n"
            "- The result addresses the specific question asked\n"
            "Present the final answer clearly."
        )
        solution = await self.generate(instruction=synthesis_instruction, context=self.problem_text)

        # Step 4: Validate and refine the solution
        refinement_instruction = (
            f"Review the following solution:\n{solution}\n"
            "Critique it for:\n"
            "- Logical consistency\n"
            "- Correctness of calculations\n"
            "- Adherence to real-world constraints (e.g., non-negative quantities)\n"
            "- Clarity and precision in presentation\n"
            "If any issues are found, revise the solution accordingly."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=solution)

        return refined_solution