# Workflow ID: gsm8k_164_0
# Benchmark: gsm8k
# Data Indices: [188, 512]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract numerical values and relationships
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, units, and relationships. "
            "Include any hidden constraints or implicit steps. Provide the output in a structured format, "
            "such as a list of key-value pairs or bullet points."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Perform intermediate reasoning and calculations
        reasoning_instruction = (
            f"Using the following extracted information: {extracted_info}, "
            "solve the problem step by step. Clearly outline each calculation or logical deduction, "
            "and ensure all units are consistent. Provide intermediate results explicitly."
        )
        intermediate_solution = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Revise and refine the intermediate solution
        revise_instruction = (
            "Critically review the intermediate solution provided. Identify any errors, inconsistencies, "
            "or missing steps. Suggest corrections and improvements where necessary."
        )
        refined_solution = await self.revise(instruction=revise_instruction, context=intermediate_solution)

        # Step 4: Summarize the final answer
        summarize_instruction = (
            "Condense the refined solution into a concise final answer. Ensure the answer is clear, "
            "numerical, and makes sense in the context of the problem. Include the appropriate units if applicable."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_answer