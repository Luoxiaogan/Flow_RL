# Workflow ID: gsm8k_7_0
# Benchmark: gsm8k
# Data Indices: [539, 602]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract known information and relationships
        extract_instruction = (
            "Carefully analyze the problem statement and extract all numerical values, "
            "relationships, and constraints. Clearly label each piece of information and "
            "describe how they relate to each other. If units are mentioned, include them."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Formulate a step-by-step plan to solve the problem
        plan_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. Include all intermediate "
            "calculations, specify the order of operations, and ensure unit consistency. "
            "Highlight any hidden steps or assumptions."
        )
        plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute the plan and compute intermediate results
        execute_instruction = (
            f"Follow the plan below step by step and perform the necessary calculations:\n{plan}\n"
            "Show all intermediate results and ensure accuracy at each step. If units are involved, "
            "track them throughout the calculations."
        )
        execution_result = await self.generate(instruction=execute_instruction, context=self.problem_text)

        # Step 4: Verify the solution for correctness and consistency
        verify_instruction = (
            "Critique the following solution and ensure it is logically consistent and accurate:\n"
            f"{execution_result}\n"
            "Check for unit correctness, adherence to real-world constraints, and alignment with the "
            "problem's context. Suggest improvements if needed."
        )
        verified_solution = await self.revise(instruction=verify_instruction, context=execution_result)

        # Step 5: Summarize the final answer
        summarize_instruction = (
            "Condense the following solution into a concise, final answer that directly addresses "
            "the question posed in the problem:\n"
            f"{verified_solution}\n"
            "Ensure the answer is clear, precise, and includes appropriate units if applicable."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=verified_solution)

        return final_answer