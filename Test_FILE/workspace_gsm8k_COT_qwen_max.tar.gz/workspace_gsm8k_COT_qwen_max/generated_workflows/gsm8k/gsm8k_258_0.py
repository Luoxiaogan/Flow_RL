# Workflow ID: gsm8k_258_0
# Benchmark: gsm8k
# Data Indices: [458, 630]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (numerical values, units, relationships)
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, units, and relationships. "
            "Include any implicit information such as rates, totals, or constraints. "
            "Format the output as a structured list for clarity."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a step-by-step solution plan
        planning_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. "
            "Identify intermediate calculations, determine the order of operations, and ensure unit consistency. "
            "Explain the reasoning behind each step."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Execute calculations step-by-step
        # Split the solution plan into individual steps and process them
        steps = solution_plan.split("\n")
        calculation_results = []
        for step in steps:
            if step.strip():  # Ignore empty lines
                calculation_instruction = (
                    f"Perform the following calculation step:\n{step}\n"
                    "Show all intermediate results and explain the reasoning behind each operation."
                )
                result = await self.generate(instruction=calculation_instruction, context=self.problem_text)
                calculation_results.append(result)

        # Step 4: Synthesize the final answer
        synthesis_instruction = (
            "Combine the following calculation results into a single coherent answer:\n" +
            "\n".join(calculation_results) + "\n"
            "Ensure the final answer is a single numerical value (integer or decimal) and include the appropriate units. "
            "Verify that the answer makes sense in the context of the problem."
        )
        final_answer = await self.generate(instruction=synthesis_instruction, context=self.problem_text)

        # Step 5: Verify contextual consistency
        verification_instruction = (
            f"Review the following final answer:\n{final_answer}\n"
            "Check for real-world constraints (e.g., non-negative quantities), unit correctness, and logical consistency. "
            "Revise the answer if necessary to ensure it aligns with the problem's context."
        )
        verified_answer = await self.revise(instruction=verification_instruction, context=final_answer)

        return verified_answer