# Workflow ID: gsm8k_381_0
# Benchmark: gsm8k
# Data Indices: [196, 244]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract known information
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, units, "
            "relationships, and entities. Identify the question being asked and any constraints. "
            "Provide this information in a structured format."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a solution plan
        plan_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. Include all intermediate "
            "calculations, ensure unit consistency, and specify the order of operations. "
            "Clearly state how the final answer will be derived."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Perform calculations
        calculation_instruction = (
            f"Execute the following solution plan step by step:\n{solution_plan}\n"
            "Perform all calculations systematically, track units, and verify intermediate results. "
            "Ensure the final answer is clearly stated as a single numerical value."
        )
        calculated_result = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Validate the solution
        validation_instruction = (
            f"Review the following calculated result:\n{calculated_result}\n"
            "Critique the solution for logical consistency, unit correctness, and real-world feasibility. "
            "Refine the result if necessary and ensure it answers the original question accurately."
        )
        validated_result = await self.revise(instruction=validation_instruction, context=calculated_result)

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"Condense the following validated result into a concise final answer:\n{validated_result}\n"
            "Highlight the single numerical value that answers the problem. Ensure clarity and precision."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=validated_result)

        return final_answer