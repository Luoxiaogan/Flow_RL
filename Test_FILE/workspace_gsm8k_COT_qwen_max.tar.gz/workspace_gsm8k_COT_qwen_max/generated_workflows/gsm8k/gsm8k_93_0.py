# Workflow ID: gsm8k_93_0
# Benchmark: gsm8k
# Data Indices: [151, 345]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information
        extraction_instruction = """
        Extract all numerical values, relationships, and constraints from the problem text. 
        Identify the known quantities, unknowns, and any mathematical relationships described in the problem. 
        Ensure that units (if any) are explicitly noted. Format the output as a structured list or paragraph.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate the solution plan
        planning_instruction = f"""
        Based on the following extracted information: {extracted_info}
        Create a step-by-step plan to solve the problem. Include:
        - The sequence of mathematical operations required
        - Any intermediate steps not explicitly stated in the problem
        - How to handle units and ensure consistency
        Format the plan as a numbered list of steps.
        """
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Perform step-by-step calculations
        calculation_instruction = f"""
        Execute the following solution plan step by step:
        {solution_plan}
        Perform all calculations accurately, showing intermediate results. 
        Ensure that units are tracked throughout and that each step logically follows from the previous one.
        """
        calculations = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Validate intermediate results
        validation_instruction = f"""
        Review the following calculations: {calculations}
        Check for:
        - Arithmetic accuracy
        - Consistency with the problem context
        - Reasonableness of intermediate results
        Suggest corrections if any errors are found.
        """
        validated_results = await self.revise(instruction=validation_instruction, context=calculations)

        # Step 5: Summarize the final answer
        summarization_instruction = f"""
        From the validated results: {validated_results}
        Extract and summarize the final numerical answer. Ensure the result is presented as a single number, 
        including any necessary decimal places or units.
        """
        final_answer = await self.summarize(instruction=summarization_instruction, context=validated_results)

        return final_answer