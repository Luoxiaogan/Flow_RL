# Workflow ID: gsm8k_286_0
# Benchmark: gsm8k
# Data Indices: [720, 78]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all numerical values, relationships, and constraints
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, relationships, "
            "and constraints. Include units where applicable and describe the context of each value."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate a step-by-step solution based on the extracted information
        reasoning_instruction = (
            f"Using the following extracted information: {extracted_info}\n"
            "Solve the problem step by step. Clearly show all intermediate calculations, "
            "including any unit conversions or logical deductions. Ensure the solution "
            "is mathematically sound and adheres to real-world constraints."
        )
        step_by_step_solution = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Revise the solution for accuracy and consistency
        revision_instruction = (
            "Critically review the following solution for logical consistency, mathematical correctness, "
            "and adherence to real-world constraints. Suggest improvements if necessary."
        )
        refined_solution = await self.revise(instruction=revision_instruction, context=step_by_step_solution)

        # Step 4: Summarize the refined solution into a concise final answer
        summarization_instruction = (
            "Condense the following solution into a single numerical answer. "
            "Ensure the answer is clear, precise, and includes appropriate units if needed."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_solution)

        return final_answer