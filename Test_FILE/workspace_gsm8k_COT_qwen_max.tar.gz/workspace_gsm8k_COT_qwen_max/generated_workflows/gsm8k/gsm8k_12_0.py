# Workflow ID: gsm8k_12_0
# Benchmark: gsm8k
# Data Indices: [798, 721]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (numerical values, relationships, constraints)
        extract_instruction = """
        Analyze the problem thoroughly and extract all relevant numerical values, relationships, and constraints.
        Clearly identify what is given and what is being asked. Format the extracted information in a structured way,
        such as a list or table, for easy reference in subsequent steps.
        """
        extraction_task = self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Construct a step-by-step solution based on the extracted information
        solution_instruction_template = """
        Using the following extracted information: {extraction}
        Solve the problem step by step. Perform all necessary calculations explicitly and ensure each step logically
        follows from the previous one. Include intermediate results and verify unit consistency throughout.
        """
        solution_task = self.generate(
            instruction=solution_instruction_template.format(extraction=await extraction_task),
            context=self.problem_text
        )

        # Run extraction and solution tasks in parallel
        extraction, solution = await asyncio.gather(extraction_task, solution_task)

        # Step 3: Validate and refine the solution
        refine_instruction = """
        Carefully review the provided solution. Check for logical consistency, calculation accuracy, and adherence
        to the problem's context. If any issues are found, refine the solution accordingly. Ensure the final result
        makes sense in the real-world scenario described in the problem.
        """
        refined_solution = await self.revise(instruction=refine_instruction, context=solution)

        # Step 4: Extract the final numerical answer
        summarize_instruction = """
        From the refined solution, extract the final numerical answer. Ensure it is presented as a single value
        without any additional explanations or units.
        """
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_answer