# Workflow ID: gsm8k_48_0
# Benchmark: gsm8k
# Data Indices: [659, 724]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract known information (numerical values, relationships, constraints)
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, relationships, "
            "and constraints mentioned in the text. Organize the information clearly for further processing."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a step-by-step solution plan
        plan_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. Include intermediate calculations, "
            "hidden steps, and the sequence of operations required. Ensure the plan is logically consistent."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Perform calculations based on the solution plan
        calculation_instruction = (
            f"Follow this solution plan step-by-step:\n{solution_plan}\n"
            "Perform all necessary calculations, ensuring unit consistency and logical correctness. "
            "Provide intermediate results and the final answer in a clear format."
        )
        calculations = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Verify and refine results
        revision_instruction = (
            f"Review the following calculations and intermediate results:\n{calculations}\n"
            "Check for accuracy, logical consistency, and adherence to real-world constraints. "
            "Refine any incorrect or ambiguous steps, and ensure the final answer makes sense in the problem's context."
        )
        refined_results = await self.revise(instruction=revision_instruction, context=calculations)

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"From the refined results below:\n{refined_results}\n"
            "Extract and summarize the final numerical answer. Ensure it is presented in the required format."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_results)

        return final_answer