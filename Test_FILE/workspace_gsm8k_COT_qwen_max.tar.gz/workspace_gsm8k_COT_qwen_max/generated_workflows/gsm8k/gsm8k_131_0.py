# Workflow ID: gsm8k_131_0
# Benchmark: gsm8k
# Data Indices: [504, 366]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information (numerical values, relationships, constraints)
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, "
            "relationships, and constraints. Clearly label each piece of information "
            "and explain how they relate to the problem. Ensure no detail is missed."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Develop a step-by-step solution plan
        planning_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "create a detailed step-by-step plan to solve the problem. "
            "Include all necessary calculations, intermediate results, "
            "and unit conversions. Ensure the plan is logically structured."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Execute the solution plan
        execution_instruction = (
            f"Follow this solution plan: {solution_plan}. "
            "Perform all calculations step by step, showing intermediate results. "
            "Ensure the final answer is clearly stated and makes sense in the context of the problem."
        )
        computed_solution = await self.generate(instruction=execution_instruction, context=self.problem_text)

        # Step 4: Verify and refine the solution
        refinement_instruction = (
            f"Review the computed solution: {computed_solution}. "
            "Check for any errors, inconsistencies, or missing steps. "
            "Refine the solution if necessary to ensure accuracy and clarity."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=computed_solution)

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"Summarize the refined solution: {refined_solution}. "
            "Clearly state the final answer and include any relevant reasoning or intermediate steps."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer