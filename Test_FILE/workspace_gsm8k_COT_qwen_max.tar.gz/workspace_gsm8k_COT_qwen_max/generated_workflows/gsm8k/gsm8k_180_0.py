# Workflow ID: gsm8k_180_0
# Benchmark: gsm8k
# Data Indices: [297, 367]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information from the problem
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, units, "
            "relationships, and operations mentioned. Organize the information clearly, "
            "including any implicit steps or constraints."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate a step-by-step solution
        solution_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "solve the problem step by step. Clearly show all calculations, "
            "intermediate results, and reasoning. Ensure the solution adheres to "
            "mathematical rules and real-world constraints (e.g., no negative items)."
        )
        solution = await self.generate(instruction=solution_instruction, context=self.problem_text)

        # Step 3: Revise the solution for correctness and clarity
        revision_instruction = (
            "Critique the provided solution and refine it if necessary. Check for: "
            "- Correct order of operations\n- Consistent unit handling\n- Logical consistency\n"
            "- Missing or unnecessary steps\n- Real-world constraints (e.g., non-negative quantities)\n"
            "Provide the revised solution with explanations for any changes made."
        )
        refined_solution = await self.revise(instruction=revision_instruction, context=solution)

        # Step 4: Summarize to extract the final answer
        summary_instruction = (
            "From the refined solution, extract the final numerical answer. "
            "Ensure the answer is clear, concise, and includes appropriate units if applicable."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer