# Workflow ID: gsm8k_387_0
# Benchmark: gsm8k
# Data Indices: [660, 711]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio
        
        # Step 1: Extract known information
        extract_instruction = (
            "Identify all numerical values, relationships, and key entities in the problem. "
            "Include units (e.g., apples, dollars) and any constraints (e.g., non-negative numbers). "
            "Format the extracted information as a structured list."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)
        
        # Step 2: Formulate a solution plan
        plan_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Determine the sequence of operations required to solve the problem. "
            "Include intermediate steps, hidden calculations, and the final goal. "
            "Ensure the plan accounts for units and contextual constraints. "
            "Format the plan as a step-by-step guide."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)
        
        # Step 3: Execute calculations
        execute_instruction = (
            f"Follow this solution plan step by step:\n{solution_plan}\n"
            "Perform all calculations explicitly, tracking units and intermediate results. "
            "Ensure each step logically follows from the previous one. "
            "Provide the final result with appropriate units."
        )
        calculations = await self.generate(instruction=execute_instruction, context=self.problem_text)
        
        # Step 4: Validate the solution
        validate_instruction = (
            "Critique the following solution to ensure it makes sense in the context of the problem:\n"
            f"{calculations}\n"
            "Check for logical consistency, unit correctness, and adherence to constraints "
            "(e.g., no negative or fractional people). Refine the solution if necessary."
        )
        validated_solution = await self.revise(instruction=validate_instruction, context=calculations)
        
        # Step 5: Summarize the result
        summarize_instruction = (
            "Condense the following solution into a single numerical answer:\n"
            f"{validated_solution}\n"
            "Ensure the answer is precise and formatted correctly."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=validated_solution)
        
        return final_answer