# Workflow ID: gsm8k_330_0
# Benchmark: gsm8k
# Data Indices: [153, 674]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all numerical values, units, and relationships
        extraction_instruction = """
        Carefully analyze the problem and extract all numerical values, units, and relationships mentioned in the text. 
        Clearly list each piece of information and describe its role in the problem (e.g., known quantity, rate, target).
        Ensure no detail is missed and provide a structured summary.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Construct a step-by-step solution plan
        modeling_instruction = f"""
        Based on the following extracted information: {extracted_info}
        Create a detailed step-by-step plan to solve the problem. 
        Include all necessary calculations, intermediate steps, and logical reasoning.
        Ensure the plan accounts for the relationships between quantities and respects any constraints.
        """
        solution_plan = await self.generate(instruction=modeling_instruction, context=self.problem_text)

        # Step 3: Parallel execution of direct solution and verification
        direct_solution_instruction = f"""
        Using the following solution plan: {solution_plan}
        Solve the problem step by step, performing all calculations explicitly.
        Provide the final answer as a single numerical value, along with a brief explanation of how it was derived.
        """
        verification_instruction = f"""
        Independently verify the solution plan: {solution_plan}
        Cross-check each step for correctness, ensuring all calculations are accurate and logically consistent.
        Highlight any discrepancies or potential errors in the plan.
        """

        direct_result, verification_result = await asyncio.gather(
            self.generate(instruction=direct_solution_instruction, context=self.problem_text),
            self.generate(instruction=verification_instruction, context=self.problem_text)
        )

        # Step 4: Synthesize results using ensemble
        synthesis_instruction = """
        Compare the direct solution and the verification results.
        Resolve any discrepancies and select the most accurate and reliable answer.
        Ensure the final result is consistent with the problem's context and constraints.
        """
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=[direct_result, verification_result])

        # Step 5: Summarize the final answer
        summary_instruction = """
        Extract the final numerical answer from the provided result.
        Ensure the output is concise and formatted as a single numerical value.
        """
        final_summary = await self.summarize(instruction=summary_instruction, context=final_answer)

        return final_summary