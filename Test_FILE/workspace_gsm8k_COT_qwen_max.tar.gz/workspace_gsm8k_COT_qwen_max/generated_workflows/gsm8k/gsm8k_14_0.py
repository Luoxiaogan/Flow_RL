# Workflow ID: gsm8k_14_0
# Benchmark: gsm8k
# Data Indices: [620, 413]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract known information
        extract_instruction = (
            "Carefully analyze the problem and extract all numerical values, units, "
            "and relationships. Include any constraints or conditions mentioned in the problem. "
            "Format the extracted information as a bulleted list."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Identify the unknown
        unknown_instruction = (
            f"Based on the extracted information: {extracted_info}, "
            "clearly identify what the problem is asking for. "
            "State the unknown quantity and its relationship to the known values."
        )
        unknown = await self.generate(instruction=unknown_instruction, context=self.problem_text)

        # Step 3: Plan the solution
        plan_instruction = (
            f"Given the extracted information: {extracted_info}, and the unknown: {unknown}, "
            "create a step-by-step plan to solve the problem. "
            "Include all necessary calculations, intermediate steps, and unit conversions. "
            "Ensure the plan is logically consistent and accounts for all constraints."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 4: Perform calculations
        calc_instruction = (
            f"Follow this plan: {solution_plan} to perform the calculations step by step. "
            "Clearly show each intermediate result and ensure units are handled correctly."
        )
        calculations = await self.generate(instruction=calc_instruction, context=self.problem_text)

        # Step 5: Validate and refine the result
        validate_instruction = (
            f"Review the calculations: {calculations} and ensure the result is reasonable "
            "given the problem context. Check for unit consistency, logical errors, and realism. "
            "If necessary, refine the result to correct any issues."
        )
        refined_result = await self.revise(instruction=validate_instruction, context=calculations)

        # Step 6: Summarize the answer
        summarize_instruction = (
            f"Summarize the final result: {refined_result} into a concise answer that directly "
            "addresses the problem question. Ensure the answer is clear, precise, and includes units if applicable."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_result)

        return final_answer