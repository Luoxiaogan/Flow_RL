# Workflow ID: gsm8k_194_0
# Benchmark: gsm8k
# Data Indices: [385, 735]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information
        extraction_instruction = """
        Extract all numerical values, their associated units, and any relationships or operations described in the problem. 
        Include percentages, fractions, rates, and any other relevant quantitative information. 
        Ensure the extracted information is complete and accurate for subsequent calculations.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Create a step-by-step plan
        plan_instruction = f"""
        Based on the following extracted information: {extracted_info}
        Create a detailed step-by-step plan to solve the problem. 
        Include all necessary calculations, intermediate steps, and ensure the order of operations is correct. 
        Identify any hidden steps or assumptions required to compute the final answer.
        """
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute the plan and compute the final answer
        execution_instruction = f"""
        Follow this plan step-by-step: {solution_plan}
        Perform all calculations accurately, respecting the order of operations and unit consistency. 
        Verify that the final result adheres to real-world constraints (e.g., no negative quantities, fractional people). 
        Provide the final numerical answer along with its unit, if applicable.
        """
        computed_result = await self.generate(instruction=execution_instruction, context=self.problem_text)

        # Step 4: Validate the solution
        validation_instruction = f"""
        Critique the following computed result: {computed_result}
        Ensure the answer makes sense in the context of the problem. 
        Check for logical consistency, unit correctness, and reasonableness of the result. 
        If there are any issues, revise the solution accordingly.
        """
        validated_result = await self.revise(instruction=validation_instruction, context=computed_result)

        # Step 5: Summarize the final answer
        summary_instruction = """
        Condense the following result into a single numerical value. 
        Ensure the output is concise and formatted correctly as the final answer.
        """
        final_answer = await self.summarize(instruction=summary_instruction, context=validated_result)

        return final_answer