# Workflow ID: gsm8k_263_0
# Benchmark: gsm8k
# Data Indices: [73, 441]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract numerical values, relationships, and units
        extraction_instruction = (
            "Extract all numerical values, relationships, and units from the problem. "
            "Identify what is being asked and list the key components needed to solve the problem. "
            "Ensure the extraction is complete and precise."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate a step-by-step solution plan
        plan_instruction = (
            f"Based on the extracted information: {extracted_info}, "
            "create a detailed step-by-step plan to solve the problem. "
            "Include all intermediate calculations, unit conversions, and logical reasoning steps. "
            "Ensure the plan is sequential and accounts for all constraints."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Compute the solution using two independent approaches
        direct_calculation_instruction = (
            f"Follow this solution plan: {solution_plan}. "
            "Perform the calculations step by step and provide the final numerical answer. "
            "Ensure all units are consistent and the result makes sense in the context of the problem."
        )
        verification_path_instruction = (
            f"Verify the solution by using an alternative reasoning strategy. "
            "For example, reverse-engineer the problem or cross-check constraints. "
            "Provide the final numerical answer and justify its correctness."
        )
        direct_result, verification_result = await asyncio.gather(
            self.generate(instruction=direct_calculation_instruction, context=self.problem_text),
            self.generate(instruction=verification_path_instruction, context=self.problem_text)
        )

        # Step 4: Ensemble decision-making
        ensemble_instruction = (
            "Compare the two solutions provided. "
            "Select the most accurate and consistent result. "
            "If there are discrepancies, resolve them by analyzing the reasoning behind each approach."
        )
        final_result = await self.ensemble(instruction=ensemble_instruction, contexts=[direct_result, verification_result])

        # Step 5: Refine the final result
        refine_instruction = (
            f"Refine the following result: {final_result}. "
            "Ensure it is properly formatted, includes units if applicable, and adheres to the problem's context. "
            "Double-check for any logical inconsistencies or calculation errors."
        )
        refined_result = await self.revise(instruction=refine_instruction, context=final_result)

        return refined_result