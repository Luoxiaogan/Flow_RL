# Workflow ID: gsm8k_299_0
# Benchmark: gsm8k
# Data Indices: [40, 726]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract known information and relationships
        extraction_instruction = (
            "Identify all numerical values, units, and relationships in the problem. "
            "Include explicit constraints and implicit assumptions. "
            "Format the output as a structured list for clarity."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan the solution approach
        plan_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. "
            "Include intermediate calculations, hidden steps, and ensure proper sequencing of operations. "
            "Highlight any assumptions or constraints that need to be considered."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute the plan
        execution_instruction_template = (
            "Follow this step from the solution plan:\n{step}\n"
            "Perform the required calculation or reasoning. "
            "Ensure all units are consistent and include intermediate results for verification."
        )
        # Split the solution plan into individual steps
        steps = solution_plan.split("\n")
        execution_tasks = [
            self.generate(instruction=execution_instruction_template.format(step=step), context=self.problem_text)
            for step in steps if step.strip()
        ]
        execution_results = await asyncio.gather(*execution_tasks)

        # Step 4: Verify and refine the solution
        refinement_instruction = (
            "Critique the following solution steps:\n{results}\n"
            "Ensure they adhere to the problem's constraints and make sense in the real-world context. "
            "Refine any steps that are ambiguous, incomplete, or incorrect."
        )
        refined_solution = await self.revise(
            instruction=refinement_instruction.format(results="\n".join(execution_results)),
            context=self.problem_text
        )

        # Step 5: Summarize the final answer
        summary_instruction = (
            "Condense the following refined solution into a single numerical value. "
            "Ensure the answer is clear, correct, and formatted appropriately.\n"
            "{solution}"
        )
        final_answer = await self.summarize(
            instruction=summary_instruction.format(solution=refined_solution),
            context=self.problem_text
        )

        return final_answer