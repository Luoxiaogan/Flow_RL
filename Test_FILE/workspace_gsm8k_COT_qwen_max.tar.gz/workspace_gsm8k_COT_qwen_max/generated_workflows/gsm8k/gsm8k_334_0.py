# Workflow ID: gsm8k_334_0
# Benchmark: gsm8k
# Data Indices: [101, 483]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (numerical values, relationships, constraints)
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, units, relationships, "
            "and constraints. Clearly label each piece of information and explain its relevance to the problem."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a step-by-step solution plan
        plan_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. Include all necessary calculations, "
            "intermediate steps, and considerations for unit consistency and contextual constraints."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute calculations
        calculation_instruction = (
            f"Follow this solution plan:\n{solution_plan}\n"
            "Perform all calculations step by step, showing intermediate results. Ensure all units are consistent "
            "and all contextual constraints are respected. Provide the final numerical answer at the end."
        )
        calculations = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Review and refine the solution
        revise_instruction = (
            f"Review the following solution:\n{calculations}\n"
            "Check for errors in logic, arithmetic, or unit handling. Suggest corrections if needed and ensure "
            "the solution is mathematically sound and contextually valid."
        )
        refined_solution = await self.revise(instruction=revise_instruction, context=calculations)

        # Step 5: Summarize the final answer
        summarize_instruction = (
            f"From the following solution:\n{refined_solution}\n"
            "Extract and present only the final numerical answer. Ensure the output is a single number, "
            "either an integer or a decimal, without any additional text."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_answer