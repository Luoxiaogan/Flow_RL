# Workflow ID: gsm8k_73_0
# Benchmark: gsm8k
# Data Indices: [400, 473]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all numerical values, relationships, and constraints from the problem. "
            "Include units, implicit relationships (e.g., 'twice as many'), and any hidden steps. "
            "Format the output as a structured list."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Model the problem mathematically
        modeling_instruction = (
            f"Given the extracted information: {extracted_info}\n"
            "Construct a step-by-step mathematical plan to solve the problem. "
            "Identify the sequence of operations (e.g., addition, multiplication, unit conversion). "
            "Ensure the plan accounts for all constraints and relationships."
        )
        solution_plan = await self.generate(instruction=modeling_instruction, context=self.problem_text)

        # Step 3: Generate parallel solution approaches
        approach_1_instruction = (
            f"Using the solution plan: {solution_plan}\n"
            "Solve the problem step by step using sequential arithmetic operations. "
            "Show all intermediate results and verify their correctness."
        )
        approach_2_instruction = (
            f"Using the solution plan: {solution_plan}\n"
            "Solve the problem algebraically, introducing variables if necessary. "
            "Simplify the solution and verify its correctness."
        )
        approach_1, approach_2 = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text)
        )

        # Step 4: Ensemble decision-making
        ensemble_instruction = (
            "Compare the following two solutions and select the most accurate and contextually appropriate one. "
            "If both are valid, choose the simpler solution. "
            "Provide the final answer as a single numerical value."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[approach_1, approach_2])

        # Step 5: Verify and summarize the final answer
        verification_instruction = (
            f"Verify that the final answer: {final_answer} satisfies the problem's constraints. "
            "Ensure the units and decimal places are correct. Summarize the solution concisely."
        )
        verified_solution = await self.summarize(instruction=verification_instruction, context=self.problem_text)

        return verified_solution