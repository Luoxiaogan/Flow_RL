# Workflow ID: gsm8k_240_0
# Benchmark: gsm8k
# Data Indices: [169, 756]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract known values and relationships
        extraction_instruction = """
        Carefully read the problem and extract all numerical values along with their units and relationships.
        Identify what is being asked and list any constraints or conditions provided.
        Ensure you capture all relevant details needed to solve the problem.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a step-by-step solution plan
        plan_instruction = f"""
        Based on the following extracted information: {extracted_info}
        Create a detailed step-by-step plan to solve the problem. Include all necessary calculations,
        logical deductions, and intermediate steps required to reach the final answer.
        Ensure the plan is clear and systematic.
        """
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute the solution plan
        execution_instruction = f"""
        Follow the solution plan step by step:
        {solution_plan}
        Perform each calculation or deduction carefully, documenting intermediate results.
        Ensure all steps are executed in the correct order and verify unit consistency throughout.
        """
        executed_solution = await self.generate(instruction=execution_instruction, context=self.problem_text)

        # Step 4: Revise and validate the solution
        revision_instruction = """
        Critically review the executed solution for any errors or inconsistencies.
        Verify that all calculations are correct and that the final answer makes sense in the context of the problem.
        Provide corrections or improvements if necessary.
        """
        revised_solution = await self.revise(instruction=revision_instruction, context=executed_solution)

        # Step 5: Summarize the final answer
        summary_instruction = """
        Condense the final result to present the single numerical value as the answer.
        Ensure the summary is clear and concise.
        """
        final_answer = await self.summarize(instruction=summary_instruction, context=revised_solution)

        return final_answer