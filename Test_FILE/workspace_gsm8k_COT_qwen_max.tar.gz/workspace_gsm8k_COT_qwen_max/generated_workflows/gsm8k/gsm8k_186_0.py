# Workflow ID: gsm8k_186_0
# Benchmark: gsm8k
# Data Indices: [110, 474]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract known values, units, and relationships
        extraction_instruction = (
            "Extract all numerical values, units, and relationships (e.g., 'half as many,' '3 times as much') "
            "from the problem. Organize them into categories such as 'known values,' 'relationships,' "
            "and 'units.' Ensure the extraction is complete and accurate."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a step-by-step solution plan
        planning_instruction = (
            f"Given the extracted information: {extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. Include:\n"
            "- Intermediate calculations\n"
            "- Order of operations\n"
            "- Handling of units and conversions\n"
            "- Any hidden steps inferred from the problem context\n"
            "Ensure the plan is logical, sequential, and accounts for all constraints."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Execute calculations
        calculation_instruction = (
            f"Follow this solution plan: {solution_plan}\n"
            "Perform all calculations step by step. Track intermediate results and ensure unit consistency. "
            "Handle fractions, decimals, and percentages correctly. Provide the final result."
        )
        calculations = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Verify and refine results
        refinement_instruction = (
            f"Review the calculations: {calculations}\n"
            "Critique the results for accuracy and contextual relevance. Check for:\n"
            "- Consistency with the problem's constraints\n"
            "- Proper handling of units\n"
            "- Real-world feasibility (e.g., no negative quantities)\n"
            "Refine the results if necessary."
        )
        refined_results = await self.revise(instruction=refinement_instruction, context=calculations)

        # Step 5: Summarize the final answer
        summarization_instruction = (
            f"Condense the refined results: {refined_results}\n"
            "Extract the final numerical answer. Ensure it is clear, concise, and directly answers the question."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_results)

        return final_answer