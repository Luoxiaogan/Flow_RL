# Workflow ID: gsm8k_235_0
# Benchmark: gsm8k
# Data Indices: [155, 426]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant numerical values and relationships
        extraction_instruction = (
            "Thoroughly analyze the problem statement to identify and extract all numerical values "
            "and their relationships. Include units, entities, and any contextual information that "
            "defines how these numbers interact."
        )
        extracted_values = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a solution strategy
        strategy_instruction = (
            f"Based on the following extracted information: {extracted_values}\n"
            "Determine the sequence of operations required to solve the problem. Identify the type of problem "
            "(e.g., sequential operations, rate problems, proportional reasoning) and specify the arithmetic "
            "operations needed. Ensure the plan accounts for unit consistency and real-world constraints."
        )
        solution_strategy = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Perform calculations
        calculation_instruction = (
            f"Using the extracted values: {extracted_values}\n"
            f"And the solution strategy: {solution_strategy}\n"
            "Execute the necessary calculations step by step. Provide intermediate results and ensure each "
            "step logically follows from the previous one. Maintain clarity about units and decimal places."
        )
        calculations = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Verify intermediate results and finalize the answer
        verification_instruction = (
            f"Review the calculations: {calculations}\n"
            "Verify that each intermediate result makes sense in the context of the problem. Check for "
            "arithmetic accuracy, unit consistency, and adherence to real-world constraints. Identify any "
            "errors or inconsistencies and suggest corrections if needed."
        )
        verified_results = await self.revise(instruction=verification_instruction, context=calculations)

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"Summarize the verified results: {verified_results}\n"
            "Provide the final answer as a single numerical value, ensuring it is clearly stated and "
            "contextually appropriate. Include units if applicable."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=verified_results)

        return final_answer