# Workflow ID: gsm8k_196_0
# Benchmark: gsm8k
# Data Indices: [457, 562]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information from the problem text
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, units, "
            "relationships, and constraints. Clearly label each piece of information "
            "and explain its relevance to the problem."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Construct a step-by-step solution plan
        solution_plan_instruction = (
            f"Using the following extracted information: {extracted_info}\n"
            "Develop a detailed step-by-step plan to solve the problem. "
            "Include all necessary calculations, intermediate results, and reasoning steps. "
            "Ensure the plan is logically consistent and accounts for all constraints."
        )
        solution_plan = await self.generate(instruction=solution_plan_instruction, context=self.problem_text)

        # Step 3: Explore multiple solution approaches in parallel
        approach_1_instruction = (
            f"Follow this solution plan strictly: {solution_plan}\n"
            "Perform all calculations step by step and document each step clearly."
        )
        approach_2_instruction = (
            f"Reinterpret the problem based on the extracted information: {extracted_info}\n"
            "Develop an alternative solution approach that differs from the original plan. "
            "Perform all calculations step by step and document each step clearly."
        )
        results = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text)
        )

        # Step 4: Evaluate and select the best solution
        evaluation_instruction = (
            "Compare the following solutions and select the best one:\n"
            f"Solution 1: {results[0]}\n"
            f"Solution 2: {results[1]}\n"
            "The best solution should be logically consistent, mathematically accurate, "
            "and adhere to all constraints in the problem. Provide a justification for your choice."
        )
        best_solution = await self.ensemble(instruction=evaluation_instruction, contexts=results)

        # Step 5: Refine the selected solution
        refinement_instruction = (
            f"Review and refine the following solution: {best_solution}\n"
            "Ensure all calculations are correct, intermediate steps are clearly documented, "
            "and the final answer is properly formatted. Verify that the solution makes sense in context."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 6: Summarize the final answer
        summary_instruction = (
            f"Extract the final numerical answer from the following solution: {refined_solution}\n"
            "Ensure the answer is clearly stated and includes appropriate units if applicable."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer