# Workflow ID: gsm8k_221_0
# Benchmark: gsm8k
# Data Indices: [262, 384]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract numerical values, relationships, and entities
        extraction_instruction = (
            "Extract all numerical values, relationships, and entities from the problem. "
            "Provide them in a structured format, including units if applicable. "
            "Ensure clarity and completeness for subsequent calculations."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan the step-by-step solution
        planning_instruction = (
            f"Based on the extracted information: {extracted_info}, "
            "create a detailed step-by-step plan to solve the problem. "
            "Include all necessary calculations, their order, and any intermediate results. "
            "Ensure the plan is logical and accounts for all given information."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Execute solution steps in parallel
        # Example: Calculate intermediate results like "twice as many pants as shirts"
        intermediate_calculations = []
        calculation_instructions = [
            "Calculate the number of pants based on the relationship 'twice as many pants as shirts'.",
            "Calculate the number of shorts based on the relationship 'half as many shorts as pants'.",
            "Sum all pieces of clothing to determine the total."
        ]
        for i, calc_instruction in enumerate(calculation_instructions):
            intermediate_calculations.append(
                self.generate(
                    instruction=f"{calc_instruction} Ensure the calculation is accurate and includes units if applicable.",
                    context=solution_plan
                )
            )
        intermediate_results = await asyncio.gather(*intermediate_calculations)

        # Step 4: Validate and refine intermediate results
        refinement_instructions = [
            "Validate the calculation of pants. Ensure it aligns with the problem statement and correct any errors.",
            "Validate the calculation of shorts. Ensure it aligns with the problem statement and correct any errors.",
            "Validate the total sum of clothing. Ensure it aligns with the problem statement and correct any errors."
        ]
        refined_results = []
        for i, refine_instruction in enumerate(refinement_instructions):
            refined_results.append(
                self.revise(
                    instruction=refine_instruction,
                    context=intermediate_results[i]
                )
            )
        validated_results = await asyncio.gather(*refined_results)

        # Step 5: Combine refined results into the final answer
        final_answer_instruction = (
            f"Combine the following validated results: {validated_results} "
            "into the final numerical answer. Ensure the answer is a single value, "
            "includes appropriate units if necessary, and makes sense in the context of the problem."
        )
        final_answer = await self.generate(instruction=final_answer_instruction, context=self.problem_text)

        return final_answer