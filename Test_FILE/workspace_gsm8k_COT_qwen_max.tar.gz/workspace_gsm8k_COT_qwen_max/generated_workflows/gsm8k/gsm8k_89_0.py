# Workflow ID: gsm8k_89_0
# Benchmark: gsm8k
# Data Indices: [421, 451]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract known information
        extract_instruction = (
            "Carefully analyze the problem and extract all numerical values, units, "
            "and relationships. Identify any implicit information or intermediate steps "
            "that might be required for solving the problem."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Formulate a solution plan
        plan_instruction = (
            f"Based on the following extracted information: {extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. Include the sequence "
            "of mathematical operations, any necessary unit conversions, and intermediate "
            "calculations. Ensure the plan is clear and logical."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute calculations (parallelizable if multiple approaches exist)
        calculate_instruction = (
            f"Follow this solution plan: {solution_plan}\n"
            "Perform the calculations step by step, showing all intermediate results. "
            "Ensure the final result is clearly stated and makes sense in the context of the problem."
        )
        calculations = await self.generate(instruction=calculate_instruction, context=self.problem_text)

        # Step 4: Verify and refine the solution
        revise_instruction = (
            f"Review the following solution: {calculations}\n"
            "Check for errors, inconsistencies, or violations of real-world constraints. "
            "Refine the solution if necessary, ensuring it is accurate and complete."
        )
        refined_solution = await self.revise(instruction=revise_instruction, context=calculations)

        # Step 5: Summarize the final answer
        summarize_instruction = (
            f"Condense the following solution into a concise final answer: {refined_solution}\n"
            "Ensure the answer is a single numerical value (integer or decimal) and matches "
            "the expected format."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_answer