# Workflow ID: gsm8k_59_0
# Benchmark: gsm8k
# Data Indices: [521, 701]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract numerical values, relationships, and the target unknown
        extraction_instruction = """
        Carefully analyze the problem and extract all numerical values, relationships, and units. 
        Identify what the question is asking for (the target unknown). 
        If there are any implicit steps or hidden calculations, note them explicitly.
        """
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate a detailed solution plan
        plan_instruction = f"""
        Based on the extracted information: {extraction}
        Create a detailed step-by-step plan to calculate the target unknown. 
        Include all intermediate steps, specify the order of operations, and handle unit consistency. 
        If there are multiple ways to interpret the problem, generate separate plans for each interpretation.
        """
        initial_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Revise the plan for accuracy and completeness
        revise_instruction = """
        Review the solution plan for accuracy and completeness. 
        Ensure all steps are logically sound, intermediate calculations are included, and the plan addresses any potential ambiguities.
        """
        revised_plan = await self.revise(instruction=revise_instruction, context=initial_plan)

        # Step 4: Execute the plan with step-by-step calculations
        execute_instruction = f"""
        Follow the revised plan: {revised_plan}
        Perform the calculations step-by-step, showing all intermediate results. 
        Verify each step to ensure correctness and consistency with the problem context.
        """
        calculations = await self.generate(instruction=execute_instruction, context=self.problem_text)

        # Step 5: Ensemble multiple results if needed
        ensemble_instruction = """
        Compare the results of different interpretations or calculation paths. 
        Select the most reasonable and consistent result based on the problem context.
        """
        final_result = await self.ensemble(instruction=ensemble_instruction, contexts=[calculations])

        # Step 6: Summarize the final answer
        summarize_instruction = """
        Condense the final result into a single numerical value. 
        Ensure the answer is reasonable and matches the problem's requirements.
        """
        answer = await self.summarize(instruction=summarize_instruction, context=final_result)

        return answer