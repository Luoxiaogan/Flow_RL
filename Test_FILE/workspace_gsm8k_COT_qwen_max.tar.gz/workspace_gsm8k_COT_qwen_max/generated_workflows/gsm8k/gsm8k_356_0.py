# Workflow ID: gsm8k_356_0
# Benchmark: gsm8k
# Data Indices: [115, 684]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Thoroughly analyze the problem and extract all numerical values, units, relationships, "
            "and constraints. Identify any sequential operations, rates, proportions, or conditions. "
            "Provide the extracted information in a structured format, clearly labeled for reference."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan the solution steps
        planning_instruction = (
            f"Based on the following extracted information: {extracted_info}\n"
            "Outline a step-by-step plan to solve the problem. Include all intermediate calculations, "
            "hidden steps, and reasoning. Ensure the plan accounts for unit consistency, real-world constraints, "
            "and the order of operations. Format the plan as a numbered list for clarity."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Execute calculations step by step
        calculation_instruction = (
            f"Follow this solution plan: {solution_plan}\n"
            "Perform the calculations step by step, ensuring accuracy at each stage. Dynamically incorporate "
            "previously computed results into subsequent steps. Provide the final numerical answer explicitly."
        )
        final_answer = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Validate and refine the result
        validation_instruction = (
            f"Review the following solution: {final_answer}\n"
            "Critique the result for accuracy, logical consistency, and adherence to the problem context. "
            "Ensure the answer makes sense (e.g., non-negative quantities, reasonable magnitudes). "
            "Refine the result if necessary and provide the corrected answer."
        )
        refined_answer = await self.revise(instruction=validation_instruction, context=final_answer)

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"Condense the following solution: {refined_answer}\n"
            "Highlight the final numerical answer clearly. Ensure the summary is concise and directly addresses "
            "the problem's question."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_answer)

        return final_summary