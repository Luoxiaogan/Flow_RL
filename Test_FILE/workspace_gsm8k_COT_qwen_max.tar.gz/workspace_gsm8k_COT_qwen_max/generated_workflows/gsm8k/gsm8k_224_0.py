# Workflow ID: gsm8k_224_0
# Benchmark: gsm8k
# Data Indices: [690, 570]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information from the problem
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, relationships, "
            "and constraints. Identify what is being asked and list all known quantities and unknowns. "
            "Ensure that units and contextual details are preserved."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate a step-by-step solution
        solution_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem step by step. "
            "Perform calculations sequentially, keeping track of intermediate results. "
            "Ensure that all steps are logically consistent and clearly explained. "
            "Verify that the solution aligns with the problem's requirements."
        )
        solution = await self.generate(instruction=solution_instruction, context=self.problem_text)

        # Step 3: Revise and refine the solution
        revision_instruction = (
            "Review the provided solution carefully. Check for calculation errors, logical inconsistencies, "
            "or missing steps. Suggest improvements if necessary and ensure the solution is complete and accurate."
        )
        refined_solution = await self.revise(instruction=revision_instruction, context=solution)

        # Step 4: Extract the final answer
        summary_instruction = (
            "From the refined solution, extract the final numerical answer. Ensure that it is clearly stated "
            "and makes sense in the context of the problem. Include units if applicable."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer