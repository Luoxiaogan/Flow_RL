# Workflow ID: gsm8k_22_0
# Benchmark: gsm8k
# Data Indices: [388, 477]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract numerical values, relationships, and constraints
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, "
            "relationships, and constraints. Identify what is given and what is being asked. "
            "Format the output as a structured summary."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Translate the problem into a mathematical model
        modeling_instruction = (
            f"Using the following extracted information: {extracted_info}\n"
            "Translate the problem into a mathematical model. Define all variables, "
            "set up equations if necessary, and outline the steps needed to solve the problem. "
            "Ensure the model accounts for all constraints and relationships."
        )
        mathematical_model = await self.generate(instruction=modeling_instruction, context=self.problem_text)

        # Step 3: Solve the problem step by step
        solution_instruction = (
            f"Given the mathematical model: {mathematical_model}\n"
            "Solve the problem step by step. Perform all necessary calculations, "
            "including arithmetic operations, unit conversions, or equation solving. "
            "Clearly show intermediate results and ensure they are consistent with the problem context."
        )
        step_by_step_solution = await self.generate(instruction=solution_instruction, context=self.problem_text)

        # Step 4: Validate intermediate results
        validation_instruction = (
            f"Review the following solution steps: {step_by_step_solution}\n"
            "Check for calculation errors, logical inconsistencies, or violations of problem constraints. "
            "Revise the solution if necessary to ensure correctness."
        )
        validated_solution = await self.revise(instruction=validation_instruction, context=step_by_step_solution)

        # Step 5: Extract the final answer
        final_answer_instruction = (
            f"From the validated solution: {validated_solution}\n"
            "Extract the final numerical answer. Ensure it is presented as a single value "
            "(integer or decimal) without any additional text."
        )
        final_answer = await self.summarize(instruction=final_answer_instruction, context=validated_solution)

        return final_answer