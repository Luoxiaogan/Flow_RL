# Workflow ID: gsm8k_42_0
# Benchmark: gsm8k
# Data Indices: [173, 479]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (numerical values, units, relationships)
        extraction_instruction = (
            "Extract all numerical values, units, and relationships from the problem. "
            "For example, identify quantities like '3 $50 bills' or '2 pounds of hamburger meat'. "
            "Also note any constraints or conditions, such as discounts or time-based events. "
            "Organize the extracted information in a structured format for clarity."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a step-by-step solution plan
        plan_instruction = (
            f"Based on the following extracted information: {extracted_info}\n"
            "Formulate a detailed step-by-step plan to solve the problem. "
            "Include all necessary calculations, conversions, and logical reasoning. "
            "Ensure the plan accounts for any hidden steps or implicit operations. "
            "The output should be a clear sequence of actions leading to the final answer."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute calculations in parallel
        # Dynamically construct instructions for each calculation based on the solution plan
        calculation_instructions = []
        for step in solution_plan.split("\n"):
            if "calculate" in step.lower() or "compute" in step.lower():
                calculation_instructions.append(
                    f"Perform the following calculation: {step}. "
                    "Ensure the result is accurate and includes appropriate units."
                )

        # Execute calculations in parallel
        calculation_results = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in calculation_instructions]
        )

        # Step 4: Synthesize results using Ensemble
        synthesis_instruction = (
            "Evaluate the following intermediate results and synthesize them into a final answer. "
            "Ensure the answer is consistent with the problem's context and constraints. "
            "If there are conflicting results, resolve them logically."
        )
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=calculation_results)

        # Step 5: Verify and refine the solution
        refinement_instruction = (
            f"Review the following solution: {final_answer}\n"
            "Check for accuracy, consistency, and completeness. "
            "Refine the solution if necessary, ensuring it aligns with the problem's requirements."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=final_answer)

        return refined_solution