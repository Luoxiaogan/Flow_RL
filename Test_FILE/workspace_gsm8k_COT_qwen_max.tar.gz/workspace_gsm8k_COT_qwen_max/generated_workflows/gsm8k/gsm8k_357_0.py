# Workflow ID: gsm8k_357_0
# Benchmark: gsm8k
# Data Indices: [600, 95]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all numerical values, relationships, and constraints
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, variables, "
            "relationships, and constraints. Include units where applicable and organize "
            "the information in a structured format."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a step-by-step solution strategy
        strategy_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. Identify intermediate "
            "calculations, the order of operations, and any hidden steps. Ensure the plan is "
            "mathematically sound and aligns with the problem's context."
        )
        solution_strategy = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Generate multiple solution approaches in parallel
        approach_1_instruction = (
            f"Follow this solution strategy:\n{solution_strategy}\n"
            "Perform the calculations step by step and arrive at the final answer. Show all "
            "intermediate results and ensure the solution is consistent with the problem's context."
        )
        approach_2_instruction = (
            f"Using the extracted information:\n{extracted_info}\n"
            "Solve the problem independently without strictly following the provided strategy. "
            "Use alternative methods or reasoning paths to verify the solution."
        )
        results = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text)
        )

        # Step 4: Ensemble decision-making to select the best solution
        ensemble_instruction = (
            "Evaluate the following candidate solutions and select the most accurate one. "
            "Compare their intermediate steps, final answers, and consistency with the problem's "
            "context. If discrepancies exist, resolve them and provide the corrected solution."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 5: Refine and verify the final answer
        refinement_instruction = (
            "Review the following solution and ensure it is correct, properly formatted, and "
            "makes sense in the context of the problem. Correct any errors, clarify ambiguities, "
            "and present the final answer as a single numerical value."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_solution)

        return refined_answer