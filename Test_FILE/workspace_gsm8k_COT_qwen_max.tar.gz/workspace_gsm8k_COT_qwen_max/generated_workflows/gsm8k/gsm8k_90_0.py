# Workflow ID: gsm8k_90_0
# Benchmark: gsm8k
# Data Indices: [637, 497]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all numerical values, relationships, and constraints from the problem. "
            "Identify known quantities, unknowns, and any implicit assumptions. "
            "Format the output as a structured list of key-value pairs."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a detailed solution strategy
        strategy_instruction = (
            f"Based on the extracted information: {extracted_info}, "
            "create a step-by-step plan to solve the problem. "
            "Include intermediate calculations, order of operations, and unit consistency checks. "
            "Ensure the plan is chronological and accounts for all constraints."
        )
        solution_strategy = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Execute intermediate steps in parallel
        intermediate_steps = [
            "Calculate the total quantity or rate based on the given relationships.",
            "Determine any proportional adjustments or conversions needed.",
            "Compute intermediate totals or differences as outlined in the solution strategy."
        ]
        tasks = [
            self.generate(instruction=f"{step} Use the following context: {solution_strategy}", context=self.problem_text)
            for step in intermediate_steps
        ]
        intermediate_results = await asyncio.gather(*tasks)

        # Step 4: Synthesize results into a final solution
        synthesis_instruction = (
            "Combine the intermediate results to compute the final answer. "
            "Ensure all calculations are consistent and resolve any conflicts. "
            "Validate the result against the problem's constraints."
        )
        final_solution = await self.ensemble(instruction=synthesis_instruction, contexts=intermediate_results)

        # Step 5: Validate and refine the final result
        refinement_instruction = (
            "Critique the final solution for accuracy and alignment with the problem's context. "
            "Check for unit consistency, realistic values, and adherence to constraints. "
            "Refine the result if necessary."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=final_solution)

        # Step 6: Summarize the final numerical result
        summary_instruction = (
            "Condense the final solution into a single numerical value. "
            "Ensure the output is precise and formatted appropriately."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer