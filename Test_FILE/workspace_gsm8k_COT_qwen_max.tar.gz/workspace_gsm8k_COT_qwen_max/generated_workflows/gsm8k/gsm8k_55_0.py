# Workflow ID: gsm8k_55_0
# Benchmark: gsm8k
# Data Indices: [46, 109]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract known information
        extraction_instruction = (
            "Extract all numerical values, relationships, and constraints from the problem. "
            "Identify units, time-based sequences, and relationships such as 'more than,' 'less than,' or 'twice as many.' "
            "Format the output as a structured list of key-value pairs."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a solution plan
        plan_instruction = (
            f"Given the extracted information: {extracted_info}\n"
            "Create a step-by-step plan to solve the problem. "
            "Include intermediate calculations, ensure hidden steps are uncovered, and specify the order of operations. "
            "Format the plan as a numbered list of actions."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Perform calculations
        calculation_instruction = (
            f"Given the solution plan: {solution_plan}\n"
            "Execute the plan step by step, performing all necessary calculations. "
            "Track units consistently and verify intermediate results at each step. "
            "Provide the final answer along with a brief explanation of how it was derived."
        )
        calculated_solution = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Revise and validate the solution
        revision_instruction = (
            f"Review the calculated solution: {calculated_solution}\n"
            "Critique the solution for correctness and contextual validity. "
            "Ensure the answer makes sense in the context of the problem and adheres to real-world constraints. "
            "If errors are found, suggest corrections."
        )
        revised_solution = await self.revise(instruction=revision_instruction, context=calculated_solution)

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"Condense the revised solution: {revised_solution}\n"
            "Extract the final numerical answer, ensuring clarity and precision. "
            "Format the output as a single number without additional text."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=revised_solution)

        return final_answer