# Workflow ID: gsm8k_46_0
# Benchmark: gsm8k
# Data Indices: [525, 741]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant numerical values and relationships
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, units, and relationships. "
            "Include any implicit information such as rates, totals, or constraints. "
            "Format the output as a structured list of key-value pairs."
        )
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate a detailed reasoning plan
        reasoning_instruction = (
            f"Based on the extracted information: {extraction}, "
            "create a detailed step-by-step reasoning plan to solve the problem. "
            "Explicitly state the sequence of calculations required, including intermediate steps. "
            "Ensure the plan accounts for unit consistency and real-world constraints."
        )
        reasoning_plan = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Compute the solution using two parallel approaches
        approach_1_instruction = (
            f"Follow this reasoning plan: {reasoning_plan}. "
            "Perform the calculations step by step, showing all intermediate results. "
            "Ensure the final answer is clearly stated and makes sense in the context of the problem."
        )
        approach_2_instruction = (
            f"Using the extracted information: {extraction}, solve the problem independently. "
            "Double-check the calculations and ensure the solution aligns with the problem's requirements."
        )

        # Execute both approaches in parallel
        results = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text)
        )

        # Step 4: Ensemble decision-making to select the best solution
        ensemble_instruction = (
            "Compare the two solutions provided. "
            "Evaluate their logical consistency, adherence to the problem's constraints, and correctness. "
            "Select the best solution and provide a justification for your choice."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 5: Refine the final solution
        refinement_instruction = (
            "Critique and refine the selected solution. "
            "Ensure it is formatted correctly, adheres to the problem's constraints, and is free of errors. "
            "Provide the final answer as a single numerical value."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=final_solution)

        return refined_solution