# Workflow ID: gsm8k_284_0
# Benchmark: gsm8k
# Data Indices: [338, 604]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all numerical values, units, and relationships from the problem. "
            "Identify the question being asked and any constraints or conditions. "
            "Format the output as a structured list of key-value pairs."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan the sequence of calculations
        reasoning_instruction = (
            f"Based on the following extracted information: {extracted_info}\n"
            "Plan the sequence of calculations required to solve the problem. "
            "Include intermediate steps, ensure unit consistency, and account for real-world constraints. "
            "Format the output as a numbered list of steps."
        )
        reasoning_plan = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Perform calculations (parallel if applicable)
        # Split reasoning_plan into independent subproblems if necessary
        # For simplicity, assume all steps are sequential here
        calculation_instruction = (
            f"Follow this reasoning plan step by step: {reasoning_plan}\n"
            "Perform the calculations and provide intermediate results. "
            "Ensure each step builds on the previous one."
        )
        intermediate_results = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Verify the solution
        verification_instruction = (
            f"Verify the following solution: {intermediate_results}\n"
            "Check for consistency with the problem statement, unit correctness, and logical coherence. "
            "Provide feedback on any errors or improvements needed."
        )
        verified_solution = await self.revise(instruction=verification_instruction, context=intermediate_results)

        # Step 5: Summarize the solution
        summary_instruction = (
            f"Summarize the solution process and final answer based on: {verified_solution}\n"
            "Highlight key steps, intermediate results, and the final numerical answer."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=verified_solution)

        return final_summary