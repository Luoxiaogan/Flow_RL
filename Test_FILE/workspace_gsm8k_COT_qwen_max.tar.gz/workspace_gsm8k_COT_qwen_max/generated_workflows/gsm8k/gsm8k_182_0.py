# Workflow ID: gsm8k_182_0
# Benchmark: gsm8k
# Data Indices: [728, 503]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information from the problem text
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, units, relationships, and constraints. "
            "Identify what is being asked and list all knowns and unknowns. "
            "Format the output as a structured summary."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Solve the problem step by step using the extracted information
        reasoning_instruction = (
            f"Using the following extracted information: {extracted_info}\n"
            "Solve the problem step by step. Clearly show all intermediate calculations and reasoning. "
            "Ensure the solution adheres to the problem's constraints and real-world context. "
            "Format the output as a detailed explanation."
        )
        solution = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Validate and refine the solution
        refinement_instruction = (
            "Critically evaluate the following solution for accuracy and completeness:\n"
            f"{solution}\n"
            "Check for unit consistency, logical correctness, and adherence to the problem's constraints. "
            "Refine the solution if necessary and provide the improved version."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=solution)

        # Step 4: Extract the final answer
        summarization_instruction = (
            "From the following refined solution, extract the final numerical answer:\n"
            f"{refined_solution}\n"
            "Ensure the answer is clear, concise, and formatted as a single number (integer or decimal)."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_solution)

        return final_answer