# Workflow ID: gsm8k_217_0
# Benchmark: gsm8k
# Data Indices: [663, 624]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem text
        extraction_instruction = (
            "Extract all numerical values, relationships, units, and the specific question being asked "
            "from the problem text. Format the output as a structured list or explanation."
        )
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Construct a mathematical model of the problem
        modeling_instruction = (
            f"Based on the following extracted information:\n{extraction}\n"
            "Construct a step-by-step plan to solve the problem. Include all necessary calculations, "
            "intermediate results, and the sequence of operations required to arrive at the final answer."
        )
        model = await self.generate(instruction=modeling_instruction, context=self.problem_text)

        # Step 3: Revise and refine the intermediate solution
        revision_instruction = (
            "Critique the following solution plan for logical consistency, unit handling, and adherence "
            "to the problem's constraints. Suggest improvements if necessary."
        )
        refined_model = await self.revise(instruction=revision_instruction, context=model)

        # Step 4: Compute the final answer
        calculation_instruction = (
            f"Using the refined solution plan:\n{refined_model}\n"
            "Perform the final calculations and provide the single numerical answer to the problem. "
            "Ensure the answer is clearly stated and makes sense in the context of the problem."
        )
        final_answer = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Optional: Explore alternative solutions in parallel
        alternative_instruction_1 = (
            "Solve the problem using an alternative approach, focusing on a different sequence of steps "
            "or interpretation of the problem's relationships."
        )
        alternative_instruction_2 = (
            "Solve the problem by prioritizing proportional reasoning or rate-based calculations, "
            "if applicable."
        )
        alternative_results = await asyncio.gather(
            self.generate(instruction=alternative_instruction_1, context=self.problem_text),
            self.generate(instruction=alternative_instruction_2, context=self.problem_text)
        )

        # Step 5: Select or synthesize the best result
        ensemble_instruction = (
            "Evaluate the following candidate solutions and select the most accurate and complete one. "
            "If necessary, synthesize a new solution that combines the strengths of the candidates."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=[final_answer] + alternative_results)

        # Step 6: Summarize the final solution
        summarization_instruction = (
            "Condense the final solution into a concise format, including the key steps, intermediate results, "
            "and the final numerical answer. Ensure clarity and completeness."
        )
        summary = await self.summarize(instruction=summarization_instruction, context=best_solution)

        return summary