# Workflow ID: gsm8k_135_0
# Benchmark: gsm8k
# Data Indices: [137, 91]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all numerical values, units, and relationships
        extraction_instruction = (
            "Thoroughly analyze the problem and extract all numerical values, units, "
            "and relationships between entities. Include implicit information such as "
            "hidden steps or constraints. Organize the extracted data in a structured format."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Create a step-by-step plan for solving the problem
        planning_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. Identify all necessary "
            "calculations, including intermediate steps and hidden operations. Ensure the plan "
            "is logically consistent and accounts for all constraints and units."
        )
        plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Execute the plan (parallelize independent steps if applicable)
        execution_instruction = (
            f"Follow this plan to solve the problem:\n{plan}\n"
            "Perform all calculations step by step, showing intermediate results. Ensure all "
            "units are consistent and calculations are accurate. If there are independent sub-problems, "
            "solve them in parallel where possible."
        )
        # Simulate parallel execution for independent sub-problems
        sub_problem_1 = self.generate(instruction=execution_instruction, context=self.problem_text)
        sub_problem_2 = self.generate(instruction=execution_instruction, context=self.problem_text)
        partial_results = await asyncio.gather(sub_problem_1, sub_problem_2)

        # Step 4: Combine results and perform final calculation
        ensemble_instruction = (
            "Evaluate the following partial results and combine them into a final solution:\n"
            f"{partial_results}\n"
            "Ensure the final calculation satisfies all constraints and answers the original question."
        )
        final_result = await self.ensemble(instruction=ensemble_instruction, contexts=partial_results)

        # Step 5: Validate and refine the final result
        validation_instruction = (
            f"Validate the following result:\n{final_result}\n"
            "Ensure it makes sense in the context of the problem, adheres to real-world constraints, "
            "and is mathematically correct. Revise if necessary."
        )
        validated_result = await self.revise(instruction=validation_instruction, context=final_result)

        # Step 6: Summarize the solution
        summary_instruction = (
            f"Summarize the following solution:\n{validated_result}\n"
            "Provide a concise and clear final answer, ensuring it directly addresses the problem."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=validated_result)

        return final_summary