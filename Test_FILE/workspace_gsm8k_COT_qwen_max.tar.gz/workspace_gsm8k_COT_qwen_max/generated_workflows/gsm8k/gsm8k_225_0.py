# Workflow ID: gsm8k_225_0
# Benchmark: gsm8k
# Data Indices: [438, 650]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract Key Information
        extraction_instruction = (
            "Thoroughly analyze the problem and extract all relevant numerical values, "
            "units, relationships, and constraints. Organize the information clearly and "
            "ensure nothing is omitted."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan the Solution
        planning_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Formulate a detailed step-by-step plan to solve the problem. Include all intermediate "
            "calculations, unit conversions, and logical sequencing of operations. Ensure the plan "
            "is clear, complete, and adaptable to the problem's context."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Execute Calculations
        calculation_instruction = (
            f"Follow the solution plan: {solution_plan}\n"
            "Perform all calculations step by step. Clearly document each step's result and verify "
            "its correctness. Ensure all units are consistent and the calculations align with the "
            "problem's requirements."
        )
        calculations = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Refine the Solution
        refinement_instruction = (
            f"Review the calculations: {calculations}\n"
            "Critique and refine the solution to ensure accuracy. Check for calculation errors, "
            "unit inconsistencies, and logical flaws. Provide a corrected and polished version "
            "of the solution."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=calculations)

        # Step 5: Summarize the Final Answer
        summarization_instruction = (
            f"Condense the refined solution: {refined_solution}\n"
            "Extract the final numerical answer with appropriate units. Ensure the answer is "
            "presented clearly and makes sense in the context of the problem."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_solution)

        return final_answer