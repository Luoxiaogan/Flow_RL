# Workflow ID: gsm8k_169_0
# Benchmark: gsm8k
# Data Indices: [321, 104]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant numerical values, entities, relationships, and units
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, entities, relationships, and units. "
            "List them clearly and categorize them (e.g., costs, quantities, rates). Ensure no detail is missed."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Translate the problem into a mathematical model
        modeling_instruction = (
            f"Based on the extracted information: {extracted_info}, "
            "translate the problem into a mathematical model. Identify the operations needed (addition, subtraction, multiplication, division, etc.) "
            "and their sequence. Include any intermediate steps required to solve the problem."
        )
        mathematical_model = await self.generate(instruction=modeling_instruction, context=self.problem_text)

        # Step 3: Perform step-by-step calculations
        calculation_instruction = (
            f"Using the mathematical model: {mathematical_model}, "
            "perform the calculations step by step. Show all intermediate results and ensure each step is logically sound. "
            "Verify that the calculations align with the problem's context and constraints."
        )
        calculated_solution = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Verify and refine the solution
        refinement_instruction = (
            f"Review the calculated solution: {calculated_solution}. "
            "Check for any errors or inconsistencies. Ensure the final answer is correct and makes sense in the context of the problem. "
            "Refine the solution if necessary."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=calculated_solution)

        # Step 5: Extract the final numerical answer
        final_extraction_instruction = (
            f"From the refined solution: {refined_solution}, "
            "extract the final numerical answer. Ensure it is presented as a single value without any additional text."
        )
        final_answer = await self.generate(instruction=final_extraction_instruction, context=refined_solution)

        return final_answer.strip()