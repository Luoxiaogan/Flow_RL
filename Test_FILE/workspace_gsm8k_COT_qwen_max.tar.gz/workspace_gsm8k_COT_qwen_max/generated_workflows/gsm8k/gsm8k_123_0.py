# Workflow ID: gsm8k_123_0
# Benchmark: gsm8k
# Data Indices: [252, 300]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant numerical values and relationships
        extraction_instruction = """
        Analyze the problem thoroughly and extract all numerical values, units, and relationships mentioned. 
        Include explicit and implicit information such as rates, totals, percentages, and constraints. 
        Organize the extracted information in a structured format for further processing.
        """
        extracted_data = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan and compute intermediate steps
        analysis_instruction = f"""
        Given the extracted information: {extracted_data}
        Identify the sequence of mathematical operations required to solve the problem. 
        Consider hidden steps, unit conversions, and real-world constraints. 
        Perform intermediate calculations step-by-step and document the reasoning process.
        """
        intermediate_solution = await self.generate(instruction=analysis_instruction, context=self.problem_text)

        # Optional Step 3: Generate alternative solutions in parallel
        parallel_instruction_1 = f"""
        Solve the problem using the following approach: Sequentially compute each step based on {intermediate_solution}.
        Ensure all calculations are accurate and logically consistent.
        """
        parallel_instruction_2 = f"""
        Solve the problem using an alternative approach: Combine related calculations into a single formula if possible.
        Verify that the result aligns with the extracted information: {extracted_data}.
        """
        results = await asyncio.gather(
            self.generate(instruction=parallel_instruction_1, context=self.problem_text),
            self.generate(instruction=parallel_instruction_2, context=self.problem_text)
        )
        best_solution = await self.ensemble(
            instruction="Compare the two solutions and select the most accurate and logically consistent one.",
            contexts=results
        )

        # Step 4: Final computation and verification
        final_instruction = f"""
        Based on the selected solution: {best_solution}
        Perform the final calculation to arrive at a single numerical answer. 
        Verify that the result makes sense in the context of the problem and adheres to all constraints.
        """
        final_result = await self.generate(instruction=final_instruction, context=self.problem_text)

        # Step 5: Refine and extract the final numerical answer
        refinement_instruction = """
        Ensure the final result is a single numerical value (integer or decimal). 
        Remove any extraneous text or explanations and return only the numerical answer.
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_result)

        return refined_answer