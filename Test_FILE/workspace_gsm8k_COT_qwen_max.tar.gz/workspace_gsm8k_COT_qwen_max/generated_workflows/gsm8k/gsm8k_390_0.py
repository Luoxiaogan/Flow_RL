# Workflow ID: gsm8k_390_0
# Benchmark: gsm8k
# Data Indices: [786, 571]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information from the problem
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, units, relationships, "
            "and contextual clues. Organize the information in a structured format, including knowns "
            "and unknowns. Ensure that all extracted data is explicitly tied back to the problem statement."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        solution_instruction_template = (
            f"Using the following extracted information: {extracted_info}\n"
            "Formulate a step-by-step solution plan to solve the problem. Include all intermediate "
            "calculations, ensure proper handling of units, and verify that the solution adheres to "
            "real-world constraints. Provide clear reasoning for each step."
        )

        # Generate two independent solution approaches
        approach_1_instruction = solution_instruction_template + " Focus on a straightforward sequential approach."
        approach_2_instruction = solution_instruction_template + " Explore alternative reasoning paths or optimizations."

        solutions = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and select the best solution
        ensemble_instruction = (
            "Compare the following candidate solutions and select the most accurate and logically consistent one. "
            "Ensure the chosen solution adheres to the problem's context and real-world constraints. "
            "If discrepancies exist, resolve them through careful reasoning."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=solutions)

        # Step 4: Summarize the final solution
        summary_instruction = (
            "Condense the solution into a concise format, highlighting the final numerical answer. "
            "Ensure the summary is clear, accurate, and directly addresses the problem's question."
        )
        final_output = await self.summarize(instruction=summary_instruction, context=best_solution)

        return final_output