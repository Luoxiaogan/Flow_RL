# Workflow ID: gsm8k_227_0
# Benchmark: gsm8k
# Data Indices: [568, 529]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all numerical values, relationships, and constraints
        extraction_instruction = """
        Carefully analyze the problem and extract all numerical values, relationships, and constraints. 
        Identify what is known and what needs to be determined. 
        Provide a clear list of these elements, ensuring that units and relationships are explicitly stated.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Create a structured plan and perform calculations
        calculation_instruction = f"""
        Based on the following extracted information:
        {extracted_info}
        Create a step-by-step plan to solve the problem. 
        Perform all necessary calculations in sequence, showing intermediate results. 
        Ensure that units are consistent throughout and that the solution addresses all aspects of the problem.
        """
        calculated_solution = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 3: Revise and refine the solution
        revision_instruction = """
        Critique the provided solution and identify any errors or areas for improvement. 
        Verify that all calculations are correct and that the final answer makes sense in the context of the problem. 
        If necessary, provide corrections or alternative approaches.
        """
        revised_solution = await self.revise(instruction=revision_instruction, context=calculated_solution)

        # Step 4: Summarize to extract the final answer
        summary_instruction = """
        From the provided solution, extract the final numerical answer. 
        Ensure that the answer is clearly stated and formatted as a single number (integer or decimal). 
        Remove any extraneous information or intermediate steps.
        """
        final_answer = await self.summarize(instruction=summary_instruction, context=revised_solution)

        return final_answer