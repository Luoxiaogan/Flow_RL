# Workflow ID: gsm8k_303_0
# Benchmark: gsm8k
# Data Indices: [79, 7]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract Key Information
        extract_instruction = (
            "Carefully read the problem statement and extract all relevant information. "
            "This includes numerical values, relationships between quantities, entities involved, "
            "and the specific question being asked. Format your output clearly with labeled sections."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Validate and Refine Extracted Information
        refine_instruction = (
            "Review the extracted information and ensure it accurately captures all necessary details "
            "from the original problem. Correct any inaccuracies and provide additional clarifications "
            "if needed. Maintain the same format as the input."
        )
        refined_info = await self.revise(instruction=refine_instruction, context=extracted_info)

        # Step 3: Formulate Solution Strategy
        strategy_instruction = (
            f"Based on the refined information:\n{refined_info}\n"
            "Develop a step-by-step plan to solve the problem. Clearly outline each calculation or logical step "
            "required to arrive at the final answer. Ensure the steps are in the correct order and address all parts "
            "of the problem."
        )
        solution_strategy = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 4: Explore Multiple Solution Paths (Parallel Execution)
        approach_1_instruction = (
            f"Following the solution strategy:\n{solution_strategy}\n"
            "Execute the calculations step by step. Provide detailed intermediate results and ensure units are consistent. "
            "Present the final answer clearly."
        )
        approach_2_instruction = (
            f"Using a slightly different method but still adhering to:\n{solution_strategy}\n"
            "Solve the problem again to verify the results. Highlight any alternative approaches or optimizations."
        )

        solutions = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text)
        )

        # Step 5: Ensemble Decision Making
        ensemble_instruction = (
            "Compare the following solutions and determine which one is the most accurate and efficient. "
            "If there are discrepancies, identify the source and resolve them. Synthesize a final answer based on this analysis."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=solutions)

        # Step 6: Final Answer Summarization
        summarize_instruction = (
            "Summarize the final solution concisely. Present the answer in a clear and standardized format, "
            "ensuring it directly addresses the original question."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=final_solution)

        return final_answer