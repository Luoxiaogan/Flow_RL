# Workflow ID: gsm8k_207_0
# Benchmark: gsm8k
# Data Indices: [716, 295]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information
        extraction_instruction = (
            "Carefully analyze the problem text and extract all numerical values, units, "
            "relationships (e.g., ratios, rates, comparisons), and the specific question being asked. "
            "Ensure that all relevant information is captured in a structured format."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Mathematical modeling
        modeling_instruction = (
            f"Based on the following extracted information: {extracted_info}\n"
            "Formulate a mathematical model or sequence of operations required to solve the problem. "
            "Clearly outline each step, including any intermediate calculations, and specify the order of operations."
        )
        mathematical_model = await self.generate(instruction=modeling_instruction, context=extracted_info)

        # Step 3: Generate parallel solution approaches
        approach_1_instruction = (
            f"Using the mathematical model: {mathematical_model}\n"
            "Solve the problem step-by-step, ensuring that all calculations are accurate and logically consistent. "
            "Provide the final answer with appropriate units."
        )
        approach_2_instruction = (
            f"Using the mathematical model: {mathematical_model}\n"
            "Solve the problem using an alternative sequence of operations or interpretation of relationships. "
            "Provide the final answer with appropriate units."
        )
        results = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=mathematical_model),
            self.generate(instruction=approach_2_instruction, context=mathematical_model)
        )

        # Step 4: Ensemble selection
        ensemble_instruction = (
            "Compare the following solutions and select the most accurate and consistent one. "
            "If there are discrepancies, synthesize the results to arrive at a single correct answer. "
            "Ensure that the final answer makes sense in the context of the problem."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 5: Refine the final answer
        refinement_instruction = (
            "Critique and refine the following solution to ensure clarity, correctness, and proper formatting. "
            "Verify that the answer is consistent with the problem's context and units."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_solution)

        return refined_answer