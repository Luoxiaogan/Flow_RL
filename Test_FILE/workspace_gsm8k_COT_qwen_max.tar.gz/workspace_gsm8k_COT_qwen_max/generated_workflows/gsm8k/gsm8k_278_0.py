# Workflow ID: gsm8k_278_0
# Benchmark: gsm8k
# Data Indices: [133, 531]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (numerical values, entities, relationships)
        extract_instruction = """
        Analyze the problem text thoroughly and extract all numerical values, entities (e.g., people, objects), 
        and their relationships. Ensure you capture implicit relationships and constraints. Format the output 
        as a structured list or dictionary for clarity.
        """
        extract_task = self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Formulate mathematical steps
        formulate_instruction = """
        Based on the extracted information, formulate a step-by-step plan to solve the problem. 
        Include all necessary intermediate calculations, specify the order of operations, and ensure 
        unit consistency throughout. Highlight any hidden steps or assumptions.
        """
        formulate_task = self.generate(instruction=formulate_instruction, context=self.problem_text)

        # Run extraction and formulation in parallel
        extracted_info, formulated_steps = await asyncio.gather(extract_task, formulate_task)

        # Step 3: Perform calculations
        calculate_instruction = f"""
        Using the extracted information: {extracted_info} and the formulated steps: {formulated_steps}, 
        perform the calculations step by step. Clearly show all intermediate results and ensure the 
        final result is accurate and contextually appropriate.
        """
        calculated_result = await self.generate(instruction=calculate_instruction, context=self.problem_text)

        # Step 4: Revise and refine the solution
        revise_instruction = """
        Critically review the calculated result and ensure it is logically consistent, unit-correct, 
        and makes sense in the context of the problem. Identify and correct any errors or ambiguities.
        """
        refined_solution = await self.revise(instruction=revise_instruction, context=calculated_result)

        # Step 5: Summarize the final answer
        summarize_instruction = """
        Condense the refined solution into a concise final answer. Ensure the answer is a single 
        numerical value (integer or decimal) and includes appropriate units if applicable.
        """
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_answer