# Workflow ID: gsm8k_272_0
# Benchmark: gsm8k
# Data Indices: [643, 376]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract knowns and unknowns
        extraction_instruction = """
        Extract all numerical values, units, relationships, and constraints from the problem. 
        Identify what is known and what needs to be calculated. 
        Provide the extracted information in a structured format, such as a list or table.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a solution plan
        plan_instruction = f"""
        Based on the following extracted information:
        {extracted_info}
        
        Create a step-by-step plan to solve the problem. 
        Include all intermediate calculations, specify the order of operations, and track units throughout. 
        Ensure the plan accounts for any hidden steps or contextual constraints.
        """
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute the solution plan
        execution_instruction = f"""
        Follow this solution plan step-by-step:
        {solution_plan}
        
        Perform all calculations explicitly, documenting intermediate results. 
        Ensure the final result is expressed as a single numerical value with appropriate units.
        """
        executed_solution = await self.generate(instruction=execution_instruction, context=self.problem_text)

        # Step 4: Verify the solution
        verification_instruction = f"""
        Critique the following solution for correctness, consistency, and alignment with the problem context:
        {executed_solution}
        
        Check for errors in calculations, unit inconsistencies, and violations of real-world constraints. 
        Provide suggestions for improvement if necessary.
        """
        verified_solution = await self.revise(instruction=verification_instruction, context=executed_solution)

        # Step 5: Summarize the final answer
        summary_instruction = """
        Extract the final numerical answer from the solution. 
        Ensure it is presented as a single value (integer or decimal) without any additional text.
        """
        final_answer = await self.summarize(instruction=summary_instruction, context=verified_solution)

        return final_answer