# Workflow ID: gsm8k_203_0
# Benchmark: gsm8k
# Data Indices: [312, 775]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all numerical values, units, and relationships
        extraction_instruction = (
            "Thoroughly analyze the problem and extract all numerical values, units, and relationships. "
            "Identify any implicit constraints or dependencies. Format the output as a clear list of items."
        )
        extracted_values = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Construct a mathematical model of the problem
        modeling_instruction = (
            f"Using the following extracted information: {extracted_values}\n"
            "Translate the relationships and constraints into a mathematical model. "
            "Specify the sequence of operations needed to solve the problem. "
            "Include intermediate steps and ensure the model is complete and accurate."
        )
        mathematical_model = await self.generate(instruction=modeling_instruction, context=self.problem_text)

        # Step 3: Perform sequential calculations
        calculation_instruction = (
            f"Given the mathematical model: {mathematical_model}\n"
            "Perform the necessary calculations step by step. "
            "Explicitly show intermediate results and ensure the order of operations is correct. "
            "Provide the final numerical result at the end."
        )
        result = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Verify the solution and refine if necessary
        verification_instruction = (
            f"Verify the following solution: {result}\n"
            "Ensure the answer is mathematically correct and makes sense in the context of the problem. "
            "Check for real-world constraints (e.g., no negative quantities, reasonable units). "
            "If necessary, refine the solution to address any issues."
        )
        final_answer = await self.revise(instruction=verification_instruction, context=result)

        return final_answer