# Workflow ID: gsm8k_111_0
# Benchmark: gsm8k
# Data Indices: [82, 481]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract numerical values, units, and relationships
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, units, and relationships. "
            "Categorize them into known values, unknowns, and constraints. "
            "Ensure that all units are clearly identified and consistent. "
            "Provide the extracted information in a structured format."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan the solution steps
        planning_instruction = (
            f"Based on the following extracted information: {extracted_info}, "
            "create a detailed step-by-step plan to solve the problem. "
            "Include all intermediate calculations, ensure proper sequencing of operations, "
            "and verify that the plan addresses all constraints and relationships. "
            "Provide the plan in a clear and logical order."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Generate multiple solution approaches in parallel
        direct_calculation_instruction = (
            f"Using the following solution plan: {solution_plan}, "
            "solve the problem using direct calculation. "
            "Show all intermediate steps and ensure the final answer is a single numerical value."
        )
        proportional_reasoning_instruction = (
            f"Using the following solution plan: {solution_plan}, "
            "solve the problem using proportional reasoning or unit tracking. "
            "Show all intermediate steps and ensure the final answer is a single numerical value."
        )

        # Parallel execution of different solution approaches
        solutions = await asyncio.gather(
            self.generate(instruction=direct_calculation_instruction, context=self.problem_text),
            self.generate(instruction=proportional_reasoning_instruction, context=self.problem_text)
        )

        # Step 4: Evaluate and select the best solution
        ensemble_instruction = (
            "Evaluate the following candidate solutions and select the most accurate and reliable one. "
            "Ensure the chosen solution adheres to the problem constraints, is mathematically sound, "
            "and provides a single numerical answer. If necessary, synthesize a final solution."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=solutions)

        # Step 5: Extract the final numerical answer
        answer_extraction_instruction = (
            f"From the following solution: {final_solution}, "
            "extract the final numerical answer. Ensure the answer is a single number, "
            "with appropriate decimal places if needed."
        )
        final_answer = await self.generate(instruction=answer_extraction_instruction, context=self.problem_text)

        return final_answer