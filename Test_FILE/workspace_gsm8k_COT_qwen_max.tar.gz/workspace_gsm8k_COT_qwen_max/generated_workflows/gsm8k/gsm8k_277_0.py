# Workflow ID: gsm8k_277_0
# Benchmark: gsm8k
# Data Indices: [299, 471]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract known information
        extraction_instruction = """
        Extract all numerical values, units, and relationships from the problem text.
        Identify any constraints or conditions explicitly stated or implied.
        Format the output as a structured list of key-value pairs or bullet points.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Identify unknowns and plan solution
        analysis_instruction = f"""
        Analyze the following extracted information: {extracted_info}
        Determine what the problem is asking for and identify any unknowns.
        Plan the sequence of operations needed to solve the problem, including any intermediate steps.
        Format the output as a clear step-by-step plan.
        """
        solution_plan = await self.generate(instruction=analysis_instruction, context=self.problem_text)

        # Step 3: Perform calculations
        calculation_instruction = f"""
        Using the following plan: {solution_plan}
        Perform the required calculations step-by-step. Ensure proper handling of units, order of operations, and intermediate results.
        If there are multiple approaches, consider them separately and provide all possible solutions.
        """
        raw_solutions = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Verify and refine solution
        verification_instruction = f"""
        Critique the following solution(s): {raw_solutions}
        Ensure they align with the problem context and constraints. Check for calculation errors, unit consistency, and logical coherence.
        Provide a revised and verified solution.
        """
        verified_solution = await self.revise(instruction=verification_instruction, context=raw_solutions)

        # Optional: Summarize the final solution
        summary_instruction = """
        Condense the verified solution into a concise format, ensuring clarity and completeness.
        """
        final_answer = await self.summarize(instruction=summary_instruction, context=verified_solution)

        return final_answer