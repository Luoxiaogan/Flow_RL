# Workflow ID: gsm8k_142_0
# Benchmark: gsm8k
# Data Indices: [164, 114]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract relevant numerical values and relationships
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, "
            "relationships, and constraints. Clearly label each extracted piece "
            "of information and explain its significance in the context of the problem."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Create a step-by-step solution plan
        planning_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. "
            "Include all intermediate calculations, specify the order of operations, "
            "and ensure unit consistency throughout. Highlight any hidden steps "
            "or assumptions that need to be considered."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Execute intermediate steps in parallel
        execution_instruction_template = (
            "Perform the following calculation step:\n{{step}}\n"
            "Ensure your result is accurate and includes appropriate units. "
            "Explain your reasoning briefly."
        )
        steps = solution_plan.split("\n")  # Assuming each step is on a new line
        step_tasks = [
            self.generate(instruction=execution_instruction_template.replace("{{step}}", step), context=self.problem_text)
            for step in steps if step.strip()
        ]
        intermediate_results = await asyncio.gather(*step_tasks)

        # Step 4: Synthesize intermediate results into the final answer
        synthesis_instruction = (
            "Combine the following intermediate results to compute the final answer:\n"
            f"{intermediate_results}\n"
            "Ensure the final result is a single numerical value and makes sense "
            "in the context of the problem. Verify unit consistency and logical coherence."
        )
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=intermediate_results)

        # Step 5: Verify and refine the solution
        refinement_instruction = (
            "Review the following solution for accuracy and logical consistency:\n"
            f"{final_answer}\n"
            "Suggest improvements or corrections if needed, and ensure the answer "
            "is presented as a single numerical value."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=final_answer)

        # Step 6: Summarize the final result
        summary_instruction = (
            "Condense the following solution into a single numerical value:\n"
            f"{refined_solution}\n"
            "Ensure the output is clear, concise, and directly answers the problem."
        )
        final_output = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_output