# Workflow ID: gsm8k_209_0
# Benchmark: gsm8k
# Data Indices: [24, 339]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio
        
        # Step 1: Extract known information
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, relationships, and constraints. "
            "Include units, ratios, percentages, and any other relevant details. Format the output clearly."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)
        
        # Step 2: Formulate a solution plan
        plan_instruction = (
            f"Based on the following extracted information: {extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. Include all necessary calculations, "
            "intermediate steps, and ensure the plan adheres to the problem's context and constraints."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)
        
        # Step 3: Perform calculations
        calculation_instruction = (
            f"Follow this solution plan: {solution_plan}\n"
            "Perform all calculations step by step, showing intermediate results. Ensure units are consistent "
            "and the final result is clearly stated."
        )
        calculated_solution = await self.generate(instruction=calculation_instruction, context=self.problem_text)
        
        # Step 4: Validate and refine the solution
        revise_instruction = (
            f"Review the following solution: {calculated_solution}\n"
            "Check for consistency with the problem's context, units, and constraints. Refine the solution if needed."
        )
        refined_solution = await self.revise(instruction=revise_instruction, context=calculated_solution)
        
        # Step 5: Summarize the final answer
        summarize_instruction = (
            f"From the refined solution: {refined_solution}\n"
            "Extract and present the final numerical answer. Ensure it is clear, concise, and contextually valid."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_solution)
        
        return final_answer