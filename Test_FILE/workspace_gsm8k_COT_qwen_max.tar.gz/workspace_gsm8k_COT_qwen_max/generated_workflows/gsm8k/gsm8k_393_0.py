# Workflow ID: gsm8k_393_0
# Benchmark: gsm8k
# Data Indices: [791, 729]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant numerical values, relationships, and constraints
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, units, and relationships. "
            "Include any implicit constraints or contextual information that might affect the solution. "
            "Organize the extracted information in a structured format for clarity."
        )
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate a step-by-step solution plan
        solution_plan_instruction = (
            f"Based on the extracted information: {extraction}, create a detailed step-by-step plan to solve the problem. "
            "Ensure that each step logically follows from the previous one and includes all necessary calculations. "
            "Pay special attention to units, order of operations, and real-world constraints."
        )
        solution_plan = await self.generate(instruction=solution_plan_instruction, context=self.problem_text)

        # Step 3: Generate two independent solutions in parallel (optional but useful for complex problems)
        solution_1_instruction = (
            f"Follow this solution plan: {solution_plan} to calculate the final answer. "
            "Show all intermediate steps and ensure the solution is mathematically sound."
        )
        solution_2_instruction = (
            f"Using a different approach if possible, follow this solution plan: {solution_plan} to calculate the final answer. "
            "Show all intermediate steps and ensure the solution is mathematically sound."
        )
        solution_1, solution_2 = await asyncio.gather(
            self.generate(instruction=solution_1_instruction, context=self.problem_text),
            self.generate(instruction=solution_2_instruction, context=self.problem_text)
        )

        # Step 4: Use Ensemble to select the best solution or synthesize them
        ensemble_instruction = (
            "Evaluate the two solutions provided. Check for logical consistency, correctness of calculations, "
            "and adherence to the problem's context. If both solutions are valid, synthesize them into a single answer. "
            "If one solution is better, choose that solution and explain why."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=[solution_1, solution_2])

        # Step 5: Validate and refine the solution
        validation_instruction = (
            f"Critique this solution: {final_solution}. Ensure it makes sense in the context of the problem. "
            "Check for unit consistency, logical flow, and adherence to real-world constraints. "
            "If necessary, suggest refinements to improve the solution."
        )
        refined_solution = await self.revise(instruction=validation_instruction, context=final_solution)

        # Step 6: Extract the final numerical answer
        answer_extraction_instruction = (
            f"From the refined solution: {refined_solution}, extract the final numerical answer. "
            "Ensure the answer is presented as a single number without any additional text."
        )
        final_answer = await self.summarize(instruction=answer_extraction_instruction, context=refined_solution)

        return final_answer