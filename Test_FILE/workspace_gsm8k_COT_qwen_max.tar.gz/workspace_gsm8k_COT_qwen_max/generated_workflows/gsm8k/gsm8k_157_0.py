# Workflow ID: gsm8k_157_0
# Benchmark: gsm8k
# Data Indices: [601, 551]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information
        extract_instruction = """
        Extract all numerical values and their associated units from the problem text.
        Identify any relationships or operations implied by the text (e.g., addition, multiplication).
        Ensure you capture all relevant data needed to solve the problem.
        """
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Identify problem type and strategy
        strategy_instruction = f"""
        Based on the extracted information: {extracted_info}
        Determine the type of problem (e.g., sequential operations, rate problems, proportional reasoning).
        Outline a step-by-step strategy to solve the problem, including any intermediate calculations required.
        Ensure the strategy considers real-world constraints and unit consistency.
        """
        strategy = await self.generate(instruction=strategy_instruction, context=extracted_info)

        # Step 3: Perform calculations
        calc_instruction_template = """
        Follow the outlined strategy step-by-step.
        Perform each calculation carefully, showing intermediate results.
        Ensure all units are consistent and track them throughout the calculations.
        """
        calc_steps = strategy.split("\n")  # Assuming strategy lists steps line by line
        calc_tasks = [
            self.generate(instruction=f"{calc_instruction_template}\nStep: {step}", context=extracted_info)
            for step in calc_steps if step.strip()
        ]
        results = await asyncio.gather(*calc_tasks)

        # Step 4: Validate and revise results
        validate_instruction = f"""
        Review the following results: {results}
        Check for consistency in units, verify intermediate results, and ensure the final answer makes sense.
        Highlight any inconsistencies or errors that need revision.
        """
        validation = await self.revise(instruction=validate_instruction, context="\n".join(results))

        # Step 5: Summarize the solution
        summarize_instruction = f"""
        Summarize the entire solution process concisely.
        Include the final answer and highlight key steps taken to arrive at the solution.
        Ensure the summary is clear and easy to understand.
        """
        summary = await self.summarize(instruction=summarize_instruction, context=validation)

        return summary