# Workflow ID: gsm8k_145_0
# Benchmark: gsm8k
# Data Indices: [197, 733]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, relationships, and constraints. "
            "Include percentages, fractions, totals, and any other relevant data. "
            "Format the output as a structured list for clarity."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate intermediate steps
        formulation_instruction = (
            f"Based on the extracted information: {extracted_info}, formulate a step-by-step plan to solve the problem. "
            "Include all intermediate calculations required to reach the final answer. "
            "Clearly specify the order of operations and any contextual constraints (e.g., non-negative quantities)."
        )
        steps = await self.generate(instruction=formulation_instruction, context=self.problem_text)

        # Step 3: Perform calculations
        calculation_instruction = (
            f"Follow the formulated steps: {steps}. Perform all intermediate calculations systematically. "
            "Ensure proper handling of units, fractions, and percentages. Provide the results of each step."
        )
        calculations = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Validate and refine results
        refinement_instruction = (
            f"Review the calculations: {calculations}. Check for consistency with the problem context. "
            "Revise any discrepancies or errors. Ensure the results make sense (e.g., no fractional people or negative items)."
        )
        refined_results = await self.revise(instruction=refinement_instruction, context=calculations)

        # Step 5: Finalize the solution
        summary_instruction = (
            f"Condense the refined results: {refined_results} into a single numerical answer. "
            "Verify that the solution satisfies the problem's requirements. Format the final answer clearly."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_results)

        return final_answer