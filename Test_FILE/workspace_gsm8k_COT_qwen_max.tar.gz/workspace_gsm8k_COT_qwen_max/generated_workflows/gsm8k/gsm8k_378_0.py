# Workflow ID: gsm8k_378_0
# Benchmark: gsm8k
# Data Indices: [554, 755]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, relationships, and key entities. "
            "Format the extracted information clearly, including units and any dependencies between values."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a solution strategy
        strategy_instruction = (
            f"Based on the following extracted information: {extracted_info}\n"
            "Outline a step-by-step solution strategy to solve the problem. "
            "Include instructions for handling units, sequencing operations, and addressing any hidden steps."
        )
        solution_strategy = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Execute solution steps in parallel
        steps = solution_strategy.split("\n")  # Assume each line is a step
        step_instructions = [
            f"Perform the following step: {step}. Ensure calculations are accurate and units are consistent."
            for step in steps if step.strip()
        ]
        step_results = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in step_instructions]
        )

        # Step 4: Synthesize intermediate results
        synthesis_instruction = (
            "Evaluate and synthesize the following results into a coherent intermediate solution. "
            "Ensure logical consistency and proper sequencing of steps."
        )
        intermediate_solution = await self.ensemble(instruction=synthesis_instruction, contexts=step_results)

        # Step 5: Validate and refine the solution
        validation_instruction = (
            "Critique the following solution to ensure it aligns with the problem's context and constraints. "
            "Refine the solution if necessary, addressing any inconsistencies or errors."
        )
        refined_solution = await self.revise(instruction=validation_instruction, context=intermediate_solution)

        # Step 6: Extract the final answer
        final_instruction = (
            "Condense the following solution into a single numerical value representing the final answer. "
            "Ensure the result is clear, accurate, and properly formatted."
        )
        final_answer = await self.summarize(instruction=final_instruction, context=refined_solution)

        return final_answer