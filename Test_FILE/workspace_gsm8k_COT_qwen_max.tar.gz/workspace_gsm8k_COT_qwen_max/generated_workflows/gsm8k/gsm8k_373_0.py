# Workflow ID: gsm8k_373_0
# Benchmark: gsm8k
# Data Indices: [514, 286]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (numerical values, relationships, units, and question)
        extraction_instruction = (
            "Extract all numerical values, units, and relationships mentioned in the problem. "
            "Identify what the question is asking for and list any constraints or conditions. "
            "Ensure the output is structured and easy to interpret."
        )
        key_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate a detailed plan for solving the problem
        plan_instruction = (
            f"Based on the extracted information: {key_info}\n"
            "Create a step-by-step plan to solve the problem. Include:\n"
            "- The sequence of mathematical operations needed\n"
            "- How to handle units consistently\n"
            "- Any intermediate calculations or hidden steps\n"
            "- A verification strategy to ensure the solution is correct."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute the calculations according to the plan
        execution_instruction = (
            f"Follow this plan step by step: {solution_plan}\n"
            "Perform all calculations explicitly, showing intermediate results. "
            "Ensure the final result answers the question posed in the problem."
        )
        solution = await self.generate(instruction=execution_instruction, context=self.problem_text)

        # Step 4: Summarize the solution process for verification
        summary_instruction = (
            "Summarize the solution process, highlighting:\n"
            "- The key steps taken\n"
            "- The final numerical result\n"
            "- Whether the result makes sense in the context of the problem."
        )
        summary = await self.summarize(instruction=summary_instruction, context=solution)

        # Step 5: Revise the solution if necessary
        revision_instruction = (
            f"Review the solution and its summary: {summary}\n"
            "Check for consistency, accuracy, and adherence to the problem's constraints. "
            "Refine the solution if any issues are identified."
        )
        refined_solution = await self.revise(instruction=revision_instruction, context=solution)

        # Step 6: Extract the final numerical answer
        answer_instruction = (
            "From the refined solution, extract the final numerical answer. "
            "Ensure it is presented as a single value (integer or decimal)."
        )
        final_answer = await self.generate(instruction=answer_instruction, context=refined_solution)

        return final_answer