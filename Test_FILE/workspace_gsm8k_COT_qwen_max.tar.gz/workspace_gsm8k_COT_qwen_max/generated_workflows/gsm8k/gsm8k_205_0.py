# Workflow ID: gsm8k_205_0
# Benchmark: gsm8k
# Data Indices: [174, 231]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (numbers, relationships, target question)
        extraction_instruction = (
            "Extract all numerical values, relationships, and constraints from the problem. "
            "Identify what is being asked for and any intermediate steps required to compute the answer. "
            "Format the output as a structured summary."
        )
        key_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        approach_1_instruction = (
            f"Using the extracted information: {key_info}\n"
            "Solve the problem step by step using a direct calculation approach. "
            "Show all intermediate steps and ensure unit consistency."
        )
        approach_2_instruction = (
            f"Using the extracted information: {key_info}\n"
            "Solve the problem step by step using a reasoning-based approach. "
            "Explain your logic clearly and verify each step."
        )
        results = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text)
        )

        # Step 3: Revise and refine the results
        revise_instruction = (
            "Critique the following solution for accuracy, logical consistency, and unit handling. "
            "Refine the solution if necessary and provide the improved version."
        )
        refined_results = await asyncio.gather(
            self.revise(instruction=revise_instruction, context=results[0]),
            self.revise(instruction=revise_instruction, context=results[1])
        )

        # Step 4: Summarize the refined results
        summarize_instruction = (
            "Condense the following solution into a concise summary. "
            "Include only the key steps and the final answer."
        )
        summaries = await asyncio.gather(
            self.summarize(instruction=summarize_instruction, context=refined_results[0]),
            self.summarize(instruction=summarize_instruction, context=refined_results[1])
        )

        # Step 5: Ensemble to select the best solution
        ensemble_instruction = (
            "Compare the following solutions and select the most accurate and logically consistent one. "
            "If both are equivalent, choose either. Format the final answer as a single numerical value."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=summaries)

        return final_answer