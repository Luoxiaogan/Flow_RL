# Workflow ID: gsm8k_99_0
# Benchmark: gsm8k
# Data Indices: [538, 492]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (numerical values, relationships, units)
        extract_instruction = (
            "Thoroughly analyze the problem and extract all numerical values, relationships, "
            "and units mentioned in the text. Format the output as follows:\n"
            "- Known values: [list all numerical values]\n"
            "- Relationships: [describe relationships between values]\n"
            "- Units: [list all units involved]\n"
            "Ensure no detail is missed and the output is structured clearly."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Formulate the mathematical model
        model_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Formulate a step-by-step plan to solve the problem. Identify the unknown(s), "
            "known(s), and the relationships between them. Translate the problem into a "
            "mathematical structure that can be solved systematically. Provide explicit "
            "instructions for each calculation step."
        )
        mathematical_model = await self.generate(instruction=model_instruction, context=self.problem_text)

        # Step 3: Solve the problem step-by-step
        solve_instruction = (
            f"Using the following mathematical model:\n{mathematical_model}\n"
            "Perform the calculations step-by-step. Show all intermediate results and ensure "
            "each step logically follows from the previous one. Verify unit consistency and "
            "adhere to real-world constraints (e.g., non-negative quantities). Present the "
            "final answer as a single numerical value."
        )
        solution = await self.generate(instruction=solve_instruction, context=self.problem_text)

        # Step 4: Validate and refine the solution
        revise_instruction = (
            f"Review the following solution:\n{solution}\n"
            "Critique it for correctness, consistency, and adherence to logical constraints. "
            "Check for proper handling of units, reasonable intermediate results, and a valid "
            "final answer. If any issues are found, suggest corrections and refine the solution."
        )
        refined_solution = await self.revise(instruction=revise_instruction, context=solution)

        # Step 5: Summarize the result
        summarize_instruction = (
            f"Condense the following solution into a concise summary:\n{refined_solution}\n"
            "Highlight the final answer and ensure the summary is clear and easy to understand."
        )
        final_summary = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_summary