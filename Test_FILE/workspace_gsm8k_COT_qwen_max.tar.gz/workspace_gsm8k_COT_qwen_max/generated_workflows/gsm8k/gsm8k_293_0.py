# Workflow ID: gsm8k_293_0
# Benchmark: gsm8k
# Data Indices: [444, 431]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant numerical values, relationships, and constraints
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, units, and relationships. "
            "Include any explicit or implicit mathematical operations (e.g., addition, subtraction, multiplication, division). "
            "If there are rates, proportions, or comparisons, clearly state them. "
            "Format the output as a structured list of key-value pairs."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a step-by-step solution plan
        planning_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. "
            "Identify any intermediate calculations or hidden steps that are required. "
            "Clearly specify the sequence of operations and the final computation needed to arrive at the answer."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Execute key steps in parallel
        parallel_instructions = [
            "Calculate the total sum of all numerical values involved in the problem.",
            "Compute any averages, proportions, or rates as outlined in the solution plan.",
            "Perform any additional intermediate calculations required for the final answer."
        ]
        parallel_tasks = [
            self.generate(instruction=instr, context=solution_plan)
            for instr in parallel_instructions
        ]
        parallel_results = await asyncio.gather(*parallel_tasks)

        # Step 4: Synthesize results into a final answer
        synthesis_instruction = (
            "Given the following results from parallel calculations:\n"
            f"{parallel_results}\n"
            "Combine these results into a single numerical answer. "
            "Ensure that the final answer is consistent with the problem's context and units. "
            "If any discrepancies exist, resolve them logically."
        )
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=parallel_results)

        # Step 5: Verify and refine the final answer
        refinement_instruction = (
            f"Review the following final answer:\n{final_answer}\n"
            "Check for consistency with the problem's context, units, and real-world constraints. "
            "Refine the answer if necessary to ensure accuracy and clarity."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        return refined_answer