# Workflow ID: gsm8k_366_0
# Benchmark: gsm8k
# Data Indices: [263, 668]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract known information and relationships
        extraction_instruction = (
            "Extract all numerical values, units, relationships, and constraints from the problem. "
            "Identify what is being asked and any intermediate steps required to solve the problem. "
            "Format the output as a structured list of key-value pairs."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate the mathematical model
        modeling_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. "
            "Include all intermediate calculations, ensure unit consistency, and specify the order of operations. "
            "Format the output as a numbered list of steps."
        )
        model = await self.generate(instruction=modeling_instruction, context=self.problem_text)

        # Step 3: Perform calculations
        calculation_instruction = (
            f"Execute the following plan step-by-step:\n{model}\n"
            "Perform all arithmetic operations explicitly, showing intermediate results. "
            "Ensure the final result answers the original question and include units where applicable."
        )
        calculations = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Validate the solution
        validation_instruction = (
            f"Critique the following solution:\n{calculations}\n"
            "Check for logical consistency, correct order of operations, and adherence to real-world constraints. "
            "If there are issues, suggest specific improvements."
        )
        validated_solution = await self.revise(instruction=validation_instruction, context=calculations)

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"Condense the following solution into a concise final answer:\n{validated_solution}\n"
            "Ensure the answer directly addresses the original question and includes the appropriate units."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=validated_solution)

        return final_answer