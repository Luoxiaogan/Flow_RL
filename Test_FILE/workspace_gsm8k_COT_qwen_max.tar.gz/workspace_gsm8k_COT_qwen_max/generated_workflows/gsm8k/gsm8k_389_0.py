# Workflow ID: gsm8k_389_0
# Benchmark: gsm8k
# Data Indices: [470, 146]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract known information (numerical values, relationships, constraints)
        extraction_instruction = (
            "Extract all numerical values, relationships, and constraints from the problem. "
            "Include units (e.g., dollars, hours) and explicitly state how quantities relate to each other. "
            "Provide this information in a structured format."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Model the problem mathematically
        modeling_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Translate the problem into a mathematical model. Identify all operations needed (e.g., addition, multiplication). "
            "Sequence the operations logically and include intermediate steps. Ensure unit consistency throughout."
        )
        mathematical_model = await self.generate(instruction=modeling_instruction, context=self.problem_text)

        # Step 3: Solve step-by-step
        solving_instruction = (
            f"Using the mathematical model: {mathematical_model}\n"
            "Compute the solution step-by-step. Clearly document each step with intermediate results. "
            "Check for contextual constraints (e.g., non-negative values, integer counts)."
        )
        solution = await self.generate(instruction=solving_instruction, context=self.problem_text)

        # Step 4: Verify and refine the solution
        refinement_instruction = (
            f"Review the solution: {solution}\n"
            "Critique it for accuracy, logical consistency, and contextual validity. "
            "Refine the solution if necessary, correcting any errors or inconsistencies."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=solution)

        # Step 5: Summarize the final answer
        summarization_instruction = (
            f"From the refined solution: {refined_solution}\n"
            "Extract and summarize the final numerical answer. Ensure the answer is clear, concise, and includes appropriate units if applicable."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_solution)

        return final_answer