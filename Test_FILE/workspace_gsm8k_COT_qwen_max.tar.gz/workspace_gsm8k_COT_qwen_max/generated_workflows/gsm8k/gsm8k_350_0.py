# Workflow ID: gsm8k_350_0
# Benchmark: gsm8k
# Data Indices: [664, 520]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, units, and relationships. "
            "Identify what is being asked and any constraints or conditions provided. "
            "Present the extracted information in a structured format."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan the solution approach
        planning_instruction = (
            f"Based on the following extracted information: {extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. "
            "Include all necessary calculations, intermediate steps, and unit conversions. "
            "Ensure the plan accounts for the order of operations and contextual constraints."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Execute calculations
        execution_instruction = (
            f"Follow this plan to solve the problem step-by-step: {solution_plan}\n"
            "Perform each calculation carefully, updating the context with intermediate results. "
            "Ensure all units are consistent and the final result answers the question posed."
        )
        final_result = await self.generate(instruction=execution_instruction, context=self.problem_text)

        # Step 4: Validate and refine results
        validation_instruction = (
            f"Review the following solution: {final_result}\n"
            "Critique the result for accuracy, unit consistency, and contextual validity. "
            "Refine the solution if necessary to ensure it is correct and makes sense in the problem's context."
        )
        refined_result = await self.revise(instruction=validation_instruction, context=final_result)

        # Step 5: Summarize the answer
        summarization_instruction = (
            f"Condense the following solution into a single numerical value: {refined_result}\n"
            "Ensure the answer is clear, precise, and formatted correctly."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_result)

        return final_answer