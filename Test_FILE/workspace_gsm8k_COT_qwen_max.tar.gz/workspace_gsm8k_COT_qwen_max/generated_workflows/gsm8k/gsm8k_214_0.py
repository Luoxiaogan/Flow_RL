# Workflow ID: gsm8k_214_0
# Benchmark: gsm8k
# Data Indices: [20, 762]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (numerical values, relationships, constraints)
        extraction_instruction = (
            "Carefully analyze the problem and extract all numerical values, units, and relationships. "
            "Include any implicit constraints or conditions mentioned in the problem. "
            "Format the output as a structured list for clarity."
        )
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a detailed plan to solve the problem
        plan_instruction = (
            f"Based on the following extracted information: {extraction}\n"
            "Create a detailed step-by-step plan to solve the problem. "
            "Include all intermediate calculations, unit conversions, and logical reasoning. "
            "Ensure the plan accounts for any hidden steps or implicit constraints."
        )
        plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Execute the plan and calculate the solution
        execution_instruction = (
            f"Follow this plan step-by-step: {plan}\n"
            "Perform all calculations, track units consistently, and verify intermediate results. "
            "Provide the final numerical answer along with its unit, if applicable."
        )
        solution = await self.generate(instruction=execution_instruction, context=self.problem_text)

        # Step 4: Refine and validate the solution
        refinement_instruction = (
            f"Review the following solution: {solution}\n"
            "Critique it for mathematical accuracy, logical consistency, and adherence to real-world constraints. "
            "Make any necessary corrections and provide the refined solution."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=solution)

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"Condense the following solution into a single numerical value with its unit, if applicable: {refined_solution}\n"
            "Ensure the output is concise and directly answers the question posed in the problem."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer