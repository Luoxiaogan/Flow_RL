# Workflow ID: gsm8k_297_0
# Benchmark: gsm8k
# Data Indices: [558, 241]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all numerical values, relationships, and constraints
        extraction_instruction = """
        Carefully read the problem and extract all numerical values, relationships, and constraints. 
        Identify what is being asked and list all given data explicitly. 
        If there are implicit relationships or hidden steps, infer and include them as well. 
        Format the output clearly with labels for each extracted piece of information.
        """
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Solve the problem step-by-step
        reasoning_instruction = f"""
        Using the extracted information: {extraction}
        Solve the problem step-by-step. Perform calculations in sequence, keeping track of intermediate results. 
        Ensure that each step logically follows from the previous one and aligns with the problem context. 
        If there are multiple paths to the solution, explore them systematically. 
        Format the solution clearly, showing all calculations and reasoning.
        """
        solution = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Verify and refine the solution
        refinement_instruction = """
        Critique the provided solution. Check for errors in calculations, logical inconsistencies, or overlooked details. 
        Ensure that the solution adheres to the problem constraints and makes sense in the real-world context. 
        If necessary, revise the solution to correct mistakes or improve clarity. 
        Provide a refined version of the solution with explanations for any changes made.
        """
        refined_solution = await self.revise(instruction=refinement_instruction, context=solution)

        # Step 4: Summarize the final answer
        summary_instruction = """
        Summarize the key findings and present the final answer. 
        Include only the essential information needed to understand the solution and its result. 
        Ensure that the final answer is clearly stated and formatted appropriately.
        """
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer