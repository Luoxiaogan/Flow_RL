# Workflow ID: gsm8k_234_0
# Benchmark: gsm8k
# Data Indices: [767, 771]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information from the problem
        extraction_instruction = (
            "Extract all numerical values, units, relationships, and the specific question being asked. "
            "Identify key entities and their interactions. Include any constraints or conditions mentioned in the problem."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate a detailed plan for solving the problem
        planning_instruction = f"""
        Based on the extracted information: {extracted_info}
        Create a step-by-step plan to solve the problem. Include:
        - The sequence of mathematical operations required
        - Any intermediate calculations needed
        - How to handle units and ensure consistency
        - Any real-world constraints that must be considered
        """
        plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Generate multiple solution approaches in parallel
        approach1_instruction = f"""
        Solve the problem using a direct calculation approach. Follow this plan: {plan}
        Ensure all steps are clearly explained and justified.
        """
        approach2_instruction = f"""
        Break the problem into smaller sub-problems and solve each sequentially. Follow this plan: {plan}
        Ensure all intermediate results are calculated and verified.
        """

        results = await asyncio.gather(
            self.generate(instruction=approach1_instruction, context=self.problem_text),
            self.generate(instruction=approach2_instruction, context=self.problem_text)
        )

        # Step 4: Select the best solution using Ensemble
        ensemble_instruction = """
        Evaluate the provided solutions and select the best one based on:
        - Correctness of calculations
        - Clarity of reasoning
        - Adherence to the problem constraints
        If both solutions are equally valid, choose the more concise one.
        """
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 5: Refine the selected solution if necessary
        refinement_instruction = """
        Review the solution for accuracy and completeness. Make improvements if needed, such as:
        - Correcting calculation errors
        - Clarifying ambiguous steps
        - Ensuring the final answer is explicitly stated
        """
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 6: Extract the final numerical answer
        summarization_instruction = """
        Extract the final numerical answer from the solution. Ensure it is formatted correctly as an integer or decimal.
        """
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_solution)

        return final_answer