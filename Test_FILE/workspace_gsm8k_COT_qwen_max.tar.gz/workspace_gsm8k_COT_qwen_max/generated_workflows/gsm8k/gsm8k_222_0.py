# Workflow ID: gsm8k_222_0
# Benchmark: gsm8k
# Data Indices: [270, 761]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract known values and relationships
        extract_instruction = (
            "Extract all numerical values, units, and relationships (e.g., percentages, rates, or operations) "
            "from the problem. Clearly label each piece of information and describe its role in the problem."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Formulate a step-by-step solution plan
        plan_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Create a detailed step-by-step plan to solve the problem. Include all necessary calculations, "
            "intermediate steps, and the order of operations. Ensure the plan is clear and logically consistent."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 3: Perform calculations step-by-step
        calculate_instruction = (
            f"Execute the following solution plan step-by-step:\n{solution_plan}\n"
            "Perform each calculation carefully and document the intermediate results. Verify that each step "
            "is consistent with the problem context and the previous steps."
        )
        calculations = await self.generate(instruction=calculate_instruction, context=self.problem_text)

        # Step 4: Revise and refine calculations
        revise_instruction = (
            "Critique and refine the following calculations:\n"
            f"{calculations}\n"
            "Ensure that each step is accurate, logically sound, and consistent with the problem context. "
            "Correct any errors and provide improved results if necessary."
        )
        refined_calculations = await self.revise(instruction=revise_instruction, context=calculations)

        # Step 5: Summarize intermediate results
        summarize_instruction = (
            "Summarize the following refined calculations:\n"
            f"{refined_calculations}\n"
            "Highlight the key intermediate results and ensure the logic flows correctly. Verify that no "
            "steps were missed and that the results make sense in the context of the problem."
        )
        summary = await self.summarize(instruction=summarize_instruction, context=refined_calculations)

        # Step 6: Extract the final numerical answer
        final_instruction = (
            "Extract the final numerical answer from the following summary:\n"
            f"{summary}\n"
            "Ensure the answer is concise, accurate, and directly addresses the question posed in the problem."
        )
        final_answer = await self.generate(instruction=final_instruction, context=summary)

        return final_answer