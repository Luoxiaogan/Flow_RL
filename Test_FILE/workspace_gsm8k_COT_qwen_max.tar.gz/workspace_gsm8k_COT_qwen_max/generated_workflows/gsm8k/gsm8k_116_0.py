# Workflow ID: gsm8k_116_0
# Benchmark: gsm8k
# Data Indices: [322, 671]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract key information (numerical values, units, relationships)
        extraction = await self.generate(
            instruction="Extract all numerical values, units, and relationships mentioned in the problem. "
                        "Identify what is known and what needs to be calculated. "
                        "Ensure you capture all constraints and contextual details.",
            context=self.problem_text
        )

        # Step 2: Formulate a solution plan
        plan = await self.generate(
            instruction=f"Based on the extracted information: {extraction}, "
                        "create a detailed step-by-step plan to solve the problem. "
                        "Include intermediate calculations, unit conversions, and the order of operations. "
                        "Ensure the plan accounts for all constraints and contextual details.",
            context=self.problem_text
        )

        # Step 3: Execute calculations in parallel
        calculation_steps = [
            "Calculate the first intermediate value based on the plan.",
            "Calculate the second intermediate value based on the plan.",
            "Calculate the third intermediate value based on the plan."
        ]
        calculation_tasks = [
            self.generate(instruction=f"{step} Plan: {plan}", context=self.problem_text)
            for step in calculation_steps
        ]
        intermediate_results = await asyncio.gather(*calculation_tasks)

        # Step 4: Validate intermediate results
        revised_results = await asyncio.gather(
            *[self.revise(instruction="Critique and refine this result to ensure accuracy and consistency with the problem context.", context=result)
              for result in intermediate_results]
        )

        # Step 5: Synthesize final answer
        final_answer = await self.ensemble(
            instruction="Combine the refined intermediate results into a single final answer. "
                        "Ensure the answer is a single numerical value, formatted appropriately, and makes sense in the problem's context.",
            contexts=revised_results
        )

        # Step 6: Summarize the reasoning process
        summary = await self.summarize(
            instruction="Summarize the entire reasoning process, including the extracted information, solution plan, intermediate results, and final answer.",
            context=self.problem_text
        )

        return final_answer, summary