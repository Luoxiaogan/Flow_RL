# Workflow ID: gsm8k_336_0
# Benchmark: gsm8k
# Data Indices: [355, 623]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract known information
        extraction_instruction = (
            "Extract all numerical values, units, and relationships from the problem. "
            "Identify quantities, costs, rates, percentages, or other mathematical entities. "
            "Ensure the extracted information is comprehensive and structured."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Identify unknowns and relationships
        analysis_instruction = (
            f"Given the extracted information: {extracted_info}, analyze the problem to determine "
            "what is being asked (the unknown) and how the known values relate to it. "
            "Identify whether the problem involves sequential operations, proportions, rates, or comparisons."
        )
        analysis = await self.generate(instruction=analysis_instruction, context=self.problem_text)

        # Step 3: Plan the solution
        plan_instruction = (
            f"Based on the analysis: {analysis}, create a detailed step-by-step plan to solve the problem. "
            "Include the order of operations, intermediate calculations, and unit handling. "
            "Ensure the plan is clear, logical, and adaptable to similar problems."
        )
        solution_plan = await self.generate(instruction=plan_instruction, context=self.problem_text)

        # Step 4: Execute calculations
        calculation_instruction = (
            f"Follow the solution plan: {solution_plan}. Perform all calculations step by step. "
            "If there are independent calculations, execute them in parallel. Ensure all intermediate "
            "results are explicitly stated and accurate."
        )
        # Example of parallel execution for independent calculations
        calculations = await asyncio.gather(
            self.generate(instruction=calculation_instruction, context="Step 1: Calculate first part."),
            self.generate(instruction=calculation_instruction, context="Step 2: Calculate second part.")
        )
        combined_results = "\n".join(calculations)

        # Step 5: Verify and finalize
        verification_instruction = (
            f"Review the calculations: {combined_results}. Validate their accuracy and alignment "
            "with the problem's context. Check for unit consistency and logical correctness. "
            "Refine any discrepancies or errors."
        )
        verified_solution = await self.revise(instruction=verification_instruction, context=combined_results)

        # Step 6: Summarize the final answer
        summary_instruction = (
            f"Condense the verified solution: {verified_solution} into a single numerical value. "
            "Ensure the result is precise and formatted correctly."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=verified_solution)

        return final_answer