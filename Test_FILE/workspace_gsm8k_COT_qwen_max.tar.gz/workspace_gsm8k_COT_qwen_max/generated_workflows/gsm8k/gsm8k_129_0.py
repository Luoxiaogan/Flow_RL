# Workflow ID: gsm8k_129_0
# Benchmark: gsm8k
# Data Indices: [326, 678]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information from the problem
        extraction_instruction = (
            "Extract all numerical values, entities, and relationships mentioned in the problem. "
            "Include details about initial and final states, changes, and constraints. "
            "Format the output as a structured list for clarity."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Identify the specific question being asked
        question_instruction = (
            f"Based on the extracted information: {extracted_info}, identify the specific question being asked. "
            "Clearly state what needs to be calculated or determined. "
            "Provide this in a concise sentence."
        )
        identified_question = await self.generate(instruction=question_instruction, context=self.problem_text)

        # Step 3: Generate multiple solution approaches in parallel
        approach_1_instruction = (
            f"Given the extracted information: {extracted_info} and the identified question: {identified_question}, "
            "solve the problem step by step using direct calculation. "
            "Show all intermediate steps and ensure unit consistency. "
            "Provide the final numerical answer at the end."
        )
        approach_2_instruction = (
            f"Given the extracted information: {extracted_info} and the identified question: {identified_question}, "
            "verify the solution by working backward from the final state to the initial state. "
            "Ensure all steps logically align with the problem description. "
            "Provide the final numerical answer at the end."
        )
        results = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text)
        )

        # Step 4: Ensemble the results to select the best solution
        ensemble_instruction = (
            "Compare the two provided solutions and select the most accurate and reliable result. "
            "If there are discrepancies, explain why one solution is preferred over the other. "
            "Provide the final numerical answer."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 5: Revise the final solution for clarity and correctness
        revision_instruction = (
            "Review the final solution for accuracy and clarity. "
            "Ensure all steps are correct, units are consistent, and the answer makes sense in the problem context. "
            "Make any necessary corrections."
        )
        revised_solution = await self.revise(instruction=revision_instruction, context=final_solution)

        # Step 6: Extract the final numerical answer
        answer_extraction_instruction = (
            f"From the revised solution: {revised_solution}, extract the final numerical answer. "
            "Ensure it is presented as a single number without additional text."
        )
        final_answer = await self.generate(instruction=answer_extraction_instruction, context=revised_solution)

        return final_answer