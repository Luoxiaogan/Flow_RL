# Workflow ID: high_level_math_ganluo_9_0
# Benchmark: high_level_math_ganluo
# Data Indices: [96, 52]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify structure and key constraints
        analysis = await self.generate("Analyze the problem to determine its mathematical category (e.g., algebra, geometry, combinatorics) and extract all given conditions.")

        # Step 2: Parallel exploration of multiple solution strategies
        task1 = self.generate("Generate an algebraic approach focusing on simplifying expressions or applying inequalities like AM-GM.")
        task2 = self.generate("Generate a geometric interpretation if applicable (e.g., coordinate geometry, symmetry).")
        task3 = self.generate("Generate a strategy based on substitution or transformation to reduce complexity.")
        
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble to select the most promising path
        ensemble_summary = await self.ensemble(
            instruction="Evaluate the three candidate approaches and select the one that appears most likely to yield a correct and efficient solution.",
            contexts_to_ensemble=solutions
        )

        # Step 4: Generate full solution using the selected strategy
        final_solution = await self.generate(
            instruction="Using the selected strategy, now write a complete step-by-step solution with clear reasoning.",
            context=ensemble_summary
        )

        # Step 5: Revise for correctness and clarity
        revised_solution = await self.revise(
            instruction="Critically review the solution for logical gaps, computational errors, and clarity. Improve if necessary.",
            context_to_revise=final_solution
        )

        # Step 6: Final verification via bidirectional check
        verification = await self.generate(
            instruction="Now generate a reverse-checking process: derive the original expression from the final answer and confirm consistency.",
            context=revised_solution
        )

        # Step 7: Final ensemble — combine original solution and verification for robustness
        final_answer = await self.ensemble(
            instruction="Based on the main solution and the verification, output the final integer answer only (0–999).",
            contexts_to_ensemble=[revised_solution, verification]
        )

        return final_answer