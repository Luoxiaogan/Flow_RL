# Workflow ID: high_level_math_ganluo_25_0
# Benchmark: high_level_math_ganluo
# Data Indices: [111, 57]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis – Understand the problem structure and key elements
        analysis = await self.generate(
            instruction="Analyze the problem to identify its category (e.g., algebra, geometry, combinatorics), constraints, variables, and what needs to be computed."
        )

        # Step 2: Generate Multiple Solution Approaches in Parallel
        approach1 = self.generate(
            instruction="Generate an algebraic solution strategy based on the problem's equations or expressions."
        )
        approach2 = self.generate(
            instruction="Generate a geometric or visual reasoning approach if applicable (e.g., coordinate system, area ratios)."
        )
        approach3 = self.generate(
            instruction="Generate a case-based or combinatorial method if the problem involves counting or discrete structures."
        )

        # Run all approaches in parallel
        approaches = await asyncio.gather(approach1, approach2, approach3)

        # Step 3: Ensemble the best approach based on internal consistency and clarity
        selected_strategy = await self.ensemble(
            instruction="Select the most promising solution path by comparing the three generated strategies. Prioritize clarity, feasibility, and alignment with the problem type.",
            contexts_to_ensemble=approaches
        )

        # Step 4: Generate a full solution using the selected strategy
        solution_draft = await self.generate(
            instruction="Now write a detailed step-by-step solution using the selected strategy. Include all necessary mathematical steps and justifications.",
            context=selected_strategy
        )

        # Step 5: Revise for correctness and completeness
        revised_solution = await self.revise(
            instruction="Critically review the solution draft. Check for logical gaps, missing cases, incorrect assumptions, or arithmetic errors. Improve clarity and rigor.",
            context_to_revise=solution_draft
        )

        # Step 6: Final Verification via Bidirectional Reasoning
        verification = await self.generate(
            instruction="Create an inverse check: Given the final answer, derive the conditions that must hold. Verify that they match the original problem constraints.",
            context=revised_solution
        )

        # Step 7: Final Ensemble – Use both original solution and verification to produce a robust answer
        final_answer = await self.ensemble(
            instruction="Combine the revised solution and the verification step to produce a confident, accurate integer answer between 0 and 999. Ensure it satisfies all constraints.",
            contexts_to_ensemble=[revised_solution, verification]
        )

        return final_answer