# Workflow ID: high_level_math_ganluo_23_0
# Benchmark: high_level_math_ganluo
# Data Indices: [94, 118]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis
        analysis = await self.generate(
            instruction="Analyze the problem to identify the mathematical domain (e.g., algebra, geometry, number theory) and key constraints or relationships."
        )

        # Step 2: Extract Core Mathematical Structure
        structure = await self.generate(
            instruction="From the analysis, extract the essential equations, identities, or geometric properties that define the problem.",
            context=analysis
        )

        # Step 3: Parallel Exploration of Multiple Solution Paths
        task1 = self.generate(
            instruction="Solve using algebraic manipulation: express all variables in terms of one unknown and solve the system.",
            context=structure
        )
        task2 = self.generate(
            instruction="Solve using trigonometric identities or geometric interpretation if applicable.",
            context=structure
        )
        task3 = self.generate(
            instruction="Try substitution or symmetry-based simplification based on the structure.",
            context=structure
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer from Competing Solutions
        final_answer = await self.ensemble(
            instruction="Compare the three proposed solutions. Identify which one satisfies all constraints and yields an integer between 0 and 999. If there's disagreement, choose the most mathematically consistent one.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional Refinement Loop (if answer seems uncertain)
        if "likely" in final_answer.lower() or "ambiguous" in final_answer.lower():
            refined = await self.revise(
                instruction="Revise the solution by checking for edge cases, verifying consistency with original constraints, and ensuring the answer is an integer between 0 and 999.",
                context_to_revise=final_answer
            )
            return refined

        return final_answer