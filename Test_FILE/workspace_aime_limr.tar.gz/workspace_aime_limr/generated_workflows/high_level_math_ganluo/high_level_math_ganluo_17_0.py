# Workflow ID: high_level_math_ganluo_17_0
# Benchmark: high_level_math_ganluo
# Data Indices: [80, 18]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand the problem structure and identify key elements
        analysis = await self.generate(
            instruction="Analyze the problem to identify the mathematical domain (e.g., combinatorics, number theory), key constraints, and what is being asked. Extract all relevant numerical or structural facts."
        )

        # Step 2: Parallel Exploration — Generate multiple solution strategies
        task1 = self.generate(
            instruction="Propose an algebraic approach based on the problem's structure.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Propose a geometric or visual interpretation if applicable.",
            context=analysis
        )
        task3 = self.generate(
            instruction="Propose a combinatorial or probabilistic method if the problem involves counting or chance.",
            context=analysis
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble — Synthesize the best solution from competing approaches
        final_solution = await self.ensemble(
            instruction="Compare the three proposed solutions. Select the most mathematically sound and complete one that directly answers the question with clear reasoning.",
            contexts_to_ensemble=solutions
        )

        # Step 4: Refinement — Revise the selected solution using error-checking heuristics
        revised_solution = await self.revise(
            instruction="Review the solution carefully for logical consistency, correctness of calculations, and whether it satisfies all constraints in the original problem. Fix any errors or gaps.",
            context_to_revise=final_solution
        )

        # Step 5: Final Verification — Ensure the answer is an integer between 0 and 999
        verification = await self.generate(
            instruction="Verify that the final answer is an integer between 0 and 999, and that it logically follows from the steps. If not, suggest corrections.",
            context=revised_solution
        )

        return verification