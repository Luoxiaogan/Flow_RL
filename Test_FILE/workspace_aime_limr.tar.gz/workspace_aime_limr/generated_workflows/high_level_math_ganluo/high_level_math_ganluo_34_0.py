# Workflow ID: high_level_math_ganluo_34_0
# Benchmark: high_level_math_ganluo
# Data Indices: [37, 103]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand the problem structure and identify key techniques
        analysis = await self.generate(
            instruction="Analyze the problem to determine its mathematical category (e.g., algebra, combinatorics, optimization) and identify potential solution strategies such as symmetry, substitution, or recursive methods."
        )

        # Step 2: Parallel Exploration — Generate multiple distinct solution paths
        task1 = self.generate(
            instruction="Assume this is an optimization problem. Use calculus or inequality techniques like AM-GM to find maximum value.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Assume this is a constraint-based problem. Try using Lagrange multipliers or variable substitution to reduce variables.",
            context=analysis
        )
        task3 = self.generate(
            instruction="Assume this is a pattern-recognition problem. Look for symmetries or substitutions that simplify the expression.",
            context=analysis
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble — Select the best solution from competing approaches
        final_solution = await self.ensemble(
            instruction="Evaluate the three candidate solutions. Choose the one that is most mathematically sound, consistent with constraints, and likely correct based on internal consistency checks.",
            contexts_to_ensemble=solutions
        )

        # Step 4: Refinement — Revise the chosen solution for clarity, correctness, and completeness
        refined_solution = await self.revise(
            instruction="Check if the solution satisfies all constraints and makes logical sense. Improve clarity, fix any errors, and ensure it's fully justified.",
            context_to_revise=final_solution
        )

        # Step 5: Final Summary — Condense the reasoning into a clear answer format
        summary = await self.summarize(
            context_to_summarize=refined_solution
        )

        return summary