# Workflow ID: high_level_math_ganluo_28_0
# Benchmark: high_level_math_ganluo
# Data Indices: [84, 72]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand problem structure and category
        analysis = await self.generate(
            instruction="Identify the mathematical domain (e.g., algebra, geometry, number theory) and key constraints in this problem."
        )

        # Step 2: Parallel Exploration — Generate multiple solution paths
        task1 = self.generate(
            instruction="Propose an algebraic approach to solve this problem, assuming it involves polynomials or complex numbers.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Propose a geometric or coordinate-based approach if applicable.",
            context=analysis
        )
        task3 = self.generate(
            instruction="Propose a combinatorial or number-theoretic method if relevant.",
            context=analysis
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble — Synthesize best solution from competing approaches
        final_solution = await self.ensemble(
            instruction="Compare all three proposed methods and select the most promising one based on clarity, correctness, and alignment with problem constraints.",
            contexts_to_ensemble=solutions
        )

        # Step 4: Refinement Loop — Revise the selected solution iteratively
        revised_solution = final_solution
        for _ in range(2):  # Two rounds of refinement
            revised_solution = await self.revise(
                instruction="Check for logical errors, missing steps, or unclear reasoning in the current solution. Improve clarity and completeness.",
                context_to_revise=revised_solution
            )

        # Step 5: Final Summary & Output
        final_output = await self.summarize(
            context_to_summarize=revised_solution
        )

        return final_output