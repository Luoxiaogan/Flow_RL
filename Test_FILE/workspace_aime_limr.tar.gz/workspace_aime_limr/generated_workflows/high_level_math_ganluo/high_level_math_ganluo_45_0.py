# Workflow ID: high_level_math_ganluo_45_0
# Benchmark: high_level_math_ganluo
# Data Indices: [73, 79]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify problem type and key constraints
        analysis = await self.generate(
            instruction="Identify the mathematical domain (e.g., algebra, geometry, number theory) and key constraints in the problem."
        )

        # Step 2: Generate multiple solution strategies based on domain
        strategies = await asyncio.gather(
            self.generate(instruction="Propose an algebraic approach to solve this problem.", context=analysis),
            self.generate(instruction="Propose a geometric or coordinate-based approach if applicable.", context=analysis),
            self.generate(instruction="Propose a combinatorial or probabilistic approach if relevant.", context=analysis)
        )

        # Step 3: Summarize each strategy to extract core reasoning
        summarized_strategies = await asyncio.gather(
            self.summarize(strategies[0]),
            self.summarize(strategies[1]),
            self.summarize(strategies[2])
        )

        # Step 4: Ensemble to select the most promising strategy
        selected_strategy = await self.ensemble(
            instruction="Choose the most viable solution path based on clarity, feasibility, and alignment with known techniques.",
            contexts_to_ensemble=summarized_strategies
        )

        # Step 5: Generate full solution using selected strategy
        solution_draft = await self.generate(
            instruction="Using the selected strategy, generate a complete step-by-step solution.",
            context=selected_strategy
        )

        # Step 6: Revise iteratively to improve accuracy and correctness
        revised_solution = await self.revise(
            instruction="Check for logical consistency, mathematical rigor, and verification of all constraints. Correct any errors or omissions.",
            context_to_revise=solution_draft
        )

        # Step 7: Final ensemble — validate against alternative interpretations
        final_answer = await self.ensemble(
            instruction="Given the revised solution, now determine the final integer answer. If multiple answers emerge, select the one that satisfies all conditions.",
            contexts_to_ensemble=[revised_solution]
        )

        return final_answer