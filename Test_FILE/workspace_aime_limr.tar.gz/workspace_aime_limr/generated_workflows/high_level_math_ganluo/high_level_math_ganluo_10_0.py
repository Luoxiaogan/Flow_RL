# Workflow ID: high_level_math_ganluo_10_0
# Benchmark: high_level_math_ganluo
# Data Indices: [50, 106]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify problem type and key constraints
        analysis = await self.generate(
            instruction="Analyze the problem structure: determine if it's algebraic, geometric, combinatorial, or number-theoretic. Identify all constraints and variables."
        )

        # Step 2: Generate multiple solution strategies in parallel (Diverge)
        strategy_tasks = [
            self.generate(instruction="Propose an algebraic approach to solve this problem."),
            self.generate(instruction="Propose a number theory approach to solve this problem."),
            self.generate(instruction="Propose a geometric or coordinate-based approach if applicable."),
            self.generate(instruction="Propose a case-based or recursive approach if applicable.")
        ]
        strategies = await asyncio.gather(*strategy_tasks)

        # Step 3: Summarize each strategy for clarity and consistency
        summarized_strategies = []
        for i, strategy in enumerate(strategies):
            summary = await self.summarize(strategy)
            summarized_strategies.append(summary)

        # Step 4: Ensemble the best approach based on feasibility and alignment with problem constraints
        best_strategy = await self.ensemble(
            instruction="Select the most promising solution path based on clarity, mathematical soundness, and relevance to the original constraints.",
            contexts_to_ensemble=summarized_strategies
        )

        # Step 5: Generate full solution using the chosen strategy
        full_solution = await self.generate(
            instruction="Using the selected strategy, provide a complete step-by-step solution, including all necessary derivations and final answer as an integer between 0 and 999.",
            context=best_strategy
        )

        # Step 6: Revise solution iteratively to fix errors or improve clarity
        revised_solution = await self.revise(
            instruction="Review the solution for logical consistency, correctness of steps, and proper application of mathematical principles. Fix any issues found.",
            context_to_revise=full_solution
        )

        # Step 7: Final ensemble to ensure robustness — compare with alternative valid approaches if needed
        final_answer = await self.ensemble(
            instruction="Return only the final integer answer that satisfies all constraints and makes mathematical sense. If multiple answers exist, choose the one consistent with the problem’s goal (e.g., 'least possible value').",
            contexts_to_ensemble=[revised_solution]
        )

        return final_answer