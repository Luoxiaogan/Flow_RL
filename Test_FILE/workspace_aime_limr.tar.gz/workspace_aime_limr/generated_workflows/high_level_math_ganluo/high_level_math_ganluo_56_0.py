# Workflow ID: high_level_math_ganluo_56_0
# Benchmark: high_level_math_ganluo
# Data Indices: [42, 69]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand problem structure and category
        analysis = await self.generate(
            instruction="Analyze the problem and identify its mathematical domain (e.g., number theory, geometry, combinatorics) and key constraints."
        )

        # Step 2: Extract structured information from the problem
        extracted = await self.generate(
            instruction="From the problem statement, extract all relevant numerical values, variables, equations, and conditions.",
            context=analysis
        )

        # Step 3: Parallel exploration of multiple solution paths
        task1 = self.generate(
            instruction="Propose an algebraic approach to solve this problem based on the extracted elements."
        )
        task2 = self.generate(
            instruction="Propose a geometric or coordinate-based approach if applicable."
        )
        task3 = self.generate(
            instruction="Propose a number-theoretic or modular arithmetic approach if applicable."
        )
        task4 = self.generate(
            instruction="Propose a combinatorial or probabilistic approach if applicable."
        )
        solutions = await asyncio.gather(task1, task2, task3, task4)

        # Step 4: Ensemble to select the best solution path
        ensemble_result = await self.ensemble(
            instruction="Evaluate and synthesize the four proposed approaches. Choose the most promising one based on clarity, feasibility, and alignment with the problem's structure.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Generate detailed step-by-step solution using selected path
        solution_draft = await self.generate(
            instruction="Using the chosen approach, generate a complete, step-by-step solution with clear reasoning for each step.",
            context=ensemble_result
        )

        # Step 6: Revise for accuracy and rigor
        final_solution = await self.revise(
            instruction="Critically review the solution draft. Check for logical gaps, calculation errors, and ensure all constraints are satisfied. Improve clarity and completeness.",
            context_to_revise=solution_draft
        )

        # Step 7: Final verification by summarizing and validating
        summary = await self.summarize(context_to_summarize=final_solution)
        verification = await self.generate(
            instruction="Based on the summary, verify that the final answer is an integer between 0 and 999 and satisfies all original constraints.",
            context=summary
        )

        return verification