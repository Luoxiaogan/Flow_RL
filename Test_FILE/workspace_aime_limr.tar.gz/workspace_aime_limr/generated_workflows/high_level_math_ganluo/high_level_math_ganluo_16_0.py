# Workflow ID: high_level_math_ganluo_16_0
# Benchmark: high_level_math_ganluo
# Data Indices: [40, 17]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand structure and domain
        analysis = await self.generate(
            instruction="Analyze the problem to identify its mathematical domain (e.g., combinatorics, geometry, number theory), key constraints, and potential solution strategies."
        )

        # Step 2: Parallel Exploration — Generate multiple distinct approaches
        task1 = self.generate(
            instruction="Generate an algebraic approach to solve this problem, focusing on known formulas or identities relevant to its domain.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Generate a geometric or coordinate-based approach if applicable, converting visual or spatial elements into equations.",
            context=analysis
        )
        task3 = self.generate(
            instruction="Generate a combinatorial or recursive strategy if the problem involves counting, sequences, or symmetry.",
            context=analysis
        )

        # Run all approaches in parallel
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble — Select best-supported solution based on consistency and clarity
        final_answer = await self.ensemble(
            instruction="Evaluate the three candidate solutions and select the one that is most mathematically sound, consistent with the problem constraints, and clearly derived.",
            contexts_to_ensemble=solutions
        )

        # Step 4: Iterative Refinement — Revise for precision and edge-case correctness
        refined_answer = await self.revise(
            instruction="Review the selected solution carefully for logical gaps, arithmetic errors, or missed edge cases. Ensure it satisfies all conditions of the original problem.",
            context_to_revise=final_answer
        )

        return refined_answer