# Workflow ID: high_level_math_ganluo_22_0
# Benchmark: high_level_math_ganluo
# Data Indices: [54, 56]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand the problem type and structure
        analysis = await self.generate(
            instruction="Analyze the problem to determine its category (e.g., algebra, geometry, combinatorics) and key constraints."
        )

        # Step 2: Generate Multiple Solution Paths — Use parallel exploration for robustness
        task1 = self.generate(instruction="Generate an algebraic approach to solve this problem.", context=analysis)
        task2 = self.generate(instruction="Generate a geometric or visual interpretation if applicable.", context=analysis)
        task3 = self.generate(instruction="Generate a case-based or recursive strategy if relevant.", context=analysis)
        
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble Final Answer — Compare and synthesize diverse approaches
        final_answer = await self.ensemble(
            instruction="Compare the three candidate solutions and select the most consistent, mathematically sound answer.",
            contexts_to_ensemble=solutions
        )

        # Step 4: Revise for Precision — Validate against potential errors or edge cases
        refined_answer = await self.revise(
            instruction="Check the selected solution for logical consistency, boundary conditions, and correctness of all steps.",
            context_to_revise=final_answer
        )

        return refined_answer