# Workflow ID: high_level_math_ganluo_46_0
# Benchmark: high_level_math_ganluo
# Data Indices: [70, 8]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify problem type and structure
        analysis = await self.generate(
            instruction="Analyze the problem to determine its category (e.g., algebra, number theory, geometry) and key constraints."
        )

        # Step 2: Generate multiple solution strategies in parallel
        strategy_tasks = [
            self.generate(instruction="Propose an algebraic approach based on the problem's structure."),
            self.generate(instruction="Propose a geometric or coordinate-based approach if applicable."),
            self.generate(instruction="Propose a number-theoretic or modular arithmetic approach if relevant.")
        ]
        strategies = await asyncio.gather(*strategy_tasks)

        # Step 3: Summarize each strategy to reduce noise and extract core ideas
        summarized_strategies = [
            await self.summarize(strategy) for strategy in strategies
        ]

        # Step 4: Ensemble the top candidate(s) — select the most promising path
        best_approach = await self.ensemble(
            instruction="Select the most coherent and mathematically sound approach from the candidates.",
            contexts_to_ensemble=summarized_strategies
        )

        # Step 5: Generate a full solution using the chosen approach
        solution = await self.generate(
            instruction="Using the selected approach, generate a complete step-by-step solution.",
            context=best_approach
        )

        # Step 6: Refine the solution through iterative revision
        revised_solution = await self.revise(
            instruction="Review the solution for logical consistency, mathematical rigor, and completeness. Fix any errors or gaps.",
            context_to_revise=solution
        )

        # Step 7: Final verification — check that the answer satisfies all constraints
        final_answer = await self.generate(
            instruction="Based on the refined solution, extract only the final integer answer (0–999).",
            context=revised_solution
        )

        return final_answer