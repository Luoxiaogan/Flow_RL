# Workflow ID: high_level_math_ganluo_39_0
# Benchmark: high_level_math_ganluo
# Data Indices: [71, 64]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify problem type and key constraints
        analysis = await self.generate(
            instruction="Identify the mathematical domain (e.g., algebra, geometry, number theory) and list all explicit constraints from the problem."
        )

        # Step 2: Parallel exploration of multiple solution strategies
        strategy_tasks = [
            self.generate(
                instruction="Propose an algebraic approach to solve this problem.",
                context=analysis
            ),
            self.generate(
                instruction="Propose a geometric or coordinate-based approach if applicable.",
                context=analysis
            ),
            self.generate(
                instruction="Propose a combinatorial or case-based approach if applicable.",
                context=analysis
            )
        ]
        strategies = await asyncio.gather(*strategy_tasks)

        # Step 3: Ensemble the best strategy based on feasibility and clarity
        best_strategy = await self.ensemble(
            instruction="Select the most promising solution strategy based on clarity, applicability, and simplicity.",
            contexts_to_ensemble=strategies
        )

        # Step 4: Generate a detailed step-by-step solution using the selected strategy
        solution_draft = await self.generate(
            instruction="Using the selected strategy, generate a complete, logically structured solution with all steps clearly explained.",
            context=best_strategy
        )

        # Step 5: Revise the solution iteratively to fix errors or improve clarity
        revised_solutions = []
        for _ in range(2):  # Two refinement cycles
            revision = await self.revise(
                instruction="Check for logical gaps, arithmetic errors, or unclear steps. Improve clarity and correctness.",
                context_to_revise=solution_draft
            )
            revised_solutions.append(revision)
            solution_draft = revision

        # Step 6: Final ensemble of refined solutions to ensure robustness
        final_answer = await self.ensemble(
            instruction="From the revised solutions, select the most consistent and mathematically sound answer.",
            contexts_to_ensemble=revised_solutions
        )

        return final_answer