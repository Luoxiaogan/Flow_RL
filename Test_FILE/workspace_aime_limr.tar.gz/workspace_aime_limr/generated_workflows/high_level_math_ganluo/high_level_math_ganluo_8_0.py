# Workflow ID: high_level_math_ganluo_8_0
# Benchmark: high_level_math_ganluo
# Data Indices: [30, 98]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand the structure and key elements
        analysis = await self.generate(
            instruction="Analyze the problem to identify the mathematical domain (e.g., probability, geometry, algebra), key variables, constraints, and required output format."
        )

        # Step 2: Parallel Exploration — Generate multiple solution paths
        task1 = self.generate(
            instruction="Propose an algebraic approach to solve this problem.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Propose a geometric or coordinate-based approach if applicable.",
            context=analysis
        )
        task3 = self.generate(
            instruction="Propose a combinatorial or probabilistic approach if applicable.",
            context=analysis
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble — Synthesize the best approach from diverse strategies
        ensemble_summary = await self.ensemble(
            instruction="Compare the three proposed approaches and select the most promising one based on clarity, feasibility, and alignment with known techniques for this problem type.",
            contexts_to_ensemble=solutions
        )

        # Step 4: Detailed Solution Generation
        detailed_solution = await self.generate(
            instruction="Using the selected approach, provide a step-by-step solution with clear reasoning at each stage.",
            context=ensemble_summary
        )

        # Step 5: Refinement Loop — Improve solution through iterative feedback
        refined_solution = await self.revise(
            instruction="Critically review the solution for logical gaps, missing edge cases, or computational errors. Correct any issues found.",
            context_to_revise=detailed_solution
        )

        # Step 6: Final Verification — Ensure answer satisfies all constraints
        verification = await self.generate(
            instruction="Verify that the final answer is an integer between 0 and 999 and makes mathematical sense given the original problem constraints.",
            context=refined_solution
        )

        return verification