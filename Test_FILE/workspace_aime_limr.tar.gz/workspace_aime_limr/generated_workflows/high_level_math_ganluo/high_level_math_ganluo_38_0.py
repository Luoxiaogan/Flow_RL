# Workflow ID: high_level_math_ganluo_38_0
# Benchmark: high_level_math_ganluo
# Data Indices: [63, 65]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify problem type and structure
        analysis = await self.generate(
            instruction="Identify the mathematical domain (e.g., geometry, algebra, number theory) and key constraints from the problem."
        )

        # Step 2: Generate multiple solution paths based on detected domains
        tasks = [
            self.generate(
                instruction="Generate a geometric approach focusing on coordinate geometry or synthetic reasoning.",
                context=analysis
            ),
            self.generate(
                instruction="Generate an algebraic approach using equations, variables, and constraints.",
                context=analysis
            ),
            self.generate(
                instruction="Generate a parametric or locus-based method if the problem involves sets of points.",
                context=analysis
            )
        ]
        candidate_solutions = await asyncio.gather(*tasks)

        # Step 3: Summarize each candidate to extract key insights
        summaries = [await self.summarize(sol) for sol in candidate_solutions]

        # Step 4: Ensemble the best solution based on internal consistency and clarity
        final_solution = await self.ensemble(
            instruction="Select the most mathematically sound and complete solution from the candidates.",
            contexts_to_ensemble=summaries
        )

        # Step 5: Revise for correctness — test against constraints and verify form
        revised_solution = await self.revise(
            instruction="Check that the final solution satisfies all given conditions and matches the required format (e.g., integer coefficients, gcd condition).",
            context_to_revise=final_solution
        )

        return revised_solution