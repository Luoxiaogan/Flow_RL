# Workflow ID: high_level_math_ganluo_44_0
# Benchmark: high_level_math_ganluo
# Data Indices: [41, 82]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand the structure and type of problem
        analysis = await self.generate(
            instruction="Analyze the problem to determine its mathematical category (e.g., algebra, geometry, number theory) and identify key constraints or variables."
        )

        # Step 2: Parallel Exploration — Try multiple solution strategies
        task1 = self.generate(
            instruction="If this is an algebraic problem involving polynomials, apply Vieta's formulas to express relationships between roots and coefficients.",
            context=analysis
        )
        task2 = self.generate(
            instruction="If this involves trigonometric identities, consider using multiple-angle formulas or Chebyshev polynomials.",
            context=analysis
        )
        task3 = self.generate(
            instruction="If it's about finding minimal values or extremal conditions, explore calculus-based optimization or inequality constraints.",
            context=analysis
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble — Compare and select best-supported approach
        ensemble_result = await self.ensemble(
            instruction="Evaluate the three candidate solutions based on mathematical coherence, correctness of assumptions, and alignment with problem constraints. Choose the one that most rigorously satisfies all conditions.",
            contexts_to_ensemble=solutions
        )

        # Step 4: Refinement — Revise for precision and edge cases
        final_solution = await self.revise(
            instruction="Critically examine the selected solution for logical gaps, computational errors, or missed edge cases. Ensure every step follows from valid premises and that the final answer is an integer between 0 and 999.",
            context_to_revise=ensemble_result
        )

        # Step 5: Final Verification — Bidirectional check if possible
        verification = await self.generate(
            instruction="Generate a concise inverse verification: if the proposed answer were correct, what would be the expected outcome? Does it satisfy the original problem’s constraints?",
            context=final_solution
        )

        # Step 6: Return final result
        return final_solution