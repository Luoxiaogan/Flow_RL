# Workflow ID: high_level_math_ganluo_11_0
# Benchmark: high_level_math_ganluo
# Data Indices: [45, 10]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify problem type and key constraints
        analysis = await self.generate(
            instruction="Analyze the problem to determine its category (e.g., combinatorics, number theory) and extract all explicit constraints and hidden structures."
        )

        # Step 2: Parallel exploration of multiple solution paths
        task1 = self.generate(
            instruction="Generate a combinatorial approach focusing on counting arrangements under given rules.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Generate a recursive or dynamic programming approach if applicable.",
            context=analysis
        )
        task3 = self.generate(
            instruction="Generate a symmetry-based or case-analysis approach if the problem has symmetries or distinct cases.",
            context=analysis
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble to select best-supported solution
        final_solution = await self.ensemble(
            instruction="Evaluate the three candidate solutions and select the most logically consistent and mathematically sound one based on internal coherence and adherence to constraints.",
            contexts_to_ensemble=solutions
        )

        # Step 4: Revise for precision and error-checking
        refined_solution = await self.revise(
            instruction="Critically review the selected solution for potential logical gaps, edge-case oversights, or calculation errors. Improve clarity and correctness.",
            context_to_revise=final_solution
        )

        return refined_solution