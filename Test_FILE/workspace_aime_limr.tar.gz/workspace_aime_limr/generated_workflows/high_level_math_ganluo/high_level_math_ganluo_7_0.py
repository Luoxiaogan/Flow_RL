# Workflow ID: high_level_math_ganluo_7_0
# Benchmark: high_level_math_ganluo
# Data Indices: [100, 6]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand problem structure and category
        analysis = await self.generate(
            instruction="Identify the mathematical domain (e.g., number theory, geometry, combinatorics) and key constraints from the problem statement."
        )

        # Step 2: Extract structured facts — critical for complex problems with multiple conditions
        extracted_facts = await self.generate(
            instruction="Extract all relevant numerical values, variables, and constraints from the problem in structured format.",
            context=analysis
        )

        # Step 3: Parallel exploration of multiple solution paths based on detected domain
        task1 = self.generate(
            instruction="Propose an algebraic approach if the problem involves equations or expressions.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Propose a geometric approach if the problem involves shapes, coordinates, or spatial reasoning.",
            context=analysis
        )
        task3 = self.generate(
            instruction="Propose a combinatorial or probabilistic approach if counting or expected value is involved.",
            context=analysis
        )
        task4 = self.generate(
            instruction="Propose a number-theoretic approach if divisibility, primes, or modular arithmetic is relevant.",
            context=analysis
        )

        solutions = await asyncio.gather(task1, task2, task3, task4)

        # Step 4: Ensemble to select the best solution path
        best_path = await self.ensemble(
            instruction="Select the most promising solution strategy based on clarity, relevance, and feasibility.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Generate detailed step-by-step solution using selected path
        full_solution = await self.generate(
            instruction="Now generate a complete, rigorous step-by-step solution following the selected strategy.",
            context=best_path
        )

        # Step 6: Refine the solution through iterative revision
        revised_solution = await self.revise(
            instruction="Check for logical gaps, calculation errors, and ensure the answer satisfies all constraints.",
            context_to_revise=full_solution
        )

        # Step 7: Final summary and verification
        final_summary = await self.summarize(
            context_to_summarize=revised_solution
        )

        # Step 8: Ensemble one last time to resolve any remaining ambiguity
        final_answer = await self.ensemble(
            instruction="Return only the integer answer between 0 and 999 that solves the problem.",
            contexts_to_ensemble=[final_summary]
        )

        return final_answer