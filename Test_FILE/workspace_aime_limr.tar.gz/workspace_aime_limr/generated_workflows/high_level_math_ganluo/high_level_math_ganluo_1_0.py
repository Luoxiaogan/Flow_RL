# Workflow ID: high_level_math_ganluo_1_0
# Benchmark: high_level_math_ganluo
# Data Indices: [114, 31]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand problem type and structure
        analysis = await self.generate(
            instruction="Identify the mathematical domain (e.g., number theory, geometry, combinatorics) and key constraints in this problem."
        )

        # Step 2: Extract structured facts from the problem using summarization
        structured_facts = await self.summarize(analysis)

        # Step 3: Parallel exploration of multiple solution paths based on problem characteristics
        task1 = self.generate(
            instruction="Generate an algebraic approach to solve this problem.",
            context=structured_facts
        )
        task2 = self.generate(
            instruction="Generate a geometric or visual approach if applicable.",
            context=structured_facts
        )
        task3 = self.generate(
            instruction="Generate a combinatorial or case-based approach if applicable.",
            context=structured_facts
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble to select the most promising solution path
        best_approach = await self.ensemble(
            instruction="Compare the three candidate approaches and select the one that appears most rigorous and directly addresses the problem's constraints.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Generate detailed step-by-step solution using the best approach
        full_solution = await self.generate(
            instruction="Now produce a complete, logically sound step-by-step solution based on the selected approach.",
            context=best_approach
        )

        # Step 6: Revise to fix errors or clarify reasoning
        final_solution = await self.revise(
            instruction="Review the solution carefully for logical consistency, completeness, and correctness. Fix any gaps or ambiguities.",
            context_to_revise=full_solution
        )

        # Step 7: Final ensemble to verify answer format and validity
        verified_answer = await self.ensemble(
            instruction="Evaluate whether the final answer satisfies all constraints and is expressed as an integer between 0 and 999. If not, revise accordingly.",
            contexts_to_ensemble=[final_solution]
        )

        return verified_answer