# Workflow ID: high_level_math_ganluo_24_0
# Benchmark: high_level_math_ganluo
# Data Indices: [19, 101]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis
        analysis = await self.generate(
            instruction="Analyze the problem to identify key mathematical concepts, constraints, and required operations."
        )

        # Step 2: Parallel Exploration of Multiple Solution Paths
        path1 = self.generate(
            instruction="Solve using coordinate geometry: express area formula in terms of p and q, then apply slope condition."
        )
        path2 = self.generate(
            instruction="Solve using vector methods: find midpoint of BC, derive median direction, set up system with area constraint."
        )
        path3 = self.generate(
            instruction="Use synthetic geometry: consider symmetry, possible positions of A that satisfy area and slope conditions."
        )

        solutions = await asyncio.gather(path1, path2, path3)

        # Step 3: Ensemble to Select Best Solution
        final_solution = await self.ensemble(
            instruction="Compare the three candidate solutions and select the most mathematically sound one based on consistency and correctness.",
            contexts_to_ensemble=solutions
        )

        # Step 4: Refine Final Answer
        refined_answer = await self.revise(
            instruction="Verify the selected solution satisfies all original constraints (area = 70, median slope = -5) and check if it yields the maximum possible value of p + q.",
            context_to_revise=final_solution
        )

        return refined_answer