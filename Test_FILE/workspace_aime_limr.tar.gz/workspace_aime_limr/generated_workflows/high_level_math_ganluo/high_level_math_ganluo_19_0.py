# Workflow ID: high_level_math_ganluo_19_0
# Benchmark: high_level_math_ganluo
# Data Indices: [75, 26]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand the problem structure
        analysis = await self.generate(
            instruction="Analyze the problem and identify its mathematical domain (e.g., algebra, geometry, combinatorics). Also note any constraints or patterns."
        )

        # Step 2: Extract key elements from the analysis for structured reasoning
        extracted = await self.generate(
            instruction="From the analysis, extract all mathematical expressions, variables, constraints, and target values in a structured format.",
            context=analysis
        )

        # Step 3: Parallel exploration — generate multiple solution strategies
        task1 = self.generate(
            instruction="Solve using algebraic manipulation and simplification techniques.",
            context=extracted
        )
        task2 = self.generate(
            instruction="Solve using geometric interpretation or coordinate-based methods if applicable.",
            context=extracted
        )
        task3 = self.generate(
            instruction="Solve using number theory or modular arithmetic if relevant.",
            context=extracted
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble the competing solutions to select the most robust one
        final_answer = await self.ensemble(
            instruction="Evaluate the three candidate solutions and choose the one that satisfies all constraints and is mathematically consistent.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Revise if needed — apply feedback loop to improve accuracy
        revised_answer = await self.revise(
            instruction="Check the final answer for consistency with the original problem constraints and correct any logical errors.",
            context_to_revise=final_answer
        )

        return revised_answer