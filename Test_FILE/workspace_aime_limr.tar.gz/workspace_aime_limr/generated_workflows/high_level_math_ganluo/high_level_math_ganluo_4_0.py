# Workflow ID: high_level_math_ganluo_4_0
# Benchmark: high_level_math_ganluo
# Data Indices: [102, 76]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand the problem structure
        analysis = await self.generate(
            instruction="Analyze the problem and identify its category (e.g., algebra, geometry, combinatorics). Also note any constraints, symmetries, or key equations."
        )

        # Step 2: Extract key mathematical elements from the analysis
        extracted = await self.generate(
            instruction="From the analysis, extract all relevant equations, variables, and constraints in structured form.",
            context=analysis
        )

        # Step 3: Parallel exploration of multiple solution strategies
        strategy_tasks = [
            self.generate(
                instruction="Propose an algebraic approach based on the extracted equations.",
                context=extracted
            ),
            self.generate(
                instruction="Propose a geometric or trigonometric interpretation if applicable.",
                context=extracted
            ),
            self.generate(
                instruction="Propose a case-based or recursive approach if the problem involves counting or discrete structures.",
                context=extracted
            )
        ]
        strategies = await asyncio.gather(*strategy_tasks)

        # Step 4: Ensemble the best solution path from diverse strategies
        best_strategy = await self.ensemble(
            instruction="Compare the three proposed strategies and select the most promising one based on clarity, feasibility, and alignment with the problem's constraints.",
            contexts_to_ensemble=strategies
        )

        # Step 5: Generate a full step-by-step solution using the selected strategy
        solution_draft = await self.generate(
            instruction="Using the selected strategy, generate a detailed, step-by-step solution that leads to the final answer.",
            context=best_strategy
        )

        # Step 6: Revise the solution iteratively to improve correctness and clarity
        revised_solution = await self.revise(
            instruction="Review the solution for logical consistency, missing steps, and potential errors. Improve clarity and rigor.",
            context_to_revise=solution_draft
        )

        # Step 7: Final verification by summarizing and checking against original problem
        summary = await self.summarize(context_to_summarize=revised_solution)
        final_check = await self.generate(
            instruction="Verify that the final solution satisfies all constraints of the original problem. If not, revise accordingly.",
            context=summary
        )

        return final_check