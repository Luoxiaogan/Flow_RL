# Workflow ID: high_level_math_ganluo_3_0
# Benchmark: high_level_math_ganluo
# Data Indices: [85, 36]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand structure and key elements
        analysis = await self.generate(
            instruction="Analyze the problem to identify its mathematical domain (e.g., geometry, algebra, combinatorics), main goal, constraints, and any hidden patterns or symmetries."
        )

        # Step 2: Parallel Exploration — Generate multiple solution paths
        task1 = self.generate(
            instruction="If this is a geometry problem, apply coordinate bashing by assigning coordinates to all relevant points and compute area using shoelace formula.",
            context=analysis
        )
        task2 = self.generate(
            instruction="If this is an algebraic or number theory problem, derive equations or modular constraints that must be satisfied.",
            context=analysis
        )
        task3 = self.generate(
            instruction="If this involves counting or probability, consider casework, symmetry, or generating functions as possible strategies.",
            context=analysis
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble — Synthesize best approach based on consistency and clarity
        ensemble_result = await self.ensemble(
            instruction="Compare the three proposed solution strategies. Select the one that is most mathematically sound, clearly structured, and directly addresses the problem's core requirement.",
            contexts_to_ensemble=solutions
        )

        # Step 4: Refinement Loop — Improve the selected solution iteratively
        revised_solution = ensemble_result
        for _ in range(2):  # Two rounds of refinement
            revised_solution = await self.revise(
                instruction="Check for logical gaps, missing cases, or arithmetic errors in the current solution. Ensure every step follows from the previous and satisfies all constraints.",
                context_to_revise=revised_solution
            )

        # Step 5: Final Verification — Bidirectional check if feasible
        final_check = await self.generate(
            instruction="Now generate an inverse verification: assume the answer is correct and show it leads back to the original conditions or constraints. If not, revise again.",
            context=revised_solution
        )

        # Step 6: Return the final integer answer (assumed to be extracted from text)
        return final_check