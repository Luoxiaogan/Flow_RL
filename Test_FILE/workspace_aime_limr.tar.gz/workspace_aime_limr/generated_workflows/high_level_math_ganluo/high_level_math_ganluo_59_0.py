# Workflow ID: high_level_math_ganluo_59_0
# Benchmark: high_level_math_ganluo
# Data Indices: [53, 108]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Analyze the problem to identify its category and key constraints
        analysis = await self.generate(
            instruction="Identify the mathematical domain (e.g., algebra, combinatorics, number theory) and list all explicit constraints or conditions in the problem."
        )

        # Step 2: Generate multiple solution paths using parallel exploration
        task1 = self.generate(
            instruction="Generate an algebraic approach based on the problem structure and constraints.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Generate a combinatorial or case-based approach if applicable.",
            context=analysis
        )
        task3 = self.generate(
            instruction="Generate a geometric or symmetry-based approach if relevant.",
            context=analysis
        )

        # Execute in parallel to explore diverse strategies
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 3: Summarize each solution for clarity and focus
        summaries = [await self.summarize(sol) for sol in solutions]

        # Step 4: Ensemble the best candidate by evaluating consistency and completeness
        final_answer = await self.ensemble(
            instruction="Select the most mathematically sound and complete solution from the candidates. Prioritize those that satisfy all constraints and are internally consistent.",
            contexts_to_ensemble=summaries
        )

        # Step 5: Optional refinement — revise if the answer seems incomplete or ambiguous
        revised_answer = await self.revise(
            instruction="Review the selected solution for logical gaps, missing steps, or potential errors. If found, improve it while preserving correctness.",
            context_to_revise=final_answer
        )

        return revised_answer