# Workflow ID: high_level_math_ganluo_57_0
# Benchmark: high_level_math_ganluo
# Data Indices: [43, 90]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis
        analysis = await self.generate(
            instruction="Analyze the problem to identify its mathematical domain (e.g., sequences, combinatorics, geometry), key constraints, and required solution type."
        )

        # Step 2: Extract Core Elements
        extracted = await self.generate(
            instruction="Extract all critical elements from the analysis: variables, recurrence relations, initial conditions, target expression, and any hidden structure or symmetry.",
            context=analysis
        )

        # Step 3: Parallel Exploration of Multiple Approaches
        task1 = self.generate(
            instruction="Solve using algebraic methods: derive a closed-form expression for the sequence or transform the infinite sum into a solvable equation."
        )
        task2 = self.generate(
            instruction="Solve using generating functions: define a generating function G(x) for the sequence and evaluate the sum as G(1/4)."
        )
        task3 = self.generate(
            instruction="Solve using recursive decomposition: break the infinite sum into smaller parts based on the recurrence relation."
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer
        final_answer = await self.ensemble(
            instruction="Compare the three candidate solutions. Choose the one that is mathematically consistent, satisfies all constraints, and matches expected integer format between 0 and 999.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional Refinement via Bidirectional Verification
        if "infinite sum" in analysis.lower() or "series" in analysis.lower():
            verification = await self.generate(
                instruction="Generate an inverse problem: given the proposed answer, verify it by reconstructing the original sum and checking convergence or consistency with known values.",
                context=final_answer
            )
            final_answer = await self.revise(
                instruction="Revise the final answer based on the verification step. If the verification fails, try again using the best approach from earlier.",
                context_to_revise=final_answer
            )

        return final_answer