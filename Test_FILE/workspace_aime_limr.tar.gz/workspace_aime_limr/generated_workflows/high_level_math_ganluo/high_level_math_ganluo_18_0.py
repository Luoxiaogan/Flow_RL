# Workflow ID: high_level_math_ganluo_18_0
# Benchmark: high_level_math_ganluo
# Data Indices: [74, 55]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand the problem structure and constraints
        analysis = await self.generate(
            instruction="Analyze the problem to identify key mathematical concepts, variables, constraints, and required operations."
        )

        # Step 2: Extract structured information (e.g., numbers, conditions, hidden parts)
        extracted = await self.generate(
            instruction="Extract all relevant numerical values, constraints, and unknowns from the problem. List them clearly.",
            context=analysis
        )

        # Step 3: Parallel exploration — try multiple solution paths based on domain clues
        task1 = self.generate(
            instruction="Solve using algebraic manipulation and equation setup based on the extracted constraints.",
            context=extracted
        )
        task2 = self.generate(
            instruction="Approach geometrically or combinatorially if applicable; otherwise, assume this path is not viable.",
            context=extracted
        )
        task3 = self.generate(
            instruction="Use modular arithmetic or number theory techniques if divisibility or primes are involved.",
            context=extracted
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble to select the most coherent and consistent solution
        final_solution = await self.ensemble(
            instruction="Compare the three candidate solutions. Choose the one that best satisfies all constraints, is mathematically sound, and matches the expected answer format (integer between 0–999).",
            contexts_to_ensemble=solutions
        )

        # Step 5: Final verification loop — revise based on logical consistency checks
        revised_solution = await self.revise(
            instruction="Review the selected solution for internal consistency: Does it satisfy all original constraints? Are intermediate steps logically valid?",
            context_to_revise=final_solution
        )

        return revised_solution