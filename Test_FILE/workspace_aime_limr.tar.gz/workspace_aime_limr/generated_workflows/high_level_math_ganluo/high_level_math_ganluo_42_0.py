# Workflow ID: high_level_math_ganluo_42_0
# Benchmark: high_level_math_ganluo
# Data Indices: [68, 4]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis — identify domain and structure
        analysis = await self.generate(
            instruction="Identify the mathematical domain (e.g., algebra, geometry, number theory, combinatorics) and key constraints in this problem."
        )

        # Step 2: Extract structured facts — if possible, convert to math-ready form
        extracted = await self.generate(
            instruction="From the problem statement, extract all numerical values, variables, and conditions as a list of clear mathematical facts.",
            context=analysis
        )

        # Step 3: Parallel exploration — generate multiple solution paths based on problem type
        task1 = self.generate(
            instruction="If this is an algebraic problem, derive a symbolic expression or equation that models the situation.",
            context=analysis
        )
        task2 = self.generate(
            instruction="If this is a combinatorial problem, define the counting strategy or recursive relation.",
            context=analysis
        )
        task3 = self.generate(
            instruction="If this is a number theory problem, apply modular arithmetic or divisibility rules to simplify.",
            context=analysis
        )
        task4 = self.generate(
            instruction="If this is a geometric problem, suggest coordinate placement or synthetic construction techniques.",
            context=analysis
        )

        solutions = await asyncio.gather(task1, task2, task3, task4)

        # Step 4: Ensemble — select best-supported approach from diverse candidates
        ensemble_result = await self.ensemble(
            instruction="Compare the four candidate solutions. Choose the one that aligns with the problem's stated goal and uses valid mathematical reasoning.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Refine — revise the chosen solution for clarity, correctness, and completeness
        refined_solution = await self.revise(
            instruction="Refine the selected solution by checking logical consistency, verifying edge cases, and simplifying expressions where possible.",
            context_to_revise=ensemble_result
        )

        # Step 6: Final verification — ensure answer satisfies constraints and is an integer between 0–999
        final_check = await self.generate(
            instruction="Verify that the final answer is an integer between 0 and 999, and confirm it satisfies all original constraints.",
            context=refined_solution
        )

        return final_check