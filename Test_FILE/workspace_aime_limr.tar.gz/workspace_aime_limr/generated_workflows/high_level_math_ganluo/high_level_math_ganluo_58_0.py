# Workflow ID: high_level_math_ganluo_58_0
# Benchmark: high_level_math_ganluo
# Data Indices: [48, 5]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis
        analysis = await self.generate(
            instruction="Analyze the problem to identify the mathematical domain (e.g., algebra, geometry, number theory) and key constraints or patterns."
        )

        # Step 2: Generate Multiple Solution Paths
        paths = await asyncio.gather(
            self.generate(instruction="Generate an algebraic approach to solve this problem.", context=analysis),
            self.generate(instruction="Generate a geometric interpretation if applicable.", context=analysis),
            self.generate(instruction="Generate a combinatorial or number-theoretic angle if relevant.", context=analysis)
        )

        # Step 3: Summarize Each Path for Clarity
        summarized_paths = await asyncio.gather(
            self.summarize(paths[0]),
            self.summarize(paths[1]),
            self.summarize(paths[2])
        )

        # Step 4: Ensemble to Select Best Approach
        best_approach = await self.ensemble(
            instruction="Evaluate the three solution approaches and select the most promising one based on clarity, feasibility, and alignment with the problem structure.",
            contexts_to_ensemble=summarized_paths
        )

        # Step 5: Generate Final Solution
        final_solution = await self.generate(
            instruction="Using the selected approach, now produce a complete step-by-step solution that leads to the final integer answer.",
            context=best_approach
        )

        # Step 6: Revise for Rigor
        refined_solution = await self.revise(
            instruction="Review the solution for logical consistency, correctness of steps, and adherence to all given constraints. Fix any errors or ambiguities.",
            context_to_revise=final_solution
        )

        # Step 7: Final Ensemble (Optional but Strongly Recommended)
        final_answer = await self.ensemble(
            instruction="Compare the original solution and the revised version. If they agree, return the answer. If not, provide a synthesized response based on both.",
            contexts_to_ensemble=[final_solution, refined_solution]
        )

        return final_answer