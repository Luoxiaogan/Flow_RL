# Workflow ID: high_level_math_ganluo_12_0
# Benchmark: high_level_math_ganluo
# Data Indices: [16, 12]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand problem type and constraints
        analysis = await self.generate(
            instruction="Analyze the problem to identify its category (e.g., algebra, combinatorics, number theory), key constraints, and required techniques."
        )

        # Step 2: Parallel Exploration — Generate multiple solution paths based on detected categories
        tasks = [
            self.generate(
                instruction="If this is an algebra problem, propose a strategy involving factoring or solving equations.",
                context=analysis
            ),
            self.generate(
                instruction="If this is a number theory problem, suggest methods like modular arithmetic or divisibility rules.",
                context=analysis
            ),
            self.generate(
                instruction="If this is a geometry or inequality problem, consider coordinate-based approaches or interval analysis.",
                context=analysis
            )
        ]
        candidate_solutions = await asyncio.gather(*tasks)

        # Step 3: Summarize each path to reduce noise and extract key ideas
        summaries = [await self.summarize(sol) for sol in candidate_solutions]

        # Step 4: Ensemble — Select the best solution based on internal consistency and clarity
        final_solution = await self.ensemble(
            instruction="Select the most coherent and mathematically sound solution from the candidates. Ensure it satisfies all problem constraints.",
            contexts_to_ensemble=summaries
        )

        # Step 5: Iterative Refinement — Improve the final solution through targeted revision
        revised_solution = await self.revise(
            instruction="Check the final solution for logical gaps, mathematical correctness, and whether it answers the original question fully.",
            context_to_revise=final_solution
        )

        return revised_solution