# Workflow ID: high_level_math_ganluo_21_0
# Benchmark: high_level_math_ganluo
# Data Indices: [109, 107]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand the problem type and constraints
        analysis = await self.generate(
            instruction="Analyze the problem to identify its category (e.g., geometry, algebra, combinatorics) and key constraints or conditions."
        )

        # Step 2: Extract Core Mathematical Elements — Isolate variables, equations, or geometric facts
        extraction = await self.generate(
            instruction="From the analysis, extract all relevant mathematical expressions, equations, or constraints in structured form.",
            context=analysis
        )

        # Step 3: Parallel Exploration — Generate multiple solution strategies based on problem structure
        task1 = self.generate(
            instruction="Generate an algebraic approach to solve this problem, assuming it involves solving equations or simplifying expressions.",
            context=extraction
        )
        task2 = self.generate(
            instruction="Generate a geometric approach if applicable, focusing on visual or coordinate-based reasoning.",
            context=extraction
        )
        task3 = self.generate(
            instruction="Generate a combinatorial or number-theoretic approach if the problem involves counting, divisibility, or modular arithmetic.",
            context=extraction
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble — Compare and synthesize the best possible solution
        final_solution = await self.ensemble(
            instruction="Compare the three generated approaches and select the most rigorous and logically consistent solution. If there's disagreement, choose the one that satisfies all constraints explicitly.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Refinement — Revise the solution to eliminate errors or clarify steps
        revised_solution = await self.revise(
            instruction="Review the selected solution carefully for logical consistency, computational accuracy, and completeness. Fix any gaps or ambiguities.",
            context_to_revise=final_solution
        )

        # Step 6: Final Verification — Ensure answer is an integer between 0 and 999
        verification = await self.generate(
            instruction="Verify that the final answer is an integer between 0 and 999 inclusive, and that it satisfies all original conditions of the problem.",
            context=revised_solution
        )

        return verification