# Workflow ID: high_level_math_ganluo_36_0
# Benchmark: high_level_math_ganluo
# Data Indices: [32, 11]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify problem type and key elements
        analysis = await self.generate(
            instruction="Analyze the problem to determine its category (e.g., combinatorics, number theory, geometry) and extract all constraints, variables, and required operations."
        )

        # Step 2: Parallel exploration of multiple solution strategies
        task1 = self.generate(
            instruction="Generate an algebraic approach based on the problem's structure and constraints.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Generate a geometric or coordinate-based approach if applicable.",
            context=analysis
        )
        task3 = self.generate(
            instruction="Generate a combinatorial or case-based approach if applicable.",
            context=analysis
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble to select the most promising solution
        final_solution = await self.ensemble(
            instruction="Compare the three candidate solutions and select the one that best satisfies all constraints and appears mathematically sound.",
            contexts_to_ensemble=solutions
        )

        # Step 4: Revise to refine and verify correctness
        revised_solution = await self.revise(
            instruction="Critically review the selected solution for logical consistency, mathematical rigor, and adherence to all problem constraints. Correct any errors or ambiguities.",
            context_to_revise=final_solution
        )

        # Step 5: Final verification using bidirectional reasoning
        verification = await self.generate(
            instruction="Now generate an inverse check: derive the original problem from this solution and confirm it matches the input conditions.",
            context=revised_solution
        )

        # Step 6: Return the final answer after ensuring clarity and correctness
        return await self.summarize(
            context_to_summarize=revised_solution + "\n\n" + verification
        )