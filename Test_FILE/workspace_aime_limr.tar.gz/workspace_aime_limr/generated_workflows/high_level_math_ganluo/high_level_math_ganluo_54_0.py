# Workflow ID: high_level_math_ganluo_54_0
# Benchmark: high_level_math_ganluo
# Data Indices: [59, 1]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify problem type and structure
        analysis = await self.generate(
            instruction="Analyze the problem to determine its category (e.g., geometry, combinatorics, number theory) and key constraints or conditions."
        )

        # Step 2: Extract structured information if needed (e.g., numbers, diagrams, relationships)
        extracted = await self.generate(
            instruction="From the problem, extract all relevant numerical values, geometric elements, or variables that define the solution space.",
            context=analysis
        )

        # Step 3: Parallel exploration of multiple solution paths
        task1 = self.generate(
            instruction="Propose a geometric approach based on the extracted elements, using coordinate geometry or synthetic methods.",
            context=extracted
        )
        task2 = self.generate(
            instruction="Propose an algebraic or recursive approach based on the extracted elements.",
            context=extracted
        )
        task3 = self.generate(
            instruction="Propose a combinatorial or probabilistic method if applicable (e.g., expected value, counting techniques).",
            context=extracted
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble to select best solution path based on coherence and logical consistency
        ensemble_result = await self.ensemble(
            instruction="Compare the three proposed approaches. Identify which one is most logically sound, mathematically consistent, and directly addresses the original question.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Refine the selected solution iteratively for accuracy
        refined_solution = await self.revise(
            instruction="Refine the selected solution by checking for edge cases, verifying each step, and ensuring no assumptions violate given constraints.",
            context_to_revise=ensemble_result
        )

        # Step 6: Final verification via bidirectional reasoning
        final_verification = await self.generate(
            instruction="Generate an inverse check: if this answer were correct, would it satisfy all conditions in the original problem? Confirm validity.",
            context=refined_solution
        )

        return final_verification