# Workflow ID: high_level_math_ganluo_13_0
# Benchmark: high_level_math_ganluo
# Data Indices: [112, 117]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand problem structure and category
        analysis = await self.generate(
            instruction="Identify the mathematical domain(s) this problem belongs to (e.g., combinatorics, geometry, number theory). Also, note key constraints or patterns."
        )

        # Step 2: Parallel Exploration — Generate multiple solution strategies
        task1 = self.generate(
            instruction="Propose an algebraic approach to solve this problem, focusing on equations or formulas that might apply."
        )
        task2 = self.generate(
            instruction="Propose a geometric or coordinate-based strategy if applicable; otherwise, skip."
        )
        task3 = self.generate(
            instruction="Propose a combinatorial or probabilistic method if relevant; otherwise, skip."
        )
        task4 = self.generate(
            instruction="Propose a number-theoretic or modular arithmetic approach if relevant; otherwise, skip."
        )
        strategies = await asyncio.gather(task1, task2, task3, task4)

        # Step 3: Ensemble Best Strategies — Select top candidates based on relevance
        ensemble_summary = await self.ensemble(
            instruction="Select the most promising strategy from the four proposed ones. Justify briefly why it's best suited for this problem.",
            contexts_to_ensemble=strategies
        )

        # Step 4: Detailed Solution Generation — Build step-by-step solution using selected strategy
        solution_draft = await self.generate(
            instruction="Now construct a complete, rigorous step-by-step solution using the selected strategy. Include all necessary intermediate steps, justifications, and calculations.",
            context=ensemble_summary
        )

        # Step 5: Iterative Refinement — Improve solution via multiple rounds of revision
        refined_solution = solution_draft
        for _ in range(2):  # Two refinement passes
            feedback = await self.generate(
                instruction="Critique the current solution draft for logical gaps, missing assumptions, or calculation errors. Provide specific suggestions for improvement."
            )
            refined_solution = await self.revise(
                instruction="Revise the solution based on the following critique: " + feedback,
                context_to_revise=refined_solution
            )

        # Step 6: Final Verification — Check answer satisfies all constraints
        final_check = await self.generate(
            instruction="Verify the final answer by checking whether it meets all conditions in the original problem. If not, identify the discrepancy and fix it.",
            context=refined_solution
        )

        # Step 7: Return Final Answer — Extract integer result between 0–999
        answer = await self.generate(
            instruction="Extract only the final numerical answer as an integer between 0 and 999. Do not include any explanation or text.",
            context=final_check
        )

        return answer