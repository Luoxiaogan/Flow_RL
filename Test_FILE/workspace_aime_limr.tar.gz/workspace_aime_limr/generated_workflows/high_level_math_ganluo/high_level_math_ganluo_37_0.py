# Workflow ID: high_level_math_ganluo_37_0
# Benchmark: high_level_math_ganluo
# Data Indices: [62, 92]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand structure and category
        analysis = await self.generate(
            instruction="Analyze the problem type (e.g., algebra, geometry, number theory) and identify key constraints or patterns."
        )

        # Step 2: Extract structured information from the problem
        extracted = await self.generate(
            instruction="Extract all relevant equations, inequalities, variables, and constraints in a clean, structured format.",
            context=analysis
        )

        # Step 3: Parallel exploration of multiple solution paths
        task1 = self.generate(
            instruction="Solve using algebraic manipulation and case analysis based on extracted constraints.",
            context=extracted
        )
        task2 = self.generate(
            instruction="Solve by considering symmetry, substitution, or transformation techniques if applicable.",
            context=extracted
        )
        task3 = self.generate(
            instruction="Approach as a combinatorial or number-theoretic problem — look for integer solutions, modular arithmetic, or divisibility patterns.",
            context=extracted
        )

        # Run parallel strategies
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble final answer from competing solutions
        final_answer = await self.ensemble(
            instruction="Compare the three proposed solutions and select the one that best satisfies all constraints and is mathematically consistent.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Revise to ensure correctness and clarity
        refined_answer = await self.revise(
            instruction="Check for logical consistency, verify against original constraints, and clarify any ambiguous steps in the solution.",
            context_to_revise=final_answer
        )

        return refined_answer