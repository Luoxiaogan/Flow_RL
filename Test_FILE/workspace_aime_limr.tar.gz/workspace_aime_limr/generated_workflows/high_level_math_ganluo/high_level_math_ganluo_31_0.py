# Workflow ID: high_level_math_ganluo_31_0
# Benchmark: high_level_math_ganluo
# Data Indices: [58, 89]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify domain and key constraints
        analysis = await self.generate(
            instruction="Identify the mathematical domain (e.g., trigonometry, algebra, geometry) and list all explicit constraints or conditions in the problem."
        )

        # Step 2: Generate multiple solution strategies based on domain
        strategies = await asyncio.gather(
            self.generate(
                instruction="Propose an algebraic approach to solve this problem.",
                context=analysis
            ),
            self.generate(
                instruction="Propose a geometric or coordinate-based approach if applicable.",
                context=analysis
            ),
            self.generate(
                instruction="Propose a method using symmetry, periodicity, or known identities (e.g., for trig problems).",
                context=analysis
            )
        )

        # Step 3: Ensemble to select best initial strategy
        selected_strategy = await self.ensemble(
            instruction="Evaluate the three proposed strategies and select the most promising one based on clarity, feasibility, and relevance to the problem's structure.",
            contexts_to_ensemble=strategies
        )

        # Step 4: Generate full solution using selected strategy
        solution_draft = await self.generate(
            instruction="Using the selected strategy, write a complete step-by-step solution with all necessary reasoning and calculations.",
            context=selected_strategy
        )

        # Step 5: Revise iteratively to fix errors or clarify logic
        revised_solution = await self.revise(
            instruction="Review the solution for logical consistency, mathematical correctness, and completeness. Fix any gaps or mistakes.",
            context_to_revise=solution_draft
        )

        # Step 6: Final verification by generating inverse or boundary check
        verification = await self.generate(
            instruction="Create a concise verification plan: either test edge cases or derive the reverse of the main calculation to ensure consistency.",
            context=revised_solution
        )

        # Step 7: Final ensemble — combine original solution and verification insight
        final_answer = await self.ensemble(
            instruction="Based on the verified solution and the verification plan, provide the final answer as an integer between 0 and 999.",
            contexts_to_ensemble=[revised_solution, verification]
        )

        return final_answer