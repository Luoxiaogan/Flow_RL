# Workflow ID: high_level_math_ganluo_49_0
# Benchmark: high_level_math_ganluo
# Data Indices: [81, 21]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis
        analysis = await self.generate(
            instruction="Analyze the problem structure and identify key mathematical domains (e.g., combinatorics, algebra, number theory). Also, determine what type of answer is expected (integer between 0-999)."
        )

        # Step 2: Extract Problem Components
        components = await self.generate(
            instruction="Extract all relevant constraints, variables, and conditions from the problem statement. Present them clearly as bullet points.",
            context=analysis
        )

        # Step 3: Parallel Exploration of Multiple Solution Paths
        task1 = self.generate(
            instruction="Propose an algebraic approach to solve this problem using equations or functional relationships."
        )
        task2 = self.generate(
            instruction="Propose a combinatorial or counting-based approach if applicable."
        )
        task3 = self.generate(
            instruction="Propose a geometric or coordinate-based method if the problem involves shapes or spatial reasoning."
        )
        task4 = self.generate(
            instruction="Propose a number-theoretic or modular arithmetic approach if divisibility or integers are central."
        )

        paths = await asyncio.gather(task1, task2, task3, task4)

        # Step 4: Ensemble Top Candidates
        ensemble_summary = await self.ensemble(
            instruction="Compare the four proposed solution strategies. Identify which one(s) appear most promising based on clarity, feasibility, and alignment with the problem's domain.",
            contexts_to_ensemble=paths
        )

        # Step 5: Generate Final Solution Based on Best Strategy
        final_solution = await self.generate(
            instruction="Using the selected strategy, generate a complete step-by-step solution that satisfies all constraints and leads to an integer answer between 0 and 999.",
            context=ensemble_summary
        )

        # Step 6: Iterative Refinement via Revise
        refined_solution = await self.revise(
            instruction="Critically review the solution for logical consistency, calculation accuracy, and adherence to all given constraints. Fix any errors or ambiguities.",
            context_to_revise=final_solution
        )

        # Step 7: Final Verification via Bidirectional Check
        verification = await self.generate(
            instruction="Create an inverse problem or test case that should yield the same result if the solution is correct. Verify the answer by solving it in reverse or checking edge cases.",
            context=refined_solution
        )

        # Step 8: Final Ensemble for Confidence
        final_answer = await self.ensemble(
            instruction="You have generated multiple versions of the solution. Choose the most consistent and logically sound answer. Return only the final integer answer.",
            contexts_to_ensemble=[refined_solution, verification]
        )

        return final_answer