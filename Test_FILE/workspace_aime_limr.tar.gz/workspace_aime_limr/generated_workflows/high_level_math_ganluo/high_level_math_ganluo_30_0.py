# Workflow ID: high_level_math_ganluo_30_0
# Benchmark: high_level_math_ganluo
# Data Indices: [29, 99]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand the structure and type of problem
        analysis = await self.generate(
            instruction="Analyze the problem to determine its mathematical domain (e.g., algebra, number theory, geometry) and identify key constraints or symmetries."
        )

        # Step 2: Extract Core Components — Isolate variables, equations, conditions
        extracted = await self.generate(
            instruction="From the analysis, extract all mathematical expressions, constraints, and unknowns that must be solved for.",
            context=analysis
        )

        # Step 3: Parallel Exploration — Try multiple solution paths (e.g., substitution, symmetry, recursion)
        task1 = self.generate(
            instruction="Propose a solution path using algebraic manipulation and functional equation techniques.",
            context=extracted
        )
        task2 = self.generate(
            instruction="Propose an alternative solution path by exploring symmetry or invariance properties.",
            context=extracted
        )
        task3 = self.generate(
            instruction="Propose a third solution path focusing on boundary cases or special values (e.g., f(1), f(-1), or extreme inputs).",
            context=extracted
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble — Synthesize the best candidate based on internal consistency
        ensemble_result = await self.ensemble(
            instruction="Compare the three proposed solutions. Identify which one(s) satisfy all constraints and yield consistent results.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Refinement Loop — Revise the ensemble result iteratively if needed
        revised = await self.revise(
            instruction="Check whether the proposed solution satisfies the original equation for test values like x=1, y=1, x=-1, etc. If not, revise accordingly.",
            context_to_revise=ensemble_result
        )

        # Step 6: Final Verification — Ensure answer meets format requirements (integer between 0–999)
        final_answer = await self.generate(
            instruction="Given the refined solution, compute the final numerical answer. It must be an integer between 0 and 999 inclusive.",
            context=revised
        )

        return final_answer