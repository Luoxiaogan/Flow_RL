# Workflow ID: high_level_math_ganluo_47_0
# Benchmark: high_level_math_ganluo
# Data Indices: [44, 7]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand problem structure and category
        analysis = await self.generate(
            instruction="Identify the mathematical domain (e.g., geometry, algebra, combinatorics) and key constraints or variables in this problem."
        )

        # Step 2: Parallel Exploration — Generate multiple solution paths based on detected domain
        tasks = [
            self.generate(
                instruction="Propose an algebraic approach to solve the problem, focusing on equations and expressions.",
                context=analysis
            ),
            self.generate(
                instruction="Propose a geometric or coordinate-based approach if applicable, using visual or spatial reasoning.",
                context=analysis
            ),
            self.generate(
                instruction="Propose a combinatorial or number-theoretic approach if the problem involves counting, divisibility, or integer properties.",
                context=analysis
            )
        ]
        candidates = await asyncio.gather(*tasks)

        # Step 3: Ensemble — Select best candidate based on internal consistency and relevance
        final_plan = await self.ensemble(
            instruction="Evaluate the three proposed approaches and select the one most likely to yield a correct answer efficiently.",
            contexts_to_ensemble=candidates
        )

        # Step 4: Generate Solution — Build detailed step-by-step solution
        solution = await self.generate(
            instruction="Now write a complete, rigorous solution based on the selected strategy, including all necessary steps and justifications.",
            context=final_plan
        )

        # Step 5: Revise — Refine solution by checking logical flow, edge cases, and clarity
        revised_solution = await self.revise(
            instruction="Critique the solution for potential errors, missing assumptions, or unclear steps. Improve rigor and clarity.",
            context_to_revise=solution
        )

        # Step 6: Final Verification — Ensure answer satisfies all conditions and is within valid range
        verification = await self.generate(
            instruction="Verify that the final answer is an integer between 0 and 999 and makes sense mathematically given the problem's constraints.",
            context=revised_solution
        )

        return verification