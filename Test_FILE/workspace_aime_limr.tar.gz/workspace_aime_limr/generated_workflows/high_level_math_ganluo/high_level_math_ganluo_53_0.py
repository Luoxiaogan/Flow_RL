# Workflow ID: high_level_math_ganluo_53_0
# Benchmark: high_level_math_ganluo
# Data Indices: [86, 78]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand structure and key elements
        analysis = await self.generate(
            instruction="Identify all given quantities, unknowns, geometric constraints, and potential solution paths (e.g., coordinate geometry, Pythagorean theorem, similar triangles)."
        )

        # Step 2: Parallel Exploration — Try multiple approaches simultaneously
        task1 = self.generate(
            instruction="Assume coordinates: Place point O at origin (0,0), X on x-axis, Y on y-axis. Derive expressions for distances XN and YM in terms of coordinates of X and Y."
        )
        task2 = self.generate(
            instruction="Use vector algebra or synthetic geometry to express XY in terms of segments from midpoints M and N using known lengths."
        )
        task3 = self.generate(
            instruction="Apply the Law of Cosines or Stewart’s Theorem in triangle ABC if applicable, or use angle bisector theorem if it's a triangle with an angle bisector."
        )

        approaches = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble — Compare and synthesize best solution path
        ensemble_instruction = "Compare the three proposed methods: determine which one leads to a clean derivation of the answer based on the given values (like XN=19, YM=22 or AB=BC=5, AC=4). Select the most mathematically sound approach."
        selected_approach = await self.ensemble(instruction=ensemble_instruction, contexts_to_ensemble=approaches)

        # Step 4: Generate Final Solution — Solve step-by-step using selected method
        solution_draft = await self.generate(
            instruction="Now solve the problem completely using the selected approach. Show all steps clearly, including intermediate calculations.",
            context=selected_approach
        )

        # Step 5: Revise — Refine for accuracy and clarity
        revised_solution = await self.revise(
            instruction="Check for logical consistency, mathematical correctness, and proper handling of units or constraints. Ensure final answer is an integer between 0 and 999.",
            context_to_revise=solution_draft
        )

        # Step 6: Final Verification — Bidirectional check
        verification = await self.generate(
            instruction="Create a reverse problem: Given the computed value of XY or AD², verify that it satisfies the original conditions (e.g., if XY=25, check whether XN=19 and YM=22 hold).",
            context=revised_solution
        )

        # Step 7: Ensemble Final Output — Confirm robustness by comparing draft vs verified
        final_answer = await self.ensemble(
            instruction="Choose the correct final answer based on the generated solution and its verification. If they agree, return the integer result. If not, choose the more reliable one based on mathematical rigor.",
            contexts_to_ensemble=[revised_solution, verification]
        )

        return final_answer