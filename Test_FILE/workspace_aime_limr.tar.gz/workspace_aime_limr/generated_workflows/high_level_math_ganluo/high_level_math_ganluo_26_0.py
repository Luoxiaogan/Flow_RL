# Workflow ID: high_level_math_ganluo_26_0
# Benchmark: high_level_math_ganluo
# Data Indices: [83, 51]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify problem type and structure
        analysis = await self.generate(
            instruction="Analyze the problem to determine its mathematical domain (e.g., number theory, geometry, combinatorics) and key constraints."
        )

        # Step 2: Extract structured information from the problem
        extracted = await self.generate(
            instruction="Extract all relevant numerical values, relationships, and conditions as a bullet list.",
            context=analysis
        )

        # Step 3: Parallel exploration of multiple solution strategies
        strategy_tasks = [
            self.generate("Generate an algebraic approach based on the extracted constraints."),
            self.generate("Generate a geometric or coordinate-based approach if applicable."),
            self.generate("Generate a combinatorial or case-based approach if applicable.")
        ]
        strategies = await asyncio.gather(*strategy_tasks)

        # Step 4: Summarize each strategy to reduce noise
        summarized_strategies = []
        for strategy in strategies:
            summary = await self.summarize(strategy)
            summarized_strategies.append(summary)

        # Step 5: Ensemble the best solution from parallel approaches
        final_solution = await self.ensemble(
            instruction="Choose the most promising solution path based on clarity, feasibility, and alignment with the original constraints.",
            contexts_to_ensemble=summarized_strategies
        )

        # Step 6: Revise the final solution for accuracy and completeness
        refined_solution = await self.revise(
            instruction="Check the solution for logical consistency, mathematical correctness, and whether it satisfies all given constraints.",
            context_to_revise=final_solution
        )

        return refined_solution