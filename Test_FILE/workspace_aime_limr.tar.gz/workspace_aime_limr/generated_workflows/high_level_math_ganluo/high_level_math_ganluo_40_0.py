# Workflow ID: high_level_math_ganluo_40_0
# Benchmark: high_level_math_ganluo
# Data Indices: [61, 105]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify domain and key constraints
        analysis = await self.generate(
            instruction="Analyze the problem to determine its mathematical domain (e.g., algebra, geometry, combinatorics) and extract all given constraints and variables."
        )

        # Step 2: Generate multiple solution strategies in parallel
        strategy_tasks = [
            self.generate(instruction="Propose an algebraic approach using substitution or symmetry.", context=analysis),
            self.generate(instruction="Propose a geometric interpretation if applicable.", context=analysis),
            self.generate(instruction="Propose a method involving inequalities or optimization techniques.", context=analysis),
        ]
        strategies = await asyncio.gather(*strategy_tasks)

        # Step 3: Summarize each strategy for clarity and consistency
        summarized_strategies = [
            await self.summarize(context_to_summarize=s) for s in strategies
        ]

        # Step 4: Ensemble the best candidate solution based on coherence and feasibility
        final_solution = await self.ensemble(
            instruction="Select the most promising solution path from the three strategies. Justify why it's optimal.",
            contexts_to_ensemble=summarized_strategies
        )

        # Step 5: Refine the selected solution through iterative revision
        revised_solution = await self.revise(
            instruction="Improve the solution by checking for logical gaps, ensuring all constraints are satisfied, and simplifying expressions where possible.",
            context_to_revise=final_solution
        )

        # Step 6: Final verification via bidirectional reasoning
        verification = await self.generate(
            instruction="Now generate the inverse problem: what would be the original problem if this solution were correct? Verify that it matches the input constraints exactly.",
            context=revised_solution
        )

        # Step 7: Return the final answer — must be an integer between 0–999
        return await self.generate(
            instruction="Extract only the final numerical answer from the verified solution. Do not include any text or explanation.",
            context=verification
        )