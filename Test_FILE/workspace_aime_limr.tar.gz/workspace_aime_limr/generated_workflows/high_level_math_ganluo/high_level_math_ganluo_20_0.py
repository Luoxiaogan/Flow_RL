# Workflow ID: high_level_math_ganluo_20_0
# Benchmark: high_level_math_ganluo
# Data Indices: [66, 33]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify domain and key constraints
        analysis = await self.generate(
            instruction="Identify the mathematical domain (e.g., combinatorics, number theory) and list all explicit constraints in the problem."
        )

        # Step 2: Parallel exploration of multiple solution strategies
        task1 = self.generate(
            instruction="Generate a combinatorial approach based on counting favorable outcomes vs total outcomes.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Generate an algebraic or geometric approach if applicable, focusing on structure or symmetry.",
            context=analysis
        )
        task3 = self.generate(
            instruction="Generate a recursive or case-based breakdown if the problem involves layered subproblems.",
            context=analysis
        )
        
        # Run parallel explorations
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble to select the best solution path
        ensemble_result = await self.ensemble(
            instruction="Compare the three proposed approaches. Select the one that most directly addresses the constraints and leverages known techniques for this problem type.",
            contexts_to_ensemble=solutions
        )

        # Step 4: Generate final solution using selected strategy
        final_solution = await self.generate(
            instruction="Using the selected strategy, compute the exact answer step-by-step. Ensure it satisfies all conditions and is expressed as an integer between 0 and 999.",
            context=ensemble_result
        )

        # Step 5: Optional refinement via revision if uncertainty remains
        refined_solution = await self.revise(
            instruction="Review the solution carefully. Check for logical gaps, arithmetic errors, or missed edge cases. Improve clarity and correctness.",
            context_to_revise=final_solution
        )

        return refined_solution