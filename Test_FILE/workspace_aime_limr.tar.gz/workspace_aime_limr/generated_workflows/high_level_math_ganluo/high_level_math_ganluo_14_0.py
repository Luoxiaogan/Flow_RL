# Workflow ID: high_level_math_ganluo_14_0
# Benchmark: high_level_math_ganluo
# Data Indices: [93, 67]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand problem structure and constraints
        analysis = await self.generate(
            instruction="Analyze the problem to identify key mathematical concepts, variables, and constraints. Focus on identifying whether it's algebraic, geometric, combinatorial, or number-theoretic."
        )

        # Step 2: Generate Multiple Solution Paths — Parallel Exploration
        task1 = self.generate(
            instruction="Generate an algebraic approach based on the problem's structure.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Generate a geometric or coordinate-based approach if applicable.",
            context=analysis
        )
        task3 = self.generate(
            instruction="Generate a combinatorial or recursive approach if the problem involves counting or sequences.",
            context=analysis
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble Final Answer — Synthesize best solution from diverse paths
        final_answer = await self.ensemble(
            instruction="Compare the three candidate solutions. Choose the one that satisfies all constraints and aligns with the problem type identified in the initial analysis.",
            contexts_to_ensemble=solutions
        )

        # Step 4: Revise for Rigor — Check internal consistency and correctness
        refined_answer = await self.revise(
            instruction="Review the final answer for logical consistency, correct application of mathematical principles, and adherence to all given conditions. If any issue arises, revise accordingly.",
            context_to_revise=final_answer
        )

        return refined_answer