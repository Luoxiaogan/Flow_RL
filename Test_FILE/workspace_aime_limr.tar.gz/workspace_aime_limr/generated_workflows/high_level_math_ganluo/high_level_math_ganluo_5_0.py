# Workflow ID: high_level_math_ganluo_5_0
# Benchmark: high_level_math_ganluo
# Data Indices: [38, 119]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand the problem type and structure
        analysis = await self.generate(
            instruction="Identify the mathematical domain (e.g., geometry, algebra, combinatorics) and key constraints in this problem."
        )

        # Step 2: Diverge — Generate multiple solution strategies based on the problem type
        strategy_1 = self.generate(
            instruction="If this is a geometry problem, suggest a coordinate-based approach.",
            context=analysis
        )
        strategy_2 = self.generate(
            instruction="If this is an algebraic or functional problem, propose a substitution or transformation method.",
            context=analysis
        )
        strategy_3 = self.generate(
            instruction="If this involves counting or optimization, suggest a casework or extremal principle approach.",
            context=analysis
        )

        # Step 3: Parallel Exploration — Run each strategy independently
        tasks = [strategy_1, strategy_2, strategy_3]
        solutions = await asyncio.gather(*tasks)

        # Step 4: Ensemble — Compare and synthesize the best solution from the three approaches
        final_solution = await self.ensemble(
            instruction="Among the three proposed solutions, select the most mathematically sound and consistent one that satisfies all given constraints.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Refinement — Revise the selected solution using critical checks
        refined_solution = await self.revise(
            instruction="Critically review the selected solution for logical consistency, boundary cases, and computational accuracy. Correct any errors.",
            context_to_revise=final_solution
        )

        # Step 6: Final Verification — Ensure the answer meets all criteria (integer between 0–999)
        verification = await self.generate(
            instruction="Verify that the final answer is an integer between 0 and 999 and makes sense in the context of the original problem.",
            context=refined_solution
        )

        return verification