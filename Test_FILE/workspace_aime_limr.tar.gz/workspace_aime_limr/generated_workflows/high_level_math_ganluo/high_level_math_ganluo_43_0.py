# Workflow ID: high_level_math_ganluo_43_0
# Benchmark: high_level_math_ganluo
# Data Indices: [39, 25]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis
        analysis = await self.generate(
            instruction="Analyze the problem to identify key mathematical concepts, constraints, and solution strategies. Focus on identifying whether it's combinatorial, number-theoretic, geometric, or algebraic in nature."
        )

        # Step 2: Generate Multiple Solution Paths (Parallel Exploration)
        task1 = self.generate(
            instruction="Generate an algebraic approach based on the problem structure, focusing on equations, identities, or transformations that may simplify the problem.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Generate a combinatorial or probabilistic approach if applicable—look for counting methods, symmetry, or expected value techniques.",
            context=analysis
        )
        task3 = self.generate(
            instruction="Generate a geometric or coordinate-based strategy if the problem involves shapes, distances, or spatial reasoning.",
            context=analysis
        )
        task4 = self.generate(
            instruction="Generate a number-theoretic approach if divisibility, primes, modular arithmetic, or Diophantine equations are involved.",
            context=analysis
        )

        solutions = await asyncio.gather(task1, task2, task3, task4)

        # Step 3: Ensemble Final Answer from Diverse Approaches
        final_answer = await self.ensemble(
            instruction="Compare the four candidate solutions. Identify which one(s) satisfy all constraints, align with known mathematical principles, and yield a valid integer answer between 0 and 999. Choose the most consistent and well-supported answer.",
            contexts_to_ensemble=solutions
        )

        # Step 4: Optional Refinement Loop (if needed)
        # If the ensemble result seems ambiguous or incomplete, try revising it
        if "likely" in final_answer.lower() or "uncertain" in final_answer.lower():
            refined_answer = await self.revise(
                instruction="Revise the selected solution to ensure clarity, correctness, and completeness. Check for logical consistency, edge cases, and proper application of mathematical rules.",
                context_to_revise=final_answer
            )
            return refined_answer

        return final_answer