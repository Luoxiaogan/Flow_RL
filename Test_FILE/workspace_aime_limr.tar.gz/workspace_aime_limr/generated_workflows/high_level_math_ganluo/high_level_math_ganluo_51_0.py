# Workflow ID: high_level_math_ganluo_51_0
# Benchmark: high_level_math_ganluo
# Data Indices: [113, 46]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis
        analysis = await self.generate(
            instruction="Analyze the problem type (e.g., algebra, geometry, combinatorics) and identify key constraints, variables, and what must be found."
        )

        # Step 2: Extract Key Elements
        extracted = await self.generate(
            instruction="From the analysis, extract all relevant mathematical expressions, equations, and known values in structured format.",
            context=analysis
        )

        # Step 3: Parallel Exploration of Multiple Approaches
        approach_tasks = [
            self.generate("Solve using an algebraic method."),
            self.generate("Solve using a geometric interpretation if applicable."),
            self.generate("Try solving by setting up a system of equations or recursive relations.")
        ]
        approaches = await asyncio.gather(*approach_tasks)

        # Step 4: Summarize Each Approach
        summarized_approaches = []
        for i, approach in enumerate(approaches):
            summary = await self.summarize(approach)
            summarized_approaches.append(summary)

        # Step 5: Ensemble Final Answer from Multiple Solutions
        final_answer = await self.ensemble(
            instruction="Compare the three solutions and select the one that best satisfies all constraints and makes mathematical sense.",
            contexts_to_ensemble=summarized_approaches
        )

        # Step 6: Optional Refinement Loop (if answer seems ambiguous)
        if "ambiguous" in final_answer.lower() or "multiple" in final_answer.lower():
            refined = await self.revise(
                instruction="Revise the solution to resolve ambiguity by checking edge cases or verifying consistency with original constraints.",
                context_to_revise=final_answer
            )
            return refined

        return final_answer