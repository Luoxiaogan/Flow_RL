# Workflow ID: high_level_math_ganluo_52_0
# Benchmark: high_level_math_ganluo
# Data Indices: [14, 20]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify problem type and key elements
        analysis = await self.generate(
            instruction="Analyze the problem to determine its category (e.g., geometry, algebra, combinatorics) and extract all given quantities, units, and relationships."
        )

        # Step 2: Parallel exploration of multiple solution strategies
        strategy_tasks = [
            self.generate(
                instruction="Generate a geometric approach based on the problem's spatial description.",
                context=analysis
            ),
            self.generate(
                instruction="Generate an algebraic or coordinate-based approach by translating the problem into equations.",
                context=analysis
            ),
            self.generate(
                instruction="Generate a unit conversion strategy if applicable (e.g., converting meters to feet).",
                context=analysis
            )
        ]
        strategies = await asyncio.gather(*strategy_tasks)

        # Step 3: Ensemble to select the most promising approach
        selected_strategy = await self.ensemble(
            instruction="Compare the three approaches and choose the one that best leverages the problem structure and minimizes complexity.",
            contexts_to_ensemble=strategies
        )

        # Step 4: Generate full solution using selected strategy
        solution_draft = await self.generate(
            instruction="Using the selected strategy, produce a complete step-by-step solution with all necessary calculations and reasoning.",
            context=selected_strategy
        )

        # Step 5: Refinement loop — revise based on logical consistency and mathematical soundness
        revised_solution = await self.revise(
            instruction="Critically review the solution for errors in logic, arithmetic, or unit handling. Correct any mistakes and ensure all constraints are satisfied.",
            context_to_revise=solution_draft
        )

        # Step 6: Final verification via bidirectional check (if applicable)
        verification_check = await self.generate(
            instruction="Now, verify the final answer by checking if it satisfies all original conditions and constraints. If possible, reverse the process to see if you return to the original setup.",
            context=revised_solution
        )

        # Step 7: Return the final verified answer as an integer between 0 and 999
        final_answer = await self.summarize(
            instruction="Extract only the final numerical answer from the verified solution. Ensure it is an integer between 0 and 999.",
            context_to_summarize=verification_check
        )

        return final_answer