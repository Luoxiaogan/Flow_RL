# Workflow ID: high_level_math_ganluo_27_0
# Benchmark: high_level_math_ganluo
# Data Indices: [2, 47]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis
        analysis = await self.generate(
            instruction="Analyze the problem to identify its mathematical domain (e.g., algebra, combinatorics, geometry) and key constraints."
        )

        # Step 2: Extract Key Elements
        extracted = await self.generate(
            instruction="From the analysis, extract all relevant quantities, variables, and conditions that must be used in the solution.",
            context=analysis
        )

        # Step 3: Parallel Exploration of Multiple Solution Paths
        task1 = self.generate(
            instruction="Solve using an algebraic approach if applicable — simplify expressions, apply formulas, or manipulate equations.",
            context=extracted
        )
        task2 = self.generate(
            instruction="Solve using a combinatorial or probabilistic approach if applicable — count arrangements, compute expected values, or use symmetry.",
            context=extracted
        )
        task3 = self.generate(
            instruction="Solve using number theory or modular arithmetic techniques — consider divisibility, primes, or congruences.",
            context=extracted
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer
        final_answer = await self.ensemble(
            instruction="Evaluate the three candidate solutions and select the one that best satisfies all constraints of the original problem. If they differ, choose the most mathematically consistent one.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional Refinement via Bidirectional Verification
        verification = await self.generate(
            instruction="Now verify the final answer by checking if it logically follows from the problem statement and satisfies all given conditions. If not, revise accordingly.",
            context=final_answer
        )

        return verification