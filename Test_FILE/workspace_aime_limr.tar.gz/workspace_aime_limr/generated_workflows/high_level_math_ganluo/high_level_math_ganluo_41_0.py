# Workflow ID: high_level_math_ganluo_41_0
# Benchmark: high_level_math_ganluo
# Data Indices: [97, 77]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify problem type and key constraints
        analysis = await self.generate(
            instruction="Analyze the problem to determine its category (e.g., number theory, algebra, combinatorics) and extract all explicit constraints."
        )

        # Step 2: Parallel exploration of multiple solution paths
        task1 = self.generate(
            instruction="Generate an algebraic approach based on the problem's structure.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Generate a number-theoretic or modular arithmetic approach if applicable.",
            context=analysis
        )
        task3 = self.generate(
            instruction="Generate a case-based or recursive strategy if the problem involves counting or sequences.",
            context=analysis
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble to select best-supported solution
        final_solution = await self.ensemble(
            instruction="Compare the three candidate solutions and choose the one that best satisfies all constraints and mathematical logic.",
            contexts_to_ensemble=solutions
        )

        # Step 4: Revise to improve clarity and correctness
        revised_solution = await self.revise(
            instruction="Critique the selected solution for logical consistency, completeness, and potential errors in computation or reasoning.",
            context_to_revise=final_solution
        )

        # Step 5: Final verification via bidirectional check (if feasible)
        verification = await self.generate(
            instruction="Create a reverse problem or test condition to verify that the answer is correct and consistent with the original constraints.",
            context=revised_solution
        )

        # Step 6: Return the final answer as an integer between 0 and 999
        return await self.summarize(
            context_to_summarize=revised_solution + "\n\n" + verification
        )