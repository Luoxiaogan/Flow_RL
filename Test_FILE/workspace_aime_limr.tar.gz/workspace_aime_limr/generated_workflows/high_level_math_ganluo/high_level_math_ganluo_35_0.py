# Workflow ID: high_level_math_ganluo_35_0
# Benchmark: high_level_math_ganluo
# Data Indices: [104, 27]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand the problem structure and identify key elements
        analysis = await self.generate(
            instruction="Analyze the problem to identify the mathematical domain (e.g., algebra, combinatorics), constraints, variables, and what needs to be computed."
        )

        # Step 2: Extract Key Elements — Isolate critical components like equations, sets, or conditions
        extracted = await self.generate(
            instruction="From the analysis, extract all relevant mathematical expressions, variables, and constraints in structured format.",
            context=analysis
        )

        # Step 3: Parallel Exploration — Generate multiple solution strategies (algebraic, geometric, recursive, etc.)
        task1 = self.generate("Generate an algebraic approach to solve this problem.")
        task2 = self.generate("Generate a combinatorial or number-theoretic approach if applicable.")
        task3 = self.generate("Generate a geometric interpretation if the problem involves shapes or coordinates.")
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble — Compare and synthesize the best path forward from multiple approaches
        ensemble_summary = await self.ensemble(
            instruction="Evaluate the three candidate solutions and select the most promising one based on clarity, feasibility, and alignment with the problem constraints.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Refinement Loop — Revise the selected solution iteratively for correctness and completeness
        revised_solution = await self.revise(
            instruction="Refine the solution by checking logical consistency, verifying all constraints, and ensuring no edge cases are missed.",
            context_to_revise=ensemble_summary
        )

        # Step 6: Final Verification — Use bidirectional verification to ensure robustness
        verification = await self.generate(
            instruction="Construct a reverse problem using the derived answer and verify that it satisfies the original equation or condition.",
            context=revised_solution
        )

        # Step 7: Output — Return the final integer answer between 0 and 999
        final_answer = await self.generate(
            instruction="Extract the final integer answer from the verified solution. Only return the number as an integer.",
            context=verification
        )

        return final_answer