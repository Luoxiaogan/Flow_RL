# Workflow ID: high_level_math_ganluo_0_0
# Benchmark: high_level_math_ganluo
# Data Indices: [15, 22]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify problem type and key elements
        analysis = await self.generate(
            instruction="Analyze the problem to determine its mathematical domain (e.g., algebra, geometry, combinatorics) and extract key constraints or structures."
        )

        # Step 2: Generate multiple solution paths based on identified structure
        path1 = self.generate(
            instruction="Generate an algebraic approach using complex numbers, if applicable.",
            context=analysis
        )
        path2 = self.generate(
            instruction="Generate a geometric or trigonometric approach, if applicable.",
            context=analysis
        )
        path3 = self.generate(
            instruction="Generate a symmetry-based or pattern-recognition approach, if applicable.",
            context=analysis
        )

        # Step 3: Run all approaches in parallel
        paths = await asyncio.gather(path1, path2, path3)

        # Step 4: Ensemble to select the best solution based on consistency and clarity
        final_solution = await self.ensemble(
            instruction="Compare the three candidate solutions. Choose the one that is most mathematically consistent, clearly reasoned, and satisfies all constraints of the original problem.",
            contexts_to_ensemble=paths
        )

        # Step 5: Optional refinement loop — revise if answer seems incomplete
        revised = await self.revise(
            instruction="Check whether the final solution fully addresses the problem and includes all necessary steps. If not, improve it.",
            context_to_revise=final_solution
        )

        return revised