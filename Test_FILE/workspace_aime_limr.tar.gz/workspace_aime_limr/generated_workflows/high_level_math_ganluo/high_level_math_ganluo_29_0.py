# Workflow ID: high_level_math_ganluo_29_0
# Benchmark: high_level_math_ganluo
# Data Indices: [88, 95]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis
        analysis = await self.generate(
            instruction="Analyze the problem to identify its category (e.g., algebra, combinatorics, number theory), key constraints, and required operations."
        )

        # Step 2: Extract Core Elements
        extracted = await self.generate(
            instruction="From the analysis, extract all mathematical expressions, variables, constraints, and conditions in structured format.",
            context=analysis
        )

        # Step 3: Parallel Exploration of Multiple Approaches
        task1 = self.generate(
            instruction="Propose an algebraic solution path based on the extracted constraints and expressions.",
            context=extracted
        )
        task2 = self.generate(
            instruction="Propose a combinatorial or case-based solution path if applicable.",
            context=extracted
        )
        task3 = self.generate(
            instruction="Propose a number-theoretic or modular arithmetic approach if relevant.",
            context=extracted
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble to Select Best Approach
        ensemble_result = await self.ensemble(
            instruction="Compare the three proposed approaches. Choose the one that best addresses the problem's structure and constraints.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Generate Final Solution Based on Chosen Path
        final_solution = await self.generate(
            instruction="Now solve the problem using the selected strategy. Provide a complete, step-by-step derivation leading to the final integer answer between 0 and 999.",
            context=ensemble_result
        )

        # Step 6: Bidirectional Verification
        verification = await self.generate(
            instruction="Create an inverse or checkable version of the solution — e.g., verify that the final answer satisfies all original constraints and makes sense mathematically.",
            context=final_solution
        )

        # Step 7: Final Ensemble for Robustness
        final_answer = await self.ensemble(
            instruction="You have two versions: the main solution and the verification. If they agree, return the answer. If not, revise the main solution using the verification insights and re-evaluate.",
            contexts_to_ensemble=[final_solution, verification]
        )

        return final_answer