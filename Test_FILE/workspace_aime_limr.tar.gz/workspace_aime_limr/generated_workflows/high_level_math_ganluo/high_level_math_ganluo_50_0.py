# Workflow ID: high_level_math_ganluo_50_0
# Benchmark: high_level_math_ganluo
# Data Indices: [34, 60]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify problem type and key elements
        analysis = await self.generate(
            instruction="Analyze the problem to determine its category (e.g., geometry, combinatorics, algebra) and extract all critical constraints, variables, and relationships."
        )

        # Step 2: Generate multiple solution paths based on identified categories
        category = analysis.split("Category:")[-1].split("\n")[0].strip()
        if "geometry" in category.lower():
            geom_solution = self.generate(
                instruction="Solve using geometric reasoning: interpret the graph or diagram, apply coordinate transformations, and find intersection points or distances."
            )
            algebraic_solution = self.generate(
                instruction="Solve using algebra: convert the geometric setup into equations, solve for unknowns, and compute required values."
            )
            solutions = [geom_solution, algebraic_solution]
        elif "combinatorics" in category.lower():
            brute_force = self.generate(
                instruction="Generate a brute-force enumeration approach for small cases to identify patterns."
            )
            optimization = self.generate(
                instruction="Apply combinatorial optimization techniques like dynamic programming or symmetry reduction to minimize computation."
            )
            solutions = [brute_force, optimization]
        else:
            # Default path: general mathematical reasoning
            basic_approach = self.generate(
                instruction="Apply standard algebraic or number-theoretic techniques appropriate to this problem type."
            )
            recursive_approach = self.generate(
                instruction="Explore recursive structures or generating functions that may model the problem's behavior."
            )
            solutions = [basic_approach, recursive_approach]

        # Step 3: Ensemble to select best solution from multiple approaches
        final_answer = await self.ensemble(
            instruction="Compare the candidate solutions and select the one that satisfies all constraints and is most mathematically sound.",
            contexts_to_ensemble=solutions
        )

        # Step 4: Refine the answer through iterative verification
        refined = await self.revise(
            instruction="Verify the selected solution by checking edge cases, recalculating critical steps, and ensuring it meets all original conditions.",
            context_to_revise=final_answer
        )

        return refined