# Workflow ID: high_level_math_ganluo_15_0
# Benchmark: high_level_math_ganluo
# Data Indices: [24, 115]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand the problem structure and identify key elements
        analysis = await self.generate(
            instruction="Identify the type of problem (geometry, algebra, number theory, etc.), extract all given quantities, constraints, and what needs to be found. Be precise about variables and relationships."
        )

        # Step 2: Parallel Exploration — Try multiple solution paths based on problem type
        tasks = [
            self.generate(
                instruction="Propose an algebraic approach to solve this problem.",
                context=analysis
            ),
            self.generate(
                instruction="Propose a geometric or coordinate-based approach if applicable.",
                context=analysis
            ),
            self.generate(
                instruction="Propose a combinatorial or case-based approach if relevant.",
                context=analysis
            )
        ]
        candidate_solutions = await asyncio.gather(*tasks)

        # Step 3: Ensemble — Synthesize best approaches from diverse perspectives
        ensemble_summary = await self.ensemble(
            instruction="Compare the three proposed solutions. Identify which one(s) are most likely correct based on mathematical soundness, clarity, and alignment with the original problem constraints.",
            contexts_to_ensemble=candidate_solutions
        )

        # Step 4: Refinement Loop — Improve the top candidate through iterative revision
        refined_solution = ensemble_summary
        for _ in range(2):  # Two rounds of refinement
            revised = await self.revise(
                instruction="Check for logical consistency, computational errors, and whether the solution satisfies all constraints in the original problem. Fix any mistakes and clarify reasoning.",
                context_to_revise=refined_solution
            )
            refined_solution = revised

        # Step 5: Final Verification — Ensure answer is an integer between 0–999 and makes sense
        final_answer = await self.generate(
            instruction="Based on the refined solution, extract the final numerical answer. Verify that it is an integer between 0 and 999 inclusive. If not, re-evaluate the logic.",
            context=refined_solution
        )

        return final_answer