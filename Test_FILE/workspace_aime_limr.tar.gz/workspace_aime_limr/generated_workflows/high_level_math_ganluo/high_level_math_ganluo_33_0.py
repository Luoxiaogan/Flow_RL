# Workflow ID: high_level_math_ganluo_33_0
# Benchmark: high_level_math_ganluo
# Data Indices: [3, 28]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify domain and key constraints
        analysis = await self.generate(
            instruction="Analyze the problem to determine its mathematical domain (e.g., algebra, geometry, number theory) and extract all given conditions and what needs to be found."
        )

        # Step 2: Generate multiple solution paths in parallel — diverge
        task1 = self.generate(
            instruction="Generate an algebraic approach based on the problem structure.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Generate a geometric or coordinate-based interpretation if applicable.",
            context=analysis
        )
        task3 = self.generate(
            instruction="Generate a combinatorial or number-theoretic approach if relevant.",
            context=analysis
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 3: Summarize each path to focus on core reasoning
        summaries = [await self.summarize(sol) for sol in solutions]

        # Step 4: Ensemble to select best-supported solution path
        selected_path = await self.ensemble(
            instruction="Select the most logically consistent and mathematically sound solution path from the candidates.",
            contexts_to_ensemble=summaries
        )

        # Step 5: Refine the selected path iteratively to eliminate errors
        refined_solution = await self.revise(
            instruction="Review the selected solution path for logical gaps, calculation errors, or missing steps. Improve clarity and correctness.",
            context_to_revise=selected_path
        )

        # Step 6: Final verification using bidirectional check
        verification = await self.generate(
            instruction="Construct a reverse problem or test case that would validate the final answer. Confirm it satisfies all original constraints.",
            context=refined_solution
        )

        # Step 7: Return the final answer as an integer between 0–999
        return await self.summarize(verification)