# Workflow ID: high_level_math_ganluo_48_0
# Benchmark: high_level_math_ganluo
# Data Indices: [13, 116]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis – Understand structure and constraints
        analysis = await self.generate(
            instruction="Analyze the problem to identify key mathematical concepts, variables, and constraints."
        )

        # Step 2: Parallel Exploration – Generate multiple solution paths (e.g., algebraic, combinatorial, number-theoretic)
        task1 = self.generate(
            instruction="Generate an algebraic approach based on the problem's structure.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Generate a combinatorial or counting-based strategy if applicable.",
            context=analysis
        )
        task3 = self.generate(
            instruction="Generate a number-theoretic or modular arithmetic approach if relevant.",
            context=analysis
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble – Synthesize best candidate from diverse approaches
        ensemble_answer = await self.ensemble(
            instruction="Compare and synthesize the three proposed solutions. Select the most logically consistent and mathematically sound answer.",
            contexts_to_ensemble=solutions
        )

        # Step 4: Refinement Loop – Revise based on internal consistency checks
        revised_answer = await self.revise(
            instruction="Critique the ensemble result for logical flaws, missing edge cases, or calculation errors. Improve rigorously.",
            context_to_revise=ensemble_answer
        )

        # Step 5: Final Verification – Use bidirectional reasoning to validate
        verification = await self.generate(
            instruction="Now, construct a reverse problem using the final answer as a given. Verify that solving this inverse yields back the original problem’s conditions.",
            context=revised_answer
        )

        # Step 6: Return final integer answer (must be between 0–999)
        return await self.summarize(
            context_to_summarize=f"{revised_answer}\n\n{verification}"
        )