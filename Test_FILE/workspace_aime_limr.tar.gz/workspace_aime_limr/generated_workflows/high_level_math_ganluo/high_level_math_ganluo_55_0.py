# Workflow ID: high_level_math_ganluo_55_0
# Benchmark: high_level_math_ganluo
# Data Indices: [0, 35]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify problem type and structure
        analysis = await self.generate(
            instruction="Analyze the problem and identify its category (e.g., algebra, geometry, combinatorics) and key constraints."
        )

        # Step 2: Generate multiple solution strategies in parallel
        task1 = self.generate(
            instruction="Generate an algebraic approach to solve this problem.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Generate a geometric or visual approach if applicable.",
            context=analysis
        )
        task3 = self.generate(
            instruction="Generate a combinatorial or number-theoretic approach if applicable.",
            context=analysis
        )
        
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble the best solution based on coherence and alignment with problem
        final_solution = await self.ensemble(
            instruction="Select the most coherent and mathematically sound solution from the candidates.",
            contexts_to_ensemble=solutions
        )

        # Step 4: Revise to ensure correctness — test against known constraints or edge cases
        revised_solution = await self.revise(
            instruction="Review the solution carefully for logical consistency, mathematical rigor, and adherence to all problem constraints.",
            context_to_revise=final_solution
        )

        # Step 5: Final summary to extract the answer in required format
        answer = await self.summarize(
            context_to_summarize=revised_solution
        )

        return answer