# Workflow ID: high_level_math_ganluo_6_0
# Benchmark: high_level_math_ganluo
# Data Indices: [49, 23]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand the problem structure and domain
        analysis = await self.generate(
            instruction="Analyze the problem to identify its mathematical domain (e.g., algebra, geometry, number theory), key constraints, and required techniques."
        )

        # Step 2: Extract Key Elements — Isolate critical variables, equations, or conditions
        extracted = await self.generate(
            instruction="From the analysis, extract all relevant mathematical expressions, constraints, and target quantities that must be computed.",
            context=analysis
        )

        # Step 3: Parallel Exploration — Generate multiple solution strategies
        task1 = self.generate(
            instruction="Propose an algebraic approach to solve this problem, focusing on equation manipulation and substitution."
        )
        task2 = self.generate(
            instruction="Propose a geometric or coordinate-based approach if applicable; otherwise, explain why it's not suitable."
        )
        task3 = self.generate(
            instruction="Propose a combinatorial or number-theoretic strategy based on divisibility, modular arithmetic, or symmetry."
        )
        strategies = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble — Select the most promising strategy
        chosen_strategy = await self.ensemble(
            instruction="Evaluate the three proposed strategies and select the one that best fits the problem’s structure and constraints.",
            contexts_to_ensemble=strategies
        )

        # Step 5: Generate Full Solution — Build step-by-step reasoning based on chosen strategy
        solution_draft = await self.generate(
            instruction="Using the selected strategy, generate a complete, logically structured solution with clear steps and justifications.",
            context=chosen_strategy
        )

        # Step 6: Iterative Refinement — Revise solution using multiple angles
        revise1 = self.revise(
            instruction="Check for logical consistency in each step of the solution. Identify any assumptions or gaps in reasoning.",
            context_to_revise=solution_draft
        )
        revise2 = self.revise(
            instruction="Verify that the final answer satisfies all given constraints in the original problem statement.",
            context_to_revise=revise1
        )
        refined_solution = await self.revise(
            instruction="Ensure clarity, correctness, and completeness—especially in edge cases or ambiguous parts.",
            context_to_revise=revise2
        )

        # Step 7: Final Verification — Bidirectional check or summary
        verification = await self.generate(
            instruction="Summarize the entire solution briefly and then verify that it leads back to the correct answer by re-evaluating the core logic.",
            context=refined_solution
        )

        return verification