# Workflow ID: high_level_math_ganluo_2_0
# Benchmark: high_level_math_ganluo
# Data Indices: [87, 9]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify problem type and key elements
        analysis = await self.generate(
            instruction="Identify the mathematical domain (e.g., algebra, geometry, number theory) and the main goal of this problem."
        )

        # Step 2: Generate multiple solution paths based on the identified domain
        tasks = [
            self.generate(
                instruction="Generate an algebraic approach if the problem involves expressions or equations.",
                context=analysis
            ),
            self.generate(
                instruction="Generate a geometric approach if the problem involves shapes, coordinates, or areas.",
                context=analysis
            ),
            self.generate(
                instruction="Generate a combinatorial or probabilistic approach if counting or uncertainty is involved.",
                context=analysis
            )
        ]
        solutions = await asyncio.gather(*tasks)

        # Step 3: Summarize each candidate solution to extract key steps and assumptions
        summaries = []
        for sol in solutions:
            summary = await self.summarize(sol)
            summaries.append(summary)

        # Step 4: Ensemble the best solution by comparing clarity, correctness, and alignment with problem constraints
        final_answer = await self.ensemble(
            instruction="Select the most coherent and mathematically sound solution from the candidates. Ensure it directly answers the question and satisfies all conditions.",
            contexts_to_ensemble=summaries
        )

        # Step 5: Revise the final answer using a second perspective to catch subtle errors
        revised_answer = await self.revise(
            instruction="Review the selected solution for logical consistency, correct application of techniques, and absence of arithmetic or conceptual mistakes.",
            context_to_revise=final_answer
        )

        return revised_answer