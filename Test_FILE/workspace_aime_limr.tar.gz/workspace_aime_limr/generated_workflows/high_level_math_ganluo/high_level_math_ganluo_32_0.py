# Workflow ID: high_level_math_ganluo_32_0
# Benchmark: high_level_math_ganluo
# Data Indices: [91, 110]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis – Understand problem type and structure
        analysis = await self.generate(
            instruction="Identify the mathematical domain (e.g., geometry, combinatorics, number theory) and key constraints from the problem statement."
        )

        # Step 2: Extract Key Elements – Isolate variables, conditions, or known values
        extracted = await self.generate(
            instruction="From the problem, extract all explicit numerical values, equations, constraints, and unknowns in structured format.",
            context=analysis
        )

        # Step 3: Parallel Exploration – Generate multiple solution paths
        task1 = self.generate(
            instruction="Propose an algebraic approach based on the extracted elements.",
            context=extracted
        )
        task2 = self.generate(
            instruction="Propose a geometric or coordinate-based approach if applicable.",
            context=extracted
        )
        task3 = self.generate(
            instruction="Propose a combinatorial or case-based strategy if relevant.",
            context=extracted
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer – Compare and synthesize best path
        final_answer = await self.ensemble(
            instruction="Evaluate the three candidate solutions and select the one that satisfies all constraints and is most mathematically sound.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Refinement Loop – Revise if needed based on internal consistency checks
        revised = await self.revise(
            instruction="Check the final answer against all original constraints. If it fails any check, revise the reasoning to correct the error.",
            context_to_revise=final_answer
        )

        return revised