# Workflow ID: mbpp_141_0
# Benchmark: mbpp
# Data Indices: [310]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="""
            Extract the function name from the test cases in the problem description.
            Return ONLY the function name, nothing else.
            """,
            context=""
        )
        
        # Step 2: Generate the initial Python code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the task described in the problem.
            Requirements:
            1. Include ALL necessary import statements at the top (e.g., 'import heapq').
            2. Handle edge cases such as empty inputs, None values, or boundary conditions.
            3. Ensure the function is efficient and follows Pythonic best practices.
            4. Return ONLY the executable Python code, no explanations.
            """,
            context=""
        )
        
        # Step 3: Revise the code to fix issues
        final_code = await self.revise(
            instruction="""
            Review the provided Python code and make improvements if necessary.
            Focus on:
            1. Missing import statements.
            2. Unhandled edge cases.
            3. Code efficiency and readability.
            Return ONLY the corrected Python code, no explanations.
            """,
            context=initial_code
        )
        
        return final_code