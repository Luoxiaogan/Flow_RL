# Workflow ID: mbpp_217_0
# Benchmark: mbpp
# Data Indices: [251]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases in the problem description. "
                        "Return ONLY the function name as plain text, without any additional words or punctuation.",
            context=""
        )
        
        # Step 2: Generate the initial Python code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the task described in the problem.
            Requirements:
            1. Include ALL necessary import statements at the top of the function.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Follow Python best practices and write clean, efficient code.
            4. Return ONLY the executable Python code without any explanations or additional text.
            """,
            context=""
        )
        
        # Step 3: Revise the code for correctness and completeness
        final_code = await self.revise(
            instruction=f"""
            Review the following Python code for the function '{func_name}':
            
            {initial_code}
            
            Check for the following:
            1. Are all necessary imports included?
            2. Are edge cases handled properly?
            3. Are there any logical or syntactical errors?
            4. Does the code follow Python best practices?
            
            Return the corrected and improved Python code ONLY, without any explanations or additional text.
            """,
            context=initial_code
        )
        
        # Step 4: Return the final code
        return final_code