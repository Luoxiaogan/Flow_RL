# Workflow ID: mbpp_349_0
# Benchmark: mbpp
# Data Indices: [346]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract ONLY the function name from the test cases in the problem description. "
                        "Return ONLY the function name as plain text, without any additional explanation.",
            context=""
        )
        
        # Step 2: Generate the initial Python code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the problem described in the problem text.
            Requirements:
            1. Include ALL necessary import statements at the top.
            2. Handle edge cases such as empty inputs, None values, or boundary conditions.
            3. Follow Pythonic best practices (e.g., use list comprehensions where appropriate).
            4. Return ONLY the executable Python code, without any explanations or comments.
            """,
            context=""
        )
        
        # Step 3: Revise the code for completeness and correctness
        final_code = await self.revise(
            instruction="Review the provided Python code and improve it if necessary. "
                        "Ensure that: "
                        "1. All required imports are included. "
                        "2. Edge cases are handled properly. "
                        "3. The code is efficient and follows Pythonic conventions. "
                        "Return ONLY the corrected Python code, without any explanations or comments.",
            context=initial_code
        )
        
        # Step 4: Return the final code
        return final_code