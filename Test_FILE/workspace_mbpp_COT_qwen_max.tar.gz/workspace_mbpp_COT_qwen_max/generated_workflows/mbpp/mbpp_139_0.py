# Workflow ID: mbpp_139_0
# Benchmark: mbpp
# Data Indices: [125]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio

        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases in the problem description. "
                        "Return ONLY the function name, nothing else.",
            context=""
        )

        # Step 2: Generate initial Python code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name.strip()}' that solves the task described in the problem.
            Requirements:
            1. Include ALL necessary import statements at the top.
            2. Handle edge cases explicitly:
               - Empty inputs (e.g., empty tuples or lists).
               - Single-element inputs.
               - Boundary values.
            3. Ensure the function signature matches the test cases.
            4. Return ONLY the executable Python code, no explanations.
            """,
            context=""
        )

        # Step 3: Revise the code for correctness and completeness
        final_code = await self.revise(
            instruction="Carefully review the provided code. Fix any issues related to:"
                        "1. Missing imports."
                        "2. Incorrect handling of edge cases."
                        "3. Inefficiencies or suboptimal logic."
                        "4. Syntax errors."
                        "Return ONLY the corrected and complete Python code.",
            context=initial_code
        )

        # Optional Step 4: Ensemble for final decision (if multiple revisions are needed)
        # Uncomment and adapt this section if multiple revisions are generated
        # candidates = [final_code]  # Add other candidates here
        # final_code = await self.ensemble(
        #     instruction="Select the best implementation based on correctness, efficiency, and readability.",
        #     contexts=candidates
        # )

        return final_code