# Workflow ID: mbpp_291_0
# Benchmark: mbpp
# Data Indices: [193]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="""
            Extract the function name from the test cases provided in the problem description.
            Return ONLY the function name as plain text, without any additional explanation or quotes.
            """,
            context=""
        )
        
        # Step 2: Generate initial code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the task described in the problem.
            Requirements:
            1. Include ALL necessary import statements at the top.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Ensure the function signature matches the test cases.
            4. Return ONLY the executable Python code, without any explanations or comments.
            """,
            context=""
        )
        
        # Step 3: Revise the code
        final_code = await self.revise(
            instruction="""
            Review the provided code and make improvements where necessary.
            Focus on:
            1. Adding any missing import statements.
            2. Fixing logical errors or omissions.
            3. Ensuring all edge cases are handled properly.
            4. Adhering to Pythonic best practices.
            Return ONLY the corrected code as plain text.
            """,
            context=initial_code
        )
        
        # Step 4: Return the final code
        return final_code