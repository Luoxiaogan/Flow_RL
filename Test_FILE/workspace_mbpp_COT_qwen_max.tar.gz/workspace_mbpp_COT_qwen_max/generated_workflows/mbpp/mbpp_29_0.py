# Workflow ID: mbpp_29_0
# Benchmark: mbpp
# Data Indices: [62]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio

        # Step 1: Extract function name and parameters
        func_info = await self.generate(
            instruction="""
            Extract the function name and its parameters from the test cases.
            Return ONLY the function name and parameters in the format:
            'function_name(param1, param2, ...)'
            """,
            context=""
        )

        # Step 2: Generate initial Python function code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_info}' that solves this task.
            Requirements:
            1. Include ALL necessary import statements at the top.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Follow Python best practices and write clean, efficient code.
            4. Return ONLY the executable Python code, no explanations.
            """,
            context=""
        )

        # Step 3: Revise the code for robustness
        final_code = await self.revise(
            instruction="""
            Review the provided code and make the following improvements:
            1. Ensure all necessary imports are included.
            2. Handle all possible edge cases (empty inputs, None, boundaries).
            3. Optimize for readability and efficiency.
            4. Return ONLY the corrected Python code, no explanations.
            """,
            context=initial_code
        )

        return final_code