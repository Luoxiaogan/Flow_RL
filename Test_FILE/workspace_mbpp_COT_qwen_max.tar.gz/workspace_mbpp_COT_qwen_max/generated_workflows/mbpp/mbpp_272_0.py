# Workflow ID: mbpp_272_0
# Benchmark: mbpp
# Data Indices: [358]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        # Add other imports if needed, e.g., json, re
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="""
            Analyze the problem description and test cases to determine the function name.
            Return ONLY the function name as plain text, without any additional explanation or quotes.
            """,
            context=""
        )
        
        # Step 2: Generate the initial Python function code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the problem described in the original problem text.
            Requirements:
            1. Include ALL necessary import statements at the top.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Ensure the function signature matches the test cases provided in the problem description.
            4. Return ONLY the executable Python code, without any explanations or comments.
            """,
            context=""
        )
        
        # Step 3: Revise the code for completeness and correctness
        final_code = await self.revise(
            instruction="""
            Review the provided Python function code and make the following improvements:
            1. Ensure all necessary imports are included.
            2. Check for and handle any missing edge cases.
            3. Verify that the function signature matches the test cases.
            4. Return ONLY the corrected Python code, without any explanations or comments.
            """,
            context=initial_code
        )
        
        return final_code