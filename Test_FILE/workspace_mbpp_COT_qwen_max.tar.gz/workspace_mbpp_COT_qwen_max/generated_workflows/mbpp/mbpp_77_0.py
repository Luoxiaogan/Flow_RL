# Workflow ID: mbpp_77_0
# Benchmark: mbpp
# Data Indices: [28]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio

        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="""
            Extract the function name from the test cases in the problem description.
            Return ONLY the function name, nothing else. If multiple names are possible,
            choose the most appropriate one based on the test cases.
            """,
            context=""
        )

        # Step 2: Generate the initial Python function code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the problem described.
            Requirements:
            1. Include ALL necessary import statements at the top (e.g., 'import math', 'from collections import Counter').
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Ensure the function is efficient and follows Pythonic best practices.
            4. Return ONLY the executable Python code, without any explanations or comments.
            """,
            context=""
        )

        # Step 3: Revise the code for completeness and correctness
        final_code = await self.revise(
            instruction="""
            Review the provided Python code and make improvements where necessary.
            Specifically:
            1. Check for missing import statements and add them if needed.
            2. Ensure all edge cases are handled (e.g., empty inputs, None values).
            3. Optimize the code for efficiency without sacrificing readability.
            4. Return ONLY the corrected Python code, without any explanations or comments.
            """,
            context=initial_code
        )

        # Step 4: Return the final code
        return final_code