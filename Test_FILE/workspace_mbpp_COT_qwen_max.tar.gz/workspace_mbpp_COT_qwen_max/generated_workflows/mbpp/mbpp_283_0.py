# Workflow ID: mbpp_283_0
# Benchmark: mbpp
# Data Indices: [367]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases provided in the problem description. "
                        "Return ONLY the function name, nothing else.",
            context=""
        )
        
        # Step 2: Generate the initial Python function code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the problem described in the problem text.
            Requirements:
            1. Include ALL necessary import statements at the top of the function.
            2. Handle edge cases such as empty inputs, None, or boundary values.
            3. Ensure the function signature matches the test cases provided.
            4. Return ONLY the executable Python code, no explanations.
            """,
            context=""
        )
        
        # Step 3: Revise the code to improve quality
        revised_code = await self.revise(
            instruction=f"""
            Critique and improve the following Python function code:
            - Check for missing imports and add them if necessary.
            - Optimize the code for efficiency and readability.
            - Ensure all edge cases are handled correctly.
            - Return ONLY the corrected Python code, no explanations.
            """,
            context=initial_code
        )
        
        # Optional Step 4: Ensemble multiple solutions (if needed)
        # Uncomment the following block for complex problems
        """
        candidate_1 = await self.generate(
            instruction=f"Write an alternative implementation of the function '{func_name}'.",
            context=""
        )
        candidate_2 = await self.generate(
            instruction=f"Write another alternative implementation of the function '{func_name}'.",
            context=""
        )
        final_code = await self.ensemble(
            instruction=f"""
            Evaluate the following implementations of the function '{func_name}':
            - Select the most efficient, readable, and robust implementation.
            - Return ONLY the selected Python code, no explanations.
            """,
            contexts=[revised_code, candidate_1, candidate_2]
        )
        """
        
        # Step 5: Return the final code
        return revised_code