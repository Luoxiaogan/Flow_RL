# Workflow ID: mbpp_305_0
# Benchmark: mbpp
# Data Indices: [19]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio

        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases in the problem description. "
                        "Return ONLY the function name as plain text, without quotes or additional information.",
            context=""
        )
        func_name = func_name.strip()  # Remove any leading/trailing whitespace

        # Step 2: Generate initial Python code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the problem described in the original problem text.
            Requirements:
            1. Include ALL necessary import statements at the top of the function.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Follow Pythonic best practices for readability and efficiency.
            4. Return ONLY the executable Python code, without any explanations or comments outside the function.
            """,
            context=""
        )

        # Step 3: Revise the code for correctness and completeness
        final_code = await self.revise(
            instruction=f"""
            Review the following Python code for the function '{func_name}':
            - Ensure all necessary imports are included.
            - Verify that edge cases are properly handled.
            - Check for Pythonic conventions and efficiency.
            - Return ONLY the corrected Python code, without any explanations or comments outside the function.
            """,
            context=initial_code
        )

        return final_code