# Workflow ID: mbpp_197_0
# Benchmark: mbpp
# Data Indices: [118]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        import json  # For parsing JSON if needed
        
        # Step 1: Extract the function name and key requirements
        func_name = await self.generate(
            instruction="""
            Extract the function name from the test cases in the problem description.
            Return ONLY the function name, nothing else.
            """,
            context=""
        )
        
        # Ensure the function name is clean (strip whitespace)
        func_name = func_name.strip()
        
        # Step 2: Generate the initial implementation
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the following task:
            {self.problem_text}
            
            Requirements:
            1. Include ALL necessary import statements at the top (e.g., import re, math, etc.)
            2. Handle edge cases such as empty inputs, None values, and boundary conditions
            3. Follow Pythonic best practices
            4. Return ONLY the executable Python code, no explanations
            
            Example Test Cases:
            assert {func_name}("ac") == 'Found a match!'
            assert {func_name}("dc") == 'Not matched!'
            assert {func_name}("abba") == 'Found a match!'
            """,
            context=""
        )
        
        # Step 3: Revise the code for completeness and robustness
        final_code = await self.revise(
            instruction=f"""
            Review and improve the following code for the function '{func_name}':
            {initial_code}
            
            Instructions:
            1. Ensure all edge cases are handled (e.g., empty strings, None inputs)
            2. Verify that all necessary imports are included
            3. Optimize for efficiency and readability
            4. Return ONLY the corrected code, no explanations
            """,
            context=initial_code
        )
        
        # Step 4: Return the final code
        return final_code