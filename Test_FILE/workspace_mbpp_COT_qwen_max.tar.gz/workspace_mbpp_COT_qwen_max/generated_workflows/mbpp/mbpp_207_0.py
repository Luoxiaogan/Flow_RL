# Workflow ID: mbpp_207_0
# Benchmark: mbpp
# Data Indices: [296]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract Function Name
        func_name = await self.generate(
            instruction="What is the function name in the test cases? Return ONLY the name, nothing else.",
            context=""
        )
        
        # Step 2: Generate Initial Code
        code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves this task.
            Requirements:
            1. Include ALL necessary import statements at the top
            2. Handle edge cases (empty inputs, None, boundaries)
            3. Ensure the function signature matches the provided test cases
            4. Return ONLY the executable Python code, no explanations
            """,
            context=""
        )
        
        # Step 3: Revise the Code
        final_code = await self.revise(
            instruction="""
            Check and improve the given code:
            1. Ensure all necessary imports are included
            2. Verify edge case handling (empty inputs, None, boundaries)
            3. Make sure the function signature matches the test cases
            4. Fix any issues found
            5. Return ONLY the corrected code
            """,
            context=code
        )
        
        return final_code