# Workflow ID: mbpp_90_0
# Benchmark: mbpp
# Data Indices: [355]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        import re  # Import regex module in case it's needed for parsing
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases. "
                        "Return ONLY the function name as plain text, nothing else.",
            context=""
        )
        
        # Step 2: Generate the initial Python code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the given task.
            Requirements:
            1. Include ALL necessary import statements at the top (e.g., 'import re').
            2. Handle edge cases such as empty strings, None inputs, and boundary values.
            3. Ensure the function adheres to Pythonic conventions and passes the provided test cases.
            4. Return ONLY the executable Python code, no explanations or additional text.
            """,
            context=""
        )
        
        # Step 3: Revise the generated code
        final_code = await self.revise(
            instruction="Review the following code for correctness and completeness. "
                        "Fix any issues with missing imports, edge case handling, or syntax errors. "
                        "Return ONLY the corrected Python code.",
            context=initial_code
        )
        
        # Optional Step 4: Ensemble evaluation (if multiple solutions are generated)
        # Uncomment the following lines if you want to compare multiple approaches
        # approach_1 = await self.generate(instruction="...", context="")
        # approach_2 = await self.generate(instruction="...", context="")
        # final_code = await self.ensemble(
        #     instruction="Select the best solution based on correctness, simplicity, and performance.",
        #     contexts=[approach_1, approach_2]
        # )
        
        return final_code