# Workflow ID: mbpp_142_0
# Benchmark: mbpp
# Data Indices: [92]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        import re  # For regex-related tasks
        
        # Step 1: Extract the function name from the test cases
        func_name = await self.generate(
            instruction="Extract the function name from the test cases in the problem description. "
                        "Return ONLY the function name, nothing else.",
            context=""
        )
        
        # Step 2: Generate the initial Python function code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the task described in the problem.
            Requirements:
            1. Include ALL necessary import statements at the top (e.g., import re for regex tasks).
            2. Handle edge cases such as empty strings, None inputs, or boundary values.
            3. Ensure the function is Pythonic and follows best practices.
            4. Return ONLY the executable Python code, no explanations.
            """,
            context=""
        )
        
        # Step 3: Revise the code for correctness and completeness
        final_code = await self.revise(
            instruction="Critique and improve the provided Python code. "
                        "Check for missing imports, unhandled edge cases, and inefficiencies. "
                        "Ensure the function adheres to Python best practices. "
                        "Return ONLY the corrected code, no explanations.",
            context=initial_code
        )
        
        return final_code