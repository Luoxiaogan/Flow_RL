# Workflow ID: mbpp_19_0
# Benchmark: mbpp
# Data Indices: [370]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract function name and parameters
        func_signature = await self.generate(
            instruction="""
            Extract the function name and its parameters from the problem description or test cases.
            Return ONLY the function signature in the format 'function_name(param1, param2, ...)', nothing else.
            """,
            context=""
        )
        
        # Step 2: Generate initial Python code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function with the signature '{func_signature}' that solves this task.
            Requirements:
            1. Include ALL necessary import statements at the top.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Ensure the implementation is efficient and Pythonic.
            4. Return ONLY the executable Python code, no explanations.
            """,
            context=""
        )
        
        # Step 3: Revise the code for missing imports and edge cases
        final_code = await self.revise(
            instruction="""
            Review the provided Python code and make necessary improvements:
            1. Add any missing import statements.
            2. Ensure all edge cases are handled appropriately.
            3. Optimize for readability and efficiency.
            Return ONLY the corrected Python code, no explanations.
            """,
            context=initial_code
        )
        
        return final_code