# Workflow ID: mbpp_107_0
# Benchmark: mbpp
# Data Indices: [199]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        # Add any necessary imports here

        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="""
            Extract the function name from the test cases or problem description.
            Return ONLY the function name as plain text, without any additional explanation.
            If multiple names are possible, choose the most logical one based on the test cases.
            """,
            context=""
        )
        func_name = func_name.strip()  # Remove any leading/trailing whitespace

        # Step 2: Generate initial code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the given task.
            Requirements:
            1. Include ALL necessary import statements at the top of the code.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Ensure the function signature matches the test cases provided.
            4. Return ONLY the executable Python code, without any explanations or comments.
            """,
            context=""
        )

        # Step 3: Revise the code for correctness and quality
        final_code = await self.revise(
            instruction="""
            Review and improve the provided Python code. Focus on the following:
            1. Ensure all test cases pass successfully.
            2. Fix any missing imports or incorrect handling of edge cases.
            3. Improve code readability and adherence to Python best practices.
            4. Return ONLY the corrected Python code, without any explanations or comments.
            """,
            context=initial_code
        )

        # Step 4: Return the final code
        return final_code