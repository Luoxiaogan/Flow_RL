# Workflow ID: mbpp_17_0
# Benchmark: mbpp
# Data Indices: [235]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        import json  # For parsing JSON if needed
        import re    # For regex operations if needed
        
        # Step 1: Extract the function name from the test cases
        func_name = await self.generate(
            instruction="Extract ONLY the function name from the test cases. Return it as plain text without quotes or additional explanations.",
            context=""
        )
        
        # Step 2: Generate the initial Python function code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the problem described in the original problem text.
            Requirements:
            1. Include ALL necessary import statements at the top of the function.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Ensure the function signature matches the test cases provided in the original problem text.
            4. Return ONLY the executable Python code, without any explanations or comments outside the function.
            """,
            context=""
        )
        
        # Step 3: Revise the initial code for quality assurance
        revised_code = await self.revise(
            instruction="""
            Review the provided Python function code for the following issues:
            1. Missing or unnecessary import statements.
            2. Failure to handle edge cases such as empty inputs, None values, or boundary conditions.
            3. Inefficiencies or deviations from Pythonic best practices.
            4. Mismatches with the function signature in the test cases.
            Fix all identified issues and return ONLY the corrected Python code.
            """,
            context=initial_code
        )
        
        # Step 4: (Optional) Use Ensemble for robustness
        # Generate alternative solutions in parallel
        alt_solution_1 = await self.generate(
            instruction=f"""
            Write an alternative Python function named '{func_name}' that solves the problem differently.
            Follow the same requirements as the initial code generation step.
            """,
            context=""
        )
        alt_solution_2 = await self.generate(
            instruction=f"""
            Write another alternative Python function named '{func_name}' that solves the problem using a completely different approach.
            Follow the same requirements as the initial code generation step.
            """,
            context=""
        )
        
        # Select the best solution using Ensemble
        final_code = await self.ensemble(
            instruction="""
            Evaluate the provided candidate solutions and select the best one based on the following criteria:
            1. Correctness: The function must pass all test cases.
            2. Efficiency: Prefer solutions with optimal time and space complexity.
            3. Pythonic Style: Adherence to Python best practices.
            4. Edge Case Handling: Comprehensive handling of edge cases.
            Return ONLY the selected Python code.
            """,
            contexts=[revised_code, alt_solution_1, alt_solution_2]
        )
        
        # Step 5: Return the final code
        return final_code