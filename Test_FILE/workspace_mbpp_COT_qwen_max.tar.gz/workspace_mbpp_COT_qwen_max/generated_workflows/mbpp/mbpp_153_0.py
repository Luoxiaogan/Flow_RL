# Workflow ID: mbpp_153_0
# Benchmark: mbpp
# Data Indices: [77]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio

        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract ONLY the function name from the test cases or problem description. "
                        "Return the function name as a plain string without any additional text.",
            context=""
        )

        # Step 2: Generate the initial Python code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the given task.
            Requirements:
            1. Include ALL necessary import statements at the top of the code.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Follow Python best practices and write clean, readable code.
            4. Return ONLY the executable Python code without any explanations or comments.
            """,
            context=""
        )

        # Step 3: Revise the code to ensure correctness and completeness
        final_code = await self.revise(
            instruction="Review the provided Python code and make improvements if necessary. "
                        "Ensure that all edge cases are handled, all required imports are included, "
                        "and the code adheres to Python best practices. "
                        "Return ONLY the corrected Python code without any explanations or comments.",
            context=initial_code
        )

        # Step 4: Return the final Python code
        return final_code