# Workflow ID: mbpp_363_0
# Benchmark: mbpp
# Data Indices: [350]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio

        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="""
            Extract the function name from the test cases or problem description.
            Return ONLY the function name as plain text, without quotes or additional explanation.
            """,
            context=""
        )

        # Step 2: Generate initial Python code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the following task:
            {self.problem_text}
            Requirements:
            1. Include ALL necessary import statements at the top of the function.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Ensure the function signature matches the test cases.
            4. Return ONLY the executable Python code without any explanations or comments.
            """,
            context=""
        )

        # Step 3: Revise the code for completeness and correctness
        final_code = await self.revise(
            instruction="""
            Review the provided Python code and make necessary improvements:
            1. Ensure all required imports are included.
            2. Verify that edge cases are handled appropriately.
            3. Fix any syntax or logical errors.
            4. Return ONLY the corrected Python code without explanations.
            """,
            context=initial_code
        )

        # Step 4: (Optional) Ensemble for final selection
        # Uncomment this section if multiple approaches are possible
        # alternative_code = await self.generate(
        #     instruction=f"""
        #     Write an alternative implementation for the function '{func_name}'.
        #     Follow the same requirements as before.
        #     """,
        #     context=""
        # )
        # final_code = await self.ensemble(
        #     instruction="Select the best implementation based on correctness, efficiency, and readability.",
        #     contexts=[final_code, alternative_code]
        # )

        return final_code