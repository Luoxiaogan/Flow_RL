# Workflow ID: mbpp_94_0
# Benchmark: mbpp
# Data Indices: [229]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        # import json  # Uncomment if you need JSON parsing
        # import re    # Uncomment if you need regex
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="""
            Extract the function name from the test cases or problem description.
            Return ONLY the function name as plain text, without any additional explanation.
            """,
            context=""
        )
        func_name = func_name.strip()  # Remove any leading/trailing whitespace

        # Step 2: Generate initial Python code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the given task.
            Requirements:
            1. Include ALL necessary import statements at the top of the code.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Ensure the function signature matches the test cases provided.
            4. Return ONLY the executable Python code, without any explanations or comments.
            """,
            context=""
        )

        # Step 3: Revise the code for correctness and completeness
        final_code = await self.revise(
            instruction="""
            Review the provided Python code and make the following improvements:
            1. Ensure all necessary imports are included.
            2. Fix any logical errors or inefficiencies.
            3. Handle edge cases that may not have been addressed.
            4. Make the code Pythonic and adhere to best practices.
            Return ONLY the corrected Python code, without any explanations.
            """,
            context=initial_code
        )

        # Step 4: Return the final code
        return final_code