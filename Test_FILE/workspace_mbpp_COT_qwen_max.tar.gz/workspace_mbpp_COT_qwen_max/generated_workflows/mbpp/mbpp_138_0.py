# Workflow ID: mbpp_138_0
# Benchmark: mbpp
# Data Indices: [137]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name from the test cases
        func_name = await self.generate(
            instruction="Extract the function name from the test cases in the problem description. "
                        "Return ONLY the function name, nothing else.",
            context=""
        )
        
        # Step 2: Generate the initial Python function code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the problem described in the problem text.
            Requirements:
            1. Include ALL necessary import statements at the top of the function.
            2. Handle edge cases such as empty inputs, None, or boundary values.
            3. Ensure the function signature matches the test cases provided.
            4. Return ONLY the executable Python code, no explanations or additional text.
            """,
            context=""
        )
        
        # Step 3: Revise the code to address missing imports and edge cases
        final_code = await self.revise(
            instruction="Check the provided code for the following issues and fix them:"
                        "1. Missing import statements."
                        "2. Unhandled edge cases (e.g., empty inputs, None, or boundary values)."
                        "3. Any syntax or logical errors."
                        "Return ONLY the corrected Python code, no explanations or additional text.",
            context=initial_code
        )
        
        # Step 4: Return the final Python function code
        return final_code