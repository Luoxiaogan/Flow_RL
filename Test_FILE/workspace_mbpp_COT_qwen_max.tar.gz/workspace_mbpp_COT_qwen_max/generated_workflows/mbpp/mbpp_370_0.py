# Workflow ID: mbpp_370_0
# Benchmark: mbpp
# Data Indices: [38]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract ONLY the function name from the test cases in the problem description. "
                        "Return the function name as plain text, without quotes or additional explanations.",
            context=""
        )
        
        # Step 2: Generate the initial code
        code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the following task:
            
            {self.problem_text}
            
            Requirements:
            1. Include ALL necessary import statements at the top of the code.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Ensure the function signature matches the test cases.
            4. Return ONLY the executable Python code, without any explanations or comments.
            """,
            context=""
        )
        
        # Step 3: Revise the code for correctness
        final_code = await self.revise(
            instruction=f"""
            Review the following Python code and make any necessary improvements:
            
            {code}
            
            Focus on:
            1. Adding any missing import statements.
            2. Handling edge cases that may have been overlooked.
            3. Fixing any syntax or logic errors.
            4. Ensuring the function passes the provided test cases.
            
            Return ONLY the corrected Python code, without any explanations or comments.
            """,
            context=code
        )
        
        return final_code