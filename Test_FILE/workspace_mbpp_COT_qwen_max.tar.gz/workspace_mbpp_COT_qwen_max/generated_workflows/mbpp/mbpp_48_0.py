# Workflow ID: mbpp_48_0
# Benchmark: mbpp
# Data Indices: [18]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        # import json  # Uncomment if you need JSON parsing
        # import re    # Uncomment if you need regex
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases. Return ONLY the function name, nothing else.",
            context=""
        )
        
        # Step 2: Generate the initial implementation
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves this task.
            Requirements:
            1. Include ALL necessary import statements at the top (if any).
            2. Handle edge cases such as empty strings, strings without numbers, or invalid inputs.
            3. Follow Python best practices (PEP 8).
            4. Return ONLY the executable Python code, no explanations.
            """,
            context=""
        )
        
        # Step 3: Revise the code for robustness
        final_code = await self.revise(
            instruction="""
            Review the provided code and ensure it meets the following criteria:
            1. All edge cases are handled correctly.
            2. Missing imports or syntax issues are fixed.
            3. The code adheres to Pythonic principles.
            4. It passes all test cases.
            Return ONLY the corrected code.
            """,
            context=initial_code
        )
        
        return final_code