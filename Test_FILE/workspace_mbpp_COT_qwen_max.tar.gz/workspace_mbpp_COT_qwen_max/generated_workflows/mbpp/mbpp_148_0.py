# Workflow ID: mbpp_148_0
# Benchmark: mbpp
# Data Indices: [163]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract ONLY the function name from the test cases in the problem description. "
                        "Return ONLY the name, nothing else.",
            context=""
        )
        
        # Step 2: Generate initial code
        code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the task described in the problem.
            Requirements:
            1. Include ALL necessary import statements at the top (e.g., import re, math, etc.)
            2. Handle edge cases such as empty inputs, None values, and boundary conditions
            3. Follow Python best practices for readability and efficiency
            4. Return ONLY the executable Python code, no explanations
            """,
            context=""
        )
        
        # Step 3: Revise the code
        final_code = await self.revise(
            instruction="Review the provided code for correctness, efficiency, and adherence to Python best practices. "
                        "Fix any issues with imports, edge cases, or logic. Return ONLY the corrected code.",
            context=code
        )
        
        return final_code