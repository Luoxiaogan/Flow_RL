# Workflow ID: mbpp_86_0
# Benchmark: mbpp
# Data Indices: [337]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio

        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="""
            Extract the function name from the test cases or problem description.
            Return ONLY the function name as plain text, without any additional explanation.
            """,
            context=""
        )

        # Step 2: Generate initial Python code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the problem described in the original problem text.
            Requirements:
            1. Include ALL necessary import statements at the top of the function.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Ensure the function adheres to Pythonic best practices.
            4. Return ONLY the executable Python code, without any explanations or comments.
            """,
            context=""
        )

        # Step 3: Revise the code for correctness and robustness
        final_code = await self.revise(
            instruction="""
            Review the provided Python code and make necessary improvements.
            Focus on:
            1. Missing import statements.
            2. Handling edge cases (e.g., empty inputs, None values, boundary conditions).
            3. Syntax errors or logical issues.
            4. Ensuring the code adheres to Pythonic best practices.
            Return ONLY the corrected Python code, without any explanations or comments.
            """,
            context=initial_code
        )

        # Step 4: Return the final code
        return final_code