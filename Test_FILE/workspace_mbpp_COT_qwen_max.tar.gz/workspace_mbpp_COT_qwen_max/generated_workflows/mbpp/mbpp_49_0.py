# Workflow ID: mbpp_49_0
# Benchmark: mbpp
# Data Indices: [79]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name from the test cases
        func_name = await self.generate(
            instruction="""
            Extract the function name from the test cases in the problem description. 
            Return ONLY the function name, nothing else. Ensure it's a valid Python identifier.
            """,
            context=""
        )
        
        # Step 2: Generate the initial Python code for the function
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the task described in the problem.
            Requirements:
            1. Include ALL necessary import statements at the top.
            2. Handle edge cases such as empty inputs, None, or boundary values.
            3. Ensure the function signature matches the test cases.
            4. Return ONLY the executable Python code, no explanations.
            """,
            context=""
        )
        
        # Step 3: Revise the code to address any issues
        final_code = await self.revise(
            instruction="""
            Review the provided Python code and make improvements where necessary.
            Focus on:
            1. Missing import statements.
            2. Edge case handling (empty inputs, None, boundaries).
            3. Code efficiency and readability.
            4. Ensuring the function passes all test cases.
            Return ONLY the corrected Python code.
            """,
            context=initial_code
        )
        
        # Step 4: Return the final, revised code
        return final_code