# Workflow ID: mbpp_366_0
# Benchmark: mbpp
# Data Indices: [270]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases. "
                        "Return ONLY the function name, nothing else.",
            context=""
        )
        
        # Step 2: Generate the initial implementation
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves this task:
            {self.problem_text}
            
            Requirements:
            1. Include ALL necessary import statements at the top of the function.
            2. Handle edge cases (e.g., empty strings, None inputs).
            3. Ensure the function is efficient and Pythonic.
            4. Return ONLY the executable Python code, no explanations.
            """,
            context=""
        )
        
        # Step 3: Revise the code for robustness
        final_code = await self.revise(
            instruction=f"""
            Review the following implementation of '{func_name}' and improve it:
            - Ensure all edge cases are handled (e.g., empty strings, None inputs).
            - Verify that the code is efficient and Pythonic.
            - Fix any syntax or logical errors.
            - Include ALL necessary import statements at the top.
            
            Return ONLY the corrected code, no explanations.
            """,
            context=initial_code
        )
        
        # Step 4: Return the final code
        return final_code