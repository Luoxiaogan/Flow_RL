# Workflow ID: mbpp_337_0
# Benchmark: mbpp
# Data Indices: [175]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        # import json  # Uncomment if you need JSON parsing
        # import re    # Uncomment if you need regex
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases or problem description. "
                        "Return ONLY the function name, nothing else.",
            context=""
        )
        
        # Step 2: Generate the initial code
        code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the task described in the problem. 
            Requirements:
            1. Include ALL necessary import statements at the top of the code.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Ensure the function signature matches the test cases provided.
            4. Return ONLY the executable Python code, no explanations or additional text.
            """,
            context=""
        )
        
        # Step 3: Revise the code for improvements
        final_code = await self.revise(
            instruction="Critique and improve the following code. "
                        "Check for missing imports, inefficiencies, and unhandled edge cases. "
                        "Return ONLY the corrected Python code.",
            context=code
        )
        
        # Optional Step 4: Parallel approaches and ensemble selection
        # Uncomment this section for complex problems with multiple valid solutions
        """
        results = await asyncio.gather(
            self.generate(instruction="Approach 1: Solve the problem using method A", context=""),
            self.generate(instruction="Approach 2: Solve the problem using method B", context="")
        )
        final_code = await self.ensemble(
            instruction="Select the best solution based on correctness, efficiency, and readability. "
                        "Return ONLY the selected Python code.",
            contexts=results
        )
        """
        
        return final_code