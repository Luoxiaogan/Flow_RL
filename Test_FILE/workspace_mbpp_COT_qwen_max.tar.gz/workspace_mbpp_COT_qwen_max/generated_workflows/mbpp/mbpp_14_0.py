# Workflow ID: mbpp_14_0
# Benchmark: mbpp
# Data Indices: [35]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases. "
                        "Return ONLY the function name as plain text, nothing else.",
            context=""
        )
        
        # Step 2: Generate the initial Python code
        code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves this task.
            Requirements:
            1. Include ALL necessary import statements at the top.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Ensure the function signature matches the test cases provided.
            4. Return ONLY the executable Python code, without any explanations or comments.
            """,
            context=""
        )
        
        # Step 3: Revise the code for correctness and completeness
        final_code = await self.revise(
            instruction="Review the provided Python code and make the following improvements: "
                        "1. Check for missing import statements and add them if necessary. "
                        "2. Ensure all edge cases are handled properly. "
                        "3. Fix any logical or syntactical errors. "
                        "Return ONLY the corrected Python code.",
            context=code
        )
        
        return final_code