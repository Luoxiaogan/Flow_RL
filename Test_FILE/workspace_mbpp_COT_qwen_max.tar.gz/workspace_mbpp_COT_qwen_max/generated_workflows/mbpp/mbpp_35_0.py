# Workflow ID: mbpp_35_0
# Benchmark: mbpp
# Data Indices: [159]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases or problem description. "
                        "Return ONLY the function name, nothing else.",
            context=""
        )
        
        # Step 2: Generate initial code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the task described in the problem.
            Requirements:
            1. Include ALL necessary import statements at the top (e.g., import math, import re).
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Follow Pythonic best practices (e.g., use list comprehensions where appropriate).
            4. Return ONLY the executable Python code, no explanations.
            """,
            context=""
        )
        
        # Step 3: Revise the code for completeness and correctness
        final_code = await self.revise(
            instruction="""
            Review the provided code and make improvements if necessary.
            Focus on:
            1. Missing import statements.
            2. Unhandled edge cases (e.g., empty inputs, None values).
            3. Inefficiencies or suboptimal implementations.
            4. Syntax or logical errors.
            Return ONLY the corrected and complete Python code.
            """,
            context=initial_code
        )
        
        return final_code