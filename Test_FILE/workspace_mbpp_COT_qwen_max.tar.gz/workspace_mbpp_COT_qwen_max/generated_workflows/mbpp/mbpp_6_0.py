# Workflow ID: mbpp_6_0
# Benchmark: mbpp
# Data Indices: [116]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        import json  # For parsing JSON strings if needed
        import re    # For regex operations if needed
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="""
            Extract the function name from the test cases in the problem description.
            Return ONLY the function name, without any additional text or explanation.
            If the function name is not explicitly mentioned, infer it from the test cases.
            """,
            context=""
        )
        func_name = func_name.strip()  # Remove any leading/trailing whitespace

        # Step 2: Generate the initial Python code
        code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the problem described in the original problem text.
            Requirements:
            1. Include ALL necessary import statements at the top of the code.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Ensure the function adheres to Pythonic best practices.
            4. Focus on passing the provided test cases.
            5. Return ONLY the executable Python code, without any explanations or comments.
            """,
            context=""
        )

        # Step 3: Revise the generated code
        final_code = await self.revise(
            instruction=f"""
            Review the following Python code for the function '{func_name}':
            
            {code}
            
            Perform the following checks:
            1. Ensure all necessary imports are included.
            2. Verify that edge cases are handled appropriately.
            3. Optimize the code for clarity and efficiency.
            4. Ensure the function passes the provided test cases.
            
            Return ONLY the corrected and final version of the code, without any explanations or comments.
            """,
            context=code
        )

        # Return the final, executable Python code
        return final_code