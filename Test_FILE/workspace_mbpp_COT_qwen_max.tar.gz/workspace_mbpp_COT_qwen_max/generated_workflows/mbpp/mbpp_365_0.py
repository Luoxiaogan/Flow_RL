# Workflow ID: mbpp_365_0
# Benchmark: mbpp
# Data Indices: [41]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        import json  # For parsing JSON if needed
        import re    # For regex operations if needed

        # Step 1: Extract the function name and task summary
        func_name = await self.generate(
            instruction="Extract ONLY the function name from the test cases. Return just the name as plain text.",
            context=""
        )
        task_summary = await self.generate(
            instruction="Summarize the task requirements in 1-2 sentences. Focus on input, output, and key operations.",
            context=""
        )

        # Step 2: Generate initial Python code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name.strip()}' that solves the following task:
            {task_summary.strip()}
            
            Requirements:
            1. Include ALL necessary import statements at the top.
            2. Handle edge cases (e.g., empty inputs, None values, boundary conditions).
            3. Follow Pythonic best practices (e.g., use list comprehensions where appropriate).
            4. Return ONLY the executable Python code, no explanations.
            """,
            context=""
        )

        # Step 3: Revise and refine the code
        final_code = await self.revise(
            instruction=f"""
            Critique and improve the following Python code:
            {initial_code.strip()}
            
            Improvement Criteria:
            1. Ensure all necessary imports are included.
            2. Verify that edge cases are handled correctly.
            3. Optimize for efficiency and readability.
            4. Ensure the function matches the expected signature and behavior.
            5. Return ONLY the corrected code, no explanations.
            """,
            context=initial_code
        )

        # Step 4: Return the final code
        return final_code.strip()