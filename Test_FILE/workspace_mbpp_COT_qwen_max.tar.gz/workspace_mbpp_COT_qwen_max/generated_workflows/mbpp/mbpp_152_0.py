# Workflow ID: mbpp_152_0
# Benchmark: mbpp
# Data Indices: [176]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio

        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="""
            Extract the function name from the test cases in the problem description.
            Return ONLY the function name, nothing else.
            """,
            context=""
        )

        # Step 2: Generate initial code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves this task:
            {self.problem_text}
            
            Requirements:
            1. Include ALL necessary import statements at the top.
            2. Handle edge cases such as empty inputs, None, and boundary values.
            3. Ensure the function is efficient and Pythonic.
            4. Return ONLY the executable Python code, no explanations.
            """,
            context=""
        )

        # Step 3: Revise the code
        final_code = await self.revise(
            instruction=f"""
            Review and improve the following Python function named '{func_name}':
            - Check for missing imports.
            - Ensure edge cases are handled (e.g., empty inputs, None).
            - Optimize for efficiency if possible.
            - Return ONLY the corrected Python code, no explanations.
            """,
            context=initial_code
        )

        # Optional: Parallel approaches and ensemble selection
        # Uncomment the following block for more complex problems
        """
        approaches = await asyncio.gather(
            self.generate(
                instruction=f"Write a Python function named '{func_name}' using approach 1...",
                context=""
            ),
            self.generate(
                instruction=f"Write a Python function named '{func_name}' using approach 2...",
                context=""
            )
        )
        final_code = await self.ensemble(
            instruction="Select the best implementation based on correctness and efficiency.",
            contexts=approaches
        )
        """

        return final_code