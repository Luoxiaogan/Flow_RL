# Workflow ID: mbpp_59_0
# Benchmark: mbpp
# Data Indices: [29]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio

        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases or problem description. "
                        "Return ONLY the function name as plain text, nothing else.",
            context=""
        )

        # Step 2: Generate the initial code
        initial_code = await self.generate(
            instruction=f"Write a Python function named '{func_name}' that solves the given task. "
                        "Requirements:\n"
                        "1. Include ALL necessary import statements at the top.\n"
                        "2. Handle edge cases such as empty inputs, None values, and boundary conditions.\n"
                        "3. Ensure the function follows Pythonic best practices.\n"
                        "4. Return ONLY the executable Python code, no explanations or additional text.",
            context=""
        )

        # Step 3: Revise the code for quality assurance
        final_code = await self.revise(
            instruction="Review the provided code and make necessary improvements. "
                        "Specifically:\n"
                        "1. Check for missing import statements and add them.\n"
                        "2. Ensure all edge cases are handled correctly.\n"
                        "3. Fix any logical errors or inefficiencies.\n"
                        "4. Return ONLY the corrected, executable Python code.",
            context=initial_code
        )

        # Step 4: Return the final code
        return final_code