# Workflow ID: mbpp_222_0
# Benchmark: mbpp
# Data Indices: [360]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="""
            Extract the function name from the test cases in the problem description. 
            Return ONLY the function name, nothing else. Ensure it matches the test case assertions.
            """,
            context=""
        )
        
        # Step 2: Generate the initial Python code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the described task.
            Requirements:
            1. Include ALL necessary import statements at the top (e.g., import math, re, etc.)
            2. Handle edge cases such as empty inputs, invalid data, and boundary values
            3. Follow Pythonic best practices for readability and efficiency
            4. Return ONLY the executable Python code, no explanations
            """,
            context=""
        )
        
        # Step 3: Revise the code for correctness and completeness
        final_code = await self.revise(
            instruction="""
            Review the provided code and make necessary improvements:
            1. Check for missing imports and add them if needed
            2. Ensure all edge cases are handled appropriately
            3. Optimize for performance if possible
            4. Return ONLY the corrected code, no explanations
            """,
            context=initial_code
        )
        
        # Optional Step 4: Ensemble (if multiple approaches are generated)
        # Uncomment and modify this section if Ensemble is needed
        # candidates = await asyncio.gather(
        #     self.generate(instruction="Alternative approach 1...", context=""),
        #     self.generate(instruction="Alternative approach 2...", context="")
        # )
        # final_code = await self.ensemble(
        #     instruction="Select the best implementation based on correctness and efficiency.",
        #     contexts=candidates
        # )
        
        return final_code