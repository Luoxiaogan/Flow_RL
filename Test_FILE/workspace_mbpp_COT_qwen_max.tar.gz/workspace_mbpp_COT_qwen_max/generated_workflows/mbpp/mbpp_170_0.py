# Workflow ID: mbpp_170_0
# Benchmark: mbpp
# Data Indices: [14]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="""
            Extract ONLY the function name from the test cases in the problem description.
            Return ONLY the function name as plain text, without any additional explanation or formatting.
            """,
            context=""
        )
        
        # Step 2: Generate the initial Python function
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the problem described in the problem text.
            Requirements:
            1. Include ALL necessary import statements at the top of the function.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Ensure the function is Pythonic, efficient, and adheres to best practices.
            4. Return ONLY the executable Python code, without any explanations or additional text.
            """,
            context=""
        )
        
        # Step 3: Revise the code for correctness and completeness
        final_code = await self.revise(
            instruction="""
            Review the provided Python function and make the following improvements:
            1. Ensure all necessary import statements are included.
            2. Verify that edge cases are handled correctly.
            3. Optimize the code for performance and readability.
            4. Return ONLY the corrected Python code, without any explanations or additional text.
            """,
            context=initial_code
        )
        
        # Step 4: Return the final Python function
        return final_code