# Workflow ID: mbpp_214_0
# Benchmark: mbpp
# Data Indices: [138]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        # Add imports for potential use in code generation
        import math  # Commonly used in mathematical computations
        import re    # Useful for string manipulation tasks

        # Step 1: Extract the function name from the test cases
        func_name = await self.generate(
            instruction="Extract the function name from the test cases. "
                        "Return ONLY the function name as plain text, nothing else.",
            context=""
        )

        # Step 2: Generate the initial implementation of the function
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the problem described in the prompt.
            Requirements:
            1. Include ALL necessary import statements at the top.
            2. Handle edge cases such as empty inputs, None, and boundary values.
            3. Ensure the function is efficient and follows Pythonic best practices.
            4. Return ONLY the executable Python code, no explanations or additional text.
            """,
            context=""
        )

        # Step 3: Revise the code to address potential issues
        final_code = await self.revise(
            instruction="Review the provided code and make improvements where necessary. "
                        "Focus on the following: "
                        "1. Ensure all required imports are included. "
                        "2. Fix any logical errors or inefficiencies. "
                        "3. Handle edge cases properly. "
                        "4. Return ONLY the corrected code, no explanations or additional text.",
            context=initial_code
        )

        # Step 4: Return the finalized code
        return final_code