# Workflow ID: mbpp_156_0
# Benchmark: mbpp
# Data Indices: [148]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract function signature
        func_signature = await self.generate(
            instruction="""
            Extract the function name and parameters from the problem description and test cases.
            Return ONLY the function signature in the format 'function_name(param1, param2, ...)'.
            Do not include any explanations or additional text.
            """,
            context=""
        )
        
        # Step 2: Generate initial code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function with the signature '{func_signature}' that solves this task.
            Requirements:
            1. Include ALL necessary import statements at the top.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Follow Python best practices and idioms.
            4. Return ONLY the executable Python code without explanations.
            """,
            context=""
        )
        
        # Step 3: Revise for edge cases and efficiency
        revised_code = await self.revise(
            instruction="""
            Review the provided code and make improvements:
            1. Check for missing imports and add them if necessary.
            2. Ensure all edge cases are handled (e.g., empty inputs, None values).
            3. Optimize for performance and readability.
            4. Return ONLY the corrected code without explanations.
            """,
            context=initial_code
        )
        
        # Optional Step 4: Ensemble for multiple approaches (if needed)
        # Uncomment and adapt if multiple solutions are generated
        # approach1 = await self.generate(instruction="...", context="")
        # approach2 = await self.generate(instruction="...", context="")
        # final_code = await self.ensemble(
        #     instruction="Select the best approach based on correctness, efficiency, and readability.",
        #     contexts=[approach1, approach2]
        # )
        
        return revised_code