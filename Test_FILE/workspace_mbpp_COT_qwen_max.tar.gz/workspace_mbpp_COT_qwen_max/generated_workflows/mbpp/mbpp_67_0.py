# Workflow ID: mbpp_67_0
# Benchmark: mbpp
# Data Indices: [327]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name from the test cases
        func_name = await self.generate(
            instruction="""
            Extract the function name from the test cases in the problem text.
            Return ONLY the function name, nothing else.
            """,
            context=""
        )
        
        # Step 2: Generate the initial Python code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the task described in the problem text.
            Requirements:
            1. Include ALL necessary import statements at the top of the code.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Ensure the function signature matches the test cases provided in the problem text.
            4. Follow Python best practices and write clean, readable code.
            5. Return ONLY the executable Python code, with no explanations or additional text.
            """,
            context=""
        )
        
        # Step 3: Revise the generated code for completeness and correctness
        final_code = await self.revise(
            instruction="""
            Review the provided Python code and make any necessary improvements:
            1. Check for and add any missing import statements.
            2. Ensure all edge cases are handled appropriately.
            3. Verify that the function signature matches the test cases.
            4. Make the code more Pythonic if possible.
            5. Return ONLY the corrected Python code, with no explanations or additional text.
            """,
            context=initial_code
        )
        
        return final_code