# Workflow ID: mbpp_113_0
# Benchmark: mbpp
# Data Indices: [191]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="""
            Extract the function name from the test cases or problem description.
            Return ONLY the function name, nothing else.
            """,
            context=""
        )
        func_name = func_name.strip()  # Remove any leading/trailing whitespace

        # Step 2: Generate initial code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the following task:
            {self.problem_text}
            
            Requirements:
            1. Include ALL necessary import statements at the top.
            2. Handle edge cases (e.g., empty inputs, None values, boundary conditions).
            3. Follow Python best practices (e.g., use list comprehensions where appropriate).
            4. Return ONLY the executable Python code, no explanations.
            """,
            context=""
        )

        # Step 3: Revise the code
        final_code = await self.revise(
            instruction=f"""
            Critique and refine the following Python function:
            {initial_code}
            
            Focus on the following:
            1. Ensure all necessary imports are included.
            2. Check for and handle edge cases (e.g., empty inputs, None values).
            3. Improve efficiency and readability.
            4. Ensure compliance with Python best practices.
            5. Return ONLY the corrected code, no explanations.
            """,
            context=initial_code
        )

        # Step 4: Return the final code
        return final_code