# Workflow ID: mbpp_208_0
# Benchmark: mbpp
# Data Indices: [149]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases or problem description. "
                        "Return ONLY the function name as plain text, without any additional explanation.",
            context=""
        )
        
        # Step 2: Generate the initial Python function code
        initial_code = await self.generate(
            instruction=f"Write a Python function named '{func_name}' that solves the given task. "
                        "Requirements:\n"
                        "1. Include ALL necessary import statements at the top.\n"
                        "2. Handle edge cases such as empty inputs, None values, and boundary conditions.\n"
                        "3. Ensure the function signature matches the test cases.\n"
                        "4. Return ONLY the executable Python code, without any explanations or comments.",
            context=""
        )
        
        # Step 3: Revise the code for completeness and correctness
        final_code = await self.revise(
            instruction="Review the provided Python function code and ensure it meets the following criteria:\n"
                        "1. All necessary imports are included.\n"
                        "2. Edge cases are handled properly.\n"
                        "3. The function signature matches the test cases.\n"
                        "4. The code is clean, efficient, and follows Python best practices.\n"
                        "Return ONLY the corrected Python code without any additional explanation.",
            context=initial_code
        )
        
        # Step 4: Return the final Python function code
        return final_code