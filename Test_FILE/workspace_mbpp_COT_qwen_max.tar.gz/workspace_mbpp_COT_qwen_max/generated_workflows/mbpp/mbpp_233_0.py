# Workflow ID: mbpp_233_0
# Benchmark: mbpp
# Data Indices: [335]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        # import json  # Uncomment if you need JSON parsing
        # import re    # Uncomment if you need regex
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="""
            Extract ONLY the function name from the test cases in the problem description.
            Return ONLY the function name as plain text, without any additional explanation or formatting.
            """,
            context=""
        )
        
        # Step 2: Generate the initial Python function code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the problem described in the following text:
            **Problem Description:** {self.problem_text}
            
            Requirements for the function:
            1. Include ALL necessary import statements at the top of the code.
            2. Handle edge cases such as empty inputs, None values, or invalid data types.
            3. Ensure the function is efficient and follows Pythonic best practices.
            4. Return ONLY the executable Python code, without any explanations or additional text.
            """,
            context=""
        )
        
        # Step 3: Revise the code for completeness and correctness
        final_code = await self.revise(
            instruction="""
            Review the provided Python code and make improvements where necessary.
            Focus on the following areas:
            1. Ensure all required import statements are included.
            2. Verify that edge cases are properly handled.
            3. Check for compliance with the test cases provided in the problem description.
            4. Optimize the code for readability and efficiency.
            Return ONLY the corrected Python code, without any explanations or additional text.
            """,
            context=initial_code
        )
        
        # Step 4: Return the final code
        return final_code