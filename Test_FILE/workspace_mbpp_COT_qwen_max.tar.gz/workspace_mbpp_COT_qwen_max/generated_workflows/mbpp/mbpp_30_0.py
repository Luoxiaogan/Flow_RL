# Workflow ID: mbpp_30_0
# Benchmark: mbpp
# Data Indices: [63]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio

        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases. "
                        "Return ONLY the function name, nothing else.",
            context=""
        )
        func_name = func_name.strip()  # Remove any leading/trailing whitespace

        # Step 2: Generate the initial implementation
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the given task.
            Requirements:
            1. Include ALL necessary import statements at the top (if any are needed).
            2. Handle edge cases such as empty inputs, None, and boundary values.
            3. Follow Python best practices and write clean, efficient code.
            4. Return ONLY the executable Python code, no explanations.
            """,
            context=""
        )

        # Step 3: Revise the code for quality and correctness
        final_code = await self.revise(
            instruction="Review the provided code and make improvements. "
                        "Check for missing imports, inefficiencies, and unhandled edge cases. "
                        "Ensure the function adheres to Python best practices. "
                        "Return ONLY the corrected code, no explanations.",
            context=initial_code
        )

        # Step 4: Return the final code
        return final_code