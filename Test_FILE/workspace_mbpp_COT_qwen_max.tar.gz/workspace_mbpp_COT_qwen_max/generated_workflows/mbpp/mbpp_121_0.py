# Workflow ID: mbpp_121_0
# Benchmark: mbpp
# Data Indices: [257]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        # import json  # Uncomment if you need JSON parsing
        # import re    # Uncomment if you need regex
        
        # Step 1: Extract the function name and key requirements
        func_name = await self.generate(
            instruction="""
            Extract the function name from the test cases in the problem description.
            Return ONLY the function name, nothing else. Ensure it matches the test case assertions.
            """,
            context=""
        )
        
        # Step 2: Generate the initial Python function code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name.strip()}' that solves the problem described in the original problem text.
            Requirements:
            1. Include ALL necessary import statements at the top (e.g., math, re, collections, etc.).
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Follow Python best practices (PEP 8 style, efficient algorithms).
            4. Return ONLY the executable Python code, without explanations or comments.
            """,
            context=""
        )
        
        # Step 3: Revise the code for correctness and completeness
        final_code = await self.revise(
            instruction="""
            Review the provided Python function code and make improvements where necessary.
            Focus on the following:
            1. Ensure all required imports are included.
            2. Verify that edge cases are handled correctly.
            3. Optimize the code for performance if possible.
            4. Fix any syntax or logical errors.
            Return ONLY the corrected Python code, without explanations or comments.
            """,
            context=initial_code
        )
        
        # Step 4: Return the final polished code
        return final_code