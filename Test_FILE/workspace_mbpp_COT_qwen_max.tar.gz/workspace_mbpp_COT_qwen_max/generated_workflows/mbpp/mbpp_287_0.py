# Workflow ID: mbpp_287_0
# Benchmark: mbpp
# Data Indices: [73]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio

        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases. Return ONLY the function name, nothing else.",
            context=""
        )

        # Step 2: Generate the initial Python code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the following task:
            {self.problem_text}
            Requirements:
            1. Include ALL necessary import statements at the top.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Follow Python best practices and idioms.
            4. Return ONLY the executable Python code, no explanations.
            """,
            context=""
        )

        # Step 3: Revise the code to ensure correctness and completeness
        final_code = await self.revise(
            instruction="""
            Critique and improve the following Python code:
            - Ensure all edge cases are handled.
            - Verify that all necessary imports are included.
            - Check for adherence to Python best practices.
            - Return ONLY the corrected code.
            """,
            context=initial_code
        )

        return final_code