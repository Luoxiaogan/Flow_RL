# Workflow ID: mbpp_258_0
# Benchmark: mbpp
# Data Indices: [321]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases. Return ONLY the function name, nothing else.",
            context=""
        )
        
        # Step 2: Generate initial code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves this task.
            Requirements:
            1. Include ALL necessary import statements at the top
            2. Handle edge cases (empty inputs, None, boundaries)
            3. Follow Python best practices
            4. Return ONLY the executable Python code, no explanations
            """,
            context=""
        )
        
        # Step 3: Revise the code for missing imports and edge cases
        final_code = await self.revise(
            instruction="""
            Review the provided code for the following:
            1. Are all necessary imports included?
            2. Are edge cases handled properly? (e.g., empty inputs, None values)
            3. Does the function signature match the test cases?
            4. Is the code efficient and Pythonic?
            Fix any issues and return ONLY the corrected code.
            """,
            context=initial_code
        )
        
        # Optional: Parallel approaches and ensemble selection
        # Uncomment the following block for more complex problems
        """
        # Generate multiple candidate solutions in parallel
        approach1 = await self.generate(
            instruction="Solve the problem using a brute-force approach. Return ONLY the code.",
            context=""
        )
        approach2 = await self.generate(
            instruction="Solve the problem using an optimized algorithm. Return ONLY the code.",
            context=""
        )
        
        # Select the best solution
        final_code = await self.ensemble(
            instruction="Select the most efficient and correct solution. Return ONLY the selected code.",
            contexts=[approach1, approach2]
        )
        """
        
        return final_code