# Workflow ID: mbpp_92_0
# Benchmark: mbpp
# Data Indices: [109]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases. "
                        "Return ONLY the function name as plain text, nothing else.",
            context=""
        )
        
        # Step 2: Generate the initial Python code
        initial_code = await self.generate(
            instruction=f"Write a Python function named '{func_name}' that solves the problem described. "
                        "Requirements:\n"
                        "1. Include ALL necessary import statements at the top.\n"
                        "2. Handle edge cases such as empty inputs, None values, and boundary conditions.\n"
                        "3. Write clean, efficient, and Pythonic code.\n"
                        "4. Return ONLY the executable Python code, no explanations.",
            context=""
        )
        
        # Step 3: Revise the code for correctness and completeness
        final_code = await self.revise(
            instruction="Review the provided Python code for the following:\n"
                        "1. Ensure all edge cases are handled.\n"
                        "2. Check for missing imports or syntax issues.\n"
                        "3. Optimize the code for clarity and efficiency.\n"
                        "4. Return ONLY the corrected Python code, no explanations.",
            context=initial_code
        )
        
        # Step 4: Return the final Python code
        return final_code