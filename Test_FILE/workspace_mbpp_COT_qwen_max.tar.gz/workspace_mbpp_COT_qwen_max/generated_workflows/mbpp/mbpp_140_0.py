# Workflow ID: mbpp_140_0
# Benchmark: mbpp
# Data Indices: [288]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio

        # Step 1: Extract the function name from the test cases
        func_name = await self.generate(
            instruction="""
            Analyze the test cases provided in the problem description.
            Extract ONLY the function name that is being tested.
            Return ONLY the function name as a plain string, without quotes or additional text.
            """,
            context=""
        )

        # Step 2: Generate the Python function code
        code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the problem described in the task.
            Requirements:
            1. Include ALL necessary import statements at the top of the function.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Ensure the function is efficient and follows Python best practices.
            4. Return ONLY the executable Python code, without any explanations or additional text.
            """,
            context=""
        )

        # Step 3: Revise the generated code for correctness and efficiency
        final_code = await self.revise(
            instruction="""
            Review the provided Python function code and improve it if necessary.
            Focus on the following aspects:
            1. Ensure all required imports are included.
            2. Verify that edge cases are handled correctly.
            3. Optimize the code for performance and readability.
            4. Fix any syntax or logical errors.
            Return ONLY the corrected and improved Python code, without explanations.
            """,
            context=code
        )

        return final_code