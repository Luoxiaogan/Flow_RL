# Workflow ID: mbpp_250_0
# Benchmark: mbpp
# Data Indices: [0]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="""
            Extract the function name from the test cases in the problem description.
            Return ONLY the function name as plain text, without any additional explanation.
            """,
            context=""
        )
        
        # Step 2: Generate the initial Python function
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the problem described in the original problem text.
            Requirements:
            1. Include ALL necessary import statements at the top (e.g., import math, from typing import List).
            2. Define the function with appropriate parameters and return type based on the test cases.
            3. Implement the logic to solve the problem efficiently.
            4. Handle edge cases such as empty inputs, None values, and boundary conditions.
            5. Return ONLY the executable Python code, with no explanations or comments outside the function.
            """,
            context=""
        )
        
        # Step 3: Revise the code for correctness and efficiency
        revised_code = await self.revise(
            instruction="""
            Review the provided Python function and make improvements:
            1. Ensure all necessary imports are included.
            2. Fix any logical errors or inefficiencies.
            3. Improve readability while maintaining correctness.
            4. Handle any edge cases that were missed.
            Return ONLY the corrected Python code.
            """,
            context=initial_code
        )
        
        # Step 4: Ensemble multiple solutions (optional, if parallel approaches are used)
        # Uncomment and modify this section if generating multiple solutions
        """
        results = await asyncio.gather(
            self.generate(instruction="Alternative approach 1...", context=""),
            self.generate(instruction="Alternative approach 2...", context="")
        )
        final_code = await self.ensemble(
            instruction="Select the best solution based on correctness, efficiency, and readability.",
            contexts=results
        )
        """
        
        return revised_code