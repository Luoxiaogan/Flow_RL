# Workflow ID: mbpp_134_0
# Benchmark: mbpp
# Data Indices: [184]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="""
            Extract the function name from the test cases in the problem description.
            Return ONLY the function name, nothing else.
            """,
            context=""
        )
        
        # Step 2: Generate the initial Python function
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the task described in the problem.
            Requirements:
            1. Include ALL necessary import statements at the top.
            2. Handle edge cases such as empty inputs, invalid formats, and boundary values.
            3. Ensure the function signature matches the test cases exactly.
            4. Return ONLY the executable Python code, no explanations.
            """,
            context=""
        )
        
        # Step 3: Revise the code for correctness and efficiency
        final_code = await self.revise(
            instruction="""
            Review the provided Python function and make improvements where necessary.
            Focus on:
            1. Correctness: Ensure the function passes all test cases.
            2. Efficiency: Optimize for performance where possible.
            3. Pythonic practices: Use idiomatic Python constructs.
            4. Edge cases: Handle all special cases mentioned in the problem.
            Return ONLY the corrected Python code.
            """,
            context=initial_code
        )
        
        return final_code