# Workflow ID: mbpp_166_0
# Benchmark: mbpp
# Data Indices: [86]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases. "
                        "Return ONLY the function name, nothing else.",
            context=""
        )
        
        # Step 2: Generate initial code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the following task:
            {self.problem_text}
            
            Requirements:
            1. Include ALL necessary import statements at the top.
            2. Handle edge cases such as empty inputs, None, and boundary values.
            3. Ensure the function is efficient and adheres to Python best practices.
            4. Return ONLY the executable Python code, no explanations.
            """,
            context=""
        )
        
        # Step 3: Revise and refine the code
        final_code = await self.revise(
            instruction=f"""
            Review the following Python function for correctness and improvements:
            {initial_code}
            
            Focus on:
            1. Missing or unnecessary import statements.
            2. Handling of edge cases (empty inputs, None, boundaries).
            3. Readability and adherence to Pythonic style.
            4. Logical and syntactical correctness.
            
            Return ONLY the corrected and improved Python code.
            """,
            context=initial_code
        )
        
        return final_code