# Workflow ID: mbpp_335_0
# Benchmark: mbpp
# Data Indices: [124]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        import re  # For regex-related tasks
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases. Return ONLY the function name, nothing else.",
            context=""
        )
        
        # Step 2: Generate initial code
        code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves this task:
            
            Task Description:
            {self.problem_text}
            
            Requirements:
            1. Include ALL necessary import statements at the top (e.g., import re).
            2. Handle edge cases such as empty inputs, None values, or no matches found.
            3. Ensure the function returns the expected output format as shown in the test cases.
            4. Return ONLY the executable Python code, no explanations or additional text.
            """,
            context=""
        )
        
        # Step 3: Revise the code for correctness
        final_code = await self.revise(
            instruction="""
            Review and improve the following Python code:
            
            - Ensure all edge cases are handled (e.g., empty strings, no matches found).
            - Verify that all necessary imports are included.
            - Make sure the function adheres to Pythonic best practices.
            - Return ONLY the corrected code, no explanations or additional text.
            """,
            context=code
        )
        
        return final_code