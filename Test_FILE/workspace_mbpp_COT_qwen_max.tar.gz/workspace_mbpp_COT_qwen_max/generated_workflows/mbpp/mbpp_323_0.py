# Workflow ID: mbpp_323_0
# Benchmark: mbpp
# Data Indices: [334]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases or problem description. "
                        "Return ONLY the function name as a plain string, without any additional text.",
            context=""
        )
        
        # Step 2: Generate the initial Python function code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the problem described in the original prompt.
            Requirements:
            1. Include ALL necessary import statements at the top of the function.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Ensure the function is efficient and follows Python best practices.
            4. Return ONLY the executable Python code without any explanations or additional text.
            """,
            context=""
        )
        
        # Step 3: Revise the code for completeness and correctness
        final_code = await self.revise(
            instruction="Carefully review the provided Python function code. "
                        "Check for and fix any issues related to: "
                        "1. Missing or unnecessary import statements. "
                        "2. Incorrect handling of edge cases. "
                        "3. Inefficiencies or non-Pythonic constructs. "
                        "4. Any other potential errors. "
                        "Return ONLY the corrected Python code without any explanations.",
            context=initial_code
        )
        
        return final_code