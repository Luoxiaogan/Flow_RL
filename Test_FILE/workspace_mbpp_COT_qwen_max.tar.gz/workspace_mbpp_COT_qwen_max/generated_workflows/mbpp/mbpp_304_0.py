# Workflow ID: mbpp_304_0
# Benchmark: mbpp
# Data Indices: [57]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the Function Name
        func_name = await self.generate(
            instruction="""
            Analyze the test cases in the problem description.
            Extract and return ONLY the function name that is being tested.
            If multiple functions are present, return the primary one used in assertions.
            Return ONLY the function name as plain text, without any additional explanations or characters.
            """,
            context=""
        )
        
        # Step 2: Generate Initial Python Function Code
        initial_code = await self.generate(
            instruction=f"""
            Write a complete and correct Python function named '{func_name}' that solves the described task.
            Requirements:
            1. Include ALL necessary import statements at the top of the function.
            2. Handle ALL possible edge cases, including empty inputs, None values, and boundary conditions.
            3. Ensure the function is efficient and adheres to Pythonic best practices.
            4. Return ONLY the executable Python code without any explanations or additional text.
            """,
            context=""
        )
        
        # Step 3: Revise the Generated Code
        revised_code = await self.revise(
            instruction="""
            Carefully review the provided Python function code.
            Check for and fix any of the following issues:
            1. Missing or unnecessary import statements.
            2. Unhandled edge cases, such as empty inputs or None values.
            3. Inefficiencies or suboptimal algorithms.
            4. Deviations from Python best practices or idiomatic expressions.
            Return ONLY the corrected and improved Python code without any explanations.
            """,
            context=initial_code
        )
        
        # Optional: Additional Revision or Ensemble Steps can be added here if needed
        
        return revised_code