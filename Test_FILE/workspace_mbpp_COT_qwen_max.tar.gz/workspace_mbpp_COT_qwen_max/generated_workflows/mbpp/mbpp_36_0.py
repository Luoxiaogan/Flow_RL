# Workflow ID: mbpp_36_0
# Benchmark: mbpp
# Data Indices: [68]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        # import json  # Uncomment if you need JSON parsing
        # import re    # Uncomment if you need regex
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract ONLY the function name from the test cases in the problem description. "
                        "Return the function name as plain text without any additional explanation.",
            context=""
        )
        
        # Step 2: Generate initial Python code
        code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the following task: {self.problem_text}.
            Requirements:
            1. Include ALL necessary import statements at the top (e.g., import re for regex tasks).
            2. Handle edge cases such as empty inputs, invalid types, and boundary values.
            3. Ensure the function signature matches the test cases provided in the problem description.
            4. Return ONLY the executable Python code, without any explanations or comments.
            """,
            context=""
        )
        
        # Step 3: Revise the code for correctness and completeness
        final_code = await self.revise(
            instruction="Review the provided Python code for the following issues and fix them:"
                        "1. Missing or unnecessary import statements."
                        "2. Failure to handle edge cases (e.g., empty inputs, invalid types)."
                        "3. Non-Pythonic or inefficient implementations."
                        "4. Mismatch with the expected function signature."
                        "Return the corrected Python code ONLY, without any explanations or comments.",
            context=code
        )
        
        return final_code