# Workflow ID: mbpp_126_0
# Benchmark: mbpp
# Data Indices: [21]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name and parameters
        func_signature = await self.generate(
            instruction="""
            Analyze the test cases in the problem description and extract the function signature.
            Return ONLY the function name and its parameters in the format: 'function_name(param1, param2, ...)'.
            Do not include any additional explanations or code.
            """,
            context=""
        )
        
        # Step 2: Generate the initial implementation of the function
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function with the signature '{func_signature}' that solves the problem described in the original text.
            Requirements:
            1. Include ALL necessary import statements at the top of the code.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Ensure the function adheres to Pythonic best practices.
            4. Return ONLY the executable Python code, without any explanations or comments.
            """,
            context=""
        )
        
        # Step 3: Revise the code to ensure correctness and completeness
        final_code = await self.revise(
            instruction="""
            Review the provided code and make the following improvements:
            1. Fix any missing imports or type mismatches.
            2. Ensure all edge cases are handled correctly.
            3. Optimize the code for clarity and efficiency.
            4. Verify that the function passes the provided test cases.
            Return ONLY the corrected and optimized Python code.
            """,
            context=initial_code
        )
        
        # Step 4: Return the final code
        return final_code