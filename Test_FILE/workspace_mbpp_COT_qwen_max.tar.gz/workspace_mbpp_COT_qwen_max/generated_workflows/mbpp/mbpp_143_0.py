# Workflow ID: mbpp_143_0
# Benchmark: mbpp
# Data Indices: [276]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract function name from test cases
        func_name = await self.generate(
            instruction="Extract ONLY the function name from the test cases. "
                        "Look for the function being called in assert statements. "
                        "Return ONLY the function name as plain text, nothing else.",
            context=""
        )
        
        # Step 2: Generate initial Python code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name.strip()}' that solves the following task:
            
            {self.problem_text}
            
            Requirements:
            1. Include ALL necessary import statements at the top of the code.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Ensure the function signature matches the test cases exactly.
            4. Return ONLY the executable Python code, no explanations or comments outside the function.
            """,
            context=""
        )
        
        # Step 3: Revise code for edge cases and missing imports
        final_code = await self.revise(
            instruction="Carefully review the following code. "
                        "Fix any issues related to missing imports, incorrect function signatures, "
                        "or improper handling of edge cases. "
                        "Ensure the code follows Python best practices. "
                        "Return ONLY the corrected code, no explanations.",
            context=initial_code
        )
        
        # Step 4: Return the final code
        return final_code