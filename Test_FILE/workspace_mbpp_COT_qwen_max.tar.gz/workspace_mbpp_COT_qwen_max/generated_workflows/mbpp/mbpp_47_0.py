# Workflow ID: mbpp_47_0
# Benchmark: mbpp
# Data Indices: [56]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        import json  # For parsing JSON if needed
        import re    # For regex operations if needed
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract ONLY the function name from the test cases or problem description. "
                        "Return ONLY the function name as a plain string, without any additional text or quotes.",
            context=""
        )
        
        # Step 2: Generate the initial Python function code
        code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the given task.
            Requirements:
            1. Include ALL necessary import statements at the top of the function.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Ensure the function is efficient and adheres to Pythonic best practices.
            4. Return ONLY the executable Python code, without any explanations or additional text.
            """,
            context=""
        )
        
        # Step 3: Revise the generated code to ensure correctness and completeness
        final_code = await self.revise(
            instruction="Critique and improve the provided Python function code. "
                        "Check for the following issues and fix them if present:\n"
                        "- Missing or unnecessary import statements.\n"
                        "- Logical errors or incorrect implementations.\n"
                        "- Inadequate handling of edge cases.\n"
                        "- Non-Pythonic or inefficient code patterns.\n"
                        "Return ONLY the corrected and executable Python code.",
            context=code
        )
        
        return final_code