# Workflow ID: mbpp_43_0
# Benchmark: mbpp
# Data Indices: [165]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio

        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="""
            Extract the function name from the test cases in the problem description.
            Return ONLY the function name as plain text, without any additional explanation.
            If multiple test cases are present, ensure consistency in the extracted name.
            """,
            context=""
        )

        # Step 2: Generate the initial Python code
        code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the following task:
            
            Task Description:
            {self.problem_text}
            
            Requirements:
            1. Include ALL necessary import statements at the top of the code.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Ensure the function signature matches the test cases.
            4. Return ONLY the executable Python code without any explanations or comments.
            """,
            context=""
        )

        # Step 3: Revise the generated code
        final_code = await self.revise(
            instruction="""
            Review and improve the following Python code:
            
            Focus on:
            1. Correctness: Ensure the code passes all test cases.
            2. Edge Cases: Verify handling of empty inputs, None values, and other special cases.
            3. Efficiency: Optimize the code for performance where possible.
            4. Pythonic Style: Follow best practices and idiomatic Python coding standards.
            5. Imports: Ensure all required modules are imported at the top.
            
            Return ONLY the corrected and improved Python code without any explanations.
            """,
            context=code
        )

        return final_code