# Workflow ID: mbpp_324_0
# Benchmark: mbpp
# Data Indices: [121]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract ONLY the function name from the test cases. Return it as plain text without quotes or additional explanation.",
            context=""
        )
        
        # Step 2: Generate the initial Python code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the problem described in the original problem text.
            Requirements:
            1. Include ALL necessary import statements at the top of the code.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Ensure the function signature matches the test cases provided.
            4. Return ONLY the executable Python code without any explanations or comments outside the function.
            """,
            context=""
        )
        
        # Step 3: Revise the code for correctness
        final_code = await self.revise(
            instruction="""
            Review the provided code and make the following improvements:
            1. Ensure all required modules are imported.
            2. Verify that edge cases are handled correctly.
            3. Check for any syntax errors or logical mistakes.
            4. Return ONLY the corrected Python code without additional explanations.
            """,
            context=initial_code
        )
        
        return final_code