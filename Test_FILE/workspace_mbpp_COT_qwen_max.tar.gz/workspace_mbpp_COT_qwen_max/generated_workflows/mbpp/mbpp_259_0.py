# Workflow ID: mbpp_259_0
# Benchmark: mbpp
# Data Indices: [42]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        import json  # For parsing JSON if needed
        import re    # For regex operations if needed
        
        # Step 1: Extract Function Name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases in the problem description. "
                        "Return ONLY the function name as plain text, nothing else.",
            context=""
        )
        
        # Step 2: Generate Initial Code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name.strip()}' that solves the task described in the problem.
            Requirements:
            1. Include ALL necessary import statements at the top of the function.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Return ONLY the executable Python code without any explanations or additional text.
            """,
            context=""
        )
        
        # Step 3: Revise the Code
        final_code = await self.revise(
            instruction="Review the provided code and make necessary improvements. "
                        "Ensure all required imports are included, edge cases are handled, and the code adheres to Python best practices. "
                        "Return ONLY the corrected Python code without explanations.",
            context=initial_code
        )
        
        return final_code