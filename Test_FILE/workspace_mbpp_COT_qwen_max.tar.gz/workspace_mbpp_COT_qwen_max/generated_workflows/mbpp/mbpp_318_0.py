# Workflow ID: mbpp_318_0
# Benchmark: mbpp
# Data Indices: [155]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        """
        import asyncio
        import json  # For parsing JSON if needed
        import re    # For regex-related problems
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract ONLY the function name from the test cases. "
                        "Return it as plain text without any additional explanation.",
            context=""
        )
        func_name = func_name.strip()  # Remove any leading/trailing whitespace

        # Step 2: Generate the initial implementation
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the problem described in the task.
            Requirements:
            1. Include ALL necessary import statements at the top (e.g., import re, math, etc.)
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Ensure the function signature matches the test cases exactly.
            4. Return ONLY the executable Python code, without any explanations or comments.
            """,
            context=""
        )

        # Step 3: Revise the code for completeness and correctness
        final_code = await self.revise(
            instruction=f"""
            Review the following code for the function '{func_name}':
            - Check for missing imports or undeclared dependencies.
            - Ensure all edge cases are handled appropriately.
            - Verify that the function signature matches the test cases.
            - Fix any logical errors or inefficiencies.
            Return ONLY the corrected Python code.
            """,
            context=initial_code
        )

        # Optional Step 4: Ensemble for final selection (if multiple approaches exist)
        # Uncomment and adapt if needed
        # candidate_1 = await self.generate(instruction="...", context="")
        # candidate_2 = await self.generate(instruction="...", context="")
        # final_code = await self.ensemble(
        #     instruction="Select the best implementation based on correctness and efficiency.",
        #     contexts=[candidate_1, candidate_2]
        # )

        return final_code