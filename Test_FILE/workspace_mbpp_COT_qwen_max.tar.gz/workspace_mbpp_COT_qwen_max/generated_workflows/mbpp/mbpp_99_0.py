# Workflow ID: mbpp_99_0
# Benchmark: mbpp
# Data Indices: [34]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="""
            Extract the function name from the test cases in the problem description. 
            Return ONLY the function name, nothing else. Ensure it is a valid Python identifier.
            """,
            context=""
        )
        
        # Step 2: Generate the initial Python function code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the task described in the problem.
            Requirements:
            1. Include ALL necessary import statements at the top (e.g., `import heapq` for heap operations).
            2. Handle edge cases such as empty inputs, `None`, or invalid data types.
            3. Ensure the function adheres to Pythonic best practices (e.g., readability, efficiency).
            4. Return ONLY the executable Python code, no explanations or additional text.
            """,
            context=""
        )
        
        # Step 3: Revise the generated code
        final_code = await self.revise(
            instruction="""
            Review the provided Python function code for correctness and completeness.
            Check for:
            1. Missing import statements.
            2. Handling of edge cases (e.g., empty inputs, `None`, invalid types).
            3. Efficiency and adherence to Pythonic practices.
            4. Compliance with the problem requirements.
            Return ONLY the corrected Python code, no explanations or additional text.
            """,
            context=initial_code
        )
        
        # Step 4: Return the final Python function code
        return final_code