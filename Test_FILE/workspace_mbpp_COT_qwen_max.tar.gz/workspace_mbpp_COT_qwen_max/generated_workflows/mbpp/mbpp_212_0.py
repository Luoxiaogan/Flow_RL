# Workflow ID: mbpp_212_0
# Benchmark: mbpp
# Data Indices: [309]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases. "
                        "Return ONLY the function name as plain text, without quotes or additional explanations.",
            context=""
        )
        
        # Step 2: Generate the initial Python code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the task described in the problem statement.
            Requirements:
            1. Include ALL necessary import statements at the top (e.g., import datetime, import re, etc.).
            2. Handle edge cases such as empty inputs, None values, and invalid types.
            3. Ensure type conversions where needed (e.g., convert strings to integers if necessary).
            4. Follow Pythonic best practices for readability and efficiency.
            5. Return ONLY the executable Python code, without any explanations or comments.
            """,
            context=""
        )
        
        # Step 3: Revise the generated code
        final_code = await self.revise(
            instruction="Review the provided code and make improvements if necessary. "
                        "Focus on the following aspects:"
                        "1. Check for missing import statements and add them if needed."
                        "2. Ensure proper handling of edge cases (e.g., invalid inputs)."
                        "3. Validate that the function adheres to Pythonic best practices."
                        "4. Return ONLY the corrected Python code, without any explanations or comments.",
            context=initial_code
        )
        
        # Step 4: Return the final code
        return final_code