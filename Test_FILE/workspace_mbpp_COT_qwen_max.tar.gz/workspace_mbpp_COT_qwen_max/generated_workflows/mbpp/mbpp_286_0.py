# Workflow ID: mbpp_286_0
# Benchmark: mbpp
# Data Indices: [153]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio

        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="""
            Extract the function name from the test cases in the problem description. 
            Return ONLY the function name as plain text, without any additional explanation or formatting.
            """,
            context=""
        )

        # Step 2: Generate the initial Python function code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the following task:
            {self.problem_text}
            
            Requirements:
            1. Include ALL necessary import statements at the top of the code.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Ensure the function signature matches the test cases provided in the problem description.
            4. Return ONLY the executable Python code, without any explanations or additional text.
            """,
            context=""
        )

        # Step 3: Revise the code for correctness and robustness
        final_code = await self.revise(
            instruction=f"""
            Review and improve the following Python function:
            {initial_code}
            
            Specific tasks:
            1. Ensure the function passes all test cases in the problem description.
            2. Verify that all edge cases are handled correctly.
            3. Check for missing import statements and add them if necessary.
            4. Optimize the code for clarity and efficiency while maintaining correctness.
            5. Return ONLY the corrected and improved Python code, without any explanations or additional text.
            """,
            context=initial_code
        )

        # Step 4: Return the final Python function code
        return final_code