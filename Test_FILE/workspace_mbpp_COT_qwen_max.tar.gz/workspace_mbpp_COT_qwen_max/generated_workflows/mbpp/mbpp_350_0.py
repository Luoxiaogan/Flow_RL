# Workflow ID: mbpp_350_0
# Benchmark: mbpp
# Data Indices: [170]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases. Return ONLY the function name, nothing else.",
            context=""
        )
        
        # Step 2: Generate the initial Python function code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves this task. 
            Requirements:
            1. Include ALL necessary import statements at the top.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Ensure the function signature matches the test cases provided in the problem description.
            4. Return ONLY the executable Python code, no explanations.
            """,
            context=""
        )
        
        # Step 3: Revise the code for completeness and correctness
        final_code = await self.revise(
            instruction="""
            Review the provided code and make improvements where necessary.
            Focus on:
            1. Adding missing import statements.
            2. Handling edge cases that may have been overlooked.
            3. Ensuring the code follows Pythonic best practices.
            4. Maintaining compatibility with the test cases.
            Return ONLY the corrected code, no explanations.
            """,
            context=initial_code
        )
        
        # Step 4: Return the final code
        return final_code