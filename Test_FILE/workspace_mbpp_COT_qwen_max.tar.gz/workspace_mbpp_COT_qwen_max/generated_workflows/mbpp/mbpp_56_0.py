# Workflow ID: mbpp_56_0
# Benchmark: mbpp
# Data Indices: [89]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        import json  # For parsing JSON if needed
        import re    # For regex operations if needed

        # Step 1: Extract function name and description
        func_metadata = await self.generate(
            instruction="""
            Analyze the problem description and extract the following:
            1. The function name
            2. A brief description of what the function does
            Return the result as a JSON string with keys 'name' and 'description'.
            """,
            context=""
        )
        func_data = json.loads(func_metadata)  # Parse JSON string to dict
        func_name = func_data["name"]
        func_description = func_data["description"]

        # Step 2: Generate initial code implementation
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the following task:
            {func_description}
            Requirements:
            1. Include ALL necessary import statements at the top
            2. Handle edge cases (empty inputs, None, boundaries)
            3. Follow Python best practices
            4. Return ONLY the executable Python code, no explanations
            """,
            context=""
        )

        # Step 3: Revise the generated code
        revised_code = await self.revise(
            instruction="""
            Review the provided Python function code and make the following improvements:
            1. Fix any missing imports
            2. Ensure all edge cases are handled
            3. Optimize for performance if possible
            4. Improve readability and adherence to Pythonic style
            Return ONLY the corrected code.
            """,
            context=initial_code
        )

        # Step 4: Return the finalized solution
        return revised_code