# Workflow ID: mbpp_206_0
# Benchmark: mbpp
# Data Indices: [231]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        import re  # For regex operations
        
        # Step 1: Extract the function name from the test cases
        func_name = await self.generate(
            instruction="Extract the function name from the test cases. "
                        "Return ONLY the function name, nothing else.",
            context=""
        )
        func_name = func_name.strip()  # Remove any leading/trailing whitespace

        # Step 2: Generate the initial Python code
        code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the following task:
            {self.problem_text}
            
            Requirements:
            1. Include ALL necessary import statements at the top (e.g., import re).
            2. Handle edge cases such as empty strings, None inputs, and invalid data.
            3. Ensure the function is efficient and follows Pythonic best practices.
            4. Return ONLY the executable Python code, no explanations.
            """,
            context=""
        )

        # Step 3: Revise the code for correctness and edge case handling
        final_code = await self.revise(
            instruction="Check the following code for correctness and completeness:\n"
                        "1. Ensure all necessary imports are included.\n"
                        "2. Verify that edge cases (e.g., empty inputs, None) are handled.\n"
                        "3. Optimize the code for performance if possible.\n"
                        "4. Return ONLY the corrected Python code, no explanations.",
            context=code
        )

        return final_code