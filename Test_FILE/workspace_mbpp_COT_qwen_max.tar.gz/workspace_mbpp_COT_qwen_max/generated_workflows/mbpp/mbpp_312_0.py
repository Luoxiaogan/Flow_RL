# Workflow ID: mbpp_312_0
# Benchmark: mbpp
# Data Indices: [146]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name from the test cases
        func_name = await self.generate(
            instruction="""
            Extract the function name used in the test cases from the problem description.
            Return ONLY the function name as plain text, without any additional explanation or formatting.
            """,
            context=""
        )
        
        # Step 2: Generate the Python function code
        code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the following task:
            
            **Task Description:**
            {self.problem_text}
            
            **Requirements for the Function:**
            1. Include ALL necessary import statements at the top of the function.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Follow Pythonic coding practices and best conventions.
            4. Ensure the function signature matches the test cases provided in the problem description.
            5. Return ONLY the executable Python code without any explanations or comments.
            """,
            context=""
        )
        
        # Step 3: Revise the generated code for robustness and correctness
        final_code = await self.revise(
            instruction="""
            Review the following Python function code and make necessary improvements:
            
            **Improvement Criteria:**
            1. Ensure all required import statements are included.
            2. Verify that edge cases are properly handled.
            3. Fix any logical, syntactical, or performance-related issues.
            4. Maintain Pythonic coding practices.
            5. Return ONLY the corrected Python code without any explanations or comments.
            """,
            context=code
        )
        
        # Return the final, revised Python function code
        return final_code