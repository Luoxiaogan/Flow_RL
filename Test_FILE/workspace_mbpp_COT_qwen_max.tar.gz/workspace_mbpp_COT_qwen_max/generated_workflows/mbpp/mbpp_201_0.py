# Workflow ID: mbpp_201_0
# Benchmark: mbpp
# Data Indices: [65]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="""
            Extract the function name from the test cases in the problem description.
            Return ONLY the function name, nothing else.
            """,
            context=""
        )
        
        # Step 2: Generate the initial Python function code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the task described in the problem.
            Requirements:
            1. Include ALL necessary import statements at the top.
            2. Handle edge cases (e.g., empty inputs, None, boundaries).
            3. Return ONLY the executable Python code, no explanations.
            """,
            context=""
        )
        
        # Step 3: Revise the code to fix issues
        final_code = await self.revise(
            instruction="""
            Check the following code for:
            1. Missing imports.
            2. Unhandled edge cases.
            3. Logical or syntactical errors.
            Fix any issues and return ONLY the corrected code.
            """,
            context=initial_code
        )
        
        return final_code