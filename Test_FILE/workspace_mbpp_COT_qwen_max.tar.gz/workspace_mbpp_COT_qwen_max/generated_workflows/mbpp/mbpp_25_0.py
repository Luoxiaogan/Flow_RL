# Workflow ID: mbpp_25_0
# Benchmark: mbpp
# Data Indices: [373]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name from the test cases
        func_name = await self.generate(
            instruction="Extract ONLY the function name from the test cases. "
                        "Return a single word, nothing else.",
            context=""
        )
        
        # Step 2: Generate the initial Python code
        code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the problem described in the original prompt.
            Requirements:
            1. Include ALL necessary import statements at the top (e.g., 'import math', 'from collections import Counter').
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Ensure the function matches the test case signatures and passes the provided assertions.
            4. Return ONLY the executable Python code, no explanations or additional text.
            """,
            context=""
        )
        
        # Step 3: Revise the code for completeness and correctness
        final_code = await self.revise(
            instruction="Review the following code and ensure it meets these criteria:\n"
                        "- All necessary imports are included.\n"
                        "- Edge cases are properly handled.\n"
                        "- The code adheres to Pythonic best practices.\n"
                        "- The function signature matches the test cases.\n"
                        "Return ONLY the corrected Python code, no explanations or additional text.",
            context=code
        )
        
        # Step 4: Return the final code
        return final_code