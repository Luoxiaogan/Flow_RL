# Workflow ID: mbpp_373_0
# Benchmark: mbpp
# Data Indices: [287]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio

        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="""
            Extract the function name from the test cases in the problem description.
            Return ONLY the function name as a plain string, without any additional text or quotes.
            """,
            context=""
        )

        # Step 2: Generate the Python code
        code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the problem described in the task.
            Requirements:
            1. Include ALL necessary import statements at the top of the code.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Ensure the function signature matches the test cases provided in the problem description.
            4. Use Pythonic practices and adhere to best coding standards.
            5. Return ONLY the executable Python code, without any explanations or additional text.
            """,
            context=""
        )

        # Step 3: Revise the generated code
        final_code = await self.revise(
            instruction="""
            Review the provided Python code and make the following improvements:
            1. Ensure all necessary imports are included.
            2. Fix any logical errors or missing edge case handling.
            3. Optimize the code for readability and efficiency.
            4. Return ONLY the corrected Python code, without any explanations or additional text.
            """,
            context=code
        )

        return final_code