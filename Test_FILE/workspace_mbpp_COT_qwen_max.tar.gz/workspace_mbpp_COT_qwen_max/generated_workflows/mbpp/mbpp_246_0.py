# Workflow ID: mbpp_246_0
# Benchmark: mbpp
# Data Indices: [54]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract ONLY the function name from the test cases. Return it as plain text without quotes or additional explanations.",
            context=""
        )
        
        # Step 2: Generate initial code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the problem described in the original prompt.
            Requirements:
            1. Include ALL necessary import statements at the top (e.g., math, itertools, etc.)
            2. Handle edge cases explicitly (empty inputs, None, boundary values)
            3. Follow Python best practices and idioms
            4. Return ONLY the executable Python code, no explanations
            """,
            context=""
        )
        
        # Step 3: Revise the code for correctness and robustness
        final_code = await self.revise(
            instruction="""
            Review the provided code and make improvements where necessary.
            Focus on:
            1. Missing imports or dependencies
            2. Incorrect handling of edge cases
            3. Efficiency and readability
            4. Adherence to Python best practices
            Return ONLY the corrected code.
            """,
            context=initial_code
        )
        
        # Optional Step 4: Ensemble to select the best solution (if generating multiple approaches)
        # Uncomment and adapt this section if needed
        """
        approaches = await asyncio.gather(
            self.generate(instruction="Generate a straightforward iterative solution", context=""),
            self.generate(instruction="Generate a solution using list comprehensions", context="")
        )
        final_code = await self.ensemble(
            instruction="Select the best solution based on correctness, efficiency, and readability.",
            contexts=approaches
        )
        """
        
        return final_code