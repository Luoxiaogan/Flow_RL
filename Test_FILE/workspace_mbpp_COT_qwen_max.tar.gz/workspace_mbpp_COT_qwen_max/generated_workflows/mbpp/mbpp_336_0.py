# Workflow ID: mbpp_336_0
# Benchmark: mbpp
# Data Indices: [336]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio

        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases. "
                        "Return ONLY the function name as plain text, nothing else.",
            context=""
        )

        # Step 2: Generate the initial Python code
        code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the task described in the problem statement.
            Requirements:
            1. Include ALL necessary import statements at the top (e.g., 'from collections import Counter').
            2. Handle edge cases:
               - Empty input strings.
               - Strings with multiple most common characters (return the first one alphabetically).
            3. Ensure the function signature matches the test cases.
            4. Return ONLY the executable Python code, no explanations.
            """,
            context=""
        )

        # Step 3: Revise the code for correctness and robustness
        final_code = await self.revise(
            instruction="Critique and improve the following code. "
                        "Ensure it handles all edge cases and passes the test cases. "
                        "Fix any issues with imports, efficiency, or correctness. "
                        "Return ONLY the corrected Python code.",
            context=code
        )

        return final_code