# Workflow ID: mbpp_98_0
# Benchmark: mbpp
# Data Indices: [130]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio

        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases. "
                        "Return ONLY the function name, nothing else.",
            context=""
        )
        func_name = func_name.strip()  # Remove any extra whitespace

        # Step 2: Generate the initial code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves this task.
            Requirements:
            1. Include ALL necessary import statements at the top.
            2. Handle edge cases (e.g., empty inputs, None, invalid values).
            3. Ensure the function signature matches the test cases.
            4. Return ONLY the executable Python code, no explanations.
            """,
            context=""
        )

        # Step 3: Revise the code to ensure correctness and quality
        final_code = await self.revise(
            instruction="Critique and refine the following code:\n"
                        "1. Ensure all necessary imports are included.\n"
                        "2. Check for and handle edge cases properly.\n"
                        "3. Improve readability and adhere to Python best practices.\n"
                        "4. Return ONLY the corrected code.",
            context=initial_code
        )

        return final_code