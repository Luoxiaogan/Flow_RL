# Workflow ID: mbpp_165_0
# Benchmark: mbpp
# Data Indices: [162]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name from the test cases
        func_name = await self.generate(
            instruction="Extract the function name from the test cases. "
                        "Return ONLY the function name, nothing else.",
            context=""
        )
        
        # Step 2: Generate the initial Python function code
        initial_code = await self.generate(
            instruction=f"Write a Python function named '{func_name}' that solves the given task. "
                        "Requirements:\n"
                        "1. Include ALL necessary import statements at the top.\n"
                        "2. Handle edge cases (e.g., empty inputs, None values, boundary conditions).\n"
                        "3. Follow Pythonic best practices.\n"
                        "4. Return ONLY the executable Python code, no explanations.\n",
            context=""
        )
        
        # Step 3: Revise the code for accuracy and completeness
        final_code = await self.revise(
            instruction="Review the provided code for the following:\n"
                        "1. Missing import statements.\n"
                        "2. Unhandled edge cases.\n"
                        "3. Inefficiencies or suboptimal solutions.\n"
                        "4. Syntax or logical errors.\n"
                        "Fix any issues and return ONLY the corrected code.",
            context=initial_code
        )
        
        return final_code