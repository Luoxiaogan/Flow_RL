# Workflow ID: mbpp_137_0
# Benchmark: mbpp
# Data Indices: [152]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        import json  # For parsing JSON strings if needed
        import re    # For regex operations if needed
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract only the function name from the test cases. Return ONLY the function name, nothing else.",
            context=""
        )
        
        # Step 2: Generate initial code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves this task.
            Requirements:
            1. Include ALL necessary import statements at the top.
            2. Handle edge cases (empty inputs, None, boundaries).
            3. Follow Pythonic best practices.
            4. Return ONLY the executable Python code, no explanations.
            """,
            context=""
        )
        
        # Step 3: Revise the code for correctness and completeness
        revised_code = await self.revise(
            instruction="""
            Critique and improve the provided code. Ensure:
            1. All necessary imports are included.
            2. Edge cases are handled properly.
            3. The code is efficient and adheres to Python best practices.
            4. Return ONLY the corrected code, no explanations.
            """,
            context=initial_code
        )
        
        # Optional Step 4: Parallel Approaches (if needed)
        # Uncomment and use for more complex problems
        # approach_1 = await self.generate(instruction="...", context="")
        # approach_2 = await self.generate(instruction="...", context="")
        # final_code = await self.ensemble(
        #     instruction="Select the best approach based on correctness and efficiency.",
        #     contexts=[approach_1, approach_2]
        # )
        
        # Step 5: Return the final code
        return revised_code