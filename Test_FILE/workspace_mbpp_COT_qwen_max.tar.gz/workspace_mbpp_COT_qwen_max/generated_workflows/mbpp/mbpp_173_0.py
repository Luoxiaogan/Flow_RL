# Workflow ID: mbpp_173_0
# Benchmark: mbpp
# Data Indices: [24]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio

        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases in the problem description. "
                        "Return ONLY the function name, nothing else.",
            context=""
        )

        # Step 2: Generate the initial implementation
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the given task. 
            Requirements:
            1. Include ALL necessary import statements at the top (e.g., 'import math', 'import re').
            2. Handle edge cases explicitly (e.g., empty inputs, single-element lists, None values).
            3. Follow Pythonic best practices (e.g., use list comprehensions where appropriate).
            4. Return ONLY the executable Python code, no explanations or comments.
            """,
            context=""
        )

        # Step 3: Revise the code for correctness and completeness
        final_code = await self.revise(
            instruction=f"""
            Review the following Python function named '{func_name}' and make improvements:
            1. Ensure all necessary imports are included.
            2. Check for and handle edge cases (e.g., empty inputs, single-element lists).
            3. Optimize for efficiency where possible.
            4. Return ONLY the corrected, executable Python code.
            """,
            context=initial_code
        )

        return final_code