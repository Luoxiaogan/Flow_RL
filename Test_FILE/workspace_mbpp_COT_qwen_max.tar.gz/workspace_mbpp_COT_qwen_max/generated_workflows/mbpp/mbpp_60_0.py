# Workflow ID: mbpp_60_0
# Benchmark: mbpp
# Data Indices: [249]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="""
            Extract the function name from the test cases in the problem description.
            Return ONLY the function name as plain text, without any additional explanation.
            """,
            context=""
        )
        
        # Step 2: Generate the initial Python code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the following task:
            {self.problem_text}
            
            Requirements:
            1. Include ALL necessary import statements at the top of the code.
            2. Handle edge cases, such as empty inputs, invalid types, and boundary values.
            3. Ensure the function is efficient and adheres to Pythonic best practices.
            4. Return ONLY the executable Python code, without any explanations.
            """,
            context=""
        )
        
        # Step 3: Revise the code to address potential issues
        final_code = await self.revise(
            instruction="""
            Review the provided Python code and make improvements where necessary.
            Focus on the following:
            1. Ensure all edge cases are handled correctly.
            2. Add any missing import statements.
            3. Optimize the code for efficiency if possible.
            4. Fix any syntax or logical errors.
            Return ONLY the corrected Python code, without any explanations.
            """,
            context=initial_code
        )
        
        # Step 4: Return the final Python code
        return final_code