# Workflow ID: mbpp_342_0
# Benchmark: mbpp
# Data Indices: [234]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases or problem description. "
                        "Return ONLY the function name, nothing else.",
            context=""
        )
        
        # Step 2: Generate initial code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the problem described in the prompt.
            Requirements:
            1. Include ALL necessary import statements at the top.
            2. Handle edge cases (e.g., empty inputs, None values, boundary conditions).
            3. Ensure the function is efficient and follows Python best practices.
            4. Return ONLY the executable Python code, no explanations.
            """,
            context=""
        )
        
        # Step 3: Revise the code for robustness
        final_code = await self.revise(
            instruction=f"""
            Review the following code for the function '{func_name}':
            
            CODE:
            {initial_code}
            
            Improvements:
            1. Check for missing imports and add them if necessary.
            2. Ensure all edge cases are handled.
            3. Optimize for efficiency if possible.
            4. Fix any syntax or logical errors.
            
            Return ONLY the corrected and improved code.
            """,
            context=initial_code
        )
        
        # Optional Step 4: Ensemble (if multiple candidates exist)
        # Uncomment and adapt this section if you generate multiple solutions
        # candidates = [final_code, alternative_code]
        # final_code = await self.ensemble(
        #     instruction="Select the best implementation or synthesize a superior solution.",
        #     contexts=candidates
        # )
        
        return final_code