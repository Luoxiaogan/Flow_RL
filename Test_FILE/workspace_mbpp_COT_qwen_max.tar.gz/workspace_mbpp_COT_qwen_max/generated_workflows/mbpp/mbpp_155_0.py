# Workflow ID: mbpp_155_0
# Benchmark: mbpp
# Data Indices: [139]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases. Return ONLY the function name, nothing else.",
            context=""
        )
        
        # Step 2: Generate the initial implementation
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the following task:
            
            **Task Description:**
            {self.problem_text}
            
            **Requirements:**
            1. Include ALL necessary import statements at the top.
            2. Handle edge cases such as empty inputs, invalid types, or boundary values.
            3. Ensure the function signature matches the test cases.
            4. Return ONLY the executable Python code, no explanations.
            """,
            context=""
        )
        
        # Step 3: Revise the code for correctness and edge cases
        final_code = await self.revise(
            instruction="""
            Review the following code and make improvements where necessary:
            
            **Improvement Criteria:**
            1. Check for missing imports.
            2. Ensure all edge cases are handled (e.g., empty inputs, invalid types).
            3. Optimize for efficiency if possible.
            4. Follow Python best practices.
            
            Return ONLY the corrected and improved code.
            """,
            context=initial_code
        )
        
        return final_code