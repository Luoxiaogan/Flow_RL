# Workflow ID: mbpp_55_0
# Benchmark: mbpp
# Data Indices: [262]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio

        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases. Return ONLY the function name, nothing else.",
            context=""
        )

        # Step 2: Generate the initial implementation
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the problem described in the original prompt.
            Requirements:
            1. Include ALL necessary import statements at the top.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Ensure the function signature matches the test cases.
            4. Return ONLY the executable Python code, no explanations.
            """,
            context=""
        )

        # Step 3: Revise the code for correctness and completeness
        final_code = await self.revise(
            instruction="""
            Review the provided code and make improvements if necessary:
            1. Ensure all required imports are included.
            2. Verify that edge cases are handled properly.
            3. Optimize the code for efficiency if possible.
            4. Return ONLY the corrected code, no explanations.
            """,
            context=initial_code
        )

        # Optional Step 4: Ensemble (if multiple approaches are needed)
        # Uncomment and adapt this section if multiple solutions are generated
        # candidates = await asyncio.gather(
        #     self.generate(instruction="Approach 1...", context=""),
        #     self.generate(instruction="Approach 2...", context="")
        # )
        # final_code = await self.ensemble(
        #     instruction="Select the best solution based on correctness, efficiency, and readability.",
        #     contexts=candidates
        # )

        return final_code