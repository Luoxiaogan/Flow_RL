# Workflow ID: mbpp_242_0
# Benchmark: mbpp
# Data Indices: [95]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio

        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases. Return ONLY the function name, nothing else.",
            context=""
        )
        func_name = func_name.strip()  # Remove any extra whitespace

        # Step 2: Generate the initial Python code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves this task.
            Requirements:
            1. Include ALL necessary import statements at the top
            2. Handle edge cases (empty inputs, None, boundaries)
            3. Follow Pythonic best practices
            4. Ensure the function signature matches the test cases
            5. Return ONLY the executable Python code, no explanations
            """,
            context=""
        )

        # Step 3: Revise the code for correctness and completeness
        final_code = await self.revise(
            instruction="Critique and improve the following code. Check for:\n"
                        "1. Missing imports\n"
                        "2. Unhandled edge cases\n"
                        "3. Inefficiencies or bugs\n"
                        "4. Compliance with Pythonic practices\n"
                        "Return ONLY the corrected code.",
            context=initial_code
        )

        # Step 4: Return the final code
        return final_code