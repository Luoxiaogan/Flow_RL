# Workflow ID: mbpp_150_0
# Benchmark: mbpp
# Data Indices: [186]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        import json  # For parsing JSON if needed
        import re    # For regex operations if needed
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases. "
                        "Return ONLY the function name, nothing else.",
            context=""
        )
        func_name = func_name.strip()  # Remove any leading/trailing whitespace

        # Step 2: Generate the initial Python code
        code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the following task:
            {self.problem_text}
            
            Requirements:
            1. Include ALL necessary import statements at the top.
            2. Handle edge cases (e.g., empty inputs, None, boundary values).
            3. Follow Python best practices and idioms.
            4. Return ONLY the executable Python code, no explanations.
            """,
            context=""
        )

        # Step 3: Revise the code for completeness and correctness
        final_code = await self.revise(
            instruction=f"""
            Review the following Python code for the function '{func_name}':
            {code}
            
            Tasks:
            1. Check for missing import statements and add them if necessary.
            2. Ensure all edge cases are handled (e.g., empty inputs, None, boundaries).
            3. Optimize the code for clarity and efficiency.
            4. Return ONLY the corrected Python code, no explanations.
            """,
            context=code
        )

        # Step 4: Return the final code
        return final_code