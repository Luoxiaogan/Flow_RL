# Workflow ID: mbpp_256_0
# Benchmark: mbpp
# Data Indices: [279]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        import json  # For parsing JSON if needed
        import re    # For regex operations if needed
        
        # Step 1: Extract the function name and parameters
        func_name = await self.generate(
            instruction="""
            Extract the function name from the test cases or problem description.
            Return ONLY the function name as plain text, nothing else.
            """,
            context=""
        )
        
        # Step 2: Generate the initial Python code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the problem described in the original problem text.
            Requirements:
            1. Include ALL necessary import statements at the top (e.g., math, re, etc.).
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Ensure the function signature matches the test cases provided.
            4. Return ONLY the executable Python code, no explanations or additional text.
            """,
            context=""
        )
        
        # Step 3: Revise the code for correctness and completeness
        revised_code = await self.revise(
            instruction="""
            Review the provided Python code and make improvements where necessary.
            Focus on:
            1. Adding missing imports or dependencies.
            2. Fixing logical errors or inefficiencies.
            3. Ensuring edge cases are handled properly.
            4. Making the code Pythonic and adhering to best practices.
            Return ONLY the corrected Python code, no explanations.
            """,
            context=initial_code
        )
        
        # Step 4: (Optional) Ensemble multiple solutions if needed
        # This step is optional and can be used for problems with multiple valid approaches
        # For simplicity, we skip this step unless explicitly required.
        
        # Final Output: Return the refined Python code
        return revised_code