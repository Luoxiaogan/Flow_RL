# Workflow ID: mbpp_186_0
# Benchmark: mbpp
# Data Indices: [216]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="""
            Extract the function name from the test cases in the problem description.
            Return ONLY the function name as plain text, without any additional explanation or formatting.
            """,
            context=""
        )
        
        # Step 2: Generate the initial implementation of the function
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the task described in the problem.
            Requirements:
            1. Include ALL necessary import statements at the top of the function.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Ensure the function is Pythonic and adheres to best practices.
            4. Return ONLY the executable Python code, without any explanations or comments.
            """,
            context=""
        )
        
        # Step 3: Revise the generated code to fix issues and optimize
        final_code = await self.revise(
            instruction="""
            Review the provided Python function code and make improvements where necessary.
            Focus on:
            1. Fixing any missing imports or syntax errors.
            2. Handling all edge cases (empty inputs, None values, etc.).
            3. Optimizing performance if possible.
            4. Ensuring the code is clean, readable, and follows Python best practices.
            Return ONLY the corrected and finalized Python code.
            """,
            context=initial_code
        )
        
        # Step 4: Return the final code
        return final_code