# Workflow ID: mbpp_355_0
# Benchmark: mbpp
# Data Indices: [277]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases. "
                        "Return ONLY the function name as plain text, nothing else.",
            context=""
        )
        
        # Step 2: Generate the initial implementation
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the problem described in the test cases.
            Requirements:
            1. Include ALL necessary import statements at the top (e.g., import math, from collections import Counter).
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Ensure the function signature matches the test cases.
            4. Return ONLY the executable Python code, no explanations or additional text.
            """,
            context=""
        )
        
        # Step 3: Revise the code for completeness and correctness
        final_code = await self.revise(
            instruction=f"""
            Review the following implementation of the function '{func_name}':
            {initial_code}
            
            Perform the following checks and improvements:
            1. Verify that all necessary import statements are included.
            2. Ensure all edge cases are handled properly.
            3. Optimize the code for efficiency if possible.
            4. Fix any syntax or logical errors.
            5. Return ONLY the corrected and improved Python code, no explanations.
            """,
            context=initial_code
        )
        
        return final_code