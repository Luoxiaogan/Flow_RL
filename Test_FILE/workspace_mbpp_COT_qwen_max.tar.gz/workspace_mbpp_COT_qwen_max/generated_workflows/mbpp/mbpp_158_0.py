# Workflow ID: mbpp_158_0
# Benchmark: mbpp
# Data Indices: [344]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract function name from test cases
        func_name = await self.generate(
            instruction="""
            Extract the function name from the test cases provided in the problem description.
            Return ONLY the function name as a plain string, without any additional text or explanation.
            """,
            context=""
        )
        
        # Step 2: Generate initial Python function code
        code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the task described in the problem.
            Requirements:
            1. Include ALL necessary import statements at the top of the function.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Ensure the function signature matches the test cases provided in the problem description.
            4. Return ONLY the executable Python code as a plain string, without any explanations or comments.
            """,
            context=""
        )
        
        # Step 3: Revise the generated code
        final_code = await self.revise(
            instruction="""
            Review the provided Python function code and make necessary improvements.
            Check for:
            - Missing import statements
            - Unhandled edge cases (e.g., empty inputs, None values)
            - Syntax errors or logical mistakes
            - Adherence to Python best practices
            Return the corrected code as a plain string, without any explanations or comments.
            """,
            context=code
        )
        
        # Step 4: Return the final, revised code
        return final_code