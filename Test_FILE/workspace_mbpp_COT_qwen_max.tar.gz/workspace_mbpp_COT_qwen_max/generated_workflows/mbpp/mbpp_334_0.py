# Workflow ID: mbpp_334_0
# Benchmark: mbpp
# Data Indices: [217]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name from the test cases
        func_name = await self.generate(
            instruction="Extract the function name from the test cases. "
                        "Return ONLY the function name, nothing else.",
            context=""
        )
        
        # Step 2: Generate the initial Python function code
        code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves this task.
            Requirements:
            1. Include ALL necessary import statements at the top.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Ensure the function is efficient and follows Python best practices.
            4. Return ONLY the executable Python code, no explanations or additional text.
            """,
            context=""
        )
        
        # Step 3: Revise the code to fix any issues
        final_code = await self.revise(
            instruction="Check the following code for issues: "
                        "1. Missing import statements. "
                        "2. Unhandled edge cases. "
                        "3. Inefficiencies or suboptimal logic. "
                        "Fix all issues and return ONLY the corrected code.",
            context=code
        )
        
        return final_code