# Workflow ID: mbpp_338_0
# Benchmark: mbpp
# Data Indices: [218]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio

        # Step 1: Extract the function name and task description
        func_name = await self.generate(
            instruction="Extract only the function name from the test cases. Return ONLY the function name, nothing else.",
            context=""
        )
        task_description = await self.generate(
            instruction="Summarize the task described in the problem statement. Focus on the input, output, and key operations. Return a concise description.",
            context=""
        )

        # Step 2: Generate initial Python code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the following task:
            {task_description}
            Requirements:
            1. Include ALL necessary import statements at the top.
            2. Handle edge cases such as empty inputs, None, and boundary values.
            3. Ensure the function is efficient and Pythonic.
            4. Return ONLY the executable Python code, no explanations.
            """,
            context=""
        )

        # Step 3: Revise the code for robustness and correctness
        final_code = await self.revise(
            instruction=f"""
            Critique and improve the following code:
            {initial_code}
            Focus on:
            1. Missing imports or dependencies.
            2. Edge case handling (empty inputs, None, boundaries).
            3. Efficiency and readability.
            4. Ensure it adheres to Python best practices.
            Return ONLY the corrected code.
            """,
            context=initial_code
        )

        # Step 4: Return the final code
        return final_code