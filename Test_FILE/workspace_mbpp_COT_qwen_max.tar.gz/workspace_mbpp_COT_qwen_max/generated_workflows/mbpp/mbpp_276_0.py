# Workflow ID: mbpp_276_0
# Benchmark: mbpp
# Data Indices: [6]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio

        # Step 1: Extract the function name from the test cases
        func_name = await self.generate(
            instruction="""
            Extract the function name used in the test cases. 
            Return ONLY the function name as plain text, without any additional explanation or formatting.
            """,
            context=""
        )

        # Step 2: Generate the initial implementation of the function
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the following task:
            
            **Task Description:** {self.problem_text}
            
            Requirements:
            1. Include ALL necessary import statements at the top (e.g., `import re` for regex tasks).
            2. Handle edge cases such as empty inputs, invalid inputs, or no match found.
            3. Ensure the function signature matches the test cases provided.
            4. Return ONLY the executable Python code, without any explanations or additional text.
            """,
            context=""
        )

        # Step 3: Revise the generated code to ensure correctness and robustness
        final_code = await self.revise(
            instruction=f"""
            Review and improve the following Python function named '{func_name}':
            
            **Code to Review:**
            {initial_code}
            
            Improvement Criteria:
            1. Check for missing or unnecessary import statements.
            2. Ensure all edge cases are handled (e.g., empty strings, invalid inputs).
            3. Fix any syntax errors, logical flaws, or inefficiencies.
            4. Return ONLY the corrected Python code, without any explanations or additional text.
            """,
            context=initial_code
        )

        # Step 4: Return the final, revised code
        return final_code