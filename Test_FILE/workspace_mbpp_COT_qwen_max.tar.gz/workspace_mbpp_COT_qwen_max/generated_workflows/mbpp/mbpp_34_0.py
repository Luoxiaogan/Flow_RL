# Workflow ID: mbpp_34_0
# Benchmark: mbpp
# Data Indices: [293]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases. "
                        "Return ONLY the function name as plain text, without any additional explanations or quotes.",
            context=""
        )
        
        # Step 2: Generate the initial Python function code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the following task:
            {self.problem_text}
            
            Requirements:
            1. Include ALL necessary import statements at the top of the function.
            2. Handle edge cases such as empty inputs, invalid data types, or boundary values.
            3. Ensure the function signature matches the test cases provided.
            4. Return ONLY the executable Python code, without any explanations or additional text.
            """,
            context=""
        )
        
        # Step 3: Revise the code to ensure correctness and robustness
        final_code = await self.revise(
            instruction="Review the following Python function code. "
                        "Ensure it meets the following criteria:\n"
                        "- All edge cases are handled.\n"
                        "- Necessary imports are included.\n"
                        "- The code is clean, efficient, and follows Pythonic practices.\n"
                        "- Any syntax or logic errors are corrected.\n"
                        "Return ONLY the corrected Python code, without any explanations or additional text.",
            context=initial_code
        )
        
        return final_code