# Workflow ID: mbpp_145_0
# Benchmark: mbpp
# Data Indices: [328]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract function name and task summary
        func_name = await self.generate(
            instruction="Extract ONLY the function name from the test cases. Return a single word, nothing else.",
            context=""
        )
        
        task_summary = await self.generate(
            instruction="Summarize the task described in the problem. Focus on what the function should do, its inputs, and outputs. Be concise but detailed.",
            context=""
        )
        
        # Step 2: Generate initial Python code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name.strip()}' that performs the following task: {task_summary.strip()}.
            Requirements:
            1. Include ALL necessary import statements at the top.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Ensure the function signature matches the test cases.
            4. Return ONLY the executable Python code, no explanations.
            """,
            context=""
        )
        
        # Step 3: Revise the code for completeness and correctness
        final_code = await self.revise(
            instruction=f"""
            Review the following code for the function '{func_name.strip()}':
            --- CODE START ---
            {initial_code.strip()}
            --- CODE END ---
            
            Instructions:
            1. Check for missing imports and add them if necessary.
            2. Ensure all edge cases are handled (e.g., empty inputs, invalid types).
            3. Optimize the code for readability and efficiency.
            4. Return ONLY the corrected Python code, no explanations.
            """,
            context=initial_code
        )
        
        # Step 4: Return the final executable Python code
        return final_code.strip()