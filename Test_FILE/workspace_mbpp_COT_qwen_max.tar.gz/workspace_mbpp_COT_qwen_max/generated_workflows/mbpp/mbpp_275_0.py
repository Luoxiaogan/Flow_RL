# Workflow ID: mbpp_275_0
# Benchmark: mbpp
# Data Indices: [322]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract function name and parameters
        func_info = await self.generate(
            instruction="""
            Analyze the test cases in the problem description.
            Extract the function name and its parameters.
            Return the result as a comma-separated string in the format:
            'function_name,param1,param2,...'
            Example: 'super_seq,str1,str2,len1,len2'
            """,
            context=""
        )
        func_parts = func_info.split(",")
        func_name = func_parts[0]
        params = ", ".join(func_parts[1:])
        
        # Step 2: Generate initial Python code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the problem described in the task.
            Function Signature: def {func_name}({params})
            Requirements:
            1. Include ALL necessary import statements at the top.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Follow Pythonic best practices.
            4. Return ONLY the executable Python code, no explanations.
            """,
            context=""
        )
        
        # Step 3: Revise the code for correctness and completeness
        final_code = await self.revise(
            instruction="""
            Review the provided Python code and make necessary improvements.
            Check for:
            1. Missing import statements.
            2. Edge case handling (e.g., empty inputs, None values).
            3. Compliance with Pythonic practices.
            4. Any logical errors or inefficiencies.
            Return ONLY the corrected Python code, no explanations.
            """,
            context=initial_code
        )
        
        return final_code