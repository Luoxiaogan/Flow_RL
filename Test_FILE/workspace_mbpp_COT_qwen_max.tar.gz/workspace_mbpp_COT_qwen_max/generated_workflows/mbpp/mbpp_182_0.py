# Workflow ID: mbpp_182_0
# Benchmark: mbpp
# Data Indices: [294]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio

        # Step 1: Extract function name and signature
        func_name = await self.generate(
            instruction="""
            Extract the function name and its parameters from the test cases.
            Return ONLY the function name followed by its parameters in parentheses.
            Example: 'max_sum_subseq(arr)'.
            """,
            context=""
        )

        # Step 2: Generate the initial Python function code
        code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the task described in the problem.
            Requirements:
            1. Include ALL necessary import statements at the top.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Follow Pythonic best practices for readability and efficiency.
            4. Return ONLY the executable Python code, no explanations.
            """,
            context=""
        )

        # Step 3: Revise the code for correctness and quality
        final_code = await self.revise(
            instruction="""
            Review the provided Python code for the following:
            1. Missing import statements.
            2. Unhandled edge cases.
            3. Potential inefficiencies or bugs.
            4. Adherence to Pythonic best practices.
            Fix any issues and return ONLY the corrected code.
            """,
            context=code
        )

        return final_code