# Workflow ID: mbpp_239_0
# Benchmark: mbpp
# Data Indices: [147]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        import json  # For JSON parsing if needed
        import re    # For regex operations if needed
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases. Return ONLY the function name, nothing else.",
            context=""
        )
        
        # Step 2: Generate initial Python code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves this task.
            Requirements:
            1. Include ALL necessary import statements at the top (e.g., import re for regex).
            2. Handle edge cases (empty inputs, None, boundaries).
            3. Ensure the function signature matches the test cases.
            4. Return ONLY the executable Python code, no explanations.
            """,
            context=""
        )
        
        # Step 3: Revise the code for completeness
        final_code = await self.revise(
            instruction="""
            Review the provided code and make improvements:
            1. Ensure all required imports are included.
            2. Fix any logical errors or missing edge cases.
            3. Improve code readability and follow Python best practices.
            4. Return ONLY the corrected code, no explanations.
            """,
            context=initial_code
        )
        
        # Optional Step 4: Explore multiple approaches in parallel
        # Uncomment this section if you want to explore multiple solutions
        """
        approach1 = await self.generate(
            instruction=f"Write a simple iterative solution for '{func_name}'. Return ONLY the code.",
            context=""
        )
        approach2 = await self.generate(
            instruction=f"Write a regex-based solution for '{func_name}'. Return ONLY the code.",
            context=""
        )
        results = await asyncio.gather(approach1, approach2)
        final_code = await self.ensemble(
            instruction="Select the best solution based on correctness, efficiency, and readability. Return ONLY the selected code.",
            contexts=results
        )
        """
        
        return final_code