# Workflow ID: mbpp_154_0
# Benchmark: mbpp
# Data Indices: [222]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        import re  # Import regex module for string manipulation tasks
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases. "
                        "Return ONLY the function name, nothing else.",
            context=""
        )
        
        # Step 2: Generate the initial implementation
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves this task.
            Requirements:
            1. Include ALL necessary import statements at the top (e.g., import re for regex tasks).
            2. Handle edge cases such as empty inputs, None, or invalid types.
            3. Return ONLY the executable Python code, no explanations.
            4. Ensure the function signature matches the test cases provided.
            """,
            context=""
        )
        
        # Step 3: Revise the code for correctness and efficiency
        final_code = await self.revise(
            instruction=f"""
            Review the following code for the function '{func_name}':
            - Check for missing imports.
            - Ensure all edge cases are handled (empty strings, None, invalid types).
            - Optimize for performance if possible.
            - Return ONLY the corrected Python code, no explanations.
            """,
            context=initial_code
        )
        
        # Return the final, refined code
        return final_code