# Workflow ID: mbpp_179_0
# Benchmark: mbpp
# Data Indices: [286]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name from the test cases
        func_name = await self.generate(
            instruction="Extract the function name from the test cases. Return ONLY the function name, nothing else.",
            context=""
        )
        
        # Step 2: Generate the initial Python code for the function
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name.strip()}' that solves the following task:
            
            **Task Description:** {self.problem_text}
            
            Requirements:
            1. Include ALL necessary import statements at the top of the function.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Ensure the function is efficient and adheres to Pythonic best practices.
            4. Return ONLY the executable Python code, no explanations or additional text.
            """,
            context=""
        )
        
        # Step 3: Revise the generated code to improve quality and correctness
        final_code = await self.revise(
            instruction="""
            Review the provided Python code and make the following improvements:
            
            1. Check for missing import statements and add them if necessary.
            2. Ensure all edge cases are handled appropriately.
            3. Optimize the code for readability and efficiency.
            4. Return ONLY the corrected Python code, no explanations or additional text.
            """,
            context=initial_code
        )
        
        # Step 4: Return the final, revised code
        return final_code.strip()