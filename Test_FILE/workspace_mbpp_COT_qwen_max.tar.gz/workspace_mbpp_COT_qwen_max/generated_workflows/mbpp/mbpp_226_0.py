# Workflow ID: mbpp_226_0
# Benchmark: mbpp
# Data Indices: [32]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio

        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract ONLY the function name from the test cases in the problem description. Return the function name as a plain string, nothing else.",
            context=""
        )

        # Step 2: Generate initial code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the following task:
            
            **Task Description:** {self.problem_text}
            
            Requirements:
            1. Include ALL necessary import statements at the top of the code.
            2. Handle edge cases such as empty inputs, single-element arrays, or invalid data types.
            3. Ensure the function signature matches the test cases provided in the problem description.
            4. Return ONLY the executable Python code, without any explanations or comments.
            """,
            context=""
        )

        # Step 3: Revise the code for correctness and efficiency
        final_code = await self.revise(
            instruction=f"""
            Review and improve the following Python function named '{func_name}':
            
            **Current Implementation:**
            {initial_code}
            
            Improvement Criteria:
            1. Verify that the logic correctly implements the task described in the problem.
            2. Check for missing imports or unnecessary dependencies.
            3. Ensure proper handling of edge cases (e.g., empty inputs, boundary values).
            4. Optimize for readability and adherence to Pythonic best practices.
            5. Return ONLY the corrected Python code, without any explanations or comments.
            """,
            context=initial_code
        )

        return final_code