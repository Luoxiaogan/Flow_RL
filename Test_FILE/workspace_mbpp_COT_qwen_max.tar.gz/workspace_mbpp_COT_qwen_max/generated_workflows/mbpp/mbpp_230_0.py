# Workflow ID: mbpp_230_0
# Benchmark: mbpp
# Data Indices: [291]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases or problem description. "
                        "Return ONLY the function name, nothing else.",
            context=""
        )
        
        # Step 2: Generate the initial Python function code
        code = await self.generate(
            instruction=f"Write a Python function named '{func_name}' that solves the task described in the problem. "
                        "Requirements:\n"
                        "1. Include ALL necessary import statements at the top.\n"
                        "2. Handle edge cases such as empty inputs, None values, and boundary conditions.\n"
                        "3. Ensure the function signature matches the name '{func_name}'.\n"
                        "4. Return ONLY the executable Python code, no explanations or additional text.",
            context=""
        )
        
        # Step 3: Revise the code for completeness and correctness
        final_code = await self.revise(
            instruction="Review the provided Python code for completeness and correctness. "
                        "Check for the following:\n"
                        "1. Are all necessary imports included?\n"
                        "2. Are edge cases handled properly?\n"
                        "3. Does the function signature match the expected name?\n"
                        "4. Is the code executable and free of syntax errors?\n"
                        "Fix any issues and return ONLY the corrected code.",
            context=code
        )
        
        return final_code