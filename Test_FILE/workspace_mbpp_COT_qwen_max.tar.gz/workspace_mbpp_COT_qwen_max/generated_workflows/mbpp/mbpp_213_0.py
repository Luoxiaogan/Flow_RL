# Workflow ID: mbpp_213_0
# Benchmark: mbpp
# Data Indices: [181]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract function name and key details
        func_name = await self.generate(
            instruction="""
            Extract the function name from the test cases in the problem description.
            Return ONLY the function name, nothing else.
            """,
            context=""
        )
        
        # Step 2: Generate initial Python function code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name.strip()}' that solves the task described in the problem.
            Requirements:
            1. Include ALL necessary import statements at the top.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Follow Python best practices and write clean, efficient code.
            4. Return ONLY the executable Python code, no explanations.
            """,
            context=""
        )
        
        # Step 3: Revise the code for completeness and correctness
        revised_code = await self.revise(
            instruction="""
            Review the provided Python function code and make improvements if necessary.
            Check for:
            1. Missing import statements.
            2. Unhandled edge cases (e.g., empty inputs, None values).
            3. Inefficiencies or non-Pythonic constructs.
            4. Ensure the function signature matches the test case expectations.
            Return ONLY the corrected Python code, no explanations.
            """,
            context=initial_code
        )
        
        # Step 4: Optionally, use Ensemble to compare multiple solutions
        # Uncomment this section if multiple approaches are possible
        # candidate_1 = await self.generate(instruction="...", context="")
        # candidate_2 = await self.generate(instruction="...", context="")
        # final_code = await self.ensemble(
        #     instruction="Select the best solution based on clarity, efficiency, and correctness.",
        #     contexts=[candidate_1, candidate_2]
        # )
        
        # Step 5: Return the final code
        return revised_code