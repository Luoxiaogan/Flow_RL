# Workflow ID: mbpp_44_0
# Benchmark: mbpp
# Data Indices: [64]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio

        # Step 1: Extract the function name from the problem description
        func_name = await self.generate(
            instruction="""
            Extract the function name from the test cases in the problem description.
            Return ONLY the function name as plain text, without quotes or additional explanation.
            """,
            context=""
        )

        # Step 2: Generate the initial implementation of the function
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the problem described below.
            
            Problem Description:
            {self.problem_text}

            Requirements:
            1. Include ALL necessary import statements at the top.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Follow Pythonic best practices (e.g., use list comprehensions where appropriate).
            4. Ensure the function signature matches the test cases provided in the problem description.
            5. Return ONLY the executable Python code, without any explanations or comments.
            """,
            context=""
        )

        # Step 3: Revise the generated code to address potential issues
        final_code = await self.revise(
            instruction="""
            Review the following code and make improvements where necessary:
            - Add any missing import statements.
            - Fix logical errors or inefficiencies.
            - Ensure all edge cases are handled.
            - Make the code more Pythonic if possible.
            Return ONLY the corrected code, without explanations or comments.
            """,
            context=initial_code
        )

        # Step 4: Return the finalized code
        return final_code