# Workflow ID: mbpp_21_0
# Benchmark: mbpp
# Data Indices: [90]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases. Return ONLY the function name, nothing else.",
            context=""
        )
        
        # Step 2: Generate the initial Python code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves this task.
            Requirements:
            1. Include ALL necessary import statements at the top (e.g., 'from collections import defaultdict').
            2. Handle edge cases like empty inputs, None values, or invalid data types.
            3. Ensure the function is efficient and follows Pythonic best practices.
            4. Return ONLY the executable Python code, no explanations.
            """,
            context=""
        )
        
        # Step 3: Revise the code for correctness and efficiency
        final_code = await self.revise(
            instruction=f"""
            Critique and improve the following Python function named '{func_name}':
            - Check for missing imports or unnecessary dependencies.
            - Ensure all edge cases are handled (e.g., empty inputs, invalid data types).
            - Optimize for performance where possible.
            - Return ONLY the corrected Python code, no explanations.
            """,
            context=initial_code
        )
        
        return final_code