# Workflow ID: mbpp_169_0
# Benchmark: mbpp
# Data Indices: [30]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        import re  # For regex-based tasks
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="""
            Extract the function name from the test cases in the problem description.
            Return ONLY the function name, nothing else.
            """,
            context=""
        )
        
        # Step 2: Generate initial Python code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the following task:
            
            Task Description:
            {self.problem_text}
            
            Requirements:
            1. Include ALL necessary import statements at the top of the code.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Ensure the function signature matches the test cases provided.
            4. Return ONLY the executable Python code, no explanations or comments.
            """,
            context=""
        )
        
        # Step 3: Revise the code for correctness and robustness
        final_code = await self.revise(
            instruction="""
            Review the provided Python code and make the following improvements:
            1. Ensure all necessary imports are included.
            2. Verify that edge cases are handled properly.
            3. Optimize the code for readability and efficiency.
            4. Ensure the function passes all test cases.
            Return ONLY the corrected Python code, no explanations or comments.
            """,
            context=initial_code
        )
        
        return final_code