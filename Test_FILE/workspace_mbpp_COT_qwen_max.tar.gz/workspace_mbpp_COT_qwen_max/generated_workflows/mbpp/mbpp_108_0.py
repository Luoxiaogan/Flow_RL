# Workflow ID: mbpp_108_0
# Benchmark: mbpp
# Data Indices: [123]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases. Return ONLY the function name, nothing else.",
            context=""
        )
        
        # Step 2: Generate the initial Python code
        code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves this task.
            Requirements:
            1. Include ALL necessary import statements at the top.
            2. Handle edge cases (empty inputs, None, boundaries).
            3. Follow Python best practices (PEP 8, efficient algorithms).
            4. Return ONLY the executable Python code, no explanations.
            """,
            context=""
        )
        
        # Step 3: Revise the generated code for correctness and completeness
        final_code = await self.revise(
            instruction="""
            Review the provided Python code and make necessary improvements.
            Focus on:
            1. Missing import statements.
            2. Unhandled edge cases (e.g., empty inputs, None, boundaries).
            3. Efficiency and readability.
            4. Adherence to Python best practices.
            Return ONLY the corrected Python code.
            """,
            context=code
        )
        
        return final_code