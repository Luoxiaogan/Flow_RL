# Workflow ID: mbpp_353_0
# Benchmark: mbpp
# Data Indices: [72]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio

        # Step 1: Extract the function name and key details
        func_name = await self.generate(
            instruction="""
            Analyze the problem description and test cases.
            Extract ONLY the exact function name required by the test cases.
            Return the function name as plain text (no quotes, no explanations).
            """,
            context=""
        )

        # Step 2: Generate the initial implementation
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves this task.
            Requirements:
            1. Include ALL necessary import statements at the top.
            2. Handle edge cases such as empty inputs, invalid data types, and boundary values.
            3. Ensure the function signature matches the test cases (e.g., parameter names and types).
            4. Return ONLY the executable Python code, without explanations or comments.
            """,
            context=""
        )

        # Step 3: Revise the code for quality assurance
        final_code = await self.revise(
            instruction=f"""
            Review the following code for the function '{func_name}':
            - Check for missing imports or unused imports.
            - Ensure all edge cases are handled (e.g., empty inputs, invalid data types).
            - Verify adherence to Pythonic practices (e.g., readability, efficiency).
            - Confirm correctness based on the provided test cases.
            Return ONLY the corrected Python code.
            """,
            context=initial_code
        )

        # Step 4: Return the final solution
        return final_code