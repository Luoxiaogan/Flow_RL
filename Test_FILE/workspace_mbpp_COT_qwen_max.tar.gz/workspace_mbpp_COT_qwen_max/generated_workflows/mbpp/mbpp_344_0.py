# Workflow ID: mbpp_344_0
# Benchmark: mbpp
# Data Indices: [255]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name and parameters
        func_name = await self.generate(
            instruction="Extract the function name from the test cases. Return ONLY the function name, nothing else.",
            context=""
        )
        params = await self.generate(
            instruction="Extract the parameter names and types from the test cases. Return them as a comma-separated list, e.g., 'arr: List[int], n: int'.",
            context=""
        )
        
        # Step 2: Generate initial code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' with parameters ({params}) that solves this task.
            Requirements:
            1. Include ALL necessary import statements at the top.
            2. Handle edge cases (empty inputs, None, boundaries).
            3. Follow Pythonic best practices and ensure efficiency.
            4. Return ONLY the executable Python code, no explanations.
            """,
            context=""
        )
        
        # Step 3: Revise the code for accuracy and completeness
        final_code = await self.revise(
            instruction="""
            Review the provided code for correctness, efficiency, and adherence to Python best practices.
            Fix any issues, including missing imports, inefficiencies, or unhandled edge cases.
            Return ONLY the corrected Python code, no explanations.
            """,
            context=initial_code
        )
        
        # Step 4: Optional Ensemble for robustness (if multiple approaches are possible)
        # Uncomment and adapt this section if needed
        # approach_1 = await self.generate(instruction="Iterative solution", context="")
        # approach_2 = await self.generate(instruction="Recursive solution", context="")
        # final_code = await self.ensemble(
        #     instruction="Select the most efficient and Pythonic implementation.",
        #     contexts=[approach_1, approach_2]
        # )
        
        return final_code