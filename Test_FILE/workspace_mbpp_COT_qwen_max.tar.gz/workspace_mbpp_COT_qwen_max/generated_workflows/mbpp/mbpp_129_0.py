# Workflow ID: mbpp_129_0
# Benchmark: mbpp
# Data Indices: [240]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        import json  # For parsing JSON if needed
        
        # Step 1: Extract the function name from the test cases
        func_name = await self.generate(
            instruction="""
            Analyze the test cases in the problem description. 
            Extract ONLY the function name used in the test cases. 
            Return the function name as plain text, without quotes or additional explanations.
            """,
            context=""
        )
        
        # Step 2: Generate the initial Python function
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name.strip()}' that solves the problem described in the task.
            Requirements:
            1. Include ALL necessary import statements at the top (e.g., 'import math', 'from collections import Counter').
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Ensure the function signature matches the test cases exactly.
            4. Follow Pythonic conventions and best practices.
            5. Return ONLY the executable Python code, without any explanations or comments.
            """,
            context=""
        )
        
        # Step 3: Revise the code for robustness and correctness
        final_code = await self.revise(
            instruction="""
            Review the provided Python code and improve it if necessary.
            Focus on:
            1. Missing imports or incorrect import statements.
            2. Edge case handling (e.g., empty inputs, None values).
            3. Logical errors or inefficiencies.
            4. Compliance with Python best practices.
            Return ONLY the corrected code, without explanations or comments.
            """,
            context=initial_code
        )
        
        # Step 4: Return the final, revised code
        return final_code.strip()