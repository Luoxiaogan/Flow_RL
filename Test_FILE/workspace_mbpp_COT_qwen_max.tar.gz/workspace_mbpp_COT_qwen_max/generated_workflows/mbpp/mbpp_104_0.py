# Workflow ID: mbpp_104_0
# Benchmark: mbpp
# Data Indices: [13]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name and key details
        func_name = await self.generate(
            instruction="Extract ONLY the function name from the test cases. Return just the name, nothing else.",
            context=""
        )
        
        # Step 2: Generate initial Python code
        code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves this task.
            Requirements:
            1. Include ALL necessary import statements at the top (e.g., from typing import List, Tuple).
            2. Handle edge cases such as empty inputs, tuples with varying lengths, and invalid data types.
            3. Use Pythonic constructs like list comprehensions or generator expressions where appropriate.
            4. Return ONLY the executable Python code, no explanations.
            """,
            context=""
        )
        
        # Step 3: Revise the code for correctness and robustness
        final_code = await self.revise(
            instruction=f"""
            Review the following code for the function '{func_name}':
            - Ensure it passes the provided test cases.
            - Check for missing imports and edge case handling.
            - Optimize for efficiency without sacrificing readability.
            - Return ONLY the corrected code, no explanations.
            """,
            context=code
        )
        
        return final_code