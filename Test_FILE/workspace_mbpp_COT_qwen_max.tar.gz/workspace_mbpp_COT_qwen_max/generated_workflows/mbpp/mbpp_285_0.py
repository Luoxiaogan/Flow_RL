# Workflow ID: mbpp_285_0
# Benchmark: mbpp
# Data Indices: [60]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio

        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="""
            Extract the function name from the test cases in the problem description.
            Return ONLY the function name as plain text, without any additional words or punctuation.
            """,
            context=""
        )

        # Step 2: Generate the initial Python function code
        code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the problem described in the following text.
            
            Requirements:
            1. Include ALL necessary import statements at the top of the function.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Ensure the function adheres to Pythonic best practices.
            4. Return ONLY the executable Python code, without any explanations or additional text.
            
            Problem Description:
            {self.problem_text}
            """,
            context=""
        )

        # Step 3: Revise the generated code
        final_code = await self.revise(
            instruction="""
            Review the provided Python function code and make improvements where necessary.
            
            Specific checks:
            1. Ensure all required import statements are included.
            2. Verify that edge cases are handled correctly.
            3. Optimize the code for efficiency and readability.
            4. Return ONLY the corrected and optimized Python code, without any explanations or additional text.
            """,
            context=code
        )

        return final_code