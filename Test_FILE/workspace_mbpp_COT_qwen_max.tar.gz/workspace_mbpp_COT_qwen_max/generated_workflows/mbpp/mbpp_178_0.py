# Workflow ID: mbpp_178_0
# Benchmark: mbpp
# Data Indices: [112]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio

        # Step 1: Extract the function name from the test cases
        func_name = await self.generate(
            instruction="Extract the function name from the test cases in the problem description. "
                        "Return ONLY the function name, nothing else.",
            context=""
        )
        func_name = func_name.strip()  # Remove any leading/trailing whitespace

        # Step 2: Generate the initial Python function code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the problem described in the task.
            Requirements:
            1. Include ALL necessary import statements at the top of the code.
            2. Handle edge cases such as empty inputs, None values, and invalid types.
            3. Ensure the function signature matches the test cases provided.
            4. Return ONLY the executable Python code, no explanations or additional text.
            """,
            context=""
        )

        # Step 3: Revise the code to fix potential issues
        final_code = await self.revise(
            instruction=f"""
            Review the following Python code for the function '{func_name}':
            - Check for missing import statements.
            - Ensure all edge cases are handled (e.g., empty inputs, None values).
            - Verify that the function adheres to Python best practices and is efficient.
            - Return ONLY the corrected Python code, no explanations or additional text.
            """,
            context=initial_code
        )

        # Step 4: Return the final code
        return final_code