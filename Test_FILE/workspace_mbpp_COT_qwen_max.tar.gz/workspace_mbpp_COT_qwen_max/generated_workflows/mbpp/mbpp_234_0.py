# Workflow ID: mbpp_234_0
# Benchmark: mbpp
# Data Indices: [306]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio

        # Step 1: Extract function name and parameters
        func_signature = await self.generate(
            instruction="""
            Extract the function name and parameters from the test cases.
            Return ONLY the function signature in the format 'def function_name(param1, param2):', nothing else.
            """,
            context=""
        )

        # Step 2: Generate initial code implementation
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function with the signature '{func_signature}' that solves the problem described in the original problem text.
            Requirements:
            1. Include ALL necessary import statements at the top.
            2. Handle edge cases such as empty inputs, None, and boundary values.
            3. Follow Pythonic best practices.
            4. Return ONLY the executable Python code, no explanations.
            """,
            context=""
        )

        # Step 3: Revise and refine the code
        final_code = await self.revise(
            instruction="""
            Critique and improve the provided code.
            Focus on:
            1. Fixing missing imports.
            2. Improving efficiency and readability.
            3. Ensuring correctness for all edge cases.
            Return ONLY the corrected code, no explanations.
            """,
            context=initial_code
        )

        return final_code