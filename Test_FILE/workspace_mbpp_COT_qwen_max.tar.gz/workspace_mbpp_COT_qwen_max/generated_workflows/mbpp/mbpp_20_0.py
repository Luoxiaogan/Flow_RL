# Workflow ID: mbpp_20_0
# Benchmark: mbpp
# Data Indices: [305]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        import json  # For parsing JSON if needed
        import re    # For regex operations if required
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="""
            Extract the function name from the test cases in the problem description.
            Return ONLY the function name as plain text, without any additional explanation.
            """,
            context=""
        )
        func_name = func_name.strip()  # Remove any leading/trailing whitespace

        # Step 2: Generate the initial Python code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the following task:
            
            {self.problem_text}
            
            Requirements:
            1. Include ALL necessary import statements at the top.
            2. Handle edge cases such as empty inputs, None values, or boundary conditions.
            3. Ensure the function is efficient and adheres to Python best practices.
            4. Return ONLY the executable Python code, without any explanations or comments.
            """,
            context=""
        )

        # Step 3: Revise the code for completeness and correctness
        final_code = await self.revise(
            instruction=f"""
            Review and improve the following Python function named '{func_name}':
            
            {initial_code}
            
            Focus on the following:
            1. Ensure all required imports are included.
            2. Verify that edge cases are handled correctly.
            3. Fix any syntax errors or logical issues.
            4. Optimize the code for readability and performance.
            
            Return ONLY the corrected and improved Python code.
            """,
            context=initial_code
        )

        # Step 4: Return the final code
        return final_code