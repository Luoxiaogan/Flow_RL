# Workflow ID: mbpp_24_0
# Benchmark: mbpp
# Data Indices: [158]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name and purpose
        func_name = await self.generate(
            instruction="Extract the function name from the test cases. "
                        "Return ONLY the function name, nothing else.",
            context=""
        )
        
        # Step 2: Generate the initial Python function
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves this task.
            Requirements:
            1. Include ALL necessary import statements at the top
            2. Handle edge cases (empty inputs, None, boundaries)
            3. Ensure the function signature matches the test cases
            4. Return ONLY the executable Python code, no explanations
            """,
            context=""
        )
        
        # Step 3: Revise the code for accuracy and completeness
        revised_code = await self.revise(
            instruction="Check the following code for issues: "
                        "1. Missing imports or incorrect usage "
                        "2. Unhandled edge cases (e.g., empty inputs, invalid types) "
                        "3. Non-Pythonic or inefficient implementation "
                        "4. Mismatch with test case expectations "
                        "Fix any issues and return only the corrected code.",
            context=initial_code
        )
        
        # Optional Step 4: Ensemble for robustness (if multiple approaches exist)
        # Uncomment this section if you want to explore multiple solutions
        # alternative_code = await self.generate(
        #     instruction=f"Write an alternative implementation for the function '{func_name}'. "
        #                 "Return ONLY the executable Python code.",
        #     context=""
        # )
        # final_code = await self.ensemble(
        #     instruction="Compare the two implementations and select the best one. "
        #                 "Criteria: correctness, efficiency, Pythonic style. "
        #                 "Return only the selected code.",
        #     contexts=[revised_code, alternative_code]
        # )
        
        # Step 5: Return the final code
        return revised_code