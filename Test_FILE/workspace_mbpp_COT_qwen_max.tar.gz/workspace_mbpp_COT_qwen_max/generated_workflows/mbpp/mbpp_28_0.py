# Workflow ID: mbpp_28_0
# Benchmark: mbpp
# Data Indices: [26]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases. "
                        "Return ONLY the function name, nothing else.",
            context=""
        )
        
        # Step 2: Generate initial Python function code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the given task.
            Requirements:
            1. Include ALL necessary import statements at the top of the function.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Write clean, efficient, and Pythonic code.
            4. Return ONLY the executable Python code, without any explanations or comments.
            """,
            context=""
        )
        
        # Step 3: Revise the code for missing imports and edge cases
        final_code = await self.revise(
            instruction=f"""
            Review the following Python function code for '{func_name}':
            - Check for missing import statements and add them at the top.
            - Ensure all edge cases are handled (e.g., empty inputs, None values, boundaries).
            - Refactor the code to follow Pythonic best practices if needed.
            - Return ONLY the corrected Python code, without any explanations or comments.
            """,
            context=initial_code
        )
        
        return final_code