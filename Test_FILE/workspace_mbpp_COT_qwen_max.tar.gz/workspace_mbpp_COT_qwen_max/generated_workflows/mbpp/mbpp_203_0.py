# Workflow ID: mbpp_203_0
# Benchmark: mbpp
# Data Indices: [120]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name from the test cases
        func_name = await self.generate(
            instruction="""
            Extract the function name from the test cases in the problem description.
            Return ONLY the function name, nothing else.
            """,
            context=""
        )
        
        # Step 2: Generate the initial Python function code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the task described in the problem.
            Requirements:
            1. Include ALL necessary import statements at the top.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Ensure the code is efficient, readable, and follows Python best practices.
            4. Return ONLY the executable Python code, without any explanations or comments.
            """,
            context=""
        )
        
        # Step 3: Revise the generated code for correctness and completeness
        final_code = await self.revise(
            instruction="""
            Review the provided Python function code and make improvements where necessary.
            Focus on:
            1. Adding any missing import statements.
            2. Handling edge cases more robustly.
            3. Optimizing performance if possible.
            4. Ensuring the code adheres to Pythonic conventions.
            Return ONLY the corrected and improved Python code.
            """,
            context=initial_code
        )
        
        # Step 4: Return the final, validated Python function
        return final_code