# Workflow ID: mbpp_284_0
# Benchmark: mbpp
# Data Indices: [259]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        import json  # For parsing JSON if needed
        import re    # For regex operations if required
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases. Return ONLY the function name, nothing else.",
            context=""
        )
        
        # Step 2: Generate the initial implementation
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves this task.
            Requirements:
            1. Include ALL necessary import statements at the top
            2. Handle edge cases (empty inputs, None, boundaries)
            3. Follow Python best practices and idioms
            4. Return ONLY the executable Python code, no explanations
            """,
            context=""
        )
        
        # Step 3: Revise the code for robustness
        revised_code = await self.revise(
            instruction=f"""
            Critique and improve the following Python function:
            {initial_code}
            Ensure the following:
            1. All edge cases are handled (e.g., empty inputs, None, invalid data)
            2. Necessary imports are included
            3. Code is efficient and Pythonic
            4. Return ONLY the corrected Python code, no explanations
            """,
            context=initial_code
        )
        
        # Step 4: Ensemble for final decision (optional for complex tasks)
        # Uncomment this section if multiple revisions or alternatives are generated
        # candidates = [initial_code, revised_code]
        # final_code = await self.ensemble(
        #     instruction="Select the best implementation or synthesize a final version. Return ONLY the final Python code.",
        #     contexts=candidates
        # )
        
        # For simplicity, assume the revised code is final
        final_code = revised_code
        
        return final_code