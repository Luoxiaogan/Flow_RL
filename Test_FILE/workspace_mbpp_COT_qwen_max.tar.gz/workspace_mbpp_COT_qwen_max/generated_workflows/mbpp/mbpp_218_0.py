# Workflow ID: mbpp_218_0
# Benchmark: mbpp
# Data Indices: [340]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio

        # Step 1: Extract the function name from the test cases
        func_name = await self.generate(
            instruction="Extract ONLY the function name from the test cases. Return the name as plain text, nothing else.",
            context=""
        )

        # Step 2: Generate the initial Python function code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the described task.
            Requirements:
            1. Include ALL necessary import statements at the top.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Ensure the function signature matches the test cases.
            4. Return ONLY the executable Python code, no explanations or additional text.
            """,
            context=""
        )

        # Step 3: Revise the generated code for completeness and correctness
        final_code = await self.revise(
            instruction="""
            Review the provided Python function code and make improvements:
            1. Ensure all necessary imports are included.
            2. Verify that edge cases are handled correctly.
            3. Fix any syntax or logic errors.
            4. Optimize the code for readability and efficiency while maintaining correctness.
            Return ONLY the corrected and improved Python code.
            """,
            context=initial_code
        )

        # Step 4: Return the final Python function code
        return final_code