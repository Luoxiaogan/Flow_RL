# Workflow ID: mbpp_229_0
# Benchmark: mbpp
# Data Indices: [230]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio

        # Step 1: Extract function name and signature
        func_name = await self.generate(
            instruction="""
            Analyze the test cases in the problem description.
            Extract the function name and its parameters.
            Return ONLY the function name followed by its parameters in parentheses, e.g., 'count_Pairs(arr, n)'.
            """,
            context=""
        )

        # Step 2: Generate initial Python code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the problem described.
            Requirements:
            1. Include ALL necessary import statements at the top (e.g., from collections import Counter).
            2. Handle edge cases such as empty inputs, single-element arrays, or arrays with no matching pairs.
            3. Follow Python best practices and idioms.
            4. Return ONLY the executable Python code, no explanations.
            """,
            context=""
        )

        # Step 3: Revise the code for completeness and correctness
        final_code = await self.revise(
            instruction="""
            Review the provided Python code and improve it.
            Focus on:
            1. Missing or unnecessary imports.
            2. Edge case handling (e.g., empty arrays, single-element arrays).
            3. Adherence to Python best practices.
            4. Alignment with the expected behavior in the test cases.
            Return ONLY the corrected Python code.
            """,
            context=initial_code
        )

        return final_code