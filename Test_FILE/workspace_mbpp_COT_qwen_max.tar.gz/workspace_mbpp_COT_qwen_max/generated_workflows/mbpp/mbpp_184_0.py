# Workflow ID: mbpp_184_0
# Benchmark: mbpp
# Data Indices: [3]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio

        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases. Return ONLY the function name, nothing else.",
            context=""
        )
        func_name = func_name.strip()  # Remove any extra whitespace

        # Step 2: Generate the initial Python code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves this task.
            Requirements:
            1. Include ALL necessary import statements at the top.
            2. Handle edge cases such as empty inputs, None, or boundary values.
            3. Follow Python best practices (PEP 8, readability, efficiency).
            4. Return ONLY the executable Python code, no explanations.
            """,
            context=""
        )

        # Step 3: Revise the code for correctness and completeness
        revised_code = await self.revise(
            instruction="Check for missing imports, edge cases, and inefficiencies. Fix any issues. Return only the corrected code.",
            context=initial_code
        )

        # Step 4: Optional Ensemble step (if multiple approaches are generated)
        # Uncomment and adapt if needed for more complex problems
        # candidate_1 = revised_code
        # candidate_2 = await self.generate(
        #     instruction=f"Write an alternative implementation for '{func_name}'.",
        #     context=""
        # )
        # final_code = await self.ensemble(
        #     instruction="Select the best implementation based on clarity, correctness, and efficiency. Return only the selected code.",
        #     contexts=[candidate_1, candidate_2]
        # )

        # Step 5: Return the final code
        return revised_code