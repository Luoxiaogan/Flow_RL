# Workflow ID: mbpp_306_0
# Benchmark: mbpp
# Data Indices: [238]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name from the test cases
        func_name = await self.generate(
            instruction="Extract the function name used in the test cases. Return ONLY the function name, nothing else.",
            context=""
        )
        
        # Step 2: Generate the initial implementation of the function
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the following task:
            
            **Task Description:**
            {self.problem_text}
            
            **Requirements:**
            1. Include ALL necessary import statements at the top (if any).
            2. Handle edge cases such as empty inputs, invalid types, or boundary values.
            3. Ensure the function signature matches the test cases.
            4. Return ONLY the executable Python code, no explanations.
            """,
            context=""
        )
        
        # Step 3: Revise the code to ensure correctness and completeness
        final_code = await self.revise(
            instruction="""
            Review the provided Python function code and make the following improvements:
            
            1. Ensure all edge cases are handled (e.g., empty lists, invalid inputs).
            2. Fix any missing imports or logical errors.
            3. Optimize the code for readability and efficiency while maintaining correctness.
            4. Return ONLY the corrected Python code, no explanations.
            """,
            context=initial_code
        )
        
        # Step 4: Return the final Python function code
        return final_code