# Workflow ID: mbpp_237_0
# Benchmark: mbpp
# Data Indices: [1]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio

        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases. "
                        "Return ONLY the function name, nothing else.",
            context=""
        )
        func_name = func_name.strip()  # Remove any leading/trailing whitespace

        # Step 2: Generate the initial Python code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the following task:
            {self.problem_text}
            
            Requirements:
            1. Include ALL necessary import statements at the top of the code.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Ensure the function is efficient and follows Python best practices.
            4. Return ONLY the executable Python code, without any explanations or comments.
            """,
            context=""
        )

        # Step 3: Revise the code to ensure correctness and robustness
        final_code = await self.revise(
            instruction=f"""
            Review the following Python code for the function '{func_name}':
            {initial_code}
            
            Perform the following checks:
            1. Ensure all necessary imports are included.
            2. Verify that edge cases (e.g., empty inputs, None values) are handled correctly.
            3. Fix any syntax or logical errors.
            4. Optimize the code for clarity and efficiency.
            
            Return ONLY the corrected Python code, without any explanations or comments.
            """,
            context=initial_code
        )

        # Step 4: Return the final, revised code
        return final_code