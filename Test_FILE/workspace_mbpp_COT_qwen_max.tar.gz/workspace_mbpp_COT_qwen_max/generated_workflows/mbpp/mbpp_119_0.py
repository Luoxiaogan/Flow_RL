# Workflow ID: mbpp_119_0
# Benchmark: mbpp
# Data Indices: [338]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        # Import modules as needed
        # import json  # Uncomment if you need JSON parsing
        # import re    # Uncomment if you need regex
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="""
            Extract the function name from the test cases in the problem description.
            Return ONLY the function name as plain text, without any additional explanation.
            """,
            context=""
        )
        
        # Step 2: Generate initial code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the task described in the problem.
            Requirements:
            1. Include ALL necessary import statements at the top of the code.
            2. Handle edge cases such as empty inputs, invalid data types, and boundary conditions.
            3. Ensure the function passes the provided test cases.
            4. Use Pythonic practices and follow best coding standards.
            5. Return ONLY the executable Python code, without any explanations or comments.
            """,
            context=""
        )
        
        # Step 3: Revise the code for correctness and efficiency
        revised_code = await self.revise(
            instruction=f"""
            Review the following code for the function '{func_name}':
            - Ensure it complies with the problem requirements and test cases.
            - Fix any missing imports or edge case handling.
            - Optimize for efficiency and readability.
            - Return ONLY the corrected Python code, without any explanations or comments.
            """,
            context=initial_code
        )
        
        # Optional Step 4: Summarize the final code
        final_summary = await self.summarize(
            instruction=f"""
            Summarize the functionality of the function '{func_name}' in one sentence.
            Focus on the core purpose of the function and its compliance with the problem requirements.
            Return ONLY the summary as plain text.
            """,
            context=revised_code
        )
        
        # Return the finalized Python code
        return revised_code