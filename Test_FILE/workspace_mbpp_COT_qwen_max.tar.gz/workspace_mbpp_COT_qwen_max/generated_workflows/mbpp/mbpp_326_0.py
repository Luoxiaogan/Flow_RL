# Workflow ID: mbpp_326_0
# Benchmark: mbpp
# Data Indices: [129]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio

        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases. "
                        "Return ONLY the function name as plain text, without any additional explanation or quotes.",
            context=""
        )

        # Step 2: Generate initial Python code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the problem described in the original problem text.
            Requirements:
            1. Include ALL necessary import statements at the top of the code.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Ensure the function signature matches the test cases provided in the original problem text.
            4. Return ONLY the executable Python code, without any explanations or additional text.
            """,
            context=""
        )

        # Step 3: Revise the code to improve correctness and robustness
        final_code = await self.revise(
            instruction="Review the provided Python code and make necessary improvements. "
                        "Focus on the following aspects: "
                        "1. Ensure all required imports are included. "
                        "2. Verify that edge cases are handled correctly. "
                        "3. Fix any syntax or logical errors. "
                        "4. Return ONLY the corrected Python code, without any explanations or additional text.",
            context=initial_code
        )

        # Step 4: Return the final refined code
        return final_code