# Workflow ID: mbpp_190_0
# Benchmark: mbpp
# Data Indices: [131]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        import re  # For regex-based validation if needed
        
        # Step 1: Extract the function name from the test cases
        func_name = await self.generate(
            instruction="""
            Analyze the test cases in the problem description.
            Extract and return ONLY the function name as plain text, nothing else.
            Ensure the function name matches the test case assertions exactly.
            """,
            context=""
        )
        
        # Step 2: Generate the initial Python function code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the task described in the problem.
            Requirements:
            1. Include ALL necessary import statements at the top of the code.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Follow Python best practices and write clean, efficient code.
            4. Return ONLY the executable Python code, without any explanations or comments.
            """,
            context=""
        )
        
        # Step 3: Revise the generated code for correctness and completeness
        final_code = await self.revise(
            instruction="""
            Carefully review the provided Python code and make improvements where necessary.
            Focus on:
            1. Adding any missing import statements.
            2. Fixing logical or syntactical errors.
            3. Ensuring proper handling of edge cases.
            4. Improving code readability and efficiency.
            Return ONLY the corrected and complete Python code.
            """,
            context=initial_code
        )
        
        # Return the final, refined Python function code
        return final_code