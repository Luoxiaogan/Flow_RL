# Workflow ID: mbpp_341_0
# Benchmark: mbpp
# Data Indices: [168]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract Function Name
        func_name = await self.generate(
            instruction="From the provided problem and test cases, extract ONLY the function name that needs to be implemented. Return just the function name as plain text.",
            context=""
        )
        
        # Ensure we have a valid function name
        if not func_name.strip():
            raise ValueError("Function name extraction failed.")
        
        # Step 2: Generate Initial Code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the given problem. Follow these strict guidelines:
            1. Include ALL necessary import statements at the top (e.g., import math, import re).
            2. Handle all possible edge cases, including empty inputs, None values, and boundary conditions.
            3. Ensure the function signature matches the test cases exactly.
            4. Make the code Pythonic and follow best practices.
            5. Return ONLY the executable Python code, without any explanations or comments outside the function.
            """,
            context=""
        )
        
        # Step 3: Revise the Generated Code
        final_code = await self.revise(
            instruction=f"""
            Review the following Python function named '{func_name}' and make necessary improvements:
            1. Check for any missing import statements.
            2. Ensure all edge cases are handled correctly.
            3. Verify that the function signature matches the test cases.
            4. Optimize the code for clarity and efficiency while maintaining correctness.
            5. Return ONLY the corrected and improved Python code, without any explanations.
            """,
            context=initial_code
        )
        
        return final_code