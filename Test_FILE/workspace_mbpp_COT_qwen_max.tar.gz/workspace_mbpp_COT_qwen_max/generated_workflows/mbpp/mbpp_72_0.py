# Workflow ID: mbpp_72_0
# Benchmark: mbpp
# Data Indices: [179]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases in the problem description. "
                        "Return ONLY the function name as plain text, without quotes or additional explanation.",
            context=""
        )
        
        # Step 2: Generate the initial Python code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the problem described in the problem text.
            Requirements:
            1. Include ALL necessary import statements at the top of the code.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Ensure the code is efficient and adheres to Python best practices.
            4. Return ONLY the executable Python code as plain text, without any explanations or additional text.
            """,
            context=""
        )
        
        # Step 3: Revise the code to ensure correctness and robustness
        final_code = await self.revise(
            instruction=f"""
            Review the following Python code for the function '{func_name}':
            - Check for missing imports or unused variables.
            - Ensure all edge cases are handled correctly.
            - Verify that the code matches the problem requirements and passes the test cases.
            - Improve efficiency and readability where possible.
            Return ONLY the corrected and improved Python code as plain text, without any explanations.
            """,
            context=initial_code
        )
        
        return final_code