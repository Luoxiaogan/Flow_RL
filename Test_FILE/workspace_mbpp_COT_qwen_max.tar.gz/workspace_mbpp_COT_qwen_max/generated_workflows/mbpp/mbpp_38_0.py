# Workflow ID: mbpp_38_0
# Benchmark: mbpp
# Data Indices: [320]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract function name and parameters
        func_signature = await self.generate(
            instruction="""
            Extract the function signature from the problem description.
            Return ONLY the function name and parameters in the format 'function_name(param1, param2, ...)'.
            Do not include any additional explanations or code.
            """,
            context=""
        )
        
        # Step 2: Generate initial code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_signature}' that solves the problem described in the original prompt.
            Requirements:
            1. Include ALL necessary import statements at the top.
            2. Handle edge cases such as empty inputs, invalid parameters, or boundary conditions.
            3. Ensure the function adheres to Python best practices and is efficient.
            4. Return ONLY the executable Python code, without any explanations or additional text.
            """,
            context=""
        )
        
        # Step 3: Revise the code for completeness and correctness
        final_code = await self.revise(
            instruction="""
            Review the provided Python function code and make improvements where necessary.
            Focus on the following:
            1. Ensure all required imports are included.
            2. Verify that edge cases are handled correctly.
            3. Optimize the code for readability and efficiency.
            4. Return ONLY the corrected and improved Python code.
            """,
            context=initial_code
        )
        
        return final_code