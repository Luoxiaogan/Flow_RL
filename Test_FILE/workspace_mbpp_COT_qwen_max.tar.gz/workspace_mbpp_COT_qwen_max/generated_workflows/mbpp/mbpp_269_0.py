# Workflow ID: mbpp_269_0
# Benchmark: mbpp
# Data Indices: [114]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        # Add any other necessary imports here

        # Step 1: Extract the function name from the test cases
        func_name = await self.generate(
            instruction="""
            Extract the function name from the test cases in the problem description.
            Return ONLY the function name as plain text, without any additional explanation.
            """,
            context=""
        )

        # Step 2: Generate the initial Python function code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the problem described in the original problem text.
            
            Requirements:
            1. Include ALL necessary import statements at the top.
            2. Handle edge cases such as empty inputs, invalid formats, or boundary values.
            3. Ensure the function signature matches the test cases provided.
            4. Return ONLY the executable Python code, without any explanations or comments.
            """,
            context=""
        )

        # Step 3: Revise the code for correctness and completeness
        final_code = await self.revise(
            instruction="""
            Review the following Python function code and improve it if necessary:
            
            - Ensure all required imports are included.
            - Check for and handle any edge cases that might have been missed.
            - Optimize the code for readability and efficiency while maintaining correctness.
            - Return ONLY the corrected and improved Python code, without any explanations or comments.
            """,
            context=initial_code
        )

        # Step 4: Return the final Python function code
        return final_code