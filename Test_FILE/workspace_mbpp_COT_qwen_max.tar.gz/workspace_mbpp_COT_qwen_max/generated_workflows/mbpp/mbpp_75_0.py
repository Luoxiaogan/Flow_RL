# Workflow ID: mbpp_75_0
# Benchmark: mbpp
# Data Indices: [242]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio

        # Step 1: Extract the function name from the test cases
        func_name = await self.generate(
            instruction="Extract ONLY the function name from the test cases in the problem description. "
                        "Return ONLY the function name, nothing else.",
            context=""
        )

        # Step 2: Generate the initial implementation of the function
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the task described in the problem.
            Requirements:
            1. Include ALL necessary import statements at the top (e.g., import heapq, import math).
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Ensure the function signature matches the test cases (e.g., parameter names and order).
            4. Return ONLY the executable Python code, no explanations or additional text.
            """,
            context=""
        )

        # Step 3: Revise the generated code to ensure correctness and completeness
        final_code = await self.revise(
            instruction="Carefully review the provided code and make necessary improvements. "
                        "Check for the following: \n"
                        "- Missing import statements \n"
                        "- Edge case handling (e.g., empty inputs, None values, boundary conditions) \n"
                        "- Compliance with Pythonic practices \n"
                        "- Ensure the function passes all test cases \n"
                        "Return ONLY the corrected and complete Python code.",
            context=initial_code
        )

        # Step 4: Return the final Python function code
        return final_code