# Workflow ID: mbpp_66_0
# Benchmark: mbpp
# Data Indices: [194]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name and necessary imports
        func_name = await self.generate(
            instruction="Extract the function name from the test cases. Return ONLY the function name, nothing else.",
            context=""
        )
        
        # Step 2: Generate the initial implementation
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves this task:
            - Use the heap queue algorithm to find the n cheapest items from a given dataset.
            - Include ALL necessary import statements at the top.
            - Handle edge cases (empty dataset, n=0, n > len(dataset)).
            - Return ONLY the executable Python code, no explanations.
            """,
            context=""
        )
        
        # Step 3: Revise the code for completeness and correctness
        final_code = await self.revise(
            instruction=f"""
            Review the following code and make improvements:
            - Ensure all necessary imports are included.
            - Validate edge cases (empty dataset, n=0, n > len(dataset)).
            - Optimize the implementation if possible.
            - Return ONLY the corrected code, no explanations.
            """,
            context=initial_code
        )
        
        return final_code