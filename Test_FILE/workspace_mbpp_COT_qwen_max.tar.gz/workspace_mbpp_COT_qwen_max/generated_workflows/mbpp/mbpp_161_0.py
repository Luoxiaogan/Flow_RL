# Workflow ID: mbpp_161_0
# Benchmark: mbpp
# Data Indices: [190]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name from test cases
        func_name = await self.generate(
            instruction="""
            Extract the function name used in the test cases.
            Return ONLY the function name, nothing else.
            """,
            context=""
        )
        
        # Step 2: Generate the initial Python function code
        code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the following task:
            {self.problem_text}
            
            Requirements:
            1. Include ALL necessary import statements at the top of the code.
            2. Handle edge cases such as empty inputs, nested structures, and invalid data types.
            3. Ensure the function matches the expected behavior in the test cases.
            4. Return ONLY the executable Python code, no explanations or comments.
            """,
            context=""
        )
        
        # Step 3: Revise the code to ensure correctness and completeness
        final_code = await self.revise(
            instruction="""
            Check the provided code for the following issues and fix them:
            1. Missing or incorrect import statements.
            2. Failure to handle edge cases (e.g., empty inputs, nested structures).
            3. Logical errors or mismatches with the test cases.
            4. Non-Pythonic or inefficient code.
            Return ONLY the corrected Python code, no explanations or comments.
            """,
            context=code
        )
        
        # Step 4: Return the final Python code
        return final_code