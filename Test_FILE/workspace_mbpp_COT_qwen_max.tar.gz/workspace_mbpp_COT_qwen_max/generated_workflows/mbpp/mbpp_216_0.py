# Workflow ID: mbpp_216_0
# Benchmark: mbpp
# Data Indices: [323]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio

        # Step 1: Extract the function name from the test cases
        func_name = await self.generate(
            instruction="""
            Extract the function name from the test cases in the problem description.
            Return ONLY the function name, nothing else. Ensure it matches the test case signatures exactly.
            """,
            context=""
        )

        # Step 2: Generate the initial Python code for the function
        code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the task described in the problem.
            Requirements:
            1. Include ALL necessary import statements at the top of the code.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Ensure the function is efficient and follows Pythonic best practices.
            4. Return ONLY the executable Python code, with no explanations or additional text.
            """,
            context=""
        )

        # Step 3: Revise the generated code to ensure correctness and completeness
        final_code = await self.revise(
            instruction="""
            Review the provided code and make improvements where necessary.
            Focus on:
            1. Missing import statements.
            2. Edge case handling (e.g., empty inputs, None values, extreme values).
            3. Code readability and adherence to Pythonic conventions.
            4. Any logical errors or inefficiencies.
            Return ONLY the corrected and final version of the code.
            """,
            context=code
        )

        return final_code