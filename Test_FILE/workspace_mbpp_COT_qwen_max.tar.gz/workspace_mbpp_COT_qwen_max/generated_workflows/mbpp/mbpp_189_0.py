# Workflow ID: mbpp_189_0
# Benchmark: mbpp
# Data Indices: [178]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio

        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="""
            Extract the function name from the test cases in the problem description.
            Return ONLY the function name as plain text, without any additional explanation.
            """,
            context=""
        )
        func_name = func_name.strip()  # Remove any leading/trailing whitespace

        # Step 2: Generate the initial Python code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the task described in the problem.
            Requirements:
            1. Include ALL necessary import statements at the top of the code.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Ensure the function signature matches the test cases exactly.
            4. Return ONLY the executable Python code, without any explanations or comments outside the function.
            """,
            context=""
        )

        # Step 3: Revise the code for completeness and correctness
        final_code = await self.revise(
            instruction="""
            Review the provided code and make the following improvements:
            1. Ensure all necessary imports are included.
            2. Verify that edge cases are handled correctly.
            3. Optimize the code for performance if possible.
            4. Return ONLY the corrected and complete Python code.
            """,
            context=initial_code
        )

        # Step 4: Return the final code
        return final_code