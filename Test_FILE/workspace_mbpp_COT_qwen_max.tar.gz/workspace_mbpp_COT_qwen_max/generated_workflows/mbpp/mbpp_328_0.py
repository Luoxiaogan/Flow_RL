# Workflow ID: mbpp_328_0
# Benchmark: mbpp
# Data Indices: [312]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        import json  # For parsing JSON strings if needed
        import re    # For regex operations if needed
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases in the problem description. "
                        "Return ONLY the function name, nothing else.",
            context=""
        )
        
        # Step 2: Generate initial Python code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the problem described in the original prompt.
            Requirements:
            1. Include ALL necessary import statements at the top (e.g., import re, math, etc.).
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Ensure the function signature matches the test cases.
            4. Return ONLY the executable Python code, no explanations.
            """,
            context=""
        )
        
        # Step 3: Revise the code for completeness and correctness
        final_code = await self.revise(
            instruction=f"""
            Review the following Python code for the function '{func_name}':
            - Check for missing imports.
            - Ensure all edge cases are handled (e.g., empty inputs, None values).
            - Optimize for efficiency if possible.
            - Fix any syntax or logical errors.
            Return ONLY the corrected Python code, no explanations.
            """,
            context=initial_code
        )
        
        # Optional: Parallel approaches for complex problems
        # Uncomment this section if multiple solutions are needed
        """
        results = await asyncio.gather(
            self.generate(instruction="Approach 1...", context=""),
            self.generate(instruction="Approach 2...", context="")
        )
        final_code = await self.ensemble(
            instruction="Select the best solution or synthesize a hybrid approach.",
            contexts=results
        )
        """
        
        return final_code