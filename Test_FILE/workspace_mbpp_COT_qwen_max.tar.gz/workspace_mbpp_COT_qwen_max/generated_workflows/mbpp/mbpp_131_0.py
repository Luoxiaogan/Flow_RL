# Workflow ID: mbpp_131_0
# Benchmark: mbpp
# Data Indices: [224]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio

        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract only the function name from the test cases in the problem description. "
                        "Return ONLY the function name, nothing else.",
            context=""
        )

        # Step 2: Generate the initial implementation of the function
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the task described in the problem statement.
            Requirements:
            1. Include ALL necessary import statements at the top (if any).
            2. Handle edge cases such as empty inputs, invalid indices, or boundary conditions.
            3. Ensure the function is Pythonic and follows best practices.
            4. Return ONLY the executable Python code, no explanations.
            """,
            context=""
        )

        # Step 3: Revise the code to improve quality and handle missing details
        final_code = await self.revise(
            instruction=f"""
            Review the following code for the function '{func_name}' and make improvements:
            - Ensure all necessary imports are included.
            - Check for proper handling of edge cases (e.g., empty lists, invalid indices).
            - Optimize for readability and efficiency.
            - Return ONLY the corrected code, no explanations.
            """,
            context=initial_code
        )

        # Step 4: Return the final code
        return final_code