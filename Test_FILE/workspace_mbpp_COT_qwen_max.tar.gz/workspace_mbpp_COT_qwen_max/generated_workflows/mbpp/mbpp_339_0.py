# Workflow ID: mbpp_339_0
# Benchmark: mbpp
# Data Indices: [166]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        # Add imports here if needed (e.g., json, re)

        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="""
            Extract the function name from the test cases in the problem description.
            Return ONLY the function name as plain text, without any additional explanation.
            """,
            context=""
        )
        
        # Step 2: Generate the initial Python code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name.strip()}' that solves the problem described in the task.
            Requirements:
            1. Include ALL necessary import statements at the top of the function.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Ensure the function is efficient and follows Python best practices.
            4. Return ONLY the executable Python code, without any explanations or comments.
            """,
            context=""
        )
        
        # Step 3: Revise the code to improve quality and correctness
        final_code = await self.revise(
            instruction="""
            Review the provided Python code and make improvements where necessary.
            Focus on the following:
            1. Ensure all required imports are included.
            2. Improve readability and maintainability.
            3. Handle edge cases explicitly.
            4. Optimize performance if possible.
            Return ONLY the corrected Python code, without any explanations or comments.
            """,
            context=initial_code
        )
        
        # Step 4: Return the final code
        return final_code