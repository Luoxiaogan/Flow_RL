# Workflow ID: mbpp_367_0
# Benchmark: mbpp
# Data Indices: [142]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        import json  # For parsing JSON if needed

        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases. Return ONLY the function name, nothing else.",
            context=""
        )

        # Step 2: Generate initial Python code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves the task described in the problem statement.
            Requirements:
            1. Include ALL necessary import statements at the top.
            2. Handle edge cases such as empty inputs, None values, and boundary conditions.
            3. Ensure the function signature matches the test cases.
            4. Return ONLY the executable Python code, no explanations.
            """,
            context=""
        )

        # Step 3: Revise the code for completeness and correctness
        revised_code = await self.revise(
            instruction="""
            Review the provided code and make improvements:
            1. Check for missing import statements.
            2. Ensure all edge cases are handled.
            3. Optimize for efficiency if possible.
            4. Return ONLY the corrected Python code.
            """,
            context=initial_code
        )

        # Optional: Parallelize for robustness
        # Generate multiple code candidates and select the best one
        code_candidates = await asyncio.gather(
            self.generate(
                instruction=f"""
                Write a Python function named '{func_name}' that solves the task.
                Requirements:
                1. Include ALL necessary import statements.
                2. Handle edge cases thoroughly.
                3. Return ONLY the executable Python code.
                """,
                context=""
            ),
            self.generate(
                instruction=f"""
                Write a Python function named '{func_name}' that solves the task.
                Focus on optimizing for performance while maintaining correctness.
                Return ONLY the executable Python code.
                """,
                context=""
            )
        )

        # Ensemble to select the best candidate
        final_code = await self.ensemble(
            instruction="""
            Evaluate the provided code candidates and select the best one based on:
            1. Correctness (matches test cases).
            2. Completeness (handles all edge cases).
            3. Efficiency (optimized implementation).
            Return ONLY the selected Python code.
            """,
            contexts=code_candidates
        )

        # Return the final code
        return final_code