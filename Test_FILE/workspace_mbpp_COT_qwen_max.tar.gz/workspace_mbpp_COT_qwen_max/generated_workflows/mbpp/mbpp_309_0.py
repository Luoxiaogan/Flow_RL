# Workflow ID: mbpp_309_0
# Benchmark: mbpp
# Data Indices: [17]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases. "
                        "Return ONLY the function name, nothing else.",
            context=""
        )
        
        # Step 2: Generate the Python function code
        code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves this task.
            Requirements:
            1. Include ALL necessary import statements at the top (e.g., import math, from functools import reduce).
            2. Handle edge cases such as empty inputs, division by zero, or invalid data types.
            3. Ensure the function adheres to Pythonic best practices.
            4. Return ONLY the executable Python code, no explanations or comments.
            """,
            context=""
        )
        
        # Step 3: Revise the generated code
        final_code = await self.revise(
            instruction="Review the following code for correctness and completeness. "
                        "Fix any issues related to missing imports, edge cases, or syntax errors. "
                        "Ensure the function passes the provided test cases. "
                        "Return ONLY the corrected code.",
            context=code
        )
        
        return final_code