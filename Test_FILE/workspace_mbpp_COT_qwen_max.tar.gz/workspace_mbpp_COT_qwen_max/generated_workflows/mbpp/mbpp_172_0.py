# Workflow ID: mbpp_172_0
# Benchmark: mbpp
# Data Indices: [233]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio

        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases or problem description. "
                        "Return ONLY the function name, nothing else.",
            context=""
        )

        # Step 2: Generate the initial Python code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves this task.
            Requirements:
            1. Include ALL necessary import statements at the top.
            2. Handle edge cases (empty inputs, None, boundaries).
            3. Follow Python best practices and idioms.
            4. Return ONLY the executable Python code, no explanations.
            """,
            context=""
        )

        # Step 3: Revise the code for robustness and correctness
        final_code = await self.revise(
            instruction="Critique and improve the following code. "
                        "Focus on missing imports, edge case handling, efficiency, and Pythonic style. "
                        "Return ONLY the corrected code.",
            context=initial_code
        )

        # Optional: Parallel generation and ensemble selection for complex problems
        # Uncomment and adapt if needed
        """
        results = await asyncio.gather(
            self.generate(instruction="Approach 1...", context=""),
            self.generate(instruction="Approach 2...", context="")
        )
        final_code = await self.ensemble(
            instruction="Select the best solution based on correctness, efficiency, and simplicity. "
                        "Return ONLY the selected code.",
            contexts=results
        )
        """

        return final_code