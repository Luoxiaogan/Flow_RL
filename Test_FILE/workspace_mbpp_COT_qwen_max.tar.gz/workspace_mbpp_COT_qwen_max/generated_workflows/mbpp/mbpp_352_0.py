# Workflow ID: mbpp_352_0
# Benchmark: mbpp
# Data Indices: [144]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio

        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases. Return ONLY the function name, nothing else.",
            context=""
        )
        func_name = func_name.strip()  # Remove any extra whitespace

        # Step 2: Generate the initial Python code
        code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves this task.
            Requirements:
            1. Include ALL necessary import statements at the top.
            2. Handle edge cases (e.g., empty inputs, invalid ranges, boundary values).
            3. Ensure the function matches the provided test cases.
            4. Return ONLY the executable Python code, no explanations.
            """,
            context=""
        )

        # Step 3: Revise the code for correctness and robustness
        final_code = await self.revise(
            instruction="""
            Review the provided code and make necessary improvements:
            1. Check for missing imports and add them if needed.
            2. Ensure all edge cases are handled properly.
            3. Optimize for readability and efficiency without altering functionality.
            4. Return ONLY the corrected Python code, no explanations.
            """,
            context=code
        )

        # Step 4: Return the final Python code
        return final_code