# Workflow ID: mbpp_4_0
# Benchmark: mbpp
# Data Indices: [31]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio

        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases. "
                        "Return ONLY the function name, nothing else.",
            context=""
        )
        func_name = func_name.strip()  # Remove any leading/trailing whitespace

        # Step 2: Generate the initial code
        initial_code = await self.generate(
            instruction=f"""
            Write a Python function named '{func_name}' that solves this task.
            Requirements:
            1. Include ALL necessary import statements at the top.
            2. Handle edge cases such as empty inputs, None, or boundary values.
            3. Ensure the function signature matches the test cases.
            4. Return ONLY the executable Python code, no explanations.
            """,
            context=""
        )

        # Step 3: Revise the code for correctness and completeness
        final_code = await self.revise(
            instruction="Check for missing imports and edge cases. "
                        "Fix any syntax or logical errors. "
                        "Return only the corrected code.",
            context=initial_code
        )

        # Step 4: Return the finalized code
        return final_code