# Workflow ID: mbpp_164_0
# Benchmark: mbpp
# Data Indices: [113]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio

        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract the function name from the test cases. "
                        "Return ONLY the function name, nothing else.",
            context=""
        )
        func_name = func_name.strip()  # Remove any leading/trailing whitespace

        # Step 2: Generate the initial Python function code
        code = await self.generate(
            instruction=f"Write a Python function named '{func_name}' that solves this task. "
                        "Requirements:\n"
                        "1. Include ALL necessary import statements at the top.\n"
                        "2. Handle edge cases such as empty inputs, None values, or boundary conditions.\n"
                        "3. Return ONLY the executable Python code, no explanations or additional text.",
            context=""
        )

        # Step 3: Revise the code for completeness and correctness
        final_code = await self.revise(
            instruction="Check the following code for issues:\n"
                        "1. Ensure all required imports are included.\n"
                        "2. Verify that edge cases are handled properly.\n"
                        "3. Fix any syntax errors or logical mistakes.\n"
                        "Return ONLY the corrected Python code.",
            context=code
        )

        return final_code