# Workflow ID: hotpotqa_196_0
# Benchmark: hotpotqa
# Data Indices: [299]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Identify key entities and relationships
        entity_extraction = await self.generate(
            instruction="Extract all key entities (e.g., names of hotels, locations) and their relationships from the question and context documents.",
            context=self.problem_text
        )

        # Step 2: Summarize document relevance (parallel execution)
        summaries = await asyncio.gather(
            *[self.summarize(
                instruction=f"Determine if this document contains information relevant to the question. Focus on entities and relationships mentioned in the question.",
                context=doc
            ) for doc in self.problem_text.split("Document ")[1:]]  # Split documents for parallel processing
        )
        relevant_docs = [f"Document {i+1}: {summary}" for i, summary in enumerate(summaries) if "relevant" in summary.lower()]

        # Step 3: Refine entity resolution
        refined_entities = await self.revise(
            instruction=f"Refine the extracted entities and their relationships based on the following summaries: {relevant_docs}. Ensure entities are correctly matched across documents.",
            context=entity_extraction
        )

        # Step 4: Construct reasoning chain
        reasoning_chain = await self.generate(
            instruction=f"Using the refined entities and relationships: {refined_entities}, construct a logical chain of reasoning to answer the question. Explicitly connect entities and their relationships.",
            context=self.problem_text
        )

        # Step 5: Extract final answer using Ensemble
        candidate_answers = await asyncio.gather(
            self.generate(
                instruction="Extract the final answer directly from the reasoning chain.",
                context=reasoning_chain
            ),
            self.generate(
                instruction="Rephrase the final answer in a concise format.",
                context=reasoning_chain
            )
        )
        final_answer = await self.ensemble(
            instruction="Select the most precise and accurate answer from the candidates.",
            contexts=candidate_answers
        )

        return final_answer