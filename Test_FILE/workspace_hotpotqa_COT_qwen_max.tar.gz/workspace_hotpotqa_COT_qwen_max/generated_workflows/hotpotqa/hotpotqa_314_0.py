# Workflow ID: hotpotqa_314_0
# Benchmark: hotpotqa
# Data Indices: [318]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Identify relevant documents
        document_selection_instruction = (
            "Identify which documents contain information about Anna Banks, Mad Hatter Entertainment, "
            "and Cressida Cowell's 'How to Train Your Dragon' series. Focus on entities and their relationships."
        )
        relevant_documents = await self.generate(instruction=document_selection_instruction, context=self.problem_text)

        # Step 2: Extract key facts in parallel
        fact_extraction_instructions = {
            "anna_banks": (
                f"Extract all information about Anna Banks and her 'Syrena Legacy' series from the following: {relevant_documents}. "
                "Focus on her connection to Mad Hatter Entertainment."
            ),
            "mad_hatter": (
                f"Extract details about Mad Hatter Entertainment's involvement with the 'How to Train Your Dragon' franchise from the following: {relevant_documents}."
            ),
            "cressida_cowell": (
                f"Find how many children's books are in Cressida Cowell's 'How to Train Your Dragon' series from the following: {relevant_documents}."
            ),
        }

        # Parallel extraction of facts
        results = await asyncio.gather(
            self.generate(instruction=fact_extraction_instructions["anna_banks"], context=self.problem_text),
            self.generate(instruction=fact_extraction_instructions["mad_hatter"], context=self.problem_text),
            self.generate(instruction=fact_extraction_instructions["cressida_cowell"], context=self.problem_text),
        )
        anna_banks_info, mad_hatter_info, cressida_cowell_info = results

        # Step 3: Refine extracted facts
        refinement_instruction = (
            "Refine the extracted facts to ensure accuracy and logical consistency. "
            "Focus on connecting Anna Banks to Mad Hatter Entertainment and linking Mad Hatter Entertainment to Cressida Cowell's series."
        )
        refined_facts = await self.revise(instruction=refinement_instruction, context="\n".join(results))

        # Step 4: Synthesize the reasoning chain and final answer
        synthesis_instruction = (
            "Combine the refined facts into a coherent reasoning chain. "
            "Ensure the final answer specifies the number of children's books in Cressida Cowell's 'How to Train Your Dragon' series."
        )
        final_answer = await self.ensemble(
            instruction=synthesis_instruction,
            contexts=[refined_facts, anna_banks_info, mad_hatter_info, cressida_cowell_info],
        )

        return final_answer