# Workflow ID: hotpotqa_248_0
# Benchmark: hotpotqa
# Data Indices: [382]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract key entities and understand the question
        question_analysis = await self.generate(
            instruction="Analyze the question and identify key entities or concepts. "
                        "Focus on entities that are likely to appear in the context documents. "
                        "Return the identified entities as a comma-separated list.",
            context=self.problem_text
        )

        # Step 2: Filter relevant documents based on key entities
        relevant_docs = await asyncio.gather(
            *[self.generate(
                instruction=f"Identify if this document contains information about {question_analysis}. "
                            "If relevant, summarize the key points related to the entities. "
                            "If not relevant, return 'Irrelevant'.",
                context=doc
            ) for doc in self.config['context_documents']]
        )
        relevant_docs = [doc for doc in relevant_docs if doc != "Irrelevant"]

        # Step 3: Resolve entities and find connections across documents
        entity_connections = await self.generate(
            instruction=f"Given these summaries of relevant documents: {relevant_docs}, "
                        "identify how the key entities are connected across the documents. "
                        "Construct a reasoning chain that links the entities to answer the question.",
            context=self.problem_text
        )

        # Step 4: Refine the reasoning chain for clarity and correctness
        refined_chain = await self.revise(
            instruction="Improve the clarity and logical flow of this reasoning chain. "
                        "Ensure all steps are justified by evidence from the documents.",
            context=entity_connections
        )

        # Step 5: Extract the final answer span
        final_answer = await self.generate(
            instruction=f"Based on the refined reasoning chain: {refined_chain}, "
                        "extract the precise answer span from the relevant documents. "
                        "Ensure the answer directly addresses the question.",
            context="\n".join(relevant_docs)
        )

        return final_answer