# Workflow ID: hotpotqa_152_0
# Benchmark: hotpotqa
# Data Indices: [37]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Identify key entities in the question
        entity_extraction_instruction = (
            "Identify the key entities mentioned in the question. "
            "Focus on proper nouns, such as names of people, places, or events. "
            "Return the entities as a comma-separated list."
        )
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Extract relevant contexts from documents for the identified entities
        context_extraction_instruction = (
            f"Extract all sentences from the provided documents that mention the following entities: {entities}. "
            "Include any alternative names or aliases used for these entities. "
            "Return the extracted sentences as a single block of text."
        )
        relevant_contexts = await self.generate(instruction=context_extraction_instruction, context=self.problem_text)

        # Step 3: Classify the reasoning type and build the reasoning chain
        reasoning_instruction = (
            "Analyze the question and determine the type of reasoning required. "
            "If the question involves connecting information through shared entities, use bridge reasoning. "
            "If it involves comparing properties, use comparison reasoning. "
            "If it involves combining multiple facts, use compositional reasoning. "
            "Based on the extracted contexts, build a reasoning chain that connects the entities and answers the question. "
            "Return the reasoning chain as a concise explanation."
        )
        reasoning_chain = await self.generate(instruction=reasoning_instruction, context=relevant_contexts)

        # Step 4: Synthesize the final answer
        synthesis_instruction = (
            "Using the reasoning chain, synthesize a concise answer to the question. "
            "Ensure the answer directly addresses the question and includes all necessary details. "
            "If the question asks 'why,' provide a clear explanation of the cause or reason."
        )
        answer = await self.generate(instruction=synthesis_instruction, context=reasoning_chain)

        # Optional Step 5: Refine the answer for clarity and accuracy
        refinement_instruction = (
            "Review the provided answer and ensure it is clear, accurate, and directly addresses the question. "
            "Make any necessary refinements to improve the quality of the response."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=answer)

        return refined_answer