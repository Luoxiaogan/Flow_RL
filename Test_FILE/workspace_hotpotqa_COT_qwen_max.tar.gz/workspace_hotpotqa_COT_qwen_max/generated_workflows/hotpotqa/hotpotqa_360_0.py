# Workflow ID: hotpotqa_360_0
# Benchmark: hotpotqa
# Data Indices: [332]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract entities and their contexts from all documents
        entity_extraction_instruction = """
        Extract all key entities mentioned in the context documents along with their descriptions.
        Focus on entities that are relevant to the question and could potentially serve as bridge entities.
        Include details such as the type of entity, its properties, and any relationships it has with other entities.
        """
        entity_extraction_task = self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Identify the bridge entity
        bridge_entity_instruction = """
        Identify the bridge entity that connects the question to the relevant documents.
        A bridge entity is typically mentioned in both the question and one or more context documents.
        Explain why this entity is significant for answering the question.
        """
        bridge_entity_task = self.generate(instruction=bridge_entity_instruction, context=self.problem_text)

        # Execute Steps 1 and 2 in parallel
        entity_extraction, bridge_entity = await asyncio.gather(entity_extraction_task, bridge_entity_task)

        # Step 3: Construct the reasoning chain
        reasoning_chain_instruction = f"""
        Using the extracted entities and the identified bridge entity, construct a reasoning chain that answers the question.
        The reasoning chain should explicitly connect the bridge entity to other relevant facts or entities across documents.
        Ensure the chain is logical and leads to a clear conclusion.
        Bridge Entity: {bridge_entity}
        Extracted Entities: {entity_extraction}
        """
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 4: Synthesize the answer
        answer_synthesis_instruction = """
        Condense the reasoning chain into a concise answer that directly addresses the question.
        The answer should be specific, factual, and derived entirely from the reasoning chain.
        """
        answer = await self.summarize(instruction=answer_synthesis_instruction, context=reasoning_chain)

        # Step 5: Validate and refine the answer
        refinement_instruction = f"""
        Review the synthesized answer and ensure it accurately reflects the reasoning chain.
        Cross-reference the answer with the original documents to verify its correctness.
        If necessary, refine the answer to improve clarity or accuracy.
        Reasoning Chain: {reasoning_chain}
        Current Answer: {answer}
        """
        final_answer = await self.revise(instruction=refinement_instruction, context=answer)

        return final_answer