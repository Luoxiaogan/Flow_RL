# Workflow ID: hotpotqa_254_0
# Benchmark: hotpotqa
# Data Indices: [75]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract Key Entities from Question
        entity_extraction_instruction = """
        Extract all key entities (e.g., names, organizations, locations) mentioned in the question. 
        Focus on identifying entities that are likely to appear in the provided documents. 
        Format the output as a JSON list of entities.
        """
        question_entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Extract Entities from Each Document
        document_entity_tasks = []
        for i in range(10):  # Assuming 10 documents as per the example
            doc_instruction = f"""
            Extract all key entities (e.g., names, organizations, locations) from Document {i+1}. 
            Focus on entities that match or relate to the following entities extracted from the question: {question_entities}.
            Format the output as a JSON list of entities.
            """
            document_entity_tasks.append(self.generate(instruction=doc_instruction, context=self.problem_text))
        
        document_entities = await asyncio.gather(*document_entity_tasks)

        # Step 3: Resolve Entities Across Documents
        resolution_instruction = f"""
        Compare the entities extracted from the question and the entities extracted from the documents. 
        Identify potential matches or references to the same entity across different documents. 
        Resolve any ambiguities and provide a unified list of resolved entities.
        Format the output as a JSON object where keys are resolved entities and values are their occurrences.
        """
        resolved_entities = await self.generate(instruction=resolution_instruction, context="\n".join(document_entities))

        # Step 4: Build Reasoning Chain
        reasoning_instruction = f"""
        Using the resolved entities, construct a reasoning chain that connects the entities mentioned in the question to the final answer. 
        Identify any "bridge entities" or shared concepts that link multiple documents. 
        Provide a step-by-step explanation of how the entities are connected.
        """
        reasoning_chain = await self.generate(instruction=reasoning_instruction, context=resolved_entities)

        # Step 5: Extract Final Answer
        answer_extraction_instruction = f"""
        Based on the reasoning chain, extract the precise answer span from the relevant documents. 
        Ensure the answer directly addresses the question and is supported by the provided context.
        """
        final_answer = await self.summarize(instruction=answer_extraction_instruction, context=reasoning_chain)

        # Step 6: Validate and Refine the Final Answer
        refinement_instruction = f"""
        Review the extracted answer for accuracy and completeness. 
        Ensure it aligns with the reasoning chain and resolves any ambiguities. 
        Refine the answer if necessary.
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        return refined_answer