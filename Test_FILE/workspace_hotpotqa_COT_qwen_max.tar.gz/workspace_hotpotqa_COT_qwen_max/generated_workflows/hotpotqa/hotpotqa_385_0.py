# Workflow ID: hotpotqa_385_0
# Benchmark: hotpotqa
# Data Indices: [323]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify relevant documents
        identify_instruction = (
            "Identify all documents that mention either 'The Mountain Goats' or 'Feeder'. "
            "Focus on documents that provide information about the location or origin of these bands. "
            "Return a list of document IDs or names that are relevant."
        )
        relevant_documents = await self.generate(instruction=identify_instruction, context=self.problem_text)

        # Step 2: Extract key information (location) for each band
        extract_instruction_template = (
            "From the provided document, extract information about the location or origin of {band}. "
            "If the document mentions where the band is based or originated, summarize that information concisely. "
            "If no such information is found, return 'Not Found'."
        )

        # Parallel extraction for both bands
        mountain_goats_extraction = self.generate(
            instruction=extract_instruction_template.format(band="The Mountain Goats"),
            context=relevant_documents
        )
        feeder_extraction = self.generate(
            instruction=extract_instruction_template.format(band="Feeder"),
            context=relevant_documents
        )

        # Gather results
        mountain_goats_location, feeder_location = await asyncio.gather(mountain_goats_extraction, feeder_extraction)

        # Step 3: Compare locations and determine which band is based in the US
        compare_instruction = (
            "Compare the locations of 'The Mountain Goats' and 'Feeder'. "
            f"The Mountain Goats is based in: {mountain_goats_location}. "
            f"Feeder is based in: {feeder_location}. "
            "Determine which band is based in the United States and provide the answer as a concise statement."
        )
        final_answer = await self.ensemble(instruction=compare_instruction, contexts=[mountain_goats_location, feeder_location])

        return final_answer