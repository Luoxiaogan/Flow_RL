# Workflow ID: hotpotqa_195_0
# Benchmark: hotpotqa
# Data Indices: [146]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Identify relevant documents
        relevance_instruction = (
            "Analyze the provided question and determine which documents contain "
            "information relevant to answering it. Provide a list of document indices."
        )
        relevant_docs = await self.generate(instruction=relevance_instruction, context=self.problem_text)

        # Step 2: Extract entities and facts from relevant documents
        async def extract_from_doc(doc_index):
            extraction_instruction = (
                f"Extract all key entities, facts, and relationships from Document {doc_index}. "
                "Focus on information that could help answer the question."
            )
            return await self.generate(instruction=extraction_instruction, context=self.problem_text)

        doc_indices = [int(idx) for idx in relevant_docs.split() if idx.isdigit()]
        extraction_tasks = [extract_from_doc(idx) for idx in doc_indices]
        extracted_facts = await asyncio.gather(*extraction_tasks)

        # Step 3: Build reasoning chain using ensemble
        reasoning_instruction = (
            "Synthesize the provided facts from multiple documents to construct a reasoning chain. "
            "Identify bridge entities or shared information that connects the documents. "
            "Ensure the reasoning chain logically leads to the answer."
        )
        reasoning_chain = await self.ensemble(instruction=reasoning_instruction, contexts=extracted_facts)

        # Step 4: Refine and finalize the answer
        refine_instruction = (
            "Refine the reasoning chain into a concise and accurate answer to the question. "
            "Ensure the answer is supported by the extracted facts and reasoning chain."
        )
        final_answer = await self.revise(instruction=refine_instruction, context=reasoning_chain)

        return final_answer