# Workflow ID: hotpotqa_33_0
# Benchmark: hotpotqa
# Data Indices: [132]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Analyze the question to identify entities and reasoning type
        question_analysis = await self.generate(
            instruction="""Analyze the question carefully to identify:
            - The main entity or topic being asked about
            - Any secondary entities or properties mentioned
            - The type of reasoning required (bridge, comparison, compositional, etc.)
            Provide a structured output with clear labels for each component.""",
            context=self.problem_text
        )

        # Step 2: Score documents for relevance
        document_scores = await self.generate(
            instruction=f"""Given the following analysis of the question:
            {question_analysis}
            
            Evaluate each document in the context for relevance to the identified entities and reasoning type. 
            Assign a relevance score to each document and provide a brief justification for the score.
            Format the output as a list of documents with their scores and justifications.""",
            context=self.problem_text
        )

        # Step 3: Extract supporting facts and build reasoning chains
        fact_extraction_tasks = []
        for doc in ["Document 1", "Document 2", "Document 3", "Document 4", "Document 5", 
                    "Document 6", "Document 7", "Document 8", "Document 9", "Document 10"]:
            task = self.generate(
                instruction=f"""Extract all relevant facts from the following document that pertain to:
                - The main entity or topic identified in the question analysis
                - Any secondary entities or properties
                Ensure the extracted facts are concise and directly related to the question.
                Document: {doc}""",
                context=self.problem_text
            )
            fact_extraction_tasks.append(task)

        extracted_facts = await asyncio.gather(*fact_extraction_tasks)

        # Step 4: Synthesize the final answer using Ensemble
        reasoning_chain = await self.ensemble(
            instruction=f"""Based on the following extracted facts from multiple documents:
            {extracted_facts}
            
            Build a logical reasoning chain to connect the facts and derive the answer to the question.
            Ensure the reasoning chain is explicit and traceable back to the source documents.
            Provide the final answer as a concise statement.""",
            contexts=extracted_facts
        )

        # Step 5: Validate and refine the answer
        refined_answer = await self.revise(
            instruction=f"""Review the following reasoning chain and answer:
            {reasoning_chain}
            
            Check for logical consistency, factual accuracy, and alignment with the question.
            Refine the answer if necessary, ensuring it is precise and well-supported by the context documents.""",
            context=self.problem_text
        )

        return refined_answer