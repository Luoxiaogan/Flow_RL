# Workflow ID: hotpotqa_190_0
# Benchmark: hotpotqa
# Data Indices: [98]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Analyze each document for relevance
        documents = [
            "Document 1: Garth Brooks (album)...",
            "Document 2: Making Memories of Us...",
            "Document 3: Some People Change (song)...",
            "Document 4: Not Counting You...",
            "Document 5: Love Me Like You Used To (song)...",
            "Document 6: I Won't Need You Anymore (Always and Forever)...",
            "Document 7: He's Mine (Billy Ray Cyrus song)...",
            "Document 8: Sugar-Foot Rag...",
            "Document 9: Say Forever You'll Be Mine (song)...",
            "Document 10: The Heart (song)..."
        ]

        relevance_tasks = [
            self.generate(
                instruction=f"Determine if this document contains information about the song 'Not Counting You' and its associated artist. Focus on explicit mentions of the song title and any related artists. Provide a brief summary of relevant information if found.",
                context=doc
            ) for doc in documents
        ]
        relevance_results = await asyncio.gather(*relevance_tasks)

        # Step 2: Select the most relevant documents
        selected_documents = await self.ensemble(
            instruction="Select the documents that provide explicit information about the song 'Not Counting You' and its associated artist. Prioritize documents with direct mentions of the song and artist.",
            contexts=relevance_results
        )

        # Step 3: Extract and resolve entities across selected documents
        entity_extraction = await self.generate(
            instruction=f"From the following selected documents, extract all mentions of the song 'Not Counting You' and its associated artist. Resolve any ambiguities by matching entity names across documents. Provide a concise list of entities.\n\nSelected Documents:\n{selected_documents}",
            context=self.problem_text
        )

        # Step 4: Construct the reasoning chain
        reasoning_chain = await self.generate(
            instruction=f"Based on the extracted entities, construct a reasoning chain that connects the song 'Not Counting You' to its writer/artist. Ensure the chain is logically consistent and explicitly references the source documents.\n\nEntities:\n{entity_extraction}",
            context=self.problem_text
        )

        # Step 5: Refine the reasoning chain
        refined_reasoning = await self.revise(
            instruction="Refine the reasoning chain to ensure clarity, logical consistency, and accuracy. Remove any redundant or irrelevant information.",
            context=reasoning_chain
        )

        # Step 6: Synthesize the final answer
        final_answer = await self.ensemble(
            instruction="Synthesize the final answer from the refined reasoning chain. Ensure the answer is precise and directly addresses the question: 'Not Counting You, is a song written, and recorded by which American country music artist?'.",
            contexts=[refined_reasoning]
        )

        return final_answer