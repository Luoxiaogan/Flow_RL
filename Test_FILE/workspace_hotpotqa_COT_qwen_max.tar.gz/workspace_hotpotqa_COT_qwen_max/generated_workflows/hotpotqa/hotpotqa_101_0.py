# Workflow ID: hotpotqa_101_0
# Benchmark: hotpotqa
# Data Indices: [162]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key entities and relevant contexts
        entity_extraction_instruction = """
        Identify all key entities mentioned in the question and locate relevant sentences or paragraphs from the provided documents that mention these entities. 
        Ensure to include all potential bridge entities that could connect the documents.
        """
        extracted_contexts = await self.generate(
            instruction=entity_extraction_instruction,
            context=self.problem_text
        )

        # Step 2: Identify the bridge entity using Ensemble
        bridge_entity_instruction = """
        Compare the provided contexts to identify the bridge entity that connects the documents. 
        The bridge entity should logically link the information required to answer the question.
        """
        bridge_entity = await self.ensemble(
            instruction=bridge_entity_instruction,
            contexts=[extracted_contexts]
        )

        # Step 3: Construct the reasoning chain and extract the answer
        reasoning_chain_instruction = f"""
        Using the identified bridge entity: {bridge_entity}, construct a reasoning chain to answer the question. 
        Locate the specific document or sentence that contains the final piece of information needed to answer the question.
        """
        reasoning_chain = await self.generate(
            instruction=reasoning_chain_instruction,
            context=self.problem_text
        )

        # Step 4: Refine the answer for precision
        refinement_instruction = """
        Critique the provided reasoning chain and extract the most precise answer to the question. 
        Ensure the answer is formatted as a short text span, entity name, or brief factual response.
        """
        refined_answer = await self.revise(
            instruction=refinement_instruction,
            context=reasoning_chain
        )

        return refined_answer