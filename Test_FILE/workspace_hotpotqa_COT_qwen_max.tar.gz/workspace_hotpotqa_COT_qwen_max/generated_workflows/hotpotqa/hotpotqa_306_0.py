# Workflow ID: hotpotqa_306_0
# Benchmark: hotpotqa
# Data Indices: [334]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Identify entities mentioned in the question
        entity_extraction_instruction = (
            "Identify the entities mentioned in the question. "
            "Focus on proper nouns such as names of people, organizations, or locations. "
            "Return the entities as a comma-separated list."
        )
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Extract relevant documents and facts for each entity
        async def extract_facts_for_entity(entity):
            fact_extraction_instruction = (
                f"Find all documents that mention the entity '{entity}'. "
                "From these documents, extract facts related to the entity's origin, nationality, or location. "
                "Summarize the findings in a concise paragraph."
            )
            return await self.generate(instruction=fact_extraction_instruction, context=self.problem_text)

        # Execute fact extraction for all entities in parallel
        entity_list = [entity.strip() for entity in entities.split(",")]
        fact_extraction_tasks = [extract_facts_for_entity(entity) for entity in entity_list]
        extracted_facts = await asyncio.gather(*fact_extraction_tasks)

        # Step 3: Compare the extracted facts and synthesize the answer
        comparison_instruction = (
            "Compare the extracted facts about the entities. "
            "Determine whether the properties of the entities match the question's criteria. "
            "Provide a concise answer to the question based on the comparison."
        )
        answer = await self.ensemble(instruction=comparison_instruction, contexts=extracted_facts)

        # Step 4: Refine the answer for clarity and precision
        refinement_instruction = (
            "Refine the answer to ensure it is clear, concise, and directly addresses the question. "
            "Remove any unnecessary details while retaining the key information."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=answer)

        return refined_answer