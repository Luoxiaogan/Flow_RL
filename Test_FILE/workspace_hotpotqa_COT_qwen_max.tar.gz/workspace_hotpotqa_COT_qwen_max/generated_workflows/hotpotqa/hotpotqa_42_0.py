# Workflow ID: hotpotqa_42_0
# Benchmark: hotpotqa
# Data Indices: [232]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Parse the question to identify key entities and relationships
        question_analysis = await self.generate(
            instruction="Analyze the question to identify key entities and their relationships. "
                        "Output the entities and their roles in JSON format.",
            context=self.problem_text
        )

        # Step 2: Identify relevant documents based on the extracted entities
        document_selection = await self.generate(
            instruction=f"Based on the identified entities: {question_analysis}, "
                        "determine which documents are relevant to answering the question. "
                        "Output the list of relevant document indices.",
            context=self.problem_text
        )

        # Step 3: Extract bridge entities and build reasoning chains
        bridge_entity_extraction = await self.generate(
            instruction=f"From the relevant documents ({document_selection}), "
                        "identify any 'bridge entities' that connect the key entities in the question. "
                        "Output the bridge entity and its role in the reasoning chain.",
            context=self.problem_text
        )

        # Step 4: Extract specific facts related to the bridge entity
        fact_extraction = await self.generate(
            instruction=f"Extract specific facts about the bridge entity: {bridge_entity_extraction}. "
                        "Focus on facts that help answer the question. Output the facts in a structured format.",
            context=self.problem_text
        )

        # Step 5: Synthesize the answer from the extracted facts
        answer_synthesis = await self.summarize(
            instruction=f"Using the extracted facts: {fact_extraction}, "
                        "synthesize a concise answer to the question. Ensure the answer is precise and directly addresses the question.",
            context=self.problem_text
        )

        return answer_synthesis