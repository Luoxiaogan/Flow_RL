# Workflow ID: hotpotqa_353_0
# Benchmark: hotpotqa
# Data Indices: [169]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify relevant documents for each entity
        entity_documents_instruction = (
            "Identify all documents that mention the given entity. "
            "Provide a list of document numbers and brief summaries of their content relevant to the entity."
        )
        patrick_docs = await self.generate(
            instruction=f"{entity_documents_instruction} Focus on the entity 'Patrick Baudry'.",
            context=self.problem_text
        )
        frank_docs = await self.generate(
            instruction=f"{entity_documents_instruction} Focus on the entity 'Frank De Winne'.",
            context=self.problem_text
        )

        # Step 2: Extract key facts about each entity
        fact_extraction_instruction = (
            "Extract key facts about the given entity from the provided documents. "
            "Focus on their role as an ESA astronaut and any leadership positions they held, "
            "such as commanding a space mission. Provide the facts in a structured format."
        )
        patrick_facts = await self.generate(
            instruction=f"{fact_extraction_instruction} Focus on the entity 'Patrick Baudry'.",
            context=patrick_docs
        )
        frank_facts = await self.generate(
            instruction=f"{fact_extraction_instruction} Focus on the entity 'Frank De Winne'.",
            context=frank_docs
        )

        # Step 3: Parallel reasoning to determine "first to command"
        reasoning_instruction = (
            "Analyze the provided facts to determine whether the given entity was the first "
            "European Space Agency astronaut to command a space mission. "
            "Construct a reasoning chain and provide a clear conclusion."
        )
        patrick_reasoning, frank_reasoning = await asyncio.gather(
            self.generate(instruction=f"{reasoning_instruction} Focus on the entity 'Patrick Baudry'.", context=patrick_facts),
            self.generate(instruction=f"{reasoning_instruction} Focus on the entity 'Frank De Winne'.", context=frank_facts)
        )

        # Step 4: Compare and decide
        comparison_instruction = (
            "Compare the reasoning chains for both entities and determine which one was the first "
            "European Space Agency astronaut to command a space mission. Provide a clear decision."
        )
        decision = await self.ensemble(
            instruction=comparison_instruction,
            contexts=[patrick_reasoning, frank_reasoning]
        )

        # Step 5: Refine the final answer
        refinement_instruction = (
            "Refine the provided decision into a concise, well-formatted answer. "
            "Ensure the response directly answers the question and includes supporting evidence."
        )
        final_answer = await self.revise(
            instruction=refinement_instruction,
            context=decision
        )

        return final_answer