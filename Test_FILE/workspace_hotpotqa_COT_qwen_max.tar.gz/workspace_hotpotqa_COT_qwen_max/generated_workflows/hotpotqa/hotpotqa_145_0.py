# Workflow ID: hotpotqa_145_0
# Benchmark: hotpotqa
# Data Indices: [163]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Identify entities and select relevant documents
        entity_identification_instruction = """
        Identify the entities mentioned in the question. These entities are typically names of people, 
        organizations, or other specific nouns. Return the entities as a comma-separated list.
        """
        entities = await self.generate(instruction=entity_identification_instruction, context=self.problem_text)

        # Split entities into a list
        entity_list = [entity.strip() for entity in entities.split(",")]

        # Parallel document selection for each entity
        async def select_documents_for_entity(entity):
            document_selection_instruction = f"""
            Given the entity "{entity}", identify which documents in the provided context contain 
            information about this entity. Return the document numbers or titles as a comma-separated list.
            """
            return await self.generate(instruction=document_selection_instruction, context=self.problem_text)

        document_selection_tasks = [select_documents_for_entity(entity) for entity in entity_list]
        document_selection_results = await asyncio.gather(*document_selection_tasks)

        # Create a mapping of entities to their relevant documents
        entity_to_documents = dict(zip(entity_list, document_selection_results))

        # Step 2: Extract relevant information for each entity
        async def extract_information_for_entity(entity, documents):
            extraction_instruction = f"""
            For the entity "{entity}", extract all relevant information from the following documents: {documents}. 
            Focus on facts that indicate whether the entity is still active or currently performing. 
            Return the extracted information as a concise summary.
            """
            return await self.generate(instruction=extraction_instruction, context=self.problem_text)

        extraction_tasks = [
            extract_information_for_entity(entity, docs) for entity, docs in entity_to_documents.items()
        ]
        extraction_results = await asyncio.gather(*extraction_tasks)

        # Step 3: Summarize extracted information
        summaries = [
            await self.summarize(
                instruction=f"Summarize the key facts about {entity} from the following information: {info}",
                context=info
            )
            for entity, info in zip(entity_list, extraction_results)
        ]

        # Step 4: Ensemble comparison to determine the answer
        ensemble_instruction = """
        Compare the summaries of the entities provided in the contexts. Determine which entity satisfies 
        the condition specified in the question (e.g., "is still playing together"). If neither entity 
        satisfies the condition, state that explicitly. Provide a clear and concise answer.
        """
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=summaries)

        # Step 5: Revise the final answer for clarity and correctness
        revision_instruction = """
        Review the provided answer and ensure it is clear, concise, and directly addresses the question. 
        Correct any ambiguities or errors.
        """
        polished_answer = await self.revise(instruction=revision_instruction, context=final_answer)

        return polished_answer