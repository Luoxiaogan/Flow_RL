# Workflow ID: hotpotqa_387_0
# Benchmark: hotpotqa
# Data Indices: [350]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Analyze the question to identify entities and reasoning type
        question_analysis = await self.generate(
            instruction="Analyze the question to determine the type of reasoning required (e.g., bridge, comparison). "
                        "Extract key entities or keywords that are central to the question. "
                        "Provide the reasoning type and the list of entities as output.",
            context=self.problem_text
        )

        # Step 2: Select relevant documents based on the extracted entities
        document_selection = await self.ensemble(
            instruction=f"Given the following entities: {question_analysis}, "
                        "identify which documents are most likely to contain relevant information. "
                        "Return the indices or names of the selected documents.",
            contexts=[self.problem_text]  # Contexts include the problem text and potentially other inputs
        )

        # Step 3: Extract relevant facts from the selected documents
        fact_extraction = await asyncio.gather(
            *[self.generate(
                instruction=f"Extract all sentences or facts from Document {doc} that mention the entities: {question_analysis}.",
                context=self.problem_text
            ) for doc in document_selection.split(", ")]  # Assuming document_selection returns a comma-separated list
        )

        # Step 4: Construct the reasoning chain
        reasoning_chain = await self.ensemble(
            instruction="Using the extracted facts, construct a reasoning chain that connects the information "
                        "across documents to answer the question. For bridge questions, identify the 'bridge entity'. "
                        "For comparison questions, extract comparable properties. Provide the reasoning chain as output.",
            contexts=fact_extraction
        )

        # Step 5: Synthesize the final answer
        final_answer = await self.generate(
            instruction=f"Based on the reasoning chain: {reasoning_chain}, "
                        "derive the final answer to the question. Ensure the answer is concise and directly addresses the question.",
            context=self.problem_text
        )

        # Step 6: Validate and refine the answer (optional)
        refined_answer = await self.revise(
            instruction="Review the final answer for accuracy and clarity. "
                        "Refine it if necessary, ensuring it is supported by the reasoning chain and original documents.",
            context=final_answer
        )

        return refined_answer