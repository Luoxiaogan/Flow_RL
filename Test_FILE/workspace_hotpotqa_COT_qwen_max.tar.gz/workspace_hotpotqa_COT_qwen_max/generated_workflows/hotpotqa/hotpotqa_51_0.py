# Workflow ID: hotpotqa_51_0
# Benchmark: hotpotqa
# Data Indices: [80]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract mentions of the entities and their attributes
        entity_extraction_instruction = (
            "Identify all mentions of the entities 'Brian Connolly' and 'Kai Hansen' in the provided context. "
            "Extract relevant attributes such as birthdates, roles, and any other distinguishing information. "
            "Ensure the extraction is comprehensive and includes all pertinent details."
        )
        entity_extraction = await self.generate(
            instruction=entity_extraction_instruction,
            context=self.problem_text
        )

        # Step 2: Summarize key facts from each document for the entities
        summarize_instruction = (
            "Summarize the key facts about 'Brian Connolly' and 'Kai Hansen' from the provided context. "
            "Focus on attributes like birthdates, roles, and any other information that could help answer "
            "the question 'Who was born first?' Ensure the summary is concise but retains all critical details."
        )
        summaries = await asyncio.gather(
            self.summarize(instruction=summarize_instruction, context=self.problem_text),
            self.summarize(instruction=summarize_instruction, context=entity_extraction)
        )

        # Step 3: Compare the extracted information to determine who was born first
        comparison_instruction = (
            "Compare the birthdates of 'Brian Connolly' and 'Kai Hansen' based on the provided summaries. "
            "Determine who was born first and provide a clear explanation of your reasoning. "
            "If there are ambiguities or missing information, highlight them explicitly."
        )
        comparison_result = await self.ensemble(
            instruction=comparison_instruction,
            contexts=summaries
        )

        # Step 4: Refine the final answer for clarity and correctness
        refinement_instruction = (
            "Refine the provided comparison result into a concise and clear answer to the question "
            "'Who was born first, Brian Connolly or Kai Hansen?' Ensure the answer is precise and "
            "includes any necessary supporting information."
        )
        final_answer = await self.revise(
            instruction=refinement_instruction,
            context=comparison_result
        )

        return final_answer