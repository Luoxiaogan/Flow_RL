# Workflow ID: hotpotqa_82_0
# Benchmark: hotpotqa
# Data Indices: [346]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract entities and identify relevant documents
        entity_extraction_instruction = (
            "Identify all named entities (e.g., people, organizations, locations) mentioned in the question. "
            "Focus on entities that are likely to connect multiple documents. "
            "Return the entities as a comma-separated list."
        )
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        document_selection_instruction = (
            f"Given the entities: {entities}, identify which documents from the provided context contain "
            "relevant information about these entities. Return the document numbers as a comma-separated list."
        )
        relevant_documents = await self.generate(instruction=document_selection_instruction, context=self.problem_text)

        # Step 2: Extract facts and build reasoning chains
        fact_extraction_instruction = (
            f"Extract key facts about the entities: {entities} from the following documents: {relevant_documents}. "
            "Focus on facts that could help answer the question. Summarize each fact in one sentence."
        )
        facts = await self.generate(instruction=fact_extraction_instruction, context=self.problem_text)

        reasoning_chain_instruction = (
            f"Using the extracted facts: {facts}, construct a reasoning chain to answer the question. "
            "Ensure the reasoning is explicit and connects the facts logically."
        )
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 3: Generate and refine the final answer
        answer_generation_instruction = (
            f"Based on the reasoning chain: {reasoning_chain}, generate a concise answer to the question. "
            "Ensure the answer is precise and directly addresses the question."
        )
        initial_answer = await self.generate(instruction=answer_generation_instruction, context=self.problem_text)

        answer_refinement_instruction = (
            f"Refine the following answer: {initial_answer} to ensure it is accurate, clear, and well-supported by the facts. "
            "Correct any ambiguities or inconsistencies."
        )
        refined_answer = await self.revise(instruction=answer_refinement_instruction, context=self.problem_text)

        # Step 4: Validate and finalize the answer
        validation_instruction = (
            f"Validate the refined answer: {refined_answer} against the original question. "
            "Ensure it directly answers the question and aligns with the extracted facts."
        )
        final_answer = await self.revise(instruction=validation_instruction, context=self.problem_text)

        return final_answer