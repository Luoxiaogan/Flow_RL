# Workflow ID: hotpotqa_376_0
# Benchmark: hotpotqa
# Data Indices: [157]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract entities from the question
        entity_extraction_instruction = """
        Identify all named entities (people, places, organizations, etc.) mentioned in the question. 
        Return them as a list of unique entities.
        """
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Search for entities in the documents
        document_search_instruction = f"""
        Given the following entities: {entities}, search through the provided documents to find mentions of these entities.
        Return a list of documents that contain at least one of these entities.
        """
        relevant_documents = await self.generate(instruction=document_search_instruction, context=self.problem_text)

        # Step 3: Resolve entities across documents
        entity_resolution_instruction = f"""
        Using the relevant documents: {relevant_documents}, resolve the entities across different documents.
        Create a mapping of how entities are related or mentioned across documents.
        """
        entity_mapping = await self.generate(instruction=entity_resolution_instruction, context=self.problem_text)

        # Step 4: Build reasoning chains
        reasoning_chain_instruction = f"""
        Based on the entity mapping: {entity_mapping}, construct a reasoning chain that connects the entities to answer the question.
        Identify the bridge entity that links different pieces of information.
        """
        reasoning_chains = await asyncio.gather(
            self.generate(instruction=reasoning_chain_instruction, context=self.problem_text),
            self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)
        )

        # Step 5: Extract the final answer
        answer_extraction_instruction = f"""
        Using the reasoning chains: {reasoning_chains}, extract the final answer from the relevant documents.
        Ensure the answer is precise and directly addresses the question.
        """
        answers = await asyncio.gather(
            self.summarize(instruction=answer_extraction_instruction, context=reasoning_chains[0]),
            self.summarize(instruction=answer_extraction_instruction, context=reasoning_chains[1])
        )

        # Step 6: Ensemble decision to select the best answer
        ensemble_instruction = f"""
        Evaluate the following candidate answers: {answers}.
        Select the most accurate and well-supported answer based on the reasoning chains and document evidence.
        """
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=answers)

        return final_answer