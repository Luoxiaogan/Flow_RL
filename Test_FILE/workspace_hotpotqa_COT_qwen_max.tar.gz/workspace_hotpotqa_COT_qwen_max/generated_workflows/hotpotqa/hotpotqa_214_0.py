# Workflow ID: hotpotqa_214_0
# Benchmark: hotpotqa
# Data Indices: [354]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract information about "Persea" and "Crocus" in parallel
        persea_extraction_task = self.generate(
            instruction="Identify all information about the genus 'Persea' in the provided documents. "
                        "Focus on numerical details such as the number of species or other relevant facts. "
                        "If no numerical data is found, summarize descriptive information about its diversity.",
            context=self.problem_text
        )
        crocus_extraction_task = self.generate(
            instruction="Identify all information about the genus 'Crocus' in the provided documents. "
                        "Focus on numerical details such as the number of species or other relevant facts. "
                        "If no numerical data is found, summarize descriptive information about its diversity.",
            context=self.problem_text
        )

        # Execute tasks in parallel
        persea_info, crocus_info = await asyncio.gather(persea_extraction_task, crocus_extraction_task)

        # Step 2: Compare the extracted information to determine which genus has more species
        comparison_result = await self.ensemble(
            instruction="Compare the species counts of the genera 'Persea' and 'Crocus' based on the provided information. "
                        "If numerical data is available, perform a direct comparison. "
                        "If only descriptive information is available, infer which genus likely has more species. "
                        "Provide a concise answer stating which genus has more species.",
            contexts=[persea_info, crocus_info]
        )

        # Step 3: Return the final result
        return comparison_result