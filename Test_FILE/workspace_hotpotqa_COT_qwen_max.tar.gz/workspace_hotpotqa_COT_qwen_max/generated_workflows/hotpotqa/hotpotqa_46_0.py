# Workflow ID: hotpotqa_46_0
# Benchmark: hotpotqa
# Data Indices: [240]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Identify entities and their mentions across documents
        entities_instruction = """
        Extract all named entities mentioned in the question. For each entity, find mentions across the provided context documents. 
        Ensure you resolve any ambiguities or potential mismatches between different mentions of the same entity.
        Include specific sentences from the documents that describe the entities.
        """
        entities_context = self.problem_text
        entity_analysis = await self.generate(instruction=entities_instruction, context=entities_context)

        # Step 2: Summarize each document focusing on the identified entities
        summarize_instruction_template = f"""
        Given the following entities: {entity_analysis}
        Summarize the content of the document specifically highlighting information related to these entities. 
        If no relevant information is found, indicate so clearly.
        """

        # Parallelize summarization of all documents
        document_summaries = await asyncio.gather(
            *[self.summarize(instruction=summarize_instruction_template, context=doc) for doc in self.config['context_documents']]
        )

        # Step 3: Construct reasoning chains by merging summaries
        ensemble_instruction = """
        Analyze the provided summaries to identify connections and relationships between the entities. 
        Build a logical reasoning chain that links facts from different documents to answer the original question. 
        Highlight supporting evidence for each step in the reasoning process.
        """
        reasoning_chain = await self.ensemble(instruction=ensemble_instruction, contexts=document_summaries)

        # Step 4: Generate the final answer
        answer_instruction = f"""
        Based on the following reasoning chain: {reasoning_chain}
        Formulate a concise, factual answer to the original question. Ensure the response directly addresses the query and includes supporting evidence where necessary.
        """
        final_answer = await self.generate(instruction=answer_instruction, context=self.problem_text)

        return final_answer