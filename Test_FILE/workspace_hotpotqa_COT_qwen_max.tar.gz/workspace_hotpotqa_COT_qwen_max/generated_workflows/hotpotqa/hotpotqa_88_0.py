# Workflow ID: hotpotqa_88_0
# Benchmark: hotpotqa
# Data Indices: [280]

class Workflow:
    def __init__(self, config, problem) -> None:
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Identify the document mentioning "7 Dwarves – Men Alone in the Wood"
        instruction_step_1 = """
        Identify the document that mentions '7 Dwarves – Men Alone in the Wood'. 
        Extract the name of the tale it follows and any related context. 
        Ensure you provide enough detail for subsequent steps.
        """
        extraction_step_1 = await self.generate(instruction=instruction_step_1, context=self.problem_text)

        # Step 2: Identify the tale and find its publication year
        instruction_step_2 = f"""
        Based on the following information: {extraction_step_1}
        Identify the name of the tale that '7 Dwarves – Men Alone in the Wood' follows. 
        Then, locate the document that provides the publication year of this tale. 
        Extract the relevant year and any supporting context.
        """
        extraction_step_2 = await self.generate(instruction=instruction_step_2, context=self.problem_text)

        # Step 3: Summarize the findings
        instruction_step_3 = """
        Summarize the extracted information about the tale and its publication year. 
        Ensure the summary is concise but retains all critical details.
        """
        summary = await self.summarize(instruction=instruction_step_3, context=extraction_step_2)

        # Step 4: Revise for accuracy
        instruction_step_4 = """
        Review the following summary and revise it for accuracy and completeness. 
        Correct any inconsistencies or ambiguities. 
        Ensure the publication year is clearly stated.
        """
        revised_summary = await self.revise(instruction=instruction_step_4, context=summary)

        # Step 5: Ensemble to finalize the answer
        instruction_step_5 = """
        Synthesize the final answer from the provided information. 
        Ensure the response is clear, concise, and directly answers the question.
        """
        final_answer = await self.ensemble(instruction=instruction_step_5, contexts=[revised_summary])

        return final_answer