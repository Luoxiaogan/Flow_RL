# Workflow ID: hotpotqa_233_0
# Benchmark: hotpotqa
# Data Indices: [174]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Document Selection
        doc_selection_instruction = (
            "Analyze the provided question and context documents. Identify which documents are relevant to answering "
            "the question. Focus on documents that mention entities, events, or facts related to the query. Provide a "
            "list of relevant document titles."
        )
        relevant_docs = await self.generate(instruction=doc_selection_instruction, context=self.problem_text)

        # Step 2: Entity Extraction and Bridging
        entity_extraction_instruction = (
            f"Given the relevant documents: {relevant_docs}, extract key entities (e.g., players, positions, seasons) "
            "and determine how they connect across documents. Identify any bridge entities that link the question to "
            "specific documents. Provide a structured summary of these entities and their relationships."
        )
        entities_and_relationships = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 3: Reasoning Chain Construction
        reasoning_chain_instruction = (
            f"Using the extracted entities and relationships: {entities_and_relationships}, construct a reasoning chain "
            "that connects the question to the answer. Summarize the key facts from the relevant documents and synthesize "
            "them into a coherent chain of reasoning."
        )
        reasoning_chain = await self.summarize(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 4: Answer Extraction
        candidate_answers = await asyncio.gather(
            self.generate(
                instruction="Based on the reasoning chain, extract a precise answer to the question. Focus on the specific "
                            "details requested in the question.",
                context=reasoning_chain
            ),
            self.generate(
                instruction="Provide an alternative interpretation of the reasoning chain and extract a different "
                            "candidate answer.",
                context=reasoning_chain
            )
        )

        final_answer_instruction = (
            "Evaluate the following candidate answers and select the most accurate one. Ensure the selected answer "
            "directly addresses the question and is supported by the reasoning chain."
        )
        final_answer = await self.ensemble(instruction=final_answer_instruction, contexts=candidate_answers)

        return final_answer