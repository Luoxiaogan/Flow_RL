# Workflow ID: hotpotqa_180_0
# Benchmark: hotpotqa
# Data Indices: [150]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify entities and locate relevant documents
        entity_identification_instruction = """
        Analyze the question and identify all named entities (e.g., people, organizations, etc.) mentioned in it.
        Then, locate the documents in the provided context that contain information about these entities.
        Return the list of entities and their corresponding document indices.
        """
        entities_and_documents = await self.generate(
            instruction=entity_identification_instruction,
            context=self.problem_text
        )

        # Step 2: Extract relevant temporal information for each entity
        extraction_tasks = []
        for entity_info in entities_and_documents.split("\n"):
            entity, doc_indices = entity_info.split(":")
            extraction_instruction = f"""
            From the documents indexed as {doc_indices}, extract all temporal information (e.g., birth dates, founding dates) related to the entity "{entity}".
            Ensure the extracted information is precise and includes the exact date or time reference.
            """
            extraction_tasks.append(
                self.generate(
                    instruction=extraction_instruction,
                    context=self.problem_text
                )
            )
        extracted_information = await asyncio.gather(*extraction_tasks)

        # Step 3: Compare the extracted temporal information
        comparison_instruction = """
        Compare the temporal information provided for the two entities.
        Determine which entity was born first or occurred earlier in time.
        Provide a clear reasoning process and the final conclusion.
        """
        comparison_result = await self.ensemble(
            instruction=comparison_instruction,
            contexts=extracted_information
        )

        # Step 4: Summarize the final answer
        summary_instruction = """
        Based on the comparison result, provide a concise answer to the original question.
        Ensure the answer is brief, accurate, and directly addresses the question.
        """
        final_answer = await self.summarize(
            instruction=summary_instruction,
            context=comparison_result
        )

        return final_answer