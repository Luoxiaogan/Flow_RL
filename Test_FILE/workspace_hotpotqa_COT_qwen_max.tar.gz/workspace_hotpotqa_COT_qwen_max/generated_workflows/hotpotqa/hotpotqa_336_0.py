# Workflow ID: hotpotqa_336_0
# Benchmark: hotpotqa
# Data Indices: [387]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Identify the coach of the 2013 Washington Huskies football team
        coach_identification_instruction = """
        Identify the head coach of the 2013 Washington Huskies football team based on the provided context documents.
        Focus on documents that explicitly mention the 2013 season and the coaching staff. Provide the full name of the coach.
        """
        coach_name = await self.generate(instruction=coach_identification_instruction, context=self.problem_text)

        # Step 2: Extract information about the coach's current employer
        employer_extraction_instruction = f"""
        Based on the identified coach ({coach_name}), find their current employer as of the latest available information.
        Look for explicit mentions of their current job title and organization. If no direct mention is found,
        infer based on recent career history or affiliations.
        """
        employer_info = await self.generate(instruction=employer_extraction_instruction, context=self.problem_text)

        # Step 3: Revise and refine the extracted information
        revision_instruction = f"""
        Critically evaluate the extracted information about the coach ({coach_name}) and their current employer.
        Ensure the response is accurate, concise, and directly answers the question. Remove any irrelevant details.
        """
        refined_answer = await self.revise(instruction=revision_instruction, context=employer_info)

        # Step 4: Summarize the final answer
        summary_instruction = f"""
        Summarize the final answer regarding the current employer of {coach_name}.
        Ensure the response is brief and directly addresses the question.
        """
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_answer)

        return final_answer