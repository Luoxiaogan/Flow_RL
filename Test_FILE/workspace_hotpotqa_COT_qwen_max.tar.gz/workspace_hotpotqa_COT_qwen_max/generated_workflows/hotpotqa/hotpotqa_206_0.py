# Workflow ID: hotpotqa_206_0
# Benchmark: hotpotqa
# Data Indices: [106]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify relevant documents
        relevance_instructions = (
            "Analyze the following document to determine its relevance to the question. "
            "Consider whether the document contains entities, facts, or information that directly or indirectly "
            "relates to the question. Provide a brief explanation of relevance or irrelevance."
        )
        relevance_tasks = [
            self.generate(instruction=relevance_instructions, context=doc) 
            for doc in self.problem_text['documents']
        ]
        relevance_results = await asyncio.gather(*relevance_tasks)

        # Step 2: Extract entities and relationships
        entity_extraction_instructions = (
            "Extract all key entities mentioned in the document, along with their relationships to other entities. "
            "Focus on entities that could serve as bridges between different documents. "
            "Provide the extracted entities in a structured format."
        )
        entity_extraction_tasks = [
            self.generate(instruction=entity_extraction_instructions, context=doc) 
            for doc, relevance in zip(self.problem_text['documents'], relevance_results) 
            if "relevant" in relevance.lower()
        ]
        entity_results = await asyncio.gather(*entity_extraction_tasks)

        # Step 3: Construct reasoning chains
        reasoning_instructions = (
            f"Using the extracted entities from the relevant documents: {entity_results}, "
            "construct a reasoning chain that connects the information across documents to answer the question. "
            "Ensure that the reasoning is logical and explicitly mentions how entities are related."
        )
        reasoning_chain = await self.generate(instruction=reasoning_instructions, context=self.problem_text['question'])

        # Step 4: Synthesize the final answer
        synthesis_instructions = (
            "Based on the reasoning chain provided, synthesize the final answer to the question. "
            "Ensure that the answer is precise and directly addresses the question."
        )
        candidate_answers = [
            self.generate(instruction=synthesis_instructions, context=reasoning_chain),
            self.generate(instruction=synthesis_instructions, context=reasoning_chain)  # Generate multiple candidates
        ]
        candidate_answers = await asyncio.gather(*candidate_answers)

        final_answer = await self.ensemble(
            instruction="Compare the candidate answers and select the most accurate and complete one.",
            contexts=candidate_answers
        )

        return final_answer