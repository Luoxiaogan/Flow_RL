# Workflow ID: hotpotqa_163_0
# Benchmark: hotpotqa
# Data Indices: [300]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Parse the question to identify key entities and the requested information
        question_analysis = await self.generate(
            instruction="Analyze the question to identify key entities and the specific information being requested. "
                        "Focus on extracting names, relationships, and the type of information needed (e.g., date, fact).",
            context=self.problem_text
        )

        # Step 2: Search documents for mentions of key entities
        document_search = await self.generate(
            instruction=f"Search the provided documents for mentions of the key entities identified in the question: {question_analysis}. "
                        "For each document, extract sentences or paragraphs that mention these entities and summarize their relevance.",
            context=self.problem_text
        )

        # Step 3: Identify the bridge entity connecting the question to the answer
        bridge_entity_identification = await self.generate(
            instruction=f"Based on the extracted information: {document_search}, identify the 'bridge entity' "
                        "that connects the key entities in the question to the requested information. "
                        "Explain why this entity is relevant and how it helps answer the question.",
            context=self.problem_text
        )

        # Step 4: Extract the specific fact needed to answer the question
        fact_extraction = await self.generate(
            instruction=f"Using the identified bridge entity: {bridge_entity_identification}, extract the specific fact "
                        "needed to answer the question. For example, if the question asks for a date, locate the relevant date "
                        "in the documents and explain its connection to the bridge entity.",
            context=self.problem_text
        )

        # Step 5: Synthesize the final answer
        answer_synthesis = await self.generate(
            instruction=f"Synthesize the final answer based on the reasoning chain: {question_analysis}, {document_search}, "
                        f"{bridge_entity_identification}, {fact_extraction}. Ensure the answer is concise, accurate, and directly "
                        "addresses the question.",
            context=self.problem_text
        )

        # Optional: Revise the answer for clarity and correctness
        final_answer = await self.revise(
            instruction="Review the synthesized answer for clarity, accuracy, and completeness. "
                        "Make any necessary refinements to ensure it is a robust and precise response.",
            context=answer_synthesis
        )

        return final_answer