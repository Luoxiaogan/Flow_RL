# Workflow ID: hotpotqa_316_0
# Benchmark: hotpotqa
# Data Indices: [107]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify key entities and relevant documents
        entity_extraction = await self.generate(
            instruction="Identify the key entities mentioned in the question. "
                        "Then, scan all context documents to find those that mention these entities explicitly or implicitly. "
                        "Return the list of relevant documents.",
            context=self.problem_text
        )

        # Step 2: Summarize relevant documents to extract key facts
        summaries = await asyncio.gather(
            *[self.summarize(
                instruction=f"Summarize this document focusing on facts related to the entity: {entity_extraction}. "
                            "Highlight any temporal information or specific details that could answer the question.",
                context=doc
            ) for doc in entity_extraction.split("\n") if doc.strip()]
        )

        # Step 3: Synthesize information using Ensemble
        synthesized_answer = await self.ensemble(
            instruction="Compare and synthesize the following summaries to extract the most relevant fact "
                        "that answers the question. Ensure the answer is consistent and supported by the context.",
            contexts=summaries
        )

        # Step 4: Validate and refine the answer
        final_answer = await self.revise(
            instruction="Review the following answer and ensure it directly addresses the question. "
                        "If necessary, refine it to make it more precise and concise.",
            context=synthesized_answer
        )

        return final_answer