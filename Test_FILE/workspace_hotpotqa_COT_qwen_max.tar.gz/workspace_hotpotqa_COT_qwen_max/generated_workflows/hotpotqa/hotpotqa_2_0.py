# Workflow ID: hotpotqa_2_0
# Benchmark: hotpotqa
# Data Indices: [308]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract premiere dates for both films in parallel
        extract_instruction_best_friend = (
            "Extract the premiere date of the film 'Best Friend Forgotten' from the provided context documents. "
            "Include any relevant information about when and where it was first released."
        )
        extract_instruction_this_film = (
            "Extract the premiere date of the film 'This Film Is Not Yet Rated' from the provided context documents. "
            "Include any relevant information about when and where it was first released."
        )

        extract_best_friend, extract_this_film = await asyncio.gather(
            self.generate(instruction=extract_instruction_best_friend, context=self.problem_text),
            self.generate(instruction=extract_instruction_this_film, context=self.problem_text)
        )

        # Step 2: Summarize the extracted information
        summarize_instruction_best_friend = (
            "Summarize the premiere date of 'Best Friend Forgotten' based on the following extracted information: "
        )
        summarize_instruction_this_film = (
            "Summarize the premiere date of 'This Film Is Not Yet Rated' based on the following extracted information: "
        )

        summary_best_friend = await self.summarize(
            instruction=summarize_instruction_best_friend, context=extract_best_friend
        )
        summary_this_film = await self.summarize(
            instruction=summarize_instruction_this_film, context=extract_this_film
        )

        # Step 3: Compare the premiere dates using Ensemble
        compare_instruction = (
            "Compare the premiere dates of the two films based on the following summaries: "
            "Determine which film premiered first and provide a clear conclusion."
        )

        comparison_result = await self.ensemble(
            instruction=compare_instruction, contexts=[summary_best_friend, summary_this_film]
        )

        # Step 4: Generate the final answer
        final_answer_instruction = (
            "Based on the comparison result, state which film premiered first. "
            "Provide a concise and clear answer."
        )

        final_answer = await self.generate(instruction=final_answer_instruction, context=comparison_result)

        return final_answer