# Workflow ID: hotpotqa_26_0
# Benchmark: hotpotqa
# Data Indices: [356]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Identify key entities and select relevant documents
        entity_extraction_instruction = (
            "Extract all key entities mentioned in the question. "
            "Then, identify which documents contain information about these entities. "
            "Provide a list of relevant documents."
        )
        relevant_documents = await self.generate(
            instruction=entity_extraction_instruction,
            context=self.problem_text
        )

        # Step 2: Detect bridge entities and establish connections
        bridge_detection_instruction = (
            f"Given the following relevant documents: {relevant_documents}, "
            "identify any entities that serve as a bridge between multiple documents. "
            "Explain how these entities connect the documents and why they are important for answering the question."
        )
        bridge_entities = await self.generate(
            instruction=bridge_detection_instruction,
            context=self.problem_text
        )

        # Step 3: Chain facts and synthesize the answer
        fact_chaining_instruction = (
            f"Using the bridge entities: {bridge_entities}, "
            "chain together the facts from the relevant documents to derive the answer. "
            "Ensure the reasoning chain is logically consistent and explicitly stated."
        )
        reasoning_chain = await self.generate(
            instruction=fact_chaining_instruction,
            context=self.problem_text
        )

        # Step 4: Summarize the reasoning chain into a concise answer
        summarization_instruction = (
            f"Condense the following reasoning chain into a concise answer: {reasoning_chain}. "
            "Ensure the answer directly addresses the question and includes supporting evidence."
        )
        concise_answer = await self.summarize(
            instruction=summarization_instruction,
            context=self.problem_text
        )

        # Step 5: Validate and refine the answer
        validation_instruction = (
            f"Review the following answer: {concise_answer}. "
            "Check for logical consistency, completeness, and accuracy. "
            "Suggest improvements if necessary."
        )
        refined_answer = await self.revise(
            instruction=validation_instruction,
            context=self.problem_text
        )

        # Step 6: Handle multiple candidate answers (if applicable)
        # Use Ensemble to select the best answer if there are multiple candidates
        ensemble_instruction = (
            "Evaluate the following candidate answers and select the best one: "
            f"{[concise_answer, refined_answer]}. "
            "Base your decision on evidence from the documents and logical consistency."
        )
        final_answer = await self.ensemble(
            instruction=ensemble_instruction,
            contexts=[concise_answer, refined_answer]
        )

        return final_answer