# Workflow ID: hotpotqa_85_0
# Benchmark: hotpotqa
# Data Indices: [99]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key entities and relationships
        entity_extraction_instruction = """
        Extract all key entities, their descriptions, and relationships mentioned in the question and context documents. 
        Identify potential bridge entities that connect multiple documents. 
        Format the output as a list of entities with their descriptions and relationships.
        """
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Evaluate document relevance
        document_relevance_instruction = f"""
        Given the extracted entities: {entities}
        Evaluate the relevance of each document to the question. 
        Provide a relevance score for each document and explain why it is relevant or not.
        """
        document_contexts = [f"Document {i+1}" for i in range(10)]  # Assuming 10 documents
        relevance_results = await self.ensemble(instruction=document_relevance_instruction, contexts=document_contexts)

        # Step 3: Construct reasoning chain
        reasoning_chain_instruction = f"""
        Based on the relevance analysis: {relevance_results}
        Construct a reasoning chain that connects the information across relevant documents. 
        Explicitly mention how entities or facts link the documents.
        """
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 4: Synthesize the answer
        answer_synthesis_instruction = f"""
        Using the reasoning chain: {reasoning_chain}
        Extract the precise answer span from the relevant documents. 
        Ensure the answer directly addresses the question.
        """
        answer = await self.summarize(instruction=answer_synthesis_instruction, context=self.problem_text)

        # Step 5: Validate and refine the answer
        validation_instruction = f"""
        Critique the following answer: {answer}
        Ensure it satisfies the question and refine it if necessary. 
        Provide the final, improved answer.
        """
        final_answer = await self.revise(instruction=validation_instruction, context=self.problem_text)

        return final_answer