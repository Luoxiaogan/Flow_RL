# Workflow ID: hotpotqa_158_0
# Benchmark: hotpotqa
# Data Indices: [327]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key entities and analyze the question
        question_analysis = await self.generate(
            instruction="Analyze the question and extract key entities, focusing on identifying the subject, the type of information requested (e.g., 'who', 'what', 'when'), and any specific constraints. Provide the extracted entities and analysis in a structured format.",
            context=self.problem_text
        )

        # Step 2: Filter relevant documents based on extracted entities
        documents = [
            "Document 1: Ernie Triplett",
            "Document 2: Marshall Glenn",
            "Document 3: Death of Lucas Leonard",
            "Document 4: James D. Anderson",
            "Document 5: Nuages gris",
            "Document 6: Tom Bettis",
            "Document 7: Scapular fracture",
            "Document 8: 2009 Kansas City Chiefs season",
            "Document 9: Derrick Thomas",
            "Document 10: Jerrel Wilson"
        ]
        relevance_results = await asyncio.gather(
            *[self.generate(
                instruction=f"Given the extracted entities: {question_analysis}\nDetermine if the following document is relevant to answering the question. Provide a relevance score (0-10) and a brief justification.",
                context=doc
            ) for doc in documents]
        )
        relevant_documents = [doc for doc, result in zip(documents, relevance_results) if "relevance score" in result and int(result.split("relevance score:")[1].split()[0]) > 5]

        # Step 3: Perform cross-document reasoning
        reasoning_chain = await self.generate(
            instruction=f"Using the relevant documents: {relevant_documents}\nBuild a reasoning chain that connects the entities and facts across documents to answer the question. Focus on identifying shared entities or relationships.",
            context=self.problem_text
        )

        # Step 4: Extract the final answer
        answer_extraction = await self.summarize(
            instruction="From the reasoning chain provided, extract the final answer to the question. Ensure the answer is concise and directly addresses the question.",
            context=reasoning_chain
        )

        # Step 5: Validate and refine the answer
        refined_answer = await self.revise(
            instruction="Review the extracted answer against the original question. Ensure it satisfies all constraints and is factually correct. Refine the answer if necessary.",
            context=answer_extraction
        )

        return refined_answer