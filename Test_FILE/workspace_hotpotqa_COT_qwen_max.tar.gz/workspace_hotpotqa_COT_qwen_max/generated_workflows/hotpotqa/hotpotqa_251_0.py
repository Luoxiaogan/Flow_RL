# Workflow ID: hotpotqa_251_0
# Benchmark: hotpotqa
# Data Indices: [215]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract key entities from the question
        entity_extraction_instruction = """
        Identify all key entities mentioned in the question, such as names of people, organizations, books, or events. 
        Focus on entities that are likely to appear in the context documents. 
        Return a list of these entities for further processing.
        """
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Summarize each document to identify relevance
        summarize_instruction = f"""
        Summarize the main theme or subject of the document. 
        Focus on whether the document discusses any of the following entities: {entities}.
        Highlight connections between these entities if mentioned.
        """
        summaries = await asyncio.gather(
            *[self.summarize(instruction=summarize_instruction, context=doc) for doc in self.config['context_documents']]
        )

        # Step 3: Extract supporting facts from relevant documents
        relevant_docs = []
        for idx, summary in enumerate(summaries):
            if any(entity.lower() in summary.lower() for entity in entities.split(", ")):
                relevant_docs.append(self.config['context_documents'][idx])

        extract_facts_instruction = f"""
        Extract sentences or facts from the document that explicitly mention any of the following entities: {entities}. 
        Focus on sentences that describe relationships or connections between these entities.
        """
        extracted_facts = await asyncio.gather(
            *[self.generate(instruction=extract_facts_instruction, context=doc) for doc in relevant_docs]
        )

        # Step 4: Synthesize the final answer
        ensemble_instruction = f"""
        Combine the following extracted facts into a coherent answer to the question: "{self.problem_text}". 
        Ensure the answer is concise, accurate, and directly addresses the question. 
        Resolve any ambiguities by prioritizing facts that are most relevant to the entities: {entities}.
        """
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=extracted_facts)

        # Optional: Refine the final answer
        refine_instruction = """
        Review the provided answer for completeness and clarity. 
        If necessary, revise it to ensure it fully addresses the question and is free of ambiguity.
        """
        refined_answer = await self.revise(instruction=refine_instruction, context=final_answer)

        return refined_answer