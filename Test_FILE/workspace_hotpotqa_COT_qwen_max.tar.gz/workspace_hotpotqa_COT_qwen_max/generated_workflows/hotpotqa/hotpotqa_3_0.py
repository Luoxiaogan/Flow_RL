# Workflow ID: hotpotqa_3_0
# Benchmark: hotpotqa
# Data Indices: [389]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Document Selection
        doc_selection_instruction = """
        Identify all documents that mention the key entities or concepts in the question. 
        Specifically, look for mentions of "Ripon Cathedral" and "Ely Cathedral" across the provided documents. 
        Return the document numbers or titles that contain relevant information.
        """
        relevant_documents = await self.generate(instruction=doc_selection_instruction, context=self.problem_text)

        # Step 2: Entity Resolution
        entity_resolution_instruction = f"""
        Resolve any ambiguities in entity mentions within the following documents: {relevant_documents}.
        Ensure that "Ripon Cathedral" and "Ely Cathedral" are correctly identified as distinct entities.
        Provide a clear mapping of entity mentions to their respective cathedrals.
        """
        resolved_entities = await self.revise(instruction=entity_resolution_instruction, context=relevant_documents)

        # Step 3: Fact Extraction
        fact_extraction_instruction = f"""
        Extract specific facts about the locations of "Ripon Cathedral" and "Ely Cathedral" from the following resolved entities: {resolved_entities}.
        Focus on identifying the geographical locations (e.g., cities, counties) associated with each cathedral.
        """
        extracted_facts = await self.generate(instruction=fact_extraction_instruction, context=resolved_entities)

        # Step 4: Reasoning Chain Construction
        reasoning_chain_instruction = f"""
        Build a reasoning chain using the following extracted facts: {extracted_facts}.
        Determine which cathedral is located in Cambridgeshire based on the provided information.
        Construct a logical sequence of steps that leads to the conclusion.
        """
        reasoning_chain = await self.revise(instruction=reasoning_chain_instruction, context=extracted_facts)

        # Step 5: Answer Synthesis
        answer_synthesis_instruction = f"""
        Synthesize the final answer based on the following reasoning chain: {reasoning_chain}.
        Ensure the answer directly addresses the question: "Which cathedral is in Cambridgeshire, Ripon Cathedral or Ely Cathedral?"
        Provide the answer in a concise format.
        """
        final_answer = await self.ensemble(
            instruction=answer_synthesis_instruction,
            contexts=[reasoning_chain, extracted_facts]
        )

        return final_answer