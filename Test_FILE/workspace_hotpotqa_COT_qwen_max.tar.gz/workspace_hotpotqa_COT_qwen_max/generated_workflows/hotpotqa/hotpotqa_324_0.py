# Workflow ID: hotpotqa_324_0
# Benchmark: hotpotqa
# Data Indices: [221]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Entity Extraction
        entity_extraction_instruction = """
        Extract all key entities mentioned in the question and their relationships.
        Focus on identifying names, roles, and any connections between them.
        Format the output as a list of entities and their descriptions.
        """
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Document Selection
        document_selection_instruction = f"""
        Evaluate the provided documents and determine which ones are most relevant to the extracted entities.
        Prioritize documents that mention the entities and their relationships.
        Consider cross-references between documents to identify potential bridges.
        """
        document_selection_results = await asyncio.gather(
            *[self.generate(instruction=document_selection_instruction, context=doc) for doc in self.problem_text['documents']]
        )
        best_documents = await self.ensemble(instruction="Select the most relevant documents based on entity mentions and relationships.", contexts=document_selection_results)

        # Step 3: Reasoning Chain Construction
        reasoning_chain_instruction = f"""
        Using the extracted entities and the selected documents, construct a reasoning chain.
        Connect the entities across documents to form a logical sequence of facts.
        Ensure the chain explicitly links the entities mentioned in the question.
        """
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=best_documents)

        # Step 4: Answer Extraction
        answer_extraction_instruction = """
        Summarize the reasoning chain into a concise answer.
        Ensure the answer directly addresses the question and is formatted as a short text span.
        """
        answer = await self.summarize(instruction=answer_extraction_instruction, context=reasoning_chain)

        # Step 5: Validation
        validation_instruction = """
        Review the answer for accuracy and clarity.
        Ensure it aligns with the reasoning chain and directly answers the question.
        Refine the wording if necessary.
        """
        final_answer = await self.revise(instruction=validation_instruction, context=answer)

        return final_answer