# Workflow ID: hotpotqa_377_0
# Benchmark: hotpotqa
# Data Indices: [186]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Parse the question to identify key entities and reasoning type
        question_analysis = await self.generate(
            instruction="Analyze the question to identify the main subject, secondary entities, and the type of reasoning required (e.g., bridge, comparison, compositional). Provide a detailed breakdown.",
            context=self.problem_text
        )

        # Step 2: Determine document relevance
        # Parallelize document relevance analysis
        documents = [
            "Document 1: Santa Clara Broncos men's basketball",
            "Document 2: 2014–15 Santa Clara Broncos men's basketball team",
            "Document 3: 2011–12 Santa Clara Broncos men's basketball team",
            "Document 4: Santa Clara University",
            "Document 5: 2016–17 Santa Clara Broncos men's basketball team",
            "Document 6: Santa Clara Broncos baseball",
            "Document 7: 2015–16 Santa Clara Broncos men's basketball team",
            "Document 8: 2010–11 Santa Clara Broncos men's basketball team",
            "Document 9: 2013–14 Santa Clara Broncos men's basketball team",
            "Document 10: 2012–13 Santa Clara Broncos men's basketball team"
        ]

        relevance_tasks = [
            self.generate(
                instruction=f"Determine if this document contains information relevant to the question. Key entities: {question_analysis}. Provide a yes/no answer and a brief explanation.",
                context=doc
            )
            for doc in documents
        ]
        relevance_results = await asyncio.gather(*relevance_tasks)

        # Step 3: Construct reasoning chain
        reasoning_chain = await self.generate(
            instruction=f"Based on the relevant documents identified ({', '.join(relevance_results)}), construct a reasoning chain that connects the information across documents. Identify any 'bridge entities' or shared information.",
            context=self.problem_text
        )

        # Step 4: Extract and summarize the answer
        answer_extraction = await self.summarize(
            instruction=f"Extract the final answer from the reasoning chain constructed ({reasoning_chain}). Ensure the answer directly addresses the question.",
            context=self.problem_text
        )

        # Step 5: Validate and refine the answer
        refined_answer = await self.revise(
            instruction=f"Review the extracted answer ({answer_extraction}) and refine it if necessary. Ensure it is accurate, concise, and supported by the documents.",
            context=self.problem_text
        )

        return refined_answer