# Workflow ID: hotpotqa_84_0
# Benchmark: hotpotqa
# Data Indices: [128]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract mentions of key entities across all documents
        entity_extraction_instruction = """
        Identify all mentions of the following entities in the provided context documents:
        - "Arturo Perez Jr."
        - "California State University system"
        - Any documentary films or universities related to these entities.
        For each mention, include the document title and the sentence where the entity appears.
        """
        entity_mentions = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Identify the bridge entity (e.g., the documentary by Arturo Perez Jr.)
        bridge_entity_instruction = f"""
        Based on the extracted entity mentions below, identify the documentary film created by Arturo Perez Jr.
        Ensure the identification is based on explicit evidence from the context documents.
        Extracted Mentions: {entity_mentions}
        """
        bridge_entity = await self.generate(instruction=bridge_entity_instruction, context=self.problem_text)

        # Step 3: Build the reasoning chain to connect the bridge entity to the final answer
        reasoning_chain_instruction = f"""
        Using the identified bridge entity ({bridge_entity}), build a reasoning chain to determine:
        - Which university in the California State University system is associated with the documentary.
        Use explicit evidence from the context documents to support your reasoning.
        """
        reasoning_chain = await self.revise(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 4: Extract the precise answer span
        answer_extraction_instruction = f"""
        Based on the reasoning chain below, extract the precise answer span that directly answers the question.
        Ensure the answer is concise and includes only the relevant university name.
        Reasoning Chain: {reasoning_chain}
        """
        answer_span = await self.summarize(instruction=answer_extraction_instruction, context=self.problem_text)

        # Step 5: Evaluate and refine the answer using an ensemble approach
        ensemble_instruction = f"""
        Evaluate the following candidate answers and select the most accurate one:
        Candidate Answers:
        - {answer_span}
        Ensure the selected answer is supported by explicit evidence from the context documents.
        """
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[answer_span])

        return final_answer