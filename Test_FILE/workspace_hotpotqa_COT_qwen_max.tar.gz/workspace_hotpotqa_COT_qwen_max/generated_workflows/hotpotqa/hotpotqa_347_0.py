# Workflow ID: hotpotqa_347_0
# Benchmark: hotpotqa
# Data Indices: [104]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract entities and relationships
        entity_extraction = await self.generate(
            instruction="""Extract all entities (people, places, organizations, etc.) 
            and their relationships mentioned in the problem. Focus on identifying:
            - The main subject of the question (e.g., 'Grand Canyon: A Different View')
            - Relevant individuals or groups associated with the subject
            - Any temporal or biographical information (e.g., birth years, roles).""",
            context=self.problem_text
        )

        # Step 2: Identify relevant documents and entities
        document_selection = await self.generate(
            instruction=f"""Based on the extracted entities and relationships:
            {entity_extraction}
            Identify which documents contain information about the main subject ('Grand Canyon: A Different View') 
            and its associated individuals. Resolve any ambiguous entity mentions (e.g., ensure 'Ken Ham' 
            is correctly identified as a young Earth creationist).""",
            context=self.problem_text
        )

        # Step 3: Summarize key facts from relevant documents
        summaries = await asyncio.gather(
            self.summarize(
                instruction="""Summarize key facts about 'Grand Canyon: A Different View' 
                and its contributors from the provided document.""",
                context="Document 3: Grand Canyon: A Different View"
            ),
            self.summarize(
                instruction="""Summarize key facts about Ken Ham, including his birth year, 
                from the provided document.""",
                context="Document 8: Ken Ham"
            )
        )

        # Step 4: Construct reasoning chain
        reasoning_chain = await self.ensemble(
            instruction="""Combine the following summaries into a coherent reasoning chain 
            to answer the question. Ensure the chain connects the main subject ('Grand Canyon: A Different View') 
            to the requested individual and extracts the required information (e.g., birth year).""",
            contexts=summaries
        )

        # Step 5: Extract the final answer
        final_answer = await self.generate(
            instruction="""From the constructed reasoning chain, extract the precise answer 
            to the question. Ensure the answer is concise and directly addresses the query.""",
            context=reasoning_chain
        )

        return final_answer