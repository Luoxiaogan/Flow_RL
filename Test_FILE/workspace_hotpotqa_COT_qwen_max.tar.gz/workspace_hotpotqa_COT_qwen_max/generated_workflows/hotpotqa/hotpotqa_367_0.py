# Workflow ID: hotpotqa_367_0
# Benchmark: hotpotqa
# Data Indices: [33]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key entities and relationships from the problem text
        entity_extraction_instruction = """
        Analyze the provided question and context documents to identify all key entities (e.g., names, dates, events) 
        and their relationships. Focus on entities that are likely to connect multiple documents. Provide a structured 
        list of entities and their roles in the context of the question.
        """
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Resolve entities across documents
        entity_resolution_instruction = f"""
        Using the extracted entities: {entities}, analyze the context documents to resolve any ambiguities or 
        variations in entity mentions. Ensure that all references to the same entity are consistent across documents. 
        Provide a mapping of entities and their resolved forms.
        """
        resolved_entities = await self.generate(instruction=entity_resolution_instruction, context=self.problem_text)

        # Step 3: Construct the reasoning chain
        reasoning_chain_instruction = f"""
        Based on the resolved entities: {resolved_entities}, construct a reasoning chain that connects the entities 
        across documents. Identify the logical flow of information that leads from the question to the answer. 
        Highlight the specific sentences or facts that support each step in the chain.
        """
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 4: Extract the final answer
        answer_extraction_instruction = f"""
        Using the reasoning chain: {reasoning_chain}, extract the final answer to the question. Ensure that the 
        answer is concise and directly addresses the question. If the answer is a text span, provide the exact 
        sentence or phrase from the documents.
        """
        extracted_answer = await self.generate(instruction=answer_extraction_instruction, context=self.problem_text)

        # Step 5: Validate and refine the answer
        validation_instruction = f"""
        Review the extracted answer: {extracted_answer} and ensure it is accurate and complete. Refine the answer 
        if necessary to improve clarity or correctness. Provide the final validated answer.
        """
        final_answer = await self.revise(instruction=validation_instruction, context=extracted_answer)

        return final_answer