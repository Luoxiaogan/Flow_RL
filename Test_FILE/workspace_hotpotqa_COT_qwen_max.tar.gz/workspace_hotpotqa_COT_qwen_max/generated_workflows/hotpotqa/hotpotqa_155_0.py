# Workflow ID: hotpotqa_155_0
# Benchmark: hotpotqa
# Data Indices: [123]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Analyze the question and extract key entities
        question_analysis = await self.generate(
            instruction="Analyze the question to determine its type (e.g., bridge, comparison) and extract key entities or concepts. "
                        "Provide the entities as a comma-separated list.",
            context=self.problem_text
        )

        # Step 2: Identify relevant documents based on extracted entities
        relevant_documents = await self.generate(
            instruction=f"Given these key entities: {question_analysis}, identify which documents contain mentions of these entities. "
                        "Return the document numbers as a comma-separated list.",
            context=self.problem_text
        )

        # Step 3: Identify the bridge entity or connecting fact
        bridge_entity = await self.generate(
            instruction=f"Using the relevant documents ({relevant_documents}), identify the bridge entity or connecting fact "
                        "that links the initial mention to the final answer. Provide the bridge entity as a short phrase.",
            context=self.problem_text
        )

        # Step 4: Construct the reasoning chain
        reasoning_chain = await self.generate(
            instruction=f"Using the bridge entity ({bridge_entity}) and the relevant documents ({relevant_documents}), "
                        "construct a reasoning chain that explicitly outlines how the information flows from one document "
                        "to another to arrive at the answer. Format the chain as a sequence of document references and facts.",
            context=self.problem_text
        )

        # Step 5: Extract the precise answer span
        answer_extraction = await self.generate(
            instruction=f"Based on the reasoning chain ({reasoning_chain}), extract the precise answer span from the relevant documents. "
                        "Ensure the answer is concise and directly answers the question.",
            context=self.problem_text
        )

        # Step 6: Refine the answer for clarity and correctness
        refined_answer = await self.revise(
            instruction="Refine the extracted answer to ensure it is clear, concise, and fully addresses the question. "
                        "Correct any inaccuracies or ambiguities.",
            context=answer_extraction
        )

        return refined_answer