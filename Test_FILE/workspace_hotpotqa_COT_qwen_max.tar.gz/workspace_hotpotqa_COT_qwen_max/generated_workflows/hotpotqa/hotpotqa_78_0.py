# Workflow ID: hotpotqa_78_0
# Benchmark: hotpotqa
# Data Indices: [241]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract Entities and Relationships
        entity_extraction_instruction = """Extract all key entities mentioned in the context documents along with their relationships. 
        Focus on entities related to mobile payment services, digital wallets, companies, executives, and any other relevant concepts. 
        Include how these entities are connected across different documents."""
        entities_and_relationships = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the Question
        question_analysis_instruction = """Analyze the question to determine the type of reasoning required (e.g., bridge, comparison, compositional). 
        Identify the specific entities and facts needed to answer the question. Break down the question into its core components."""
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Select Relevant Documents and Summarize Information
        document_selection_instruction = f"""Based on the extracted entities and relationships ({entities_and_relationships}) and the question analysis ({question_analysis}), 
        select the most relevant documents that contain the necessary information to answer the question. Summarize the key information from these documents."""
        summaries = await asyncio.gather(
            self.summarize(instruction=document_selection_instruction, context=doc) for doc in self.problem_text.split("\n\n")
        )
        synthesized_summary = await self.ensemble(instruction="Synthesize the summaries into a coherent overview of the relevant information.", contexts=summaries)

        # Step 4: Construct Reasoning Chain
        reasoning_chain_instruction = f"""Using the synthesized summary ({synthesized_summary}), construct a reasoning chain that connects the relevant facts from different documents. 
        Identify the 'bridge entity' or logical connection that links the documents together."""
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=synthesized_summary)

        # Step 5: Generate Final Answer
        answer_generation_instruction = f"""Based on the reasoning chain ({reasoning_chain}), generate the final answer to the question. 
        Ensure the answer is precise and directly addresses the question."""
        final_answer = await self.generate(instruction=answer_generation_instruction, context=reasoning_chain)

        return final_answer