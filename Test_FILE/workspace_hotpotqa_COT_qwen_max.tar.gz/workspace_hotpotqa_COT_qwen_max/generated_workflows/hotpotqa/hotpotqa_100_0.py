# Workflow ID: hotpotqa_100_0
# Benchmark: hotpotqa
# Data Indices: [112]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Analyze the question and extract key entities
        entity_extraction = await self.generate(
            instruction="Analyze the question and extract all key entities, relationships, and constraints. "
                        "Focus on identifying names, roles, dates, and specific events mentioned in the question. "
                        "Format the output as a structured list of entities and their descriptions.",
            context=self.problem_text
        )

        # Step 2: Identify relevant documents based on extracted entities
        document_selection = await self.generate(
            instruction=f"Using the extracted entities and relationships: {entity_extraction}, "
                        "identify which documents contain information about these entities. "
                        "Provide a list of document numbers and a brief explanation of why each document is relevant.",
            context=self.problem_text
        )

        # Step 3: Perform cross-document reasoning
        reasoning_tasks = []
        for doc in ["Document 9", "Document 10"]:  # Dynamically replace with parsed document numbers
            reasoning_task = self.generate(
                instruction=f"Analyze {doc} and extract information related to the entities and relationships: {entity_extraction}. "
                            "Focus on connecting facts across documents to build a reasoning chain. "
                            "If multiple facts are involved, explain how they relate to each other.",
                context=self.problem_text
            )
            reasoning_tasks.append(reasoning_task)

        reasoning_results = await asyncio.gather(*reasoning_tasks)

        # Step 4: Ensemble to synthesize the reasoning chain
        reasoning_chain = await self.ensemble(
            instruction="Combine the reasoning results from multiple documents into a coherent chain. "
                        "Ensure that the chain connects all relevant facts and leads to a clear conclusion. "
                        "If there are conflicting facts, resolve them based on the provided context.",
            contexts=reasoning_results
        )

        # Step 5: Extract the final answer
        final_answer = await self.generate(
            instruction=f"Based on the reasoning chain: {reasoning_chain}, "
                        "extract the precise answer to the question. "
                        "The answer should be a short text span (e.g., an entity name, phrase, or brief factual response).",
            context=self.problem_text
        )

        return final_answer