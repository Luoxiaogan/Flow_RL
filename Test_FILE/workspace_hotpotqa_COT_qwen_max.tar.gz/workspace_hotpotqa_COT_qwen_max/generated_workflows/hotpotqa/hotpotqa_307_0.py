# Workflow ID: hotpotqa_307_0
# Benchmark: hotpotqa
# Data Indices: [127]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract entities from the problem text
        entity_extraction_instruction = """
        Identify all named entities (people, institutions, etc.) mentioned in the context documents.
        Focus on entities that could potentially answer the question: "Who attended Guildhall School of Music and Drama?"
        Return the list of entities in a structured format.
        """
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Filter documents relevant to Guildhall School of Music and Drama
        relevance_filter_instruction = f"""
        From the context documents, identify and summarize the documents that mention the Guildhall School of Music and Drama.
        Focus on sentences or paragraphs that discuss individuals associated with the institution.
        """
        relevant_documents = await self.summarize(instruction=relevance_filter_instruction, context=self.problem_text)

        # Step 3: Map entities to relevant documents
        mapping_instruction = f"""
        Using the extracted entities ({entities}) and the relevant documents ({relevant_documents}),
        create a mapping of entities to the documents they appear in. Ensure that only entities associated
        with the Guildhall School of Music and Drama are included.
        """
        entity_document_mapping = await self.generate(instruction=mapping_instruction, context=self.problem_text)

        # Step 4: Construct reasoning chains for each entity
        reasoning_chain_instruction = f"""
        For each entity in the mapping ({entity_document_mapping}), construct a reasoning chain that connects
        the entity to the Guildhall School of Music and Drama. Verify whether the entity attended or was
        otherwise associated with the institution. Provide supporting evidence from the documents.
        """
        reasoning_chains = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 5: Synthesize the final answer
        synthesis_instruction = f"""
        Based on the reasoning chains ({reasoning_chains}), synthesize a concise answer to the question:
        "Who attended Guildhall School of Music and Drama?" Include the names of the individuals and
        brief supporting evidence from the documents.
        """
        raw_answer = await self.generate(instruction=synthesis_instruction, context=self.problem_text)

        # Step 6: Refine the final answer
        refinement_instruction = """
        Review the synthesized answer and refine it for clarity, correctness, and conciseness.
        Ensure that the answer directly addresses the question and includes all relevant entities.
        """
        final_answer = await self.revise(instruction=refinement_instruction, context=raw_answer)

        return final_answer