# Workflow ID: hotpotqa_23_0
# Benchmark: hotpotqa
# Data Indices: [239]

class Workflow:
    def __init__(self, config, problem) -> None:
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Parse the question to identify key entities and reasoning type
        question_analysis = await self.generate(
            instruction="Analyze the question to identify key entities, relationships, and the type of reasoning required (e.g., bridge entity, comparison, compositional).",
            context=self.problem_text
        )

        # Step 2: Summarize each document to determine relevance
        document_summaries = await asyncio.gather(
            *[self.summarize(
                instruction="Summarize the document and highlight any information related to the entities or concepts mentioned in the question.",
                context=doc
            ) for doc in self.config["context_documents"]]
        )

        # Step 3: Filter relevant documents based on summaries
        relevant_docs = await self.ensemble(
            instruction="Evaluate the summaries and select the documents most relevant to answering the question.",
            contexts=document_summaries
        )

        # Step 4: Extract specific facts from relevant documents
        fact_extraction_tasks = []
        for doc in self.config["context_documents"]:
            if doc in relevant_docs:
                fact_extraction_tasks.append(
                    self.generate(
                        instruction=f"Extract all sentences or facts from the document that mention the entities or concepts identified in the question: {question_analysis}.",
                        context=doc
                    )
                )
        extracted_facts = await asyncio.gather(*fact_extraction_tasks)

        # Step 5: Build reasoning chains to connect entities across documents
        reasoning_chain = await self.generate(
            instruction=f"Using the extracted facts: {extracted_facts}, construct a reasoning chain that connects the entities and leads to the answer.",
            context=self.problem_text
        )

        # Step 6: Synthesize the final answer
        final_answer = await self.ensemble(
            instruction="Combine the reasoning chain and extracted facts to produce a concise and accurate answer to the question.",
            contexts=[reasoning_chain] + extracted_facts
        )

        return final_answer