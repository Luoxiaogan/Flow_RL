# Workflow ID: hotpotqa_37_0
# Benchmark: hotpotqa
# Data Indices: [352]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Parse the question to extract key entities
        question_analysis = await self.generate(
            instruction="Extract the key entities and the specific query from the question. "
                        "Identify the main subject and what is being asked about it. "
                        "Provide the results in a structured format.",
            context=self.problem_text
        )

        # Step 2: Identify relevant documents for each entity
        document_relevance_tasks = [
            self.generate(
                instruction=f"Determine if this document contains information about {entity}. "
                            "Focus on mentions of the entity and related details. "
                            "Provide a confidence score for relevance.",
                context=document
            )
            for entity in ["Words and Music", "actress born in 1919"]
            for document in [f"Document {i}" for i in range(1, 11)]
        ]
        document_relevance_results = await asyncio.gather(*document_relevance_tasks)

        # Step 3: Resolve entities and link information across documents
        entity_resolution = await self.ensemble(
            instruction="Compare the information from the relevant documents to resolve entities. "
                        "Establish connections between entities mentioned in different documents. "
                        "Provide a clear explanation of how the entities are linked.",
            contexts=document_relevance_results
        )

        # Step 4: Construct the reasoning chain to answer the question
        reasoning_chain = await self.generate(
            instruction="Using the resolved entities and their connections, construct a reasoning chain to answer the question. "
                        "Explain each step of the reasoning process clearly. "
                        "Ensure the final answer is precise and directly addresses the question.",
            context=entity_resolution
        )

        # Step 5: Extract and refine the final answer
        final_answer = await self.revise(
            instruction="Extract the precise answer span from the reasoning chain. "
                        "Ensure the answer is concise and accurate. "
                        "If necessary, refine the wording for clarity.",
            context=reasoning_chain
        )

        return final_answer