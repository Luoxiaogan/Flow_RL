# Workflow ID: hotpotqa_295_0
# Benchmark: hotpotqa
# Data Indices: [90]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Parse the question and identify key entities
        entity_identification = await self.generate(
            instruction="Identify all key entities mentioned in the question and their relationships. "
                        "Focus on names, organizations, and any explicit connections stated in the question. "
                        "Format the output as a JSON object with keys 'entities' and 'relationships'.",
            context=self.problem_text
        )

        # Step 2: Summarize each document with respect to the identified entities
        documents = [
            "Document 1: Argentina national football team...",
            "Document 2: American Football Association...",
            "Document 3: Northern Mariana Islands national football team...",
            "Document 4: Argentina national under-23 football team...",
            "Document 5: Supercopa Argentina...",
            "Document 6: Argentine Football Association...",
            "Document 7: Raúl Bernao...",
            "Document 8: Federico Sacchi...",
            "Document 9: Torneo Argentino C...",
            "Document 10: Argentina national beach soccer team..."
        ]

        summary_tasks = [
            self.summarize(
                instruction=f"Summarize this document focusing on information related to the entities: {entity_identification}. "
                            "Include only sentences that mention these entities or their relationships.",
                context=doc
            )
            for doc in documents
        ]
        document_summaries = await asyncio.gather(*summary_tasks)

        # Step 3: Construct the reasoning chain
        reasoning_chain = await self.generate(
            instruction=f"Using the following summaries, construct a reasoning chain that connects the entities mentioned in the question. "
                        f"Ensure the chain explicitly links the entities across documents. "
                        f"Summaries: {document_summaries}. "
                        "Output the reasoning chain as a step-by-step explanation.",
            context=self.problem_text
        )

        # Step 4: Extract the precise answer
        answer_extraction = await self.generate(
            instruction=f"Based on the reasoning chain: {reasoning_chain}, extract the precise answer to the question. "
                        "The answer should be a short text span, entity name, or brief factual response.",
            context=self.problem_text
        )

        # Step 5: Validate and refine the answer
        refined_answer = await self.revise(
            instruction="Critique and refine the extracted answer to ensure it is accurate, complete, and directly addresses the question. "
                        "If necessary, rephrase the answer for clarity.",
            context=answer_extraction
        )

        return refined_answer