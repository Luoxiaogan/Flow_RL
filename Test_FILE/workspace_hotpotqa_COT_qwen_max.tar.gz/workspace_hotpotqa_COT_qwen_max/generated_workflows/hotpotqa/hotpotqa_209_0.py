# Workflow ID: hotpotqa_209_0
# Benchmark: hotpotqa
# Data Indices: [233]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Parse the question to identify key entities and relationships
        question_analysis = await self.generate(
            instruction="Identify the key entities and relationships in the question. "
                        "Focus on what the question is asking for and the main subject. "
                        "For example, if the question asks about a series or franchise, "
                        "identify its name and the specific detail being requested (e.g., protagonist).",
            context=self.problem_text
        )

        # Step 2: Summarize each document to identify relevance
        documents = [
            "Document 1: 2016 in video gaming",
            "Document 2: Uncharted: Drake's Fortune",
            "Document 3: 2017 in video gaming",
            "Document 4: Uncharted",
            "Document 5: Uncharted: The Lost Legacy",
            "Document 6: 2013 in video gaming",
            "Document 7: 2018 in video gaming",
            "Document 8: Jak 3",
            "Document 9: List of Uncharted media",
            "Document 10: Ratchet & Clank"
        ]
        summaries = await asyncio.gather(
            *[self.summarize(
                instruction=f"Summarize this document and highlight any information related to the entities and relationships identified in the question. "
                            f"Focus on key details such as the protagonist, developer, or other relevant attributes.",
                context=doc
            ) for doc in documents]
        )

        # Step 3: Identify relevant documents and extract supporting facts
        relevant_docs = await self.ensemble(
            instruction="Evaluate the summaries and select the documents most relevant to answering the question. "
                        "Focus on documents that mention the key entities and provide direct or indirect answers to the query.",
            contexts=summaries
        )

        # Step 4: Extract and synthesize the answer
        answer_extraction = await self.generate(
            instruction=f"Based on the selected relevant documents ({relevant_docs}), "
                        "extract the precise answer to the question. "
                        "Ensure the answer is concise and directly addresses the query. "
                        "For example, if the question asks for the protagonist of a series, "
                        "provide the name of the character.",
            context=self.problem_text
        )

        # Step 5: Validate and refine the answer
        refined_answer = await self.revise(
            instruction="Review the extracted answer and ensure it accurately reflects the information in the context documents. "
                        "If necessary, refine the answer to improve clarity or correctness.",
            context=answer_extraction
        )

        return refined_answer