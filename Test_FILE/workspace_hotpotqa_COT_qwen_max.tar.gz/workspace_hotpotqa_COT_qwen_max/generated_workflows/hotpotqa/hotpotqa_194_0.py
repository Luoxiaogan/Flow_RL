# Workflow ID: hotpotqa_194_0
# Benchmark: hotpotqa
# Data Indices: [317]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Identify entities and select relevant documents
        entity_identification_instruction = """
        Identify all named entities mentioned in the question. Focus on entities that could serve as bridges between documents. 
        For example, songs, albums, bands, or other creative works. Return the entities as a list.
        """
        entities = await self.generate(instruction=entity_identification_instruction, context=self.problem_text)

        document_selection_instruction = f"""
        Given the entities {entities}, identify which documents in the provided context are relevant to these entities. 
        Return the relevant documents as a list of document IDs or titles.
        """
        relevant_documents = await self.generate(instruction=document_selection_instruction, context=self.problem_text)

        # Step 2: Extract bridge entities and relationships
        bridge_entity_extraction_instruction = f"""
        From the relevant documents {relevant_documents}, extract any shared entities or relationships that connect the entities {entities}. 
        For example, find a band, artist, or organization that is associated with both entities. 
        Return the bridge entity as a string.
        """
        bridge_entity = await self.generate(instruction=bridge_entity_extraction_instruction, context=self.problem_text)

        # Step 3: Verify connections and synthesize facts
        verification_instruction = f"""
        Verify that the bridge entity "{bridge_entity}" is indeed connected to both entities {entities}. 
        Provide supporting evidence from the relevant documents {relevant_documents}.
        """
        verification_results = await self.generate(instruction=verification_instruction, context=self.problem_text)

        # Step 4: Ensemble evaluation for robustness
        ensemble_instruction = f"""
        Evaluate the following candidate answer: "{bridge_entity}". 
        Ensure it is supported by the evidence in the documents and correctly answers the question. 
        If there are multiple candidates, select the most accurate one.
        """
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[entities, relevant_documents, verification_results])

        # Step 5: Extract precise answer span
        answer_extraction_instruction = f"""
        Extract the precise answer span from the final result "{final_answer}". 
        Ensure it is concise and directly answers the question.
        """
        precise_answer = await self.generate(instruction=answer_extraction_instruction, context=self.problem_text)

        return precise_answer