# Workflow ID: hotpotqa_303_0
# Benchmark: hotpotqa
# Data Indices: [43]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information about the Wuerffel Trophy and its namesake
        wuerffel_info = await self.generate(
            instruction="""
            Identify the person after whom the Wuerffel Trophy is named. 
            Include any notable achievements or awards mentioned in the context, 
            especially related to college football accolades like the Heisman Trophy.
            """,
            context=self.problem_text
        )

        # Step 2: Identify the year the namesake won the Heisman Trophy
        heisman_year_task = await self.generate(
            instruction=f"""
            Based on the following information about the Wuerffel Trophy and its namesake:
            {wuerffel_info}
            
            Determine the year the person won the Heisman Trophy. 
            Look for explicit mentions of the Heisman Trophy and the corresponding year.
            """,
            context=self.problem_text
        )

        # Step 3: Validate and summarize the reasoning chain
        reasoning_summary = await self.summarize(
            instruction="""
            Summarize the reasoning process used to determine the year the Wuerffel Trophy 
            namesake won the Heisman Trophy. Ensure the summary includes:
            - The name of the person
            - The relationship between the person and the Heisman Trophy
            - The specific year identified
            """,
            context=heisman_year_task
        )

        # Step 4: Handle potential ambiguities or conflicts
        # Use Ensemble to compare multiple candidate answers if necessary
        final_answer = await self.ensemble(
            instruction="""
            Evaluate the following candidate answers and reasoning summaries. 
            Select the most accurate and well-supported answer.
            """,
            contexts=[heisman_year_task, reasoning_summary]
        )

        return final_answer