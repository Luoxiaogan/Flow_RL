# Workflow ID: hotpotqa_281_0
# Benchmark: hotpotqa
# Data Indices: [135]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Parse the question to identify key entities and the requested information
        question_analysis = await self.generate(
            instruction="Analyze the question to identify the key entity being asked about and the type of information requested. "
                        "For example, determine if the question is asking for a population count, a date, or a comparison. "
                        "Output the key entity and the type of information as a JSON object.",
            context=self.problem_text
        )

        # Extract parsed information
        import json
        parsed_info = json.loads(question_analysis)
        key_entity = parsed_info.get("key_entity", "")
        info_type = parsed_info.get("info_type", "")

        # Step 2: Identify relevant documents mentioning the key entity
        document_selection = await self.generate(
            instruction=f"Identify all documents that mention the entity '{key_entity}'. "
                        "Provide a list of document names or identifiers where this entity appears.",
            context=self.problem_text
        )

        # Step 3: Find bridge entities and chain information
        bridge_candidates = await asyncio.gather(
            *[self.generate(
                instruction=f"From the document '{doc}', extract entities related to '{key_entity}' that could serve as bridge entities. "
                            "A bridge entity connects the key entity to the requested information. "
                            "List potential bridge entities and their relevance.",
                context=self.problem_text
            ) for doc in document_selection.split(",")]
        )
        best_bridge_entity = await self.ensemble(
            instruction=f"Evaluate the following bridge entity candidates: {', '.join(bridge_candidates)}. "
                        "Select the most relevant bridge entity that connects the key entity to the requested information.",
            contexts=bridge_candidates
        )

        # Step 4: Extract the specific fact needed to answer the question
        fact_extraction = await self.summarize(
            instruction=f"Using the bridge entity '{best_bridge_entity}', extract the specific fact from the documents that answers the question. "
                        f"The question is asking for {info_type}. Provide the exact value or statement.",
            context=self.problem_text
        )

        # Step 5: Validate and refine the answer
        final_answer = await self.revise(
            instruction=f"Review the extracted fact '{fact_extraction}' to ensure it directly answers the question. "
                        "If necessary, refine the answer to improve clarity and accuracy.",
            context=self.problem_text
        )

        return final_answer