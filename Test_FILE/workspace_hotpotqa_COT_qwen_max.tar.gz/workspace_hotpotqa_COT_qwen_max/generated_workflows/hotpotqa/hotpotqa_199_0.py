# Workflow ID: hotpotqa_199_0
# Benchmark: hotpotqa
# Data Indices: [271]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify Relevant Documents
        relevant_docs_instruction = (
            "Identify all documents that contain information about 'French Kiss' and 'Adam Brooks'. "
            "Focus on documents that mention the writer of 'French Kiss' and any biographical details about Adam Brooks. "
            "Provide a list of document numbers or titles that are relevant."
        )
        relevant_docs = await self.generate(instruction=relevant_docs_instruction, context=self.problem_text)

        # Step 2: Entity Resolution
        entity_resolution_instruction = (
            f"Given the following relevant documents: {relevant_docs}, confirm that 'Adam Brooks' mentioned in the context of 'French Kiss' "
            "is the same person referenced in other documents. Provide a brief explanation of how the entities are matched."
        )
        entity_match = await self.generate(instruction=entity_resolution_instruction, context=self.problem_text)

        # Step 3: Extract Birth Year
        birth_year_instruction = (
            f"From the following confirmed information about Adam Brooks: {entity_match}, extract the birth year of Adam Brooks. "
            "Ensure the extraction is precise and includes only the numerical value of the year."
        )
        birth_year = await self.generate(instruction=birth_year_instruction, context=self.problem_text)

        # Step 4: Validate and Refine
        refine_instruction = (
            f"Review the extracted birth year: {birth_year}. Ensure it is accurate and aligns with the question. "
            "If necessary, refine the result to ensure correctness."
        )
        refined_birth_year = await self.revise(instruction=refine_instruction, context=birth_year)

        # Step 5: Final Answer
        summarize_instruction = (
            f"Condense the following refined birth year: {refined_birth_year} into a concise answer. "
            "The response should be a single number representing the birth year of Adam Brooks."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_birth_year)

        return final_answer