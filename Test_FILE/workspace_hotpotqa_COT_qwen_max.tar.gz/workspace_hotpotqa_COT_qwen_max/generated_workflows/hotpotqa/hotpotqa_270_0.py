# Workflow ID: hotpotqa_270_0
# Benchmark: hotpotqa
# Data Indices: [293]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Identify key entities in the question
        entity_extraction = await self.generate(
            instruction="Extract all key entities mentioned in the question. "
                        "Focus on proper nouns such as names of places, people, or organizations. "
                        "Return the entities as a comma-separated list.",
            context=self.problem_text
        )

        # Step 2: Locate relevant documents mentioning the key entities
        relevant_docs = await self.generate(
            instruction=f"Identify which documents mention the following entities: {entity_extraction}. "
                        "Return the document numbers as a comma-separated list.",
            context=self.problem_text
        )

        # Step 3: Detect bridge entities and relationships
        bridge_entity_detection = await self.generate(
            instruction=f"Analyze the documents ({relevant_docs}) to find relationships or shared entities "
                        "that connect the key entities to other information. "
                        "Return the bridge entity and its relationship as a concise statement.",
            context=self.problem_text
        )

        # Step 4: Extract relevant facts about the bridge entity
        fact_extraction = await self.generate(
            instruction=f"Extract all relevant facts about the bridge entity mentioned in: {bridge_entity_detection}. "
                        "Focus on numerical data, dates, or specific properties. "
                        "Return the facts as bullet points.",
            context=self.problem_text
        )

        # Step 5: Build the reasoning chain and derive the answer
        reasoning_chain = await self.generate(
            instruction=f"Using the following facts:\n{fact_extraction}\n"
                        "Construct a logical reasoning chain to answer the question. "
                        "Ensure the reasoning is step-by-step and explicitly connects the facts to the question. "
                        "Return the final answer as a concise statement.",
            context=self.problem_text
        )

        # Step 6: Validate and refine the answer
        refined_answer = await self.revise(
            instruction="Review the reasoning chain and ensure the answer is accurate and supported by the facts. "
                        "If necessary, refine the answer for clarity and correctness.",
            context=reasoning_chain
        )

        return refined_answer