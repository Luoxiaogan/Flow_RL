# Workflow ID: hotpotqa_168_0
# Benchmark: hotpotqa
# Data Indices: [205]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Summarize relevance of each document to the question
        documents = self.problem_text.split("\n\n")  # Assuming documents are separated by double newlines
        relevance_tasks = [
            self.summarize(
                instruction="Summarize how this document relates to the question. "
                            "Focus on entities, events, or facts that directly address the query. "
                            "If the document is irrelevant, state so explicitly.",
                context=doc
            )
            for doc in documents
        ]
        relevance_summaries = await asyncio.gather(*relevance_tasks)

        # Step 2: Identify relevant documents
        relevant_docs = []
        for doc, summary in zip(documents, relevance_summaries):
            if "irrelevant" not in summary.lower():
                relevant_docs.append(doc)

        # Step 3: Extract entities and relationships from relevant documents
        entity_extraction_instruction = (
            "Extract all named entities (people, organizations, locations, etc.) mentioned in the text. "
            "For each entity, describe its role or significance in the context of the question. "
            "Pay special attention to entities that appear across multiple documents."
        )
        entity_extraction_tasks = [
            self.generate(instruction=entity_extraction_instruction, context=doc)
            for doc in relevant_docs
        ]
        entity_extractions = await asyncio.gather(*entity_extraction_tasks)

        # Step 4: Build reasoning chains
        reasoning_instruction = (
            "Analyze the extracted entities and their relationships. "
            "Construct a reasoning chain that connects the entities across documents. "
            "Focus on bridging entities that link different parts of the question. "
            "Provide a clear explanation of how the entities relate to the final answer."
        )
        reasoning_chain = await self.generate(
            instruction=reasoning_instruction,
            context="\n".join(entity_extractions)
        )

        # Step 5: Synthesize the final answer
        synthesis_instruction = (
            "Based on the reasoning chain and supporting facts, provide a concise answer to the question. "
            "Ensure the answer is supported by evidence from the documents. "
            "If there are multiple plausible answers, evaluate them and select the most likely one."
        )
        final_answer = await self.generate(
            instruction=synthesis_instruction,
            context=reasoning_chain
        )

        return final_answer