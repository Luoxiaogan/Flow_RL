# Workflow ID: hotpotqa_164_0
# Benchmark: hotpotqa
# Data Indices: [190]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Identify relevant documents and extract keywords
        document_selection_instruction = """
        Analyze the question and extract all key entities, names, or phrases that could help identify relevant documents. 
        Focus on entities mentioned in the question and their potential synonyms or related terms. 
        Return a list of these keywords/phrases for document matching.
        """
        keywords = await self.generate(instruction=document_selection_instruction, context=self.problem_text)

        # Step 2: Match keywords to documents and select relevant ones
        document_matching_instruction = f"""
        Use the extracted keywords/phrases: {keywords} to identify which documents are most relevant to the question. 
        For each document, determine if it contains information about the extracted entities or related topics. 
        Return a list of relevant document IDs or titles.
        """
        relevant_documents = await self.generate(instruction=document_matching_instruction, context=self.problem_text)

        # Step 3: Extract entities and identify bridge entities
        entity_extraction_instruction = f"""
        From the relevant documents: {relevant_documents}, extract all named entities such as people, organizations, locations, and dates. 
        Identify any shared entities (bridge entities) that appear across multiple documents. 
        These bridge entities will help connect the reasoning chain between documents.
        """
        entities_and_bridges = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 4: Construct reasoning chain
        reasoning_chain_instruction = f"""
        Using the extracted entities and bridge entities: {entities_and_bridges}, construct a reasoning chain that connects the question to the answer. 
        Start with the question, then trace the logical steps through the relevant documents, linking entities and facts. 
        Ensure the chain is complete and leads to a specific answer.
        """
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 5: Refine the reasoning chain
        refinement_instruction = """
        Review the reasoning chain and refine it for clarity, logical consistency, and completeness. 
        Ensure that each step logically follows from the previous one and that the chain leads to a precise answer.
        """
        refined_chain = await self.revise(instruction=refinement_instruction, context=reasoning_chain)

        # Step 6: Extract the final answer
        answer_extraction_instruction = """
        From the refined reasoning chain, extract the precise answer span that directly answers the question. 
        Ensure the answer is concise and accurate, and include supporting evidence if necessary.
        """
        final_answer = await self.summarize(instruction=answer_extraction_instruction, context=refined_chain)

        return final_answer