# Workflow ID: hotpotqa_124_0
# Benchmark: hotpotqa
# Data Indices: [3]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Resolve "Mama Grizzly" to Sarah Palin
        entity_resolution_instruction = (
            "Identify the real-world entity referred to as 'Mama Grizzly' in the context of the provided documents. "
            "Ensure the identification is precise and matches the descriptions in the documents."
        )
        mama_grizzly_entity = await self.generate(instruction=entity_resolution_instruction, context=self.problem_text)

        # Step 2: Extract information about Sarah Palin's governorship
        governor_info_instruction = (
            f"Given that 'Mama Grizzly' refers to {mama_grizzly_entity}, locate the document(s) that provide "
            "information about her role as Governor of Alaska. Specifically, determine which number Governor she was."
        )
        governor_info_extraction = await self.generate(instruction=governor_info_instruction, context=self.problem_text)

        # Step 3: Validate and synthesize the answer
        validation_instruction = (
            "Compare the following pieces of information to determine the most accurate and complete answer to the question: "
            "'Which number of Governor of Alaska was Mama Grizzly?' Ensure the response is concise and factually correct."
        )
        final_answer = await self.ensemble(
            instruction=validation_instruction,
            contexts=[mama_grizzly_entity, governor_info_extraction]
        )

        return final_answer