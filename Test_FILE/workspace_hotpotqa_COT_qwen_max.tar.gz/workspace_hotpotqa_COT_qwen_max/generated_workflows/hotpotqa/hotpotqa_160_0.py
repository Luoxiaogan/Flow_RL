# Workflow ID: hotpotqa_160_0
# Benchmark: hotpotqa
# Data Indices: [362]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key entities and their relationships
        entity_extraction_instruction = """
        Identify all key entities mentioned in the question and their relationships. 
        Focus on proper nouns, dates, and specific terms. Provide a structured list of these entities 
        along with any contextual clues about their roles or connections.
        """
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Analyze documents for relevance to the entities
        document_analysis_instruction = f"""
        Analyze each document to determine its relevance to the entities and relationships identified below.
        Entities and Relationships: {entities}
        For each document, provide a brief summary of its relevance and highlight any bridging facts or shared entities.
        """
        # Assuming the documents are concatenated in self.problem_text
        document_relevance = await self.generate(instruction=document_analysis_instruction, context=self.problem_text)

        # Step 3: Construct the reasoning chain
        reasoning_chain_instruction = f"""
        Based on the entities and document relevance analysis provided below, construct a reasoning chain 
        to connect the information across documents. Clearly identify the bridging entities or facts that 
        link the documents together.
        Entities and Relationships: {entities}
        Document Relevance: {document_relevance}
        """
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 4: Extract the precise answer
        answer_extraction_instruction = f"""
        Using the reasoning chain constructed below, extract the precise answer to the question. 
        Ensure the answer is a short text span, entity name, or factual response. If the question requires 
        a comparison or compositional reasoning, include the final derived value.
        Reasoning Chain: {reasoning_chain}
        """
        answer = await self.summarize(instruction=answer_extraction_instruction, context=self.problem_text)

        # Step 5: Validate and refine the answer
        refinement_instruction = f"""
        Review the extracted answer below against the reasoning chain and the original question. 
        Refine the answer if it lacks precision, completeness, or logical consistency. Ensure the final 
        answer is accurate and directly addresses the question.
        Extracted Answer: {answer}
        Reasoning Chain: {reasoning_chain}
        """
        final_answer = await self.revise(instruction=refinement_instruction, context=self.problem_text)

        return final_answer