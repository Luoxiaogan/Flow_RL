# Workflow ID: hotpotqa_204_0
# Benchmark: hotpotqa
# Data Indices: [166]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key entities and relationships from the question
        entity_extraction = await self.generate(
            instruction="Identify all key entities (e.g., names, titles, relationships) mentioned in the question. "
                        "Focus on proper nouns, specific terms, and any clues about connections between entities. "
                        "Provide the results in a structured format.",
            context=self.problem_text
        )

        # Step 2: Select relevant documents based on extracted entities
        document_selection = await self.generate(
            instruction=f"Given the following entities extracted from the question: {entity_extraction}, "
                        "identify which documents are likely to contain relevant information. "
                        "Look for documents that mention these entities or related concepts. "
                        "Provide a list of document indices or titles.",
            context=self.problem_text
        )

        # Step 3: Resolve entities across selected documents
        resolved_entities = await self.generate(
            instruction=f"Using the following entities: {entity_extraction} and the selected documents: {document_selection}, "
                        "resolve any ambiguities or variations in entity mentions. "
                        "For example, match aliases, alternate names, or different references to the same entity. "
                        "Provide a mapping of entities across documents.",
            context=self.problem_text
        )

        # Step 4: Build reasoning chains to connect entities
        reasoning_chain = await self.generate(
            instruction=f"With the resolved entities: {resolved_entities}, construct a reasoning chain "
                        "that connects the entities across documents. "
                        "Explain how the entities relate to each other and how they lead to the answer. "
                        "Ensure the chain is logical and explicitly references the supporting facts.",
            context=self.problem_text
        )

        # Step 5: Extract the precise answer span
        answer_extraction = await self.generate(
            instruction=f"Based on the reasoning chain: {reasoning_chain}, extract the precise answer span "
                        "that directly answers the question. Ensure the answer is concise and matches the expected format.",
            context=self.problem_text
        )

        # Optional Step 6: Revise the answer for clarity and correctness
        final_answer = await self.revise(
            instruction="Review the extracted answer and refine it for clarity, correctness, and conciseness. "
                        "Ensure it is fully supported by the reasoning chain and adheres to the question requirements.",
            context=answer_extraction
        )

        return final_answer