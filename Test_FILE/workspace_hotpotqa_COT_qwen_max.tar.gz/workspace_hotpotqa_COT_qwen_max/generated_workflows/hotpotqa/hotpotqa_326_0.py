# Workflow ID: hotpotqa_326_0
# Benchmark: hotpotqa
# Data Indices: [42]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Analyze the question and extract key entities
        question_analysis = await self.generate(
            instruction="Analyze the question to identify key entities and the reasoning type. "
                        "Extract all named entities, such as people, organizations, locations, and dates. "
                        "Determine whether the question requires bridge reasoning, comparison, or compositional reasoning.",
            context=self.problem_text
        )

        # Step 2: Identify relevant documents
        relevant_docs = await self.generate(
            instruction=f"Based on the extracted entities: {question_analysis}, "
                        "identify which documents are relevant to the question. "
                        "List the documents that mention the key entities.",
            context=self.problem_text
        )

        # Step 3: Summarize relevant information from each document
        doc_summaries = await asyncio.gather(
            *(self.summarize(
                instruction=f"Summarize the information about the key entities: {question_analysis}. "
                            "Focus on facts that connect the entities or provide context for the question.",
                context=doc
            ) for doc in relevant_docs.split("\n"))
        )

        # Step 4: Build reasoning chains
        reasoning_chains = await asyncio.gather(
            *(self.generate(
                instruction=f"Using the summaries: {summaries}, construct a reasoning chain that connects the entities. "
                            "Explain how the entities relate to each other and how they answer the question.",
                context=self.problem_text
            ) for summaries in doc_summaries)
        )

        # Step 5: Select the best reasoning chain
        best_chain = await self.ensemble(
            instruction="Evaluate the reasoning chains and select the most coherent and accurate one. "
                        "Ensure the selected chain directly answers the question.",
            contexts=reasoning_chains
        )

        # Step 6: Extract and refine the final answer
        final_answer = await self.revise(
            instruction="Extract the final answer from the selected reasoning chain. "
                        "Ensure the answer is precise, concise, and directly addresses the question.",
            context=best_chain
        )

        return final_answer