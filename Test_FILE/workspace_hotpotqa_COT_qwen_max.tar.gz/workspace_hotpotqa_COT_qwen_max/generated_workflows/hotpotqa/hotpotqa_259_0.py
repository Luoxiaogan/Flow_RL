# Workflow ID: hotpotqa_259_0
# Benchmark: hotpotqa
# Data Indices: [54]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Parse the question to identify entities and reasoning type
        question_analysis = await self.generate(
            instruction="Analyze the question to identify key entities and the reasoning type. "
                        "Extract the main subject (e.g., Finnish racing driver), the action (e.g., had pole position), "
                        "and the event (e.g., 2008 French Grand Prix).",
            context=self.problem_text
        )

        # Step 2: Identify relevant documents
        relevant_docs_task = self.generate(
            instruction=f"Based on the extracted entities ({question_analysis}), identify which documents "
                        "contain relevant information. Focus on documents mentioning the event, entities, "
                        "and their relationships.",
            context=self.problem_text
        )

        # Step 3: Resolve entities across documents
        entity_resolution_task = self.generate(
            instruction=f"Resolve entities across the identified documents. Ensure consistency in entity "
                        "mentions (e.g., confirm that 'Kimi Räikkönen' in one document refers to the same person "
                        "in another).",
            context=self.problem_text
        )

        # Run Steps 2 and 3 in parallel
        relevant_docs, entity_resolution = await asyncio.gather(relevant_docs_task, entity_resolution_task)

        # Step 4: Construct the reasoning chain
        reasoning_chain = await self.ensemble(
            instruction="Synthesize information from the relevant documents to construct a reasoning chain. "
                        "For example, if Document A mentions that Person X had pole position in Event Y, and "
                        "Document B confirms Person X's nationality, combine these facts into a coherent chain.",
            contexts=[relevant_docs, entity_resolution]
        )

        # Step 5: Extract the final answer
        answer_extraction = await self.generate(
            instruction=f"Extract the precise answer span from the reasoning chain ({reasoning_chain}). "
                        "Ensure the answer directly addresses the question (e.g., 'Kimi Räikkönen').",
            context=self.problem_text
        )

        # Step 6: Refine the answer for accuracy
        refined_answer = await self.revise(
            instruction="Critique and refine the extracted answer. Ensure it is accurate, complete, and "
                        "directly answers the question.",
            context=answer_extraction
        )

        return refined_answer