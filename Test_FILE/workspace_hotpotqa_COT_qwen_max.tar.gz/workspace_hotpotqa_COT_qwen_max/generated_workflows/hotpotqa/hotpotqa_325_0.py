# Workflow ID: hotpotqa_325_0
# Benchmark: hotpotqa
# Data Indices: [328]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract mentions of double albums and their release dates
        extraction_instruction = """
        Analyze the provided documents and extract all mentions of double albums along with their release dates.
        Include the name of the artist associated with each album. Format the output as a list of entries:
        - Album Name: [Album], Artist: [Artist], Release Date: [Date]
        """
        album_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Identify key entities and their relationships
        entity_resolution_instruction = f"""
        Using the extracted album information:
        {album_info}
        Match each album to its respective artist and resolve any ambiguities. Ensure that the output clearly links each artist to their album and release date.
        """
        resolved_entities = await self.generate(instruction=entity_resolution_instruction, context=self.problem_text)

        # Step 3: Compare release dates to determine the earliest double album
        reasoning_instruction = f"""
        Based on the resolved entities:
        {resolved_entities}
        Compare the release dates of the double albums to determine which artist released their album first. Focus on the albums of Bob Dylan, Frank Zappa, and any other artists mentioned. Provide the name of the artist who released the earliest double album.
        """
        reasoning_results = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Synthesize results to extract the final answer
        synthesis_instruction = f"""
        From the reasoning results:
        {reasoning_results}
        Extract the name of the artist who beat both Bob Dylan and Frank Zappa to the release of the first studio double album. Ensure the answer is concise and directly addresses the question.
        """
        final_answer = await self.generate(instruction=synthesis_instruction, context=self.problem_text)

        return final_answer