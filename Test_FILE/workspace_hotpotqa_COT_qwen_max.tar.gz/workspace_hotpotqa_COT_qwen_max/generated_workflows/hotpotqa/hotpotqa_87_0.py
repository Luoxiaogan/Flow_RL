# Workflow ID: hotpotqa_87_0
# Benchmark: hotpotqa
# Data Indices: [188]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Identify key entities and analyze the question
        question_analysis = await self.generate(
            instruction="Analyze the question and identify key entities (e.g., names, organizations) and the type of information being asked for.",
            context=self.problem_text
        )

        # Step 2: Extract relevant information from documents
        document_extractions = await asyncio.gather(
            self.generate(
                instruction=f"Extract all information related to the entity 'Dave Feamster' from the provided documents.",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"Extract all information related to pizza chains mentioned in the provided documents.",
                context=self.problem_text
            )
        )

        # Step 3: Refine and summarize extracted information
        refined_info = await asyncio.gather(
            self.revise(
                instruction="Refine the extracted information about Dave Feamster to focus on relevant facts.",
                context=document_extractions[0]
            ),
            self.revise(
                instruction="Refine the extracted information about pizza chains to focus on relevant facts.",
                context=document_extractions[1]
            )
        )
        summarized_info = await asyncio.gather(
            self.summarize(
                instruction="Summarize the refined information about Dave Feamster into key facts.",
                context=refined_info[0]
            ),
            self.summarize(
                instruction="Summarize the refined information about pizza chains into key facts.",
                context=refined_info[1]
            )
        )

        # Step 4: Build reasoning chains and synthesize information
        reasoning_chain = await self.generate(
            instruction=f"Using the following facts:\n{summarized_info[0]}\nand\n{summarized_info[1]}\n"
                        f"Build a reasoning chain to connect the information and answer the question.",
            context=self.problem_text
        )

        # Step 5: Final answer synthesis
        final_answer = await self.ensemble(
            instruction="Synthesize the reasoning chain and extracted facts into a concise answer that directly addresses the question.",
            contexts=[reasoning_chain, *summarized_info]
        )

        return final_answer