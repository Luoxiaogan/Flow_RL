# Workflow ID: hotpotqa_338_0
# Benchmark: hotpotqa
# Data Indices: [289]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio
        
        # Step 1: Analyze the question to identify key entities and intent
        question_analysis = await self.generate(
            instruction="Analyze the question to identify the key entities and the type of information being requested. "
                        "Provide a structured breakdown of the question components.",
            context=self.problem_text
        )
        
        # Step 2: Identify relevant documents and extract mentions of key entities
        document_selection = await self.generate(
            instruction=f"Based on the following question analysis:\n{question_analysis}\n"
                        "Identify which documents contain relevant information about the key entities. "
                        "Extract specific sentences or paragraphs that mention these entities.",
            context=self.problem_text
        )
        
        # Step 3: Summarize relevant information from each document
        summaries = await asyncio.gather(
            *(self.summarize(
                instruction=f"Summarize the following document excerpt, focusing on information about the key entities:\n{doc}",
                context=doc
            ) for doc in document_selection.split("\n\n"))  # Assuming each document is separated by double newlines
        )
        
        # Step 4: Perform cross-document reasoning to build inference chains
        reasoning_chain = await self.ensemble(
            instruction=f"Given the summaries of relevant documents:\n{' '.join(summaries)}\n"
                        "Perform cross-document reasoning to connect the key entities and derive the answer. "
                        "Clearly explain the reasoning process and identify the final answer.",
            contexts=summaries
        )
        
        # Step 5: Extract and refine the final answer
        final_answer = await self.revise(
            instruction=f"Refine the following reasoning chain to extract the precise answer:\n{reasoning_chain}\n"
                        "Ensure the answer is concise and directly addresses the question.",
            context=reasoning_chain
        )
        
        return final_answer