# Workflow ID: hotpotqa_300_0
# Benchmark: hotpotqa
# Data Indices: [84]

class Workflow:
    def __init__(self, config, problem) -> None:
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Analyze the question type and extract key entities
        question_analysis = await self.generate(
            instruction="Analyze the question to determine its type (e.g., bridge, comparison, compositional). "
                        "Extract key entities mentioned in the question and identify their roles.",
            context=self.problem_text
        )

        # Step 2: Identify relevant documents and extract supporting facts
        document_selection = await self.generate(
            instruction=f"Based on the extracted entities ({question_analysis}), identify which context documents "
                        "are most relevant. Extract key sentences or facts from these documents that could help answer the question.",
            context=self.problem_text
        )

        # Step 3: Perform cross-document reasoning
        reasoning_chain = await self.generate(
            instruction=f"Using the extracted facts ({document_selection}), construct a reasoning chain that connects "
                        "the information across documents. Resolve any ambiguities and ensure logical consistency.",
            context=self.problem_text
        )

        # Step 4: Generate the final answer
        final_answer = await self.generate(
            instruction=f"Based on the reasoning chain ({reasoning_chain}), generate the final answer. "
                        "Ensure the answer is concise and directly addresses the question.",
            context=self.problem_text
        )

        return final_answer