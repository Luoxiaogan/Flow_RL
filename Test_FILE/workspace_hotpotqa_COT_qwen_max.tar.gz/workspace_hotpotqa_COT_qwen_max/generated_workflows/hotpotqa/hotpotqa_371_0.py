# Workflow ID: hotpotqa_371_0
# Benchmark: hotpotqa
# Data Indices: [276]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Analyze the question and extract key entities
        entity_analysis = await self.generate(
            instruction="Analyze the question to identify key entities, relationships, and the reasoning type required. "
                        "Focus on understanding whether this is a bridge, comparison, or compositional question. "
                        "Output the entities and reasoning type clearly.",
            context=self.problem_text
        )

        # Step 2: Score document relevance
        documents = [
            "Document 1: Buffalo Springfield (compilation album)",
            "Document 2: For What It's Worth",
            "Document 3: Long May You Run",
            "Document 4: Train discography",
            "Document 5: Buffalo Springfield (box set)",
            "Document 6: Neil Young",
            "Document 7: Kristen Stills",
            "Document 8: Buffalo Springfield",
            "Document 9: Buffalo Springfield (album)",
            "Document 10: Crosby, Stills, Nash & Young"
        ]
        relevance_scores = await asyncio.gather(
            *[self.generate(
                instruction=f"Score the relevance of this document to the question based on the entities and reasoning type: {entity_analysis}. "
                            "Output a score from 1 to 10, where 10 is highly relevant.",
                context=doc
            ) for doc in documents]
        )

        # Step 3: Select top relevant documents
        ranked_documents = sorted(zip(documents, relevance_scores), key=lambda x: int(x[1]), reverse=True)[:3]
        selected_documents = [doc for doc, _ in ranked_documents]

        # Step 4: Construct reasoning chain
        reasoning_chain = await self.generate(
            instruction=f"Using the selected documents ({', '.join(selected_documents)}), construct a reasoning chain to connect the entities and answer the question. "
                        "Ensure all steps are explicit and logical.",
            context=self.problem_text
        )

        # Step 5: Extract the answer
        answer_extraction = await self.summarize(
            instruction=f"Extract the precise answer span from the reasoning chain: {reasoning_chain}. "
                        "Ensure the answer is concise and directly addresses the question.",
            context=self.problem_text
        )

        # Step 6: Validate and refine the answer
        refined_answer = await self.revise(
            instruction=f"Validate the extracted answer ({answer_extraction}) against the question. "
                        "Refine it if necessary to ensure accuracy and proper formatting.",
            context=self.problem_text
        )

        return refined_answer