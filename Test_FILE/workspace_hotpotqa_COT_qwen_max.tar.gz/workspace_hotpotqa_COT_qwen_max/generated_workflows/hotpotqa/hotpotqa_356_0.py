# Workflow ID: hotpotqa_356_0
# Benchmark: hotpotqa
# Data Indices: [314]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Identify key entities and relevant documents
        entity_identification = await self.generate(
            instruction="Identify all key entities mentioned in the question and determine which documents contain relevant information about these entities. Focus on entities like authors, book series, franchises, and production companies.",
            context=self.problem_text
        )

        # Step 2: Detect bridge entities and construct reasoning chains
        bridge_detection = await self.generate(
            instruction=f"Based on the identified entities and relevant documents: {entity_identification}, detect the bridge entities or concepts that connect multiple documents. For example, find shared entities or relationships between the documents.",
            context=self.problem_text
        )

        # Step 3: Perform multi-hop reasoning
        reasoning_steps = await asyncio.gather(
            self.generate(
                instruction=f"From the document about 'How to Train Your Dragon', determine how many children's books are in the series written by Cressida Cowell. Ensure the reasoning is clear and supported by evidence.",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"Verify the connection between Mad Hatter Entertainment and Anna Banks' 'Syrena Legacy' series. Explain how this relationship supports answering the question.",
                context=self.problem_text
            )
        )

        # Step 4: Extract and validate the final answer
        final_answer = await self.ensemble(
            instruction="Combine the results of the reasoning steps to extract the final answer. Ensure the answer directly addresses the question and is supported by the reasoning chains.",
            contexts=reasoning_steps
        )

        # Step 5: Validate the answer for accuracy and completeness
        validated_answer = await self.revise(
            instruction="Review the final answer to ensure it is accurate, complete, and directly answers the question. Correct any inconsistencies or missing details.",
            context=final_answer
        )

        return validated_answer