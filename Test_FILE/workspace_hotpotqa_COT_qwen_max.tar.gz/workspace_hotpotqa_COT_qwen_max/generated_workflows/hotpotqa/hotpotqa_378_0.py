# Workflow ID: hotpotqa_378_0
# Benchmark: hotpotqa
# Data Indices: [29]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Analyze the question to identify its type and key entities
        analysis_instruction = (
            "Analyze the question to determine its type (e.g., bridge, comparison) and identify key entities or keywords. "
            "Focus on understanding what information is being asked and how it might be connected across multiple documents."
        )
        question_analysis = await self.generate(instruction=analysis_instruction, context=self.problem_text)

        # Step 2: Identify relevant documents
        relevance_instruction = (
            "Evaluate each document to determine its relevance to the question. "
            "Consider whether the document contains information about the key entities or concepts identified in the question analysis."
        )
        documents = self.problem_text.split("\n\n")  # Assuming documents are separated by double newlines
        relevance_tasks = [self.generate(instruction=relevance_instruction, context=doc) for doc in documents]
        relevance_results = await asyncio.gather(*relevance_tasks)

        # Filter relevant documents based on the results
        relevant_documents = [doc for doc, result in zip(documents, relevance_results) if "relevant" in result.lower()]

        # Step 3: Identify bridge entities or shared concepts
        bridge_instruction = (
            "Identify bridge entities or shared concepts that connect the relevant documents. "
            "These entities should help establish a logical chain of reasoning between the documents."
        )
        bridge_entities = await self.generate(instruction=bridge_instruction, context="\n".join(relevant_documents))

        # Step 4: Construct the reasoning chain
        reasoning_instruction = (
            f"Using the identified bridge entities ({bridge_entities}), construct a reasoning chain that connects the relevant documents. "
            "Ensure the chain logically leads to the answer by synthesizing information from multiple documents."
        )
        reasoning_chain = await self.generate(instruction=reasoning_instruction, context="\n".join(relevant_documents))

        # Step 5: Extract the final answer span
        extraction_instruction = (
            "Extract the final answer span from the constructed reasoning chain. "
            "Ensure the answer is precise and directly supported by the reasoning chain."
        )
        answer_span = await self.summarize(instruction=extraction_instruction, context=reasoning_chain)

        # Step 6: Validate and refine the answer
        refinement_instruction = (
            "Critique and refine the extracted answer to ensure it is accurate, concise, and fully supported by the reasoning chain."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=answer_span)

        return refined_answer