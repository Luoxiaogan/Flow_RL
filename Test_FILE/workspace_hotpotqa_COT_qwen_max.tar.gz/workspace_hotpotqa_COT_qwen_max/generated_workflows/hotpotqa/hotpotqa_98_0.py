# Workflow ID: hotpotqa_98_0
# Benchmark: hotpotqa
# Data Indices: [360]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Identify the song referring to the Maharishi
        instruction_song = """
        Extract the name of the song by The Beach Boys that refers to the Maharishi. 
        Look for explicit mentions of the Maharishi in the context documents and link them to a specific song title. 
        Provide the song title and the document where it was found.
        """
        song_info = await self.generate(instruction=instruction_song, context=self.problem_text)

        # Step 2: Identify the songwriter of the song
        instruction_songwriter = f"""
        Based on the following information: {song_info}, identify the songwriter(s) of the song. 
        Extract their names and any relevant biographical details from the context documents. 
        Ensure the songwriter is explicitly linked to the song.
        """
        songwriter_info = await self.generate(instruction=instruction_songwriter, context=self.problem_text)

        # Step 3: Resolve ambiguities if multiple candidates exist
        instruction_resolve = """
        Compare the following candidate songwriters and determine which one is most relevant to the song mentioning the Maharishi. 
        Use evidence from the context documents to justify your choice.
        """
        resolved_songwriter = await self.ensemble(instruction=instruction_resolve, contexts=[songwriter_info])

        # Step 4: Extract the birth year of the songwriter
        instruction_birth_year = f"""
        Based on the following information: {resolved_songwriter}, determine the birth year of the songwriter. 
        If the birth year is not explicitly mentioned, infer it using contextual clues or related information from the documents.
        """
        birth_year = await self.generate(instruction=instruction_birth_year, context=self.problem_text)

        # Step 5: Refine the final answer
        instruction_final = f"""
        Compile the following information into a concise answer: {birth_year}. 
        Ensure the response directly addresses the question about the birth year of the songwriter.
        """
        final_answer = await self.revise(instruction=instruction_final, context=birth_year)

        return final_answer