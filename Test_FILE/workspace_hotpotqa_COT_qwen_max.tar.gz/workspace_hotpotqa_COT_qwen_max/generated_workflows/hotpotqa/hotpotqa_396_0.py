# Workflow ID: hotpotqa_396_0
# Benchmark: hotpotqa
# Data Indices: [25]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract relevant documents for each entity
        instruction_extract_docs = (
            "Identify which documents contain information about the entities mentioned in the question. "
            "Focus on extracting sentences that describe the genre or type of the entities. "
            "Ensure you resolve any ambiguous entity mentions."
        )
        extracted_docs = await self.generate(instruction=instruction_extract_docs, context=self.problem_text)

        # Step 2: Extract key facts about each entity in parallel
        instruction_extract_facts_stuff = (
            f"Extract all relevant information about 'The Stuff of Legend' from the provided context. "
            "Focus on its genre, type, and any related descriptors. Ensure the output is precise and factual."
        )
        instruction_extract_facts_boatniks = (
            f"Extract all relevant information about 'The Boatniks' from the provided context. "
            "Focus on its genre, type, and any related descriptors. Ensure the output is precise and factual."
        )

        # Parallel execution for fact extraction
        facts_stuff, facts_boatniks = await asyncio.gather(
            self.generate(instruction=instruction_extract_facts_stuff, context=extracted_docs),
            self.generate(instruction=instruction_extract_facts_boatniks, context=extracted_docs)
        )

        # Step 3: Refine extracted facts for clarity and accuracy
        instruction_refine_facts = (
            "Review the extracted facts and refine them for clarity and accuracy. "
            "Ensure the output explicitly states the genre or type of the entity."
        )
        refined_stuff = await self.revise(instruction=instruction_refine_facts, context=facts_stuff)
        refined_boatniks = await self.revise(instruction=instruction_refine_facts, context=facts_boatniks)

        # Step 4: Compare the facts to answer the question
        instruction_compare_facts = (
            "Compare the refined facts about 'The Stuff of Legend' and 'The Boatniks'. "
            "Determine if both entities belong to the same genre (American comedy). "
            "Provide a clear and concise answer ('Yes' or 'No') based on the comparison."
        )
        comparison_result = await self.ensemble(
            instruction=instruction_compare_facts,
            contexts=[refined_stuff, refined_boatniks]
        )

        # Step 5: Finalize the answer
        instruction_finalize_answer = (
            "Based on the comparison result, provide a final answer to the question. "
            "Ensure the answer is concise and directly addresses the question."
        )
        final_answer = await self.generate(instruction=instruction_finalize_answer, context=comparison_result)

        return final_answer