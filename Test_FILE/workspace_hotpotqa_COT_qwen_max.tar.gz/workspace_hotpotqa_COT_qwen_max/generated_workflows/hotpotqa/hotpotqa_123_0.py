# Workflow ID: hotpotqa_123_0
# Benchmark: hotpotqa
# Data Indices: [64]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key entities, relationships, and reasoning type
        extraction_instruction = (
            "Analyze the question and context documents to extract key entities, relationships, "
            "and determine the reasoning type (e.g., bridge, comparison, compositional). "
            "Identify potential 'bridge entities' or properties to compare. "
            "Output the results in a structured format."
        )
        extraction_result = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Select relevant documents
        selection_instruction = (
            f"Based on the extracted entities and relationships: {extraction_result}, "
            "identify which documents contain relevant information to answer the question. "
            "Provide a list of document indices or names along with brief justifications."
        )
        document_selection = await self.generate(instruction=selection_instruction, context=self.problem_text)

        # Step 3: Build reasoning chains
        reasoning_instruction = (
            f"Using the selected documents: {document_selection} and extracted entities: {extraction_result}, "
            "construct a reasoning chain that connects the information across documents. "
            "For bridge questions, identify how entities connect between documents. "
            "For comparison questions, highlight the properties being compared. "
            "For compositional questions, outline the steps to combine facts."
        )
        reasoning_chains = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Synthesize the answer
        synthesis_instruction = (
            f"Given the reasoning chains: {reasoning_chains}, synthesize a concise answer to the question. "
            "Ensure the answer is supported by specific sentences or facts from the documents. "
            "If there are multiple possible answers, evaluate and select the most accurate one."
        )
        answers = await asyncio.gather(
            self.generate(instruction=synthesis_instruction, context=self.problem_text),
            self.generate(instruction=synthesis_instruction, context=self.problem_text)  # Parallel generation for robustness
        )
        final_answer = await self.ensemble(instruction="Select the most accurate and well-supported answer.", contexts=answers)

        # Step 5: Validate and refine the answer
        refinement_instruction = (
            f"Validate the final answer: {final_answer} against the original question and context documents. "
            "Refine the answer if necessary to ensure precision and correctness."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        return refined_answer