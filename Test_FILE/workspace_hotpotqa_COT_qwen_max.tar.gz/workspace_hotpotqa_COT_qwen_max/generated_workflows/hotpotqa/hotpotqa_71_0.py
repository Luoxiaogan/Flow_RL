# Workflow ID: hotpotqa_71_0
# Benchmark: hotpotqa
# Data Indices: [310]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Identify the university associated with WRTI-FM
        instruction_identify_university = """
        Analyze the context documents and determine which university is associated with WRTI-FM. 
        Focus on mentions of WRTI-FM and any related universities. Provide the name of the university.
        """
        university_result = await self.generate(instruction=instruction_identify_university, context=self.problem_text)

        # Step 2: Identify the Baptist minister who founded the university
        instruction_identify_founder = f"""
        Based on the context documents, determine which Baptist minister founded the university named {university_result}. 
        Look for explicit mentions of the university's founding and the associated Baptist minister. Provide the name of the minister.
        """
        founder_result = await self.generate(instruction=instruction_identify_founder, context=self.problem_text)

        # Step 3: Construct the reasoning chain and finalize the answer
        reasoning_chain = f"""
        The question asks for the Baptist minister who founded the university where Bob Perkins joined WRTI-FM in 1997. 
        Step 1: Identified the university as {university_result}.
        Step 2: Determined that the Baptist minister who founded {university_result} is {founder_result}.
        Final Answer: {founder_result}.
        """

        # Optional: Revise the reasoning chain for clarity and correctness
        revised_reasoning = await self.revise(
            instruction="Ensure the reasoning chain is clear, logical, and free of errors.",
            context=reasoning_chain
        )

        # Return the final answer
        return revised_reasoning