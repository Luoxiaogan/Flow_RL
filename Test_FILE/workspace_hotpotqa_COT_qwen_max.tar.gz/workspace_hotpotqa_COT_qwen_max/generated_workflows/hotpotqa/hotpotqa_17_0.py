# Workflow ID: hotpotqa_17_0
# Benchmark: hotpotqa
# Data Indices: [180]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Parse the question to identify key entities and relationships
        question_parsing_instruction = """
        Analyze the question to identify the key entities and relationships. 
        Extract the main subject, the target information, and any intermediate entities required to answer the question. 
        Format the output as a JSON object with keys: 'main_entity', 'target_info', and 'intermediate_entities'.
        """
        parsed_question = await self.generate(instruction=question_parsing_instruction, context=self.problem_text)

        # Dynamically incorporate extracted entities into subsequent instructions
        import json
        parsed_data = json.loads(parsed_question)
        main_entity = parsed_data['main_entity']
        target_info = parsed_data['target_info']
        intermediate_entities = parsed_data['intermediate_entities']

        # Step 2: Filter documents to identify those relevant to the entities
        document_filtering_instruction = f"""
        Identify the documents that mention the following entities: {main_entity}, {', '.join(intermediate_entities)}.
        Provide a list of document indices that are relevant to answering the question.
        """
        relevant_documents = await self.generate(instruction=document_filtering_instruction, context=self.problem_text)

        # Step 3: Summarize relevant information from the filtered documents
        summarization_tasks = []
        for doc_index in json.loads(relevant_documents):
            summarization_instruction = f"""
            Summarize the information in Document {doc_index} related to the entities: {main_entity}, {', '.join(intermediate_entities)}.
            Focus on facts that help answer the question: {self.problem_text}.
            """
            summarization_tasks.append(self.summarize(instruction=summarization_instruction, context=self.problem_text))

        summaries = await asyncio.gather(*summarization_tasks)

        # Step 4: Construct the reasoning chain and extract the answer
        reasoning_instruction = f"""
        Based on the following summaries, construct a reasoning chain to answer the question: {self.problem_text}.
        Use the entities and relationships identified earlier: main_entity={main_entity}, target_info={target_info}, intermediate_entities={intermediate_entities}.
        Provide the final answer in a clear and concise format.
        """
        reasoning_chain = await self.generate(instruction=reasoning_instruction, context="\n".join(summaries))

        # Step 5: Refine the extracted answer for precision
        refinement_instruction = """
        Review the reasoning chain and ensure the extracted answer is accurate and directly addresses the question.
        If necessary, refine the answer to improve clarity and correctness.
        """
        final_answer = await self.revise(instruction=refinement_instruction, context=reasoning_chain)

        return final_answer