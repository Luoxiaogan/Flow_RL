# Workflow ID: hotpotqa_290_0
# Benchmark: hotpotqa
# Data Indices: [71]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract entities and key terms from the question
        entity_extraction_instruction = """
        Analyze the question and extract all key entities, terms, and phrases that are likely to appear in the relevant documents. 
        Focus on proper nouns (e.g., names of places, roads, companies), numerical values, and any specific descriptors. 
        Return the extracted entities as a comma-separated list.
        """
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Identify relevant documents
        document_selection_instruction = f"""
        Given the extracted entities: {entities}, identify which documents contain information relevant to these entities. 
        For each document, determine if it contains any of the extracted entities or closely related terms. 
        Return a list of document indices (0-based) that are relevant to the question.
        """
        relevant_documents = await self.generate(instruction=document_selection_instruction, context=self.problem_text)

        # Step 3: Detect bridge entities
        bridge_entity_detection_instruction = f"""
        Using the relevant documents ({relevant_documents}) and the extracted entities ({entities}), identify "bridge entities" 
        that connect multiple documents. A bridge entity is a common entity or concept that appears in more than one document 
        and helps link information together. Return the bridge entities as a comma-separated list.
        """
        bridge_entities = await self.generate(instruction=bridge_entity_detection_instruction, context=self.problem_text)

        # Step 4: Construct reasoning chains
        reasoning_chain_instruction = f"""
        Using the relevant documents ({relevant_documents}) and the bridge entities ({bridge_entities}), construct a logical 
        reasoning chain that connects the information across documents to answer the question. Start with the question, 
        identify the key facts from each document, and explain how they lead to the answer. Provide the reasoning chain as 
        a step-by-step explanation.
        """
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 5: Refine the reasoning chain
        refinement_instruction = """
        Review the reasoning chain and ensure it is clear, logical, and complete. If there are any gaps or ambiguities, 
        revise the chain to address them. Return the refined reasoning chain.
        """
        refined_reasoning_chain = await self.revise(instruction=refinement_instruction, context=reasoning_chain)

        # Step 6: Extract the final answer
        answer_extraction_instruction = f"""
        Based on the refined reasoning chain ({refined_reasoning_chain}), extract the final answer to the question. 
        Ensure the answer is concise and directly addresses the question. If the answer is a short text span, return it verbatim. 
        If the answer requires synthesis, provide a brief summary.
        """
        final_answer = await self.generate(instruction=answer_extraction_instruction, context=self.problem_text)

        return final_answer