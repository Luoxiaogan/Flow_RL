# Workflow ID: hotpotqa_169_0
# Benchmark: hotpotqa
# Data Indices: [11]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Parse the question to identify key entities and target information
        question_analysis = await self.generate(
            instruction="Analyze the question to identify key entities (e.g., names, places) and the specific information being asked. "
                        "Return the entities and the type of information requested in JSON format.",
            context=self.problem_text
        )
        import json
        question_data = json.loads(question_analysis)
        entities = question_data.get("entities", [])
        target_info = question_data.get("target_info", "")

        # Step 2: Identify relevant documents containing the entities
        document_selection_tasks = [
            self.generate(
                instruction=f"Determine if the document contains information about {entity}. "
                            "If yes, summarize the relevant sentences.",
                context=doc
            )
            for entity in entities for doc in self.problem_text.split("\n\n")  # Assuming documents are separated by double newlines
        ]
        document_results = await asyncio.gather(*document_selection_tasks)
        relevant_documents = [result for result in document_results if result.strip()]

        # Step 3: Identify bridge entities and relationships
        bridge_entity_identification = await self.generate(
            instruction=f"Identify any 'bridge entities' that connect the key entities ({', '.join(entities)}). "
                        "Explain how these entities are related and which documents support these relationships.",
            context="\n".join(relevant_documents)
        )

        # Step 4: Extract supporting facts and synthesize the answer
        fact_extraction = await self.generate(
            instruction=f"Extract all supporting facts from the relevant documents that help answer the question. "
                        f"Synthesize these facts into a concise response addressing the target information ({target_info}).",
            context=bridge_entity_identification
        )

        # Step 5: Validate and refine the final answer
        final_answer = await self.revise(
            instruction="Ensure the answer directly addresses the question and is supported by the extracted facts. "
                        "Refine the response if necessary.",
            context=fact_extraction
        )

        return final_answer