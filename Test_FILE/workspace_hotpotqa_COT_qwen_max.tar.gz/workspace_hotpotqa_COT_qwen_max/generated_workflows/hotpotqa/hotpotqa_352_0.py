# Workflow ID: hotpotqa_352_0
# Benchmark: hotpotqa
# Data Indices: [234]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract Relevant Documents
        relevant_docs_instruction = """
        Analyze the provided context documents and identify which ones contain information about the album "The Grind Date" by De La Soul.
        Focus on documents that mention details such as the album's release date, producers, or related collaborations.
        Return a list of document numbers and brief summaries of their relevant content.
        """
        relevant_docs = await self.generate(instruction=relevant_docs_instruction, context=self.problem_text)

        # Step 2: Identify the Producer of "The Grind Date"
        producer_instruction = f"""
        Based on the following extracted information about "The Grind Date": {relevant_docs}
        Identify the name of the producer associated with this album. Ensure the producer is explicitly linked to the album in the text.
        If multiple producers are mentioned, prioritize the one described as California-based.
        Return the name of the producer.
        """
        producer_name = await self.generate(instruction=producer_instruction, context=self.problem_text)

        # Step 3: Resolve the Real Name of the Producer
        real_name_instruction = f"""
        Using the provided context documents, find the real name of the person identified as "{producer_name}".
        Look for explicit statements about their real name, aliases, or biographical details.
        Return the real name of the producer.
        """
        real_name = await self.generate(instruction=real_name_instruction, context=self.problem_text)

        # Step 4: Refine the Answer
        refine_instruction = f"""
        Review the following extracted real name: {real_name}.
        Ensure it is concise, accurate, and formatted appropriately.
        If necessary, correct any errors or inconsistencies.
        Return the refined answer.
        """
        refined_answer = await self.revise(instruction=refine_instruction, context=real_name)

        # Step 5: Ensemble for Final Decision (if needed)
        ensemble_instruction = """
        Evaluate the following candidate answers and select the most accurate one.
        Criteria for selection include relevance to the question, factual correctness, and clarity.
        """
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[refined_answer])

        return final_answer