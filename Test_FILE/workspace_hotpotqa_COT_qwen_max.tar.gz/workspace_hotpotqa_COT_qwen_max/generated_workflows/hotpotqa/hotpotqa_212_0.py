# Workflow ID: hotpotqa_212_0
# Benchmark: hotpotqa
# Data Indices: [329]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio
        
        # Step 1: Parse the question to identify key entities and intent
        question_analysis = await self.generate(
            instruction="Analyze the question to identify key entities and what is being asked. "
                        "Extract all named entities and describe the type of reasoning required (e.g., bridge, comparison).",
            context=self.problem_text
        )
        
        # Step 2: Identify relevant documents and resolve entities
        entity_candidates = await self.generate(
            instruction=f"Based on the analysis: {question_analysis}, "
                        "identify all mentions of the key entities across the provided documents. "
                        "For each mention, note the document and context.",
            context=self.problem_text
        )
        
        # Use Ensemble to select the most relevant entity and document
        relevant_entity = await self.ensemble(
            instruction="From the list of entity candidates, determine which entity is most relevant to the question. "
                        "Consider the context and the relationships between entities.",
            contexts=[entity_candidates]
        )
        
        # Step 3: Extract information about the award and its history
        award_info = await self.generate(
            instruction=f"Given the relevant entity: {relevant_entity}, "
                        "find the document that provides information about the award mentioned in the question. "
                        "Extract details about the award's origin and history.",
            context=self.problem_text
        )
        
        # Step 4: Perform multi-hop reasoning to connect the facts
        reasoning_chain = await self.generate(
            instruction=f"Using the following information: {award_info}, "
                        "connect the facts to answer the question. "
                        "Ensure the reasoning chain is explicit and logical.",
            context=self.problem_text
        )
        
        # Step 5: Validate and refine the reasoning chain
        refined_reasoning = await self.revise(
            instruction="Review the reasoning chain for accuracy and completeness. "
                        "Ensure all steps are logically sound and supported by the documents.",
            context=reasoning_chain
        )
        
        # Step 6: Extract the final answer
        final_answer = await self.generate(
            instruction=f"Based on the refined reasoning: {refined_reasoning}, "
                        "extract the precise answer to the question. "
                        "Ensure the answer is concise and directly addresses the question.",
            context=self.problem_text
        )
        
        return final_answer