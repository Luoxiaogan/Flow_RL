# Workflow ID: hotpotqa_348_0
# Benchmark: hotpotqa
# Data Indices: [114]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract entities and relationships
        entity_extraction_instruction = (
            "Extract all key entities, relationships, and potential bridge entities from the question and context documents. "
            "Identify how these entities might connect across different documents. "
            "Provide the output in a structured format, listing entities and their relationships."
        )
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Select relevant documents
        document_selection_instruction = (
            f"Based on the extracted entities and relationships: {entities}, "
            "identify which documents are most relevant to answering the question. "
            "Provide a list of relevant document titles or identifiers."
        )
        relevant_documents = await self.generate(instruction=document_selection_instruction, context=self.problem_text)

        # Step 3: Construct reasoning chain
        reasoning_chain_instruction = (
            f"Using the relevant documents: {relevant_documents}, "
            "construct a reasoning chain that connects the information across documents. "
            "Ensure each step logically follows from the previous one. "
            "Provide the reasoning chain as a step-by-step explanation."
        )
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 4: Extract answer
        answer_extraction_instruction = (
            f"Based on the reasoning chain: {reasoning_chain}, "
            "extract the precise answer to the question from the relevant documents. "
            "Ensure the answer is concise and directly addresses the question."
        )
        answer = await self.summarize(instruction=answer_extraction_instruction, context=self.problem_text)

        # Step 5: Validate and refine answer
        validation_instruction = (
            f"Validate the extracted answer: {answer} against the question. "
            "Critique and refine the answer if necessary. "
            "Ensure the final answer is accurate and complete."
        )
        refined_answer = await self.revise(instruction=validation_instruction, context=self.problem_text)

        return refined_answer