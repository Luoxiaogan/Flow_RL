# Workflow ID: hotpotqa_239_0
# Benchmark: hotpotqa
# Data Indices: [378]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract entities and relationships
        entity_extraction_instruction = """
        Extract all key entities (e.g., films, people, organizations) and relationships mentioned in the question and context documents. 
        Focus on identifying entities that are likely to be connected across multiple documents. 
        Format the output as a JSON object with keys "entities" and "relationships".
        """
        entity_extraction = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Filter relevant documents
        document_filtering_instruction = f"""
        Based on the extracted entities and relationships ({entity_extraction}), identify which documents are relevant to answering the question. 
        Provide a list of document indices or titles that contain information about the extracted entities or relationships.
        """
        relevant_documents = await self.generate(instruction=document_filtering_instruction, context=self.problem_text)

        # Step 3: Construct reasoning chain
        reasoning_chain_instruction = f"""
        Using the relevant documents ({relevant_documents}) and the extracted entities/relationships ({entity_extraction}), construct a reasoning chain that connects the information across documents. 
        Explicitly state how entities are related and how the information flows from one document to another. 
        Format the output as a step-by-step explanation.
        """
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 4: Synthesize the answer
        answer_synthesis_instruction = f"""
        Based on the reasoning chain ({reasoning_chain}), extract the precise answer to the question. 
        Ensure the answer is concise and directly addresses the question. 
        If the question requires a yes/no answer or a short factual response, provide it explicitly.
        """
        synthesized_answer = await self.summarize(instruction=answer_synthesis_instruction, context=reasoning_chain)

        # Step 5: Validate and refine the answer
        refinement_instruction = f"""
        Critique and refine the synthesized answer ({synthesized_answer}) to ensure it is accurate, well-supported, and directly answers the question. 
        If necessary, revise the answer to improve clarity or correctness.
        """
        final_answer = await self.revise(instruction=refinement_instruction, context=synthesized_answer)

        return final_answer