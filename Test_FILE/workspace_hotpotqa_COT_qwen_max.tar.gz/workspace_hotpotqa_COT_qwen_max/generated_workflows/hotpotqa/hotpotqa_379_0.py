# Workflow ID: hotpotqa_379_0
# Benchmark: hotpotqa
# Data Indices: [307]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Identify key entities in the question
        entity_instruction = """
        Analyze the question to identify the key entities mentioned. 
        These entities could be people, organizations, locations, or other relevant nouns. 
        Return the entities as a comma-separated list.
        """
        entities = await self.generate(instruction=entity_instruction, context=self.problem_text)

        # Step 2: Select relevant documents containing the entities
        doc_selection_instruction = f"""
        Analyze the provided context documents to find mentions of the following entities: {entities}.
        Return the indices or names of the documents that contain these entities.
        """
        relevant_docs = await self.generate(instruction=doc_selection_instruction, context=self.problem_text)

        # Step 3: Identify bridge entities connecting the key entities
        bridge_instruction = f"""
        From the relevant documents ({relevant_docs}), identify any "bridge entities" that connect the key entities ({entities}).
        A bridge entity is something that links two or more entities together, such as a shared organization, location, or event.
        Return the bridge entity and explain how it connects the key entities.
        """
        bridge_entity = await self.generate(instruction=bridge_instruction, context=self.problem_text)

        # Step 4: Construct the reasoning chain using the bridge entity
        reasoning_instruction = f"""
        Using the bridge entity ({bridge_entity}) and the relevant documents ({relevant_docs}), construct a reasoning chain that connects the key entities ({entities}).
        The reasoning chain should explain how the entities are related through the bridge entity and lead to the answer to the question.
        """
        reasoning_chain = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 5: Extract the final answer from the reasoning chain
        answer_instruction = f"""
        Based on the reasoning chain ({reasoning_chain}), extract the precise answer to the question.
        The answer should be concise and directly address the question.
        """
        final_answer = await self.generate(instruction=answer_instruction, context=self.problem_text)

        return final_answer