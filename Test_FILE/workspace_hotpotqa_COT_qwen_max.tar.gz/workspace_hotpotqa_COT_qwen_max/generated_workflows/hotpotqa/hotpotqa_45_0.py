# Workflow ID: hotpotqa_45_0
# Benchmark: hotpotqa
# Data Indices: [195]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Analyze the question to identify entities and reasoning type
        analysis_instruction = (
            "Analyze the question to identify the key entities and the type of reasoning required. "
            "Key entities include names, places, or concepts mentioned in the question. "
            "The reasoning type can be bridge, comparison, or compositional. "
            "Output the entities and reasoning type in a structured format."
        )
        analysis_result = await self.generate(instruction=analysis_instruction, context=self.problem_text)

        # Step 2: Select relevant documents based on identified entities
        selection_instruction = (
            f"Given the identified entities: {analysis_result}, analyze each document to determine "
            "which ones are most relevant to the question. Relevance is determined by the presence "
            "of the key entities or closely related information. Output a list of relevant documents."
        )
        documents = [f"Document {i+1}" for i in range(10)]  # Example: 10 documents
        selection_results = await asyncio.gather(
            *[self.generate(instruction=selection_instruction, context=doc) for doc in documents]
        )
        relevant_documents = [doc for doc, result in zip(documents, selection_results) if "relevant" in result.lower()]

        # Step 3: Identify the bridge entity (if applicable)
        bridge_instruction = (
            f"Given the relevant documents: {relevant_documents}, identify the bridge entity "
            "that connects multiple documents. The bridge entity is typically a shared concept, person, "
            "or event. Output the bridge entity and its role in connecting the documents."
        )
        bridge_entity = await self.generate(instruction=bridge_instruction, context="\n".join(relevant_documents))

        # Step 4: Construct the reasoning chain
        reasoning_instruction = (
            f"Using the bridge entity: {bridge_entity}, construct a reasoning chain that connects "
            "the relevant documents. The reasoning chain should explicitly track how information flows "
            "from one document to another through the bridge entity. Output the reasoning chain."
        )
        reasoning_chain = await self.generate(instruction=reasoning_instruction, context="\n".join(relevant_documents))

        # Step 5: Extract the final answer
        extraction_instruction = (
            f"Given the reasoning chain: {reasoning_chain}, extract the precise answer to the question. "
            "The answer should be a short text span, such as an entity name, phrase, or factual statement. "
            "Ensure the answer directly addresses the question."
        )
        final_answer = await self.summarize(instruction=extraction_instruction, context=reasoning_chain)

        # Step 6: Validate and refine the answer
        refinement_instruction = (
            f"Validate the answer: {final_answer} by cross-referencing it with the original documents. "
            "If necessary, refine the answer to ensure accuracy and conciseness."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=self.problem_text)

        return refined_answer