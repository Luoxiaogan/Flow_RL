# Workflow ID: hotpotqa_346_0
# Benchmark: hotpotqa
# Data Indices: [130]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Analyze the question to identify entities and reasoning type
        question_analysis = await self.generate(
            instruction="""Analyze the question to determine the reasoning type (bridge, comparison, compositional). 
            Identify all entities mentioned in the question and their potential relationships. 
            Provide a detailed breakdown of the entities and the type of reasoning required.""",
            context=self.problem_text
        )

        # Step 2: Select relevant documents and summarize their content
        document_summaries = await asyncio.gather(
            self.generate(
                instruction=f"Summarize the content of Document 1 in relation to the question. Focus on entities and facts relevant to: {question_analysis}",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"Summarize the content of Document 2 in relation to the question. Focus on entities and facts relevant to: {question_analysis}",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"Summarize the content of Document 3 in relation to the question. Focus on entities and facts relevant to: {question_analysis}",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"Summarize the content of Document 4 in relation to the question. Focus on entities and facts relevant to: {question_analysis}",
                context=self.problem_text
            )
        )

        # Step 3: Detect bridge entities and synthesize information
        bridge_entity_detection = await self.ensemble(
            instruction=f"Identify shared entities or concepts between the following document summaries. Synthesize the information to detect the bridge entity: {question_analysis}",
            contexts=document_summaries
        )

        # Step 4: Generate the final answer
        final_answer = await self.generate(
            instruction=f"Based on the detected bridge entity and the synthesized information, construct the final answer to the question. Ensure the answer is concise and directly addresses the question: {question_analysis}",
            context=bridge_entity_detection
        )

        # Step 5: Validate and refine the answer
        refined_answer = await self.revise(
            instruction="Critique and refine the generated answer. Ensure it is accurate, complete, and directly addresses the question.",
            context=final_answer
        )

        return refined_answer