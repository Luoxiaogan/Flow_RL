# Workflow ID: hotpotqa_335_0
# Benchmark: hotpotqa
# Data Indices: [236]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Analyze the question and extract key entities
        entity_analysis = await self.generate(
            instruction="Analyze the question and extract all key entities and their relationships. "
                        "Focus on identifying the main subject (e.g., person, show) and what is being asked. "
                        "Provide the output as a structured summary.",
            context=self.problem_text
        )

        # Step 2: Identify relevant documents
        doc_analysis_tasks = []
        for i in range(1, 11):  # Assuming 10 context documents
            doc_context = f"Document {i}: [CONTENT OF DOCUMENT {i}]"  # Replace with actual document content
            task = self.generate(
                instruction=f"Determine if this document is relevant to the question. "
                            f"Use the extracted entities: {entity_analysis}. "
                            f"Focus on whether the document mentions the key entities or related concepts. "
                            f"Provide a binary relevance score (Relevant/Not Relevant) and a brief justification.",
                context=doc_context
            )
            doc_analysis_tasks.append(task)
        
        doc_relevance_results = await asyncio.gather(*doc_analysis_tasks)

        # Step 3: Extract information from relevant documents
        relevant_docs = []
        for i, result in enumerate(doc_relevance_results):
            if "Relevant" in result:  # Check relevance score
                relevant_docs.append(f"Document {i+1}: [CONTENT OF DOCUMENT {i+1}]")  # Replace with actual content

        info_extraction_tasks = []
        for doc in relevant_docs:
            task = self.generate(
                instruction=f"Extract information from this document that relates to the question. "
                            f"Focus on the key entities: {entity_analysis}. "
                            f"Provide the extracted information in a structured format.",
                context=doc
            )
            info_extraction_tasks.append(task)
        
        extracted_info = await asyncio.gather(*info_extraction_tasks)

        # Step 4: Synthesize information across documents
        synthesized_info = await self.ensemble(
            instruction="Synthesize the extracted information from multiple documents to build a reasoning chain. "
                        "Connect the dots between entities and facts to derive the final answer. "
                        "Ensure the reasoning is clear and logical.",
            contexts=extracted_info
        )

        # Step 5: Extract and refine the final answer
        final_answer = await self.generate(
            instruction="Extract the final answer from the synthesized information. "
                        "Ensure the answer is concise and directly addresses the question.",
            context=synthesized_info
        )

        refined_answer = await self.revise(
            instruction="Refine the final answer to ensure accuracy and clarity. "
                        "Cross-check it against the original question and context documents.",
            context=final_answer
        )

        return refined_answer