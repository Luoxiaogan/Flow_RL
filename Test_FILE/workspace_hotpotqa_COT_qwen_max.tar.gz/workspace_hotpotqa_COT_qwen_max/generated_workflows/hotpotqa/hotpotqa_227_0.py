# Workflow ID: hotpotqa_227_0
# Benchmark: hotpotqa
# Data Indices: [377]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Parse the question to identify key entities and reasoning type
        question_analysis = await self.generate(
            instruction="Analyze the question to identify key entities and determine the reasoning type (bridge, comparison, or compositional). "
                        "Provide a structured output including the entities and reasoning type.",
            context=self.problem_text
        )

        # Step 2: Identify relevant documents based on key entities
        document_selection = await self.generate(
            instruction=f"Given the key entities identified in the question ({question_analysis}), "
                        "identify which documents contain relevant information. "
                        "Provide a list of relevant document indices and explain why they are relevant.",
            context=self.problem_text
        )

        # Step 3: Extract relevant information from selected documents
        extraction_tasks = []
        for doc_idx in range(10):  # Assuming up to 10 documents
            extraction_tasks.append(
                self.generate(
                    instruction=f"Extract information related to the key entities ({question_analysis}) "
                                f"from Document {doc_idx + 1}. Focus on facts that could help answer the question.",
                    context=self.problem_text
                )
            )
        document_extractions = await asyncio.gather(*extraction_tasks)

        # Step 4: Synthesize information to build a reasoning chain
        reasoning_chain = await self.ensemble(
            instruction="Combine the extracted information from the documents to form a reasoning chain. "
                        "Ensure the chain connects all key entities and leads to the answer.",
            contexts=document_extractions
        )

        # Step 5: Generate the final answer
        final_answer = await self.generate(
            instruction=f"Based on the reasoning chain ({reasoning_chain}), provide the final answer to the question. "
                        "Ensure the answer is concise and directly addresses the question.",
            context=self.problem_text
        )

        # Step 6: Validate and refine the answer
        refined_answer = await self.revise(
            instruction="Review the final answer for factual correctness and relevance to the question. "
                        "Make any necessary refinements to improve clarity and accuracy.",
            context=final_answer
        )

        return refined_answer