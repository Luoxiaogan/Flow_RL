# Workflow ID: hotpotqa_386_0
# Benchmark: hotpotqa
# Data Indices: [322]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Analyze the question to identify key entities and reasoning type
        question_analysis = await self.generate(
            instruction="Analyze the question to identify key entities (e.g., names, bands, roles) and the type of reasoning required (e.g., bridge entity, comparison). "
                        "Provide a structured summary of the findings.",
            context=self.problem_text
        )

        # Step 2: Evaluate which documents are relevant to the identified entities
        document_selections = await asyncio.gather(
            self.generate(instruction=f"Based on the analysis: {question_analysis}, determine if Document 1 contains relevant information.", context=self.problem_text),
            self.generate(instruction=f"Based on the analysis: {question_analysis}, determine if Document 2 contains relevant information.", context=self.problem_text),
            self.generate(instruction=f"Based on the analysis: {question_analysis}, determine if Document 3 contains relevant information.", context=self.problem_text),
            self.generate(instruction=f"Based on the analysis: {question_analysis}, determine if Document 4 contains relevant information.", context=self.problem_text),
            self.generate(instruction=f"Based on the analysis: {question_analysis}, determine if Document 5 contains relevant information.", context=self.problem_text),
            self.generate(instruction=f"Based on the analysis: {question_analysis}, determine if Document 6 contains relevant information.", context=self.problem_text),
            self.generate(instruction=f"Based on the analysis: {question_analysis}, determine if Document 7 contains relevant information.", context=self.problem_text),
            self.generate(instruction=f"Based on the analysis: {question_analysis}, determine if Document 8 contains relevant information.", context=self.problem_text),
            self.generate(instruction=f"Based on the analysis: {question_analysis}, determine if Document 9 contains relevant information.", context=self.problem_text),
            self.generate(instruction=f"Based on the analysis: {question_analysis}, determine if Document 10 contains relevant information.", context=self.problem_text)
        )
        relevant_documents = await self.ensemble(
            instruction="Evaluate the relevance of each document based on the provided assessments. Select only the most relevant documents.",
            contexts=document_selections
        )

        # Step 3: Extract relationships between entities from relevant documents
        entity_extraction = await self.generate(
            instruction=f"From the relevant documents: {relevant_documents}, extract relationships between key entities (e.g., 'Kelly Conlon was a bass player for Death'). "
                        "Track mentions of these entities across documents and summarize their connections.",
            context=self.problem_text
        )

        # Step 4: Construct the reasoning chain to answer the question
        reasoning_chain = await self.generate(
            instruction=f"Using the extracted relationships: {entity_extraction}, construct a reasoning chain that connects the information to answer the question. "
                        "Ensure the reasoning is logical and explicitly links all necessary entities and facts.",
            context=self.problem_text
        )

        # Step 5: Refine the answer for clarity and precision
        refined_answer = await self.revise(
            instruction="Refine the reasoning chain to produce a concise, accurate, and direct answer to the question. "
                        "Ensure the answer is in the expected format (e.g., short text span, yes/no, factual response).",
            context=reasoning_chain
        )

        return refined_answer