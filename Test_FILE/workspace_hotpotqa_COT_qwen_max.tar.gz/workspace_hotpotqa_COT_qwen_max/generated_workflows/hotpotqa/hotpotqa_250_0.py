# Workflow ID: hotpotqa_250_0
# Benchmark: hotpotqa
# Data Indices: [108]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key entities from the question
        entity_extraction_instruction = (
            "Identify all key entities mentioned in the question. "
            "Focus on proper nouns such as names of people, movies, or organizations. "
            "Return the entities as a comma-separated list."
        )
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Select relevant documents based on the extracted entities
        select_documents_instruction = (
            f"Analyze each document and determine which ones are relevant to the entities: {entities}. "
            "A document is relevant if it directly mentions or provides information about any of the entities. "
            "Return the indices of the relevant documents as a comma-separated list."
        )
        relevant_documents = await self.generate(instruction=select_documents_instruction, context=self.problem_text)

        # Convert relevant_documents string to a list of indices
        relevant_document_indices = [int(idx.strip()) for idx in relevant_documents.split(",")]

        # Step 3: Analyze relevant documents to find the bridge entity
        bridge_entity_tasks = []
        for idx in relevant_document_indices:
            bridge_entity_instruction = (
                f"Analyze Document {idx} to find any entities that connect the key entities: {entities}. "
                "For example, if the question asks about a musician related to a movie, identify the musician. "
                "Return the connecting entity name."
            )
            bridge_entity_tasks.append(self.generate(instruction=bridge_entity_instruction, context=self.problem_text))

        # Run bridge entity analysis in parallel
        bridge_entities = await asyncio.gather(*bridge_entity_tasks)

        # Step 4: Extract properties of the bridge entity
        property_extraction_tasks = []
        for entity in bridge_entities:
            property_extraction_instruction = (
                f"Extract the nationality or other relevant properties of the entity: {entity}. "
                "If the property is not explicitly mentioned, infer it based on contextual clues. "
                "Return the property as a single phrase."
            )
            property_extraction_tasks.append(self.generate(instruction=property_extraction_instruction, context=self.problem_text))

        # Run property extraction in parallel
        properties = await asyncio.gather(*property_extraction_tasks)

        # Step 5: Synthesize the final answer
        synthesize_instruction = (
            f"Synthesize the following properties into a concise answer: {properties}. "
            "Ensure the answer directly addresses the original question. "
            "Return the final answer as a single sentence."
        )
        final_answer = await self.summarize(instruction=synthesize_instruction, context=self.problem_text)

        return final_answer