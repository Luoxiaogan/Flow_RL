# Workflow ID: hotpotqa_197_0
# Benchmark: hotpotqa
# Data Indices: [373]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Parse the question to identify key entities and relationships
        question_analysis = await self.generate(
            instruction="Analyze the question to identify key entities and their relationships. "
                        "Extract specific details such as names, dates, or roles mentioned in the question. "
                        "Focus on understanding what information needs to be found and how entities are connected.",
            context=self.problem_text
        )

        # Step 2: Extract information about the predecessor (politician born on 4 October 1947)
        predecessor_info = await self.generate(
            instruction=f"Based on the analysis: {question_analysis}, "
                        "find the politician born on 4 October 1947. "
                        "Extract all relevant information about this politician, including their name, role, and any mention of succession.",
            context=self.problem_text
        )

        # Step 3: Identify the successor and extract their birth date
        successor_info = await self.generate(
            instruction=f"Based on the predecessor information: {predecessor_info}, "
                        "identify the politician who succeeded them. "
                        "Extract all relevant information about this successor, including their name and birth date.",
            context=self.problem_text
        )

        # Step 4: Construct the reasoning chain and synthesize the answer
        reasoning_chain = await self.ensemble(
            instruction="Combine the information about the predecessor and successor into a coherent reasoning chain. "
                        "Ensure the connection between the two entities is clear and logical. "
                        "Synthesize the final answer based on the extracted information.",
            contexts=[predecessor_info, successor_info]
        )

        # Step 5: Refine the answer for clarity and precision
        final_answer = await self.revise(
            instruction="Refine the synthesized answer to ensure it is concise, precise, and directly addresses the question. "
                        "Remove any unnecessary details while retaining key information.",
            context=reasoning_chain
        )

        return final_answer