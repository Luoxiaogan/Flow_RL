# Workflow ID: hotpotqa_236_0
# Benchmark: hotpotqa
# Data Indices: [214]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key entities and relationships from the question
        entity_extraction_instruction = """
        Analyze the question and identify all key entities and their relationships. 
        Focus on entities that are likely to appear in the context documents. 
        Provide a structured list of these entities and their roles in the question.
        """
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Summarize relevant information from each document
        summarize_instruction_template = f"""
        Given the following entities and their relationships: {entities}
        Extract and summarize all information from the document that is relevant to these entities. 
        Ensure the summary includes specific facts, dates, or relationships that could help answer the question.
        """
        summaries = await asyncio.gather(
            *[self.summarize(instruction=summarize_instruction_template, context=doc) for doc in self.config['context_documents']]
        )

        # Step 3: Build reasoning chains by connecting summaries
        reasoning_instruction = f"""
        Using the summaries of the documents provided, construct a reasoning chain that connects the key entities ({entities}) 
        to answer the question. Explicitly mention how the information from different documents supports the reasoning process. 
        Ensure the chain is logical and complete.
        """
        reasoning_chain = await self.generate(instruction=reasoning_instruction, context="\n".join(summaries))

        # Step 4: Refine the reasoning chain into a concise answer
        refine_instruction = """
        Based on the reasoning chain, extract the final answer to the question. 
        Ensure the answer is concise, precise, and directly addresses the question. 
        If the question asks for a span of years, provide the exact range. If it's a yes/no question, provide the correct response.
        """
        final_answer = await self.revise(instruction=refine_instruction, context=reasoning_chain)

        return final_answer