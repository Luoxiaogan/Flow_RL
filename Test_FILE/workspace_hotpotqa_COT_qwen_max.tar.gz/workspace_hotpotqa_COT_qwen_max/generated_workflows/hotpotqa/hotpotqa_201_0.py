# Workflow ID: hotpotqa_201_0
# Benchmark: hotpotqa
# Data Indices: [196]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract information about "Superfast!" and the franchise it parodies
        instruction_superfast = (
            "Extract all information about the film 'Superfast!' from the context documents. "
            "Focus on details about what it parodies and any related entities."
        )
        instruction_franchise = (
            "Extract all information about franchises or films described as involving "
            "'illegal street racing and heists' from the context documents. "
            "Include details about their characteristics and names."
        )

        # Parallel extraction
        superfast_info, franchise_info = await asyncio.gather(
            self.generate(instruction=instruction_superfast, context=self.problem_text),
            self.generate(instruction=instruction_franchise, context=self.problem_text)
        )

        # Step 2: Identify the bridge entity
        instruction_bridge = (
            f"Given the following information:\n"
            f"Details about 'Superfast!': {superfast_info}\n"
            f"Details about potential franchises: {franchise_info}\n"
            "Identify the franchise that 'Superfast!' parodies. "
            "Provide reasoning for your choice."
        )
        bridge_entity = await self.generate(instruction=instruction_bridge, context=self.problem_text)

        # Step 3: Summarize the reasoning chain and extract the answer
        instruction_summary = (
            f"Based on the reasoning:\n{bridge_entity}\n"
            "Summarize the name of the franchise that 'Superfast!' parodies. "
            "Ensure the answer is concise and directly addresses the question."
        )
        final_answer = await self.summarize(instruction=instruction_summary, context=bridge_entity)

        return final_answer