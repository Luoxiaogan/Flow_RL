# Workflow ID: hotpotqa_81_0
# Benchmark: hotpotqa
# Data Indices: [348]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract mentions of entities from the context documents
        entities = ["Chenango Canal", "Texas Irrigation Canals"]
        extraction_tasks = [
            self.generate(
                instruction=f"Extract all sentences or paragraphs from the context documents that mention '{entity}'. "
                            f"Focus on details about the location or geographical context of '{entity}'.",
                context=self.problem_text
            )
            for entity in entities
        ]
        extracted_info = await asyncio.gather(*extraction_tasks)

        # Step 2: Analyze extracted information to infer the country
        analysis_tasks = [
            self.generate(
                instruction=f"Based on the following extracted information: {info}\n"
                            f"Determine the country where '{entities[i]}' is located. "
                            f"If the country is not explicitly mentioned, infer it based on geographical or contextual clues.",
                context=self.problem_text
            )
            for i, info in enumerate(extracted_info)
        ]
        analysis_results = await asyncio.gather(*analysis_tasks)

        # Step 3: Synthesize the final answer using Ensemble
        final_answer = await self.ensemble(
            instruction="Combine the following analyses to determine the countries where the entities are located. "
                        "Ensure the answer is consistent and concise.",
            contexts=analysis_results
        )

        # Step 4 (Optional): Refine the answer if needed
        refined_answer = await self.revise(
            instruction="Review the following answer and refine it if necessary. "
                        "Ensure it directly addresses the question and is free of ambiguity.",
            context=final_answer
        )

        return refined_answer