# Workflow ID: hotpotqa_228_0
# Benchmark: hotpotqa
# Data Indices: [285]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Parse the question and extract key entities
        question_analysis = await self.generate(
            instruction="Analyze the question to identify key entities, concepts, and the type of information being requested. "
                        "Provide a structured output listing these components.",
            context=self.problem_text
        )

        # Step 2: Identify relevant documents
        document_tasks = []
        for i in range(1, 11):  # Assuming 10 documents as per the example
            doc_context = f"Document {i}: [Content of Document {i}]"
            task = self.generate(
                instruction=f"Given the extracted entities: {question_analysis}, determine if this document contains relevant information. "
                            "Provide a brief explanation of relevance or lack thereof.",
                context=doc_context
            )
            document_tasks.append(task)
        
        document_relevance = await asyncio.gather(*document_tasks)

        # Step 3: Detect bridge entities
        bridge_entity_candidates = await self.ensemble(
            instruction="Evaluate the provided document relevance analyses to identify potential bridge entities "
                        "that connect information across multiple documents. Provide a ranked list of candidates.",
            contexts=document_relevance
        )

        # Step 4: Construct the reasoning chain
        reasoning_chain = await self.generate(
            instruction=f"Using the identified bridge entity: {bridge_entity_candidates}, synthesize information "
                        "from the relevant documents to construct a reasoning chain that answers the question. "
                        "Ensure the chain is logically coherent and explicitly connects all entities.",
            context=self.problem_text
        )

        # Step 5: Extract the final answer
        final_answer = await self.summarize(
            instruction="Condense the reasoning chain into a concise answer that directly addresses the question. "
                        "Ensure the answer is precise and includes only the necessary information.",
            context=reasoning_chain
        )

        return final_answer