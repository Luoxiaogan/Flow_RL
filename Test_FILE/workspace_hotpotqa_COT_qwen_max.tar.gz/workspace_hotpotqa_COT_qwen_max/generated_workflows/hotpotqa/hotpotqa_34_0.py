# Workflow ID: hotpotqa_34_0
# Benchmark: hotpotqa
# Data Indices: [137]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify key entities and relevant documents
        entity_identification = await self.generate(
            instruction="Identify the key entities mentioned in the question and determine which documents are relevant to these entities. "
                        "Focus on finding documents that contain information about the entities' nationality or related attributes. "
                        "Return the list of entities and their corresponding relevant document indices.",
            context=self.problem_text
        )

        # Step 2: Extract nationality information for each entity
        entities_and_docs = eval(entity_identification)  # Convert string output to Python object
        extraction_tasks = []
        for entity, doc_indices in entities_and_docs.items():
            extraction_instruction = (
                f"Extract information about the nationality or origin of the entity '{entity}' from the following documents: {doc_indices}. "
                "If the nationality is not explicitly stated, infer it based on contextual clues such as place of birth, residence, or other relevant details. "
                "Return the extracted information in a concise format."
            )
            extraction_tasks.append(
                self.generate(instruction=extraction_instruction, context=self.problem_text)
            )
        extracted_info = await asyncio.gather(*extraction_tasks)

        # Step 3: Synthesize extracted information into a coherent response
        synthesis_instruction = (
            "Combine the extracted information about the entities into a single, coherent response. "
            "Ensure the response directly answers the question and resolves any ambiguities or inconsistencies. "
            "Format the response clearly and concisely."
        )
        final_answer = await self.ensemble(
            instruction=synthesis_instruction,
            contexts=extracted_info
        )

        return final_answer