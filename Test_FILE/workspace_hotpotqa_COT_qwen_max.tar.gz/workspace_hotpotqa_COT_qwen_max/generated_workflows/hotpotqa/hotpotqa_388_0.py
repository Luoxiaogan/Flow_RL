# Workflow ID: hotpotqa_388_0
# Benchmark: hotpotqa
# Data Indices: [231]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Analyze the question and extract key entities
        question_analysis = await self.generate(
            instruction="Analyze the question to identify the main entities and the type of reasoning required. "
                        "Extract the 'bridge entity' and the target property explicitly. "
                        "For example, if the question asks about collaborations, identify the collaborator and the context. "
                        "Output the extracted entities and reasoning type.",
            context=self.problem_text
        )

        # Step 2: Identify relevant documents and gather facts
        document_selection = await self.generate(
            instruction=f"Based on the extracted entities ({question_analysis}), identify which documents "
                        "contain relevant information. Extract specific sentences or facts that mention the "
                        "bridge entity and its associations. Focus on cross-document connections.",
            context=self.problem_text
        )

        # Step 3: Resolve ambiguities and build reasoning chains
        refined_facts = await self.revise(
            instruction=f"Refine the extracted facts ({document_selection}) to resolve any ambiguities in entity mentions. "
                        "For example, ensure that different mentions of the same entity are correctly matched. "
                        "Construct a reasoning chain that connects the bridge entity to the target property.",
            context=document_selection
        )

        # Step 4: Evaluate and synthesize potential answers
        potential_answers = await asyncio.gather(
            self.generate(
                instruction=f"Based on the refined facts ({refined_facts}), propose a potential answer. "
                            "Ensure the answer is directly supported by the extracted information.",
                context=refined_facts
            ),
            self.generate(
                instruction=f"Provide an alternative interpretation of the refined facts ({refined_facts}). "
                            "Consider other possible answers that fit the reasoning chain.",
                context=refined_facts
            )
        )

        final_answer = await self.ensemble(
            instruction="Evaluate the proposed answers and select the most consistent and well-supported one. "
                        "Ensure the final answer is concise and directly addresses the question.",
            contexts=potential_answers
        )

        # Step 5: Summarize the reasoning chain
        summarized_reasoning = await self.summarize(
            instruction=f"Condense the reasoning chain ({refined_facts}) into a concise explanation. "
                        "Highlight the key steps and supporting facts.",
            context=refined_facts
        )

        return {
            "answer": final_answer,
            "reasoning": summarized_reasoning
        }