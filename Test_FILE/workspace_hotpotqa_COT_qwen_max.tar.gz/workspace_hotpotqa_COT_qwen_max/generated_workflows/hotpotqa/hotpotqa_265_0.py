# Workflow ID: hotpotqa_265_0
# Benchmark: hotpotqa
# Data Indices: [331]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Identify core entities and relevant documents
        entities_and_documents = await self.generate(
            instruction="""Identify the core entities mentioned in the question and determine which documents are relevant to these entities. 
            Core entities are typically proper nouns or specific terms that connect the question to the context documents. 
            For each entity, list the document numbers where they appear.""",
            context=self.problem_text
        )

        # Step 2: Extract bridge entities
        bridge_entity = await self.generate(
            instruction=f"""Based on the identified entities and relevant documents, determine the bridge entity that connects the entities mentioned in the question. 
            A bridge entity is a shared term or concept that links multiple documents. Provide the bridge entity and explain why it is relevant.""",
            context=entities_and_documents
        )

        # Step 3: Extract relevant facts about the bridge entity
        fact_extraction_tasks = []
        for doc_num in range(1, 11):  # Assuming there are 10 documents
            fact_extraction_tasks.append(
                self.generate(
                    instruction=f"""Extract any relevant facts about the bridge entity '{bridge_entity}' from Document {doc_num}. 
                    Focus on facts that directly relate to the question and provide supporting evidence.""",
                    context=self.problem_text
                )
            )
        extracted_facts = await asyncio.gather(*fact_extraction_tasks)

        # Step 4: Summarize the extracted facts
        summarized_facts = await self.summarize(
            instruction="""Condense the extracted facts into a concise summary. 
            Focus on retaining only the most relevant information that directly answers the question.""",
            context="\n".join(extracted_facts)
        )

        # Step 5: Synthesize the final answer
        draft_answer = await self.generate(
            instruction=f"""Using the summarized facts, synthesize a concise answer to the question. 
            Ensure the answer is specific, clear, and directly addresses the query.""",
            context=summarized_facts
        )

        # Step 6: Refine the answer
        final_answer = await self.revise(
            instruction="""Critique and refine the draft answer to ensure accuracy, clarity, and completeness. 
            Verify that the answer aligns with the original question and context.""",
            context=draft_answer
        )

        return final_answer