# Workflow ID: hotpotqa_308_0
# Benchmark: hotpotqa
# Data Indices: [167]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify key entities and select relevant documents
        entity_instruction = ("Identify all key entities in the question and determine which documents "
                              "are relevant to these entities. Provide a list of relevant document names.")
        relevant_docs = await self.generate(instruction=entity_instruction, context=self.problem_text)

        # Step 2: Build cross-document reasoning chain
        reasoning_instruction = (f"Given the relevant documents: {relevant_docs}, "
                                 "build a reasoning chain that connects information across these documents. "
                                 "Focus on shared entities or facts that help answer the question.")
        reasoning_chain = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Extract the specific answer
        extraction_instruction = (f"Using the reasoning chain: {reasoning_chain}, "
                                  "extract the specific answer from the relevant documents. "
                                  "Ensure the answer is precise and directly addresses the question.")
        extracted_answer = await self.summarize(instruction=extraction_instruction, context=self.problem_text)

        # Step 4: Validate and refine the answer
        refinement_instruction = (f"Critique and refine the following answer: {extracted_answer}. "
                                  "Ensure it is accurate and fully supported by the provided documents.")
        refined_answer = await self.revise(instruction=refinement_instruction, context=self.problem_text)

        # Optional: Parallel execution for additional validation paths
        validation_tasks = [
            self.generate(instruction="Provide an alternative reasoning path.", context=self.problem_text),
            self.summarize(instruction="Summarize supporting facts for the answer.", context=self.problem_text)
        ]
        validation_results = await asyncio.gather(*validation_tasks)

        # Final ensemble to synthesize the best answer
        final_instruction = ("Given the refined answer and additional validation results, "
                             "synthesize the best possible answer.")
        final_answer = await self.ensemble(instruction=final_instruction, contexts=[refined_answer] + validation_results)

        return final_answer