# Workflow ID: hotpotqa_99_0
# Benchmark: hotpotqa
# Data Indices: [267]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Identify Relevant Documents
        relevance_instructions = """
        Analyze each document provided in the context and determine its relevance to the question.
        Focus on identifying documents that contain information about the entities or facts mentioned in the question.
        Provide a brief explanation for each document's relevance or irrelevance.
        """
        relevant_docs = await self.generate(instruction=relevance_instructions, context=self.problem_text)

        # Step 2: Extract Entities and Facts
        extraction_instructions = f"""
        From the relevant documents identified in the following analysis: {relevant_docs},
        extract key entities (e.g., names, places) and facts (e.g., actions, properties).
        Ensure the extracted information is directly related to the question and can help build a reasoning chain.
        """
        extracted_info = await self.generate(instruction=extraction_instructions, context=self.problem_text)

        # Step 3: Construct Reasoning Chain
        reasoning_instructions = f"""
        Using the extracted entities and facts: {extracted_info},
        construct a step-by-step reasoning chain that connects the information across documents.
        Ensure the chain logically leads to an answer for the question.
        """
        reasoning_chain = await self.generate(instruction=reasoning_instructions, context=self.problem_text)

        # Step 4: Synthesize Final Answer
        synthesis_instructions = f"""
        Evaluate the reasoning chain: {reasoning_chain},
        and synthesize the final answer. Ensure the answer is concise, factually correct, and directly addresses the question.
        If there are multiple possible answers, select the most accurate one based on the provided context.
        """
        candidate_answers = await asyncio.gather(
            self.generate(instruction=synthesis_instructions, context=self.problem_text),
            self.generate(instruction=synthesis_instructions, context=self.problem_text)
        )
        final_answer = await self.ensemble(instruction="Select the most accurate and concise answer.", contexts=candidate_answers)

        # Optional Step 5: Refine Final Answer
        refinement_instructions = f"""
        Review the final answer: {final_answer},
        and refine it for clarity, precision, and grammatical correctness.
        Ensure the refined answer directly addresses the question.
        """
        refined_answer = await self.revise(instruction=refinement_instructions, context=final_answer)

        return refined_answer