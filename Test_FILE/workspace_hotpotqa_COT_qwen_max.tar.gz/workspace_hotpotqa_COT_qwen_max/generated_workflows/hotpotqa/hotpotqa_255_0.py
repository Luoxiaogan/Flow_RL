# Workflow ID: hotpotqa_255_0
# Benchmark: hotpotqa
# Data Indices: [97]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Identify key entities and relevant documents
        entity_identification_instruction = """
        Identify the key entities mentioned in the question. 
        For each entity, determine which documents mention it and extract relevant sentences.
        Ensure the output is structured as a JSON object with entities as keys and document references as values.
        """
        entity_info = await self.generate(
            instruction=entity_identification_instruction,
            context=self.problem_text
        )

        # Parse the JSON output to get entities and their associated documents
        import json
        entity_data = json.loads(entity_info)

        # Step 2: Extract location information for each entity in parallel
        async def extract_location(entity, documents):
            extraction_instruction = f"""
            From the provided documents, extract the location of the entity '{entity}'.
            Ensure the output is a short phrase or sentence clearly stating the location.
            """
            return await self.generate(
                instruction=extraction_instruction,
                context="\n".join(documents)
            )

        # Run extraction tasks in parallel
        tasks = [
            extract_location(entity, data["documents"])
            for entity, data in entity_data.items()
        ]
        location_results = await asyncio.gather(*tasks)

        # Step 3: Synthesize the results into a final answer
        synthesis_instruction = """
        Combine the provided location results into a coherent answer.
        Ensure the response directly answers the question and is concise.
        """
        final_answer = await self.ensemble(
            instruction=synthesis_instruction,
            contexts=location_results
        )

        return final_answer