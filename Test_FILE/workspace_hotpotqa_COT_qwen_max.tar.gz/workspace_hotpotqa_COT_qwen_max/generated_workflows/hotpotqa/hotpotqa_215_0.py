# Workflow ID: hotpotqa_215_0
# Benchmark: hotpotqa
# Data Indices: [72]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Analyze the question to identify entities and reasoning type
        question_analysis = await self.generate(
            instruction="Analyze the question to identify all key entities, their relationships, and the type of reasoning required (e.g., bridge entity, comparison). "
                        "Provide a structured output listing the entities and the reasoning type.",
            context=self.problem_text
        )

        # Step 2: Identify relevant documents containing information about the entities
        document_selection = await self.generate(
            instruction=f"Based on the identified entities and reasoning type ({question_analysis}), "
                        "scan the provided documents and select those that contain relevant information. "
                        "Provide a list of document indices and brief summaries of their relevance.",
            context=self.problem_text
        )

        # Step 3: Resolve bridge entities and match mentions across documents
        resolved_entities = await self.ensemble(
            instruction=f"Compare mentions of entities across the selected documents ({document_selection}) "
                        "to resolve any ambiguities (e.g., different names for the same entity). "
                        "Provide a unified list of entities with their resolved names.",
            contexts=[self.problem_text, document_selection]
        )

        # Step 4: Chain facts and derive the answer
        fact_chaining = await self.generate(
            instruction=f"Using the resolved entities ({resolved_entities}) and the selected documents ({document_selection}), "
                        "chain the facts together to build a reasoning chain that answers the question. "
                        "Ensure the reasoning is explicit and includes supporting sentences from the documents.",
            context=self.problem_text
        )

        # Step 5: Refine the answer for precision and clarity
        refined_answer = await self.revise(
            instruction="Critique and refine the generated answer to ensure it is precise, concise, and matches the expected format (e.g., short text span, yes/no).",
            context=fact_chaining
        )

        return refined_answer