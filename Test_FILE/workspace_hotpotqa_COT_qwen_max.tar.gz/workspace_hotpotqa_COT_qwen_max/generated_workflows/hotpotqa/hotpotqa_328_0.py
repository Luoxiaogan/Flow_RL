# Workflow ID: hotpotqa_328_0
# Benchmark: hotpotqa
# Data Indices: [81]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Parse the question to identify key entities and relationships
        question_analysis = await self.generate(
            instruction="Analyze the question to identify key entities and their relationships. "
                        "Focus on identifying the main subject (e.g., Crown Prince), the institution (e.g., Royal Academy of Music), "
                        "and the target attribute (e.g., mother). Provide a structured breakdown of these components.",
            context=self.problem_text
        )

        # Step 2: Select relevant documents based on keyword matching
        document_selection = await self.generate(
            instruction=f"Given the following analysis of the question: {question_analysis}, "
                        "identify which documents are relevant to answering the question. "
                        "Look for documents mentioning 'Crown Prince', 'Royal Academy of Music', and 'mother'. "
                        "Return a list of document indices or titles.",
            context=self.problem_text
        )

        # Step 3: Identify the bridge entity (Crown Prince)
        bridge_entity_identification = await self.generate(
            instruction=f"Based on the selected documents: {document_selection}, "
                        "identify the Crown Prince who is associated with the Royal Academy of Music. "
                        "Provide the name of the Crown Prince and the document(s) where this information is found.",
            context=self.problem_text
        )

        # Step 4: Trace the reasoning chain to find the mother's name
        mother_identification = await self.generate(
            instruction=f"Given the Crown Prince identified as: {bridge_entity_identification}, "
                        "trace back through the documents to find information about his mother. "
                        "Extract the name of the mother and the document(s) where this information is found.",
            context=self.problem_text
        )

        # Step 5: Refine and extract the final answer
        final_answer = await self.revise(
            instruction=f"Refine the extracted information about the mother: {mother_identification}. "
                        "Ensure the answer is concise, accurate, and directly addresses the question. "
                        "Return only the name of the mother.",
            context=self.problem_text
        )

        return final_answer