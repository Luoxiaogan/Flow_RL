# Workflow ID: hotpotqa_327_0
# Benchmark: hotpotqa
# Data Indices: [303]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify Key Entities and Relationships
        entity_instruction = """
        Analyze the given question and extract all key entities and their relationships. 
        Focus on identifying the main subject of the question and any associated entities that might be crucial for answering it.
        Ensure you capture any geographical locations, organizations, or specific terms mentioned.
        Format your output as a list of entities and their descriptions.
        """
        entities = await self.generate(instruction=entity_instruction, context=self.problem_text)

        # Step 2: Document Selection and Information Extraction
        extraction_instruction = f"""
        Given the following entities and their descriptions:
        {entities}

        Extract relevant information from the provided documents that pertain to these entities.
        Focus on finding data that could directly or indirectly help answer the original question.
        Summarize the extracted information for each document separately.
        """
        document_summaries = []
        for doc in range(1, 11):  # Assuming there are 10 documents
            summary = await self.generate(instruction=extraction_instruction, context=f"Document {doc}")
            document_summaries.append(summary)

        # Step 3: Building Reasoning Chains
        reasoning_instruction = f"""
        Using the summarized information from the following documents:
        {document_summaries}

        Build a reasoning chain that connects the extracted facts to answer the original question.
        Identify any intermediary entities or facts that bridge the information gap between the question and the final answer.
        Ensure the reasoning is logical and coherent.
        """
        reasoning_chain = await self.ensemble(instruction=reasoning_instruction, contexts=document_summaries)

        # Step 4: Answer Synthesis
        synthesis_instruction = f"""
        Based on the following reasoning chain:
        {reasoning_chain}

        Compile a concise and accurate answer to the original question.
        Ensure the answer is directly supported by the provided documents and the reasoning chain.
        """
        final_answer = await self.summarize(instruction=synthesis_instruction, context=self.problem_text)

        return final_answer