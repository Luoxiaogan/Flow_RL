# Workflow ID: hotpotqa_157_0
# Benchmark: hotpotqa
# Data Indices: [94]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Parse the question and extract key entities
        question_analysis = await self.generate(
            instruction="Analyze the question and extract all key entities, including names, relationships, and requested information. "
                        "Provide a structured output with the following format: "
                        "{ 'entities': [list of entities], 'question_type': type of question (e.g., bridge, comparison), 'requested_info': what the question is asking for }",
            context=self.problem_text
        )

        # Step 2: Identify relevant documents using Ensemble
        relevant_documents = await self.ensemble(
            instruction="Evaluate all provided documents and select those that are most relevant to answering the question. "
                        "Relevance is determined by the presence of key entities and their connection to the requested information. "
                        "Return the indices or titles of the relevant documents.",
            contexts=[f"Document {i+1}: {doc}" for i, doc in enumerate(self.config['documents'])]
        )

        # Step 3: Resolve entities and build reasoning chains
        reasoning_chain = await self.generate(
            instruction=f"Using the relevant documents ({relevant_documents}), resolve the entities mentioned in the question ({question_analysis}). "
                        "Build a reasoning chain that connects the entities to the requested information. "
                        "Include intermediate steps and supporting facts.",
            context=self.problem_text
        )

        # Step 4: Refine the reasoning chain
        refined_chain = await self.revise(
            instruction="Critically evaluate the reasoning chain and refine it for clarity, accuracy, and completeness. "
                        "Ensure all steps logically follow and lead to the requested information.",
            context=reasoning_chain
        )

        # Step 5: Extract and finalize the answer
        final_answer = await self.generate(
            instruction="Extract the final answer from the refined reasoning chain. "
                        "The answer should be concise and directly address the question. "
                        "If the answer is a year or a specific fact, ensure it is explicitly stated.",
            context=refined_chain
        )

        return final_answer