# Workflow ID: hotpotqa_351_0
# Benchmark: hotpotqa
# Data Indices: [44]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key entities and parse the question
        entity_extraction_instruction = """
        Analyze the question and extract all key entities and concepts mentioned. Focus on:
        - Proper nouns (people, places, organizations, etc.)
        - Relationships or actions described in the question
        - Any specific constraints or conditions provided
        Format your output as a JSON object with keys "entities" (list of strings) and "question_type" (e.g., "bridge", "comparison").
        """
        entity_info = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Identify relevant documents based on extracted entities
        document_selection_instruction = f"""
        Based on the following extracted entities: {entity_info}, identify which documents in the provided context are most relevant.
        Focus on documents that mention these entities or provide related background information.
        Output a list of document titles or indices that are relevant to answering the question.
        """
        relevant_documents = await self.generate(instruction=document_selection_instruction, context=self.problem_text)

        # Step 3: Resolve bridge entities and establish reasoning chains
        bridge_entity_instruction = f"""
        Using the relevant documents identified here: {relevant_documents}, determine the bridge entity or fact that connects the key entities in the question.
        For example, if the question asks about an actor portraying a historical figure, identify the historical figure and the corresponding movie/document.
        Provide a detailed explanation of how these entities are connected.
        """
        bridge_resolution = await self.generate(instruction=bridge_entity_instruction, context=self.problem_text)

        # Step 4: Extract specific facts and synthesize the answer
        fact_extraction_instruction = f"""
        Based on the bridge entity resolution: {bridge_resolution}, extract the specific facts or sentences from the documents that directly answer the question.
        Ensure the extracted information is precise and includes all necessary details (e.g., names, dates, relationships).
        """
        extracted_facts = await self.generate(instruction=fact_extraction_instruction, context=self.problem_text)

        # Step 5: Generate and refine the final answer
        answer_synthesis_instruction = f"""
        Using the extracted facts: {extracted_facts}, synthesize a concise and accurate answer to the original question.
        Ensure the answer is in the required format (e.g., short text span, yes/no, brief factual response).
        """
        initial_answer = await self.generate(instruction=answer_synthesis_instruction, context=self.problem_text)

        refinement_instruction = """
        Review the following answer for clarity, accuracy, and completeness. Make improvements if needed.
        """
        final_answer = await self.revise(instruction=refinement_instruction, context=initial_answer)

        return final_answer