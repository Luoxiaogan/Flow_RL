# Workflow ID: hotpotqa_116_0
# Benchmark: hotpotqa
# Data Indices: [372]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Entity Identification and Question Parsing
        entity_instruction = """
        Analyze the given question and identify all key entities and their relationships. 
        Extract any specific mentions of characters, places, events, or other relevant nouns.
        Provide a structured output listing these entities and their roles in the question.
        """
        entities = await self.generate(instruction=entity_instruction, context=self.problem_text)

        # Step 2: Document Selection
        doc_selection_instruction = f"""
        Evaluate the relevance of each document based on the following extracted entities and relationships:
        {entities}
        For each document, determine whether it contains information pertinent to the entities or relationships mentioned.
        Return a list of relevant document indices.
        """
        relevant_docs = await self.ensemble(instruction=doc_selection_instruction, contexts=[f"Document {i+1}: {doc}" for i, doc in enumerate(self.problem_text.split('\n\n'))])

        # Step 3: Information Extraction
        info_extraction_instruction = f"""
        From the selected documents ({relevant_docs}), extract sentences or facts that are relevant to the following entities and relationships:
        {entities}
        Summarize the key information that connects these entities across the documents.
        """
        extracted_info = await self.summarize(instruction=info_extraction_instruction, context=self.problem_text)

        # Step 4: Reasoning and Answer Synthesis
        reasoning_instruction = f"""
        Using the extracted information:
        {extracted_info}
        Perform multi-hop reasoning to connect the dots between different pieces of information.
        Synthesize a concise answer to the original question based on this reasoning.
        Ensure the answer is directly supported by the provided documents.
        """
        synthesized_answer = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 5: Answer Refinement
        refinement_instruction = """
        Critique the following answer and refine it for precision and clarity.
        Ensure the answer directly addresses the original question and is supported by the provided documents.
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=synthesized_answer)

        return refined_answer