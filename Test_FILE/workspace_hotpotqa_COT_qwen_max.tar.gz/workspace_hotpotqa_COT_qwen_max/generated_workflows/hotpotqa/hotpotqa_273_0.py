# Workflow ID: hotpotqa_273_0
# Benchmark: hotpotqa
# Data Indices: [255]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract key entities and identify relevant documents
        entity_extraction_instruction = """
        Identify all mentions of the entities 'Björn Tom Fredrik Nordström' and 'Swedish melodic death metal band' 
        across the provided documents. For each mention, note the document it appears in and any associated 
        relationships or facts. Provide the output in a structured format.
        """
        entity_mentions = await self.generate(
            instruction=entity_extraction_instruction,
            context=self.problem_text
        )

        # Step 2: Identify reasoning chains
        reasoning_chain_instruction = f"""
        Using the extracted entity mentions: {entity_mentions}, determine the relationships between 
        'Björn Tom Fredrik Nordström' and any Swedish melodic death metal bands. Specifically, find:
        - Which band(s) he worked with.
        - Whether any of those bands released an album in 2014.
        Construct a reasoning chain that connects these facts across documents.
        """
        reasoning_chain = await self.generate(
            instruction=reasoning_chain_instruction,
            context=self.problem_text
        )

        # Step 3: Synthesize information
        synthesis_instruction = f"""
        Based on the reasoning chain: {reasoning_chain}, synthesize the information to determine:
        - The name of the Swedish melodic death metal band that released an album in 2014.
        - The title of the album.
        Ensure the output is concise and directly answers the question.
        """
        synthesis_result = await self.generate(
            instruction=synthesis_instruction,
            context=self.problem_text
        )

        # Step 4: Summarize the final answer
        summarization_instruction = f"""
        Extract the final answer from the synthesized information: {synthesis_result}. 
        The answer should be a short text span that directly responds to the question.
        """
        final_answer = await self.summarize(
            instruction=summarization_instruction,
            context=synthesis_result
        )

        return final_answer