# Workflow ID: hotpotqa_65_0
# Benchmark: hotpotqa
# Data Indices: [235]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify entities and select relevant documents
        entity_identification_instruction = """
        Analyze the question to identify the key entities mentioned. 
        For each entity, determine which documents in the provided context are likely to contain relevant information.
        Return the entities and the corresponding document indices as a JSON object in the format:
        {"entities": ["Entity1", "Entity2"], "document_indices": {"Entity1": [indices], "Entity2": [indices]}}
        """
        entity_info = await self.generate(
            instruction=entity_identification_instruction,
            context=self.problem_text
        )
        import json
        entity_data = json.loads(entity_info)
        entities = entity_data["entities"]
        document_indices = entity_data["document_indices"]

        # Step 2: Extract relevant information for each entity
        async def extract_entity_info(entity, indices):
            extraction_instruction = f"""
            Focus on the documents with indices {indices} to extract all relevant information about "{entity}".
            Pay special attention to chronological markers such as birth years, dates, or other temporal information.
            Return the extracted information as a concise summary.
            """
            return await self.generate(
                instruction=extraction_instruction,
                context=self.problem_text
            )

        extraction_tasks = [
            extract_entity_info(entity, document_indices[entity])
            for entity in entities
        ]
        extracted_infos = await asyncio.gather(*extraction_tasks)

        # Step 3: Compare the extracted information
        comparison_instruction = f"""
        Compare the following pieces of information about the entities {entities}:
        - Information about {entities[0]}: {extracted_infos[0]}
        - Information about {entities[1]}: {extracted_infos[1]}
        Determine which entity was born first based on the extracted information.
        Provide a clear reasoning chain and the final answer.
        """
        comparison_result = await self.ensemble(
            instruction=comparison_instruction,
            contexts=extracted_infos
        )

        # Step 4: Generate the final answer
        final_answer_instruction = f"""
        Based on the comparison result: {comparison_result}, generate a concise and precise answer to the original question.
        Ensure the answer directly addresses the question and includes the reasoning behind it.
        """
        final_answer = await self.generate(
            instruction=final_answer_instruction,
            context=self.problem_text
        )

        return final_answer