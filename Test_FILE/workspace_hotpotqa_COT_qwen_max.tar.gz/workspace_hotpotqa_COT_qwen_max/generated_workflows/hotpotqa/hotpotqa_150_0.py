# Workflow ID: hotpotqa_150_0
# Benchmark: hotpotqa
# Data Indices: [315]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify key entities and relevant documents
        entity_extraction_instruction = (
            "Identify all key entities mentioned in the question. "
            "For each entity, find the documents that contain relevant information about it. "
            "Return the entities and their associated documents in a structured format."
        )
        entities_and_documents = await self.generate(
            instruction=entity_extraction_instruction,
            context=self.problem_text
        )

        # Step 2: Construct the reasoning chain
        reasoning_instruction = (
            f"Based on the following entities and their associated documents: {entities_and_documents}, "
            "construct a reasoning chain that connects the information across documents. "
            "Explicitly identify any bridge entities or comparisons needed to answer the question. "
            "Provide the reasoning chain in a step-by-step format."
        )
        reasoning_chain = await self.generate(
            instruction=reasoning_instruction,
            context=self.problem_text
        )

        # Step 3: Extract the precise answer
        answer_extraction_instruction = (
            f"Using the reasoning chain: {reasoning_chain}, "
            "extract the precise answer span from the text. "
            "Ensure the answer aligns with the question type (e.g., yes/no, short text span)."
        )
        raw_answer = await self.summarize(
            instruction=answer_extraction_instruction,
            context=self.problem_text
        )

        # Step 4: Validate and refine the answer
        refinement_instruction = (
            f"Critique and refine the following answer: {raw_answer}. "
            "Ensure it is accurate, concise, and directly addresses the question. "
            "If necessary, revise the answer based on the original problem text."
        )
        refined_answer = await self.revise(
            instruction=refinement_instruction,
            context=self.problem_text
        )

        return refined_answer