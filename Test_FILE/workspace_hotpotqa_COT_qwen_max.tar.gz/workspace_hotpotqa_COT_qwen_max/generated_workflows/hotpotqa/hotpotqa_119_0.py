# Workflow ID: hotpotqa_119_0
# Benchmark: hotpotqa
# Data Indices: [102]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract key entities and concepts from the question
        entity_extraction_instruction = """
        Analyze the question and extract all key entities, concepts, and relationships mentioned.
        Focus on identifying entities that are likely to appear in the context documents.
        Provide the extracted entities as a comma-separated list.
        """
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Filter relevant documents based on extracted entities
        document_filter_instruction = f"""
        Compare the extracted entities ({entities}) against each document.
        Rank the documents based on their relevance to the entities.
        Return the top 3 most relevant documents as a list of document indices (0-based).
        """
        relevant_documents = await self.ensemble(instruction=document_filter_instruction, contexts=[self.problem_text])

        # Step 3: Identify bridge entities in the relevant documents
        bridge_entity_instruction = f"""
        Analyze the top relevant documents ({relevant_documents}) to identify any shared entities or concepts
        that connect multiple documents. These are called "bridge entities."
        Provide the bridge entity as a single string.
        """
        bridge_entity = await self.generate(instruction=bridge_entity_instruction, context=self.problem_text)

        # Step 4: Construct the reasoning chain using the bridge entity
        reasoning_chain_instruction = f"""
        Using the bridge entity ({bridge_entity}), construct a reasoning chain that connects the entities
        across the relevant documents. Explicitly mention how the documents relate to each other.
        Provide the reasoning chain as a concise paragraph.
        """
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 5: Extract and refine the final answer
        answer_extraction_instruction = f"""
        From the reasoning chain ({reasoning_chain}), extract the precise answer to the question.
        Ensure the answer is a short text span, entity name, or brief factual response.
        """
        raw_answer = await self.generate(instruction=answer_extraction_instruction, context=self.problem_text)

        refinement_instruction = """
        Refine the extracted answer to ensure it is precise, grammatically correct, and matches the expected format.
        """
        final_answer = await self.revise(instruction=refinement_instruction, context=raw_answer)

        return final_answer