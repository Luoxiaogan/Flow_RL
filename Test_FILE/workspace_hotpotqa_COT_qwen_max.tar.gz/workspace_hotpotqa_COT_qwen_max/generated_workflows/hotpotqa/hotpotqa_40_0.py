# Workflow ID: hotpotqa_40_0
# Benchmark: hotpotqa
# Data Indices: [257]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key entities and relationships from the question
        entity_extraction_instruction = (
            "Identify all key entities (e.g., names, locations, objects) and their relationships "
            "from the question. Focus on entities that are likely to appear in the context documents. "
            "Format the output as a list of entities and their descriptions."
        )
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Locate relevant documents based on extracted entities
        document_selection_instruction = (
            f"Given the following entities: {entities}, identify which documents in the context "
            "are most relevant. Provide a brief explanation for each document's relevance."
        )
        relevant_documents = await self.generate(instruction=document_selection_instruction, context=self.problem_text)

        # Step 3: Build reasoning chains across documents
        reasoning_chain_instruction = (
            f"Using the relevant documents: {relevant_documents}, construct reasoning chains "
            "that connect the entities to answer the question. Ensure the reasoning is explicit "
            "and traceable back to the documents."
        )
        reasoning_chains = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 4: Summarize reasoning chains for clarity
        summary_instruction = (
            "Condense the reasoning chains into a concise summary that highlights the key steps "
            "and connections between entities."
        )
        summarized_reasoning = await self.summarize(instruction=summary_instruction, context=reasoning_chains)

        # Step 5: Extract the precise answer span
        answer_extraction_instruction = (
            f"Based on the summarized reasoning: {summarized_reasoning}, extract the precise "
            "answer span that directly answers the question. Ensure the answer is specific and "
            "supported by the reasoning."
        )
        answer_span = await self.generate(instruction=answer_extraction_instruction, context=summarized_reasoning)

        # Step 6: Revise the answer for accuracy and clarity
        revision_instruction = (
            "Review the extracted answer span and ensure it is accurate, concise, and fully "
            "supported by the reasoning chains. Make any necessary corrections."
        )
        final_answer = await self.revise(instruction=revision_instruction, context=answer_span)

        return final_answer