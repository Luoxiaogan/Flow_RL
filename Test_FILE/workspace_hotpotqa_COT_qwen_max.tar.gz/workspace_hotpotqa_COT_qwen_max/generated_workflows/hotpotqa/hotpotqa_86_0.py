# Workflow ID: hotpotqa_86_0
# Benchmark: hotpotqa
# Data Indices: [399]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract mentions of key entities and identify relevant documents
        entity_extraction_instruction = """
        Identify all mentions of the entities mentioned in the question across the provided documents. 
        For each entity, list the documents where they appear and highlight any shared attributes or connections between them.
        Focus on attributes like nationality, profession, or other relevant properties.
        """
        entity_mentions = await self.generate(
            instruction=entity_extraction_instruction,
            context=self.problem_text
        )

        # Step 2: Resolve entities and link them to shared attributes
        resolution_instruction = f"""
        Based on the extracted mentions: {entity_mentions}, resolve the entities across documents. 
        Ensure that each mention refers to the same individual or concept. 
        Then, identify shared attributes between the entities, such as nationality, location, or other relevant properties.
        """
        resolved_entities = await self.generate(
            instruction=resolution_instruction,
            context=self.problem_text
        )

        # Step 3: Build reasoning chains to connect entities and answer the question
        reasoning_instruction = f"""
        Using the resolved entities and their shared attributes: {resolved_entities}, construct a reasoning chain to answer the question.
        Clearly explain how the entities are connected and what inference leads to the answer.
        """
        reasoning_chain = await self.generate(
            instruction=reasoning_instruction,
            context=self.problem_text
        )

        # Step 4: Synthesize information from multiple documents to validate the reasoning chain
        synthesis_instruction = f"""
        Evaluate the reasoning chain: {reasoning_chain} against the provided documents. 
        Synthesize the information to confirm the correctness of the inferred answer.
        """
        synthesized_answer = await self.ensemble(
            instruction=synthesis_instruction,
            contexts=[self.problem_text, reasoning_chain]
        )

        # Step 5: Refine the answer for precision and clarity
        refinement_instruction = f"""
        Refine the synthesized answer: {synthesized_answer} to ensure it is precise, concise, and directly addresses the question.
        Remove any extraneous information while preserving the key points.
        """
        final_answer = await self.revise(
            instruction=refinement_instruction,
            context=synthesized_answer
        )

        return final_answer