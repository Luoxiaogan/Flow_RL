# Workflow ID: hotpotqa_230_0
# Benchmark: hotpotqa
# Data Indices: [194]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract Mascot Information
        mascot_instruction = """
        Identify the mascot of the University of Tennessee at Chattanooga and the animal it represents. 
        Focus on documents that mention the university and its mascot. 
        Provide the name of the mascot and the associated animal.
        """
        mascot_info = await self.generate(instruction=mascot_instruction, context=self.problem_text)

        # Step 2: Identify Species Name
        species_instruction = f"""
        Find the species name of the animal mentioned in the following context: {mascot_info}. 
        Look for documents that describe the scientific classification of the animal. 
        Provide the full species name in binomial nomenclature.
        """
        species_name = await self.generate(instruction=species_instruction, context=self.problem_text)

        # Step 3: Synthesize the Answer
        synthesis_instruction = """
        Combine the mascot information and the species name to determine the species name of the animal 
        used as the mascot by the University of Tennessee at Chattanooga. Ensure the connection between 
        the mascot and the species name is clear and logical.
        """
        synthesis_result = await self.ensemble(
            instruction=synthesis_instruction,
            contexts=[mascot_info, species_name]
        )

        # Step 4: Refine the Final Answer
        refine_instruction = """
        Refine the following text into a concise, accurate, and well-formatted answer. 
        Ensure the species name is clearly stated and matches the binomial nomenclature format.
        """
        final_answer = await self.revise(instruction=refine_instruction, context=synthesis_result)

        return final_answer