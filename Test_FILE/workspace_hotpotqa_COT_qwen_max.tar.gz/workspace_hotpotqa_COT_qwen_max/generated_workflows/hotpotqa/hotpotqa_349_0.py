# Workflow ID: hotpotqa_349_0
# Benchmark: hotpotqa
# Data Indices: [14]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract Entities and Relationships
        entity_extraction_instruction = (
            "Extract all named entities (people, places, organizations) mentioned in the question and find their relationships "
            "across the provided documents. Focus on identifying potential 'bridge entities' that connect multiple documents. "
            "Provide the output as a list of entities and their associated relationships."
        )
        entities_and_relationships = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Refine Extracted Information
        refinement_instruction = (
            f"Review the extracted entities and relationships: {entities_and_relationships}. "
            "Ensure that all entities are correctly identified and their relationships are accurately described. "
            "Correct any errors or ambiguities in the extraction process."
        )
        refined_entities = await self.revise(instruction=refinement_instruction, context=entities_and_relationships)

        # Step 3: Identify Bridge Entity and Build Reasoning Chain
        bridge_entity_instruction = (
            f"Using the refined entities and relationships: {refined_entities}, identify the 'bridge entity' "
            "that connects multiple documents. Then, construct a reasoning chain that links the entities "
            "to answer the question. Provide the reasoning chain as a step-by-step explanation."
        )
        reasoning_chain = await self.generate(instruction=bridge_entity_instruction, context=refined_entities)

        # Step 4: Generate Candidate Answers
        candidate_answers_instruction = (
            f"Based on the reasoning chain: {reasoning_chain}, generate possible answers to the question. "
            "Ensure each answer is supported by specific sentences from the documents. "
            "Provide the output as a list of candidate answers with their supporting evidence."
        )
        candidate_answers = await self.generate(instruction=candidate_answers_instruction, context=reasoning_chain)

        # Step 5: Ensemble to Select Final Answer
        ensemble_instruction = (
            f"Evaluate the candidate answers: {candidate_answers}. "
            "Select the most accurate and well-supported answer based on the reasoning chain and document evidence. "
            "If there are conflicting answers, resolve the conflict by revisiting the supporting evidence."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[candidate_answers])

        # Step 6: Summarize Supporting Facts
        summary_instruction = (
            f"Summarize the key facts from the documents that support the final answer: {final_answer}. "
            "Ensure the summary is concise and directly relevant to the question."
        )
        supporting_facts = await self.summarize(instruction=summary_instruction, context=final_answer)

        return {
            "final_answer": final_answer,
            "supporting_facts": supporting_facts
        }