# Workflow ID: hotpotqa_256_0
# Benchmark: hotpotqa
# Data Indices: [220]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key entities and concepts from the question
        entity_extraction_instruction = """
        Analyze the question carefully and extract all key entities, concepts, or phrases that are explicitly mentioned or implied. 
        These could include names of people, movies, books, dates, or any other relevant information. 
        Format the output as a list of entities with brief descriptions of their roles in the question.
        """
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Identify relevant documents and match entities
        document_matching_instruction = f"""
        Using the extracted entities: {entities}, search through the provided context documents to find mentions of these entities. 
        For each entity, list the documents where it appears and briefly describe how it is mentioned in those documents. 
        Focus on finding connections between entities across different documents.
        """
        relevant_documents = await self.generate(instruction=document_matching_instruction, context=self.problem_text)

        # Step 3: Construct the reasoning chain
        reasoning_chain_instruction = f"""
        Based on the matched entities and relevant documents: {relevant_documents}, construct a reasoning chain that connects the entities to answer the question. 
        Explain step-by-step how the information from different documents is linked together to form a coherent answer. 
        Highlight any bridge entities or intermediate facts that are crucial to the reasoning process.
        """
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 4: Generate the final answer
        answer_generation_instruction = f"""
        Using the reasoning chain: {reasoning_chain}, extract the final answer to the question. 
        Ensure that the answer directly addresses the question and is formatted appropriately (e.g., a short text span, yes/no, or brief factual response). 
        If there are multiple possible answers, evaluate them and select the most accurate one.
        """
        final_answer = await self.generate(instruction=answer_generation_instruction, context=self.problem_text)

        # Step 5: Refine the final answer (optional but recommended)
        refinement_instruction = f"""
        Review the generated answer: {final_answer} for accuracy and clarity. 
        Revise it if necessary to ensure it is precise, concise, and fully supported by the reasoning chain. 
        Correct any ambiguities or inconsistencies.
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        return refined_answer