# Workflow ID: hotpotqa_188_0
# Benchmark: hotpotqa
# Data Indices: [358]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Parse the question to identify key entities and reasoning type
        parse_question_instruction = """
        Analyze the question to identify the key entities and the type of reasoning required.
        Extract the primary entity mentioned in the question and determine the target information being asked.
        For example, if the question asks about the birth year of an artist associated with a specific song,
        identify the song and the need to find the artist's birth year.
        Output the extracted entities and reasoning type in a structured format.
        """
        parsed_question = await self.generate(instruction=parse_question_instruction, context=self.problem_text)

        # Step 2: Identify relevant documents and extract information
        extract_info_instruction = f"""
        Based on the parsed question: {parsed_question}, identify the relevant documents that mention the key entities.
        Extract all pertinent information about the entities from these documents.
        Ensure the extracted information includes any connections between entities (e.g., artist-song relationships).
        Output the extracted information in a structured format.
        """
        extracted_info = await self.generate(instruction=extract_info_instruction, context=self.problem_text)

        # Step 3: Perform cross-document reasoning to resolve entities
        reasoning_instruction = f"""
        Using the extracted information: {extracted_info}, perform cross-document reasoning to resolve the entities.
        For example, if the question involves finding the birth year of an artist associated with a song,
        first identify the artist from the song's document, then locate the artist's biographical details in another document.
        Build a clear reasoning chain that connects the entities across documents.
        Output the resolved entities and their relationships in a structured format.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Extract the final answer and validate the reasoning chain
        answer_extraction_instruction = f"""
        Based on the reasoning result: {reasoning_result}, extract the final answer to the question.
        Ensure the answer is precise and matches the expected format (e.g., a specific year for birth year questions).
        Validate the reasoning chain to ensure all steps are logically consistent and supported by the documents.
        Output the final answer along with the supporting reasoning chain.
        """
        final_answer = await self.generate(instruction=answer_extraction_instruction, context=self.problem_text)

        # Step 5: Refine the final output for clarity and correctness
        refine_instruction = """
        Review the final answer and reasoning chain to ensure clarity, correctness, and completeness.
        If necessary, refine the language or structure to improve readability and accuracy.
        Output the refined final answer and reasoning chain.
        """
        refined_output = await self.revise(instruction=refine_instruction, context=final_answer)

        return refined_output