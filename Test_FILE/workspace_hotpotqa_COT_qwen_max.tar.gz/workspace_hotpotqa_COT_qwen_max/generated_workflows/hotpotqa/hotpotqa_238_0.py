# Workflow ID: hotpotqa_238_0
# Benchmark: hotpotqa
# Data Indices: [51]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract entities and relationships from the context documents
        entity_extraction_instruction = """
        Extract all mentions of bands, albums, EPs, and their associated metadata (e.g., release years, lineups) 
        from the provided context documents. Organize the information into structured records, including:
        - Band name
        - Album/EP name
        - Release year
        - Lineup details (if mentioned)
        Ensure completeness and accuracy.
        """
        entity_extraction_task = self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to identify key entities and relationships
        question_analysis_instruction = """
        Analyze the question to identify the key entities (e.g., band names, album/EP names) and relationships 
        (e.g., release years, lineups). Output the identified entities and relationships in a structured format.
        """
        question_analysis_task = self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Run entity extraction and question analysis in parallel
        entities, question_details = await asyncio.gather(entity_extraction_task, question_analysis_task)

        # Step 3: Match entities from the question with those extracted from the documents
        entity_matching_instruction = f"""
        Match the entities mentioned in the question ({question_details}) with those extracted from the context documents ({entities}). 
        Resolve any ambiguities and ensure the correct entities are selected for further processing.
        """
        matched_entities = await self.ensemble(instruction=entity_matching_instruction, contexts=[entities, question_details])

        # Step 4: Validate the facts against the question
        fact_validation_instruction = f"""
        Verify whether the extracted facts ({matched_entities}) satisfy the conditions in the question ({question_details}). 
        Focus on ensuring the correctness of the relationships (e.g., release years, lineups).
        """
        validated_facts = await self.revise(instruction=fact_validation_instruction, context=matched_entities)

        # Step 5: Synthesize the final answer
        answer_synthesis_instruction = f"""
        Based on the validated facts ({validated_facts}), synthesize the final answer to the question ({question_details}). 
        Ensure the answer is concise, accurate, and directly addresses the question.
        """
        final_answer = await self.generate(instruction=answer_synthesis_instruction, context=validated_facts)

        return final_answer