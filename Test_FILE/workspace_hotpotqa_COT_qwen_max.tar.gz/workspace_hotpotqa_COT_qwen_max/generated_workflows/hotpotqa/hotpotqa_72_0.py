# Workflow ID: hotpotqa_72_0
# Benchmark: hotpotqa
# Data Indices: [216]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract key entities and identify relevant documents
        entity_extraction = await self.generate(
            instruction="Extract all key entities (names, titles, etc.) from the question. "
                        "Then, identify which documents mention these entities.",
            context=self.problem_text
        )

        # Step 2: Construct reasoning chains across documents
        reasoning_chain = await self.generate(
            instruction=f"Based on the extracted entities: {entity_extraction}, "
                        "construct a reasoning chain that connects the entities across documents. "
                        "Focus on finding the 'bridge entity' that links multiple documents.",
            context=self.problem_text
        )

        # Step 3: Summarize key facts from relevant documents
        summary_tasks = []
        for i in range(1, 11):  # Assuming up to 10 documents
            doc_context = f"Document {i}: [Content of Document {i}]"
            summary_task = self.summarize(
                instruction=f"Summarize the key facts from Document {i} related to the entities: {entity_extraction}.",
                context=doc_context
            )
            summary_tasks.append(summary_task)
        summaries = await asyncio.gather(*summary_tasks)

        # Step 4: Synthesize candidate answers using Ensemble
        candidate_answers = await self.ensemble(
            instruction="Compare the summaries and synthesize candidate answers. "
                        "Ensure the answer directly addresses the question.",
            contexts=summaries
        )

        # Step 5: Validate and refine the final answer
        refined_answer = await self.revise(
            instruction="Critique the candidate answer to ensure it is accurate, complete, and well-supported. "
                        "Refine the answer if necessary.",
            context=candidate_answers
        )

        return refined_answer