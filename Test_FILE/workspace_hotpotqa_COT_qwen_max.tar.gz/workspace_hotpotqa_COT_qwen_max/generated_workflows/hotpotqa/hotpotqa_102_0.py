# Workflow ID: hotpotqa_102_0
# Benchmark: hotpotqa
# Data Indices: [134]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio
        
        # Step 1: Identify key entities and select relevant documents
        entity_extraction = await self.generate(
            instruction="Identify all named entities (people, bands, organizations) mentioned in the question. "
                        "Then, analyze the context documents to determine which documents contain information "
                        "about these entities. Provide a list of relevant documents and their key content.",
            context=self.problem_text
        )
        
        # Step 2: Detect the bridge entity connecting the question's entities
        bridge_entity_detection = await self.generate(
            instruction=f"Based on the extracted entities and relevant documents: {entity_extraction}, "
                        "identify the 'bridge entity' that connects the entities mentioned in the question. "
                        "For example, if the question asks about a person and a band, find the document "
                        "that links them together. Explain the reasoning behind your choice.",
            context=self.problem_text
        )
        
        # Step 3: Chain facts to build the reasoning path
        fact_chaining = await self.generate(
            instruction=f"Using the identified bridge entity: {bridge_entity_detection}, "
                        "chain together facts from the relevant documents to answer the question. "
                        "For example, if Document A says Person X played in Band Y, and Document B says "
                        "Band Y was founded by Person Z, then Person Z is the answer. Provide a step-by-step "
                        "reasoning chain.",
            context=self.problem_text
        )
        
        # Step 4: Extract the precise answer span
        answer_extraction = await self.summarize(
            instruction=f"From the reasoning chain: {fact_chaining}, extract the precise answer span "
                        "that directly answers the question. Ensure the answer is concise and accurate.",
            context=self.problem_text
        )
        
        # Step 5: Refine the answer for clarity and correctness
        refined_answer = await self.revise(
            instruction=f"Review the extracted answer: {answer_extraction}. Ensure it is clear, accurate, "
                        "and fully addresses the question. If necessary, refine it based on additional "
                        "information from the context documents.",
            context=self.problem_text
        )
        
        # Final Output
        return refined_answer