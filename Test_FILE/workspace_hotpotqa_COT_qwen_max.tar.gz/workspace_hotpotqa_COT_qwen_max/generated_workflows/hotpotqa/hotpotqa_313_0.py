# Workflow ID: hotpotqa_313_0
# Benchmark: hotpotqa
# Data Indices: [164]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify relevant documents
        relevance_instruction = """
        Analyze the provided context documents and determine which ones are relevant to answering the question. 
        Focus on documents that mention entities, facts, or relationships directly related to the query. 
        Provide a concise list of relevant document indices or names.
        """
        relevant_docs = await self.generate(instruction=relevance_instruction, context=self.problem_text)

        # Step 2: Extract and resolve entities (parallelizable)
        entity_extraction_instruction = f"""
        From the relevant documents identified as {relevant_docs}, extract all key entities mentioned. 
        Entities include people, places, organizations, and other named entities. 
        Ensure that entities are resolved consistently across documents (e.g., "Botswana" and "Motswana").
        """
        reasoning_chain_instruction = f"""
        Using the entities extracted from the relevant documents, construct a reasoning chain to connect 
        the facts needed to answer the question. Explicitly mention how entities and facts are linked 
        across documents. For example, if the question asks about the birthplace of a person, trace the 
        connection between the person and their associated location.
        """

        entity_extraction, reasoning_chain = await asyncio.gather(
            self.generate(instruction=entity_extraction_instruction, context=self.problem_text),
            self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)
        )

        # Step 3: Generate candidate answers (parallelizable)
        answer_candidates = await asyncio.gather(
            self.generate(instruction="Based on the reasoning chain, provide a concise answer to the question.", context=reasoning_chain),
            self.generate(instruction="Summarize the key supporting facts and derive the answer.", context=entity_extraction)
        )

        # Step 4: Ensemble to select the best answer
        ensemble_instruction = """
        Evaluate the provided candidate answers and select the most accurate and well-supported one. 
        Consider the reasoning chain and supporting facts when making your decision. 
        If there is ambiguity, choose the answer with stronger evidence.
        """
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=answer_candidates)

        # Step 5: Refine the final answer
        refine_instruction = """
        Review the selected answer for clarity, precision, and correctness. 
        Ensure it directly addresses the question and is supported by the provided documents.
        """
        refined_answer = await self.revise(instruction=refine_instruction, context=final_answer)

        return refined_answer