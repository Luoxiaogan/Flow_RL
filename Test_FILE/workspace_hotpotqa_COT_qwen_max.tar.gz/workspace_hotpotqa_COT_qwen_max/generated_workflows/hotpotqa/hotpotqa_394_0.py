# Workflow ID: hotpotqa_394_0
# Benchmark: hotpotqa
# Data Indices: [155]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract Key Entities and Concepts
        entity_extraction_instruction = """
        Identify all key entities, concepts, and relationships mentioned in the question. 
        These may include team names, locations, years, events, or any other relevant information.
        Ensure that the extraction is comprehensive and leaves no important detail out.
        """
        extracted_entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Identify Relevant Documents
        document_selection_instruction = f"""
        Based on the extracted entities and concepts: {extracted_entities},
        identify which documents in the provided context contain relevant information.
        Focus on documents that mention the entities or events related to the question.
        """
        relevant_documents = await self.generate(instruction=document_selection_instruction, context=self.problem_text)

        # Step 3: Resolve Entity Ambiguities
        entity_resolution_instruction = f"""
        Examine the relevant documents: {relevant_documents}.
        Resolve any ambiguities in entity mentions (e.g., different names for the same entity).
        Ensure that all mentions of the same entity are correctly linked across documents.
        """
        resolved_entities = await self.generate(instruction=entity_resolution_instruction, context=relevant_documents)

        # Step 4: Construct Reasoning Chain
        reasoning_chain_instruction = f"""
        Using the resolved entities: {resolved_entities}, build a reasoning chain that connects the facts across documents.
        Start with the question and trace the logical steps needed to arrive at the answer.
        For example, if the question asks about a championship game, find the document that describes the outcome and connect it to the team names mentioned in other documents.
        """
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=resolved_entities)

        # Step 5: Extract Answer
        answer_extraction_instruction = f"""
        Based on the reasoning chain: {reasoning_chain}, extract the precise answer to the question.
        Ensure the answer is concise and matches the expected format (e.g., short text spans or yes/no answers).
        """
        extracted_answer = await self.generate(instruction=answer_extraction_instruction, context=reasoning_chain)

        # Step 6: Validate and Refine Answer
        validation_instruction = f"""
        Validate the extracted answer: {extracted_answer} by cross-referencing it with supporting facts from multiple documents.
        If necessary, refine the answer to ensure accuracy and completeness.
        """
        refined_answer = await self.revise(instruction=validation_instruction, context=extracted_answer)

        # Step 7: Summarize Supporting Facts
        summary_instruction = f"""
        Summarize the key supporting facts that justify the answer: {refined_answer}.
        Ensure the summary is concise but includes all critical information.
        """
        supporting_facts_summary = await self.summarize(instruction=summary_instruction, context=reasoning_chain)

        # Step 8: Ensemble Final Answer
        ensemble_instruction = f"""
        Compare the refined answer: {refined_answer} with the supporting facts summary: {supporting_facts_summary}.
        Select the best final answer that is both accurate and well-supported by the documents.
        """
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[refined_answer, supporting_facts_summary])

        return final_answer