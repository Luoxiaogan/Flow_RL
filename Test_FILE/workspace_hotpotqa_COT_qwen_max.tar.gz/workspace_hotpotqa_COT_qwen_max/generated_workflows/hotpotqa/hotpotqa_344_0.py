# Workflow ID: hotpotqa_344_0
# Benchmark: hotpotqa
# Data Indices: [17]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key entities and identify relevant documents
        entity_extraction_instruction = """
        Identify all key entities mentioned in the question, such as names, titles, roles, and relationships.
        Then, determine which documents in the provided context are relevant to these entities.
        Return the list of entities and the corresponding relevant documents.
        """
        entity_and_documents = await self.generate(
            instruction=entity_extraction_instruction,
            context=self.problem_text
        )

        # Step 2: Find the bridge entity connecting documents
        bridge_entity_instruction = f"""
        Based on the extracted entities and relevant documents: {entity_and_documents},
        identify the bridge entity or concept that connects the question to the relevant document(s).
        This could be a shared entity, a specific event, or a common theme.
        Return the bridge entity and the most relevant document.
        """
        bridge_entity_and_document = await self.generate(
            instruction=bridge_entity_instruction,
            context=self.problem_text
        )

        # Step 3: Extract the final answer from the relevant document
        answer_extraction_instruction = f"""
        Given the bridge entity and relevant document: {bridge_entity_and_document},
        locate the exact sentence or phrase in the document that answers the question.
        Ensure the answer is precise and matches the requested format (e.g., name, date, fact).
        """
        preliminary_answer = await self.generate(
            instruction=answer_extraction_instruction,
            context=self.problem_text
        )

        # Step 4: Verify and refine the answer
        refinement_instruction = f"""
        Critique the following preliminary answer: {preliminary_answer}.
        Ensure it is accurate, complete, and directly addresses the question.
        If necessary, refine the answer based on the original problem text and reasoning chain.
        """
        final_answer = await self.revise(
            instruction=refinement_instruction,
            context=preliminary_answer
        )

        return final_answer