# Workflow ID: hotpotqa_177_0
# Benchmark: hotpotqa
# Data Indices: [93]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Document Selection and Relevance Filtering
        relevance_instruction = """
        Analyze the question and determine which documents are relevant to answering it. 
        Focus on identifying documents that mention the entities or topics in the question.
        Provide a list of relevant document indices.
        """
        relevant_docs = await self.generate(instruction=relevance_instruction, context=self.problem_text)

        # Step 2: Entity Resolution and Tracking
        entity_extraction_instruction = f"""
        Extract mentions of the entities in the question from the relevant documents.
        Ensure that different mentions of the same entity are correctly linked.
        Identify the roles or attributes associated with each entity.
        Relevant Documents: {relevant_docs}
        """
        entity_info = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 3: Reasoning Chain Construction
        reasoning_chain_instruction = f"""
        Build a reasoning chain that connects the entities across documents.
        Determine how the information in one document relates to the information in another.
        Use the extracted entity information to form logical connections.
        Entity Information: {entity_info}
        """
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 4: Answer Extraction and Validation
        answer_extraction_instruction = f"""
        Based on the reasoning chain, extract the answer to the question.
        Validate the answer by ensuring it is supported by the text in the documents.
        Reasoning Chain: {reasoning_chain}
        """
        candidate_answers = await asyncio.gather(
            self.generate(instruction=answer_extraction_instruction, context=self.problem_text),
            self.generate(instruction=answer_extraction_instruction, context=self.problem_text)
        )

        # Step 5: Final Answer Synthesis
        final_answer_instruction = f"""
        Evaluate the candidate answers and select the most accurate and well-supported one.
        Provide a concise answer that directly addresses the question.
        Candidate Answers: {candidate_answers}
        """
        final_answer = await self.ensemble(instruction=final_answer_instruction, contexts=candidate_answers)

        return final_answer