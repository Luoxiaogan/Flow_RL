# Workflow ID: hotpotqa_282_0
# Benchmark: hotpotqa
# Data Indices: [333]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio
        
        # Step 1: Identify relevant documents
        relevant_docs_instruction = """
        Identify which documents contain information relevant to the question. 
        Focus on entities mentioned in the question and find documents discussing these entities.
        List the document names and a brief reason why they are relevant.
        """
        relevant_docs = await self.generate(instruction=relevant_docs_instruction, context=self.problem_text)

        # Step 2: Extract key information from relevant documents
        extraction_instruction = f"""
        From the following relevant documents: {relevant_docs}
        Extract key information related to the entities mentioned in the question.
        Pay special attention to properties like birthdates, roles, or other attributes that could lead to the answer.
        Format your response as a list of key-value pairs where the key is the entity and the value is the extracted information.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 3: Refine extracted information
        refine_instruction = f"""
        Review the extracted information: {extracted_info}
        Ensure accuracy by cross-referencing with the original documents.
        Correct any inconsistencies or errors.
        """
        refined_info = await self.revise(instruction=refine_instruction, context=extracted_info)

        # Step 4: Build reasoning chains
        reasoning_instruction = f"""
        Using the refined information: {refined_info}
        Build a reasoning chain to connect the entities and their properties mentioned in the question.
        Clearly articulate how the information leads to the final answer.
        """
        reasoning_chain = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 5: Synthesize final answer
        synthesis_instruction = f"""
        Based on the reasoning chain: {reasoning_chain}
        Synthesize the final answer to the question.
        Ensure the answer is precise and directly addresses the question.
        """
        final_answer = await self.generate(instruction=synthesis_instruction, context=self.problem_text)

        return final_answer