# Workflow ID: hotpotqa_109_0
# Benchmark: hotpotqa
# Data Indices: [371]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Parse the question and extract key entities
        entity_instruction = """
        Analyze the question and extract all key entities and their relationships.
        Focus on identifying proper nouns, specific concepts, and the type of information requested.
        Ensure the output is structured and concise.
        """
        key_entities = await self.generate(instruction=entity_instruction, context=self.problem_text)

        # Step 2: Identify relevant documents for each entity
        document_selection_instruction = f"""
        Based on the extracted entities: {key_entities},
        search through the provided context documents and identify which documents mention these entities.
        Provide a list of document indices and brief explanations of why they are relevant.
        """
        relevant_documents = await self.generate(instruction=document_selection_instruction, context=self.problem_text)

        # Step 3: Resolve entities and find bridging documents
        bridging_instruction = f"""
        Using the relevant documents: {relevant_documents},
        resolve entity mentions and find connections between them.
        Identify a bridging document that links the entities logically.
        """
        bridging_document = await self.generate(instruction=bridging_instruction, context=self.problem_text)

        # Step 4: Construct the reasoning chain
        reasoning_chain_instruction = f"""
        Using the bridging document: {bridging_document},
        construct a logical reasoning chain that connects the entities.
        Ensure the chain is clear, accurate, and directly addresses the question.
        """
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 5: Refine the reasoning chain
        refine_instruction = """
        Critique and refine the reasoning chain to ensure clarity and correctness.
        Remove any unnecessary steps and focus on the most direct path to the answer.
        """
        refined_chain = await self.revise(instruction=refine_instruction, context=reasoning_chain)

        # Step 6: Extract the final answer
        answer_extraction_instruction = """
        From the refined reasoning chain, extract the precise answer span that directly answers the question.
        Ensure the answer is concise and formatted appropriately.
        """
        final_answer = await self.summarize(instruction=answer_extraction_instruction, context=refined_chain)

        return final_answer