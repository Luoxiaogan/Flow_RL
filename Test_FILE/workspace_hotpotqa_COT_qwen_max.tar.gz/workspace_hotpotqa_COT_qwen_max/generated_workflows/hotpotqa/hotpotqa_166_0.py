# Workflow ID: hotpotqa_166_0
# Benchmark: hotpotqa
# Data Indices: [133]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio
        
        # Step 1: Extract relevant information about both filmmakers
        extraction_instruction = """
        Extract all information about the following filmmakers from the provided context documents:
        - Vincente Minnelli: Focus on his filmography, style, recognition, and affiliations.
        - Jay T. Wright: Focus on his filmography, style, recognition, and affiliations.
        Include details about the types of films they made, their recognition in independent circuits, and any notable achievements.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)
        
        # Step 2: Summarize key attributes for each filmmaker
        summarize_instruction = f"""
        Summarize the key attributes of the following filmmakers based on the extracted information:
        - Vincente Minnelli: Highlight his filmography, style, and recognition.
        - Jay T. Wright: Highlight his filmography, style, and recognition.
        Focus on attributes that are relevant to determining who is better known for independent films.
        """
        summary = await self.summarize(instruction=summarize_instruction, context=extracted_info)
        
        # Step 3: Compare the two filmmakers
        ensemble_instruction = f"""
        Compare the two filmmakers based on their summarized attributes:
        - Vincente Minnelli: {summary.split('- Jay T. Wright')[0].strip()}
        - Jay T. Wright: {summary.split('- Jay T. Wright')[1].strip()}
        Determine who is better known for independent films. Provide a clear and concise conclusion.
        """
        comparison_result = await self.ensemble(instruction=ensemble_instruction, contexts=[summary])
        
        # Step 4: Refine the final answer
        revise_instruction = """
        Revise the following comparison result to ensure it is clear, concise, and well-supported:
        - Ensure the reasoning is explicit and the conclusion is unambiguous.
        """
        final_answer = await self.revise(instruction=revise_instruction, context=comparison_result)
        
        return final_answer