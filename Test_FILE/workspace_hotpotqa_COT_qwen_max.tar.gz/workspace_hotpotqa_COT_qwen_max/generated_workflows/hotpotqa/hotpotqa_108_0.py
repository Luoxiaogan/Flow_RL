# Workflow ID: hotpotqa_108_0
# Benchmark: hotpotqa
# Data Indices: [363]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract mentions of the entities in question
        entities_instruction = """
        Identify all mentions of the entities in the question within the provided documents. 
        Include the sentences or phrases where these entities appear, along with their surrounding context. 
        Ensure you capture any information related to their nationality, profession, or other relevant attributes.
        """
        entity_mentions = await self.generate(instruction=entities_instruction, context=self.problem_text)

        # Step 2: Determine relevant documents and filter information
        relevance_instruction = f"""
        Analyze the extracted mentions of the entities: {entity_mentions}.
        Identify which documents provide relevant information about the entities' nationalities or other attributes.
        Filter out any irrelevant details and focus on facts that directly address the question.
        """
        relevant_info = await self.revise(instruction=relevance_instruction, context=entity_mentions)

        # Step 3: Perform multi-hop reasoning to connect facts
        reasoning_instruction = f"""
        Using the filtered information: {relevant_info}, perform multi-hop reasoning to determine the nationalities of the entities.
        Connect indirect references and synthesize facts from multiple documents to build a coherent reasoning chain.
        """
        reasoning_results = await asyncio.gather(
            self.generate(instruction=reasoning_instruction, context=relevant_info),
            self.generate(instruction=reasoning_instruction, context=relevant_info)
        )

        # Step 4: Synthesize the final answer
        synthesis_instruction = """
        Compare and synthesize the reasoning results to determine whether the entities satisfy the condition in the question.
        Provide a concise answer that directly addresses the question.
        """
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=reasoning_results)

        # Step 5: Summarize the final answer
        summary_instruction = f"""
        Condense the synthesized answer: {final_answer} into a brief, precise response.
        Ensure the response directly answers the question without unnecessary details.
        """
        summarized_answer = await self.summarize(instruction=summary_instruction, context=final_answer)

        return summarized_answer