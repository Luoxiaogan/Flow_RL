# Workflow ID: hotpotqa_112_0
# Benchmark: hotpotqa
# Data Indices: [325]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Question Analysis
        question_analysis_instruction = (
            "Analyze the question to identify the key entities and the relationship being asked about. "
            "Extract the names of the entities and describe the type of relationship (e.g., network affiliation)."
        )
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 2: Document Selection
        document_selection_instruction = (
            f"Given the identified entities: {question_analysis}, determine which documents are relevant to each entity. "
            "Evaluate each document's relevance based on whether it contains explicit information about the entities."
        )
        document_selection = await self.ensemble(instruction=document_selection_instruction, contexts=[self.problem_text])

        # Step 3: Entity Resolution
        entity_resolution_instructions = []
        entity_contexts = []

        entities = ["Agents of S.H.I.E.L.D.: Slingshot", "Marvel Television"]  # Example entities from the illustrative case
        for entity in entities:
            entity_instruction = (
                f"For the entity '{entity}', extract all relevant information from the provided documents. "
                "Focus on details that describe its network affiliation or related organizational connections."
            )
            entity_resolution_instructions.append(entity_instruction)
            entity_contexts.append(document_selection)

        entity_resolutions = await asyncio.gather(
            *[self.generate(instruction=instr, context=ctx) for instr, ctx in zip(entity_resolution_instructions, entity_contexts)]
        )

        # Step 4: Cross-Document Reasoning
        reasoning_instruction = (
            "Synthesize the information extracted for each entity to determine the shared network affiliation. "
            "Build a reasoning chain that connects the entities through their common network."
        )
        reasoning_result = await self.ensemble(instruction=reasoning_instruction, contexts=entity_resolutions)

        # Step 5: Answer Finalization
        finalize_instruction = (
            "Refine the synthesized reasoning into a concise answer. Ensure the answer is precise, directly addresses the question, "
            "and is supported by evidence from the documents."
        )
        final_answer = await self.revise(instruction=finalize_instruction, context=reasoning_result)

        return final_answer