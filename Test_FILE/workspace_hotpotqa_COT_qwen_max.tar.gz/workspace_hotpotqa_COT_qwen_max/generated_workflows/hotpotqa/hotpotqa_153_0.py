# Workflow ID: hotpotqa_153_0
# Benchmark: hotpotqa
# Data Indices: [147]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Analyze the question to identify the target entity and reasoning type
        question_analysis = await self.generate(
            instruction="Analyze the question to identify the target entity and the type of information being requested. "
                        "Provide a structured output with the entity name and reasoning type (e.g., bridge, comparison).",
            context=self.problem_text
        )

        # Dynamically incorporate the identified entity into subsequent instructions
        entity_name = question_analysis.split("Entity: ")[1].split("\n")[0]
        reasoning_type = question_analysis.split("Reasoning Type: ")[1].split("\n")[0]

        # Step 2: Identify relevant documents based on the target entity
        relevant_docs = await self.generate(
            instruction=f"Identify which documents in the provided context contain information about '{entity_name}'. "
                        "Provide a list of document names or indices.",
            context=self.problem_text
        )

        # Step 3: Extract bridge entity and connect to the answer
        bridge_entity_extraction = await self.generate(
            instruction=f"Using the information from the relevant documents ({relevant_docs}), "
                        f"identify the 'bridge entity' that connects '{entity_name}' to the answer. "
                        "Explain the reasoning chain in detail.",
            context=self.problem_text
        )

        bridge_entity = bridge_entity_extraction.split("Bridge Entity: ")[1].split("\n")[0]

        # Step 4: Locate the document(s) containing information about the bridge entity
        bridge_entity_docs = await self.generate(
            instruction=f"Identify which documents in the provided context contain information about '{bridge_entity}'. "
                        "Provide a list of document names or indices.",
            context=self.problem_text
        )

        # Step 5: Extract the precise answer span from the relevant document(s)
        answer_candidates = await asyncio.gather(
            *[self.generate(
                instruction=f"Extract the specific sentence or fact from the document that answers the question. "
                            f"Ensure the answer is precise and directly addresses the question.",
                context=self.problem_text
            ) for _ in range(len(bridge_entity_docs.split(", ")))]
        )

        # Step 6: Ensemble to select the best answer candidate
        final_answer = await self.ensemble(
            instruction="Evaluate the provided answer candidates and select the most accurate and relevant one. "
                        "Provide the final answer as a concise text span.",
            contexts=answer_candidates
        )

        # Step 7: Refine the final answer for clarity and correctness
        refined_answer = await self.revise(
            instruction="Refine the final answer to ensure it is clear, concise, and grammatically correct. "
                        "If necessary, rephrase the answer while preserving its meaning.",
            context=final_answer
        )

        return refined_answer