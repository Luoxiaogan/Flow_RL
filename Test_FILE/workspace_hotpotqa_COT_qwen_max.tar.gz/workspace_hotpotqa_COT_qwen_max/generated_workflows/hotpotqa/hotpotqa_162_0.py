# Workflow ID: hotpotqa_162_0
# Benchmark: hotpotqa
# Data Indices: [386]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key entities and their mentions
        entity_extraction_instruction = """
        Identify all key entities mentioned in the question and their relationships. 
        Then, find all mentions of these entities across the provided documents. 
        Ensure you track variations of entity names (e.g., synonyms, abbreviations).
        """
        entities_and_mentions = await self.generate(
            instruction=entity_extraction_instruction,
            context=self.problem_text
        )

        # Step 2: Filter relevant documents
        document_filtering_instruction = f"""
        Using the extracted entities and their mentions: {entities_and_mentions}, 
        evaluate each document and determine its relevance to the question. 
        A document is relevant if it contains significant information about the entities 
        or their relationships. Return only the relevant documents.
        """
        relevant_documents = await self.ensemble(
            instruction=document_filtering_instruction,
            contexts=[doc for doc in self.problem_text.split("\n\n") if doc.strip()]
        )

        # Step 3: Construct reasoning chains
        reasoning_chain_instruction = f"""
        Using the relevant documents: {relevant_documents}, 
        construct a reasoning chain that connects the information across documents 
        to answer the question. Ensure the chain explicitly tracks how entities 
        are related and how facts are derived from one document to another.
        """
        reasoning_chain = await self.generate(
            instruction=reasoning_chain_instruction,
            context=relevant_documents
        )

        # Step 4: Synthesize the final answer
        answer_synthesis_instruction = f"""
        From the reasoning chain: {reasoning_chain}, 
        extract the precise answer to the question. Ensure the answer is concise 
        and directly addresses the question. If the answer involves a span of text, 
        include only the relevant portion.
        """
        final_answer = await self.summarize(
            instruction=answer_synthesis_instruction,
            context=reasoning_chain
        )

        # Step 5: Validate and refine the answer
        refinement_instruction = f"""
        Critique the answer: {final_answer}, and refine it if necessary. 
        Ensure the answer is accurate, complete, and directly addresses the question. 
        If any part of the answer is ambiguous or incomplete, improve it.
        """
        refined_answer = await self.revise(
            instruction=refinement_instruction,
            context=final_answer
        )

        return refined_answer