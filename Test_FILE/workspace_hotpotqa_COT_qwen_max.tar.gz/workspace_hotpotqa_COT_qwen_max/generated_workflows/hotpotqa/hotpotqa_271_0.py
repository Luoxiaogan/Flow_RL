# Workflow ID: hotpotqa_271_0
# Benchmark: hotpotqa
# Data Indices: [309]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract key entities and identify relevant documents
        entity_extraction_instruction = """
        Extract all key entities mentioned in the question. Focus on identifying:
        - The type of entity being asked about (e.g., mall, hotel, company).
        - Any specific details provided about these entities (e.g., location, characteristics).
        - Relationships between entities implied by the question.
        Return the extracted entities in a structured format.
        """
        extracted_entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Identify relevant documents and find the bridge entity
        document_selection_instruction = f"""
        Based on the extracted entities ({extracted_entities}), identify which documents contain relevant information.
        Specifically, look for:
        - Documents mentioning hotels managed by companies headquartered in Baar, Switzerland.
        - Documents mentioning malls associated with these hotels.
        Return the names of the relevant documents and the connecting entity (bridge entity) that links them.
        """
        relevant_documents_and_bridge_entity = await self.generate(instruction=document_selection_instruction, context=self.problem_text)

        # Step 3: Extract the surface area of the mall
        answer_extraction_instruction = f"""
        Using the identified bridge entity ({relevant_documents_and_bridge_entity}), locate the document that provides information about the mall's surface area.
        Extract the exact numerical value and unit of the surface area from the document.
        If multiple values are present, use contextual clues to determine the correct one.
        Return the surface area as a precise answer.
        """
        surface_area = await self.generate(instruction=answer_extraction_instruction, context=self.problem_text)

        # Step 4: Validate and refine the answer
        validation_instruction = f"""
        Review the extracted surface area ({surface_area}) to ensure it is accurate and matches the question requirements.
        If necessary, revise the answer to improve clarity or correctness.
        """
        final_answer = await self.revise(instruction=validation_instruction, context=surface_area)

        return final_answer