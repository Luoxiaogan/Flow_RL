# Workflow ID: hotpotqa_111_0
# Benchmark: hotpotqa
# Data Indices: [20]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key entities and parse the question
        entity_extraction_instruction = """
        Analyze the question and extract all key entities, including named entities (e.g., people, places, organizations), numerical values, and any other relevant information. 
        Identify the type of information being requested (e.g., population, location, date). Provide the extracted information in a structured format.
        """
        extracted_entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Select relevant documents based on extracted entities
        document_selection_instruction = f"""
        Based on the following extracted entities: {extracted_entities}, determine which documents contain relevant information. 
        Match entities and numerical values mentioned in the question with the content of each document. 
        Return a list of document indices or names that are most likely to contain the answer.
        """
        relevant_documents = await self.generate(instruction=document_selection_instruction, context=self.problem_text)

        # Step 3: Resolve entities and construct reasoning chain
        reasoning_chain_instruction = f"""
        Using the relevant documents identified as {relevant_documents}, resolve entity mentions across documents. 
        Build a reasoning chain that connects the entities and facts mentioned in the question to derive the answer. 
        Ensure that each step in the reasoning chain is logically sound and supported by evidence from the documents.
        """
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 4: Summarize relevant document sections
        summarization_instruction = f"""
        Summarize the key information from the relevant documents identified as {relevant_documents}. 
        Focus on sentences or paragraphs that directly relate to the entities and facts mentioned in the question. 
        Ensure the summary retains all critical details needed to answer the question.
        """
        summarized_info = await self.summarize(instruction=summarization_instruction, context=self.problem_text)

        # Step 5: Revise and refine the reasoning chain
        refinement_instruction = f"""
        Review the reasoning chain constructed as follows: {reasoning_chain}. 
        Critique its logical consistency and accuracy. Refine the chain if necessary to ensure correctness. 
        Incorporate any additional supporting evidence from the summarized information: {summarized_info}.
        """
        refined_reasoning = await self.revise(instruction=refinement_instruction, context=reasoning_chain)

        # Step 6: Extract the final answer
        answer_extraction_instruction = f"""
        Based on the refined reasoning chain: {refined_reasoning}, extract the precise answer to the question. 
        Ensure the answer is concise and directly addresses the query. If the answer involves a specific entity or fact, include it explicitly.
        """
        final_answer = await self.generate(instruction=answer_extraction_instruction, context=self.problem_text)

        return final_answer