# Workflow ID: hotpotqa_149_0
# Benchmark: hotpotqa
# Data Indices: [96]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Parse the question to identify entities
        entity_identification_instruction = (
            "Identify the entities being compared or queried in the question. "
            "Extract these entities and prepare them for document selection."
        )
        entities = await self.generate(instruction=entity_identification_instruction, context=self.problem_text)

        # Step 2: Select relevant documents containing the entities
        document_selection_instruction = (
            f"Given the entities: {entities}, identify which documents contain relevant information about these entities. "
            "Focus on finding documents that mention these entities and could provide useful facts."
        )
        relevant_documents = await self.generate(instruction=document_selection_instruction, context=self.problem_text)

        # Step 3: Extract relevant facts (release years) from the selected documents
        fact_extraction_instruction = (
            f"From the relevant documents: {relevant_documents}, extract specific facts about the entities: {entities}. "
            "Focus on extracting information related to the release years of the films mentioned."
        )
        extracted_facts = await self.generate(instruction=fact_extraction_instruction, context=self.problem_text)

        # Step 4: Compare the extracted facts to determine the older film
        comparison_instruction = (
            f"Given the extracted facts: {extracted_facts}, compare the release years of the films mentioned. "
            "Determine which film is older based on the provided information."
        )
        comparison_results = await self.ensemble(instruction=comparison_instruction, contexts=[extracted_facts])

        # Step 5: Formulate the final answer
        answer_formulation_instruction = (
            f"Based on the comparison results: {comparison_results}, formulate a clear and concise answer to the question. "
            "Ensure the answer directly addresses the question and provides the necessary information."
        )
        final_answer = await self.generate(instruction=answer_formulation_instruction, context=self.problem_text)

        return final_answer