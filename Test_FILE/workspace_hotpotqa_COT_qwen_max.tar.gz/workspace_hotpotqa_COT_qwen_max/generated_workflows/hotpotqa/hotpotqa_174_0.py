# Workflow ID: hotpotqa_174_0
# Benchmark: hotpotqa
# Data Indices: [290]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract entities and relationships
        extraction_instruction = """
        Analyze the provided context documents and extract all key entities (e.g., video games, publishers, characters) 
        and their relationships (e.g., "published by," "antagonist of"). Provide the output in a structured format, 
        such as a list of tuples (entity, relationship, related_entity).
        """
        entities_and_relationships = await self.generate(
            instruction=extraction_instruction,
            context=self.problem_text
        )

        # Step 2: Identify the bridge entity
        bridge_instruction = f"""
        Given the extracted entities and relationships: {entities_and_relationships}, identify the bridge entity 
        that connects the question to the relevant document(s). The bridge entity should be the most relevant 
        entity or relationship that helps answer the question. Return the bridge entity as a string.
        """
        candidate_entities = [
            "Sierra Entertainment",  # Publisher mentioned in the question
            "antagonist figure",     # Key concept in the question
            "F.E.A.R.",              # Game series with a central antagonist
            "Alma Wade"              # Antagonist in the F.E.A.R. series
        ]
        bridge_entity = await self.ensemble(
            instruction=bridge_instruction,
            contexts=candidate_entities
        )

        # Step 3: Construct the reasoning chain
        reasoning_instruction = f"""
        Using the bridge entity: {bridge_entity}, construct a reasoning chain that connects the question 
        to the relevant document(s). The reasoning chain should explain how the bridge entity leads to 
        the answer. Provide the output as a detailed explanation.
        """
        reasoning_chain = await self.generate(
            instruction=reasoning_instruction,
            context=self.problem_text
        )

        # Step 4: Extract the final answer
        answer_instruction = f"""
        Based on the reasoning chain: {reasoning_chain}, extract the final answer to the question. 
        The answer should be a concise text span (e.g., the name of the video game).
        """
        final_answer = await self.summarize(
            instruction=answer_instruction,
            context=reasoning_chain
        )

        return final_answer