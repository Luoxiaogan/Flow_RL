# Workflow ID: hotpotqa_0_0
# Benchmark: hotpotqa
# Data Indices: [58]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Analyze the question and identify key entities
        entity_extraction_instruction = """
        Analyze the question and identify key entities or concepts mentioned in it. 
        These entities could include names, objects, relationships, or specific properties. 
        Return a concise list of these entities.
        """
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Select relevant documents based on the identified entities
        document_selection_instruction = f"""
        Review all provided context documents and identify those that mention any of the following entities: {entities}.
        Return a list of relevant documents along with brief explanations of why they are relevant.
        """
        relevant_documents = await self.generate(instruction=document_selection_instruction, context=self.problem_text)

        # Step 3: Extract key information from the relevant documents
        extraction_tasks = []
        for doc in relevant_documents.split("\n"):
            if doc.strip():  # Ensure the document is not empty
                extraction_instruction = f"""
                Extract sentences or facts from the following document that are relevant to the entities: {entities}.
                Focus on information that helps answer the question: "{self.problem_text}".
                """
                extraction_tasks.append(self.generate(instruction=extraction_instruction, context=doc))

        extracted_facts = await asyncio.gather(*extraction_tasks)

        # Step 4: Construct the reasoning chain by connecting extracted facts
        reasoning_chain_instruction = f"""
        Combine the following extracted facts into a coherent reasoning chain that answers the question: "{self.problem_text}".
        Ensure the reasoning explicitly connects the entities and leads to a clear conclusion.
        Facts: {extracted_facts}
        """
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 5: Summarize the reasoning chain to derive the final answer
        summarization_instruction = """
        Summarize the reasoning chain into a concise answer that directly addresses the question.
        Ensure the answer is precise and supported by the reasoning.
        """
        final_answer = await self.summarize(instruction=summarization_instruction, context=reasoning_chain)

        return final_answer