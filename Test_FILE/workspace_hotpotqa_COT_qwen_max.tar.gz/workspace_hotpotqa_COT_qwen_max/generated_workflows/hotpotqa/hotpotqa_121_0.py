# Workflow ID: hotpotqa_121_0
# Benchmark: hotpotqa
# Data Indices: [136]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Document Selection and Relevance Filtering
        document_filter_instruction = (
            "Identify all documents that mention historical transportation routes "
            "(e.g., Santa Fe Trail) or modern highways (e.g., U.S. Route 56). "
            "Focus on documents that provide context about alignments, origins, or connections "
            "between these routes and highways. Return a list of relevant document summaries."
        )
        relevant_documents = await self.generate(instruction=document_filter_instruction, context=self.problem_text)

        # Step 2: Entity Resolution and Bridging
        entity_extraction_instruction = (
            f"From the following relevant documents:\n{relevant_documents}\n"
            "Extract key entities such as historical routes (e.g., Santa Fe Trail), modern highways "
            "(e.g., U.S. Route 56), and any shared entities or concepts that connect them. "
            "Provide a mapping of how these entities relate to each other."
        )
        entity_mapping = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 3: Reasoning Chain Construction
        reasoning_chain_instruction = (
            f"Using the entity mapping:\n{entity_mapping}\n"
            "Construct a reasoning chain that explains how the Santa Fe Trail aligns with or influenced "
            "modern highways like U.S. Route 56. Ensure the chain includes logical steps and references "
            "to specific documents where applicable."
        )
        reasoning_chain = await self.revise(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 4: Answer Extraction
        answer_extraction_instruction = (
            f"Based on the reasoning chain:\n{reasoning_chain}\n"
            "Extract the precise answer span that directly answers the question. "
            "Ensure the response is concise and formatted appropriately."
        )
        final_answer = await self.summarize(instruction=answer_extraction_instruction, context=self.problem_text)

        return final_answer