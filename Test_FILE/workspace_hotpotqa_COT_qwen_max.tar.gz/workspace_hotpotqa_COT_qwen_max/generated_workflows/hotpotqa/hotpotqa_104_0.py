# Workflow ID: hotpotqa_104_0
# Benchmark: hotpotqa
# Data Indices: [0]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract entities from the question
        entity_extraction_instruction = """
        Identify the key entities mentioned in the question. These entities are typically nouns or proper nouns that represent concepts, objects, or topics. 
        Focus on extracting entities that are likely to appear in the context documents. Format the output as a comma-separated list of entities.
        """
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)
        entities_list = [entity.strip() for entity in entities.split(",")]

        # Step 2: Identify relevant documents for each entity
        async def find_relevant_documents(entity):
            document_selection_instruction = f"""
            Given the entity "{entity}", identify which documents from the provided context are most relevant to this entity. 
            Relevant documents are those that explicitly mention the entity or provide information directly related to it. 
            Return the names or identifiers of the relevant documents as a comma-separated list.
            """
            return await self.generate(instruction=document_selection_instruction, context=self.problem_text)

        relevant_documents_tasks = [find_relevant_documents(entity) for entity in entities_list]
        relevant_documents_results = await asyncio.gather(*relevant_documents_tasks)
        relevant_documents = dict(zip(entities_list, relevant_documents_results))

        # Step 3: Extract key facts about each entity from their relevant documents
        async def extract_facts(entity, documents):
            fact_extraction_instruction = f"""
            For the entity "{entity}", extract key facts from the following relevant documents: {documents}. 
            Focus on facts that are likely to help answer the question. Include information about the entity's properties, relationships, or significance. 
            Format the output as a bullet-point list of facts.
            """
            return await self.generate(instruction=fact_extraction_instruction, context=self.problem_text)

        fact_extraction_tasks = [extract_facts(entity, relevant_documents[entity]) for entity in entities_list]
        extracted_facts_results = await asyncio.gather(*fact_extraction_tasks)
        extracted_facts = dict(zip(entities_list, extracted_facts_results))

        # Step 4: Perform cross-document reasoning to synthesize the facts
        reasoning_instruction = f"""
        Based on the following extracted facts, perform multi-hop reasoning to answer the question. 
        Facts for each entity are provided below:
        {extracted_facts}
        Analyze the relationships between the entities and synthesize the information to determine the answer. 
        Provide a clear and concise reasoning chain that leads to the answer.
        """
        reasoning_result = await self.ensemble(
            instruction=reasoning_instruction,
            contexts=[facts for facts in extracted_facts.values()]
        )

        # Step 5: Generate the final answer
        answer_generation_instruction = f"""
        Based on the following reasoning chain, generate a concise and precise answer to the question. 
        Reasoning Chain: {reasoning_result}
        Ensure the answer is directly responsive to the question and includes only the essential information.
        """
        final_answer = await self.generate(instruction=answer_generation_instruction, context=self.problem_text)

        return final_answer