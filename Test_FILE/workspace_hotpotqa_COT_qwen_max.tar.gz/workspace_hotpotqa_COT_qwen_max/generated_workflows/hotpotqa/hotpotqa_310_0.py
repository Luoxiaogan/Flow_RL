# Workflow ID: hotpotqa_310_0
# Benchmark: hotpotqa
# Data Indices: [281]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Analyze the question to determine its type
        question_analysis = await self.generate(
            instruction="Analyze the question to determine its type (bridge, comparison, or compositional). "
                        "Identify key entities and relationships mentioned in the question. "
                        "Provide a detailed breakdown of what the question is asking.",
            context=self.problem_text
        )

        # Step 2: Select relevant documents
        document_selection = await self.generate(
            instruction=f"Based on the following question analysis: {question_analysis}, "
                        "identify which documents contain relevant information. "
                        "Focus on entities and keywords mentioned in the question.",
            context=self.problem_text
        )

        # Step 3: Resolve entities across documents
        entity_resolution = await self.generate(
            instruction=f"Using the selected documents: {document_selection}, "
                        "resolve entities mentioned in the question across multiple documents. "
                        "Establish relationships between entities and events.",
            context=self.problem_text
        )

        # Step 4: Construct reasoning chains in parallel
        reasoning_chain_tasks = []
        for doc in ["March Across the Belts", "Treaty of Roskilde", "Treaty of Copenhagen"]:
            reasoning_chain_tasks.append(
                self.generate(
                    instruction=f"Construct a reasoning chain for the entity/event: {doc}. "
                                "Trace back through related events and extract relevant information.",
                    context=self.problem_text
                )
            )
        reasoning_chains = await asyncio.gather(*reasoning_chain_tasks)

        # Step 5: Extract the final answer
        answer_extraction = await self.generate(
            instruction=f"Based on the reasoning chains: {reasoning_chains}, "
                        "extract the final answer to the question. "
                        "Ensure the answer is precise and matches the expected format.",
            context=self.problem_text
        )

        # Step 6: Refine the answer
        refined_answer = await self.revise(
            instruction="Refine the extracted answer for clarity, accuracy, and conciseness. "
                        "Ensure it directly addresses the question.",
            context=answer_extraction
        )

        return refined_answer