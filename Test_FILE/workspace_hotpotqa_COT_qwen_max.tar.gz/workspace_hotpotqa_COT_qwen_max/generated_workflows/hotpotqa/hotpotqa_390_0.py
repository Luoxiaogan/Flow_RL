# Workflow ID: hotpotqa_390_0
# Benchmark: hotpotqa
# Data Indices: [23]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Entity Identification
        entity_extraction_instruction = """
        Identify all mentions of 'The Black Keys' and 'Beastie Boys' in the provided documents. 
        For each mention, extract the surrounding sentences that describe the band's composition or members.
        Ensure to capture any numerical data related to the number of members.
        """
        entity_mentions = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Member Count Extraction
        member_count_instruction = f"""
        From the extracted mentions: {entity_mentions}, determine the number of members in each band.
        Look for explicit statements about the number of members or infer from descriptions of the band's composition.
        Provide the count for both 'The Black Keys' and 'Beastie Boys'.
        """
        member_counts = await self.generate(instruction=member_count_instruction, context=self.problem_text)

        # Step 3: Comparison
        comparison_instruction = f"""
        Given the member counts: {member_counts}, compare the number of members between 'The Black Keys' and 'Beastie Boys'.
        Determine which band has more members or if they have the same number.
        """
        comparison_result = await self.ensemble(instruction=comparison_instruction, contexts=[member_counts])

        # Step 4: Answer Formulation
        answer_instruction = f"""
        Based on the comparison result: {comparison_result}, formulate a concise answer to the question:
        "Which band has more members, The Black Keys or Beastie Boys?"
        If one band has more members, state that explicitly. If they have the same number of members, indicate that as well.
        """
        final_answer = await self.generate(instruction=answer_instruction, context=self.problem_text)

        return final_answer