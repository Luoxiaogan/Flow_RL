# Workflow ID: hotpotqa_147_0
# Benchmark: hotpotqa
# Data Indices: [375]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Parse the question and extract key entities/relationships
        question_analysis = await self.generate(
            instruction="Analyze the question to identify key entities and relationships. "
                        "Extract the main subject, relationships, and target role. "
                        "Format the output as a JSON object with keys: 'subject', 'relationship', 'target_role'.",
            context=self.problem_text
        )
        question_info = json.loads(question_analysis)

        # Step 2: Identify relevant documents containing the subject and related entities
        document_selection = await self.generate(
            instruction=f"Identify which documents mention the subject '{question_info['subject']}' "
                        f"or related entities based on the relationship '{question_info['relationship']}'. "
                        "Return a list of document indices.",
            context=self.problem_text
        )
        relevant_documents = json.loads(document_selection)

        # Step 3: Resolve the bridge entity by connecting information across documents
        bridge_entity_resolution = await asyncio.gather(
            *[
                self.generate(
                    instruction=f"From the provided context, extract information about '{question_info['subject']}' "
                                f"and its relationship '{question_info['relationship']}'. "
                                "Focus on identifying the bridge entity that connects the documents.",
                    context=self.problem_text.split("Document")[doc_idx + 1].split("\n\n")[0]  # Extract specific document
                )
                for doc_idx in relevant_documents
            ]
        )
        resolved_entities = [json.loads(res) for res in bridge_entity_resolution]

        # Step 4: Chain facts to derive the final answer
        fact_chaining = await self.ensemble(
            instruction=f"Given the following resolved entities: {resolved_entities}, "
                        "chain the facts to determine the answer to the question. "
                        "Ensure the reasoning is explicit and logical.",
            contexts=[self.problem_text.split("Document")[doc_idx + 1].split("\n\n")[0] for doc_idx in relevant_documents]
        )

        # Step 5: Extract the precise answer span
        answer_extraction = await self.generate(
            instruction=f"Based on the fact chaining result: '{fact_chaining}', "
                        "extract the precise answer span from the relevant document. "
                        "Ensure the answer directly addresses the question.",
            context=self.problem_text
        )

        return answer_extraction.strip()