# Workflow ID: hotpotqa_264_0
# Benchmark: hotpotqa
# Data Indices: [160]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Parse the question and extract key entities
        question_analysis = await self.generate(
            instruction="""
            Analyze the provided question and extract all key entities, roles, and relationships.
            Identify what type of question it is (bridge, comparison, compositional, etc.).
            Return the extracted information in a structured format.
            """,
            context=self.problem_text
        )

        # Step 2: Assess document relevance
        async def assess_document_relevance(doc):
            return await self.generate(
                instruction=f"""
                Given the extracted entities and relationships: {question_analysis}
                Determine how relevant this document is to answering the question.
                Focus on whether it contains information about the key entities or relationships.
                Provide a relevance score and a brief justification.
                """,
                context=doc
            )

        # Assuming documents are provided as a list in the problem text
        # For demonstration, we simulate document texts here
        documents = [f"Document {i}" for i in range(1, 11)]
        relevance_results = await asyncio.gather(*[assess_document_relevance(doc) for doc in documents])

        # Step 3: Identify bridge entities
        bridge_entity_detection = await self.generate(
            instruction="""
            Using the extracted entities and relevant documents, identify any bridge entities
            that connect multiple documents. Explain how these entities link the information.
            """,
            context="\n".join(relevance_results)
        )

        # Step 4: Construct reasoning chain
        reasoning_chain = await self.generate(
            instruction=f"""
            Based on the identified bridge entities: {bridge_entity_detection}
            Construct a logical reasoning chain that connects the information across documents.
            Ensure the chain leads to answering the original question.
            """,
            context=self.problem_text
        )

        # Step 5: Extract the final answer
        final_answer = await self.generate(
            instruction=f"""
            From the constructed reasoning chain: {reasoning_chain}
            Extract the precise answer to the original question.
            Ensure the answer is concise and directly addresses the question.
            """,
            context=self.problem_text
        )

        return final_answer