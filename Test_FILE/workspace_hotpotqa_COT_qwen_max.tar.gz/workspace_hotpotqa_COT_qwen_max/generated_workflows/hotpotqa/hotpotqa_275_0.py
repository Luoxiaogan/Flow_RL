# Workflow ID: hotpotqa_275_0
# Benchmark: hotpotqa
# Data Indices: [191]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Document Selection and Relevance Filtering
        documents = self.problem_text.split("\n\n")  # Assuming documents are separated by double newlines
        relevance_tasks = [
            self.generate(
                instruction=f"""
                Determine if the following document is relevant to the question:
                "**Question:** {self.problem_text}"
                Analyze the content and decide if it contains entities, facts, or relationships that could help answer the question.
                Respond with 'Relevant' or 'Not Relevant'.
                """,
                context=doc
            )
            for doc in documents
        ]
        relevance_results = await asyncio.gather(*relevance_tasks)
        relevant_documents = [doc for doc, result in zip(documents, relevance_results) if "Relevant" in result]

        # Step 2: Entity and Fact Extraction
        extraction_tasks = [
            self.generate(
                instruction=f"""
                Extract all key entities, relationships, and facts from the following document that are relevant to the question:
                "**Question:** {self.problem_text}"
                Ensure the extracted information is concise but complete.
                """,
                context=doc
            )
            for doc in relevant_documents
        ]
        extracted_facts = await asyncio.gather(*extraction_tasks)

        # Step 3: Reasoning Chain Construction
        reasoning_chain = await self.ensemble(
            instruction=f"""
            Synthesize the following extracted facts into a coherent reasoning chain to answer the question:
            "**Question:** {self.problem_text}"
            Connect entities and facts logically, ensuring the chain leads to a valid conclusion.
            """,
            contexts=extracted_facts
        )

        # Step 4: Answer Synthesis
        final_answer = await self.summarize(
            instruction=f"""
            Summarize the reasoning chain into a concise answer for the question:
            "**Question:** {self.problem_text}"
            Ensure the answer is precise and directly addresses the question.
            """,
            context=reasoning_chain
        )

        return final_answer