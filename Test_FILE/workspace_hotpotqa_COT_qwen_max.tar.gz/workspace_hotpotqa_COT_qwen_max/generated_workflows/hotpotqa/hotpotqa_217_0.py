# Workflow ID: hotpotqa_217_0
# Benchmark: hotpotqa
# Data Indices: [187]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract entities from the question
        entities_extraction = await self.generate(
            instruction="Identify the main entities mentioned in the question. "
                        "Focus on proper nouns or specific terms that are likely to appear in the context documents. "
                        "Return the entities as a comma-separated list.",
            context=self.problem_text
        )

        # Parse entities into a list
        entities = [entity.strip() for entity in entities_extraction.split(",")]

        # Step 2: Extract family information for each entity (parallel execution)
        family_extraction_tasks = []
        for entity in entities:
            task = self.generate(
                instruction=f"Find the family or taxonomic classification of {entity} from the context documents. "
                            f"Look for explicit mentions of '{entity}' followed by terms like 'family', 'genus', or similar taxonomic descriptors. "
                            f"If multiple families are mentioned, prioritize the most specific one. "
                            f"Return the family name only.",
                context=self.problem_text
            )
            family_extraction_tasks.append(task)

        family_results = await asyncio.gather(*family_extraction_tasks)

        # Step 3: Compare the families of the entities
        comparison_result = await self.ensemble(
            instruction="Compare the families extracted for the entities. "
                        "Determine if they belong to the same family. "
                        "If the families are identical, conclude that they belong to the same family. "
                        "Otherwise, conclude that they do not.",
            contexts=family_results
        )

        # Step 4: Generate the final answer
        final_answer = await self.generate(
            instruction="Based on the comparison result, provide a concise answer to the question. "
                        "If the entities belong to the same family, state so explicitly. "
                        "If not, clearly indicate that they belong to different families.",
            context=comparison_result
        )

        return final_answer