# Workflow ID: hotpotqa_213_0
# Benchmark: hotpotqa
# Data Indices: [268]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify relevant documents
        doc_identification_instruction = """
        Analyze the provided question and determine which documents in the context contain relevant information.
        Focus on identifying documents that mention the entities in the question explicitly.
        Provide a concise list of document names or identifiers.
        """
        relevant_docs_task = self.generate(instruction=doc_identification_instruction, context=self.problem_text)

        # Step 2: Extract key information (population data)
        extraction_instruction = """
        From the provided context, extract all numerical data and descriptive statistics related to population.
        Include the names of the entities (e.g., cities, regions) alongside their respective population figures.
        Ensure the extracted information is structured and easy to interpret.
        """
        extraction_task = self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Execute steps 1 and 2 in parallel
        relevant_docs, extracted_info = await asyncio.gather(relevant_docs_task, extraction_task)

        # Step 3: Resolve entity ambiguities
        entity_resolution_instruction = f"""
        Compare the extracted information from different documents to resolve any ambiguities in entity mentions.
        For example, match variations of the same entity name (e.g., "Danyang" vs. "Danyang, Jiangsu").
        Synthesize a unified representation of each entity and its associated data.
        """
        resolved_entities = await self.ensemble(instruction=entity_resolution_instruction, contexts=[relevant_docs, extracted_info])

        # Step 4: Perform reasoning (comparison or inference)
        reasoning_instruction = f"""
        Based on the resolved entities and their associated data, perform the required reasoning to answer the question.
        For comparison questions, compare the relevant attributes (e.g., population sizes).
        For inferential questions, build a logical chain of reasoning to derive the answer.
        Provide a clear and concise reasoning process along with the final answer.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=resolved_entities)

        # Step 5: Refine the answer
        refinement_instruction = """
        Review the reasoning result and refine it into a concise, accurate, and well-formatted answer.
        Ensure the answer directly addresses the question and is free of unnecessary details.
        """
        final_answer = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        return final_answer