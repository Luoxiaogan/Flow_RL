# Workflow ID: hotpotqa_74_0
# Benchmark: hotpotqa
# Data Indices: [320]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify Relevant Documents
        identify_instruction = (
            "Analyze the question and determine which documents are relevant. "
            "Identify key entities in the question and match them to documents containing related information. "
            "Return a list of document names that are likely to contain the answer."
        )
        relevant_docs = await self.generate(instruction=identify_instruction, context=self.problem_text)

        # Step 2: Extract Supporting Facts from Relevant Documents
        extract_instruction_template = (
            "Given the document text below, extract all sentences or facts that are relevant to the question. "
            "Focus on information that directly relates to the entities or concepts mentioned in the question. "
            "Question: {question}\n\nDocument Text:\n{doc_text}"
        )
        extract_tasks = []
        for doc in relevant_docs.split(","):  # Assuming relevant_docs is a comma-separated list of document names
            doc_text = self.problem_text  # In a real implementation, fetch the actual document text
            extract_instruction = extract_instruction_template.format(question=self.problem_text, doc_text=doc_text)
            extract_tasks.append(self.generate(instruction=extract_instruction, context=doc_text))
        extracted_facts = await asyncio.gather(*extract_tasks)

        # Step 3: Build Reasoning Chains
        ensemble_instruction = (
            "Synthesize the following extracted facts into a coherent reasoning chain. "
            "Identify connections between entities and build a logical chain to arrive at the answer. "
            "Ensure the reasoning is clear and well-supported by the facts."
        )
        reasoning_chain = await self.ensemble(instruction=ensemble_instruction, contexts=extracted_facts)

        # Step 4: Refine the Answer
        refine_instruction = (
            "Refine the following reasoning chain into a concise and precise answer. "
            "Ensure the answer is supported by the facts and formatted appropriately. "
            "If the question requires a specific format (e.g., yes/no, entity name), adhere to that format."
        )
        refined_answer = await self.revise(instruction=refine_instruction, context=reasoning_chain)

        return refined_answer