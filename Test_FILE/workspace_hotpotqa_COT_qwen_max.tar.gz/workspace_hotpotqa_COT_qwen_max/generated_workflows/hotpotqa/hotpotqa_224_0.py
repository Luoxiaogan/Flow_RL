# Workflow ID: hotpotqa_224_0
# Benchmark: hotpotqa
# Data Indices: [124]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract the relationship between "Adventures in Middle-earth" and "The Hobbit"
        relationship_extraction = await self.generate(
            instruction="Identify the relationship between 'Adventures in Middle-earth' and 'The Hobbit'. "
                        "Focus on sentences that mention both entities and describe their connection. "
                        "Provide the exact text from the document that establishes this relationship.",
            context=self.problem_text
        )

        # Step 2: Locate the release year of "The Hobbit"
        hobbit_release_year_extraction = await self.generate(
            instruction="Find the release year of 'The Hobbit' by J.R.R. Tolkien. "
                        "Look for sentences that explicitly mention the publication date or year of 'The Hobbit'. "
                        "Provide the exact text from the document that contains this information.",
            context=self.problem_text
        )

        # Step 3: Parallelize independent operations if needed
        # For example, if additional facts need extraction, they can be processed in parallel here.

        # Step 4: Combine the extracted information to synthesize the answer
        final_answer = await self.ensemble(
            instruction="Combine the following pieces of information to answer the question: "
                        f"Relationship: {relationship_extraction}. "
                        f"Release Year: {hobbit_release_year_extraction}. "
                        "Ensure the final answer is concise and directly addresses the question.",
            contexts=[relationship_extraction, hobbit_release_year_extraction]
        )

        return final_answer