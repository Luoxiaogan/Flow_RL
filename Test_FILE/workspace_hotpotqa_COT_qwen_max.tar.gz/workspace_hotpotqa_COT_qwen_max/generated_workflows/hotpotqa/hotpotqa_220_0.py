# Workflow ID: hotpotqa_220_0
# Benchmark: hotpotqa
# Data Indices: [343]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key entities and relevant context
        entity_extraction_instruction = """
        Identify all named entities (people, places, distances, etc.) mentioned in the question. 
        Then, search through the provided context documents to extract sentences or paragraphs 
        that contain these entities. Return the extracted information in a structured format.
        """
        extracted_context = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Identify the bridge entity
        bridge_entity_instruction = f"""
        Analyze the extracted context below and identify the "bridge entity" that connects 
        the entities mentioned in the question. A bridge entity is typically a shared entity 
        (e.g., a person, place, or concept) that links information across multiple documents. 
        If multiple candidates exist, list them all for further evaluation.

        Extracted Context: {extracted_context}
        """
        bridge_entities = await self.generate(instruction=bridge_entity_instruction, context=self.problem_text)

        # Step 3: Decide on the best bridge entity (if multiple candidates)
        if "and" in bridge_entities or "," in bridge_entities:  # Multiple candidates detected
            ensemble_instruction = """
            Evaluate the candidate bridge entities listed below and select the one that 
            most effectively connects the entities mentioned in the question. Provide a 
            justification for your choice.

            Candidate Bridge Entities: {}
            """.format(bridge_entities)
            best_bridge_entity = await self.ensemble(instruction=ensemble_instruction, contexts=[bridge_entities])
        else:
            best_bridge_entity = bridge_entities

        # Step 4: Construct the reasoning chain and synthesize the answer
        reasoning_chain_instruction = f"""
        Using the best bridge entity identified below, construct a reasoning chain that 
        connects the entities mentioned in the question. Then, synthesize the final answer 
        in a concise and clear format. Ensure the answer directly addresses the question.

        Best Bridge Entity: {best_bridge_entity}
        Extracted Context: {extracted_context}
        """
        preliminary_answer = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 5: Refine the final answer
        refine_instruction = """
        Review the preliminary answer below and refine it for clarity, correctness, and 
        conciseness. Ensure the final answer is a direct response to the question and 
        includes only necessary information.

        Preliminary Answer: {}
        """.format(preliminary_answer)
        final_answer = await self.revise(instruction=refine_instruction, context=preliminary_answer)

        return final_answer