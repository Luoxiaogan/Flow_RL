# Workflow ID: hotpotqa_361_0
# Benchmark: hotpotqa
# Data Indices: [210]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify entities and parse the question
        entity_extraction_instruction = (
            "Extract all named entities (people, organizations, etc.) mentioned in the question. "
            "Then determine the specific information being requested by analyzing the question structure. "
            "Provide the results in a structured format."
        )
        entities_and_question = await self.generate(
            instruction=entity_extraction_instruction,
            context=self.problem_text
        )

        # Step 2: Select relevant documents
        document_selection_instruction = (
            f"Given the extracted entities: {entities_and_question}, "
            "identify which documents in the provided context are relevant to answering the question. "
            "Consider both direct mentions of the entities and indirect connections through shared concepts. "
            "Return the indices or names of the relevant documents."
        )
        relevant_documents = await self.ensemble(
            instruction=document_selection_instruction,
            contexts=[self.problem_text]  # Contexts include the problem text for reference
        )

        # Step 3: Extract information from selected documents
        info_extraction_instruction = (
            f"Using the relevant documents identified as {relevant_documents}, "
            "extract specific information related to the entities and the question. "
            "Focus on facts such as affiliations, properties, or numerical data. "
            "Provide the extracted information in a concise format."
        )
        extracted_info = await asyncio.gather(
            self.generate(instruction=info_extraction_instruction, context=self.problem_text),
            self.generate(instruction=info_extraction_instruction, context=self.problem_text)
        )

        # Step 4: Synthesize the final answer
        synthesis_instruction = (
            f"Combine the extracted information: {extracted_info} "
            "to answer the original question. Ensure the answer is precise and directly addresses the query. "
            "If numerical data is involved, provide it explicitly. Format the answer clearly."
        )
        final_answer = await self.generate(
            instruction=synthesis_instruction,
            context=self.problem_text
        )

        # Step 5: Revise the answer for clarity and correctness
        revision_instruction = (
            "Review the provided answer for accuracy, clarity, and completeness. "
            "Ensure it aligns with the original question and includes all necessary details. "
            "Make improvements if needed."
        )
        refined_answer = await self.revise(
            instruction=revision_instruction,
            context=final_answer
        )

        return refined_answer