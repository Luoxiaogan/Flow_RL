# Workflow ID: hotpotqa_186_0
# Benchmark: hotpotqa
# Data Indices: [151]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract relevant documents and entity mentions
        entity_extraction_instruction = """
        Analyze the provided context documents to identify mentions of the entities in the question.
        For each entity, list the documents where they appear and summarize their roles or descriptions.
        Focus on information that helps answer the question.
        """
        entity_mentions = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Analyze entity roles in parallel
        async def analyze_entity(entity_name):
            analysis_instruction = f"""
            Based on the extracted information, determine whether {entity_name} is a singer.
            Provide evidence from the documents to support your conclusion.
            """
            return await self.generate(instruction=analysis_instruction, context=entity_mentions)

        entities = ["Floor Jansen", "Kevin Rowland"]  # Dynamically extract these from the question in a real implementation
        analyses = await asyncio.gather(*(analyze_entity(entity) for entity in entities))

        # Step 3: Compare and synthesize results
        synthesis_instruction = """
        Evaluate the analyses of the entities and determine whether both are singers.
        Provide a concise answer to the question, supported by evidence from the analyses.
        """
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=analyses)

        return final_answer