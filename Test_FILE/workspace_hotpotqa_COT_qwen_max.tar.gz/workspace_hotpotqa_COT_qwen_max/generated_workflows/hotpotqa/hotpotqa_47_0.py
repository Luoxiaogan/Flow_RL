# Workflow ID: hotpotqa_47_0
# Benchmark: hotpotqa
# Data Indices: [120]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Document Selection
        document_selection_instruction = """
        Identify which documents contain information relevant to the question. 
        Match keywords and entities in the question with those found in the provided documents. 
        Return a list of relevant document indices or names.
        """
        relevant_documents = await self.generate(instruction=document_selection_instruction, context=self.problem_text)

        # Step 2: Entity Extraction
        entity_extraction_instruction = f"""
        Extract key entities and relationships from the following relevant documents: {relevant_documents}.
        Ensure you track mentions of the same entity across different documents. 
        Return a structured format listing entities and their relationships.
        """
        extracted_entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 3: Refine Entities
        refine_entities_instruction = f"""
        Review the extracted entities: {extracted_entities}.
        Ensure entities are correctly matched across documents and resolve any ambiguities. 
        Return the refined list of entities and relationships.
        """
        refined_entities = await self.revise(instruction=refine_entities_instruction, context=extracted_entities)

        # Step 4: Reasoning Chain Construction
        reasoning_chain_instruction = f"""
        Using the refined entities: {refined_entities}, construct a reasoning chain that connects the information across documents.
        Ensure the chain logically leads to answering the question. 
        Return the reasoning chain as a structured narrative.
        """
        reasoning_chain = await self.summarize(instruction=reasoning_chain_instruction, context=refined_entities)

        # Step 5: Answer Synthesis
        answer_synthesis_instruction = f"""
        Based on the reasoning chain: {reasoning_chain}, synthesize the final answer to the question.
        Ensure the answer is concise and directly addresses the question. 
        Return the final answer.
        """
        final_answer = await self.generate(instruction=answer_synthesis_instruction, context=reasoning_chain)

        return final_answer