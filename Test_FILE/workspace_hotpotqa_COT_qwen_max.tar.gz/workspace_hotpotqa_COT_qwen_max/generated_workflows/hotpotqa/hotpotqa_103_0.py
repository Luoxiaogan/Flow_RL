# Workflow ID: hotpotqa_103_0
# Benchmark: hotpotqa
# Data Indices: [74]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Analyze the question and identify key entities
        question_analysis = await self.generate(
            instruction="Analyze the question and extract all key entities, including people, organizations, events, and relationships. "
                        "Provide a structured summary of the entities and their roles in the context of the question.",
            context=self.problem_text
        )

        # Step 2: Summarize each document to determine relevance
        documents = self.problem_text.split("\n\n")  # Assuming documents are separated by double newlines
        summaries = await asyncio.gather(
            *[self.summarize(
                instruction=f"Summarize the content of this document. Focus on entities and facts that could be relevant to the question: {question_analysis}.",
                context=doc
            ) for doc in documents]
        )

        # Step 3: Filter relevant documents using Ensemble
        relevant_documents = await self.ensemble(
            instruction=f"Select the documents that are most relevant to the question based on the summaries. "
                        f"Relevant documents should contain information about the entities and relationships mentioned in: {question_analysis}.",
            contexts=summaries
        )

        # Step 4: Extract facts and build reasoning chains
        fact_extraction_tasks = []
        for doc in documents:
            if doc in relevant_documents:  # Assuming relevant_documents contains the full text of selected docs
                fact_extraction_tasks.append(
                    self.generate(
                        instruction=f"Extract all facts from this document that are relevant to the question: {question_analysis}. "
                                    f"Focus on entities, relationships, and events that connect to the entities mentioned in the question.",
                        context=doc
                    )
                )
        extracted_facts = await asyncio.gather(*fact_extraction_tasks)

        # Step 5: Synthesize the answer
        synthesized_answer = await self.ensemble(
            instruction=f"Combine the extracted facts into a coherent answer to the question: {question_analysis}. "
                        f"Ensure the answer directly addresses the question and includes supporting evidence from the documents.",
            contexts=extracted_facts
        )

        # Step 6: Refine the answer
        refined_answer = await self.revise(
            instruction="Refine the synthesized answer to make it concise, accurate, and well-structured. "
                        "Ensure it directly addresses the question and includes only relevant information.",
            context=synthesized_answer
        )

        return refined_answer