# Workflow ID: hotpotqa_221_0
# Benchmark: hotpotqa
# Data Indices: [179]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key entities and identify relevant documents
        entity_extraction_instruction = (
            "Identify all mentions of 'Titus Andronicus', 'motion picture', and 'Elliot Goldenthal' in the provided context. "
            "Focus on sentences that explicitly connect these entities. Provide the extracted sentences verbatim."
        )
        extracted_entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Filter documents based on relevance
        filtering_instruction = (
            f"From the extracted sentences: {extracted_entities}, determine which documents discuss both a motion picture "
            "and its connection to 'Titus Andronicus'. Additionally, identify documents mentioning Elliot Goldenthal's involvement "
            "in composing the soundtrack. Summarize the findings for each relevant document."
        )
        filtered_documents = await self.summarize(instruction=filtering_instruction, context=self.problem_text)

        # Step 3: Build reasoning chains and synthesize information
        reasoning_instruction = (
            f"Using the filtered documents: {filtered_documents}, construct a reasoning chain that connects the motion picture "
            "to 'Titus Andronicus' and Elliot Goldenthal. Ensure the chain explicitly mentions how the motion picture is an adaptation "
            "of the play and how Elliot Goldenthal contributed to its soundtrack. Provide a concise synthesis of the reasoning."
        )
        reasoning_chain = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the answer
        validation_instruction = (
            f"Review the reasoning chain: {reasoning_chain}. Ensure it accurately answers the question and provides precise answer spans. "
            "Refine the response to improve clarity and correctness if needed."
        )
        refined_answer = await self.revise(instruction=validation_instruction, context=reasoning_chain)

        # Step 5: Finalize the answer using Ensemble to select the best candidate
        final_instruction = (
            "Given the refined answer, ensure it is the most accurate and concise response to the question. "
            "If multiple interpretations exist, select the one with the strongest evidence from the documents."
        )
        final_answer = await self.ensemble(instruction=final_instruction, contexts=[refined_answer])

        return final_answer