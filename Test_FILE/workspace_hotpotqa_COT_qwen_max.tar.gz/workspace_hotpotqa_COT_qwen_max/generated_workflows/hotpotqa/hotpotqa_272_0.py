# Workflow ID: hotpotqa_272_0
# Benchmark: hotpotqa
# Data Indices: [305]

class Workflow:
    def __init__(self, config, problem) -> None:
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Entity Extraction and Question Analysis
        entity_extraction_instruction = """
        Analyze the given question to identify the key entities and relationships involved.
        Extract all relevant entities mentioned in the question and describe the relationship between them.
        Focus on entities that are likely to appear in the provided documents.
        """
        extracted_entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Document Selection
        document_selection_instruction = f"""
        Given the extracted entities: {extracted_entities}, evaluate which documents contain relevant information.
        Rank the documents based on their relevance to the entities and relationships identified in the question.
        Consider both direct mentions of the entities and indirect connections through shared concepts.
        """
        document_contexts = [f"Document {i+1}" for i in range(10)]  # Assuming 10 documents as per the example
        selected_documents = await self.ensemble(instruction=document_selection_instruction, contexts=document_contexts)

        # Step 3: Reasoning Chain Construction
        reasoning_chain_instruction = f"""
        Using the selected documents: {selected_documents}, construct a reasoning chain that connects the entities across documents.
        Follow the relationships identified earlier to synthesize the information into a coherent chain of reasoning.
        Ensure that the chain explicitly links the entities mentioned in the question to the final answer.
        """
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 4: Answer Extraction
        answer_extraction_instruction = """
        From the constructed reasoning chain, extract the specific text span or fact that directly answers the question.
        Ensure that the extracted answer is concise and matches the expected answer type (e.g., entity name, phrase, yes/no).
        """
        extracted_answer = await self.summarize(instruction=answer_extraction_instruction, context=reasoning_chain)

        # Step 5: Refinement
        refinement_instruction = f"""
        Critique and refine the extracted answer: {extracted_answer}.
        Ensure that the answer is accurate, complete, and directly addresses the question.
        Cross-check with the original problem context to verify correctness.
        """
        final_answer = await self.revise(instruction=refinement_instruction, context=self.problem_text)

        return final_answer