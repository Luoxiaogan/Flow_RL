# Workflow ID: hotpotqa_311_0
# Benchmark: hotpotqa
# Data Indices: [279]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key entities from the question
        entity_extraction_instruction = """
        Analyze the question and extract all key entities (e.g., movie titles, actors, etc.) that are explicitly mentioned. 
        Focus on identifying entities that are likely to appear in the context documents. 
        Format the output as a JSON object with keys 'entities' and 'types', where 'entities' is a list of entity names and 'types' is a list of their corresponding categories (e.g., 'movie', 'actor').
        """
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)
        
        # Parse the extracted entities
        import json
        entities_data = json.loads(entities)
        entity_names = entities_data.get("entities", [])
        entity_types = entities_data.get("types", [])

        # Step 2: Identify relevant documents for each entity
        document_identification_tasks = []
        for entity, entity_type in zip(entity_names, entity_types):
            instruction = f"""
            Identify all documents that mention the {entity_type} '{entity}'. 
            Provide a concise summary of how '{entity}' is discussed in each document. 
            Format the output as a JSON object with keys 'document_titles' and 'summaries'.
            """
            document_identification_tasks.append(self.generate(instruction=instruction, context=self.problem_text))
        
        document_results = await asyncio.gather(*document_identification_tasks)

        # Parse document results
        document_data = [json.loads(result) for result in document_results]

        # Step 3: Resolve bridge entities
        bridge_entity_instruction = """
        Analyze the provided document summaries and identify entities that are mentioned across multiple documents. 
        These entities serve as potential bridge entities connecting the information. 
        Format the output as a JSON object with keys 'bridge_entities' and 'connections', where 'bridge_entities' is a list of entity names and 'connections' describes how they link the documents.
        """
        bridge_entities_context = "\n".join([str(doc) for doc in document_data])
        bridge_entities = await self.generate(instruction=bridge_entity_instruction, context=bridge_entities_context)

        # Parse bridge entities
        bridge_data = json.loads(bridge_entities)
        bridge_entity_names = bridge_data.get("bridge_entities", [])

        # Step 4: Extract the final answer
        answer_extraction_tasks = []
        for bridge_entity in bridge_entity_names:
            instruction = f"""
            Using the provided context, determine if '{bridge_entity}' is the correct answer to the question. 
            If yes, extract the exact answer span from the text. 
            Format the output as a JSON object with keys 'answer' and 'confidence', where 'answer' is the extracted text and 'confidence' is a score between 0 and 1 indicating the likelihood of correctness.
            """
            answer_extraction_tasks.append(self.generate(instruction=instruction, context=self.problem_text))
        
        answer_results = await asyncio.gather(*answer_extraction_tasks)

        # Parse answer results
        answer_data = [json.loads(result) for result in answer_results]
        best_answer = max(answer_data, key=lambda x: x.get("confidence", 0))

        # Step 5: Validate and summarize the reasoning chain
        reasoning_summary_instruction = f"""
        Summarize the reasoning chain that led to the answer '{best_answer["answer"]}'. 
        Include details about the extracted entities, relevant documents, bridge entities, and the final extraction process. 
        Ensure the summary is concise yet comprehensive.
        """
        reasoning_summary = await self.summarize(instruction=reasoning_summary_instruction, context=self.problem_text)

        # Return the final answer and reasoning summary
        return {
            "answer": best_answer["answer"],
            "reasoning_summary": reasoning_summary
        }