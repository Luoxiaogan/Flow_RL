# Workflow ID: hotpotqa_253_0
# Benchmark: hotpotqa
# Data Indices: [390]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify relevant documents and key entities
        relevance_analysis = await self.generate(
            instruction="""Analyze all provided documents to identify which ones are relevant to the question. 
            Extract key entities mentioned in the question (e.g., names, roles, relationships) and determine which documents discuss these entities. 
            Provide a brief explanation of why each document is relevant or irrelevant.""",
            context=self.problem_text
        )

        # Step 2: Extract the bridge entity connecting the question to the answer
        bridge_entity_extraction = await self.generate(
            instruction=f"""Based on the relevance analysis: {relevance_analysis}, 
            identify the 'bridge entity' that connects the question to the final answer. 
            This could be a shared person, organization, or concept mentioned across multiple documents. 
            Explain how this entity relates to the question and the documents.""",
            context=self.problem_text
        )

        # Step 3: Synthesize the final answer using the bridge entity
        synthesis_task_1 = self.generate(
            instruction=f"""Using the bridge entity identified here: {bridge_entity_extraction}, 
            analyze the relevant documents to extract specific facts or sentences that support the answer. 
            Focus on constructing a logical chain of reasoning that leads to the answer.""",
            context=self.problem_text
        )
        synthesis_task_2 = self.generate(
            instruction=f"""Cross-reference the bridge entity with the question: {self.problem_text}. 
            Ensure that all reasoning steps are explicitly stated and lead to a clear conclusion.""",
            context=self.problem_text
        )

        # Execute synthesis tasks in parallel
        synthesis_results = await asyncio.gather(synthesis_task_1, synthesis_task_2)

        # Combine results using Ensemble
        final_synthesis = await self.ensemble(
            instruction=f"""Given the following analyses: {synthesis_results[0]} and {synthesis_results[1]}, 
            synthesize a concise and accurate answer to the question. Ensure the reasoning chain is complete and unambiguous.""",
            contexts=synthesis_results
        )

        # Step 4: Validate and refine the final answer
        refined_answer = await self.revise(
            instruction="""Review the synthesized answer for accuracy, clarity, and completeness. 
            Ensure that it directly addresses the question and includes all necessary supporting facts. 
            If any part of the reasoning is unclear or incomplete, revise it accordingly.""",
            context=final_synthesis
        )

        return refined_answer