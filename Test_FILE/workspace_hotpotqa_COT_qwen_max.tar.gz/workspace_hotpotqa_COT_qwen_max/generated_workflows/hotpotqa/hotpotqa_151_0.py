# Workflow ID: hotpotqa_151_0
# Benchmark: hotpotqa
# Data Indices: [359]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify key entities in the question
        entity_extraction_instruction = (
            "Identify all named entities (people, places, organizations, etc.) mentioned in the question. "
            "Focus on entities that are likely to appear in the context documents. "
            "Return the entities as a comma-separated list."
        )
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Select relevant documents based on extracted entities
        document_selection_instruction = (
            f"Given the following entities: {entities}, identify which context documents mention these entities. "
            "Return the indices of the relevant documents as a comma-separated list."
        )
        relevant_documents = await self.generate(instruction=document_selection_instruction, context=self.problem_text)

        # Convert document indices to a list of strings for further processing
        relevant_documents_list = [f"Document {i.strip()}" for i in relevant_documents.split(",")]

        # Step 3: Extract relationships between entities in the relevant documents
        relationship_extraction_instruction = (
            f"Given the entities: {entities}, analyze the following documents: {', '.join(relevant_documents_list)}. "
            "Find any relationships or connections between the entities. "
            "If there is a 'bridge entity' that connects the entities in the question, highlight it explicitly. "
            "Provide a concise summary of the relationships."
        )
        relationships = await self.generate(instruction=relationship_extraction_instruction, context=self.problem_text)

        # Step 4: Construct the reasoning chain
        reasoning_chain_instruction = (
            f"Based on the relationships: {relationships}, construct a reasoning chain that answers the question. "
            "Clearly explain how the entities are connected and what the final answer is. "
            "Ensure the reasoning is logical and follows from the provided information."
        )
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 5: Extract and refine the final answer
        answer_extraction_instruction = (
            f"From the reasoning chain: {reasoning_chain}, extract the final answer to the question. "
            "Ensure the answer is precise and directly addresses the question."
        )
        raw_answer = await self.generate(instruction=answer_extraction_instruction, context=self.problem_text)

        answer_refinement_instruction = (
            f"Refine the following answer: {raw_answer}. "
            "Ensure it is clear, concise, and grammatically correct. "
            "If necessary, rephrase it for better readability."
        )
        final_answer = await self.revise(instruction=answer_refinement_instruction, context=raw_answer)

        return final_answer