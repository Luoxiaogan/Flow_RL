# Workflow ID: hotpotqa_372_0
# Benchmark: hotpotqa
# Data Indices: [263]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Identify key entities and select relevant documents
        entity_identification = await self.generate(
            instruction="Extract all named entities (people, movies, etc.) mentioned in the question. "
                        "Then, identify which documents contain information about these entities. "
                        "Provide a list of relevant document IDs and the entities they mention.",
            context=self.problem_text
        )

        # Step 2: Detect the bridge entity
        bridge_entity_detection = await self.generate(
            instruction=f"Using the identified entities and relevant documents from: {entity_identification}, "
                        "find the 'bridge entity' that connects the two pieces of information. "
                        "For example, if the question asks about a relationship between two entities, "
                        "identify the common entity that links them across documents.",
            context=self.problem_text
        )

        # Step 3: Construct the reasoning chain
        reasoning_chain = await self.generate(
            instruction=f"Based on the bridge entity identified here: {bridge_entity_detection}, "
                        "construct a reasoning chain that connects the entities mentioned in the question. "
                        "Include specific sentences from the documents that support each step of the reasoning. "
                        "Ensure the chain leads logically to the final answer.",
            context=self.problem_text
        )

        # Step 4: Extract the final answer
        final_answer = await self.generate(
            instruction=f"From the reasoning chain provided here: {reasoning_chain}, "
                        "extract the precise answer span that directly answers the question. "
                        "Ensure the answer is concise and matches the expected format (e.g., short text, yes/no).",
            context=self.problem_text
        )

        # Optional: Refine the final answer if needed
        refined_answer = await self.revise(
            instruction="Review the extracted answer and ensure it is accurate, complete, and properly formatted. "
                        "If necessary, revise it to improve clarity or correctness.",
            context=final_answer
        )

        return refined_answer