# Workflow ID: hotpotqa_176_0
# Benchmark: hotpotqa
# Data Indices: [143]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Identify the reasoning type
        reasoning_type = await self.generate(
            instruction="""Analyze the question and determine the reasoning type. 
            The reasoning type can be one of the following:
            - Bridge: Connecting information across documents through shared entities.
            - Comparison: Comparing properties or attributes of entities.
            - Compositional: Combining multiple facts to derive the answer.
            Provide the reasoning type as a single word: 'Bridge', 'Comparison', or 'Compositional'.""",
            context=self.problem_text
        )

        # Step 2: Extract relevant information based on reasoning type
        if "Bridge" in reasoning_type:
            extraction_instruction = """Extract shared entities or concepts that connect the documents. 
            Focus on entities mentioned in the question and find connections across documents."""
        elif "Comparison" in reasoning_type:
            extraction_instruction = """Extract properties or attributes of the entities mentioned in the question. 
            Compare these properties across documents."""
        else:  # Compositional
            extraction_instruction = """Extract all facts that might contribute to the final answer. 
            Combine these facts to form a complete picture."""

        extracted_info = await self.generate(
            instruction=extraction_instruction,
            context=self.problem_text
        )

        # Step 3: Resolve entity mentions across documents
        resolved_entities = await self.revise(
            instruction="""Resolve any ambiguous entity mentions across documents. 
            Ensure consistency in referring to the same entity across different contexts.""",
            context=extracted_info
        )

        # Step 4: Build reasoning chain
        reasoning_chain = await self.ensemble(
            instruction="""Synthesize the extracted information into a reasoning chain. 
            Connect facts through shared entities or logical relationships. 
            Ensure the chain leads to the final answer.""",
            contexts=[resolved_entities, self.problem_text]
        )

        # Step 5: Extract final answer
        final_answer = await self.summarize(
            instruction="""Condense the reasoning chain into a precise answer. 
            Ensure the answer matches the expected format (short text span, yes/no, or factual response).""",
            context=reasoning_chain
        )

        return final_answer