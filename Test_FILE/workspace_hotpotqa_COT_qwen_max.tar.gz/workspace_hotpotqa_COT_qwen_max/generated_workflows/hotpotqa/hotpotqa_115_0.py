# Workflow ID: hotpotqa_115_0
# Benchmark: hotpotqa
# Data Indices: [59]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio
        
        # Step 1: Identify the 1987 war film mentioned in "The Pervert's Guide to Ideology"
        instruction_1 = (
            "From the provided context, identify the name of the 1987 British-American war film "
            "that is explored in 'The Pervert's Guide to Ideology'. Ensure the response is precise "
            "and includes only the name of the film."
        )
        film_name = await self.generate(instruction=instruction_1, context=self.problem_text)

        # Step 2: Extract the director and producer of the identified film
        instruction_2 = (
            f"Based on the provided context, identify the director and producer of the film '{film_name}'. "
            "Ensure the response is structured as follows: Director: [Name], Producer: [Name]."
        )
        film_details = await self.generate(instruction=instruction_2, context=self.problem_text)

        # Step 3: Revise the extracted information for accuracy
        revision_instruction = (
            "Review the following information and ensure it accurately identifies the director and producer "
            "of the specified film. Correct any errors or ambiguities."
        )
        revised_details = await self.revise(instruction=revision_instruction, context=film_details)

        # Step 4: Ensemble to synthesize the final answer
        ensemble_instruction = (
            "Synthesize the final answer based on the provided information. Ensure the response is concise, "
            "accurate, and directly answers the original question."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[revised_details])

        return final_answer