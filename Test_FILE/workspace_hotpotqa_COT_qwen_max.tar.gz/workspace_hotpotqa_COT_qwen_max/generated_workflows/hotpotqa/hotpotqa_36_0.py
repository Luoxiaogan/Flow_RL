# Workflow ID: hotpotqa_36_0
# Benchmark: hotpotqa
# Data Indices: [204]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio
        
        # Step 1: Document Selection
        doc_selection_instruction = """
        Analyze the provided context documents and determine which ones are relevant to answering the question. 
        Focus on documents that contain information about the entities or events mentioned in the question. 
        Provide a list of relevant document indices along with a brief explanation of their relevance.
        """
        relevant_docs = await self.generate(instruction=doc_selection_instruction, context=self.problem_text)
        
        # Step 2: Entity Resolution and Information Extraction
        extraction_instruction = f"""
        Based on the relevant documents identified ({relevant_docs}), extract key entities and facts that are directly related to the question. 
        Pay special attention to entities that serve as "bridge entities" connecting multiple documents. 
        Provide the extracted information in a structured format, such as key-value pairs or bullet points.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)
        
        # Step 3: Reasoning Chain Construction
        reasoning_instruction = f"""
        Using the extracted information ({extracted_info}), construct a reasoning chain that connects the facts to answer the question. 
        If multiple documents are involved, explain how they relate to each other through shared entities or events. 
        Ensure the reasoning chain is explicit and logical.
        """
        reasoning_chain = await self.generate(instruction=reasoning_instruction, context=self.problem_text)
        
        # Step 4: Answer Synthesis
        synthesis_instruction = f"""
        Based on the reasoning chain constructed ({reasoning_chain}), synthesize the final answer to the question. 
        Ensure the answer is concise, precise, and directly addresses the question. 
        If the question asks for a specific entity, date, or fact, provide it explicitly.
        """
        final_answer = await self.summarize(instruction=synthesis_instruction, context=self.problem_text)
        
        return final_answer