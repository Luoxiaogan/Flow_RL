# Workflow ID: hotpotqa_321_0
# Benchmark: hotpotqa
# Data Indices: [22]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify key entities in the question
        entity_instruction = """
        Identify the key entities mentioned in the question. These are typically proper nouns like names of people, organizations, or other named entities. Return the entities as a comma-separated list.
        """
        entities = await self.generate(instruction=entity_instruction, context=self.problem_text)
        entities_list = [entity.strip() for entity in entities.split(",")]

        # Step 2: Select relevant documents for each entity
        doc_selection_tasks = []
        for entity in entities_list:
            doc_instruction = f"""
            Given the entity "{entity}", identify which documents in the provided context contain relevant information about this entity. Return the document numbers as a comma-separated list.
            """
            doc_selection_tasks.append(self.generate(instruction=doc_instruction, context=self.problem_text))

        relevant_docs = await asyncio.gather(*doc_selection_tasks)
        relevant_docs_dict = {entity: docs.split(",") for entity, docs in zip(entities_list, relevant_docs)}

        # Step 3: Extract the specific property being compared for each entity
        property_extraction_tasks = []
        for entity, docs in relevant_docs_dict.items():
            property_instruction = f"""
            For the entity "{entity}" mentioned in the question, extract the specific property being compared (e.g., world ranking, date, etc.) from the following documents: {', '.join(docs)}. Provide the exact value of the property if available. If multiple values are found, return all of them separated by commas.
            """
            property_extraction_tasks.append(self.generate(instruction=property_instruction, context=self.problem_text))

        extracted_properties = await asyncio.gather(*property_extraction_tasks)
        properties_dict = {entity: prop.split(",") for entity, prop in zip(entities_list, extracted_properties)}

        # Step 4: Compare the extracted properties and generate the final answer
        comparison_instruction = f"""
        Given the following properties for each entity:
        {json.dumps(properties_dict, indent=4)}
        Compare the properties to determine which entity has the higher (or lower) value for the specified property. Provide the final answer in the format: "[Entity] has a higher [property] than [Entity]."
        """
        final_answer = await self.ensemble(instruction=comparison_instruction, contexts=list(properties_dict.values()))

        return final_answer