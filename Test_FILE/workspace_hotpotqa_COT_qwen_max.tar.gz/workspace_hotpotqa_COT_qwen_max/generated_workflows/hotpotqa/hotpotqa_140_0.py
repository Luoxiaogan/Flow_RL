# Workflow ID: hotpotqa_140_0
# Benchmark: hotpotqa
# Data Indices: [55]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key entities from the question
        entity_extraction_instruction = """
        Identify all key entities mentioned in the question. These could include names of people, objects, places, or concepts. 
        Provide the entities as a comma-separated list. Ensure that the entities are directly relevant to answering the question.
        """
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Analyze documents for each entity in parallel
        document_analysis_tasks = []
        for entity in entities.split(","):
            entity = entity.strip()
            analysis_instruction = f"""
            Given the entity "{entity}", analyze the provided documents to find any information related to this entity. 
            Focus on identifying relevant sentences or facts that could help answer the original question. 
            If the entity appears in multiple documents, summarize the connections between them.
            """
            task = self.generate(instruction=analysis_instruction, context=self.problem_text)
            document_analysis_tasks.append(task)

        # Execute document analysis tasks in parallel
        document_analysis_results = await asyncio.gather(*document_analysis_tasks)

        # Step 3: Synthesize information using Ensemble
        synthesis_instruction = """
        Given the information extracted from multiple documents, synthesize the key connections between the entities. 
        Resolve any ambiguities or conflicts in the information. Focus on building a reasoning chain that connects 
        the entities to answer the original question. Provide the synthesized information in a concise format.
        """
        synthesized_info = await self.ensemble(instruction=synthesis_instruction, contexts=document_analysis_results)

        # Step 4: Extract the final answer
        final_answer_instruction = """
        Based on the synthesized information, extract the final answer to the original question. 
        Ensure that the answer is precise and directly addresses the question. If the answer is a short text span, 
        provide it exactly as it appears in the documents. If the answer requires inference, clearly explain the reasoning.
        """
        final_answer = await self.generate(instruction=final_answer_instruction, context=synthesized_info)

        return final_answer