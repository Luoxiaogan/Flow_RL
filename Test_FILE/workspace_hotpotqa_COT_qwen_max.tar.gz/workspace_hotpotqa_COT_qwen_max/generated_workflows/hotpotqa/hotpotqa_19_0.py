# Workflow ID: hotpotqa_19_0
# Benchmark: hotpotqa
# Data Indices: [347]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract entities and their attributes from the question
        entity_extraction_instruction = """
        Extract all entities mentioned in the question along with their attributes (e.g., birth year, relationships).
        Provide the output as a structured list, including the entity name and its associated attributes.
        """
        entity_extraction = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Match entities to relevant documents
        document_selection_instruction = f"""
        Using the extracted entities and their attributes ({entity_extraction}), identify which documents contain relevant information.
        Provide a mapping of each entity to the documents where it is mentioned.
        """
        document_selection = await self.generate(instruction=document_selection_instruction, context=self.problem_text)

        # Step 3: Construct reasoning chains across documents
        reasoning_chain_instruction = f"""
        Based on the entity-document mapping ({document_selection}), construct reasoning chains that connect the entities across documents.
        Explicitly state how the entities are related and provide a logical sequence of connections.
        """
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 4: Extract the precise answer from the reasoning chain
        answer_extraction_instruction = f"""
        From the reasoning chain ({reasoning_chain}), extract the precise answer to the question.
        Ensure the answer is concise and directly addresses the question.
        """
        answer_extraction = await self.summarize(instruction=answer_extraction_instruction, context=reasoning_chain)

        return answer_extraction