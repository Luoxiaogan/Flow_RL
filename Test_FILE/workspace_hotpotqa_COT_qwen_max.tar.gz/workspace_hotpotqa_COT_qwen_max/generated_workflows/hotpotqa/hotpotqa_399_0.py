# Workflow ID: hotpotqa_399_0
# Benchmark: hotpotqa
# Data Indices: [189]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Analyze the question to determine its type and extract key entities
        question_analysis = await self.generate(
            instruction="Analyze the question to determine its type (e.g., bridge, comparison, compositional). "
                        "Identify key entities, properties, or relationships mentioned in the question. "
                        "Provide a detailed breakdown of the question's requirements.",
            context=self.problem_text
        )

        # Step 2: Extract entities and keywords from the context documents
        entity_extraction = await self.generate(
            instruction=f"Extract all entities, keywords, and relevant information from the context documents. "
                        f"Focus on entities related to the question analysis: {question_analysis}.",
            context=self.problem_text
        )

        # Step 3: Select relevant documents based on extracted entities
        document_selection = await self.ensemble(
            instruction=f"Select the most relevant documents from the context based on the extracted entities: {entity_extraction}. "
                        f"Ensure the selected documents contain information that can help answer the question.",
            contexts=[self.problem_text]  # Pass the full problem text for document selection
        )

        # Step 4: Construct reasoning chains based on the question type
        reasoning_chain = await self.generate(
            instruction=f"Construct a reasoning chain to answer the question. "
                        f"Use the question analysis: {question_analysis}, extracted entities: {entity_extraction}, "
                        f"and relevant documents: {document_selection}. "
                        f"For bridge questions, identify the 'bridge entity' connecting documents. "
                        f"For comparison questions, extract comparable properties. "
                        f"For compositional questions, combine multiple facts into a coherent chain.",
            context=self.problem_text
        )

        # Step 5: Synthesize the answer
        answer_synthesis = await self.summarize(
            instruction=f"Synthesize the final answer based on the reasoning chain: {reasoning_chain}. "
                        f"Ensure the answer is concise, precise, and matches the expected format (short text span, yes/no, or factual response).",
            context=self.problem_text
        )

        # Step 6: Validate and refine the answer
        refined_answer = await self.revise(
            instruction=f"Validate the answer: {answer_synthesis}. "
                        f"Ensure all supporting facts are correct and the reasoning chain is sound. "
                        f"Refine the answer if necessary to improve clarity and accuracy.",
            context=self.problem_text
        )

        return refined_answer