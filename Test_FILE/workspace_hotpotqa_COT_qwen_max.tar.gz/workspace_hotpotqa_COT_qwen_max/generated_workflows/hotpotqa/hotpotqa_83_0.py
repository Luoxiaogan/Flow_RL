# Workflow ID: hotpotqa_83_0
# Benchmark: hotpotqa
# Data Indices: [161]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify the American skier associated with the High Fives Foundation
        entity_instruction = """
        Analyze the provided documents to identify the American World Cup alpine ski racer and Olympic gold medalist 
        who is associated with the High Fives Foundation. Focus on documents mentioning the foundation and extract 
        the name of the skier explicitly linked to it. Provide the full name of the skier as the result.
        """
        skier_name = await self.generate(instruction=entity_instruction, context=self.problem_text)

        # Step 2: Retrieve the birth year of the identified skier
        birth_year_instruction = f"""
        Based on the identified skier ({skier_name}), locate the document that provides biographical details 
        about this individual. Extract the birth year of the skier from the relevant document. Ensure the birth year 
        is presented in the format YYYY.
        """
        birth_year = await self.generate(instruction=birth_year_instruction, context=self.problem_text)

        # Step 3: Validate the extracted birth year
        validation_instruction = f"""
        Verify that the extracted birth year ({birth_year}) corresponds to the American World Cup alpine ski racer 
        and Olympic gold medalist identified earlier ({skier_name}). Ensure the birth year is accurate and matches 
        the context of the question. If there are discrepancies, refine the answer accordingly.
        """
        final_answer = await self.revise(instruction=validation_instruction, context=birth_year)

        return final_answer