# Workflow ID: hotpotqa_369_0
# Benchmark: hotpotqa
# Data Indices: [60]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract key entities and attributes from the question
        entity_extraction_instruction = """
        Extract all key entities and attributes mentioned in the question. 
        Focus on identifying the main subject (e.g., person, organization) and its descriptors (e.g., nationality, achievements). 
        Return the extracted information in a structured format.
        """
        extracted_entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Filter relevant documents based on extracted entities
        document_filter_instruction = f"""
        Identify which documents are most relevant to the extracted entities and attributes: {extracted_entities}.
        Prioritize documents that mention the main subject and its descriptors.
        Return a list of relevant document indices or summaries.
        """
        relevant_documents = await self.generate(instruction=document_filter_instruction, context=self.problem_text)

        # Step 3: Summarize relevant document content
        summary_tasks = []
        for doc in relevant_documents.split("\n"):  # Assuming documents are separated by newlines
            summary_instruction = f"""
            Summarize the key information from the following document: {doc}.
            Focus on facts related to the extracted entities and attributes: {extracted_entities}.
            """
            summary_tasks.append(self.summarize(instruction=summary_instruction, context=doc))
        document_summaries = await asyncio.gather(*summary_tasks)

        # Step 4: Perform cross-document reasoning
        reasoning_instruction = f"""
        Analyze the following document summaries to connect entities and facts: {document_summaries}.
        Build a reasoning chain that links the extracted entities and attributes across documents.
        Highlight any contradictions or missing information.
        """
        reasoning_chain = await self.generate(instruction=reasoning_instruction, context="\n".join(document_summaries))

        # Step 5: Synthesize the final answer
        synthesis_instruction = f"""
        Based on the reasoning chain: {reasoning_chain}, synthesize a concise answer to the original question.
        Ensure the answer directly addresses the question and includes all necessary details.
        """
        synthesized_answer = await self.generate(instruction=synthesis_instruction, context=self.problem_text)

        # Step 6: Validate and refine the answer
        refinement_instruction = f"""
        Review the synthesized answer: {synthesized_answer}.
        Ensure it is accurate, complete, and supported by the reasoning chain: {reasoning_chain}.
        Refine the answer if needed.
        """
        final_answer = await self.revise(instruction=refinement_instruction, context=synthesized_answer)

        return final_answer