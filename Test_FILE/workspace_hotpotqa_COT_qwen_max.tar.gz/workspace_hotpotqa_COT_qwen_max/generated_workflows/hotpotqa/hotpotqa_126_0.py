# Workflow ID: hotpotqa_126_0
# Benchmark: hotpotqa
# Data Indices: [131]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Parse the question and identify key entities
        entity_extraction_instruction = """
        Analyze the question and extract all key entities, dates, and relationships.
        Identify the type of reasoning required (e.g., bridge, comparison).
        Output the extracted information in a structured format.
        """
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Select relevant documents
        document_selection_instruction = f"""
        Using the extracted entities ({entities}), analyze each document and determine which ones contain relevant information.
        Focus on documents that mention the entities or provide related context.
        Output the list of relevant documents and their key sentences.
        """
        relevant_documents = await self.generate(instruction=document_selection_instruction, context=self.problem_text)

        # Step 3: Resolve entities and link across documents
        entity_resolution_instruction = f"""
        Resolve entity mentions across the relevant documents ({relevant_documents}).
        Ensure consistency in how entities are referred to (e.g., "Valentino's" vs. "Val and Zena Weiler").
        Refine the extracted information to ensure accuracy.
        """
        resolved_entities = await self.revise(instruction=entity_resolution_instruction, context=relevant_documents)

        # Step 4: Construct reasoning chains
        reasoning_chain_instruction = f"""
        Build a reasoning chain by connecting the refined facts ({resolved_entities}).
        For example, if one document mentions "Valentino's was founded by Val and Zena Weiler in 1957," connect this to the question.
        Synthesize the information into a coherent narrative.
        """
        reasoning_chains = await self.generate(instruction=reasoning_chain_instruction, context=resolved_entities)

        # Step 5: Compare and synthesize information
        synthesis_instruction = f"""
        Compare and synthesize the reasoning chains ({reasoning_chains}) to derive the final answer.
        Ensure the reasoning is logically sound and supported by evidence from the documents.
        """
        synthesized_answer = await self.ensemble(instruction=synthesis_instruction, contexts=[reasoning_chains])

        # Step 6: Extract the precise answer span
        answer_extraction_instruction = f"""
        Extract the precise answer span from the synthesized information ({synthesized_answer}).
        Ensure the response is concise and directly answers the question.
        """
        final_answer = await self.summarize(instruction=answer_extraction_instruction, context=synthesized_answer)

        return final_answer