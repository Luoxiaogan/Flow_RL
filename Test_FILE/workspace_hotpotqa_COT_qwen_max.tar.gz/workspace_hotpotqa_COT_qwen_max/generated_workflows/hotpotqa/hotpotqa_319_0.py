# Workflow ID: hotpotqa_319_0
# Benchmark: hotpotqa
# Data Indices: [193]

class Workflow:
    def __init__(self, config, problem) -> None:
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract Key Entities and Relationships
        entity_extraction_instruction = """
        Extract all key entities (people, books, institutions) and their relationships from the provided context documents.
        Focus on entities mentioned in the question and those that appear across multiple documents.
        Include details about their roles and any significant actions or properties associated with them.
        """
        extracted_entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Identify Bridge Entities
        bridge_entity_instruction = f"""
        Based on the extracted entities and relationships: {extracted_entities},
        identify which entities serve as bridges between different documents.
        Specifically, look for entities that connect information necessary to answer the question.
        Provide a detailed explanation of how these entities connect the documents.
        """
        bridge_entities = await self.generate(instruction=bridge_entity_instruction, context=self.problem_text)

        # Step 3: Document Selection and Summarization
        document_summary_instruction = f"""
        Using the identified bridge entities: {bridge_entities},
        determine which documents are relevant to the question.
        Summarize these documents focusing on parts that mention the bridge entities or related information.
        Ensure the summaries capture the essential details needed to answer the question.
        """
        relevant_summaries = await self.summarize(instruction=document_summary_instruction, context=self.problem_text)

        # Step 4: Reasoning Chain Construction
        reasoning_chain_instruction = f"""
        Construct a reasoning chain based on the summarized documents: {relevant_summaries}.
        Explicitly connect the information from each document through the identified bridge entities.
        Ensure each step in the chain logically follows from the previous one and leads towards answering the question.
        """
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 5: Answer Extraction and Refinement
        answer_refinement_instruction = f"""
        From the constructed reasoning chain: {reasoning_chain},
        extract the final answer to the question.
        Ensure the answer is precise, directly addresses the question, and includes supporting facts from the chain.
        """
        initial_answer = await self.generate(instruction=answer_refinement_instruction, context=self.problem_text)

        refined_answer = await self.revise(instruction="Refine the answer to ensure clarity, precision, and correctness.", context=initial_answer)

        return refined_answer