# Workflow ID: hotpotqa_94_0
# Benchmark: hotpotqa
# Data Indices: [47]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Document Selection
        document_selection_instruction = """
        Identify all documents that contain information about the entities mentioned in the question. 
        Focus on extracting documents that are directly relevant to answering the question. 
        Ensure that the output includes only the most pertinent documents.
        """
        relevant_documents = await self.generate(instruction=document_selection_instruction, context=self.problem_text)

        # Step 2: Entity Resolution
        entity_resolution_instruction = f"""
        Analyze the provided documents and resolve entity mentions across them. 
        Ensure that entities mentioned in the question are consistently tracked across the documents. 
        Identify shared entities or relationships between the documents. 
        Relevant documents: {relevant_documents}
        """
        resolved_entities = await self.generate(instruction=entity_resolution_instruction, context=self.problem_text)

        # Step 3: Reasoning Chain Construction
        reasoning_chain_instruction = f"""
        Using the resolved entities and relevant documents, construct a logical reasoning chain to answer the question. 
        Synthesize facts from the documents to derive the answer. 
        Ensure that the reasoning process is clear and explicitly connects the entities mentioned in the question. 
        Resolved entities: {resolved_entities}
        Relevant documents: {relevant_documents}
        """
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 4: Answer Extraction
        answer_extraction_instruction = f"""
        Extract the precise answer span from the reasoning chain. 
        Ensure the response is concise and directly answers the question. 
        Reasoning chain: {reasoning_chain}
        """
        final_answer = await self.summarize(instruction=answer_extraction_instruction, context=reasoning_chain)

        return final_answer