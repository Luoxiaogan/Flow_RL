# Workflow ID: hotpotqa_323_0
# Benchmark: hotpotqa
# Data Indices: [152]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract key entities and select relevant documents
        entity_extraction_instruction = """
        Identify all key entities mentioned in the question, such as names of people, groups, or specific terms. 
        Then, determine which documents from the provided context are most relevant to these entities. 
        Provide a list of relevant entities and their associated documents.
        """
        entity_extraction = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Identify the bridge entity connecting the documents
        bridge_entity_instruction = f"""
        Based on the extracted entities and their associated documents, identify the bridge entity or concept 
        that connects the information across multiple documents. This could be a shared group, event, or relationship. 
        Explain how the bridge entity relates to the question.
        """
        bridge_entity = await self.generate(instruction=bridge_entity_instruction, context=entity_extraction)

        # Step 3: Construct and refine the reasoning chain
        reasoning_chain_instruction = f"""
        Using the identified bridge entity, construct a reasoning chain that connects the question to the answer. 
        Ensure that the chain explicitly links the entities mentioned in the question to the final answer. 
        If there are any ambiguities or gaps, address them here.
        """
        reasoning_chain = await self.revise(instruction=reasoning_chain_instruction, context=bridge_entity)

        # Step 4: Extract the final answer
        answer_extraction_instruction = """
        Extract the final answer from the reasoning chain. The answer should be concise and directly address the question. 
        If the answer involves an entity name, phrase, or fact, ensure it is clearly stated.
        """
        final_answer = await self.summarize(instruction=answer_extraction_instruction, context=reasoning_chain)

        return final_answer