# Workflow ID: hotpotqa_225_0
# Benchmark: hotpotqa
# Data Indices: [238]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Identify relevant documents containing the entities in the question
        relevant_docs_instruction = (
            "Identify all documents that mention the entities in the question. "
            "Focus on documents that provide information about the roles or professions of these entities. "
            "If there are multiple entities with the same name, note this ambiguity for later resolution."
        )
        relevant_docs = await self.generate(instruction=relevant_docs_instruction, context=self.problem_text)

        # Step 2: Summarize key sentences describing the entities' roles or professions
        summarization_instruction = (
            f"From the identified documents ({relevant_docs}), extract key sentences that describe "
            "the roles, professions, or activities of the entities mentioned in the question. "
            "Ensure the summaries include sufficient context to resolve ambiguities."
        )
        summaries = await self.summarize(instruction=summarization_instruction, context=relevant_docs)

        # Step 3: Resolve ambiguities (e.g., disambiguate multiple "Aqeel Ahmed" entries)
        disambiguation_instruction = (
            f"Review the summaries ({summaries}) and resolve any ambiguities regarding entity identity. "
            "For example, if there are multiple individuals with the same name, use contextual clues "
            "to determine which one is relevant to the question. Provide a clear explanation of your reasoning."
        )
        resolved_entities = await self.revise(instruction=disambiguation_instruction, context=summaries)

        # Step 4: Synthesize the extracted information into a coherent answer
        synthesis_instruction = (
            f"Given the resolved entities ({resolved_entities}), construct a logical chain of reasoning "
            "to answer the question. Ensure the answer is concise and supported by evidence from the summaries. "
            "If the question requires a yes/no answer, explicitly state the reasoning behind your conclusion."
        )
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=[resolved_entities])

        return final_answer