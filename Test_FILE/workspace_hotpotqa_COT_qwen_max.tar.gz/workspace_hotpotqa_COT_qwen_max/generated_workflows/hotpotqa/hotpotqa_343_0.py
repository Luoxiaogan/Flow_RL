# Workflow ID: hotpotqa_343_0
# Benchmark: hotpotqa
# Data Indices: [283]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract entities and analyze the question
        question_analysis = await self.generate(
            instruction="Analyze the question and extract all key entities, concepts, and the type of reasoning required (e.g., bridge, comparison, compositional).",
            context=self.problem_text
        )

        # Step 2: Identify relevant documents
        document_relevance_tasks = [
            self.generate(
                instruction=f"Given the extracted entities and concepts: {question_analysis}\n"
                            "Determine if this document contains relevant information.",
                context=document
            )
            for document in self.config['documents']  # Assuming documents are provided in the config
        ]
        document_relevance_results = await asyncio.gather(*document_relevance_tasks)

        # Step 3: Identify bridge entities
        bridge_entity = await self.ensemble(
            instruction="Compare mentions of entities across the following documents and identify the most likely bridge entity that connects them.",
            contexts=document_relevance_results
        )

        # Step 4: Construct reasoning chain
        reasoning_chain = await self.generate(
            instruction=f"Using the identified bridge entity: {bridge_entity}\n"
                        "Construct a reasoning chain by synthesizing information from the relevant documents.",
            context="\n".join(document_relevance_results)
        )

        # Step 5: Extract the final answer
        final_answer = await self.summarize(
            instruction="Extract the precise answer from the constructed reasoning chain. Ensure the answer is concise and directly addresses the question.",
            context=reasoning_chain
        )

        return final_answer