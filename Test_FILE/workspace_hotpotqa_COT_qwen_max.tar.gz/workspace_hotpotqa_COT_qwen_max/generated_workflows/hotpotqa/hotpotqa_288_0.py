# Workflow ID: hotpotqa_288_0
# Benchmark: hotpotqa
# Data Indices: [153]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify relevant documents for each entity
        async def extract_relevant_info(entity):
            instruction = f"""
            Identify all mentions of the entity "{entity}" in the provided context documents.
            Focus on sentences or phrases that explicitly state whether "{entity}" is a film.
            If no explicit statement is found, note any indirect evidence or lack thereof.
            Ensure the output is concise but includes all relevant information.
            """
            return await self.generate(instruction=instruction, context=self.problem_text)

        # Step 2: Verify if each entity is a film
        async def verify_film_status(entity, info):
            instruction = f"""
            Analyze the following information about "{entity}":
            {info}
            Determine whether "{entity}" is explicitly stated to be a film.
            If there is ambiguity, provide reasoning for why it cannot be definitively classified as a film.
            Output your conclusion as "Yes", "No", or "Uncertain".
            """
            return await self.generate(instruction=instruction, context=info)

        # Parallel extraction of relevant information for both entities
        entities = ["Tonka", "The Happiest Millionaire"]
        extraction_tasks = [extract_relevant_info(entity) for entity in entities]
        extracted_info = await asyncio.gather(*extraction_tasks)

        # Parallel verification of film status for both entities
        verification_tasks = [
            verify_film_status(entity, info) for entity, info in zip(entities, extracted_info)
        ]
        verification_results = await asyncio.gather(*verification_tasks)

        # Step 3: Build reasoning chain and construct final answer
        instruction = f"""
        Based on the following verification results:
        - Tonka: {verification_results[0]}
        - The Happiest Millionaire: {verification_results[1]}
        Determine whether both entities are films.
        If both are confirmed as films, answer "Yes". If either is not a film, answer "No".
        If there is uncertainty for either entity, answer "Uncertain".
        """
        final_answer = await self.generate(instruction=instruction, context="")

        return final_answer