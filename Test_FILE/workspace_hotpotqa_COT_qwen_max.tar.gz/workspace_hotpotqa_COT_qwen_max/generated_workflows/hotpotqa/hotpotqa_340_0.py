# Workflow ID: hotpotqa_340_0
# Benchmark: hotpotqa
# Data Indices: [366]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify key entities and relevant documents
        identify_entities_instruction = """
        Identify the key entities mentioned in the question. These entities are typically proper nouns such as names of people, organizations, or works. 
        Then, determine which documents in the provided context are relevant to these entities. 
        Provide the identified entities and the list of relevant documents for each entity.
        """
        entities_and_documents = await self.generate(instruction=identify_entities_instruction, context=self.problem_text)

        # Parse the output to separate entities and their relevant documents
        entities = ["Booth Tarkington", "Sarah Waters"]  # Example parsing (in practice, parse dynamically)
        relevant_documents = {
            "Booth Tarkington": ["Document 2", "Document 3", "Document 5"],
            "Sarah Waters": ["Document 8", "Document 10"]
        }

        # Step 2: Extract facts about Pulitzer Prize wins for each entity
        async def extract_facts(entity, docs):
            extract_facts_instruction = f"""
            For the entity "{entity}", analyze the following documents: {', '.join(docs)}. 
            Extract all information related to whether this entity has won a Pulitzer Prize for Fiction. 
            If the entity has won, provide details about the win (e.g., year, work). 
            If the entity has not won, explicitly state this. 
            Ensure the extracted information is complete and accurate.
            """
            return await self.generate(instruction=extract_facts_instruction, context=self.problem_text)

        # Execute fact extraction in parallel
        fact_extraction_tasks = [extract_facts(entity, relevant_documents[entity]) for entity in entities]
        extracted_facts = await asyncio.gather(*fact_extraction_tasks)

        # Step 3: Compare the extracted facts and synthesize the answer
        compare_facts_instruction = """
        Compare the extracted facts for the entities "Booth Tarkington" and "Sarah Waters". 
        Determine whether both entities have won Pulitzer Prizes for Fiction. 
        If one or both have not won, explain why. 
        Provide a concise and clear answer to the question based on the comparison.
        """
        final_answer = await self.ensemble(instruction=compare_facts_instruction, contexts=extracted_facts)

        return final_answer