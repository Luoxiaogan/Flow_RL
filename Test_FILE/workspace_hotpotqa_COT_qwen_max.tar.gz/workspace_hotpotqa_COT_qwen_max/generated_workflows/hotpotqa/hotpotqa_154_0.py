# Workflow ID: hotpotqa_154_0
# Benchmark: hotpotqa
# Data Indices: [13]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Summarize each document to identify relevance
        summaries = await asyncio.gather(
            *[self.summarize(
                instruction="Summarize the document focusing on mentions of Jim Dickey and any significant actions like redshirting players.",
                context=doc
            ) for doc in self.problem_text['context_documents']]
        )

        # Step 2: Select relevant documents using Ensemble
        relevant_docs = await self.ensemble(
            instruction="Select documents that specifically mention Jim Dickey redshirting players and provide details about the football team's performance.",
            contexts=summaries
        )

        # Step 3: Extract key information from relevant documents
        extraction_tasks = []
        for doc in self.problem_text['context_documents']:
            if doc in relevant_docs:
                extraction_tasks.append(
                    self.generate(
                        instruction=f"Extract the year Jim Dickey redshirted players and the final record of the Kansas State Wildcats football team from this document: {doc}",
                        context=doc
                    )
                )
        extracted_info = await asyncio.gather(*extraction_tasks)

        # Step 4: Synthesize the extracted information into an answer
        synthesized_answer = await self.generate(
            instruction="Combine the extracted information to form a coherent answer to the question: What was the final record for the Kansas State Wildcats football team in the year that Jim Dickey redshirted 18 players?",
            context="\n".join(extracted_info)
        )

        # Step 5: Refine the synthesized answer for accuracy and clarity
        final_answer = await self.revise(
            instruction="Revise the answer to ensure it is precise, clear, and directly answers the question.",
            context=synthesized_answer
        )

        return final_answer