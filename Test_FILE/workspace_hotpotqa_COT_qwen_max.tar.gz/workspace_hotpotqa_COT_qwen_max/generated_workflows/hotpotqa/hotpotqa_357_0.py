# Workflow ID: hotpotqa_357_0
# Benchmark: hotpotqa
# Data Indices: [31]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract key entities and relationships from the question
        entity_extraction_instruction = """
        Analyze the question to identify key entities and relationships.
        Specifically, extract:
        - The name of the series mentioned in the question.
        - The episode title or other identifying details.
        - Any indirect references to related entities (e.g., novels, authors).
        Provide the extracted information in a structured format.
        """
        entity_extraction = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Identify relevant documents
        document_selection_instruction = f"""
        Based on the extracted entities: {entity_extraction}, analyze the provided context documents.
        Identify which documents contain information about:
        - The series mentioned in the question.
        - The novel or source material the series is based on.
        - The author of the novel.
        List the relevant documents and briefly explain their relevance.
        """
        document_selection = await self.generate(instruction=document_selection_instruction, context=self.problem_text)

        # Step 3: Construct the reasoning chain
        reasoning_chain_instruction = f"""
        Using the relevant documents: {document_selection}, construct a reasoning chain to answer the question.
        Specifically:
        - Identify the series and its connection to the novel.
        - Trace the novel back to its author.
        Provide the reasoning chain in a clear, step-by-step format.
        """
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 4: Extract the final answer
        answer_extraction_instruction = f"""
        From the reasoning chain: {reasoning_chain}, extract the final answer to the question.
        Ensure the answer is precise and matches the expected format (e.g., the author's name).
        """
        final_answer = await self.summarize(instruction=answer_extraction_instruction, context=reasoning_chain)

        return final_answer