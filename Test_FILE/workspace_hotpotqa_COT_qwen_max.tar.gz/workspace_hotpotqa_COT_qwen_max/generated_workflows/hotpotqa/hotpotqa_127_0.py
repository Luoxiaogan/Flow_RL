# Workflow ID: hotpotqa_127_0
# Benchmark: hotpotqa
# Data Indices: [177]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Identify key entities and relevant documents
        entity_extraction = await self.generate(
            instruction="Identify the key entities mentioned in the question and find which documents contain information about these entities. "
                        "Focus on entities like 'Johns Mountain' and 'National Forest'. "
                        "Return the names of the relevant documents and the sentences mentioning these entities.",
            context=self.problem_text
        )

        # Step 2: Identify the bridge entity
        bridge_entity_identification = await self.generate(
            instruction=f"Based on the extracted entities and their mentions in the documents ({entity_extraction}), "
                        "identify the bridge entity that connects the question's entities to the final answer. "
                        "For example, determine which National Forest 'Johns Mountain' is located in.",
            context=self.problem_text
        )

        # Step 3: Extract specific facts about the bridge entity
        fact_extraction_task = await self.generate(
            instruction=f"Extract specific facts about the bridge entity identified ({bridge_entity_identification}). "
                        "Focus on numerical data, such as the total acreage of the National Forest where 'Johns Mountain' is located.",
            context=self.problem_text
        )

        # Step 4: Summarize the relevant information
        summary_task = await self.summarize(
            instruction="Condense the extracted facts into a concise summary that directly answers the question. "
                        "Ensure the summary includes the total acreage of the National Forest.",
            context=fact_extraction_task
        )

        # Step 5: Synthesize the final answer
        final_answer = await self.ensemble(
            instruction="Evaluate the following summaries and extract the most accurate and complete answer to the question. "
                        "Ensure the answer is precise and supported by the provided facts.",
            contexts=[entity_extraction, bridge_entity_identification, fact_extraction_task, summary_task]
        )

        return final_answer