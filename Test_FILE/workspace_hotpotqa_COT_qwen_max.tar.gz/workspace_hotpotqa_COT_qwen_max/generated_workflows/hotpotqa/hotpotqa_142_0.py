# Workflow ID: hotpotqa_142_0
# Benchmark: hotpotqa
# Data Indices: [201]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key entities and relationships
        entity_extraction_instruction = (
            "Identify all entities mentioned in the context and their relationships. "
            "Focus on people, organizations, and affiliations. "
            "Pay special attention to any mention of 'Gyp Rosetti' and his connections to New York crime families."
        )
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Identify the bridge entity
        bridge_identification_instruction = (
            "From the extracted entities, determine the 'bridge entity' that connects 'Gyp Rosetti' "
            "to the specific New York crime family he worked for. "
            "Look for intermediaries such as bosses or leaders mentioned in the context."
        )
        bridge_candidates = await self.generate(instruction=bridge_identification_instruction, context=entities)

        # Parallel execution for validating bridge candidates
        validation_instructions = [
            f"Validate if '{candidate}' is the correct bridge entity connecting Gyp Rosetti to a New York crime family."
            for candidate in bridge_candidates.split(", ")
        ]
        validations = await asyncio.gather(
            *[self.generate(instruction=instr, context=entities) for instr in validation_instructions]
        )

        # Step 3: Select the most plausible bridge entity
        ensemble_instruction = (
            "Compare the following candidate bridge entities and select the most plausible one. "
            "Ensure the selected entity directly connects Gyp Rosetti to a New York crime family."
        )
        best_bridge = await self.ensemble(instruction=ensemble_instruction, contexts=validations)

        # Step 4: Construct the reasoning chain
        reasoning_chain_instruction = (
            f"Using the bridge entity '{best_bridge}', construct a logical chain that links 'Gyp Rosetti' "
            "to the specific New York crime family he worked for. Include supporting evidence from the context."
        )
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 5: Validate and refine the reasoning chain
        refinement_instruction = (
            "Review the following reasoning chain for logical consistency and completeness. "
            "Ensure it accurately answers the question and is supported by evidence from the context."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=reasoning_chain)

        return refined_answer