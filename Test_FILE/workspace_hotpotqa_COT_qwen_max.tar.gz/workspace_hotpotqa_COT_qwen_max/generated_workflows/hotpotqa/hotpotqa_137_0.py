# Workflow ID: hotpotqa_137_0
# Benchmark: hotpotqa
# Data Indices: [374]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key entities and identify relevant documents
        entity_extraction_instruction = (
            "Identify all key entities mentioned in the question and find "
            "relevant sentences from the provided documents that mention these entities. "
            "Focus on sentences that provide context about the entities' relationships."
        )
        entity_contexts = await asyncio.gather(
            *[self.generate(instruction=entity_extraction_instruction, context=doc) for doc in self.problem_text["documents"]]
        )

        # Step 2: Detect bridge entities and construct reasoning chains
        bridge_detection_instruction = (
            "Analyze the extracted contexts to identify 'bridge entities' that connect "
            "multiple documents. Explain how these entities are related and why they are relevant "
            "to answering the question."
        )
        bridge_entities = await self.generate(
            instruction=bridge_detection_instruction,
            context="\n".join(entity_contexts)
        )

        # Step 3: Summarize key facts and synthesize reasoning chains
        reasoning_instruction = (
            "Summarize the key facts from the relevant documents and construct a reasoning chain "
            "that connects the entities mentioned in the question. Ensure the chain explicitly "
            "explains how the entities are related and leads to the answer."
        )
        reasoning_chain = await self.summarize(
            instruction=reasoning_instruction,
            context=bridge_entities
        )

        # Step 4: Extract candidate answers and select the best one
        answer_extraction_instruction = (
            "Extract all possible answer spans from the reasoning chain that directly address the question. "
            "Ensure the answers are concise and supported by the provided context."
        )
        candidate_answers = await asyncio.gather(
            *[self.generate(instruction=answer_extraction_instruction, context=reasoning_chain) for _ in range(3)]
        )

        final_answer_instruction = (
            "Evaluate the candidate answers and select the most accurate and well-supported one. "
            "Provide a brief justification for your choice."
        )
        final_answer = await self.ensemble(
            instruction=final_answer_instruction,
            contexts=candidate_answers
        )

        return final_answer