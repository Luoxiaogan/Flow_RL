# Workflow ID: hotpotqa_366_0
# Benchmark: hotpotqa
# Data Indices: [302]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Analyze the question to identify key entities and reasoning type
        question_analysis = await self.generate(
            instruction="Analyze the question to identify key entities and determine the type of reasoning required (e.g., bridge, comparison, compositional). Provide a detailed breakdown of the question structure.",
            context=self.problem_text
        )

        # Step 2: Extract entities from the question and context documents
        entity_extraction_task = asyncio.create_task(
            self.generate(
                instruction="Extract all named entities (e.g., people, organizations, albums) mentioned in the question and context documents. Ensure the extraction is comprehensive and includes aliases if applicable.",
                context=self.problem_text
            )
        )

        # Step 3: Select relevant documents based on extracted entities
        document_selection_task = asyncio.create_task(
            self.generate(
                instruction="Identify which documents contain information about the extracted entities. Focus on documents that are most likely to contribute to answering the question.",
                context=self.problem_text
            )
        )

        # Wait for both tasks to complete
        entities, relevant_documents = await asyncio.gather(entity_extraction_task, document_selection_task)

        # Step 4: Identify the bridge entity for cross-document reasoning
        bridge_entity_identification = await self.generate(
            instruction=f"Given the extracted entities ({entities}) and relevant documents ({relevant_documents}), identify the 'bridge entity' that connects multiple documents. Explain why this entity is critical for answering the question.",
            context=self.problem_text
        )

        # Step 5: Build the reasoning chain using the bridge entity
        fact_chaining_task = asyncio.create_task(
            self.generate(
                instruction=f"Using the bridge entity ({bridge_entity_identification}), extract supporting facts from the relevant documents and synthesize them into a coherent reasoning chain. Ensure the chain explicitly connects the dots between documents.",
                context=self.problem_text
            )
        )

        # Step 6: Summarize relevant information from documents
        document_summaries_task = asyncio.create_task(
            asyncio.gather(*[
                self.summarize(
                    instruction="Condense the key information from this document while preserving details relevant to the question.",
                    context=doc
                ) for doc in relevant_documents.split("\n")  # Assuming documents are separated by newlines
            ])
        )

        # Wait for both tasks to complete
        reasoning_chain, document_summaries = await asyncio.gather(fact_chaining_task, document_summaries_task)

        # Step 7: Synthesize the final answer
        final_answer = await self.ensemble(
            instruction=f"Given the reasoning chain ({reasoning_chain}) and document summaries ({document_summaries}), synthesize the final answer. Ensure the answer is precise and directly addresses the question.",
            contexts=[reasoning_chain, *document_summaries]
        )

        return final_answer