# Workflow ID: hotpotqa_125_0
# Benchmark: hotpotqa
# Data Indices: [69]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Analyze the problem to determine reasoning type and key entities
        analysis_instruction = """
        Analyze the given problem text to determine:
        1. The type of reasoning required (bridge, comparison, compositional).
        2. Key entities mentioned in the question.
        3. Any specific constraints or patterns in the question.
        Provide a structured analysis including the reasoning type and entities.
        """
        analysis = await self.generate(instruction=analysis_instruction, context=self.problem_text)

        # Step 2: Extract entities and identify relevant documents
        entity_extraction_instruction = f"""
        Based on the analysis: {analysis}
        Extract all key entities mentioned in the question and identify:
        - Documents that mention these entities.
        - Shared entities across documents (if applicable).
        - Comparable properties for comparison questions (if applicable).
        Provide a list of entities and their corresponding documents.
        """
        entity_extraction = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 3: Construct the reasoning chain
        reasoning_chain_instruction = f"""
        Using the extracted entities and relevant documents: {entity_extraction}
        Construct a reasoning chain to answer the question. Follow these guidelines:
        - For bridge questions, connect entities across documents via shared mentions.
        - For comparison questions, compare properties of entities.
        - For compositional questions, combine multiple facts to derive the answer.
        Ensure the reasoning chain is explicit and logical.
        """
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 4: Extract the precise answer span
        answer_extraction_instruction = f"""
        Based on the reasoning chain: {reasoning_chain}
        Extract the precise answer span that directly addresses the question.
        Ensure the answer is concise and matches the question's requirements.
        """
        answer = await self.generate(instruction=answer_extraction_instruction, context=self.problem_text)

        # Optional: Revise the answer if needed
        revise_instruction = """
        Critique and refine the extracted answer to ensure it is accurate, concise, and directly addresses the question.
        """
        final_answer = await self.revise(instruction=revise_instruction, context=answer)

        return final_answer