# Workflow ID: hotpotqa_32_0
# Benchmark: hotpotqa
# Data Indices: [242]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify relevant documents
        documents = self.problem_text.split("\n\n")  # Split into individual documents
        relevance_tasks = [
            self.generate(
                instruction=f"Determine if this document is relevant to the question. "
                            f"Consider whether it contains entities or facts mentioned in the question. "
                            f"Question: {self.problem_text.split('QUESTION:')[1].strip()}",
                context=doc
            ) for doc in documents
        ]
        relevance_results = await asyncio.gather(*relevance_tasks)

        # Filter relevant documents
        relevant_documents = [doc for doc, result in zip(documents, relevance_results) if "relevant" in result.lower()]

        # Step 2: Extract key entities and relationships
        entity_extraction_tasks = [
            self.generate(
                instruction=f"Extract all key entities and relationships from this document. "
                            f"Focus on entities mentioned in the question: "
                            f"{self.problem_text.split('QUESTION:')[1].strip()}",
                context=doc
            ) for doc in relevant_documents
        ]
        entity_results = await asyncio.gather(*entity_extraction_tasks)

        # Step 3: Build reasoning chains
        reasoning_chain = await self.ensemble(
            instruction=f"Synthesize information from the following extracts to build a reasoning chain. "
                        f"Connect entities and facts to answer the question: "
                        f"{self.problem_text.split('QUESTION:')[1].strip()}",
            contexts=entity_results
        )

        # Step 4: Extract the final answer
        final_answer = await self.summarize(
            instruction=f"Extract the precise answer span from the reasoning chain. "
                        f"The answer should directly address the question: "
                        f"{self.problem_text.split('QUESTION:')[1].strip()}",
            context=reasoning_chain
        )

        return final_answer.strip()