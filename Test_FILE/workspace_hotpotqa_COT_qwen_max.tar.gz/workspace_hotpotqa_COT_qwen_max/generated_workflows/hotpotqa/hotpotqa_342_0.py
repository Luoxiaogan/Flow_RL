# Workflow ID: hotpotqa_342_0
# Benchmark: hotpotqa
# Data Indices: [313]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract entities and keywords from the question
        entity_extraction_instruction = (
            "Identify all key entities, concepts, and relationships mentioned in the question. "
            "Focus on proper nouns, specific terms, and phrases that can help locate relevant documents. "
            "Format the output as a JSON object with keys 'entities' (list of strings) and 'keywords' (list of strings)."
        )
        entity_info = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)
        
        # Parse the extracted entities and keywords
        import json
        entity_data = json.loads(entity_info)
        entities = entity_data.get("entities", [])
        keywords = entity_data.get("keywords", [])

        # Step 2: Identify relevant documents
        document_selection_instruction = (
            f"Using the extracted entities ({', '.join(entities)}) and keywords ({', '.join(keywords)}), "
            "identify which documents in the provided context are most relevant to answering the question. "
            "Return a list of document indices or titles that contain useful information."
        )
        relevant_documents = await self.generate(instruction=document_selection_instruction, context=self.problem_text)

        # Step 3: Detect bridge entities
        bridge_entity_detection_instruction = (
            f"Analyze the relevant documents ({relevant_documents}) to identify shared entities or concepts "
            "that connect information across multiple documents. These 'bridge entities' are crucial for "
            "multi-hop reasoning. Return the most likely bridge entity as a string."
        )
        bridge_entity = await self.generate(instruction=bridge_entity_detection_instruction, context=self.problem_text)

        # Step 4: Chain facts and synthesize the answer
        fact_chaining_instruction = (
            f"Using the bridge entity '{bridge_entity}', chain together facts from the relevant documents "
            "to construct a coherent answer to the question. Ensure the reasoning process is clear and logical. "
            "Provide the final answer as a concise statement."
        )
        candidate_answer = await self.generate(instruction=fact_chaining_instruction, context=self.problem_text)

        # Step 5: Evaluate and refine the answer
        refinement_instruction = (
            f"Review the candidate answer '{candidate_answer}' for completeness and accuracy. "
            "If necessary, refine it by incorporating additional details or correcting errors. "
            "Return the final refined answer."
        )
        final_answer = await self.revise(instruction=refinement_instruction, context=self.problem_text)

        return final_answer