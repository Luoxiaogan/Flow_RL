# Workflow ID: hotpotqa_318_0
# Benchmark: hotpotqa
# Data Indices: [211]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Parse the question and identify key entities and relationships
        entity_extraction_instruction = (
            "Analyze the question and identify the key entities and relationships. "
            "Focus on extracting named entities (e.g., people, places, organizations) and their connections. "
            "For example, if the question asks about a premiere, identify the play, the theater, and any relevant dates. "
            "Return the extracted information in a structured format."
        )
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Select relevant documents and extract information
        document_analysis_instruction = (
            f"Given the extracted entities: {entities}, analyze each document to determine which ones are relevant. "
            "Focus on documents that mention the identified entities and their relationships. "
            "Return a list of relevant documents along with the specific sentences or paragraphs that contain the needed information."
        )
        relevant_documents = await self.generate(instruction=document_analysis_instruction, context=self.problem_text)

        # Step 3: Perform cross-document reasoning
        reasoning_instruction = (
            f"Using the relevant documents: {relevant_documents}, perform cross-document reasoning to connect the information. "
            "Build a reasoning chain that links the entities and answers the question. "
            "For example, if the question asks about the founding year of a theater, find the document that mentions the theater's founding year and link it to the play's premiere. "
            "Return the reasoning chain and the extracted answer."
        )
        reasoning_chain = await self.ensemble(
            instruction=reasoning_instruction,
            contexts=[self.problem_text, entities, relevant_documents]
        )

        # Step 4: Refine the answer
        refinement_instruction = (
            f"Review the reasoning chain: {reasoning_chain} and refine the extracted answer. "
            "Ensure the answer is precise, correct, and complete. "
            "If necessary, revise the answer to address any ambiguities or inconsistencies."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=reasoning_chain)

        # Step 5: Summarize the final answer
        summarization_instruction = (
            f"Condense the refined answer: {refined_answer} into a concise response. "
            "Ensure the final output is in the required format (short text span, yes/no, or factual response)."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_answer)

        return final_answer