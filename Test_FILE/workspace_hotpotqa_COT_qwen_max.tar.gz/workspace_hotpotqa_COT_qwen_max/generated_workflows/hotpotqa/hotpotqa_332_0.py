# Workflow ID: hotpotqa_332_0
# Benchmark: hotpotqa
# Data Indices: [395]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Parse the question to identify key entities and relationships
        question_parsing_instruction = (
            "Carefully analyze the question to identify key entities, their relationships, "
            "and any constraints. Extract names, roles, temporal information, and relational "
            "keywords (e.g., 'succeeded', 'born'). Ensure the output is structured and clear."
        )
        parsed_question = await self.generate(instruction=question_parsing_instruction, context=self.problem_text)

        # Step 2: Select relevant documents based on extracted entities
        document_selection_instruction = (
            f"Given the extracted entities: {parsed_question}, evaluate all provided documents "
            "to determine which are most relevant. Focus on documents that mention the entities "
            "or provide related contextual information. Return the most relevant documents."
        )
        relevant_documents = await self.ensemble(instruction=document_selection_instruction, contexts=[self.problem_text])

        # Step 3: Identify the bridge entity and its connections
        bridge_entity_instruction = (
            f"Using the relevant documents: {relevant_documents}, identify the bridge entity "
            "that connects the information required to answer the question. Explain the "
            "relationship between the bridge entity and other entities mentioned in the question."
        )
        bridge_entity = await self.generate(instruction=bridge_entity_instruction, context=relevant_documents)

        # Step 4: Extract the final answer (e.g., birth date)
        answer_extraction_instruction = (
            f"Based on the bridge entity and its connections: {bridge_entity}, extract the "
            "specific fact requested in the question (e.g., birth date). Ensure the answer "
            "is precise and directly addresses the question."
        )
        extracted_answer = await self.summarize(instruction=answer_extraction_instruction, context=relevant_documents)

        # Step 5: Validate and refine the answer
        refinement_instruction = (
            f"Critique and refine the extracted answer: {extracted_answer}. Ensure the reasoning "
            "chain is logically sound, and the answer is accurate and concise. Correct any errors "
            "or ambiguities."
        )
        final_answer = await self.revise(instruction=refinement_instruction, context=extracted_answer)

        return final_answer