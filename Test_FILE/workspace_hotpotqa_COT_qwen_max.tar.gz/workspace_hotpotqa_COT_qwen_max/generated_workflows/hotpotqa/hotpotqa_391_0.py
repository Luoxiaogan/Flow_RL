# Workflow ID: hotpotqa_391_0
# Benchmark: hotpotqa
# Data Indices: [35]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Understand the question
        question_analysis = await self.generate(
            instruction="Analyze the question to identify the key entities, relationships, and the type of information being requested. "
                        "For example, determine if the question involves a bridge entity, comparison, or compositional reasoning. "
                        "Output a structured summary including the identified entities and reasoning type.",
            context=self.problem_text
        )

        # Step 2: Identify relevant documents
        relevant_documents = await self.generate(
            instruction=f"Based on the analysis: {question_analysis}, identify which documents in the provided context are relevant. "
                        "Look for mentions of the key entities and any related information. "
                        "Output a list of document indices or names that are likely to contain the required information.",
            context=self.problem_text
        )

        # Step 3: Resolve entities across documents
        entity_resolution = await self.generate(
            instruction=f"Using the relevant documents: {relevant_documents}, resolve entities across documents. "
                        "Match entities with similar names or descriptions to establish connections. "
                        "For example, if 'John Cohen' is mentioned in one document and 'banjo player' in another, confirm they refer to the same person. "
                        "Output a mapping of entities and their connections.",
            context=self.problem_text
        )

        # Step 4: Build reasoning chains
        reasoning_chain = await self.generate(
            instruction=f"Based on the resolved entities: {entity_resolution}, construct a logical chain of reasoning to connect the question to the answer. "
                        "For example, trace how 'John Cohen' is connected to a banjo player from a specific Kentucky town. "
                        "Output the reasoning chain step-by-step.",
            context=self.problem_text
        )

        # Step 5: Extract the final answer
        final_answer = await self.generate(
            instruction=f"Using the reasoning chain: {reasoning_chain}, extract the precise answer span from the relevant document(s). "
                        "Ensure the answer directly addresses the question. "
                        "Output the final answer.",
            context=self.problem_text
        )

        return final_answer