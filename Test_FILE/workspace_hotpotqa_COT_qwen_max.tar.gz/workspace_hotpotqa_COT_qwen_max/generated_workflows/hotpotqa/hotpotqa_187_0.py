# Workflow ID: hotpotqa_187_0
# Benchmark: hotpotqa
# Data Indices: [68]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Identify entities (Poe and The Contortionist) and disambiguate
        entity_instruction = """
        Identify the entities mentioned in the question and disambiguate them based on the provided context documents.
        Ensure you match the correct entity descriptions from the documents to the question.
        Provide a clear mapping of each entity to its corresponding document(s).
        """
        entity_mapping = await self.generate(instruction=entity_instruction, context=self.problem_text)

        # Step 2: Select relevant documents for each entity
        doc_selection_instruction = f"""
        Based on the entity mapping: {entity_mapping}, select the documents that contain information about the nationalities of the identified entities.
        Focus on extracting sentences or paragraphs that explicitly mention nationality, origin, or related details.
        """
        relevant_docs = await self.generate(instruction=doc_selection_instruction, context=self.problem_text)

        # Step 3: Extract nationality information (parallel execution for efficiency)
        nationality_instruction_poe = f"""
        From the relevant documents: {relevant_docs}, extract information about the nationality of Poe.
        Consider explicit mentions of nationality, place of birth, or cultural background.
        """
        nationality_instruction_contortionist = f"""
        From the relevant documents: {relevant_docs}, extract information about the nationality of The Contortionist.
        Consider explicit mentions of origin, location, or related details.
        """
        nationality_poe, nationality_contortionist = await asyncio.gather(
            self.generate(instruction=nationality_instruction_poe, context=self.problem_text),
            self.generate(instruction=nationality_instruction_contortionist, context=self.problem_text)
        )

        # Step 4: Synthesize the final answer
        synthesis_instruction = f"""
        Combine the extracted nationality information:
        - Poe: {nationality_poe}
        - The Contortionist: {nationality_contortionist}
        Formulate a concise and accurate answer to the question: "What nationality are Poe and The Contortionist?"
        """
        final_answer = await self.generate(instruction=synthesis_instruction, context=self.problem_text)

        # Step 5: Revise the final answer for clarity and correctness
        revision_instruction = """
        Review the final answer for clarity, accuracy, and completeness.
        Ensure it directly addresses the question and is free of ambiguity.
        """
        polished_answer = await self.revise(instruction=revision_instruction, context=final_answer)

        return polished_answer