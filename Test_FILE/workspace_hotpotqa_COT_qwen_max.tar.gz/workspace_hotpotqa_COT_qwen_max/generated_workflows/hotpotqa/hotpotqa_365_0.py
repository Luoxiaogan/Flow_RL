# Workflow ID: hotpotqa_365_0
# Benchmark: hotpotqa
# Data Indices: [101]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Identify relevant documents mentioning "Summerland Tour" and its founder
        relevant_docs_instruction = (
            "Identify all documents that mention the 'Summerland Tour' and its founder. "
            "Focus on sentences that describe the creation or founding of the Summerland Tour. "
            "Return the document names and relevant excerpts."
        )
        relevant_docs = await self.generate(instruction=relevant_docs_instruction, context=self.problem_text)

        # Step 2: Extract the name of the founder
        founder_extraction_instruction = (
            f"From the following text: {relevant_docs}, "
            "extract the name of the person who founded the Summerland Tour. "
            "Ensure the name is explicitly mentioned and relevant to the question."
        )
        founder_name = await self.generate(instruction=founder_extraction_instruction, context=self.problem_text)

        # Step 3: Locate the birth date of the founder
        birth_date_instruction = (
            f"Search all documents for the birth date of {founder_name}. "
            "Look for sentences that explicitly mention the birth date or year of the person. "
            "Return the exact date or year if available."
        )
        birth_date = await self.generate(instruction=birth_date_instruction, context=self.problem_text)

        # Step 4: Synthesize the final answer
        synthesis_instruction = (
            f"Combine the following information into a concise answer: "
            f"The founder of the Summerland Tour is {founder_name}, and their birth date is {birth_date}. "
            "Ensure the answer is clear, precise, and formatted correctly."
        )
        final_answer = await self.ensemble(
            instruction=synthesis_instruction,
            contexts=[founder_name, birth_date]
        )

        return final_answer