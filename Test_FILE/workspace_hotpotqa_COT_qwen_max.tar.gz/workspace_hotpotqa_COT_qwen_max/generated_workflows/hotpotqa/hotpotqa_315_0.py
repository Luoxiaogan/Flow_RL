# Workflow ID: hotpotqa_315_0
# Benchmark: hotpotqa
# Data Indices: [198]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify Relevant Documents
        documents = [
            "Arrowhead Pawn Shop", "Chumlee", "Corey Harrison", "Pawn Shop Chronicles",
            "Benjamin Harrison Home", "List of Pawn Stars episodes", "Pawnography",
            "Richard Benjamin Harrison", "Benjamin Harrison IV", "Rick Harrison"
        ]

        async def assess_relevance(doc):
            return await self.generate(
                instruction=f"Determine if the document '{doc}' is relevant to the question. "
                            f"Consider whether it contains information about entities or facts related to the query.",
                context=self.problem_text
            )

        relevance_results = await asyncio.gather(*[assess_relevance(doc) for doc in documents])

        relevant_docs = [doc for doc, result in zip(documents, relevance_results) if "relevant" in result.lower()]

        # Step 2: Extract Key Entities and Facts from Relevant Documents
        async def extract_entities(doc):
            return await self.generate(
                instruction=f"Extract key entities and facts from the document '{doc}' that are relevant to the question. "
                            f"Focus on entities mentioned in the question and any bridging entities that connect information across documents.",
                context=self.problem_text
            )

        entity_extraction_results = await asyncio.gather(*[extract_entities(doc) for doc in relevant_docs])

        # Step 3: Refine Extracted Information
        async def refine_entities(extracted_info):
            return await self.revise(
                instruction="Refine the extracted entities and facts to ensure accuracy and relevance to the question. "
                            "Remove any extraneous information and focus on key details.",
                context=extracted_info
            )

        refined_results = await asyncio.gather(*[refine_entities(info) for info in entity_extraction_results])

        # Step 4: Construct Reasoning Chain
        reasoning_chain = "\n".join(refined_results)

        reasoning_summary = await self.summarize(
            instruction="Summarize the reasoning chain connecting the extracted facts across documents. "
                        "Ensure the summary clearly outlines the logical steps leading to the answer.",
            context=reasoning_chain
        )

        # Step 5: Synthesize Final Answer
        async def generate_answer():
            return await self.generate(
                instruction="Based on the summarized reasoning chain, synthesize a concise answer to the question. "
                            "Ensure the answer is supported by the identified facts and reasoning steps.",
                context=reasoning_summary
            )

        answer_candidates = await asyncio.gather(*[generate_answer() for _ in range(2)])  # Generate multiple candidates

        final_answer = await self.ensemble(
            instruction="Select the best answer from the candidates provided. "
                        "Ensure the chosen answer is accurate, concise, and fully supported by the reasoning chain.",
            contexts=answer_candidates
        )

        return final_answer