# Workflow ID: hotpotqa_22_0
# Benchmark: hotpotqa
# Data Indices: [113]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract entities and locate relevant documents
        entity_extraction_instruction = """
        Identify all key entities mentioned in the question. Focus on proper nouns such as names, places, and groups. 
        Then, search through the provided documents to locate any mentions of these entities. Return the relevant excerpts 
        along with their source documents.
        """
        entities_and_contexts = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Resolve bridge entities and trace ancestry
        ancestry_instruction = f"""
        Based on the extracted entities and their mentions in the documents, determine the ancestry or origin of the person 
        in question. Specifically, focus on tracing the lineage of {entities_and_contexts}. If the person's ancestry is tied 
        to a specific group (e.g., Afro-Jamaicans), extract the relevant historical details about that group's arrival or 
        presence in the specified location.
        """
        ancestry_details = await self.generate(instruction=ancestry_instruction, context=self.problem_text)

        # Step 3: Refine and validate the extracted historical facts
        refinement_instruction = """
        Review the extracted historical facts and ensure they are accurate and relevant to the question. Remove any 
        extraneous information and clarify ambiguous statements. If necessary, cross-reference with other documents to 
        confirm the validity of the facts.
        """
        refined_facts = await self.revise(instruction=refinement_instruction, context=ancestry_details)

        # Step 4: Synthesize the final answer
        synthesis_instruction = """
        Combine the refined historical facts into a concise answer that directly addresses the question. Ensure the 
        response includes the specific year or time period requested and provides sufficient context to explain the 
        reasoning behind the answer.
        """
        final_answer = await self.summarize(instruction=synthesis_instruction, context=refined_facts)

        return final_answer