# Workflow ID: hotpotqa_384_0
# Benchmark: hotpotqa
# Data Indices: [277]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Parse the question to identify key entities and reasoning type
        question_analysis = await self.generate(
            instruction="Analyze the question to identify key entities, relationships, and the type of reasoning required (e.g., bridge, comparison). Provide a structured breakdown of the question.",
            context=self.problem_text
        )

        # Step 2: Filter relevant documents based on key entities
        relevant_docs = await self.generate(
            instruction=f"Given the following analysis of the question: {question_analysis}\n"
                        "Identify which documents are relevant to answering the question by checking for mentions of key entities or concepts.",
            context=self.problem_text
        )

        # Step 3: Detect bridge entities or relationships
        bridge_detection = await self.generate(
            instruction=f"Using the relevant documents identified here: {relevant_docs}\n"
                        "Find the 'bridge entity' or relationship that connects information across documents. "
                        "Explain how these entities or relationships link the documents.",
            context=self.problem_text
        )

        # Step 4: Extract supporting facts and construct reasoning chain
        fact_extraction = await self.generate(
            instruction=f"Based on the bridge detection: {bridge_detection}\n"
                        "Extract specific facts from the relevant documents that contribute to answering the question. "
                        "Construct a logical reasoning chain that connects these facts.",
            context=self.problem_text
        )

        # Step 5: Synthesize the final answer
        answer_synthesis = await self.summarize(
            instruction=f"Using the reasoning chain constructed here: {fact_extraction}\n"
                        "Synthesize a concise and precise answer to the question. Ensure the answer is supported by the extracted facts.",
            context=self.problem_text
        )

        # Optional Step 6: Refine the answer for accuracy and clarity
        refined_answer = await self.revise(
            instruction="Critique the provided answer for accuracy, completeness, and clarity. Suggest improvements if necessary.",
            context=answer_synthesis
        )

        return refined_answer