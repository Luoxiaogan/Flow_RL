# Workflow ID: hotpotqa_135_0
# Benchmark: hotpotqa
# Data Indices: [105]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Parse the question to extract key entities
        question_parsing_instruction = (
            "Carefully analyze the question and extract the key entities (e.g., names of organisms, concepts) "
            "and the specific information being requested (e.g., taxonomic category). Format the output as a JSON object "
            "with keys 'entities' (list of strings) and 'requested_info' (string)."
        )
        parsed_question = await self.generate(instruction=question_parsing_instruction, context=self.problem_text)
        
        # Dynamically construct instructions based on extracted entities
        import json
        parsed_data = json.loads(parsed_question)
        entities = parsed_data.get("entities", [])
        requested_info = parsed_data.get("requested_info", "")

        # Step 2: Identify relevant documents for each entity
        document_selection_tasks = []
        for entity in entities:
            document_selection_instruction = (
                f"Search through the provided context documents to find all mentions of the entity '{entity}'. "
                "Extract relevant sentences or paragraphs that provide information about the entity's "
                f"{requested_info}. If no relevant information is found, return an empty string."
            )
            document_selection_tasks.append(self.generate(instruction=document_selection_instruction, context=self.problem_text))
        
        # Execute document selection tasks in parallel
        relevant_documents = await asyncio.gather(*document_selection_tasks)

        # Step 3: Extract and summarize taxonomic information for each entity
        taxonomic_summarization_tasks = []
        for i, entity in enumerate(entities):
            summarization_instruction = (
                f"Based on the provided text, summarize the {requested_info} of the entity '{entity}'. "
                "Provide a concise statement that directly answers the question about the entity's classification."
            )
            taxonomic_summarization_tasks.append(self.summarize(instruction=summarization_instruction, context=relevant_documents[i]))
        
        # Execute summarization tasks in parallel
        taxonomic_summaries = await asyncio.gather(*taxonomic_summarization_tasks)

        # Step 4: Synthesize the final answer
        synthesis_instruction = (
            "Combine the provided summaries into a coherent answer that directly addresses the original question. "
            "Ensure the response is concise and clearly states the requested information for each entity."
        )
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=taxonomic_summaries)

        return final_answer