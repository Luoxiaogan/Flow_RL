# Workflow ID: hotpotqa_62_0
# Benchmark: hotpotqa
# Data Indices: [228]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify entities and select relevant documents
        entity_identification = await self.generate(
            instruction="Identify all named entities in the question and list them explicitly. "
                        "Then, scan the provided documents to find which ones mention these entities. "
                        "Return the list of entities and the relevant document indices.",
            context=self.problem_text
        )

        # Step 2: Resolve entities and find bridging relationships
        entity_resolution = await self.generate(
            instruction=f"Given the identified entities: {entity_identification}, "
                        "resolve any ambiguities and confirm their connections across documents. "
                        "Identify bridging entities or relationships that link the entities in the question. "
                        "For example, if 'Person A' is connected to 'Organization B' through a role, specify this relationship.",
            context=self.problem_text
        )

        # Step 3: Build reasoning chains in parallel
        reasoning_chain_1 = self.generate(
            instruction="Extract all relevant facts about the first entity from the relevant documents. "
                        "Focus on properties, roles, and historical events associated with the entity.",
            context=self.problem_text
        )
        reasoning_chain_2 = self.generate(
            instruction="Extract all relevant facts about the second entity from the relevant documents. "
                        "Focus on properties, roles, and historical events associated with the entity.",
            context=self.problem_text
        )
        reasoning_chains = await asyncio.gather(reasoning_chain_1, reasoning_chain_2)

        # Step 4: Synthesize reasoning chains into an answer
        synthesis = await self.ensemble(
            instruction="Combine the extracted facts from both reasoning chains into a coherent narrative. "
                        "Ensure the reasoning chain logically connects the entities in the question to the final answer. "
                        "If there are conflicting facts, resolve them based on document reliability or context.",
            contexts=reasoning_chains
        )

        # Step 5: Extract and validate the final answer
        final_answer = await self.generate(
            instruction="From the synthesized reasoning chain, extract the precise answer to the question. "
                        "Ensure the answer is concise and directly addresses the question. "
                        "Validate the answer by cross-referencing it with the original documents.",
            context=synthesis
        )

        return final_answer