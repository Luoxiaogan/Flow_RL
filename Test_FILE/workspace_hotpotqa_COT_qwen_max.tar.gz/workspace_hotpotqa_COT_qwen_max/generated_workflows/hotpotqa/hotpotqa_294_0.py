# Workflow ID: hotpotqa_294_0
# Benchmark: hotpotqa
# Data Indices: [63]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key entities and relationships
        entity_extraction_instruction = """
        Identify all key entities mentioned in the question and their relationships. 
        Focus on entities like names of people, organizations, events, and specific properties (e.g., "NBC," "Family Feud," "co-created").
        Organize the information in a structured format, such as a list or table.
        """
        extracted_entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Select relevant documents
        document_selection_instruction = f"""
        Based on the extracted entities: {extracted_entities}, determine which documents contain relevant information.
        Compare the documents and select the one(s) that best match the question's requirements.
        """
        document_contexts = [f"Document {i+1}: {doc}" for i, doc in enumerate(self.problem_text.split("Document")[1:])]
        relevant_document = await self.ensemble(instruction=document_selection_instruction, contexts=document_contexts)

        # Step 3: Construct reasoning chain
        reasoning_chain_instruction = f"""
        Using the selected document: {relevant_document} and the extracted entities: {extracted_entities},
        construct a reasoning chain that connects the entities to answer the question.
        Ensure the chain explicitly links all relevant information, such as co-creators, hosts, and networks.
        """
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 4: Refine the reasoning chain
        refinement_instruction = """
        Critique and refine the reasoning chain to ensure clarity, correctness, and completeness.
        Address any missing links or ambiguities in the chain.
        """
        refined_reasoning = await self.revise(instruction=refinement_instruction, context=reasoning_chain)

        # Step 5: Extract the final answer
        answer_extraction_instruction = """
        From the refined reasoning chain, extract the precise answer to the question.
        Ensure the answer is concise and directly addresses the question.
        """
        final_answer = await self.summarize(instruction=answer_extraction_instruction, context=refined_reasoning)

        return final_answer