# Workflow ID: hotpotqa_132_0
# Benchmark: hotpotqa
# Data Indices: [34]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key entities and relationships from the question
        entity_extraction = await self.generate(
            instruction="Identify all key entities mentioned in the question and their relationships. "
                        "Focus on entities like books, authors, organizations, or locations. "
                        "Provide the output as a list of entities and their potential connections.",
            context=self.problem_text
        )

        # Step 2: Summarize each document to assess relevance
        documents = self.problem_text.split("\n\n")  # Assuming documents are separated by double newlines
        summaries = await asyncio.gather(
            *[self.summarize(
                instruction="Summarize the key points of this document. Focus on entities, events, and relationships.",
                context=doc
            ) for doc in documents]
        )

        # Step 3: Identify relevant documents and bridge entities
        relevant_docs = await self.ensemble(
            instruction=f"Given the following summaries: {summaries}\n"
                        f"And the extracted entities: {entity_extraction}\n"
                        "Identify which documents are most relevant to answering the question. "
                        "Also, detect any 'bridge entities' that connect multiple documents.",
            contexts=summaries
        )

        # Step 4: Construct the reasoning chain
        reasoning_chain = await self.generate(
            instruction=f"Based on the relevant documents: {relevant_docs}\n"
                        "Construct a reasoning chain that connects the entities and answers the question. "
                        "Explicitly mention how the entities are related across documents.",
            context=self.problem_text
        )

        # Step 5: Extract the final answer
        final_answer = await self.generate(
            instruction=f"From the reasoning chain: {reasoning_chain}\n"
                        "Extract the precise answer to the question. Ensure the answer is concise and accurate.",
            context=self.problem_text
        )

        return final_answer