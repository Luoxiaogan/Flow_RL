# Workflow ID: hotpotqa_27_0
# Benchmark: hotpotqa
# Data Indices: [370]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Initial Extraction - Extract relevant entities and facts from documents
        extraction_instruction = """
        Extract all mentions of entities and facts from the documents that could be relevant to answering the question.
        Pay special attention to entities mentioned in the question and their relationships.
        Format the output as a list of key-value pairs where the key is the entity and the value is the associated fact.
        """
        initial_extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Entity Matching Across Documents - Resolve entities across documents
        ensemble_instruction = f"""
        Compare the extracted information to resolve entity references across different documents.
        Specifically, focus on matching entities mentioned in the question with those found in the documents.
        Output a consolidated view of each entity's attributes and relationships.
        """
        resolved_entities = await self.ensemble(instruction=ensemble_instruction, contexts=[initial_extraction])

        # Step 3: Reasoning Chain Construction - Build logical chains to derive the answer
        reasoning_instruction = f"""
        Using the resolved entities and their relationships, construct a reasoning chain to answer the question.
        Clearly articulate how one piece of information leads to another until the final answer is derived.
        Ensure the reasoning is traceable and explicitly mention which documents support each step.
        """
        reasoning_chain = await self.generate(instruction=reasoning_instruction, context=resolved_entities)

        # Step 4: Final Answer Extraction - Condense the reasoning into a concise answer
        summarization_instruction = """
        Summarize the reasoning chain into a concise answer that directly addresses the question.
        Ensure the answer is precise and includes only the necessary information.
        """
        final_answer = await self.summarize(instruction=summarization_instruction, context=reasoning_chain)

        return final_answer