# Workflow ID: hotpotqa_144_0
# Benchmark: hotpotqa
# Data Indices: [224]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Analyze the question and extract key entities
        entity_extraction = await self.generate(
            instruction="Analyze the question to identify key entities, relationships, and constraints. "
                        "Focus on extracting names, roles, dates, and other critical information that will guide the reasoning process. "
                        "Format the output as a JSON object with keys 'entities', 'roles', and 'constraints'.",
            context=self.problem_text
        )

        # Step 2: Evaluate document relevance
        documents = [
            "Joaquim Peris de Vargas...", "Emilio Sagi Liñán...", "José Bravo...", 
            "Josep Maria Fusté...", "Urby Emanuelson...", "Enrique Fernández Viola...", 
            "1998–99 FC Barcelona season...", "FC Barcelona Bàsquet...", "Boudewijn Zenden...", 
            "Ferenc Plattkó..."
        ]  # Replace with actual document texts
        
        relevance_tasks = [
            self.generate(
                instruction=f"Determine if the following document is relevant to the extracted entities and constraints: {entity_extraction}. "
                            "Provide a score from 0 to 1 indicating relevance, where 1 means highly relevant.",
                context=doc
            ) for doc in documents
        ]
        relevance_scores = await asyncio.gather(*relevance_tasks)

        # Filter relevant documents based on scores
        relevant_documents = [doc for doc, score in zip(documents, relevance_scores) if float(score) > 0.5]

        # Step 3: Resolve entities and link mentions across documents
        entity_resolution = await self.revise(
            instruction="Resolve entity mentions across the relevant documents. "
                        "Ensure that different mentions of the same entity are linked correctly. "
                        "For example, 'Boudewijn Zenden' and 'Bolo Zenden' should be recognized as the same person.",
            context="\n".join(relevant_documents)
        )

        # Step 4: Construct the reasoning chain
        reasoning_chain = await self.generate(
            instruction=f"Using the resolved entities: {entity_resolution}, construct a logical chain of facts to answer the question. "
                        "Combine information from multiple documents to build a coherent reasoning path. "
                        "Ensure that each step in the chain is supported by evidence from the text.",
            context="\n".join(relevant_documents)
        )

        # Step 5: Extract the final answer
        final_answer = await self.summarize(
            instruction="Extract the precise answer span from the reasoning chain. "
                        "Ensure the response is concise and directly addresses the question.",
            context=reasoning_chain
        )

        return final_answer