# Workflow ID: hotpotqa_231_0
# Benchmark: hotpotqa
# Data Indices: [256]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify key entities and analyze the question
        question_analysis_instruction = (
            "Analyze the question and identify all key entities and the type of information being requested. "
            "For example, determine if the question is asking for a date, a name, a comparison, or other specific details. "
            "Output the identified entities and the inferred question type in a structured format."
        )
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 2: Select relevant documents based on entity mentions
        document_selection_instruction = (
            f"Based on the following question analysis: {question_analysis}, "
            "identify which documents from the provided context contain information about the mentioned entities. "
            "List the relevant documents along with brief explanations of why they are relevant."
        )
        document_selection = await self.generate(instruction=document_selection_instruction, context=self.problem_text)

        # Step 3: Extract relevant information from the selected documents
        information_extraction_instruction = (
            f"From the following document selection: {document_selection}, "
            "extract specific sentences or facts that are pertinent to answering the question. "
            "Focus on finding bridge entities, comparative properties, or multi-hop facts as needed. "
            "Condense the extracted information into concise summaries."
        )
        extracted_information = await self.summarize(instruction=information_extraction_instruction, context=self.problem_text)

        # Step 4: Construct the reasoning chain by synthesizing information
        reasoning_chain_instruction = (
            f"Using the following extracted information: {extracted_information}, "
            "construct a reasoning chain that connects the dots between the documents. "
            "Explain how the information from different documents relates to each other and leads to the answer. "
            "Ensure the reasoning chain is logical and complete."
        )
        reasoning_chain = await self.ensemble(instruction=reasoning_chain_instruction, contexts=[question_analysis, document_selection, extracted_information])

        # Step 5: Generate the final answer based on the reasoning chain
        answer_generation_instruction = (
            f"Based on the following reasoning chain: {reasoning_chain}, "
            "generate the final answer to the question. "
            "Ensure the answer is precise and matches the question type (e.g., short text span, yes/no, factual statement)."
        )
        final_answer = await self.generate(instruction=answer_generation_instruction, context=self.problem_text)

        return final_answer