# Workflow ID: hotpotqa_398_0
# Benchmark: hotpotqa
# Data Indices: [117]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Analyze the question to determine its type
        question_analysis = await self.generate(
            instruction="Analyze the question to determine its type (e.g., bridge, comparison, compositional). "
                        "Provide a brief explanation of the reasoning behind your classification.",
            context=self.problem_text
        )

        # Step 2: Extract key entities and relationships
        entity_extraction = await self.generate(
            instruction=f"Based on the question analysis: {question_analysis}, "
                        "extract all key entities and their relationships mentioned in the problem text. "
                        "Focus on entities that are likely to connect across multiple documents.",
            context=self.problem_text
        )

        # Step 3: Summarize each document and select the most relevant ones
        document_summaries = await asyncio.gather(
            *[self.summarize(
                instruction="Summarize this document while focusing on entities and facts relevant to the question.",
                context=doc
            ) for doc in self.config["context_documents"]]
        )
        relevant_documents = await self.ensemble(
            instruction=f"Given the extracted entities and relationships: {entity_extraction}, "
                        "select the most relevant document summaries that contain information necessary to answer the question.",
            contexts=document_summaries
        )

        # Step 4: Construct the reasoning chain
        reasoning_chain = await self.generate(
            instruction=f"Using the selected documents: {relevant_documents}, "
                        "build a reasoning chain that connects the entities and relationships to answer the question. "
                        "Ensure the chain explicitly shows how the information flows from one document to another.",
            context=self.problem_text
        )

        # Step 5: Generate the final answer
        final_answer = await self.generate(
            instruction=f"Based on the reasoning chain: {reasoning_chain}, "
                        "generate a concise and accurate answer to the question. "
                        "Ensure the answer is supported by specific evidence from the documents.",
            context=self.problem_text
        )

        # Step 6: Validate and refine the answer
        refined_answer = await self.revise(
            instruction="Critique and refine the final answer to ensure it is accurate, well-supported, and concise. "
                        "Check for any logical inconsistencies or missing information.",
            context=final_answer
        )

        return refined_answer