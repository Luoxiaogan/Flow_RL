# Workflow ID: hotpotqa_75_0
# Benchmark: hotpotqa
# Data Indices: [218]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract entities from the question
        question_instruction = (
            "Identify all named entities (e.g., films, people, organizations) mentioned in the question. "
            "Focus specifically on entities that are likely to be discussed in the provided context documents. "
            "Return the entities as a comma-separated list."
        )
        entities = await self.generate(instruction=question_instruction, context=self.problem_text)
        entity_list = [entity.strip() for entity in entities.split(",")]

        # Step 2: Parallel extraction of relevant information for each entity
        async def process_entity(entity):
            extract_instruction = (
                f"Find all information about the film '{entity}' in the provided context documents. "
                "Focus specifically on whether the film is described as animated. "
                "Return the relevant sentences or paragraphs verbatim."
            )
            return await self.generate(instruction=extract_instruction, context=self.problem_text)

        results = await asyncio.gather(*(process_entity(entity) for entity in entity_list))

        # Step 3: Analyze and synthesize the extracted information
        synthesis_instruction = (
            "Given the following information about multiple films, determine whether each film is animated. "
            "Provide a concise answer for each film in the format: 'Film Name: Yes/No'. "
            "If the information is ambiguous, state 'Ambiguous' for that film."
        )
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=results)

        return final_answer