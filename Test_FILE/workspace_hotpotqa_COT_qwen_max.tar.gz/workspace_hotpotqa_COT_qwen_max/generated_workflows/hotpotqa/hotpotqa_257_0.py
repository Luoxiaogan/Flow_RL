# Workflow ID: hotpotqa_257_0
# Benchmark: hotpotqa
# Data Indices: [388]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Identify relevant documents
        relevance_instruction = """
        Analyze the provided context documents and determine which ones contain information relevant to answering the question. 
        Focus on identifying mentions of the entities or facts mentioned in the question. 
        Provide a concise list of relevant document indices or titles.
        """
        relevant_docs = await self.generate(instruction=relevance_instruction, context=self.problem_text)

        # Step 2: Extract entity-specific information
        extraction_instruction = f"""
        Based on the identified relevant documents ({relevant_docs}), extract detailed information about the entities mentioned in the question.
        Specifically, focus on determining whether each entity satisfies the criteria in the question (e.g., being a professional wrestler and actor).
        Organize the extracted information clearly for comparison.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 3: Construct reasoning chain and synthesize answer
        reasoning_instruction = f"""
        Using the extracted information ({extracted_info}), construct a reasoning chain to determine which entity satisfies the question's criteria.
        Compare the properties of the entities and provide a clear justification for the final answer.
        """
        candidate_answers = await asyncio.gather(
            self.generate(instruction=f"Based on {extracted_info}, analyze Seth Rollins."),
            self.generate(instruction=f"Based on {extracted_info}, analyze Dennis Agajanian.")
        )
        final_answer = await self.ensemble(
            instruction="Compare the two analyses and select the entity that best satisfies the question's criteria.",
            contexts=candidate_answers
        )

        # Step 4: Refine the final answer
        refinement_instruction = """
        Ensure the final answer is concise, accurate, and formatted appropriately (e.g., short text span or yes/no). 
        Remove any redundant information and focus on delivering a polished response.
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        return refined_answer