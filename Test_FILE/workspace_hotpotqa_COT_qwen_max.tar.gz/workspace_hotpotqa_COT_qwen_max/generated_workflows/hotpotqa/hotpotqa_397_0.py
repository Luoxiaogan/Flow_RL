# Workflow ID: hotpotqa_397_0
# Benchmark: hotpotqa
# Data Indices: [172]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify key entities and extract relevant context
        entity_extraction = await self.generate(
            instruction="Identify all key entities mentioned in the question and locate their mentions in the context documents. "
                        "Focus on entities that are likely to be central to answering the question. "
                        "For each entity, extract the sentences or paragraphs from the documents that describe it.",
            context=self.problem_text
        )

        # Step 2: Build the reasoning chain
        reasoning_chain = await self.generate(
            instruction=f"Using the extracted information: {entity_extraction}, construct a logical reasoning chain that connects the entities to the question. "
                        "Explain how the entities relate to each other and how they lead to the answer. "
                        "If the question involves multiple hops, explicitly outline each step in the chain.",
            context=self.problem_text
        )

        # Step 3: Generate candidate answers
        candidates = await asyncio.gather(
            self.generate(
                instruction=f"Based on the reasoning chain: {reasoning_chain}, generate a concise answer to the question. "
                            "Ensure the answer is specific and supported by the context documents.",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"Provide an alternative interpretation or answer to the question based on: {reasoning_chain}. "
                            "Consider any ambiguities or alternative connections between entities.",
                context=self.problem_text
            )
        )

        # Step 4: Select the best answer using Ensemble
        final_answer = await self.ensemble(
            instruction="Evaluate the candidate answers and select the most accurate one. "
                        "Consider the reasoning chain and supporting facts from the context documents. "
                        "If there are discrepancies, resolve them by favoring the answer with stronger evidence.",
            contexts=candidates
        )

        # Step 5: Extract supporting facts
        supporting_facts = await self.summarize(
            instruction=f"Identify the key sentences or paragraphs from the context documents that support the final answer: {final_answer}. "
                        "Ensure the supporting facts are concise but comprehensive enough to justify the answer.",
            context=self.problem_text
        )

        # Step 6: Refine the final output (optional)
        refined_output = await self.revise(
            instruction=f"Review the final answer: {final_answer} and its supporting facts: {supporting_facts}. "
                        "Ensure the answer is clear, accurate, and fully supported by the facts. "
                        "Make any necessary refinements to improve clarity or correctness.",
            context=self.problem_text
        )

        return refined_output