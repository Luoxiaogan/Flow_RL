# Workflow ID: hotpotqa_148_0
# Benchmark: hotpotqa
# Data Indices: [41]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Identify entities and extract relevant contexts
        entity_extraction_instruction = (
            "Identify all entities mentioned in the question and extract relevant sentences "
            "from the provided documents that mention these entities. Ensure the extracted "
            "sentences are directly related to the question."
        )
        extracted_contexts = await self.generate(
            instruction=entity_extraction_instruction,
            context=self.problem_text
        )

        # Step 2: Classify the reasoning type
        reasoning_type_instruction = (
            "Determine the reasoning type required to answer the question. "
            "Classify the question as one of the following: "
            "1. Bridge reasoning (connecting entities across documents), "
            "2. Comparison reasoning (comparing properties of entities), "
            "3. Compositional reasoning (combining multiple facts). "
            "Provide a clear explanation for the classification."
        )
        reasoning_type = await self.generate(
            instruction=reasoning_type_instruction,
            context=extracted_contexts
        )

        # Step 3: Build reasoning chains based on the reasoning type
        reasoning_chain_instruction = (
            f"Based on the identified reasoning type ({reasoning_type}), build a reasoning chain. "
            "For bridge reasoning, find the bridge entity that connects documents. "
            "For comparison reasoning, extract relevant properties of the entities being compared. "
            "For compositional reasoning, synthesize multiple facts into a coherent chain. "
            "Ensure the reasoning chain is logically consistent and supported by the extracted contexts."
        )
        reasoning_chain = await self.generate(
            instruction=reasoning_chain_instruction,
            context=extracted_contexts
        )

        # Step 4: Extract and refine the final answer
        answer_extraction_instruction = (
            "Extract the final answer span from the reasoning chain. Ensure the answer is concise, "
            "supported by the extracted contexts, and directly addresses the question."
        )
        raw_answer = await self.generate(
            instruction=answer_extraction_instruction,
            context=reasoning_chain
        )

        refinement_instruction = (
            "Refine the extracted answer to ensure clarity, correctness, and conciseness. "
            "Validate that the answer is fully supported by the reasoning chain and extracted contexts."
        )
        refined_answer = await self.revise(
            instruction=refinement_instruction,
            context=raw_answer
        )

        # Step 5: Summarize supporting facts and validate the answer
        summary_instruction = (
            "Summarize the supporting facts from the extracted contexts that validate the refined answer. "
            "Ensure the summary is concise and highlights the key evidence."
        )
        supporting_facts = await self.summarize(
            instruction=summary_instruction,
            context=extracted_contexts
        )

        # Step 6: Ensemble to select the best answer (if multiple candidates exist)
        ensemble_instruction = (
            "Evaluate the refined answer against the supporting facts. If multiple candidate answers "
            "exist, select the one that is most logically consistent and supported by the evidence."
        )
        final_answer = await self.ensemble(
            instruction=ensemble_instruction,
            contexts=[refined_answer, supporting_facts]
        )

        return final_answer