# Workflow ID: hotpotqa_67_0
# Benchmark: hotpotqa
# Data Indices: [284]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract entities and analyze the question
        question_analysis = await self.generate(
            instruction="Analyze the question to identify key entities and what is being asked. "
                        "Specifically, extract the names of individuals or films mentioned and determine "
                        "the relationship between them. For example, identify if the question asks about "
                        "a shared film, a director, or other connections. Provide a structured summary.",
            context=self.problem_text
        )

        # Step 2: Identify relevant documents for each entity
        entity_documents = await self.generate(
            instruction=f"Using the entities identified in the previous step ({question_analysis}), "
                        "search through the provided documents to find which ones mention these entities. "
                        "For each entity, list the relevant documents and highlight the sentences that "
                        "contain pertinent information. Ensure all potential connections are covered.",
            context=self.problem_text
        )

        # Step 3: Find the bridge entity (connecting film)
        bridge_entity = await self.generate(
            instruction=f"Based on the documents identified ({entity_documents}), find the 'bridge entity' "
                        "that connects the two entities mentioned in the question. For example, if the "
                        "question involves two people, identify the film or event they are both associated with. "
                        "Provide reasoning for why this entity is the correct connection.",
            context=self.problem_text
        )

        # Step 4: Extract director information
        director_info = await self.generate(
            instruction=f"Using the bridge entity identified ({bridge_entity}), locate the document that "
                        "provides information about its director. Extract the director's name and any "
                        "relevant details about their role in the film. Ensure the information is precise "
                        "and directly answers the question.",
            context=self.problem_text
        )

        # Step 5: Refine and synthesize the final answer
        refined_answer = await self.revise(
            instruction="Refine the extracted director information to ensure clarity and accuracy. "
                        "Remove any unnecessary details and format the answer to directly address the question. "
                        "Ensure the response is concise and includes only the director's name and any "
                        "essential context.",
            context=director_info
        )

        return refined_answer