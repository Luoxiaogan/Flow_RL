# Workflow ID: hotpotqa_299_0
# Benchmark: hotpotqa
# Data Indices: [85]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Parse the question and identify key entities
        entity_extraction_instruction = """
        Analyze the question and identify all key entities (e.g., names, organizations, locations).
        Determine the type of reasoning required (bridge, comparison, compositional).
        Output the entities and reasoning type in a structured format.
        """
        entities_and_reasoning = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Select relevant documents based on identified entities
        document_selection_instruction = f"""
        Given the following entities and reasoning type: {entities_and_reasoning}
        Evaluate each document and determine which ones are most likely to contain relevant information.
        Prioritize documents that mention the identified entities or are related to the reasoning type.
        Output a list of selected document indices.
        """
        relevant_documents = await self.ensemble(instruction=document_selection_instruction, contexts=[doc for doc in self.problem_text.split("\n\n") if doc.strip()])

        # Step 3: Extract supporting facts and build reasoning chains
        extraction_tasks = []
        for doc in relevant_documents.split(","):
            extraction_instruction = f"""
            From the document provided, extract sentences or facts that are relevant to the question.
            Focus on information related to the entities: {entities_and_reasoning}.
            Build explicit reasoning chains if possible.
            """
            extraction_tasks.append(self.generate(instruction=extraction_instruction, context=doc.strip()))
        extracted_facts = await asyncio.gather(*extraction_tasks)

        # Step 4: Synthesize the final answer
        synthesis_instruction = f"""
        Given the following extracted facts: {extracted_facts}
        Synthesize the final answer to the question.
        Ensure the answer is concise and directly addresses the question.
        If there are ambiguities, resolve them based on the extracted facts.
        """
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=extracted_facts)

        return final_answer