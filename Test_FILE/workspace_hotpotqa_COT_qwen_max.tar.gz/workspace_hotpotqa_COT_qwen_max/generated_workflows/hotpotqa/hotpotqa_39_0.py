# Workflow ID: hotpotqa_39_0
# Benchmark: hotpotqa
# Data Indices: [10]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Parse the question to identify key entities and relationships
        question_analysis = await self.generate(
            instruction="Analyze the question to identify key entities, relationships, and the type of answer required. "
                        "Focus on extracting nouns (e.g., locations, people) and verbs (e.g., 'is named after'). "
                        "Provide a structured summary of the findings.",
            context=self.problem_text
        )

        # Step 2: Identify relevant documents based on the question analysis
        document_selection = await self.generate(
            instruction=f"Based on the following question analysis: {question_analysis}, "
                        "identify which documents are most relevant to answering the question. "
                        "Focus on documents that mention the key entities and relationships. "
                        "Provide a list of document names and their relevance scores.",
            context=self.problem_text
        )

        # Step 3: Extract potential bridge entities from the relevant documents
        bridge_entity_extraction = await self.generate(
            instruction=f"From the following document selection: {document_selection}, "
                        "identify potential bridge entities that connect the key entities in the question. "
                        "A bridge entity is something that appears in multiple documents and links the question's entities. "
                        "Provide a list of bridge entities and their supporting evidence.",
            context=self.problem_text
        )

        # Step 4: Ensemble to select the most relevant bridge entity
        bridge_entity_decision = await self.ensemble(
            instruction="Evaluate the following bridge entity candidates and select the most relevant one. "
                        "Consider how well each candidate connects the key entities in the question. "
                        "Provide the selected bridge entity and justification.",
            contexts=[bridge_entity_extraction]
        )

        # Step 5: Chain facts to derive the final answer
        fact_chaining = await self.generate(
            instruction=f"Using the selected bridge entity: {bridge_entity_decision}, "
                        "chain the facts from the relevant documents to derive the final answer. "
                        "Ensure the reasoning is clear and supported by specific sentences from the documents. "
                        "Provide the final answer and supporting facts.",
            context=self.problem_text
        )

        # Step 6: Summarize the final answer
        final_answer = await self.summarize(
            instruction="Condense the following fact-chained reasoning into a concise final answer. "
                        "Ensure the answer directly addresses the question and includes any necessary supporting details.",
            context=fact_chaining
        )

        return final_answer