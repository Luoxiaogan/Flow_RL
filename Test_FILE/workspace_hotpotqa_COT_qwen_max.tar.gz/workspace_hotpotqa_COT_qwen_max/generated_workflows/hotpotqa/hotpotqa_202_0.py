# Workflow ID: hotpotqa_202_0
# Benchmark: hotpotqa
# Data Indices: [79]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract information about Nam Woo-hyun
        nam_info_extraction = await self.generate(
            instruction="""
            Extract all relevant information about Nam Woo-hyun from the provided documents. 
            Focus on his profession, roles, and any significant activities or attributes mentioned. 
            Ensure that you capture complete sentences or phrases that describe his occupation or primary activities. 
            If there are multiple mentions across different documents, consolidate them into a coherent summary.
            """,
            context=self.problem_text
        )

        # Step 2: Extract information about Roy Wood
        roy_info_extraction = await self.generate(
            instruction="""
            Extract all relevant information about Roy Wood from the provided documents. 
            Focus on his profession, roles, and any significant activities or attributes mentioned. 
            Ensure that you capture complete sentences or phrases that describe his occupation or primary activities. 
            If there are multiple mentions across different documents, consolidate them into a coherent summary.
            """,
            context=self.problem_text
        )

        # Step 3: Refine the extracted information for both entities
        refined_nam_info = await self.revise(
            instruction=f"""
            Review and refine the following extracted information about Nam Woo-hyun:
            {nam_info_extraction}
            Ensure that the information is accurate, complete, and relevant to the question of his occupation.
            """,
            context=nam_info_extraction
        )

        refined_roy_info = await self.revise(
            instruction=f"""
            Review and refine the following extracted information about Roy Wood:
            {roy_info_extraction}
            Ensure that the information is accurate, complete, and relevant to the question of his occupation.
            """,
            context=roy_info_extraction
        )

        # Step 4: Compare the refined information to find mutual occupations
        mutual_occupation = await self.ensemble(
            instruction="""
            Compare the refined information about Nam Woo-hyun and Roy Wood to identify any mutual occupations or roles.
            Specifically, look for professions or activities that are explicitly mentioned for both individuals.
            Provide a clear and concise reasoning chain that explains how you arrived at your conclusion.
            """,
            contexts=[refined_nam_info, refined_roy_info]
        )

        # Step 5: Summarize the final answer
        final_answer = await self.summarize(
            instruction="""
            Summarize the findings from the comparison step into a concise answer.
            Ensure that the answer directly addresses the question of mutual occupation between Nam Woo-hyun and Roy Wood.
            Include any supporting facts or reasoning that led to this conclusion.
            """,
            context=mutual_occupation
        )

        return final_answer