# Workflow ID: hotpotqa_18_0
# Benchmark: hotpotqa
# Data Indices: [6]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Identify documents mentioning "Gidget" and "The Flying Nun"
        instruction_step1 = (
            "Identify all documents that mention the shows 'Gidget' and 'The Flying Nun'. "
            "Focus on extracting names of actresses associated with these shows. "
            "Provide the document titles and the relevant excerpts."
        )
        relevant_docs = await self.generate(instruction=instruction_step1, context=self.problem_text)

        # Step 2: Resolve the actress entity across documents
        instruction_step2 = (
            f"Given the following documents:\n{relevant_docs}\n"
            "Determine the common actress mentioned across the documents related to 'Gidget' and 'The Flying Nun'. "
            "Resolve any ambiguities and provide the full name of the actress."
        )
        actress_candidates = await asyncio.gather(
            self.generate(instruction=instruction_step2, context=self.problem_text),
            self.generate(instruction=instruction_step2, context=self.problem_text)  # Parallel execution for robustness
        )
        actress_entity = await self.ensemble(
            instruction="Compare the candidate actresses and select the most consistent one across documents.",
            contexts=actress_candidates
        )

        # Step 3: Find the movie and director from 1988
        instruction_step3 = (
            f"Given the actress {actress_entity}, find the movie she starred in during 1988. "
            "Extract the name of the movie and its director from the provided documents."
        )
        movie_director_info = await self.generate(instruction=instruction_step3, context=self.problem_text)

        # Step 4: Validate and finalize the answer
        instruction_step4 = (
            f"Review the following information: {movie_director_info}. "
            "Ensure the answer is accurate, complete, and formatted as a short factual response. "
            "If necessary, revise the output to improve clarity or correctness."
        )
        final_answer = await self.revise(instruction=instruction_step4, context=movie_director_info)

        return final_answer