# Workflow ID: hotpotqa_69_0
# Benchmark: hotpotqa
# Data Indices: [159]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Identify key entities and select relevant documents
        entity_extraction_instruction = """
        Analyze the question and extract all key entities (e.g., names, titles, dates). 
        Match these entities against the provided context documents to identify which documents are relevant.
        Return a list of document indices or names that contain information about the extracted entities.
        """
        relevant_documents = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Extract relevant facts from the selected documents
        fact_extraction_instruction = f"""
        From the following relevant documents: {relevant_documents}, 
        extract specific sentences or facts that directly contribute to answering the question. 
        Focus on numerical values, relationships between entities, and explicit statements.
        """
        extracted_facts = await asyncio.gather(
            *[self.generate(instruction=fact_extraction_instruction, context=doc) for doc in relevant_documents.split(",")]
        )

        # Step 3: Build a reasoning chain
        reasoning_instruction = f"""
        Using the extracted facts: {extracted_facts}, 
        construct a logical reasoning chain that connects the entities mentioned in the question. 
        Ensure the chain explicitly explains how the facts lead to the answer.
        """
        reasoning_chain = await self.revise(instruction=reasoning_instruction, context=" ".join(extracted_facts))

        # Step 4: Synthesize the final answer
        synthesis_instruction = f"""
        Based on the reasoning chain: {reasoning_chain}, 
        synthesize a concise and precise answer to the question. 
        Ensure the answer directly addresses the question and includes any necessary supporting details.
        """
        final_answer = await self.summarize(instruction=synthesis_instruction, context=reasoning_chain)

        return final_answer