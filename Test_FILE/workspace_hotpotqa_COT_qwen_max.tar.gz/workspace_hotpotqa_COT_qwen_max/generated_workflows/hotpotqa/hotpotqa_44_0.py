# Workflow ID: hotpotqa_44_0
# Benchmark: hotpotqa
# Data Indices: [225]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract mentions of entities and their contexts
        entities = ["Pioneer Canal", "Orleans Canal"]
        entity_extraction_tasks = []
        for entity in entities:
            instruction = f"Extract all sentences mentioning '{entity}' from the provided documents. Ensure the sentences include contextual information about the entity's location or country."
            task = self.generate(instruction=instruction, context=self.problem_text)
            entity_extraction_tasks.append(task)

        # Execute entity extraction in parallel
        entity_contexts = await asyncio.gather(*entity_extraction_tasks)

        # Step 2: Classify reasoning type
        reasoning_instruction = """Analyze the question and classify its reasoning type. 
        - Bridge questions require connecting information through shared entities.
        - Comparison questions involve comparing properties of entities.
        - Compositional questions combine multiple facts to derive the answer.
        Based on the extracted contexts, determine the reasoning type for the question."""
        reasoning_type = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Extract relevant facts for each entity
        fact_extraction_tasks = []
        for i, entity_context in enumerate(entity_contexts):
            instruction = f"From the extracted context for '{entities[i]}', identify relevant facts such as its location or country. Focus on information that could be compared with other entities."
            task = self.generate(instruction=instruction, context=entity_context)
            fact_extraction_tasks.append(task)

        # Execute fact extraction in parallel
        entity_facts = await asyncio.gather(*fact_extraction_tasks)

        # Step 4: Compare facts and identify shared property
        ensemble_instruction = """Compare the facts extracted for the two entities and determine the shared property (e.g., country). 
        Provide a clear and concise answer based on the comparison."""
        shared_property = await self.ensemble(instruction=ensemble_instruction, contexts=entity_facts)

        # Step 5: Refine the final answer
        refinement_instruction = "Ensure the answer is precise, well-supported, and formatted appropriately. Remove any unnecessary details."
        final_answer = await self.revise(instruction=refinement_instruction, context=shared_property)

        return final_answer