# Workflow ID: hotpotqa_232_0
# Benchmark: hotpotqa
# Data Indices: [345]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Filter relevant documents
        filter_instruction = f"""
        Identify all sentences or paragraphs from the provided context documents that are relevant to the question: "{self.problem_text}".
        Focus on mentions of Suriname and languages. Include only those parts of the documents that explicitly discuss these topics.
        """
        filtered_contexts = await self.generate(instruction=filter_instruction, context=self.problem_text)

        # Step 2: Identify shared entities or bridge entities
        entity_instruction = f"""
        From the following filtered content: "{filtered_contexts}", identify shared entities or concepts that connect multiple documents.
        Specifically, look for mentions of Suriname and languages spoken there. Highlight these entities clearly.
        """
        shared_entities = await self.generate(instruction=entity_instruction, context=filtered_contexts)

        # Step 3: Construct reasoning chains
        reasoning_instruction = f"""
        Using the shared entities: "{shared_entities}", construct a reasoning chain to answer the question: "{self.problem_text}".
        Synthesize information from different documents to explain how the entities are related and lead to the answer.
        """
        reasoning_chain = await self.generate(instruction=reasoning_instruction, context=shared_entities)

        # Step 4: Extract the final answer
        answer_instruction = f"""
        From the reasoning chain: "{reasoning_chain}", extract the precise answer to the question: "{self.problem_text}".
        Ensure the answer is a short text span, such as an entity name or a brief factual response.
        """
        raw_answer = await self.generate(instruction=answer_instruction, context=reasoning_chain)

        # Step 5: Revise and validate the answer
        revise_instruction = f"""
        Critique and refine the following answer: "{raw_answer}".
        Ensure it accurately reflects the information in the reasoning chain and directly answers the question: "{self.problem_text}".
        """
        final_answer = await self.revise(instruction=revise_instruction, context=raw_answer)

        return final_answer