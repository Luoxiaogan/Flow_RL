# Workflow ID: hotpotqa_245_0
# Benchmark: hotpotqa
# Data Indices: [175]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Question Analysis
        question_analysis_instruction = (
            "Analyze the given question to determine what type of information is being requested. "
            "Identify key entities, relationships, and any specific constraints mentioned in the question. "
            "Provide a structured breakdown of the question components."
        )
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 2: Document Selection
        document_selection_instruction = (
            f"Based on the question analysis: {question_analysis}, identify which documents contain relevant information. "
            "Look for mentions of key entities and concepts related to the question. "
            "List the documents that are most likely to contain the necessary information."
        )
        document_selection = await self.generate(instruction=document_selection_instruction, context=self.problem_text)

        # Step 3: Entity Resolution
        entity_resolution_instruction = (
            f"Given the selected documents: {document_selection}, resolve entities mentioned in the question across these documents. "
            "Match entities with similar names or descriptions to ensure consistency. "
            "Provide a mapping of entities across different documents."
        )
        entity_resolution = await self.generate(instruction=entity_resolution_instruction, context=self.problem_text)

        # Step 4: Fact Extraction
        fact_extraction_instruction = (
            f"Using the resolved entities: {entity_resolution}, extract specific facts from the selected documents. "
            "Focus on numerical data, dates, or descriptive information that directly relates to the question. "
            "Organize the extracted facts by document and entity."
        )
        fact_extraction = await self.generate(instruction=fact_extraction_instruction, context=self.problem_text)

        # Step 5: Reasoning Chain Construction
        reasoning_chain_instruction = (
            f"Construct a logical reasoning chain using the extracted facts: {fact_extraction}. "
            "Connect the facts across documents to form a coherent narrative that leads to the answer. "
            "Ensure that each step in the chain is justified by the information provided in the documents."
        )
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 6: Answer Synthesis
        answer_synthesis_instruction = (
            f"Synthesize the final answer based on the reasoning chain: {reasoning_chain}. "
            "Condense the information into a concise response that directly addresses the question. "
            "Ensure the answer is supported by the facts extracted from the documents."
        )
        answer = await self.generate(instruction=answer_synthesis_instruction, context=self.problem_text)

        return answer