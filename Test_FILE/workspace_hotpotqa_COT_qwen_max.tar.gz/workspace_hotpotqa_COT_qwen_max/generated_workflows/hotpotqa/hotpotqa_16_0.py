# Workflow ID: hotpotqa_16_0
# Benchmark: hotpotqa
# Data Indices: [53]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract height information for both mountains
        extraction_instruction = """
        Identify and extract all numerical height values (in meters) mentioned in the context documents 
        for the following entities: Apsarasas Kangri and Gangkhar Puensum. Ensure that the extracted values 
        are explicitly associated with their respective entities. Format the output as follows:
        - Apsarasas Kangri: [height in meters]
        - Gangkhar Puensum: [height in meters]
        If no height is found for an entity, state "Height not found."
        """
        height_extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Compare the extracted heights
        comparison_instruction = f"""
        Using the extracted height information below, determine whether Apsarasas Kangri is taller than Gangkhar Puensum.
        Heights:
        {height_extraction}
        Perform the comparison step by step:
        1. Parse the numerical values for both mountains.
        2. Compare the two values.
        3. Conclude whether Apsarasas Kangri is taller than Gangkhar Puensum.
        Provide the conclusion in the format: "Yes" if Apsarasas Kangri is taller, otherwise "No".
        """
        comparison_result = await self.generate(instruction=comparison_instruction, context=self.problem_text)

        # Step 3: Handle potential discrepancies using Ensemble
        refinement_instruction = """
        Evaluate the following comparison result and ensure its correctness. If there are any ambiguities 
        or missing information, resolve them based on the context documents. Provide the final conclusion 
        in the format: "Yes" or "No".
        """
        final_answer = await self.ensemble(instruction=refinement_instruction, contexts=[comparison_result, height_extraction])

        # Step 4: Refine the final answer for clarity and correctness
        refinement_instruction_final = """
        Refine the following answer to ensure it is concise, accurate, and properly formatted. 
        The answer should be either "Yes" or "No".
        """
        polished_answer = await self.revise(instruction=refinement_instruction_final, context=final_answer)

        return polished_answer