# Workflow ID: hotpotqa_172_0
# Benchmark: hotpotqa
# Data Indices: [266]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Analyze the question and extract key entities
        question_analysis = await self.generate(
            instruction="Analyze the question and extract key entities and their relationships. "
                        "Identify the type of question (bridge, comparison, compositional). "
                        "Provide a structured breakdown of the entities and what is being asked.",
            context=self.problem_text
        )

        # Step 2: Select relevant documents based on entities
        document_selection = await self.generate(
            instruction=f"Based on the following analysis: {question_analysis}, "
                        "identify which documents are relevant to the entities and relationships. "
                        "List the document names and briefly explain why they are relevant.",
            context=self.problem_text
        )

        # Step 3: Detect bridge entities and build reasoning chains
        bridge_detection = await self.generate(
            instruction=f"Using the selected documents: {document_selection}, "
                        "identify any bridge entities that connect multiple documents. "
                        "Explain how these entities relate to the question and provide reasoning chains.",
            context=self.problem_text
        )

        # Step 4: Extract specific facts contributing to the answer
        fact_extraction = await self.generate(
            instruction=f"From the reasoning chains: {bridge_detection}, "
                        "extract specific facts from the documents that directly contribute to answering the question. "
                        "Ensure the facts are precise and relevant.",
            context=self.problem_text
        )

        # Step 5: Synthesize the answer using Ensemble
        candidate_answers = await asyncio.gather(
            self.generate(
                instruction=f"Based on the extracted facts: {fact_extraction}, "
                            "synthesize a concise answer to the question.",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"Double-check the reasoning and facts: {fact_extraction}, "
                            "and provide an alternative synthesis if necessary.",
                context=self.problem_text
            )
        )
        final_answer = await self.ensemble(
            instruction="Compare the candidate answers and select the most accurate and concise one. "
                        "If there are discrepancies, resolve them by revisiting the facts and reasoning.",
            contexts=candidate_answers
        )

        return final_answer