# Workflow ID: hotpotqa_392_0
# Benchmark: hotpotqa
# Data Indices: [83]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Parse the question to identify key entities and relationships
        question_analysis = await self.generate(
            instruction="Analyze the question to identify key entities and relationships. "
                        "Focus on understanding what the question is asking and what types of entities are involved. "
                        "For example, identify names, dates, or specific concepts mentioned in the question. "
                        "Output the analysis in a structured format.",
            context=self.problem_text
        )

        # Step 2: Extract relevant information from the documents
        relevant_info_extraction = await self.generate(
            instruction=f"Based on the following question analysis: {question_analysis}, "
                        "search the provided documents for mentions of the identified entities and relationships. "
                        "Extract all relevant sentences or paragraphs that could help answer the question. "
                        "Ensure the output includes document references for traceability.",
            context=self.problem_text
        )

        # Step 3: Build the reasoning chain
        reasoning_chain = await self.generate(
            instruction=f"Using the extracted information: {relevant_info_extraction}, "
                        "construct a reasoning chain that connects the entities across documents. "
                        "For example, if the question involves a parody of a character, first identify the original character, "
                        "then find any mentions of parodies. Output the reasoning chain step by step.",
            context=self.problem_text
        )

        # Step 4: Extract the precise answer
        answer_extraction = await self.generate(
            instruction=f"Based on the reasoning chain: {reasoning_chain}, "
                        "extract the precise answer span from the text. Ensure the answer directly addresses the question. "
                        "If the answer is ambiguous, provide multiple candidates.",
            context=self.problem_text
        )

        # Step 5: Refine the answer
        refined_answer = await self.revise(
            instruction="Refine the extracted answer to ensure it is concise, accurate, and directly addresses the question. "
                        "If there are multiple candidates, select the most reliable one.",
            context=answer_extraction
        )

        # Step 6: Validate the final answer
        final_answer = await self.ensemble(
            instruction="Evaluate the refined answer against the reasoning chain and extracted information. "
                        "Ensure the answer is consistent with the evidence and reasoning steps. "
                        "If multiple answers were provided, select the best one.",
            contexts=[refined_answer, reasoning_chain, relevant_info_extraction]
        )

        return final_answer