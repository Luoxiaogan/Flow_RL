# Workflow ID: hotpotqa_246_0
# Benchmark: hotpotqa
# Data Indices: [361]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract key entities and their descriptions
        entity_extraction_instruction = """
        Extract all entities mentioned in the context documents along with their descriptions. 
        Focus on geographical locations, organizations, and notable features. Provide the output 
        in a structured format: Entity Name - Description.
        """
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Identify relationships between the entities of interest
        relationship_extraction_instruction = f"""
        Given the extracted entities: {entities}
        Identify relationships or shared attributes between the entities mentioned in the question. 
        Focus on geographical proximity, classifications, or other relevant connections. 
        Provide the output as a list of relationships.
        """
        relationships = await self.generate(instruction=relationship_extraction_instruction, context=self.problem_text)

        # Step 3: Construct a reasoning chain
        reasoning_chain_instruction = f"""
        Using the extracted entities: {entities} and their relationships: {relationships}
        Build a reasoning chain that connects the entities mentioned in the question. 
        Explain how the relationships support the answer to the question. 
        Ensure the reasoning is clear and logical.
        """
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 4: Refine the reasoning chain
        refinement_instruction = """
        Review the reasoning chain and ensure it is clear, concise, and logically sound. 
        Correct any ambiguities or errors in the reasoning.
        """
        refined_reasoning = await self.revise(instruction=refinement_instruction, context=reasoning_chain)

        # Step 5: Generate the final answer
        answer_synthesis_instruction = f"""
        Based on the refined reasoning chain: {refined_reasoning}
        Generate a concise answer that directly addresses the question. 
        Ensure the answer is supported by the reasoning chain and includes specific details from the context documents.
        """
        final_answer = await self.generate(instruction=answer_synthesis_instruction, context=self.problem_text)

        return final_answer