# Workflow ID: hotpotqa_293_0
# Benchmark: hotpotqa
# Data Indices: [349]

class Workflow:
    def __init__(self, config, problem) -> None:
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio
        
        # Step 1: Extract entities from the question
        entity_extraction_instruction = """
        Extract all named entities (e.g., people, movies, companies) mentioned in the question. 
        Provide them as a list of strings, ensuring each entity is distinct and relevant to the query.
        """
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)
        
        # Step 2: Filter relevant documents based on extracted entities
        doc_filter_instruction = f"""
        Identify which documents mention any of the following entities: {entities}.
        Provide a list of document indices or titles that are relevant to answering the question.
        """
        relevant_docs = await self.generate(instruction=doc_filter_instruction, context=self.problem_text)
        
        # Step 3: Identify the bridge entity connecting the documents
        bridge_entity_instruction = f"""
        Analyze the relevant documents ({relevant_docs}) to identify the bridge entity that connects 
        the extracted entities ({entities}). The bridge entity is the shared reference point across documents.
        """
        bridge_entity = await self.generate(instruction=bridge_entity_instruction, context=self.problem_text)
        
        # Step 4: Construct the reasoning chain
        reasoning_chain_instruction = f"""
        Using the bridge entity ({bridge_entity}), construct a reasoning chain that connects the extracted 
        entities ({entities}) across the relevant documents ({relevant_docs}). Ensure the chain explicitly 
        explains how the entities relate to each other.
        """
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)
        
        # Step 5: Extract the precise answer span
        answer_extraction_instruction = f"""
        Based on the reasoning chain ({reasoning_chain}), extract the precise answer span that directly 
        answers the question. The answer should be concise and match the expected format (e.g., entity name).
        """
        answer = await self.generate(instruction=answer_extraction_instruction, context=self.problem_text)
        
        # Step 6: Refine the answer for clarity and correctness
        refinement_instruction = f"""
        Review the extracted answer ({answer}) for clarity, correctness, and conciseness. Make any necessary 
        refinements to ensure it accurately addresses the question.
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=answer)
        
        return refined_answer