# Workflow ID: hotpotqa_59_0
# Benchmark: hotpotqa
# Data Indices: [340]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key entities from the question
        entity_extraction_instruction = (
            "Carefully analyze the provided question and extract all key entities, such as names, dates, and specific terms. "
            "Identify what type of information is being requested (e.g., a person, place, date, or event). "
            "Format your output as a JSON object with keys 'entities' (list of extracted entities) and 'query_type' (type of information requested)."
        )
        entity_info = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Dynamically construct instructions for subsequent steps
        try:
            import json
            parsed_entity_info = json.loads(entity_info)
            entities = parsed_entity_info.get("entities", [])
            query_type = parsed_entity_info.get("query_type", "")
        except Exception:
            entities = []
            query_type = ""

        # Step 2: Select relevant documents
        document_selection_instruction = (
            f"Given the following entities: {', '.join(entities)}, determine which documents are most relevant "
            f"to answering the question. Prioritize documents that explicitly mention these entities and provide "
            f"information related to the query type ({query_type}). Return a ranked list of document indices."
        )
        document_scores = await asyncio.gather(
            *[self.generate(instruction=document_selection_instruction, context=doc) for doc in self.problem_text.split("\n\n")]
        )
        best_documents = sorted(enumerate(document_scores), key=lambda x: x[1], reverse=True)[:3]  # Top 3 documents

        # Step 3: Build reasoning chain
        reasoning_chain_instruction = (
            f"Using the top documents containing the entities {', '.join(entities)}, construct a reasoning chain "
            f"that connects these entities to answer the question. Explicitly explain how the information flows "
            f"from one document to another, and highlight any bridging entities or facts. Format your output as "
            f"a step-by-step explanation."
        )
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context="\n".join(best_documents))

        # Step 4: Extract the final answer
        answer_extraction_instruction = (
            f"Based on the reasoning chain provided, extract the precise answer to the original question. "
            f"The answer should be concise and directly address the query type ({query_type}). If the answer "
            f"is a named entity, ensure it matches the format used in the documents."
        )
        final_answer = await self.summarize(instruction=answer_extraction_instruction, context=reasoning_chain)

        return final_answer