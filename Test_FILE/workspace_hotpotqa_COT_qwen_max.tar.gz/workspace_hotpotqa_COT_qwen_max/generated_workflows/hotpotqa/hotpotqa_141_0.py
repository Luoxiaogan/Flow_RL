# Workflow ID: hotpotqa_141_0
# Benchmark: hotpotqa
# Data Indices: [229]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract entities and analyze the question
        question_analysis = await self.generate(
            instruction="Analyze the question to determine the type of reasoning required (comparison, bridge, compositional). "
                        "Extract all key entities mentioned in the question. "
                        "Identify which documents are likely to contain relevant information.",
            context=self.problem_text
        )

        # Step 2: Select relevant documents
        document_selection = await self.generate(
            instruction=f"Based on the extracted entities and question analysis: {question_analysis}, "
                        "identify the documents that contain information about these entities. "
                        "Return the names or identifiers of these documents.",
            context=self.problem_text
        )

        # Step 3: Extract and process relevant information
        # Parallel extraction of information from selected documents
        info_extraction_tasks = []
        for doc in document_selection.split(","):  # Assuming document names are comma-separated
            task = self.generate(
                instruction=f"Extract all relevant information about the entities mentioned in the question from the document: {doc}. "
                            "Focus on numerical data, spatial data (e.g., coordinates), or relationships between entities.",
                context=self.problem_text
            )
            info_extraction_tasks.append(task)

        extracted_info = await asyncio.gather(*info_extraction_tasks)

        # Step 4: Construct reasoning chain and derive the answer
        reasoning_chain = await self.generate(
            instruction=f"Using the extracted information: {extracted_info}, "
                        "construct a reasoning chain to answer the question. "
                        "For comparison questions, compare numerical or spatial data. "
                        "For bridge questions, identify the bridge entity and connect information across documents. "
                        "For compositional questions, synthesize facts to derive the answer.",
            context=self.problem_text
        )

        # Step 5: Validate and finalize the answer
        answer_validation = await self.ensemble(
            instruction="Evaluate the reasoning chain and validate the derived answer. "
                        "Ensure the answer is supported by specific facts from the documents. "
                        "If there are discrepancies, resolve them by revisiting the reasoning chain.",
            contexts=extracted_info + [reasoning_chain]
        )

        # Step 6: Summarize supporting facts
        supporting_facts = await self.summarize(
            instruction="Summarize the key supporting facts from the documents that justify the answer. "
                        "Include only the most relevant sentences.",
            context=self.problem_text
        )

        # Final output
        return {
            "answer": answer_validation,
            "supporting_facts": supporting_facts
        }