# Workflow ID: hotpotqa_133_0
# Benchmark: hotpotqa
# Data Indices: [32]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract relevant information about the entities in the question
        instruction_extract_entities = """
        Identify the key entities mentioned in the question and extract relevant sentences or paragraphs 
        from the provided documents that describe these entities. Focus on details such as their nationality, 
        profession, and any other distinguishing characteristics. Ensure the extracted information is concise 
        and directly related to the entities mentioned in the question.
        """
        context_extract_entities = self.problem_text
        extracted_info = await self.generate(instruction=instruction_extract_entities, context=context_extract_entities)

        # Step 2: Match entities across documents and build reasoning chains
        instruction_match_entities = """
        Analyze the extracted information to determine how the entities are described across different documents. 
        Specifically, check if each entity is described as a French critic and of Polish descent. Build a reasoning 
        chain that connects the descriptions of the entities from different documents. Highlight any contradictions 
        or ambiguities in the descriptions.
        """
        matched_entities = await self.generate(instruction=instruction_match_entities, context=extracted_info)

        # Step 3: Compare and synthesize information using Ensemble
        instruction_synthesize = """
        Evaluate the reasoning chains for each entity and determine which entity satisfies the conditions 
        specified in the question (i.e., being a French critic and of Polish descent). Provide a clear justification 
        for your choice based on the evidence from the documents. If there are conflicting descriptions, resolve 
        them by prioritizing the most reliable or consistent information.
        """
        contexts_to_synthesize = [extracted_info, matched_entities]
        synthesized_answer = await self.ensemble(instruction=instruction_synthesize, contexts=contexts_to_synthesize)

        # Step 4: Refine the final answer
        instruction_refine = """
        Ensure the final answer is precise and well-supported by the reasoning chain. Extract the exact answer 
        span (e.g., the name of the entity) and confirm that it satisfies the constraints of the question. 
        Remove any redundant or unnecessary information.
        """
        final_answer = await self.revise(instruction=instruction_refine, context=synthesized_answer)

        return final_answer