# Workflow ID: hotpotqa_117_0
# Benchmark: hotpotqa
# Data Indices: [237]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key entities and relationships
        entity_extraction_instruction = """
        Identify all key entities (e.g., people, organizations, teams, years) and their relationships in the question and context documents.
        Provide the output as a structured list of entities and their connections.
        """
        entities_and_relationships = await self.generate(
            instruction=entity_extraction_instruction,
            context=self.problem_text
        )

        # Step 2: Select relevant documents and track entities
        document_selection_instruction = f"""
        Based on the extracted entities and relationships ({entities_and_relationships}), determine which documents are relevant to answering the question.
        Track mentions of these entities across the documents to resolve any ambiguities.
        Provide a summary of the relevant documents and entity mentions.
        """
        relevant_documents = await self.generate(
            instruction=document_selection_instruction,
            context=self.problem_text
        )

        # Step 3: Construct reasoning chain
        reasoning_chain_instruction = f"""
        Using the relevant documents and entity tracking information ({relevant_documents}), construct a reasoning chain that connects the entities mentioned in the question.
        Ensure the chain explicitly explains how the entities are related and how they lead to the answer.
        """
        reasoning_chain = await self.generate(
            instruction=reasoning_chain_instruction,
            context=self.problem_text
        )

        # Step 4: Synthesize the answer
        synthesis_instruction = f"""
        Combine the reasoning chain ({reasoning_chain}) with the relevant documents to synthesize the final answer.
        Ensure the answer is concise, directly addresses the question, and includes supporting facts.
        """
        candidate_answers = await asyncio.gather(
            self.generate(instruction=synthesis_instruction, context=self.problem_text),
            self.generate(instruction=synthesis_instruction, context=self.problem_text)  # Optional redundancy for robustness
        )
        final_answer = await self.ensemble(
            instruction="Select the most accurate and well-supported answer from the candidates.",
            contexts=candidate_answers
        )

        # Step 5: Refine the final answer
        refinement_instruction = """
        Critique and refine the provided answer to ensure it is accurate, well-supported, and formatted correctly.
        """
        refined_answer = await self.revise(
            instruction=refinement_instruction,
            context=final_answer
        )

        return refined_answer