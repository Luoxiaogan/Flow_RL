# Workflow ID: hotpotqa_393_0
# Benchmark: hotpotqa
# Data Indices: [219]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Identify key entities and select relevant documents
        entity_identification = await self.generate(
            instruction="Identify the key entities mentioned in the question and determine which documents contain information about these entities.",
            context=self.problem_text
        )

        # Step 2: Extract relevant information for each entity
        extraction_tasks = []
        for entity in ["Brief Interviews with Hideous Men", "John Krasinski"]:
            extraction_task = self.generate(
                instruction=f"Extract all relevant information about {entity} from the provided documents. Focus on attributes such as origin, nationality, or creation details.",
                context=entity_identification
            )
            extraction_tasks.append(extraction_task)
        
        extracted_info = await asyncio.gather(*extraction_tasks)

        # Step 3: Compare and synthesize information
        synthesis_instruction = (
            "Compare the extracted information about the two entities to identify common attributes. "
            "Specifically, focus on finding shared attributes like country of origin. "
            "If there are multiple possibilities, evaluate them critically."
        )
        synthesis = await self.ensemble(
            instruction=synthesis_instruction,
            contexts=extracted_info
        )

        # Step 4: Extract the final answer
        final_answer = await self.generate(
            instruction="Based on the synthesized information, extract the final answer as a concise text span.",
            context=synthesis
        )

        return final_answer