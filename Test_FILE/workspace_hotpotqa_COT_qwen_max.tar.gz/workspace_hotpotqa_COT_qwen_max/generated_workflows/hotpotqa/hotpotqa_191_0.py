# Workflow ID: hotpotqa_191_0
# Benchmark: hotpotqa
# Data Indices: [192]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Parse the question to identify key entities and relationships
        question_analysis = await self.generate(
            instruction="Analyze the question to identify the main subject, relationship, and any constraints. "
                        "Provide a structured breakdown of the query components.",
            context=self.problem_text
        )

        # Step 2: Summarize each document to identify relevance
        summaries = await asyncio.gather(
            *[self.summarize(
                instruction="Summarize the document to highlight key entities, locations, and relationships. "
                            "Focus on information that could connect to the question.",
                context=doc
            ) for doc in self.config['context_documents']]
        )

        # Step 3: Identify the most relevant documents
        relevant_docs = await self.ensemble(
            instruction="Evaluate the summaries to determine which documents are most relevant to the question. "
                        "Focus on documents that mention the main subject or related entities.",
            contexts=summaries
        )

        # Step 4: Extract bridge entities and chain facts
        bridge_entity = await self.generate(
            instruction=f"Using the relevant documents, identify the bridge entity that connects the main subject "
                        f"to the answer. Provide explicit reasoning for the connection. Question analysis: {question_analysis}",
            context=relevant_docs
        )

        fact_chain = await self.generate(
            instruction=f"Chain the facts together using the bridge entity. Start with the main subject, connect "
                        f"it to the bridge entity, and then derive the final answer. Bridge entity: {bridge_entity}",
            context=relevant_docs
        )

        # Step 5: Extract the final answer
        final_answer = await self.generate(
            instruction="Extract the precise answer span from the fact chain. Ensure the response is concise "
                        "and directly addresses the question.",
            context=fact_chain
        )

        return final_answer