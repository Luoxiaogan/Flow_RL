# Workflow ID: hotpotqa_267_0
# Benchmark: hotpotqa
# Data Indices: [312]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Document Selection
        document_selection_instruction = """
        Analyze the provided context documents and identify which ones mention Ray Liotta 
        or any of the stars of "10 Things I Hate About You." Provide a list of relevant 
        document indices along with brief explanations for each selection.
        """
        relevant_documents = await self.generate(
            instruction=document_selection_instruction,
            context=self.problem_text
        )

        # Step 2: Entity Extraction
        entity_extraction_instruction = f"""
        From the following relevant documents: {relevant_documents}, extract all key entities 
        such as actor names, film titles, and other related information. Organize the entities 
        by document and highlight any potential connections between Ray Liotta and the stars 
        of "10 Things I Hate About You."
        """
        extracted_entities = await self.generate(
            instruction=entity_extraction_instruction,
            context=self.problem_text
        )

        # Step 3: Bridge Entity Identification
        bridge_entity_instruction = f"""
        Based on the extracted entities: {extracted_entities}, identify the "bridge entity" 
        that connects Ray Liotta to one of the stars of "10 Things I Hate About You." 
        This could be a shared film, a co-star, or another contextual link. Provide a detailed 
        explanation of how this connection is established.
        """
        bridge_entity = await self.generate(
            instruction=bridge_entity_instruction,
            context=self.problem_text
        )

        # Step 4: Reasoning Chain Construction
        reasoning_chain_instruction = f"""
        Using the identified bridge entity: {bridge_entity}, construct a reasoning chain 
        that connects Ray Liotta to one of the stars of "10 Things I Hate About You." 
        Synthesize information from multiple documents to explain how this connection leads 
        to the answer. Ensure the reasoning is clear and logical.
        """
        reasoning_chain = await self.ensemble(
            instruction=reasoning_chain_instruction,
            contexts=[relevant_documents, extracted_entities, bridge_entity]
        )

        # Step 5: Answer Extraction
        answer_extraction_instruction = f"""
        Based on the reasoning chain: {reasoning_chain}, extract the precise answer to the 
        question in the form of a short text span. Ensure the answer directly addresses the 
        question and is supported by the provided context.
        """
        final_answer = await self.summarize(
            instruction=answer_extraction_instruction,
            context=reasoning_chain
        )

        return final_answer