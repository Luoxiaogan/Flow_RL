# Workflow ID: hotpotqa_205_0
# Benchmark: hotpotqa
# Data Indices: [24]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Analyze the question and identify key entities
        question_analysis = await self.generate(
            instruction="Analyze the question and identify all key entities, query terms, and relationships. "
                        "Focus on identifying entities like 'natural harbors,' 'Hudson River,' and 'federally owned.' "
                        "Provide a structured list of these terms to guide subsequent steps.",
            context=self.problem_text
        )

        # Step 2: Select relevant documents
        document_selection = await self.generate(
            instruction=f"Based on the identified entities and query terms ({question_analysis}), "
                        "determine which documents are most relevant to answering the question. "
                        "Provide a list of document indices or names along with brief justifications.",
            context=self.problem_text
        )

        # Step 3: Extract facts and build reasoning chains
        # Extract facts from each relevant document in parallel
        relevant_documents = [doc.strip() for doc in document_selection.split("\n") if doc.strip()]
        fact_extraction_tasks = [
            self.generate(
                instruction=f"Extract all relevant facts from the following document: {doc}. "
                            "Focus on entities and relationships mentioned in the question analysis. "
                            "Provide the extracted facts in a structured format.",
                context=self.problem_text
            )
            for doc in relevant_documents
        ]
        extracted_facts = await asyncio.gather(*fact_extraction_tasks)

        # Step 4: Combine facts into a coherent answer
        combined_answer = await self.ensemble(
            instruction="Combine the extracted facts into a coherent answer. "
                        "Ensure the reasoning chain connects shared entities across documents. "
                        "The final answer should directly address the question.",
            contexts=extracted_facts
        )

        # Step 5: Refine and validate the answer
        refined_answer = await self.revise(
            instruction="Critique and refine the provided answer for accuracy and completeness. "
                        "Ensure it aligns with the question's requirements and includes all necessary details.",
            context=combined_answer
        )

        return refined_answer