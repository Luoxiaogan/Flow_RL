# Workflow ID: hotpotqa_107_0
# Benchmark: hotpotqa
# Data Indices: [65]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Parse the question and identify key entities
        entity_extraction_instruction = """
        Analyze the question and identify all key entities, relationships, and the type of information being asked for.
        Entities could include people, places, events, or numerical values. Relationships describe how these entities are connected.
        Output the results in a structured format: {"entities": [...], "relationships": [...], "question_type": "..."}.
        """
        entities_and_relationships = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Select relevant documents based on entities
        document_selection_instruction = f"""
        Using the extracted entities and relationships: {entities_and_relationships}, scan through all provided documents.
        Identify which documents contain information related to these entities and relationships.
        Output the list of relevant document indices or names.
        """
        relevant_documents = await self.generate(instruction=document_selection_instruction, context=self.problem_text)

        # Step 3: Extract relevant information from selected documents
        extraction_tasks = []
        for doc in relevant_documents.split(","):  # Assuming comma-separated document names/indices
            extraction_instruction = f"""
            Extract sentences or facts from the document '{doc.strip()}' that are relevant to the entities and relationships identified earlier: {entities_and_relationships}.
            Focus on information that helps answer the question.
            """
            extraction_tasks.append(self.summarize(instruction=extraction_instruction, context=self.problem_text))
        
        extracted_facts = await asyncio.gather(*extraction_tasks)

        # Step 4: Construct the reasoning chain
        reasoning_chain_instruction = f"""
        Based on the following extracted facts: {extracted_facts}, construct a logical reasoning chain that connects the information across documents.
        Ensure the chain explicitly explains how the facts lead to the answer.
        Output the reasoning chain as a step-by-step explanation.
        """
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 5: Synthesize the final answer
        answer_synthesis_instruction = f"""
        Using the reasoning chain: {reasoning_chain}, synthesize the final answer to the question.
        Ensure the answer is concise, precise, and directly addresses the question.
        """
        final_answer = await self.generate(instruction=answer_synthesis_instruction, context=self.problem_text)

        # Optional refinement step
        refined_answer = await self.revise(
            instruction="Refine the answer to ensure clarity, correctness, and completeness.",
            context=final_answer
        )

        return refined_answer