# Workflow ID: hotpotqa_247_0
# Benchmark: hotpotqa
# Data Indices: [274]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Analyze the question and identify key entities/reasoning type
        question_analysis = await self.generate(
            instruction="Analyze the question to identify key entities and the type of reasoning required. "
                        "Key entities include names, events, or properties mentioned in the question. "
                        "Reasoning types include bridge entity connection, property comparison, or fact chaining. "
                        "Format your response as a JSON object with keys 'entities' and 'reasoning_type'.",
            context=self.problem_text
        )

        # Parse the analysis result
        import json
        analysis_result = json.loads(question_analysis)
        entities = analysis_result.get("entities", [])
        reasoning_type = analysis_result.get("reasoning_type", "")

        # Step 2: Identify relevant documents and extract supporting facts
        document_tasks = []
        for i, doc in enumerate(self.config["context_documents"], start=1):
            task = self.generate(
                instruction=f"Given the question and the following document (Document {i}): "
                            f"Determine if this document contains information relevant to the question. "
                            f"If relevant, extract supporting facts about the entities: {', '.join(entities)}. "
                            f"Format your response as a JSON object with keys 'is_relevant' (boolean) and 'facts' (list).",
                context=doc
            )
            document_tasks.append(task)

        document_results = await asyncio.gather(*document_tasks)
        relevant_facts = []
        for result in document_results:
            doc_result = json.loads(result)
            if doc_result.get("is_relevant", False):
                relevant_facts.extend(doc_result.get("facts", []))

        # Step 3: Resolve entities and build reasoning chains
        reasoning_chain = await self.ensemble(
            instruction=f"Given the following extracted facts: {relevant_facts} "
                        f"and the reasoning type: {reasoning_type}, "
                        f"resolve entities across documents and build a reasoning chain to answer the question. "
                        f"Ensure the chain connects all relevant entities logically and leads to the final answer.",
            contexts=relevant_facts
        )

        # Step 4: Extract and summarize the final answer
        final_answer = await self.summarize(
            instruction="Based on the reasoning chain provided, extract the precise answer to the question. "
                        "The answer should be a short text span, such as an entity name, phrase, yes/no, or brief factual response.",
            context=reasoning_chain
        )

        return final_answer