# Workflow ID: hotpotqa_5_0
# Benchmark: hotpotqa
# Data Indices: [351]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio
        
        # Step 1: Analyze the question to determine its type and extract key entities
        question_analysis = await self.generate(
            instruction="Analyze the question to determine its type (e.g., bridge, comparison, compositional). "
                        "Extract all key entities, concepts, or numerical values mentioned in the question. "
                        "Provide a detailed breakdown of what the question is asking.",
            context=self.problem_text
        )

        # Step 2: Identify relevant documents and summarize their content
        # Assume `self.problem_text` includes both the question and the context documents
        summaries = await asyncio.gather(
            *[self.summarize(
                instruction=f"Summarize this document focusing on the entities and concepts mentioned in the question: {question_analysis}. "
                            "Include only information that could be relevant to answering the question.",
                context=doc
            ) for doc in self.problem_text.split("Document ")[1:]]  # Split documents by "Document" header
        )
        
        # Step 3: Perform cross-document reasoning to build inference chains
        reasoning_chain = await self.generate(
            instruction=f"Using the summaries provided, perform multi-hop reasoning to connect information across documents. "
                        f"Identify any 'bridge entities' or key facts that link documents. "
                        f"Derive a logical chain of reasoning leading to the answer. Entities: {question_analysis}.",
            context="\n".join(summaries)
        )

        # Step 4: Extract and validate the final answer
        candidate_answers = await asyncio.gather(
            self.generate(
                instruction=f"Based on the reasoning chain: {reasoning_chain}, extract the final answer as a precise text span. "
                            "Ensure the answer directly addresses the question.",
                context=self.problem_text
            ),
            self.revise(
                instruction=f"Review the reasoning chain: {reasoning_chain}. "
                            "Refine the answer to ensure it is accurate and concise.",
                context=self.problem_text
            )
        )

        # Step 5: Select the best answer using Ensemble
        final_answer = await self.ensemble(
            instruction="Evaluate the candidate answers and reasoning refinements. "
                        "Select the most accurate and well-supported answer.",
            contexts=candidate_answers
        )

        return final_answer