# Workflow ID: hotpotqa_339_0
# Benchmark: hotpotqa
# Data Indices: [27]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract candidate albums released in 2017
        extract_albums_instruction = (
            "Identify all albums mentioned in the provided documents that were released in 2017. "
            "Focus on explicit mentions of release years and ensure accuracy. "
            "Provide the album names as a comma-separated list."
        )
        albums_result = await self.generate(instruction=extract_albums_instruction, context=self.problem_text)

        # Step 2: Verify if these albums have dedicated tours
        verify_tours_instruction = (
            f"Given the following albums released in 2017: {albums_result}, "
            "check if each album has a dedicated tour mentioned in the documents. "
            "Provide the names of albums with confirmed tours as a comma-separated list."
        )
        tours_result = await self.generate(instruction=verify_tours_instruction, context=self.problem_text)

        # Step 3: Ensemble to select the correct answer
        ensemble_instruction = (
            f"From the following albums with confirmed tours: {tours_result}, "
            "select the one that best answers the question: 'What album not only released in 2017 but also had a tour dedicated to it?' "
            "Provide the final answer as a single album name."
        )
        final_answer = await self.ensemble(
            instruction=ensemble_instruction,
            contexts=[albums_result, tours_result]
        )

        # Step 4: Refine the final answer
        refine_instruction = (
            "Refine the following answer into a concise and grammatically correct format: "
            f"{final_answer}. Ensure the response is clear and directly addresses the question."
        )
        refined_answer = await self.revise(instruction=refine_instruction, context=final_answer)

        return refined_answer