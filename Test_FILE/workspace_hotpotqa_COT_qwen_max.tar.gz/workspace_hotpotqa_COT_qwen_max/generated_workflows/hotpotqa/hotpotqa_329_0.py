# Workflow ID: hotpotqa_329_0
# Benchmark: hotpotqa
# Data Indices: [396]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Entity Identification
        entity_extraction_instruction = (
            "Identify all entities mentioned in the question and classify their types. "
            "For example, distinguish between albums, artists, locations, and other relevant categories. "
            "Output the entities and their types in a structured format."
        )
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Document Selection
        document_selection_instruction = (
            f"Given the following entities and their types: {entities}, "
            "determine which documents contain relevant information about these entities. "
            "Rank the documents by relevance and output the top candidates."
        )
        document_contexts = [f"Document {i+1}" for i in range(10)]  # Example: 10 documents
        relevant_documents = await self.ensemble(instruction=document_selection_instruction, contexts=document_contexts)

        # Step 3: Reasoning Chain Construction
        reasoning_chain_instruction = (
            f"Using the relevant documents: {relevant_documents}, "
            "construct a reasoning chain that connects the entities mentioned in the question. "
            "For example, if the question asks about an artist's birthplace, find the document that mentions the artist "
            "and then locate the birthplace information. Output the reasoning chain as a sequence of logical steps."
        )
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 4: Answer Extraction
        answer_extraction_instruction = (
            f"Based on the reasoning chain: {reasoning_chain}, "
            "extract the final answer span that directly addresses the question. "
            "Ensure the answer is concise and formatted appropriately."
        )
        answer = await self.summarize(instruction=answer_extraction_instruction, context=self.problem_text)

        # Step 5: Validation and Refinement
        refinement_instruction = (
            f"Critique and refine the following answer: {answer}. "
            "Ensure it is accurate, complete, and directly addresses the question. "
            "If necessary, revise the answer to improve clarity or correctness."
        )
        final_answer = await self.revise(instruction=refinement_instruction, context=answer)

        return final_answer