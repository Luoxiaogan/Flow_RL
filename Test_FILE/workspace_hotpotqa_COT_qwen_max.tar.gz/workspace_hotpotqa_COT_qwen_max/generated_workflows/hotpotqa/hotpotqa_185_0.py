# Workflow ID: hotpotqa_185_0
# Benchmark: hotpotqa
# Data Indices: [394]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Identify key entities and extract relevant contexts
        entity_extraction_instruction = (
            "Identify all key entities mentioned in the question and extract sentences from the context documents "
            "that contain these entities. Focus on sentences that provide factual information or describe relationships."
        )
        entity_contexts = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Locate bridge entities and intermediate facts
        bridge_entity_instruction = (
            f"Using the extracted contexts: {entity_contexts}, identify any bridge entities or intermediate facts "
            "that connect the primary entity to the potential answer. Look for shared entities, relationships, or events."
        )
        bridge_entities = await self.generate(instruction=bridge_entity_instruction, context=self.problem_text)

        # Step 3: Extract supporting facts and candidate answers
        supporting_facts_instruction = (
            f"Based on the bridge entities: {bridge_entities}, extract supporting facts from the context documents. "
            "Focus on facts that directly answer the question or lead to the answer."
        )
        supporting_facts = await self.generate(instruction=supporting_facts_instruction, context=self.problem_text)

        # Step 4: Refine and summarize the extracted information
        refinement_instruction = (
            "Refine the extracted supporting facts to ensure accuracy and relevance. Remove any redundant or irrelevant information."
        )
        refined_facts = await self.revise(instruction=refinement_instruction, context=supporting_facts)

        summarization_instruction = (
            "Condense the refined facts into a concise summary that retains all key information necessary to answer the question."
        )
        summarized_answer = await self.summarize(instruction=summarization_instruction, context=refined_facts)

        # Step 5: Ensemble decision for the final answer
        ensemble_instruction = (
            "Compare the summarized answer with the original question and context documents. "
            "Ensure the answer is precise, factual, and directly addresses the question."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[summarized_answer, self.problem_text])

        return final_answer