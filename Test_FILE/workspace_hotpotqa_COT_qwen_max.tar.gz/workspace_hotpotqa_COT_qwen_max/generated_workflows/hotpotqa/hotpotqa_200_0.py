# Workflow ID: hotpotqa_200_0
# Benchmark: hotpotqa
# Data Indices: [227]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract information about John Farleigh and his associations
        farleigh_info = await self.generate(
            instruction="""Extract all sentences or paragraphs that mention John Farleigh and his associations with English novelists. 
            Focus on identifying the name(s) of the novelist(s) whose works he illustrated.""",
            context=self.problem_text
        )

        # Step 2: Identify the novelist(s) and extract their birth year
        novelist_extraction = await self.generate(
            instruction=f"""Based on the following information about John Farleigh: {farleigh_info}, 
            identify the name(s) of the novelist(s) he illustrated for. Then, search the context documents 
            to find the birth year of the identified novelist(s). Provide the name and birth year.""",
            context=self.problem_text
        )

        # Step 3: Summarize the reasoning chain
        reasoning_summary = await self.summarize(
            instruction="""Summarize the reasoning chain used to determine the birth year of the novelist. 
            Include the key entities (e.g., John Farleigh, the novelist) and how they were connected.""",
            context=novelist_extraction
        )

        # Step 4: Handle potential ambiguity with Ensemble (if multiple candidates exist)
        # Split the extracted information into individual candidates
        candidates = novelist_extraction.split("\n")
        if len(candidates) > 1:
            final_answer = await self.ensemble(
                instruction="""Compare the following candidate answers and select the most accurate one. 
                Ensure the selected answer provides the correct birth year of the novelist illustrated by John Farleigh.""",
                contexts=candidates
            )
        else:
            final_answer = novelist_extraction

        # Step 5: Refine the final answer for clarity and correctness
        refined_answer = await self.revise(
            instruction="""Refine the final answer to ensure it is clear, concise, and directly addresses the question. 
            The answer should include the birth year of the novelist illustrated by John Farleigh.""",
            context=final_answer
        )

        return refined_answer