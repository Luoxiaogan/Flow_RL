# Workflow ID: hotpotqa_61_0
# Benchmark: hotpotqa
# Data Indices: [292]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Analyze the question and extract key entities
        question_analysis = await self.generate(
            instruction="Analyze the question to identify key entities and the type of reasoning required. "
                        "For example, determine if the question is asking for a bridge entity, a comparison, or a compositional fact. "
                        "Extract all relevant entities mentioned in the question.",
            context=self.problem_text
        )

        # Step 2: Identify relevant documents containing the entities
        document_selection = await self.generate(
            instruction=f"Based on the extracted entities: {question_analysis}, "
                        "identify which documents contain relevant information. "
                        "List the document numbers and briefly explain why they are relevant.",
            context=self.problem_text
        )

        # Step 3: Extract and resolve bridge entities
        bridge_entity_resolution = await self.generate(
            instruction=f"Using the relevant documents: {document_selection}, "
                        "resolve the connection between the entities. "
                        "Extract specific sentences or facts that establish the relationship between the entities.",
            context=self.problem_text
        )

        # Step 4: Synthesize the final answer
        final_answer = await self.generate(
            instruction=f"Based on the resolved bridge entity: {bridge_entity_resolution}, "
                        "synthesize the final answer to the question. "
                        "Ensure the answer is concise and directly addresses the question.",
            context=self.problem_text
        )

        # Step 5: Revise and refine the answer for clarity and correctness
        refined_answer = await self.revise(
            instruction="Critique and refine the final answer to ensure it is clear, accurate, and well-supported by the context.",
            context=final_answer
        )

        return refined_answer