# Workflow ID: hotpotqa_182_0
# Benchmark: hotpotqa
# Data Indices: [324]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Identify Relevant Documents
        relevant_docs_instruction = """
        Analyze the provided context documents to identify which ones mention Julia Stiles and her Teen Choice Award nominations. 
        Focus on documents that provide information about films she was nominated for and their directors. 
        Return a list of document indices and brief summaries of their relevance.
        """
        relevant_docs = await self.generate(instruction=relevant_docs_instruction, context=self.problem_text)

        # Step 2: Extract Key Information
        extract_info_instruction = f"""
        Based on the identified relevant documents ({relevant_docs}), extract detailed information about:
        - The films for which Julia Stiles received Teen Choice Award nominations.
        - The directors of those films.
        Ensure the extraction is precise and includes all necessary details to answer the question.
        """
        extracted_info = await self.generate(instruction=extract_info_instruction, context=self.problem_text)

        # Step 3: Entity Resolution and Bridging
        resolve_entities_instruction = f"""
        Resolve any ambiguities in the extracted information ({extracted_info}). 
        Specifically:
        - Confirm that all mentions of Julia Stiles refer to the same person.
        - Link each film to its corresponding director.
        Provide a clear mapping of films to directors.
        """
        resolved_entities = await self.revise(instruction=resolve_entities_instruction, context=extracted_info)

        # Step 4: Multi-hop Reasoning
        reasoning_chain_instruction = f"""
        Using the resolved information ({resolved_entities}), construct a reasoning chain to answer the question:
        "Who was the director of the film for which Julia Stiles was nominated for a second pair of Teen Choice Awards?"
        Clearly outline the logical steps and connections between entities.
        """
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 5: Answer Synthesis
        synthesize_answer_instruction = f"""
        Based on the reasoning chain ({reasoning_chain}), synthesize a concise and accurate answer to the question.
        Ensure the answer is supported by the extracted information and reasoning.
        """
        final_answer = await self.summarize(instruction=synthesize_answer_instruction, context=reasoning_chain)

        return final_answer