# Workflow ID: hotpotqa_54_0
# Benchmark: hotpotqa
# Data Indices: [49]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio
        
        # Step 1: Extract key entities and parse the question
        entity_extraction = await self.generate(
            instruction="Identify the primary entity mentioned in the question and the type of information being sought. "
                        "For example, if the question asks about a person's role or affiliation, extract the person's name and the context.",
            context=self.problem_text
        )
        
        # Step 2: Filter relevant documents
        document_relevance_tasks = [
            self.generate(
                instruction=f"Determine if this document contains information relevant to the entity '{entity_extraction}'. "
                            "Focus on explicit mentions of the entity or related concepts.",
                context=doc
            ) for doc in self.config['documents']
        ]
        relevance_results = await asyncio.gather(*document_relevance_tasks)
        relevant_documents = [doc for doc, result in zip(self.config['documents'], relevance_results) if "relevant" in result.lower()]
        
        # Step 3: Resolve entity mentions across documents
        entity_resolution = await self.ensemble(
            instruction="Compare mentions of the entity across the provided documents. "
                        "Resolve any ambiguities and confirm consistent references to the same entity.",
            contexts=relevant_documents
        )
        
        # Step 4: Construct the reasoning chain
        reasoning_chain = await self.generate(
            instruction=f"Using the resolved entity '{entity_resolution}', build a reasoning chain that connects information "
                        "from the relevant documents. Ensure logical consistency and explicitly mention how each document contributes to the answer.",
            context="\n".join(relevant_documents)
        )
        
        # Step 5: Extract the precise answer
        answer_extraction = await self.summarize(
            instruction="From the reasoning chain, extract the precise answer span that directly answers the question. "
                        "Ensure the answer is concise and supported by the provided documents.",
            context=reasoning_chain
        )
        
        # Step 6: Validate and refine the answer
        refined_answer = await self.revise(
            instruction="Review the extracted answer against the original problem text. "
                        "Ensure it is accurate, complete, and directly addresses the question. Make refinements if necessary.",
            context=answer_extraction
        )
        
        return refined_answer