# Workflow ID: hotpotqa_143_0
# Benchmark: hotpotqa
# Data Indices: [355]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify relevant documents
        relevant_docs_instruction = """
        Analyze the provided documents and identify all that mention the pair of motor races held on 18 and 19 April 2015 at the Bahrain International Circuit in Sakhir, Bahrain.
        Provide a list of document indices or titles that are relevant to this specific event.
        """
        relevant_docs = await self.generate(instruction=relevant_docs_instruction, context=self.problem_text)

        # Step 2: Extract team names from relevant documents
        team_extraction_instruction = f"""
        From the following relevant documents: {relevant_docs}, extract all team names mentioned in the context of the pair of motor races held on 18 and 19 April 2015.
        Ensure you capture all variations of team names and provide them as a comprehensive list.
        """
        extracted_teams = await self.generate(instruction=team_extraction_instruction, context=self.problem_text)

        # Step 3: Deduplicate and refine team names
        deduplication_instruction = f"""
        Review the following list of extracted team names: {extracted_teams}.
        Remove duplicates and resolve variations in naming conventions to ensure each team is represented only once.
        Return a refined list of unique team names.
        """
        refined_teams = await self.revise(instruction=deduplication_instruction, context=extracted_teams)

        # Step 4: Count unique teams and finalize the answer
        final_answer_instruction = f"""
        Count the number of unique teams in the following refined list: {refined_teams}.
        Present the result as a single number representing the total count of teams represented in the races.
        """
        final_answer = await self.generate(instruction=final_answer_instruction, context=refined_teams)

        return final_answer