# Workflow ID: hotpotqa_285_0
# Benchmark: hotpotqa
# Data Indices: [398]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract entities from the question
        entities_extraction = await self.generate(
            instruction="Identify all named entities in the question. Focus on proper nouns such as people, organizations, or locations.",
            context=self.problem_text
        )
        
        # Step 2: Select relevant documents for each entity
        document_selection_instructions = f"""
        Given the extracted entities: {entities_extraction}, identify which documents contain information about these entities. 
        For each entity, list the relevant documents and briefly describe why they are relevant.
        """
        document_selection = await self.generate(
            instruction=document_selection_instructions,
            context=self.problem_text
        )

        # Step 3: Extract entity-specific facts in parallel
        async def extract_facts(entity):
            return await self.generate(
                instruction=f"""
                Extract all relevant facts about {entity} from the provided documents. 
                Focus on answering whether {entity} is an astronaut or has any association with space missions. 
                Provide a concise summary of the findings.
                """,
                context=document_selection
            )

        entities = ["Thomas Reiter", "Sigmund Jähn"]  # Dynamically parsed from entities_extraction in a real implementation
        facts_results = await asyncio.gather(*(extract_facts(entity) for entity in entities))

        # Step 4: Synthesize the results using Ensemble
        synthesis_instruction = f"""
        Compare the extracted facts about {entities[0]} and {entities[1]}. 
        Determine whether both entities are described as astronauts in the provided documents. 
        Provide a clear and concise conclusion based on the evidence.
        """
        synthesis_result = await self.ensemble(
            instruction=synthesis_instruction,
            contexts=facts_results
        )

        # Step 5: Refine the final answer
        refined_answer = await self.revise(
            instruction="Critique and refine the provided answer to ensure it is clear, concise, and directly addresses the question.",
            context=synthesis_result
        )

        return refined_answer