# Workflow ID: hotpotqa_260_0
# Benchmark: hotpotqa
# Data Indices: [342]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract information about Piers Haggard and Georges Méliès
        extraction_instruction = (
            "Extract all information about the following entities from the provided documents. "
            "Include details about their roles, professions, activities, and any other relevant attributes. "
            "Ensure the output is concise but comprehensive."
        )
        piers_extraction = self.generate(instruction=extraction_instruction, context="Piers Haggard")
        melies_extraction = self.generate(instruction=extraction_instruction, context="Georges Méliès")
        piers_info, melies_info = await asyncio.gather(piers_extraction, melies_extraction)

        # Step 2: Identify occupations for each entity
        occupation_instruction = (
            "From the provided information, identify the specific occupations or professional roles "
            "associated with the entity. List them clearly and concisely."
        )
        piers_occupations = self.generate(instruction=occupation_instruction, context=piers_info)
        melies_occupations = self.generate(instruction=occupation_instruction, context=melies_info)
        piers_jobs, melies_jobs = await asyncio.gather(piers_occupations, melies_occupations)

        # Step 3: Find mutual occupation(s)
        ensemble_instruction = (
            "Compare the two lists of occupations and identify any mutual occupation(s) shared by both entities. "
            "If there are multiple mutual occupations, list them all. If none exist, state that explicitly."
        )
        mutual_occupation = await self.ensemble(
            instruction=ensemble_instruction,
            contexts=[piers_jobs, melies_jobs]
        )

        # Step 4: Refine the final answer (optional)
        refine_instruction = (
            "Refine the provided answer to ensure it is clear, concise, and directly addresses the question. "
            "Remove any unnecessary details or ambiguity."
        )
        final_answer = await self.revise(instruction=refine_instruction, context=mutual_occupation)

        return final_answer