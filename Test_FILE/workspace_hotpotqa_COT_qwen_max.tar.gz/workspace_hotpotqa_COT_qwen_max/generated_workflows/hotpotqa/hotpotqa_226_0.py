# Workflow ID: hotpotqa_226_0
# Benchmark: hotpotqa
# Data Indices: [100]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Parse the question and identify key entities
        question_analysis = await self.generate(
            instruction="Analyze the question and extract all key entities, relationships, and the type of answer required. "
                        "Focus on identifying the main subject and any constraints or specific details mentioned in the question.",
            context=self.problem_text
        )

        # Step 2: Identify relevant documents
        document_relevance_tasks = [
            self.generate(
                instruction=f"Determine whether this document contains information about the entities or relationships extracted from the question. "
                            f"Entities and relationships to look for: {question_analysis}. "
                            "If relevant, summarize the key points related to these entities.",
                context=doc
            )
            for doc in ["Document 1", "Document 2", "Document 3", "Document 4", "Document 5", 
                        "Document 6", "Document 7", "Document 8", "Document 9", "Document 10"]
        ]
        document_relevance_results = await asyncio.gather(*document_relevance_tasks)

        # Step 3: Synthesize information across documents
        reasoning_chain = await self.ensemble(
            instruction="Synthesize information from the relevant documents to build a reasoning chain. "
                        "Connect the dots between entities mentioned in the question and the facts provided in the documents. "
                        "Ensure the reasoning is logical and explicitly tracks entity mentions across documents.",
            contexts=document_relevance_results
        )

        # Step 4: Extract the precise answer
        answer_extraction = await self.summarize(
            instruction="Based on the reasoning chain provided, extract the precise answer to the question. "
                        "Ensure the answer is concise and directly addresses the question.",
            context=reasoning_chain
        )

        # Step 5: Refine the answer
        refined_answer = await self.revise(
            instruction="Critique and refine the extracted answer to ensure accuracy, clarity, and proper formatting. "
                        "Correct any errors or ambiguities in the response.",
            context=answer_extraction
        )

        return refined_answer