# Workflow ID: hotpotqa_297_0
# Benchmark: hotpotqa
# Data Indices: [170]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key entities and analyze the question
        entity_extraction_instruction = """
        Analyze the given question and extract all key entities (e.g., names, locations, organizations). 
        Determine the type of information being requested (e.g., location, date, comparison).
        Format the output as follows:
        Key Entities: [List of entities]
        Information Requested: [Description of what is being asked]
        """
        entity_analysis = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Identify relevant documents
        document_selection_instruction = f"""
        Based on the extracted entities ({entity_analysis}), scan the provided documents to identify which ones contain relevant information.
        Focus on documents mentioning the key entities and their relationships.
        List the relevant documents and briefly describe why they are pertinent.
        """
        relevant_documents = await self.generate(instruction=document_selection_instruction, context=self.problem_text)

        # Step 3: Find the bridge entity or connecting information
        bridge_entity_instruction = f"""
        Using the relevant documents identified ({relevant_documents}), determine the "bridge entity" or connecting information that links the entities mentioned in the question.
        Provide a reasoning chain explaining how the entities are connected across documents.
        """
        bridge_entity = await self.generate(instruction=bridge_entity_instruction, context=self.problem_text)

        # Step 4: Synthesize the final answer
        synthesis_instruction = f"""
        Based on the reasoning chain ({bridge_entity}), extract the precise answer to the question.
        Ensure the answer directly addresses the information requested and is supported by specific sentences from the documents.
        Format the output as follows:
        Final Answer: [Precise answer]
        Supporting Facts: [Relevant sentences from the documents]
        """
        candidate_answers = [
            await self.generate(instruction=synthesis_instruction, context=self.problem_text),
            await self.generate(instruction="Consider alternative interpretations of the question and provide a secondary answer if applicable.", context=self.problem_text)
        ]
        final_answer = await self.ensemble(
            instruction="Evaluate the candidate answers and select the most accurate one based on the reasoning chain and supporting facts.",
            contexts=candidate_answers
        )

        # Step 5: Refine the final answer
        refinement_instruction = """
        Critique and refine the final answer to ensure clarity, correctness, and completeness.
        If necessary, adjust the phrasing or add additional supporting details.
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        return refined_answer