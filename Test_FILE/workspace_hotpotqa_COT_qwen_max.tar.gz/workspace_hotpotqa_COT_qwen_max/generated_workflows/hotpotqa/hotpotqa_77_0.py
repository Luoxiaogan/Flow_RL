# Workflow ID: hotpotqa_77_0
# Benchmark: hotpotqa
# Data Indices: [294]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Identify the main entity in the question
        entity_identification_instruction = """
        Identify the main entity mentioned in the question. 
        The entity could be a person, organization, location, or other significant noun.
        Provide the entity name as the output.
        """
        main_entity = await self.generate(instruction=entity_identification_instruction, context=self.problem_text)

        # Step 2: Find documents mentioning the entity
        document_selection_instruction = f"""
        From the provided context documents, identify all documents that mention the entity "{main_entity.strip()}".
        For each relevant document, extract the sentences or paragraphs that contain information about the entity.
        Return the extracted information along with the document titles.
        """
        relevant_documents = await self.generate(instruction=document_selection_instruction, context=self.problem_text)

        # Step 3: Extract relevant facts about the entity
        fact_extraction_instruction = f"""
        From the extracted information about "{main_entity.strip()}", identify all relevant facts.
        Focus on facts that directly answer the question or contribute to building an inference chain.
        Organize the facts in a structured format for further processing.
        """
        extracted_facts = await self.generate(instruction=fact_extraction_instruction, context=relevant_documents)

        # Step 4: Summarize the extracted facts
        summarization_instruction = f"""
        Condense the extracted facts about "{main_entity.strip()}" into a concise summary.
        Ensure that the summary retains all critical information needed to answer the question.
        """
        summarized_facts = await self.summarize(instruction=summarization_instruction, context=extracted_facts)

        # Step 5: Generate the final answer
        answer_generation_instruction = f"""
        Based on the summarized facts, generate a precise and accurate answer to the question.
        Ensure that the answer is supported by the information provided in the context.
        """
        final_answer = await self.generate(instruction=answer_generation_instruction, context=summarized_facts)

        # Step 6: Refine the final answer
        refinement_instruction = """
        Review the generated answer for clarity, correctness, and completeness.
        Make any necessary improvements to ensure the answer is concise and directly addresses the question.
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        return refined_answer