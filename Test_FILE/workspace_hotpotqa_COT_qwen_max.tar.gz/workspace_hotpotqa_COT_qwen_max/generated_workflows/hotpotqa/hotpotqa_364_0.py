# Workflow ID: hotpotqa_364_0
# Benchmark: hotpotqa
# Data Indices: [213]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key entities and relevant documents
        entity_extraction_instruction = """Identify all key entities mentioned in the question and determine which documents are relevant to answering it. Provide the entities and their corresponding document IDs."""
        entity_extraction = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Identify the bridge entity
        bridge_entity_instruction = f"""Based on the extracted entities and relevant documents, identify the bridge entity that connects multiple documents. Bridge entities are typically shared nouns or concepts. Entities: {entity_extraction}"""
        bridge_entity = await self.generate(instruction=bridge_entity_instruction, context=self.problem_text)

        # Step 3: Construct the reasoning chain
        reasoning_chain_instruction = f"""Using the bridge entity identified, construct a reasoning chain that connects the documents and leads to the answer. Bridge entity: {bridge_entity}"""
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 4: Extract the final answer
        answer_extraction_instruction = f"""Based on the reasoning chain, extract the final answer to the question. Reasoning chain: {reasoning_chain}"""
        answer_extraction = await self.summarize(instruction=answer_extraction_instruction, context=self.problem_text)

        # Step 5: Validate and refine the answer
        refinement_instruction = f"""Critique and refine the extracted answer to ensure it is accurate and directly addresses the question. Extracted answer: {answer_extraction}"""
        refined_answer = await self.revise(instruction=refinement_instruction, context=self.problem_text)

        return refined_answer