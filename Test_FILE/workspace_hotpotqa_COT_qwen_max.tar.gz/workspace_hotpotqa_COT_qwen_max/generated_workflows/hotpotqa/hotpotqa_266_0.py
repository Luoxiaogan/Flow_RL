# Workflow ID: hotpotqa_266_0
# Benchmark: hotpotqa
# Data Indices: [182]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify key entities and reasoning type
        entity_identification = await self.generate(
            instruction="Identify all key entities mentioned in the question and classify the reasoning type as one of the following: bridge, comparison, or compositional. Provide the reasoning type and list the entities.",
            context=self.problem_text
        )

        # Dynamically construct instructions for document selection and information extraction
        extraction_instruction = f"""
        Given the identified entities and reasoning type: {entity_identification},
        search through the provided documents and extract sentences that mention these entities.
        Focus on sentences that provide relevant information for answering the question.
        """

        # Step 2: Extract relevant information from documents
        document_extraction = await self.generate(
            instruction=extraction_instruction,
            context=self.problem_text
        )

        # Step 3: Construct reasoning chain
        reasoning_chain_instruction = f"""
        Using the extracted information: {document_extraction},
        construct a reasoning chain that connects the entities across documents.
        For bridge questions, identify the bridge entity that links the documents.
        For comparison questions, extract comparable properties of the entities.
        For compositional questions, chain multiple facts together to derive the answer.
        """

        reasoning_chain = await self.generate(
            instruction=reasoning_chain_instruction,
            context=self.problem_text
        )

        # Step 4: Synthesize the final answer
        answer_synthesis_instruction = f"""
        Based on the reasoning chain: {reasoning_chain},
        synthesize the final answer to the question. Ensure the answer is concise and directly addresses the question.
        If the question requires a yes/no answer, provide the appropriate response.
        If the question requires an entity name or factual response, extract the precise answer span from the reasoning chain.
        """

        final_answer = await self.generate(
            instruction=answer_synthesis_instruction,
            context=self.problem_text
        )

        # Step 5: Validate and refine the answer
        refinement_instruction = f"""
        Review the final answer: {final_answer},
        and validate if it aligns with the reasoning chain and extracted information.
        If necessary, refine the answer to ensure accuracy and clarity.
        """

        refined_answer = await self.revise(
            instruction=refinement_instruction,
            context=final_answer
        )

        return refined_answer