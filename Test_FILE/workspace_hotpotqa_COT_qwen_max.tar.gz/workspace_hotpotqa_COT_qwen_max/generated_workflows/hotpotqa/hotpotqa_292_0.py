# Workflow ID: hotpotqa_292_0
# Benchmark: hotpotqa
# Data Indices: [142]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract entities and relevant facts
        entity_extraction = await self.generate(
            instruction="""Identify all mentions of the target entity (e.g., 'John Jett') 
            and related facts from the documents. Focus on the question and context. 
            Extract specific details such as events, relationships, and attributes.""",
            context=self.problem_text
        )

        # Step 2: Build reasoning chains
        reasoning_chain = await self.generate(
            instruction=f"""Using the extracted information: {entity_extraction}, 
            construct a logical chain of reasoning to answer the question. 
            Connect facts across documents through shared entities or logical relationships. 
            Ensure the chain explicitly addresses the question.""",
            context=self.problem_text
        )

        # Step 3: Summarize the reasoning chain
        summarized_answer = await self.summarize(
            instruction="Condense the reasoning chain into a concise answer. Focus on the key facts and relationships.",
            context=reasoning_chain
        )

        # Step 4: Ensemble multiple reasoning paths (if needed)
        # Generate alternative reasoning paths for robustness
        alternative_reasoning = await self.generate(
            instruction=f"""Provide an alternative reasoning path based on the extracted information: {entity_extraction}. 
            Ensure it addresses the same question but uses different connections or facts.""",
            context=self.problem_text
        )
        final_answer = await self.ensemble(
            instruction="Compare the reasoning paths and select the most accurate and complete answer.",
            contexts=[summarized_answer, alternative_reasoning]
        )

        # Step 5: Refine the final answer
        refined_answer = await self.revise(
            instruction="Refine the answer for clarity, correctness, and conciseness. Ensure it directly answers the question.",
            context=final_answer
        )

        return refined_answer