# Workflow ID: hotpotqa_28_0
# Benchmark: hotpotqa
# Data Indices: [296]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify relevant documents for "The American Ruling Class" and "Stevie"
        instruction_entity_identification = """
        Identify all documents that mention the entities "The American Ruling Class" and "Stevie".
        For each entity, list the document numbers and provide a brief summary of the context in which the entity appears.
        Focus on documents that provide information about whether these entities are films.
        """

        entity_identification = await self.generate(instruction=instruction_entity_identification, context=self.problem_text)

        # Step 2: Extract information about whether these entities are films
        instruction_film_status_extraction = f"""
        Based on the following identified documents: {entity_identification}
        Extract specific sentences or phrases that confirm or deny whether "The American Ruling Class" and "Stevie" are films.
        Provide clear evidence from the text to support your conclusions.
        """

        film_status_extraction = await self.generate(instruction=instruction_film_status_extraction, context=self.problem_text)

        # Step 3: Combine information and produce the final answer
        instruction_final_answer = f"""
        Based on the extracted information: {film_status_extraction}
        Determine whether "The American Ruling Class" and "Stevie" are films.
        Provide a concise answer for each entity, supported by the evidence from the documents.
        """

        final_answer = await self.ensemble(instruction=instruction_final_answer, contexts=[entity_identification, film_status_extraction])

        return final_answer