# Workflow ID: hotpotqa_10_0
# Benchmark: hotpotqa
# Data Indices: [158]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Parse the question to identify entities and reasoning type
        question_analysis = await self.generate(
            instruction="Analyze the question to identify key entities, relationships, and the reasoning type (e.g., bridge, comparison). "
                        "Provide a structured output detailing the entities involved and the logical steps required to answer the question.",
            context=self.problem_text
        )

        # Step 2: Evaluate document relevance
        # Extract document texts dynamically from the problem context
        documents = [f"Document {i+1}: {doc}" for i, doc in enumerate(self.problem_text.split("\n\n")) if doc.startswith("Document")]
        relevance_tasks = [
            self.generate(
                instruction=f"Evaluate the relevance of this document to the entities and reasoning type identified in the question analysis: {question_analysis}. "
                            "Provide a score from 0 to 10 indicating how relevant this document is to answering the question.",
                context=doc
            )
            for doc in documents
        ]
        relevance_scores = await asyncio.gather(*relevance_tasks)

        # Step 3: Select the most relevant documents
        selected_documents = await self.ensemble(
            instruction="Select the most relevant documents based on their relevance scores. "
                        "Ensure the selected documents collectively cover all entities and reasoning steps identified in the question analysis.",
            contexts=[f"{doc}\nRelevance Score: {score}" for doc, score in zip(documents, relevance_scores)]
        )

        # Step 4: Resolve entities and construct reasoning chain
        reasoning_chain = await self.generate(
            instruction=f"Using the selected documents: {selected_documents}, resolve entity mentions across documents and construct a reasoning chain. "
                        "Extract supporting facts and connect them logically to address the question.",
            context=self.problem_text
        )

        # Step 5: Summarize the reasoning chain
        summarized_reasoning = await self.summarize(
            instruction="Condense the reasoning chain into a concise summary that preserves all key facts and logical connections. "
                        "Ensure the summary directly supports answering the question.",
            context=reasoning_chain
        )

        # Step 6: Extract and refine the final answer
        final_answer = await self.revise(
            instruction="Extract the precise answer span from the summarized reasoning chain. "
                        "Ensure the answer is concise, accurate, and directly addresses the question.",
            context=summarized_reasoning
        )

        return final_answer