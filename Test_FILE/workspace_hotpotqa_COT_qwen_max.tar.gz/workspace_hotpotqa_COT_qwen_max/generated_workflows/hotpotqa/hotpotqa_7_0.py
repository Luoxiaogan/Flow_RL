# Workflow ID: hotpotqa_7_0
# Benchmark: hotpotqa
# Data Indices: [46]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key entities and relationships from the question
        entity_extraction_instruction = """
        Extract all key entities (e.g., names, dates, titles) and their relationships from the question. 
        Identify the primary entity and the specific information being asked for.
        """
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Identify relevant documents based on extracted entities
        document_selection_instruction = f"""
        Given the extracted entities: {entities}, identify which documents contain relevant information.
        Match entities from the question to the documents and rank them by relevance.
        """
        document_results = []
        for i in range(1, 11):  # Assuming 10 documents as per the example
            doc_context = f"Document {i}: [Content of Document {i}]"
            result = await self.generate(instruction=document_selection_instruction, context=doc_context)
            document_results.append(result)

        # Step 3: Build a reasoning chain across documents
        reasoning_instruction = f"""
        Using the relevant documents identified: {document_results}, connect the information across documents.
        Build a reasoning chain that links the primary entity to the requested information.
        """
        reasoning_chain = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Extract the precise answer span
        answer_extraction_instruction = f"""
        Based on the reasoning chain: {reasoning_chain}, extract the exact answer span from the text.
        Ensure the answer directly addresses the question.
        """
        answer_span = await self.generate(instruction=answer_extraction_instruction, context=self.problem_text)

        # Step 5: Validate and refine the answer
        refinement_instruction = f"""
        Revise the extracted answer: {answer_span} to ensure accuracy and completeness.
        Cross-check it against the original problem text and refine if necessary.
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=self.problem_text)

        # Step 6: Summarize the final answer
        summary_instruction = """
        Condense the refined answer into a concise form suitable for the question.
        """
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_answer)

        return final_answer