# Workflow ID: hotpotqa_12_0
# Benchmark: hotpotqa
# Data Indices: [5]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio
        
        # Step 1: Parse the question to identify key entities and reasoning type
        question_analysis = await self.generate(
            instruction="Analyze the question to identify the key entities and the type of reasoning required (e.g., bridge entity, comparison). "
                        "Output the entities and reasoning type in JSON format.",
            context=self.problem_text
        )
        
        # Step 2: Summarize each document to identify relevant ones
        document_summaries = await asyncio.gather(
            *[self.summarize(
                instruction="Summarize the document to highlight key entities, themes, and facts relevant to the question.",
                context=document
            ) for document in self.problem_text['context_documents']]
        )
        
        # Step 3: Identify shared entities or relationships across documents
        shared_entities = await self.ensemble(
            instruction="Compare the document summaries to identify shared entities or relationships that connect the documents. "
                        "Focus on entities mentioned in the question analysis.",
            contexts=document_summaries
        )
        
        # Step 4: Construct the reasoning chain and derive the answer
        reasoning_chain = await self.generate(
            instruction=f"Using the shared entities identified ({shared_entities}), construct a reasoning chain that connects the information "
                        "from the documents to answer the question. Ensure the chain is logical and explicitly references the documents.",
            context=self.problem_text
        )
        
        # Step 5: Validate and refine the answer
        final_answer = await self.revise(
            instruction="Critique and refine the reasoning chain to ensure the answer is accurate, complete, and directly supported by the text. "
                        "Output the final answer in a clear and concise format.",
            context=reasoning_chain
        )
        
        return final_answer