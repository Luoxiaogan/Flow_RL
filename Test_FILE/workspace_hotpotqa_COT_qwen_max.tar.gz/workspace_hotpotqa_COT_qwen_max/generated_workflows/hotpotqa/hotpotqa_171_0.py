# Workflow ID: hotpotqa_171_0
# Benchmark: hotpotqa
# Data Indices: [154]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Identify entities and select relevant documents
        entity_extraction_instruction = """
        Identify all named entities in the question that represent people or organizations.
        Then, find which documents in the provided context mention these entities.
        Return the entities and their corresponding document titles in a structured format.
        """
        entities_and_documents = await self.generate(
            instruction=entity_extraction_instruction,
            context=self.problem_text
        )

        # Parse the result into a structured format
        # Assuming the output is a JSON-like string for simplicity
        import json
        parsed_entities_and_documents = json.loads(entities_and_documents)

        # Step 2: Extract relevant information for each entity in parallel
        async def extract_entity_info(entity, document_titles):
            extraction_instruction = f"""
            From the documents titled {document_titles}, extract all information related to {entity}.
            Focus on details that could help answer the question, such as nationality, roles, or affiliations.
            """
            raw_info = await self.generate(
                instruction=extraction_instruction,
                context=self.problem_text
            )
            revised_info = await self.revise(
                instruction=f"Ensure the extracted information about {entity} is accurate and relevant.",
                context=raw_info
            )
            return revised_info

        tasks = [
            extract_entity_info(entity, data["documents"])
            for entity, data in parsed_entities_and_documents.items()
        ]
        entity_information = await asyncio.gather(*tasks)

        # Step 3: Synthesize the information to answer the question
        synthesis_instruction = """
        Based on the provided information about each entity, determine which entity satisfies the question's criteria.
        Provide a clear and concise answer, supported by reasoning.
        """
        final_answer = await self.ensemble(
            instruction=synthesis_instruction,
            contexts=entity_information
        )

        return final_answer