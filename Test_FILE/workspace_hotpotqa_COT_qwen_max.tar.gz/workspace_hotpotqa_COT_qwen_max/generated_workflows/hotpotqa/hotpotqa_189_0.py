# Workflow ID: hotpotqa_189_0
# Benchmark: hotpotqa
# Data Indices: [249]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Analyze the question and extract key entities
        question_analysis = await self.generate(
            instruction="Analyze the question to identify key entities and their relationships. "
                        "Focus on understanding what the question is asking for and what information is needed to answer it. "
                        "Provide a detailed breakdown of the entities and their potential roles in the context.",
            context=self.problem_text
        )

        # Step 2: Filter relevant documents based on key entities
        filtered_documents = await self.generate(
            instruction=f"Using the identified entities: {question_analysis}, "
                        "filter the provided documents to find those that mention these entities. "
                        "Ensure the selected documents are relevant to answering the question.",
            context=self.problem_text
        )

        # Step 3: Resolve entity ambiguities
        resolved_entities = await self.ensemble(
            instruction="Compare mentions of the target entity across the filtered documents. "
                        "Resolve any ambiguities by determining the most likely interpretation of the entity "
                        "based on the context of the question and the documents.",
            contexts=[filtered_documents, self.problem_text]
        )

        # Step 4: Construct the reasoning chain
        reasoning_chain = await self.generate(
            instruction=f"Based on the resolved entities: {resolved_entities}, "
                        "construct a logical reasoning chain that connects the question to the answer. "
                        "Synthesize information from the filtered documents to build this chain step by step. "
                        "Ensure the reasoning is clear and leads directly to the answer.",
            context=filtered_documents
        )

        # Step 5: Summarize the reasoning chain into a concise answer
        final_answer = await self.summarize(
            instruction="Condense the reasoning chain into a concise answer that directly addresses the question. "
                        "Ensure the answer is precise and includes only the necessary information.",
            context=reasoning_chain
        )

        return final_answer