# Workflow ID: hotpotqa_92_0
# Benchmark: hotpotqa
# Data Indices: [67]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key entities and relationships from the question
        entity_extraction_instruction = (
            "Extract all key entities and relationships mentioned in the question. "
            "Focus on identifying proper nouns (e.g., names of places, organizations), "
            "geographical references, and any other relevant terms. "
            "Provide the output as a list of entities and their descriptions."
        )
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Identify relevant documents and match entities across them
        document_matching_instruction = (
            f"Given the following entities: {entities}, analyze the provided documents "
            "to find which ones contain information about these entities. "
            "For each document, summarize how it relates to the entities and whether it provides useful information."
        )
        document_summaries = await asyncio.gather(
            *[self.generate(instruction=document_matching_instruction, context=doc) for doc in self.problem_text["documents"]]
        )

        # Step 3: Resolve entities and construct a reasoning chain
        reasoning_chain_instruction = (
            f"Using the following summaries of relevant documents: {document_summaries}, "
            "construct a reasoning chain that connects the entities mentioned in the question. "
            "Explicitly state how the information from different documents supports the answer. "
            "Ensure the reasoning is logical and step-by-step."
        )
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 4: Extract the final answer
        answer_extraction_instruction = (
            f"Based on the following reasoning chain: {reasoning_chain}, "
            "extract the final answer as a short text span or phrase. "
            "Ensure the answer directly addresses the question and is supported by the reasoning."
        )
        final_answer = await self.summarize(instruction=answer_extraction_instruction, context=reasoning_chain)

        return final_answer