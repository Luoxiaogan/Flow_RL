# Workflow ID: hotpotqa_21_0
# Benchmark: hotpotqa
# Data Indices: [264]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract entities and identify relevant documents
        entity_extraction_instruction = """
        Extract all named entities (e.g., organizations, products, locations) mentioned in the question and match them with entities found in the provided documents.
        Return the list of entities along with the document IDs where they appear.
        """
        entities_and_documents = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Classify the reasoning type (bridging, comparison, compositional)
        reasoning_type_instruction = f"""
        Based on the extracted entities and the question, classify the reasoning type required to answer the question. 
        The possible types are:
        - Bridging: Connecting information across documents through shared entities.
        - Comparison: Evaluating properties or attributes of entities.
        - Compositional: Combining multiple facts to derive the answer.
        Entities and documents: {entities_and_documents}
        """
        reasoning_type = await self.generate(instruction=reasoning_type_instruction, context=self.problem_text)

        # Step 3: Bridge entity detection (if bridging is required)
        if "Bridging" in reasoning_type:
            bridge_entity_instruction = f"""
            Identify the bridge entity that connects the documents mentioned in the question. 
            A bridge entity is typically a shared concept, organization, or product that links the entities across documents.
            Entities and documents: {entities_and_documents}
            """
            bridge_entity = await self.generate(instruction=bridge_entity_instruction, context=self.problem_text)
        else:
            bridge_entity = None

        # Step 4: Fact extraction and synthesis
        fact_extraction_instruction = f"""
        Extract specific facts from the relevant documents that are necessary to answer the question. 
        Focus on the entities and reasoning type identified earlier.
        Entities and documents: {entities_and_documents}
        Reasoning type: {reasoning_type}
        Bridge entity (if applicable): {bridge_entity}
        """
        extracted_facts = await self.generate(instruction=fact_extraction_instruction, context=self.problem_text)

        # Step 5: Answer formulation
        answer_formulation_instruction = f"""
        Using the extracted facts, formulate a concise answer to the question. 
        Ensure the answer directly addresses the question and is supported by the facts.
        Extracted facts: {extracted_facts}
        """
        initial_answer = await self.generate(instruction=answer_formulation_instruction, context=self.problem_text)

        # Step 6: Validation and refinement
        refinement_instruction = f"""
        Review the initial answer for accuracy and clarity. 
        Ensure it is concise, directly addresses the question, and is fully supported by the extracted facts.
        Initial answer: {initial_answer}
        Extracted facts: {extracted_facts}
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=initial_answer)

        # Step 7: Summarize supporting evidence
        summary_instruction = f"""
        Summarize the key supporting evidence that validates the refined answer. 
        Include references to specific documents and sentences.
        Refined answer: {refined_answer}
        Extracted facts: {extracted_facts}
        """
        supporting_evidence = await self.summarize(instruction=summary_instruction, context=extracted_facts)

        # Final output
        return {
            "answer": refined_answer,
            "supporting_evidence": supporting_evidence
        }