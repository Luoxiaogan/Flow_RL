# Workflow ID: hotpotqa_249_0
# Benchmark: hotpotqa
# Data Indices: [202]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify key entities and parse the question
        entity_identification = await self.generate(
            instruction="Identify the key entities mentioned in the question and determine what the question is asking. "
                        "Extract the entities and the specific type of information requested (e.g., 'scientific career').",
            context=self.problem_text
        )

        # Step 2: Locate relevant documents containing the entities
        document_selection = await self.generate(
            instruction=f"Using the identified entities: {entity_identification}, "
                        "scan all context documents to find which ones mention these entities. "
                        "Return the list of relevant documents.",
            context=self.problem_text
        )

        # Step 3: Extract information about the entities' scientific careers
        info_extraction = await self.generate(
            instruction=f"From the relevant documents: {document_selection}, "
                        "extract specific information about the scientific careers of the identified entities. "
                        "Focus on details such as their fields of study, notable achievements, and roles.",
            context=self.problem_text
        )

        # Step 4: Perform multi-hop reasoning to find the common scientific career
        reasoning_result = await self.ensemble(
            instruction="Compare the extracted information about the scientific careers of the entities. "
                        "Identify the common scientific field or role shared by both entities. "
                        "Provide a clear and concise conclusion.",
            contexts=[info_extraction]
        )

        # Step 5: Generate the final answer
        final_answer = await self.generate(
            instruction=f"Based on the reasoning result: {reasoning_result}, "
                        "generate a concise answer to the original question. "
                        "Ensure the answer directly addresses the question and includes supporting evidence.",
            context=self.problem_text
        )

        return final_answer