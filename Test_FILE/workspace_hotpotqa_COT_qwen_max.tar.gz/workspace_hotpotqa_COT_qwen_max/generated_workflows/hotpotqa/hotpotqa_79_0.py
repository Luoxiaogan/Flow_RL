# Workflow ID: hotpotqa_79_0
# Benchmark: hotpotqa
# Data Indices: [181]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key entities and relationships from the question
        entity_extraction_instruction = (
            "Analyze the question and extract all key entities, relationships, and constraints. "
            "Focus on identifying the main subject (e.g., band, person, organization) and the specific information being asked (e.g., album, date, event). "
            "Format the output as a JSON object with keys 'entities', 'relationships', and 'constraints'."
        )
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Identify relevant documents based on extracted entities
        document_selection_instruction = (
            f"Using the extracted entities: {entities}, identify which documents contain relevant information. "
            "Focus on documents that mention the main subject and the specific information being asked. "
            "Return a list of document indices or titles that are relevant."
        )
        relevant_documents = await self.generate(instruction=document_selection_instruction, context=self.problem_text)

        # Step 3: Perform cross-document reasoning to connect information
        reasoning_instruction = (
            f"Based on the relevant documents: {relevant_documents}, perform cross-document reasoning to answer the question. "
            "Identify bridge entities or shared information that connects different documents. "
            "Build a reasoning chain step by step, explaining how the information from different documents leads to the answer. "
            "Format the output as a JSON object with keys 'reasoning_chain' and 'answer'."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Verify and refine the answer
        verification_instruction = (
            f"Verify the reasoning chain: {reasoning_result['reasoning_chain']} and the proposed answer: {reasoning_result['answer']}. "
            "Ensure the answer is accurate and supported by the documents. "
            "If necessary, revise the answer or reasoning chain to improve clarity and correctness."
        )
        verified_answer = await self.revise(instruction=verification_instruction, context=self.problem_text)

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"Summarize the final answer and reasoning chain: {verified_answer}. "
            "Provide a concise response that directly answers the question, along with any supporting facts from the documents."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=self.problem_text)

        return final_summary