# Workflow ID: hotpotqa_120_0
# Benchmark: hotpotqa
# Data Indices: [367]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Analyze the question and identify key entities
        question_analysis = await self.generate(
            instruction="Analyze the question to identify the key entities and relationships. "
                        "Determine the type of reasoning required (e.g., bridge, comparison, compositional). "
                        "Provide a structured output with the identified entities and reasoning type.",
            context=self.problem_text
        )

        # Step 2: Select relevant documents based on identified entities
        document_selection = await self.generate(
            instruction=f"Based on the identified entities and reasoning type: {question_analysis}, "
                        "select the most relevant documents from the provided context. "
                        "Focus on documents that mention the key entities or their relationships.",
            context=self.problem_text
        )

        # Step 3: Extract relevant information from selected documents
        extraction_tasks = []
        for doc in document_selection.split("\n"):  # Assuming documents are listed line-by-line
            extraction_tasks.append(
                self.summarize(
                    instruction=f"Extract all sentences or facts from the following document that mention the key entities: {question_analysis}.",
                    context=doc
                )
            )
        extracted_info = await asyncio.gather(*extraction_tasks)

        # Step 4: Construct reasoning chains from extracted information
        reasoning_chain = await self.generate(
            instruction=f"Combine the following extracted facts into a coherent reasoning chain: {extracted_info}. "
                        "Ensure the chain logically connects the key entities and answers the question.",
            context=self.problem_text
        )

        # Step 5: Synthesize the final answer
        final_answer = await self.revise(
            instruction="Refine the reasoning chain into a concise and accurate answer. "
                        "Ensure the answer directly addresses the question and is supported by the provided facts.",
            context=reasoning_chain
        )

        return final_answer