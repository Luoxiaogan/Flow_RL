# Workflow ID: hotpotqa_218_0
# Benchmark: hotpotqa
# Data Indices: [78]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract entities and relationships
        entity_extraction_instruction = (
            "Identify all entities mentioned in the context documents and their relationships. "
            "Focus on entities that could serve as bridge entities connecting multiple documents. "
            "Provide the output in a structured format, listing entities and their relationships."
        )
        entities_and_relationships = await self.generate(
            instruction=entity_extraction_instruction,
            context=self.problem_text
        )

        # Step 2: Filter relevant documents
        relevance_filter_instruction = (
            f"Given the extracted entities and relationships: {entities_and_relationships}, "
            "determine which documents are most relevant to answering the question. "
            "Focus on documents that mention the entities or relationships identified earlier. "
            "Provide a list of relevant document indices or names."
        )
        relevant_documents = await self.generate(
            instruction=relevance_filter_instruction,
            context=self.problem_text
        )

        # Step 3: Summarize relevant document content
        summarization_instruction = (
            f"For each relevant document identified: {relevant_documents}, "
            "summarize the key information related to the question. "
            "Ensure the summary includes details about entities and their relationships."
        )
        document_summaries = await self.summarize(
            instruction=summarization_instruction,
            context=self.problem_text
        )

        # Step 4: Construct reasoning chain
        reasoning_chain_instruction = (
            f"Using the summaries of relevant documents: {document_summaries}, "
            "construct a logical chain of reasoning that connects the information across documents. "
            "Explain how the entities and relationships lead to the answer. "
            "Provide the reasoning chain in a step-by-step format."
        )
        reasoning_chain = await self.generate(
            instruction=reasoning_chain_instruction,
            context=self.problem_text
        )

        # Step 5: Synthesize final answer
        final_answer_instruction = (
            f"Based on the reasoning chain: {reasoning_chain}, "
            "extract the final answer to the question. "
            "Ensure the answer is concise, precise, and supported by specific text spans from the documents."
        )
        final_answer = await self.generate(
            instruction=final_answer_instruction,
            context=self.problem_text
        )

        return final_answer