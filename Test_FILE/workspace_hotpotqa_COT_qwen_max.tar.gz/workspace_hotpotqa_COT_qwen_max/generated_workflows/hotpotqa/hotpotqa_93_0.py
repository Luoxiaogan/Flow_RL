# Workflow ID: hotpotqa_93_0
# Benchmark: hotpotqa
# Data Indices: [223]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract Entities and Identify Relevant Documents
        entity_extraction_instruction = (
            "Identify all key entities and terms in the question. "
            "Then, analyze each document to determine its relevance to these entities. "
            "Return a list of relevant documents along with their key information."
        )
        relevant_documents = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Summarize Relevant Information
        summarize_instruction = (
            f"Given the following relevant documents: {relevant_documents}, "
            "summarize the key information related to the question entities. "
            "Focus on factual details and relationships between entities."
        )
        summary = await self.summarize(instruction=summarize_instruction, context=relevant_documents)

        # Step 3: Construct Reasoning Chain
        reasoning_instruction = (
            f"Using the summarized information: {summary}, "
            "construct a reasoning chain that connects the facts to answer the question. "
            "Ensure the chain is logical and explicitly mentions how each fact leads to the next."
        )
        reasoning_chain = await self.generate(instruction=reasoning_instruction, context=summary)

        # Step 4: Refine the Answer
        refine_instruction = (
            f"Refine the following reasoning chain: {reasoning_chain} "
            "into a concise and direct answer to the question. "
            "Ensure the answer is clear, accurate, and formatted appropriately."
        )
        refined_answer = await self.revise(instruction=refine_instruction, context=reasoning_chain)

        return refined_answer