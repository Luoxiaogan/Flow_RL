# Workflow ID: hotpotqa_198_0
# Benchmark: hotpotqa
# Data Indices: [226]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Identify Relevant Documents
        identification_instruction = """
        Identify all documents that contain information relevant to the question. 
        Look for entities, dates, and key phrases mentioned in the question and find their occurrences in the provided documents.
        Ensure you consider synonyms and related terms that might indicate relevance.
        """
        relevant_docs = await self.generate(instruction=identification_instruction, context=self.problem_text)

        # Step 2: Extract Key Information
        extraction_instruction = f"""
        From the identified relevant documents: {relevant_docs}, extract key sentences or facts that are pertinent to answering the question.
        Focus on entities, dates, and relationships between different pieces of information. 
        Ensure the extracted information is concise and directly related to the question.
        """
        key_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 3: Summarize Extracted Information
        summarization_instruction = """
        Condense the extracted key information into a summary that captures the essential facts needed to answer the question.
        Ensure the summary maintains the logical connections between different pieces of information.
        """
        summarized_info = await self.summarize(instruction=summarization_instruction, context=key_info)

        # Step 4: Build Reasoning Chain
        reasoning_instruction = f"""
        Based on the summarized information: {summarized_info}, construct a reasoning chain that connects the facts logically to answer the question.
        If the question requires bridging entities, clearly show how the entities are connected across different documents.
        If the question involves comparisons, outline the properties being compared and how they relate to each other.
        """
        reasoning_chain = await self.generate(instruction=reasoning_instruction, context=summarized_info)

        # Step 5: Generate Final Answer
        final_answer_instruction = f"""
        Using the reasoning chain: {reasoning_chain}, generate a concise and accurate answer to the question.
        Ensure the answer is supported by the facts and is presented in the format requested by the question (e.g., short text span, yes/no, factual response).
        """
        final_answer = await self.generate(instruction=final_answer_instruction, context=reasoning_chain)

        return final_answer