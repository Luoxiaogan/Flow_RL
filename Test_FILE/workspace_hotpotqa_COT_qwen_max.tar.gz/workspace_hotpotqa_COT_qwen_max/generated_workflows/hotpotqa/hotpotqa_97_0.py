# Workflow ID: hotpotqa_97_0
# Benchmark: hotpotqa
# Data Indices: [122]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Identify and resolve key entities
        entity_instruction = """
        Identify all key entities mentioned in the question. Ensure you resolve any ambiguities 
        by cross-referencing the context documents. Provide a list of resolved entities.
        """
        resolved_entities = await self.generate(instruction=entity_instruction, context=self.problem_text)

        # Step 2: Select relevant documents for each entity
        doc_selection_instruction = f"""
        Based on the resolved entities ({resolved_entities}), identify and extract the portions 
        of the context documents that mention these entities. Focus only on sentences or paragraphs 
        that provide meaningful information about the entities.
        """
        relevant_docs = await self.generate(instruction=doc_selection_instruction, context=self.problem_text)

        # Step 3: Summarize relevant document portions
        summary_instruction = """
        Summarize the extracted portions of the documents into concise statements. 
        Ensure the summaries retain all critical information about the entities.
        """
        summaries = await asyncio.gather(
            *[self.summarize(instruction=summary_instruction, context=doc) for doc in relevant_docs.split("\n\n")]
        )

        # Step 4: Build the reasoning chain
        reasoning_instruction = f"""
        Using the summaries of the relevant documents ({summaries}), construct a reasoning chain 
        that connects the entities mentioned in the question. Explicitly state how the facts 
        from different documents are linked to form a coherent answer.
        """
        reasoning_chain = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 5: Extract and refine the final answer
        answer_instruction = """
        Based on the reasoning chain, extract the final answer to the question. Ensure the answer 
        is precise and directly addresses the question. If the answer is yes/no, provide a clear 
        justification for your conclusion.
        """
        raw_answer = await self.generate(instruction=answer_instruction, context=reasoning_chain)

        refinement_instruction = """
        Refine the raw answer for clarity, correctness, and conciseness. Ensure the final output 
        is well-formatted and easy to understand.
        """
        final_answer = await self.revise(instruction=refinement_instruction, context=raw_answer)

        return final_answer