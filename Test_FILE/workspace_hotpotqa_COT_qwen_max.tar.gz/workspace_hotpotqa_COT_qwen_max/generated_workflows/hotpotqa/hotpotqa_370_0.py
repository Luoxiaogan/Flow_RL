# Workflow ID: hotpotqa_370_0
# Benchmark: hotpotqa
# Data Indices: [156]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract Key Entities from the Question
        extract_entities_instruction = """
        Identify all key entities mentioned in the question. These could include names of people, organizations, places, or specific terms.
        Ensure you capture all possible variations or synonyms that might appear in the documents.
        """
        entities = await self.generate(instruction=extract_entities_instruction, context=self.problem_text)

        # Step 2: Select Relevant Documents
        select_documents_instruction = f"""
        Given the following entities: {entities}
        Match these entities with the content of the provided documents to determine which documents are relevant to answering the question.
        Return a list of document indices or titles that contain information related to these entities.
        """
        relevant_docs = await self.generate(instruction=select_documents_instruction, context=self.problem_text)

        # Step 3: Build Reasoning Chain
        build_reasoning_instruction = f"""
        Using the relevant documents identified: {relevant_docs}
        Construct a reasoning chain that connects the entities across these documents to answer the question.
        Ensure that each step in the chain is logically connected and explicitly stated.
        """
        reasoning_chain = await self.generate(instruction=build_reasoning_instruction, context=self.problem_text)

        # Step 4: Refine Reasoning Chain
        refine_reasoning_instruction = f"""
        Review the following reasoning chain: {reasoning_chain}
        Identify any gaps or ambiguities in the logic and refine the chain to ensure clarity and correctness.
        """
        refined_reasoning = await self.revise(instruction=refine_reasoning_instruction, context=reasoning_chain)

        # Step 5: Extract Final Answer
        extract_answer_instruction = f"""
        Based on the refined reasoning chain: {refined_reasoning}
        Extract the precise answer to the question. Ensure the answer is concise and directly addresses the question.
        """
        final_answer = await self.generate(instruction=extract_answer_instruction, context=self.problem_text)

        return final_answer