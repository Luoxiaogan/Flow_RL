# Workflow ID: hotpotqa_302_0
# Benchmark: hotpotqa
# Data Indices: [269]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Identify key entities and relevant documents
        entity_identification = await self.generate(
            instruction="Identify all key entities mentioned in the question. "
                        "Then, scan the provided documents to find which ones mention these entities. "
                        "Return a list of relevant documents along with the entities they mention.",
            context=self.problem_text
        )

        # Step 2: Extract specific facts about the entities
        fact_extraction = await self.generate(
            instruction=f"Using the identified entities and relevant documents from the previous step ({entity_identification}), "
                        "extract specific facts about each entity. Focus on whether the entities are described as 'film directors' or have similar roles. "
                        "Return the extracted facts in a structured format.",
            context=self.problem_text
        )

        # Step 3: Build reasoning chains to connect the facts
        reasoning_chain = await self.generate(
            instruction=f"Based on the extracted facts ({fact_extraction}), build a reasoning chain to answer the question. "
                        "For example, confirm whether both entities are described as 'film directors' in their respective documents. "
                        "Provide a clear justification for the conclusion.",
            context=self.problem_text
        )

        # Step 4: Synthesize the final answer
        final_answer = await self.revise(
            instruction="Refine the reasoning chain into a concise answer. "
                        "If both entities are confirmed as 'film directors', the answer is 'Yes'. Otherwise, it is 'No'. "
                        "Ensure the answer is precise and directly addresses the question.",
            context=reasoning_chain
        )

        return final_answer