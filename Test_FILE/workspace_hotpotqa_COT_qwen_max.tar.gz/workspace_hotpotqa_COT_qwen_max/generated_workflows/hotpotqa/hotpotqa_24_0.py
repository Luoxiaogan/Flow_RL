# Workflow ID: hotpotqa_24_0
# Benchmark: hotpotqa
# Data Indices: [52]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract entities from the question
        entity_extraction_instruction = """
        Identify all named entities mentioned in the question. These could include locations, organizations, people, or other specific terms. 
        Return the entities as a comma-separated list.
        """
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Find relevant documents for each entity
        entity_contexts = []
        extract_context_instruction = f"""
        For each entity in the list: {entities}, find all sentences or paragraphs in the provided documents that mention the entity. 
        Return the extracted contexts as a single string, clearly separating information for each entity.
        """
        entity_contexts.append(await self.generate(instruction=extract_context_instruction, context=self.problem_text))

        # Step 3: Construct reasoning chains
        reasoning_instruction = f"""
        Analyze the extracted contexts for the entities: {entities}. 
        Identify how these entities are related based on the information provided. 
        Construct a reasoning chain that connects the entities and explains their relationship.
        """
        reasoning_chain = await self.generate(instruction=reasoning_instruction, context="\n".join(entity_contexts))

        # Step 4: Synthesize the answer
        synthesis_instruction = f"""
        Based on the reasoning chain: {reasoning_chain}, synthesize a concise answer to the question. 
        Ensure the answer is precise and directly addresses the question.
        """
        answer = await self.generate(instruction=synthesis_instruction, context=self.problem_text)

        # Step 5: Validate and refine the answer
        validation_instruction = f"""
        Review the synthesized answer: {answer} against the original documents and reasoning chain. 
        Ensure the answer is accurate and complete. If necessary, refine the answer.
        """
        refined_answer = await self.revise(instruction=validation_instruction, context=answer)

        return refined_answer