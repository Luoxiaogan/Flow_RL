# Workflow ID: hotpotqa_358_0
# Benchmark: hotpotqa
# Data Indices: [70]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Analyze documents for relevance
        relevance_analysis = await self.generate(
            instruction="Analyze all provided documents and determine which ones are relevant to the question. "
                        "Focus on entities, relationships, and facts mentioned in the question. "
                        "Provide a list of relevant documents along with brief explanations of their relevance.",
            context=self.problem_text
        )

        # Step 2: Identify bridge entities and relationships
        entity_mapping = await self.generate(
            instruction=f"Using the relevance analysis: {relevance_analysis}, "
                        "identify all entities mentioned in the question and map their occurrences across the relevant documents. "
                        "Highlight any shared entities or relationships that connect multiple documents.",
            context=self.problem_text
        )

        # Step 3: Construct reasoning chains
        reasoning_chain = await self.generate(
            instruction=f"Based on the entity mapping: {entity_mapping}, "
                        "construct a reasoning chain that connects the information across documents. "
                        "Explain how the facts from one document lead to or support facts in another document. "
                        "Ensure the chain directly addresses the question.",
            context=self.problem_text
        )

        # Step 4: Extract and refine the final answer
        raw_answer = await self.generate(
            instruction=f"From the reasoning chain: {reasoning_chain}, "
                        "extract the final answer to the question. Ensure the answer is precise and supported by specific sentences from the documents.",
            context=self.problem_text
        )

        refined_answer = await self.revise(
            instruction="Refine the extracted answer to ensure it is accurate, concise, and directly addresses the question.",
            context=raw_answer
        )

        return refined_answer