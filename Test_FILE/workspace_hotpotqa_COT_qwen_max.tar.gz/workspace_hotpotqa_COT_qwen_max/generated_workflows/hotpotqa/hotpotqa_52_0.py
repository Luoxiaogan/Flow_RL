# Workflow ID: hotpotqa_52_0
# Benchmark: hotpotqa
# Data Indices: [197]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Analyze the question and extract key entities
        entity_extraction = await self.generate(
            instruction="Extract all key entities (e.g., locations, names) and the type of information being asked from the question. "
                        "Provide them in a structured format.",
            context=self.problem_text
        )

        # Step 2: Identify relevant documents based on extracted entities
        document_selection = await self.generate(
            instruction=f"Based on the extracted entities: {entity_extraction}, identify which documents contain relevant information. "
                        "List the document names or indices.",
            context=self.problem_text
        )

        # Step 3: Extract relevant facts from the selected documents
        fact_extraction_tasks = []
        for doc in document_selection.split(","):
            task = self.generate(
                instruction=f"Extract all relevant facts about the entities {entity_extraction} from the document: {doc.strip()}. "
                            "Focus on relationships, shared properties, or connections between entities.",
                context=self.problem_text
            )
            fact_extraction_tasks.append(task)
        extracted_facts = await asyncio.gather(*fact_extraction_tasks)

        # Step 4: Perform cross-document reasoning to connect facts
        reasoning_result = await self.ensemble(
            instruction="Analyze the provided facts and identify how they connect across documents. "
                        "Focus on shared properties, relationships, or logical chains that lead to the answer.",
            contexts=extracted_facts
        )

        # Step 5: Synthesize the final answer
        synthesized_answer = await self.generate(
            instruction=f"Based on the reasoning result: {reasoning_result}, synthesize a concise and precise answer to the question. "
                        "Ensure the answer directly addresses the question and is supported by the facts.",
            context=self.problem_text
        )

        # Step 6: Validate and refine the answer
        refined_answer = await self.revise(
            instruction="Review the synthesized answer and ensure it is accurate, concise, and fully supported by the extracted facts. "
                        "Refine the answer if necessary.",
            context=synthesized_answer
        )

        return refined_answer