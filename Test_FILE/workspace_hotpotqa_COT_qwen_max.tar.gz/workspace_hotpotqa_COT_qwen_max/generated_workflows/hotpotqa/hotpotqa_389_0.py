# Workflow ID: hotpotqa_389_0
# Benchmark: hotpotqa
# Data Indices: [253]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify entities and select relevant documents
        entities_instruction = (
            "Identify all named entities mentioned in the question. "
            "For each entity, find the documents that contain relevant information about them. "
            "Return a mapping of entities to their corresponding documents."
        )
        entities_and_documents = await self.generate(instruction=entities_instruction, context=self.problem_text)

        # Step 2: Extract facts about the entities in parallel
        async def extract_facts(entity):
            fact_extraction_instruction = (
                f"Extract all relevant facts about {entity} from the provided documents. "
                "Focus on facts that help answer the question. "
                "Include specific details such as birth years, achievements, or other identifying information."
            )
            return await self.generate(instruction=fact_extraction_instruction, context=entities_and_documents)

        entities = ["Thomaz Koch", "Peter Fleming"]  # Dynamically extracted from Step 1 in a real implementation
        fact_extraction_tasks = [extract_facts(entity) for entity in entities]
        extracted_facts = await asyncio.gather(*fact_extraction_tasks)

        # Step 3: Compare the extracted facts to determine the answer
        comparison_instruction = (
            "Compare the extracted facts about the entities to answer the question. "
            "Provide a clear reasoning chain that connects the facts to the final answer. "
            "Ensure the answer is concise and directly addresses the question."
        )
        final_answer = await self.ensemble(instruction=comparison_instruction, contexts=extracted_facts)

        # Step 4: Refine the final answer if necessary
        refinement_instruction = (
            "Review the final answer and ensure it is precise, well-supported, and directly addresses the question. "
            "Make any necessary refinements to improve clarity and correctness."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        return refined_answer