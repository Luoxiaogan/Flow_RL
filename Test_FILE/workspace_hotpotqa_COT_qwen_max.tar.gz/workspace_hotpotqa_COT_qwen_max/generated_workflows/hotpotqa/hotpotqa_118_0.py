# Workflow ID: hotpotqa_118_0
# Benchmark: hotpotqa
# Data Indices: [21]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify the question type and key entities
        question_analysis = await self.generate(
            instruction="Analyze the question to determine its type (e.g., bridge, comparison, compositional) "
                        "and extract all key entities mentioned in the question. Provide the entities as a list.",
            context=self.problem_text
        )

        # Step 2: Search relevant documents for key entities
        search_results = await asyncio.gather(
            *[self.generate(
                instruction=f"Search the provided documents for mentions of the entity '{entity}'. "
                            "Return the document excerpts that contain the entity.",
                context=self.problem_text
            ) for entity in eval(question_analysis)]  # Assuming question_analysis returns a JSON-like list
        )

        # Step 3: Extract supporting facts from the search results
        supporting_facts = await asyncio.gather(
            *[self.generate(
                instruction=f"Extract specific sentences or facts from the following excerpt that are relevant "
                            f"to the question: {excerpt}. Focus on facts that help answer the question.",
                context=excerpt
            ) for excerpt in search_results]
        )

        # Step 4: Resolve entities across documents if needed
        resolved_entities = await asyncio.gather(
            *[self.generate(
                instruction=f"Resolve the entity '{entity}' by finding additional information about it in the documents. "
                            "If the entity is a location, find its full address or geographical details.",
                context=self.problem_text
            ) for entity in eval(question_analysis)]
        )

        # Step 5: Synthesize the final answer
        final_answer = await self.ensemble(
            instruction="Combine the extracted supporting facts and resolved entities to construct the final answer. "
                        "Ensure the reasoning chain is complete and accurate.",
            contexts=supporting_facts + resolved_entities
        )

        return final_answer