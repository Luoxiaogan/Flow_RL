# Workflow ID: hotpotqa_380_0
# Benchmark: hotpotqa
# Data Indices: [270]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract the name of the actress who played Jackie Cook
        actress_extraction_instruction = (
            "Identify the name of the actress who played the character Jackie Cook on the television series 'Veronica Mars'. "
            "Ensure that the answer is precise and includes only the full name of the actress."
        )
        actress_name = await self.generate(instruction=actress_extraction_instruction, context=self.problem_text)

        # Step 2: Find the 2009 drama film starring the actress and its director
        film_and_director_instruction = (
            f"Find the 2009 drama film starring {actress_name} and identify its director. "
            "Provide the name of the director as the final output. Ensure the answer is concise and accurate."
        )
        director_name = await self.generate(instruction=film_and_director_instruction, context=self.problem_text)

        # Step 3: Synthesize the final answer using Ensemble
        final_instruction = (
            "Combine the results of the previous steps to provide the final answer. "
            "The answer should be the name of the director of the 2009 drama film starring the actress who played Jackie Cook."
        )
        final_answer = await self.ensemble(instruction=final_instruction, contexts=[actress_name, director_name])

        return final_answer