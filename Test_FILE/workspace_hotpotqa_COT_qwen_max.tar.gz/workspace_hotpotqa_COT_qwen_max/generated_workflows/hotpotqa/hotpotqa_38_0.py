# Workflow ID: hotpotqa_38_0
# Benchmark: hotpotqa
# Data Indices: [275]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Identify entities and select relevant documents
        entity_identification_instruction = """
        Identify the main entities mentioned in the question. 
        For each entity, determine which documents are relevant by analyzing the context documents.
        Return the entities and their corresponding relevant document indices.
        """
        entity_doc_mapping = await self.generate(instruction=entity_identification_instruction, context=self.problem_text)

        # Parse the entity-document mapping (assuming JSON-like structure)
        import json
        entity_doc_mapping = json.loads(entity_doc_mapping)

        # Step 2: Extract facts about each entity in parallel
        async def extract_facts(entity, doc_indices):
            extraction_instruction = f"""
            Extract all relevant information about '{entity}' from the following documents: {doc_indices}.
            Focus on facts that help determine whether '{entity}' is a rock band.
            """
            return await self.generate(instruction=extraction_instruction, context=self.problem_text)

        extraction_tasks = [extract_facts(entity, docs) for entity, docs in entity_doc_mapping.items()]
        extracted_facts = await asyncio.gather(*extraction_tasks)

        # Step 3: Revise and refine the extracted facts
        async def refine_facts(facts):
            refinement_instruction = """
            Review the extracted facts and remove any irrelevant or redundant information.
            Ensure the remaining facts are accurate and directly related to the entity being a rock band.
            """
            return await self.revise(instruction=refinement_instruction, context=facts)

        refinement_tasks = [refine_facts(facts) for facts in extracted_facts]
        refined_facts = await asyncio.gather(*refinement_tasks)

        # Step 4: Summarize the refined facts
        async def summarize_facts(facts):
            summarization_instruction = """
            Summarize the key information about the entity being a rock band.
            Include only the most critical facts that directly answer the question.
            """
            return await self.summarize(instruction=summarization_instruction, context=facts)

        summarization_tasks = [summarize_facts(facts) for facts in refined_facts]
        summarized_facts = await asyncio.gather(*summarization_tasks)

        # Step 5: Ensemble the summarized facts to generate the final answer
        ensemble_instruction = """
        Compare the summarized facts about each entity.
        Determine whether both entities are rock bands based on the provided information.
        Generate a clear and concise answer to the question.
        """
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=summarized_facts)

        return final_answer