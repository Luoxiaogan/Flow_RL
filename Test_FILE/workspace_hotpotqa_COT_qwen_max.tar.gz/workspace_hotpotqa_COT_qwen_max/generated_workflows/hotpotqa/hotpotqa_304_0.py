# Workflow ID: hotpotqa_304_0
# Benchmark: hotpotqa
# Data Indices: [381]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Analyze the question to identify entities and reasoning type
        question_analysis = await self.generate(
            instruction="""Analyze the question to identify key entities and classify the reasoning type. 
            The reasoning type can be one of the following: bridge, comparison, or compositional. 
            Extract all relevant entities mentioned in the question and provide a brief explanation of their roles. 
            Ensure the output is structured as JSON with keys: 'entities', 'reasoning_type', and 'explanation'.""",
            context=self.problem_text
        )

        # Step 2: Select relevant documents based on identified entities
        document_selection = await self.ensemble(
            instruction=f"""Evaluate all provided documents to determine which ones contain information 
            about the following entities: {question_analysis['entities']}. 
            Return the indices or titles of the most relevant documents. 
            Ensure the output is structured as a list of document identifiers.""",
            contexts=[self.problem_text]  # Pass all documents as context
        )

        # Step 3: Resolve entities across selected documents
        entity_resolution = await self.generate(
            instruction=f"""Resolve the following entities across the selected documents: {question_analysis['entities']}. 
            Identify shared entities or bridging facts that connect the documents. 
            Provide a detailed explanation of how the entities are related across documents. 
            Ensure the output is structured as JSON with keys: 'resolved_entities' and 'explanation'.""",
            context=document_selection
        )

        # Step 4: Construct the reasoning chain
        reasoning_chain = await self.generate(
            instruction=f"""Construct a reasoning chain based on the resolved entities: {entity_resolution['resolved_entities']}. 
            Combine facts from the selected documents to logically connect the information and derive the answer. 
            Ensure the output is structured as a step-by-step explanation leading to the final answer.""",
            context=entity_resolution['explanation']
        )

        # Step 5: Extract the precise answer span
        answer_extraction = await self.summarize(
            instruction="""Extract the precise answer span from the reasoning chain. 
            Ensure the response is concise and directly addresses the question. 
            If the answer is a yes/no question, provide the appropriate response.""",
            context=reasoning_chain
        )

        return answer_extraction