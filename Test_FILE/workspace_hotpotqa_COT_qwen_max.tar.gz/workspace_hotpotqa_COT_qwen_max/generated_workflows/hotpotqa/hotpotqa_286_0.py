# Workflow ID: hotpotqa_286_0
# Benchmark: hotpotqa
# Data Indices: [118]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Identify relevant documents
        document_identification_instruction = """
        Analyze all provided documents to identify which ones mention the key entities or phrases from the question. 
        Specifically, look for mentions of "Diya Aur Baati Hum" and any information about it being replaced by another show. 
        Return a list of relevant document indices or names.
        """
        relevant_documents = await self.generate(
            instruction=document_identification_instruction,
            context=self.problem_text
        )

        # Step 2: Extract key facts about the replacement show
        fact_extraction_instruction = f"""
        From the relevant documents identified ({relevant_documents}), extract specific facts about the show that replaced "Diya Aur Baati Hum." 
        Focus on finding the name of the replacement show and any information about what inspired it. 
        Return the extracted facts in a structured format.
        """
        extracted_facts = await self.generate(
            instruction=fact_extraction_instruction,
            context=self.problem_text
        )

        # Step 3: Build reasoning chains to connect the facts
        reasoning_chain_instruction = f"""
        Using the extracted facts ({extracted_facts}), build a logical reasoning chain that connects "Diya Aur Baati Hum" to the show that replaced it and identifies the film that inspired the replacement show. 
        Ensure the reasoning is clear and supported by evidence from the documents.
        """
        reasoning_chain = await self.ensemble(
            instruction=reasoning_chain_instruction,
            contexts=[relevant_documents, extracted_facts]
        )

        # Step 4: Refine and validate the reasoning chain
        refinement_instruction = f"""
        Review the reasoning chain ({reasoning_chain}) for accuracy and completeness. 
        Ensure that the final answer is precise, directly addresses the question, and is supported by the context. 
        Correct any errors or ambiguities.
        """
        refined_answer = await self.revise(
            instruction=refinement_instruction,
            context=reasoning_chain
        )

        # Step 5: Output the final answer
        return refined_answer