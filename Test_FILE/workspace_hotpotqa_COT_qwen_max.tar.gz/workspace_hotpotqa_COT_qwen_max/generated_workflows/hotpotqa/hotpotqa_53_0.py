# Workflow ID: hotpotqa_53_0
# Benchmark: hotpotqa
# Data Indices: [298]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Analyze the question to identify entities and reasoning type
        question_analysis = await self.generate(
            instruction="Analyze the question to identify key entities and determine the reasoning type (bridge, comparison, compositional, etc.). "
                        "Provide a detailed breakdown of the entities and their roles in the question.",
            context=self.problem_text
        )

        # Step 2: Identify relevant documents based on extracted entities
        document_relevance_tasks = [
            self.generate(
                instruction=f"Based on the extracted entities ({question_analysis}), determine if this document is relevant to the question. "
                            "Provide a justification for your decision.",
                context=document
            )
            for document in self.config['documents']  # Assuming documents are provided in the config
        ]
        document_relevances = await asyncio.gather(*document_relevance_tasks)

        # Step 3: Identify the bridge entity (if applicable)
        bridge_entity = await self.generate(
            instruction=f"Using the extracted entities ({question_analysis}) and the relevant documents ({document_relevances}), "
                        "identify the bridge entity that connects multiple documents. Explain why this entity is crucial for answering the question.",
            context=self.problem_text
        )

        # Step 4: Construct the reasoning chain
        reasoning_chain = await self.generate(
            instruction=f"Using the bridge entity ({bridge_entity}) and the relevant documents ({document_relevances}), "
                        "construct a detailed reasoning chain that connects the question to the answer. "
                        "Explicitly mention how each document contributes to the chain.",
            context=self.problem_text
        )

        # Step 5: Extract the final answer
        final_answer = await self.summarize(
            instruction="Condense the reasoning chain into a concise answer that directly addresses the question. "
                        "Ensure the answer is precise and factually accurate.",
            context=reasoning_chain
        )

        return final_answer