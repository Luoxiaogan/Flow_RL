# Workflow ID: hotpotqa_284_0
# Benchmark: hotpotqa
# Data Indices: [288]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract key entities and relationships from the question
        entity_extraction = await self.generate(
            instruction="Identify the key entities and relationships mentioned in the question. "
                        "Focus on named entities (e.g., locations, organizations, people) and their connections. "
                        "Output the results in a structured format.",
            context=self.problem_text
        )

        # Step 2: Select relevant documents based on extracted entities
        document_selection = await self.generate(
            instruction=f"Given the extracted entities: {entity_extraction}, "
                        "identify which documents contain relevant information. "
                        "Focus on documents that mention these entities and their relationships. "
                        "Output a list of relevant document indices or titles.",
            context=self.problem_text
        )

        # Step 3: Identify the bridge entity connecting documents
        bridge_entity = await self.generate(
            instruction=f"Using the relevant documents: {document_selection}, "
                        "identify the 'bridge entity' that connects the documents. "
                        "This could be a person, organization, or event that links the entities mentioned in the question. "
                        "Explain why this entity is significant.",
            context=self.problem_text
        )

        # Step 4: Construct the reasoning chain
        reasoning_chain = await self.generate(
            instruction=f"Given the bridge entity: {bridge_entity}, "
                        "construct a reasoning chain that connects the entities mentioned in the question. "
                        "Use facts from the relevant documents to build this chain step by step. "
                        "Ensure the chain logically leads to the answer.",
            context=self.problem_text
        )

        # Step 5: Extract the precise answer span
        answer_extraction = await self.summarize(
            instruction="From the constructed reasoning chain, extract the precise answer span. "
                        "This should be a short text span (entity name, phrase, or brief factual response).",
            context=reasoning_chain
        )

        # Step 6: Validate and refine the reasoning chain and answer
        refined_answer = await self.revise(
            instruction="Critique the reasoning chain and answer for accuracy and completeness. "
                        "Refine the answer if necessary, ensuring it directly addresses the question.",
            context=answer_extraction
        )

        return refined_answer