# Workflow ID: hotpotqa_240_0
# Benchmark: hotpotqa
# Data Indices: [66]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract information about "Fir" and "Asystasia"
        instruction_extract = """
        Extract all mentions of the specified entity from the context documents. 
        Include descriptions, classifications, and any taxonomic details (e.g., family, genus, species). 
        Focus on evidence that indicates whether the entity is a coniferous tree. 
        Format the output as a concise summary of the relevant information.
        """
        fir_extraction = self.generate(
            instruction=f"Entity: Fir\n{instruction_extract}",
            context=self.problem_text
        )
        asystasia_extraction = self.generate(
            instruction=f"Entity: Asystasia\n{instruction_extract}",
            context=self.problem_text
        )

        # Run extractions in parallel
        fir_info, asystasia_info = await asyncio.gather(fir_extraction, asystasia_extraction)

        # Step 2: Analyze whether each entity is a coniferous tree
        instruction_analyze = """
        Based on the provided information, determine whether the entity is classified as a coniferous tree. 
        Coniferous trees are gymnosperms, typically evergreen, and belong to families such as Pinaceae or Cupressaceae. 
        Provide a clear yes/no answer with supporting evidence.
        """
        fir_analysis = self.generate(
            instruction=f"Entity: Fir\nInformation: {fir_info}\n{instruction_analyze}",
            context=self.problem_text
        )
        asystasia_analysis = self.generate(
            instruction=f"Entity: Asystasia\nInformation: {asystasia_info}\n{instruction_analyze}",
            context=self.problem_text
        )

        # Run analyses in parallel
        fir_result, asystasia_result = await asyncio.gather(fir_analysis, asystasia_analysis)

        # Step 3: Compare results and synthesize the final answer
        instruction_compare = """
        Compare the results for the two entities. 
        If both are classified as coniferous trees, return 'Yes'. 
        If either or both are not coniferous trees, return 'No'. 
        Include a brief explanation for the answer.
        """
        final_answer = await self.ensemble(
            instruction=instruction_compare,
            contexts=[fir_result, asystasia_result]
        )

        return final_answer