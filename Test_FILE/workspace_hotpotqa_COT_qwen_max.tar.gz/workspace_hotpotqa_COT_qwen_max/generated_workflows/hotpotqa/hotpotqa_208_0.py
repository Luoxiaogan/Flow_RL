# Workflow ID: hotpotqa_208_0
# Benchmark: hotpotqa
# Data Indices: [259]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Analyze the question to identify key entities and requirements
        question_analysis = await self.generate(
            instruction="Analyze the question to identify the main entities and what is being asked. "
                        "Focus on identifying the target entity (e.g., 101st Jäger Division) and the specific information required (e.g., dissolution year).",
            context=self.problem_text
        )

        # Step 2: Extract relevant information from documents
        document_extraction_tasks = [
            self.generate(
                instruction=f"Extract information about the 101st Jäger Division and its connection to the German Army. "
                            f"Focus on key facts such as its formation, role, and any related historical events.",
                context=doc
            )
            for doc in ["Document 9", "Document 7"]  # Example relevant documents
        ]
        extracted_facts = await asyncio.gather(*document_extraction_tasks)

        # Step 3: Build reasoning chains across documents
        reasoning_chain = await self.generate(
            instruction=f"Using the following extracted facts, build a reasoning chain to answer the question:\n"
                        f"Facts from Document 9: {extracted_facts[0]}\n"
                        f"Facts from Document 7: {extracted_facts[1]}\n"
                        f"Connect the 101st Jäger Division to the German Army and determine the dissolution year of the German Army.",
            context=self.problem_text
        )

        # Step 4: Refine the reasoning and validate the answer
        refined_reasoning = await self.revise(
            instruction="Review the reasoning chain and ensure it is logically sound and fully supported by the extracted facts. "
                        "Refine any unclear or unsupported steps.",
            context=reasoning_chain
        )

        # Step 5: Synthesize the final answer
        final_answer = await self.ensemble(
            instruction="Synthesize the refined reasoning into a concise and accurate answer to the question. "
                        "Ensure the answer is directly supported by the reasoning chain.",
            contexts=[refined_reasoning, self.problem_text]
        )

        return final_answer