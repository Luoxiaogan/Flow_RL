# Workflow ID: hotpotqa_128_0
# Benchmark: hotpotqa
# Data Indices: [12]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Analyze the question to extract entities and reasoning type
        question_analysis = await self.generate(
            instruction="Analyze the question to determine the type of reasoning required (e.g., bridge, comparison, compositional). Identify key entities mentioned in the question and their relationships. Provide a detailed breakdown of the reasoning steps needed to answer the question.",
            context=self.problem_text
        )

        # Step 2: Identify relevant documents based on extracted entities
        document_selection = await self.generate(
            instruction=f"Based on the following analysis: {question_analysis}, identify which documents are relevant to answering the question. For each document, explain why it is relevant and how it connects to the entities mentioned in the question.",
            context=self.problem_text
        )

        # Step 3: Perform cross-document reasoning to connect entities
        reasoning_paths = await asyncio.gather(
            self.generate(
                instruction=f"Using the following document selection: {document_selection}, build reasoning chains that connect the entities across documents. Focus on finding 'bridge entities' that link different documents.",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"Alternative approach: Using the following document selection: {document_selection}, compare properties of entities mentioned in the question to derive the answer.",
                context=self.problem_text
            )
        )
        best_reasoning_path = await self.ensemble(
            instruction="Evaluate the following reasoning paths and select the most coherent and accurate one. Provide a justification for your choice.",
            contexts=reasoning_paths
        )

        # Step 4: Extract the final answer from the relevant documents
        answer_extraction = await self.summarize(
            instruction=f"Based on the following reasoning path: {best_reasoning_path}, extract the final answer from the relevant documents. Ensure the answer is concise and directly addresses the question.",
            context=self.problem_text
        )

        # Step 5: Refine the answer for precision and formatting
        refined_answer = await self.revise(
            instruction="Critique and refine the following answer to ensure it is precise, well-formatted, and adheres to the expected answer type (e.g., short text span, yes/no).",
            context=answer_extraction
        )

        return refined_answer