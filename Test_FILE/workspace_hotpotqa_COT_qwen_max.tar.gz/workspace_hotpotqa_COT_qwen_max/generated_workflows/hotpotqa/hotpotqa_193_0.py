# Workflow ID: hotpotqa_193_0
# Benchmark: hotpotqa
# Data Indices: [15]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key entities from the question
        entity_extraction_instruction = """
        Analyze the question and extract all key entities, such as names of people, movies, companies, or other relevant terms. 
        Provide the extracted entities in a concise list format. Ensure that the extraction is comprehensive and includes all 
        potential bridge entities that could connect multiple documents.
        """
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Identify relevant documents for each entity
        document_selection_instruction = f"""
        Given the extracted entities: {entities}, identify which documents in the provided context contain information 
        about these entities. For each entity, list the document titles and briefly explain why they are relevant. 
        Focus on finding documents that could potentially connect the entities through shared information.
        """
        relevant_documents = await self.generate(instruction=document_selection_instruction, context=self.problem_text)

        # Step 3: Find the bridge entity connecting the documents
        bridge_entity_instruction = f"""
        Using the relevant documents identified: {relevant_documents}, find the bridge entity that connects the 
        information across documents. This could be a person, place, or concept mentioned in both contexts. 
        Provide a detailed explanation of how the bridge entity links the documents and supports the answer.
        """
        bridge_entity = await self.generate(instruction=bridge_entity_instruction, context=self.problem_text)

        # Step 4: Synthesize the final answer
        answer_synthesis_instruction = f"""
        Based on the bridge entity identified: {bridge_entity}, synthesize the final answer to the question. 
        Ensure the answer is precise, matches the required format (e.g., a person's name), and is supported by 
        specific sentences from the documents. If the answer requires additional reasoning (e.g., comparisons), 
        include those steps explicitly.
        """
        final_answer = await self.generate(instruction=answer_synthesis_instruction, context=self.problem_text)

        return final_answer