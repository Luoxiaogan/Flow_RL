# Workflow ID: hotpotqa_159_0
# Benchmark: hotpotqa
# Data Indices: [393]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information for both entities
        extract_instruction = """Extract all sentences or paragraphs that mention the specified entity. Focus on details related to their political roles, achievements, and influence."""
        extraction_tasks = [
            self.generate(instruction=extract_instruction.replace("specified entity", "Francis Bacon"), context=self.problem_text),
            self.generate(instruction=extract_instruction.replace("specified entity", "Thomas Bushell"), context=self.problem_text)
        ]
        bacon_context, bushell_context = await asyncio.gather(*extraction_tasks)

        # Step 2: Summarize political power for each entity
        summarize_instruction = """Summarize the political power and influence of the specified entity based on the provided context. Highlight key roles, achievements, and any indicators of authority."""
        summary_tasks = [
            self.summarize(instruction=summarize_instruction.replace("specified entity", "Francis Bacon"), context=bacon_context),
            self.summarize(instruction=summarize_instruction.replace("specified entity", "Thomas Bushell"), context=bushell_context)
        ]
        bacon_summary, bushell_summary = await asyncio.gather(*summary_tasks)

        # Step 3: Compare the summaries to determine who had more political power
        compare_instruction = """Compare the political power and influence of Francis Bacon and Thomas Bushell based on their summaries. Provide a clear and concise conclusion."""
        comparison_result = await self.ensemble(instruction=compare_instruction, contexts=[bacon_summary, bushell_summary])

        # Step 4: Refine the final answer
        refine_instruction = """Critique and refine the provided comparison result. Ensure the answer is precise, supported by evidence, and formatted appropriately."""
        final_answer = await self.revise(instruction=refine_instruction, context=comparison_result)

        return final_answer