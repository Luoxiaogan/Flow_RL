# Workflow ID: hotpotqa_136_0
# Benchmark: hotpotqa
# Data Indices: [344]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract key entities and analyze the question
        entity_extraction_instruction = """
        Identify all key entities mentioned in the question. 
        Determine the type of question (e.g., bridge, comparison, compositional).
        Provide a brief analysis of what the question is asking.
        """
        entity_analysis = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Summarize each document to facilitate selection
        summary_tasks = []
        for i in range(1, 11):  # Assuming we have 10 documents based on the example
            doc_summary_instruction = f"""
            Summarize Document {i} focusing on the key entities identified earlier: {entity_analysis}.
            Highlight any mentions of these entities and their relationships.
            """
            summary_task = self.summarize(instruction=doc_summary_instruction, context=f"Document {i}: [Insert document text here]")
            summary_tasks.append(summary_task)

        document_summaries = await asyncio.gather(*summary_tasks)

        # Step 3: Select relevant documents using ensemble
        doc_selection_instruction = f"""
        Evaluate the summaries provided and select the documents that contain information about the key entities: {entity_analysis}.
        Prioritize documents that mention multiple key entities or provide connecting information.
        """
        relevant_documents = await self.ensemble(instruction=doc_selection_instruction, contexts=document_summaries)

        # Step 4: Perform cross-document inference
        reasoning_instruction = f"""
        Using the selected documents: {relevant_documents}, build a reasoning chain that connects the key entities.
        Follow the logical steps required to answer the question based on the information provided in the documents.
        """
        reasoning_chain = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 5: Synthesize and refine the final answer
        answer_refinement_instruction = f"""
        Refine the following reasoning chain into a concise and accurate answer to the original question: {reasoning_chain}.
        Ensure the answer directly addresses the question and is supported by the information in the documents.
        """
        final_answer = await self.revise(instruction=answer_refinement_instruction, context=reasoning_chain)

        return final_answer