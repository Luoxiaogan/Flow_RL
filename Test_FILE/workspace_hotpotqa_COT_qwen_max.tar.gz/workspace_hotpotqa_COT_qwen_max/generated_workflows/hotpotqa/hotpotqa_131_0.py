# Workflow ID: hotpotqa_131_0
# Benchmark: hotpotqa
# Data Indices: [26]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract entities and identify relevant documents
        entity_extraction_instruction = """
        Analyze the problem text to identify all key entities (e.g., people, albums, tours) and their relationships.
        Determine which documents in the context are relevant to the question.
        Format your response as a list of entities and their associated documents.
        """
        entities_and_documents = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Detect bridge entities
        bridge_entity_instruction = f"""
        Based on the extracted entities and their relationships ({entities_and_documents}), identify the bridge entity
        that connects information across multiple documents. Explain why this entity is significant for answering the question.
        """
        bridge_entity = await self.generate(instruction=bridge_entity_instruction, context=self.problem_text)

        # Step 3: Construct reasoning chain
        reasoning_chain_instruction = f"""
        Using the bridge entity ({bridge_entity}), construct a reasoning chain that connects the question to the answer.
        Synthesize information from multiple documents to explain how the answer can be derived.
        """
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 4: Parallel execution for document synthesis
        synthesis_instruction = f"""
        Given the reasoning chain ({reasoning_chain}), synthesize information from the relevant documents
        to provide a coherent and accurate explanation of the answer.
        """
        synthesis_results = await asyncio.gather(
            self.generate(instruction=synthesis_instruction, context=self.problem_text),
            self.generate(instruction=synthesis_instruction, context=self.problem_text)
        )
        synthesized_answer = await self.ensemble(instruction="Select the most coherent and accurate synthesis.", contexts=synthesis_results)

        # Step 5: Extract final answer
        answer_extraction_instruction = f"""
        Based on the synthesized information ({synthesized_answer}), extract the precise answer span that directly answers the question.
        Ensure the answer is concise and formatted appropriately.
        """
        final_answer = await self.summarize(instruction=answer_extraction_instruction, context=self.problem_text)

        return final_answer