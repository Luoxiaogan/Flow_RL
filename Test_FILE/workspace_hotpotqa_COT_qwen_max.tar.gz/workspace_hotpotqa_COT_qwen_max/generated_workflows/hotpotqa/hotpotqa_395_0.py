# Workflow ID: hotpotqa_395_0
# Benchmark: hotpotqa
# Data Indices: [260]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract mentions of "Creation Records" and related entities
        instruction_extract_creation = """
        Identify all mentions of "Creation Records" in the provided documents. 
        For each mention, extract the associated entities and their relationships with Creation Records. 
        Provide the output as a structured summary, including document references.
        """
        creation_mentions = await self.generate(
            instruction=instruction_extract_creation,
            context=self.problem_text
        )

        # Step 2: Parallel extraction for each entity
        instruction_extract_entity = """
        Given the extracted mentions of "Creation Records", analyze the relationship between {entity} and Creation Records. 
        Summarize the evidence from the documents that supports or refutes this relationship. 
        Ensure the summary is concise and includes specific document references.
        """

        tasks = [
            self.generate(
                instruction=instruction_extract_entity.format(entity="The Jesus and Mary Chain"),
                context=creation_mentions
            ),
            self.generate(
                instruction=instruction_extract_entity.format(entity="Jonathan Davis"),
                context=creation_mentions
            )
        ]
        results = await asyncio.gather(*tasks)

        # Step 3: Compare the summaries and decide the answer
        instruction_compare_entities = """
        Compare the summaries of the relationships between "The Jesus and Mary Chain" and "Jonathan Davis" with Creation Records. 
        Based on the evidence provided, determine which entity has a documented connection to Creation Records. 
        Provide the final answer in the format: "[Entity] signed with Creation Records."
        """
        final_answer = await self.ensemble(
            instruction=instruction_compare_entities,
            contexts=results
        )

        return final_answer