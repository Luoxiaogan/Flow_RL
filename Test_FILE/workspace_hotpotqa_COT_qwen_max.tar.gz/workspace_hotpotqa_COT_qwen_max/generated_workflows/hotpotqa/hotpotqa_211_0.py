# Workflow ID: hotpotqa_211_0
# Benchmark: hotpotqa
# Data Indices: [119]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify key entities and parse the question
        entity_identification_instruction = (
            "Analyze the question and identify all key entities and relationships. "
            "Focus on the main subject, the action or property being questioned, "
            "and any secondary entities mentioned. Provide a clear breakdown of these components."
        )
        entities = await self.generate(instruction=entity_identification_instruction, context=self.problem_text)

        # Step 2: Extract relevant information from documents
        extraction_instruction = (
            f"Based on the identified entities: {entities}, locate and extract relevant sentences or paragraphs "
            "from the provided documents. Ensure that the extracted information includes direct references "
            "to the entities and their relationships."
        )
        document_extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 3: Build reasoning chains and synthesize information
        reasoning_instruction = (
            "Using the extracted information, construct a logical chain that connects the entities and answers the question. "
            "If there are multiple possible interpretations or conflicting statements, evaluate them critically. "
            "Ensure the reasoning process is explicit and traceable."
        )
        reasoning_results = await asyncio.gather(
            self.generate(instruction=reasoning_instruction, context=document_extraction),
            self.generate(instruction=reasoning_instruction, context=document_extraction)  # Parallel reasoning paths
        )
        synthesized_answer = await self.ensemble(
            instruction="Synthesize the reasoning results into a coherent and accurate response. "
                        "Resolve any conflicts or ambiguities by prioritizing evidence from the documents.",
            contexts=reasoning_results
        )

        # Step 4: Refine the final answer
        refinement_instruction = (
            "Critique and refine the synthesized answer to ensure it is concise, accurate, and directly addresses the question. "
            "Remove any unnecessary details while preserving the core information."
        )
        final_answer = await self.revise(instruction=refinement_instruction, context=synthesized_answer)

        return final_answer