# Workflow ID: hotpotqa_382_0
# Benchmark: hotpotqa
# Data Indices: [138]

class Workflow:
    def __init__(self, config, problem) -> None:
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract Key Entities from the Question
        entity_extraction_instruction = """
        Identify all key entities mentioned in the question. 
        These could be names of people, places, organizations, or any other significant nouns.
        Ensure you capture all entities that might help in locating relevant documents.
        """
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Select Relevant Documents Based on Entities
        document_selection_instruction = f"""
        Given the following entities: {entities}
        Identify which documents contain information about these entities.
        Focus on selecting documents that are most likely to contribute to answering the question.
        """
        relevant_documents = await self.generate(instruction=document_selection_instruction, context=self.problem_text)

        # Step 3: Summarize Relevant Documents
        summarization_instruction = """
        Summarize the content of each selected document, focusing on information related to the identified entities.
        Highlight any connections between the entities and other facts within the document.
        """
        summaries = await asyncio.gather(
            *[self.summarize(instruction=summarization_instruction, context=doc) for doc in relevant_documents.split("\n")]
        )

        # Step 4: Construct Reasoning Chains
        reasoning_instruction = f"""
        Using the summaries provided, construct reasoning chains that connect the entities: {entities}.
        Look for shared entities, facts, or logical connections between the documents.
        The goal is to build a coherent path that leads to the answer.
        """
        reasoning_chains = await asyncio.gather(
            *[self.generate(instruction=reasoning_instruction, context=summary) for summary in summaries]
        )

        # Step 5: Ensemble the Best Reasoning Path
        ensemble_instruction = """
        Evaluate the provided reasoning chains and select the most coherent and complete chain that answers the question.
        Consider factors such as logical consistency, factual accuracy, and relevance to the original question.
        """
        best_reasoning_chain = await self.ensemble(instruction=ensemble_instruction, contexts=reasoning_chains)

        # Step 6: Extract and Refine the Final Answer
        answer_extraction_instruction = f"""
        Based on the reasoning chain: {best_reasoning_chain}
        Extract the precise answer to the original question.
        Ensure the answer is concise and directly addresses the question.
        """
        raw_answer = await self.generate(instruction=answer_extraction_instruction, context=self.problem_text)

        refinement_instruction = """
        Refine the extracted answer to ensure it is accurate, concise, and fully supported by the reasoning chain.
        Correct any ambiguities or inconsistencies.
        """
        final_answer = await self.revise(instruction=refinement_instruction, context=raw_answer)

        return final_answer