# Workflow ID: hotpotqa_110_0
# Benchmark: hotpotqa
# Data Indices: [141]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Identify relevant documents and entities
        entity_extraction_instruction = (
            "Identify all entities and their key attributes mentioned in the documents "
            "that are relevant to answering the question. Focus on numerical values, "
            "properties, and relationships between entities."
        )
        entity_facts = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Detect reasoning type and extract relevant facts
        reasoning_detection_instruction = (
            f"Based on the extracted entities and facts: {entity_facts}, determine the type of reasoning required. "
            "If the question involves comparing properties, extract the specific properties to be compared. "
            "If it involves bridging information, identify the bridge entities."
        )
        reasoning_type_and_facts = await self.generate(instruction=reasoning_detection_instruction, context=self.problem_text)

        # Step 3: Summarize key facts for comparison
        summarization_instruction = (
            f"Condense the following information into key facts relevant to the question: {reasoning_type_and_facts}. "
            "Focus on extracting numerical values, properties, and relationships needed for comparison."
        )
        summarized_facts = await self.summarize(instruction=summarization_instruction, context=reasoning_type_and_facts)

        # Step 4: Compare and synthesize facts to derive the answer
        comparison_instruction = (
            f"Compare the following facts: {summarized_facts} to answer the question. "
            "Ensure the reasoning chain is explicit and the final answer is precise."
        )
        answers = [
            await self.generate(instruction=comparison_instruction, context=self.problem_text),
            await self.revise(instruction="Refine the previous answer to ensure accuracy and clarity.", context=answers[0])
        ]

        # Step 5: Ensemble to finalize the best answer
        ensemble_instruction = (
            "Evaluate the following candidate answers and select the most accurate and concise one. "
            "Ensure the reasoning chain is clear and the answer directly addresses the question."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=answers)

        return final_answer