# Workflow ID: hotpotqa_156_0
# Benchmark: hotpotqa
# Data Indices: [91]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract the question and documents
        question = self.problem_text.split("**QUESTION:**")[1].strip()
        documents = self.problem_text.split("**CONTEXT DOCUMENTS:**")[1].split("**QUESTION:**")[0].strip().split("\n\n")

        # Step 2: Score document relevance in parallel
        async def score_relevance(doc):
            return await self.generate(
                instruction=f"Score the relevance of this document to the question: '{question}'. "
                            f"Provide a score from 0 to 10 and explain your reasoning.",
                context=doc
            )

        relevance_scores = await asyncio.gather(*[score_relevance(doc) for doc in documents])

        # Step 3: Select top relevant documents
        relevant_docs = [doc for doc, score in zip(documents, relevance_scores) if "Score: " in score and int(score.split("Score: ")[1][0]) > 5]

        # Step 4: Extract bridge entities
        async def extract_entities(doc):
            return await self.generate(
                instruction=f"Identify key entities in this document that could serve as bridge entities "
                            f"for answering the question: '{question}'. List them and explain why they are relevant.",
                context=doc
            )

        entity_extractions = await asyncio.gather(*[extract_entities(doc) for doc in relevant_docs])
        bridge_entities = "\n".join(entity_extractions)

        # Step 5: Construct reasoning chain
        reasoning_chain = await self.ensemble(
            instruction=f"Synthesize information from the following documents and bridge entities to "
                        f"construct a reasoning chain that answers the question: '{question}'. "
                        f"Ensure all relevant facts are included and logically connected.",
            contexts=relevant_docs + [bridge_entities]
        )

        # Step 6: Generate the final answer
        final_answer = await self.summarize(
            instruction=f"Based on the reasoning chain provided, generate a concise and precise answer "
                        f"to the question: '{question}'. Ensure the answer is fully supported by the reasoning chain.",
            context=reasoning_chain
        )

        return final_answer