# Workflow ID: hotpotqa_355_0
# Benchmark: hotpotqa
# Data Indices: [62]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio
        
        # Step 1: Analyze the question to identify key entities and terms
        question_analysis = await self.generate(
            instruction="Analyze the question to identify key entities, terms, and the type of information required. "
                        "Provide a detailed breakdown of the question's components.",
            context=self.problem_text
        )
        
        # Step 2: Select relevant documents based on the identified entities
        document_selection_prompts = [
            f"Given the question analysis: {question_analysis}, determine if this document is relevant to the question. "
            f"Document content: {doc}"
            for doc in self.config['context_documents']
        ]
        relevance_results = await asyncio.gather(
            *[self.generate(instruction=prompt, context="") for prompt in document_selection_prompts]
        )
        relevant_docs = [doc for doc, result in zip(self.config['context_documents'], relevance_results) if "relevant" in result.lower()]
        
        # Step 3: Extract and synthesize information from relevant documents
        synthesis_prompts = [
            f"Extract key information from this document that connects to the question analysis: {question_analysis}. "
            f"Document content: {doc}"
            for doc in relevant_docs
        ]
        extracted_info = await asyncio.gather(
            *[self.generate(instruction=prompt, context="") for prompt in synthesis_prompts]
        )
        
        # Step 4: Build the reasoning chain using Ensemble
        reasoning_chain = await self.ensemble(
            instruction="Combine the extracted information into a coherent reasoning chain that answers the question. "
                        "Ensure the chain explicitly connects entities and concepts across documents.",
            contexts=extracted_info
        )
        
        # Step 5: Summarize the reasoning chain into a concise answer
        final_answer = await self.summarize(
            instruction="Condense the reasoning chain into a concise answer that directly addresses the question.",
            context=reasoning_chain
        )
        
        return final_answer