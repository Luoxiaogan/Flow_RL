# Workflow ID: hotpotqa_58_0
# Benchmark: hotpotqa
# Data Indices: [36]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Initial Analysis - Identify reasoning type and key entities
        initial_analysis = await self.generate(
            instruction="Analyze the question to determine the reasoning type (e.g., bridge, comparison, compositional) "
                        "and identify the key entities mentioned. Provide a detailed breakdown of the entities and their roles.",
            context=self.problem_text
        )

        # Step 2: Entity Resolution - Extract and match entities across documents
        entities_extraction_tasks = [
            self.generate(
                instruction=f"Extract all mentions of the entities identified in the question ({initial_analysis}) "
                            f"from this document. Include contextual information for each mention.",
                context=doc
            ) for doc in self.config['documents']  # Assuming documents are provided in the config
        ]
        entities_results = await asyncio.gather(*entities_extraction_tasks)

        resolved_entities = await self.ensemble(
            instruction="Resolve ambiguities and match entity mentions across the provided documents. "
                        "Ensure consistency in entity references.",
            contexts=entities_results
        )

        # Step 3: Fact Extraction - Extract relevant facts about the entities
        fact_extraction_tasks = [
            self.generate(
                instruction=f"Extract all relevant facts about the resolved entities ({resolved_entities}) "
                            f"from this document. Focus on facts that could contribute to answering the question.",
                context=doc
            ) for doc in self.config['documents']
        ]
        facts_results = await asyncio.gather(*fact_extraction_tasks)

        # Step 4: Reasoning Chain Construction - Synthesize facts into a coherent chain
        reasoning_chain = await self.ensemble(
            instruction="Synthesize the extracted facts into a coherent reasoning chain that connects information "
                        "across documents. Ensure logical flow and relevance to the question.",
            contexts=facts_results
        )

        # Step 5: Answer Extraction - Extract the precise answer span
        final_answer = await self.generate(
            instruction=f"Based on the constructed reasoning chain ({reasoning_chain}), extract the precise answer "
                        f"span that directly answers the question. Ensure the answer is concise and accurate.",
            context=self.problem_text
        )

        return final_answer