# Workflow ID: hotpotqa_374_0
# Benchmark: hotpotqa
# Data Indices: [168]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Identify key entities and classify the question type
        entity_extraction = await self.generate(
            instruction="Extract all key entities (e.g., names, titles, dates) and classify the reasoning type of the question (bridge, comparison, compositional).",
            context=self.problem_text
        )

        # Step 2: Select relevant documents based on the extracted entities
        doc_selection = await self.ensemble(
            instruction=f"Given these extracted entities: {entity_extraction}, evaluate the relevance of each document to the question.",
            contexts=[f"Document {i+1}: {doc}" for i, doc in enumerate(self.config['documents'])]
        )

        # Step 3: Summarize relevant information from selected documents
        relevant_docs = [doc for doc in self.config['documents'] if doc in doc_selection]
        summaries = await asyncio.gather(
            *[self.summarize(
                instruction="Summarize the key information related to the extracted entities and their relationships.",
                context=doc
            ) for doc in relevant_docs]
        )

        # Step 4: Construct the reasoning chain
        reasoning_chain = await self.generate(
            instruction=f"Using the following summaries: {summaries}, construct a logical reasoning chain that connects the entities to answer the question.",
            context=self.problem_text
        )

        # Step 5: Refine the reasoning chain and extract the final answer
        refined_reasoning = await self.revise(
            instruction="Refine the reasoning chain to ensure logical consistency and clarity. Extract the precise answer span from the chain.",
            context=reasoning_chain
        )

        return refined_reasoning