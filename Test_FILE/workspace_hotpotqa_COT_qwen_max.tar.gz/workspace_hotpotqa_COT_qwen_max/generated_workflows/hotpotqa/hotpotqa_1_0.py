# Workflow ID: hotpotqa_1_0
# Benchmark: hotpotqa
# Data Indices: [252]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract the entities from the question
        entity_extraction_instruction = (
            "Identify the two entities being compared in the question. "
            "Return them as a JSON object with keys 'entity1' and 'entity2'."
        )
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)
        entities_dict = json.loads(entities)  # Parse the JSON response
        entity1 = entities_dict["entity1"]
        entity2 = entities_dict["entity2"]

        # Step 2: Extract birth dates for both entities in parallel
        async def extract_birth_date(entity):
            instruction = (
                f"Find the birth date of {entity} from the provided context documents. "
                "If the exact date is not available, provide the earliest possible year. "
                "Return the result in the format YYYY-MM-DD or YYYY if only the year is known."
            )
            return await self.generate(instruction=instruction, context=self.problem_text)

        birth_dates = await asyncio.gather(
            extract_birth_date(entity1),
            extract_birth_date(entity2)
        )
        birth_date_entity1, birth_date_entity2 = birth_dates

        # Step 3: Compare the birth dates
        comparison_instruction = (
            f"Compare the birth dates of {entity1} ({birth_date_entity1}) and {entity2} ({birth_date_entity2}). "
            "Determine who was born first and provide the answer in the format: '[Entity] was born first.'"
        )
        result = await self.ensemble(instruction=comparison_instruction, contexts=[birth_date_entity1, birth_date_entity2])

        # Step 4: Return the final answer
        return result