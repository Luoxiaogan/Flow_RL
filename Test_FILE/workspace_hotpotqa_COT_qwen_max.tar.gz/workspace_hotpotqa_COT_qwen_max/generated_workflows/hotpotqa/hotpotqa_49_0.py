# Workflow ID: hotpotqa_49_0
# Benchmark: hotpotqa
# Data Indices: [206]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract information about Nyree Kindred
        instruction_nyree = (
            "Identify all information about Nyree Kindred from the provided documents. "
            "Focus on her participation in the Paralympic Games, including the type of events and medals won. "
            "Provide a concise summary of her involvement in the Paralympic Games."
        )
        nyree_info = await self.generate(instruction=instruction_nyree, context=self.problem_text)

        # Step 2: Extract information about the governing body of the Paralympic Games
        instruction_governing_body = (
            "Identify the organization or body that governs the Paralympic Games. "
            "Provide details about its role, responsibilities, and any other relevant information. "
            "Ensure the response is clear and focused on governance."
        )
        governing_body_info = await self.generate(instruction=instruction_governing_body, context=self.problem_text)

        # Step 3: Synthesize the final answer using Ensemble
        instruction_synthesis = (
            "Combine the following two pieces of information to answer the question: "
            "1. Nyree Kindred's participation in the Paralympic Games. "
            "2. The governing body of the Paralympic Games. "
            "Determine which organization governs the Paralympic Games that Nyree Kindred has competed in. "
            "Provide a clear and concise answer."
        )
        final_answer = await self.ensemble(
            instruction=instruction_synthesis,
            contexts=[nyree_info, governing_body_info]
        )

        # Step 4: Refine the final answer if necessary
        instruction_refinement = (
            "Review the following answer for clarity, accuracy, and completeness. "
            "Ensure it directly addresses the question and is phrased appropriately. "
            "Make any necessary improvements."
        )
        refined_answer = await self.revise(instruction=instruction_refinement, context=final_answer)

        return refined_answer