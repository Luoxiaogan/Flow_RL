# Workflow ID: hotpotqa_268_0
# Benchmark: hotpotqa
# Data Indices: [200]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key entities from the question
        entity_extraction_instruction = """
        Extract all named entities (people, places, organizations) mentioned in the question. 
        Focus on entities that are likely to appear in the context documents. 
        Provide the results in a structured format: {entity_type: entity_name}.
        """
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Identify relevant documents containing the extracted entities
        doc_selection_instruction = f"""
        Search through the provided context documents to find which ones mention the following entities: {entities}.
        Return the indices or titles of the relevant documents.
        """
        relevant_docs = await self.generate(instruction=doc_selection_instruction, context=self.problem_text)

        # Step 3: Identify the bridge entity connecting the question to the answer
        bridge_entity_instruction = f"""
        Analyze the relevant documents ({relevant_docs}) to identify the "bridge entity" that connects the question to the answer.
        The bridge entity is typically a shared concept, place, or person mentioned in both the question and the documents.
        """
        bridge_entity = await self.generate(instruction=bridge_entity_instruction, context=self.problem_text)

        # Step 4: Construct the reasoning chain to find the answer
        reasoning_chain_instruction = f"""
        Using the bridge entity ({bridge_entity}), analyze the relevant documents to construct a reasoning chain that leads to the answer.
        Specifically, identify the ethnic group associated with the bridge entity in the context of the question.
        """
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 5: Extract the precise answer span
        answer_extraction_instruction = f"""
        Based on the reasoning chain ({reasoning_chain}), extract the precise answer span from the relevant documents.
        Ensure the answer directly addresses the question: "Nnorom Azuonye was born in a state whose inhabitants are mostly which ethnic group?"
        """
        answer_span = await self.summarize(instruction=answer_extraction_instruction, context=self.problem_text)

        # Final Output
        return answer_span