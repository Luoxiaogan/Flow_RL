# Workflow ID: hotpotqa_43_0
# Benchmark: hotpotqa
# Data Indices: [321]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key entities and reasoning type from the question
        entity_extraction_instruction = """
        Analyze the question to identify key entities, the reasoning type (bridge, comparison, etc.), 
        and any specific constraints. Provide a structured output with the following sections:
        - Key Entities: List all named entities mentioned in the question.
        - Reasoning Type: Specify whether the question requires bridging, comparison, or compositional reasoning.
        - Constraints: Note any specific requirements (e.g., date/time, yes/no answer).
        """
        question_analysis = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Score document relevance and extract supporting facts
        document_relevance_instruction = f"""
        Given the key entities and reasoning type from the question analysis ({question_analysis}),
        evaluate the relevance of each document to the question. For each document:
        - Identify supporting facts related to the key entities.
        - Score the document's relevance on a scale of 1 to 10.
        - Extract sentences containing relevant information.
        Return a list of documents with their relevance scores and supporting facts.
        """
        documents = self.problem_text.split("\n\n")  # Assuming documents are separated by double newlines
        relevance_tasks = [self.generate(instruction=document_relevance_instruction, context=doc) for doc in documents]
        relevance_results = await asyncio.gather(*relevance_tasks)

        # Step 3: Resolve entities and build reasoning chains
        entity_resolution_instruction = f"""
        Using the question analysis ({question_analysis}) and document relevance results ({relevance_results}),
        identify shared entities or relationships across documents. Resolve ambiguities in entity mentions
        and construct a logical chain connecting the extracted facts to answer the question.
        """
        reasoning_chain = await self.ensemble(instruction=entity_resolution_instruction, contexts=relevance_results)

        # Step 4: Refine and summarize the reasoning chain
        refinement_instruction = """
        Review the reasoning chain for coherence, completeness, and accuracy. Refine any ambiguous or incomplete
        parts to ensure the chain logically leads to the answer.
        """
        refined_chain = await self.revise(instruction=refinement_instruction, context=reasoning_chain)

        summary_instruction = """
        Condense the refined reasoning chain into a concise answer. Ensure the output adheres to the required
        format (short text span, yes/no, etc.) and directly addresses the question.
        """
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_chain)

        return final_answer