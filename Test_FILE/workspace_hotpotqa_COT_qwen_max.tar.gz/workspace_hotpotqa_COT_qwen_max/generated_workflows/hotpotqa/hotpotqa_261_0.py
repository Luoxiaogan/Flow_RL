# Workflow ID: hotpotqa_261_0
# Benchmark: hotpotqa
# Data Indices: [337]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract album information for Sunny Day Real Estate
        sunny_day_instruction = """
        Extract all album-related information for the band Sunny Day Real Estate from the provided context documents. 
        Include studio albums, live albums, and any other relevant releases. Ensure that the information is specific 
        to Sunny Day Real Estate and not confused with other bands or projects. Provide the results in a clear list format.
        """
        sunny_day_albums_raw = await self.generate(instruction=sunny_day_instruction, context=self.problem_text)

        # Step 2: Extract album information for Against Me!
        against_me_instruction = """
        Extract all album-related information for the band Against Me! from the provided context documents. 
        Include studio albums, live albums, and any other relevant releases. Ensure that the information is specific 
        to Against Me! and not confused with other bands or projects. Provide the results in a clear list format.
        """
        against_me_albums_raw = await self.generate(instruction=against_me_instruction, context=self.problem_text)

        # Step 3: Refine the extracted album lists
        refine_instruction = """
        Review the provided list of albums and ensure that each entry is accurate and correctly attributed to the respective band. 
        Remove any duplicates or irrelevant entries. The final output should be a refined list of albums.
        """
        sunny_day_albums_refined = await self.revise(instruction=refine_instruction, context=sunny_day_albums_raw)
        against_me_albums_refined = await self.revise(instruction=refine_instruction, context=against_me_albums_raw)

        # Step 4: Count the number of albums for each band
        sunny_day_count = len(sunny_day_albums_refined.split('\n'))
        against_me_count = len(against_me_albums_refined.split('\n'))

        # Step 5: Compare the counts and determine the final answer
        compare_instruction = f"""
        Compare the number of albums recorded by Sunny Day Real Estate and Against Me!. 
        Sunny Day Real Estate has recorded {sunny_day_count} albums, while Against Me! has recorded {against_me_count} albums. 
        Determine which band has recorded more albums and provide the final answer in a clear and concise format.
        """
        final_answer = await self.ensemble(instruction=compare_instruction, contexts=[sunny_day_albums_refined, against_me_albums_refined])

        return final_answer