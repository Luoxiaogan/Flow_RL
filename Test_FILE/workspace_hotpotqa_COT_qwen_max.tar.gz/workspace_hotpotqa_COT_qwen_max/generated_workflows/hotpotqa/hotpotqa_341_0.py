# Workflow ID: hotpotqa_341_0
# Benchmark: hotpotqa
# Data Indices: [392]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key entities and relationships
        entity_extraction_instruction = """
        Identify all key entities mentioned in the question and their relationships.
        Entities include but are not limited to: people, organizations, events, dates, locations.
        Relationships should describe how these entities are connected or related to each other.
        Format your response as a JSON object with keys 'entities' and 'relationships'.
        """
        entity_extraction = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Parse the extracted entities and relationships
        import json
        extracted_info = json.loads(entity_extraction)
        entities = extracted_info.get('entities', [])
        relationships = extracted_info.get('relationships', [])

        # Step 2: Identify relevant documents for each entity
        document_identification_tasks = []
        for entity in entities:
            document_instruction = f"""
            Given the entity '{entity}', identify which documents contain information about this entity.
            Return the document names or identifiers that are relevant to '{entity}'.
            """
            document_identification_tasks.append(self.generate(instruction=document_instruction, context=self.problem_text))

        # Execute document identification tasks in parallel
        relevant_documents = await asyncio.gather(*document_identification_tasks)

        # Step 3: Identify the bridge entity
        bridge_entity_instruction = f"""
        Based on the extracted entities {entities} and their relationships {relationships}, 
        identify the bridge entity that connects multiple documents.
        The bridge entity is typically a shared entity or concept that appears across different documents.
        If there are multiple potential bridge entities, list them all.
        """
        bridge_entities = await self.generate(instruction=bridge_entity_instruction, context=self.problem_text)

        # Step 4: Construct reasoning chains
        reasoning_chain_tasks = []
        for doc_set in relevant_documents:
            reasoning_instruction = f"""
            Summarize the key information from the following documents: {doc_set}.
            Focus on the entities {entities} and the relationships {relationships}.
            Highlight any information that helps connect these entities across documents.
            """
            reasoning_chain_tasks.append(self.summarize(instruction=reasoning_instruction, context=doc_set))

        # Execute reasoning chain tasks in parallel
        reasoning_chains = await asyncio.gather(*reasoning_chain_tasks)

        # Step 5: Extract the final answer
        answer_extraction_instruction = f"""
        Based on the reasoning chains {reasoning_chains}, extract the precise answer to the original question.
        Ensure the answer is a short text span, entity name, or brief factual response.
        If the question requires a yes/no answer, provide the appropriate response.
        """
        final_answer = await self.generate(instruction=answer_extraction_instruction, context="\n".join(reasoning_chains))

        return final_answer