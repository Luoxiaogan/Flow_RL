# Workflow ID: hotpotqa_184_0
# Benchmark: hotpotqa
# Data Indices: [48]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Identify entities and select relevant documents
        entities_instruction = """
        Identify all key entities mentioned in the question. 
        Then, determine which documents in the provided context are relevant to these entities.
        Return the list of relevant document names.
        """
        relevant_documents = await self.generate(
            instruction=entities_instruction,
            context=self.problem_text
        )

        # Step 2: Classify reasoning type
        reasoning_type_instruction = f"""
        Based on the question and the identified entities ({relevant_documents}), 
        classify the reasoning type as either 'bridge' or 'comparison'.
        Provide a brief explanation for your classification.
        """
        reasoning_type = await self.generate(
            instruction=reasoning_type_instruction,
            context=self.problem_text
        )

        # Step 3: Extract facts from relevant documents
        facts_extraction_instruction = f"""
        Extract all relevant facts from the documents listed in {relevant_documents}.
        For 'bridge' reasoning, focus on identifying the bridge entity that connects the documents.
        For 'comparison' reasoning, extract comparable properties (e.g., numerical values, dates).
        Organize the facts clearly and label them by document source.
        """
        facts_extraction_tasks = [
            self.generate(
                instruction=facts_extraction_instruction,
                context=self.problem_text
            )
            for _ in range(len(relevant_documents.split(",")))  # Parallel tasks for each document
        ]
        extracted_facts = await asyncio.gather(*facts_extraction_tasks)

        # Step 4: Synthesize the answer
        synthesis_instruction = f"""
        Based on the extracted facts ({extracted_facts}), synthesize the final answer to the question.
        For 'bridge' reasoning, connect the facts through the bridge entity.
        For 'comparison' reasoning, compare the extracted properties and provide the result.
        Ensure the answer is concise and directly addresses the question.
        """
        synthesized_answer = await self.generate(
            instruction=synthesis_instruction,
            context=self.problem_text
        )

        # Step 5: Validate and refine the answer
        validation_instruction = f"""
        Cross-check the synthesized answer ({synthesized_answer}) with the original documents.
        Identify any discrepancies or missing information.
        If necessary, refine the answer to ensure accuracy and completeness.
        """
        refined_answer = await self.revise(
            instruction=validation_instruction,
            context=self.problem_text
        )

        return refined_answer