# Workflow ID: hotpotqa_345_0
# Benchmark: hotpotqa
# Data Indices: [18]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Parse the question to identify entities and reasoning type
        question_analysis = await self.generate(
            instruction="Analyze the question to identify key entities, relationships, and the type of reasoning required (e.g., bridge, comparison, compositional).",
            context=self.problem_text
        )

        # Step 2: Identify relevant documents
        relevant_docs_task = self.generate(
            instruction=f"Based on the identified entities ({question_analysis}), determine which documents contain relevant information.",
            context=self.problem_text
        )

        # Step 3: Resolve entities across documents
        entity_resolution_task = self.generate(
            instruction=f"Match entities across the identified documents to ensure consistency. Use the analysis ({question_analysis}) as a guide.",
            context=self.problem_text
        )

        # Execute Steps 2 and 3 in parallel
        relevant_docs, entity_resolution = await asyncio.gather(relevant_docs_task, entity_resolution_task)

        # Step 4: Construct the reasoning chain
        reasoning_chain = await self.generate(
            instruction=f"Using the resolved entities ({entity_resolution}) and relevant documents ({relevant_docs}), construct a reasoning chain to connect the information.",
            context=self.problem_text
        )

        # Step 5: Extract the final answer
        final_answer = await self.generate(
            instruction=f"From the reasoning chain ({reasoning_chain}), extract the precise answer span that directly answers the question.",
            context=self.problem_text
        )

        return final_answer