# Workflow ID: hotpotqa_252_0
# Benchmark: hotpotqa
# Data Indices: [306]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract entities and relationships from the question
        entity_extraction_instruction = """
        Identify all key entities and relationships mentioned in the question. 
        Focus on entities like organizations, people, locations, and their roles or attributes. 
        Provide the output as a list of entities and their relationships.
        """
        entities_and_relationships = await self.generate(
            instruction=entity_extraction_instruction,
            context=self.problem_text
        )

        # Step 2: Extract mentions of entities from each document
        document_extraction_instruction = f"""
        For each document, extract mentions of the following entities and their relationships: {entities_and_relationships}.
        Include the document title and the extracted information in the output.
        """
        document_extractions = await asyncio.gather(
            *[self.generate(instruction=document_extraction_instruction, context=doc) for doc in self.config["context_documents"]]
        )

        # Step 3: Identify the bridge entity
        bridge_entity_instruction = """
        Analyze the extracted information from all documents to identify the bridge entity that connects the key entities mentioned in the question.
        The bridge entity is typically a person, organization, or concept that appears in multiple documents and establishes a relationship between them.
        """
        bridge_entity = await self.ensemble(
            instruction=bridge_entity_instruction,
            contexts=document_extractions
        )

        # Step 4: Construct the reasoning chain
        reasoning_chain_instruction = f"""
        Using the identified bridge entity ({bridge_entity}), construct a reasoning chain that connects the key entities mentioned in the question.
        Ensure the chain includes all relevant facts and relationships extracted from the documents.
        """
        reasoning_chain = await self.revise(
            instruction=reasoning_chain_instruction,
            context="\n".join(document_extractions)
        )

        # Step 5: Extract the final answer
        answer_extraction_instruction = """
        From the constructed reasoning chain, extract the precise answer to the question.
        The answer should be a short text span, such as an entity name, phrase, or factual response.
        """
        final_answer = await self.summarize(
            instruction=answer_extraction_instruction,
            context=reasoning_chain
        )

        return final_answer