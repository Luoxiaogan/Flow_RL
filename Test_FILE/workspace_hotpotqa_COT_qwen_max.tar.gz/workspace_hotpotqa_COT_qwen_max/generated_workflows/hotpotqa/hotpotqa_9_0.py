# Workflow ID: hotpotqa_9_0
# Benchmark: hotpotqa
# Data Indices: [365]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Analyze the question and identify key entities
        analysis_instruction = (
            "Analyze the question to identify key entities and the type of reasoning required. "
            "Determine whether the question is a bridge, comparison, or compositional question. "
            "Extract the main entities and their relationships."
        )
        question_analysis = await self.generate(instruction=analysis_instruction, context=self.problem_text)

        # Step 2: Select relevant documents
        document_selection_instruction = (
            f"Based on the extracted entities and relationships: {question_analysis}, "
            "evaluate which documents are most relevant to answering the question. "
            "Rank the documents by relevance and provide reasoning for each ranking."
        )
        # Assume `documents` is a list of all context documents
        documents = [f"Document {i+1}" for i in range(10)]  # Replace with actual document texts
        relevant_documents = await self.ensemble(instruction=document_selection_instruction, contexts=documents)

        # Step 3: Construct the reasoning chain
        reasoning_chain_instruction = (
            f"Using the selected documents: {relevant_documents}, "
            "construct a reasoning chain that connects the entities mentioned in the question. "
            "Explicitly describe the relationships between entities and how they lead to the answer."
        )
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 4: Extract the answer
        answer_extraction_instruction = (
            f"From the reasoning chain: {reasoning_chain}, "
            "extract the precise answer span that directly answers the question. "
            "Ensure the answer is concise and matches the expected format (e.g., date, entity name)."
        )
        answer = await self.summarize(instruction=answer_extraction_instruction, context=reasoning_chain)

        # Step 5: Validate and refine the answer
        validation_instruction = (
            f"Validate the extracted answer: {answer} against the original question. "
            "Refine the answer if necessary to ensure accuracy and completeness."
        )
        refined_answer = await self.revise(instruction=validation_instruction, context=answer)

        return refined_answer