# Workflow ID: hotpotqa_235_0
# Benchmark: hotpotqa
# Data Indices: [311]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract information about Luke Pasqualino's involvement in "Our Girl"
        luke_instruction = """
        Identify all mentions of Luke Pasqualino in the context of the show "Our Girl". 
        Extract the timeline of his involvement, including when he joined the show and any significant events related to his role.
        """
        luke_extraction_task = self.generate(instruction=luke_instruction, context=self.problem_text)

        # Step 2: Extract information about Lacey Turner's involvement in "Our Girl"
        lacey_instruction = """
        Identify all mentions of Lacey Turner in the context of the show "Our Girl". 
        Extract the timeline of her involvement, including when she joined the show and any significant events related to her role.
        """
        lacey_extraction_task = self.generate(instruction=lacey_instruction, context=self.problem_text)

        # Step 3: Run both extractions in parallel
        luke_info, lacey_info = await asyncio.gather(luke_extraction_task, lacey_extraction_task)

        # Step 4: Compare the timelines to determine who acted first
        comparison_instruction = f"""
        Compare the timelines of Luke Pasqualino and Lacey Turner in the show "Our Girl".
        Based on the following extracted information:
        - Luke Pasqualino: {luke_info}
        - Lacey Turner: {lacey_info}
        Determine who acted first in the show and provide a clear conclusion.
        """
        comparison_result = await self.generate(instruction=comparison_instruction, context=self.problem_text)

        # Step 5: Summarize the final answer
        summary_instruction = """
        Summarize the conclusion about who acted first in the show "Our Girl" between Luke Pasqualino and Lacey Turner.
        Ensure the answer is concise and directly addresses the question.
        """
        final_answer = await self.summarize(instruction=summary_instruction, context=comparison_result)

        return final_answer