# Workflow ID: hotpotqa_6_0
# Benchmark: hotpotqa
# Data Indices: [86]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key entities from the question
        entity_extraction_instruction = """
        Analyze the question and identify all key entities mentioned. These could include names of people, organizations, locations, or other relevant terms. 
        Focus on entities that are likely to appear in the provided context documents. Return the entities as a comma-separated list.
        """
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Identify relevant documents and bridge entity
        bridge_entity_instruction = f"""
        Using the extracted entities ({entities}), analyze the provided context documents to find the bridge entity that connects them. 
        For example, if the question asks about a person and a hotel, identify the specific hotel associated with the person. 
        Return the bridge entity as a single phrase or sentence.
        """
        bridge_entity = await self.generate(instruction=bridge_entity_instruction, context=self.problem_text)

        # Step 3: Extract location information for the bridge entity
        location_extraction_instruction = f"""
        Based on the identified bridge entity ({bridge_entity}), locate the document(s) that mention it. 
        Extract any information related to the location of the bridge entity, such as city, country, or specific address. 
        Return the location as a concise phrase or sentence.
        """
        location = await self.generate(instruction=location_extraction_instruction, context=self.problem_text)

        # Step 4: Synthesize the final answer
        synthesis_instruction = f"""
        Combine the extracted information to answer the question. The key entities are ({entities}), the bridge entity is ({bridge_entity}), and its location is ({location}). 
        Formulate a concise and precise answer to the question based on this information.
        """
        final_answer = await self.generate(instruction=synthesis_instruction, context=self.problem_text)

        return final_answer