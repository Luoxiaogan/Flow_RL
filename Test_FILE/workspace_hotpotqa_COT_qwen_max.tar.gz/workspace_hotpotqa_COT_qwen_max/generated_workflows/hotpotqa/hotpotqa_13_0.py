# Workflow ID: hotpotqa_13_0
# Benchmark: hotpotqa
# Data Indices: [56]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Analyze the question to identify key entities and constraints
        question_analysis = await self.generate(
            instruction="Analyze the question to identify key entities, constraints, and relationships. "
                        "Extract specific terms such as names, dates, locations, and other relevant details. "
                        "Provide a structured summary of the question's requirements.",
            context=self.problem_text
        )

        # Step 2: Summarize each document to identify relevance to the question
        documents = [
            "Document 1: On Returning (1977–1979)",
            "Document 2: The Shizit",
            "Document 3: Act Three (G4 album)",
            "Document 4: Dare (album)",
            "Document 5: While She Sleeps",
            "Document 6: The Human League",
            "Document 7: Mission Mountain Wood Band",
            "Document 8: Third Album",
            "Document 9: List of songs recorded by My Bloody Valentine",
            "Document 10: Zatopeks"
        ]

        summaries = await asyncio.gather(
            *[self.summarize(
                instruction=f"Summarize this document and highlight any information related to the entities "
                            f"and constraints identified in the question analysis: {question_analysis}.",
                context=doc
            ) for doc in documents]
        )

        # Step 3: Identify the most relevant documents using Ensemble
        relevant_documents = await self.ensemble(
            instruction="Evaluate the summaries of the provided documents and select those that are most relevant "
                        "to answering the question. Consider how well each document aligns with the entities and "
                        "constraints identified in the question analysis.",
            contexts=summaries
        )

        # Step 4: Construct the reasoning chain to connect entities across documents
        reasoning_chain = await self.generate(
            instruction=f"Using the relevant documents ({relevant_documents}), construct a reasoning chain that "
                        f"connects the entities and constraints identified in the question analysis. "
                        f"Ensure that the chain logically leads to the answer.",
            context=self.problem_text
        )

        # Step 5: Extract and refine the final answer
        raw_answer = await self.generate(
            instruction=f"Based on the reasoning chain ({reasoning_chain}), extract the precise answer to the question. "
                        f"Ensure the answer is concise and directly addresses the question.",
            context=self.problem_text
        )
        refined_answer = await self.revise(
            instruction="Refine the extracted answer for clarity, correctness, and conciseness. "
                        "Ensure it is formatted appropriately and matches the expected answer type.",
            context=raw_answer
        )

        return refined_answer