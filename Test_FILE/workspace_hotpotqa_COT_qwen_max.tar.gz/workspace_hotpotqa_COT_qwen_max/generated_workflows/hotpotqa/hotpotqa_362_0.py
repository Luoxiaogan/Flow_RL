# Workflow ID: hotpotqa_362_0
# Benchmark: hotpotqa
# Data Indices: [183]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Parse the question to identify key entities and reasoning type
        question_analysis = await self.generate(
            instruction="Analyze the question to identify key entities (e.g., names, dates, titles) and determine the type of reasoning required (bridge, comparison, etc.). Provide a structured output with entities and reasoning type.",
            context=self.problem_text
        )

        # Step 2: Summarize each document to assess relevance
        documents = [f"Document {i+1}" for i in range(10)]  # Assuming 10 documents
        summaries = await asyncio.gather(
            *[self.summarize(
                instruction=f"Summarize the key points of this document, focusing on entities and facts that might relate to the question: {question_analysis}",
                context=f"Document {i+1}"
            ) for i in range(10)]
        )

        # Step 3: Filter relevant documents based on summaries
        relevant_documents = await self.ensemble(
            instruction=f"Based on the summaries provided, select the documents most relevant to answering the question. Consider the entities and reasoning type identified earlier: {question_analysis}",
            contexts=summaries
        )

        # Step 4: Build reasoning chains across relevant documents
        reasoning_chain = await self.generate(
            instruction=f"Using the relevant documents identified ({relevant_documents}), build a reasoning chain that connects the entities and facts to answer the question. Ensure the chain explicitly links all necessary information.",
            context=self.problem_text
        )

        # Step 5: Extract the precise answer span
        answer_extraction = await self.generate(
            instruction=f"From the reasoning chain provided ({reasoning_chain}), extract the precise answer span that directly addresses the question. Ensure the answer is concise and accurate.",
            context=self.problem_text
        )

        # Step 6: Refine the answer for clarity and correctness
        refined_answer = await self.revise(
            instruction=f"Refine the extracted answer ({answer_extraction}) to ensure it is clear, concise, and properly formatted. Validate that it directly answers the question.",
            context=self.problem_text
        )

        return refined_answer