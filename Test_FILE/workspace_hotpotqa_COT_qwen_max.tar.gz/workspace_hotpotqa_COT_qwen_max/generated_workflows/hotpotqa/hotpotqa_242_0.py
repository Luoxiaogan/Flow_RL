# Workflow ID: hotpotqa_242_0
# Benchmark: hotpotqa
# Data Indices: [110]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Parse the question and extract key entities/relationships
        question_analysis = await self.generate(
            instruction="Analyze the question to identify key entities and relationships. "
                        "Focus on the main subject, the target information, and any connecting entities. "
                        "Provide a structured summary of these elements.",
            context=self.problem_text
        )

        # Step 2: Identify relevant documents by matching entities
        document_selection = await self.generate(
            instruction=f"Using the identified entities and relationships from the question ({question_analysis}), "
                        "determine which documents contain relevant information. "
                        "Match entities from the question to entities mentioned in the documents. "
                        "List the relevant documents and explain why they are relevant.",
            context=self.problem_text
        )

        # Step 3: Detect the bridge entity (parallelizable)
        bridge_candidates = await asyncio.gather(
            self.generate(
                instruction="Identify potential bridge entities that connect the relevant documents. "
                            "These entities should appear in multiple documents and serve as links between them. "
                            "List all candidates with explanations.",
                context=document_selection
            ),
            self.generate(
                instruction="Analyze the relationships between entities in the question and the documents. "
                            "Determine if there are alternative bridge entities that could connect the reasoning chain. "
                            "List these candidates with justifications.",
                context=question_analysis
            )
        )
        bridge_entity = await self.ensemble(
            instruction="Compare the candidate bridge entities and select the most plausible one. "
                        "Consider how well each candidate connects the documents and aligns with the question. "
                        "Provide a clear rationale for your choice.",
            contexts=bridge_candidates
        )

        # Step 4: Construct the reasoning chain
        reasoning_chain = await self.generate(
            instruction=f"Using the selected bridge entity ({bridge_entity}), construct a reasoning chain "
                        "that connects the relevant documents. Explain each step of the chain, showing how "
                        "information flows from one document to another through the bridge entity.",
            context=self.problem_text
        )

        # Step 5: Extract and refine the answer
        answer_extraction = await self.summarize(
            instruction="From the constructed reasoning chain, extract the final answer to the question. "
                        "Ensure the answer is concise and directly addresses the question. "
                        "If necessary, revise the reasoning chain to improve clarity or accuracy.",
            context=reasoning_chain
        )

        return answer_extraction