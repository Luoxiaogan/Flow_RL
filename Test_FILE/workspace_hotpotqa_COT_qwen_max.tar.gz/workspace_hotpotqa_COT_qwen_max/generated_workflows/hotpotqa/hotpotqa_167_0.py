# Workflow ID: hotpotqa_167_0
# Benchmark: hotpotqa
# Data Indices: [326]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Analyze the question to identify key entities and reasoning type
        question_analysis = await self.generate(
            instruction="Analyze the question to identify the main entity, the property being asked about, and the type of reasoning required (e.g., bridge, comparison, compositional). Provide a detailed breakdown.",
            context=self.problem_text
        )

        # Step 2: Summarize each document to assess relevance
        documents = self.problem_text.split("\n\n")  # Assuming documents are separated by double newlines
        summaries = await asyncio.gather(
            *[self.summarize(
                instruction=f"Summarize this document and highlight any information related to {question_analysis}.",
                context=doc
            ) for doc in documents]
        )

        # Step 3: Identify relevant documents and extract facts
        relevant_documents = []
        for doc, summary in zip(documents, summaries):
            relevance_check = await self.generate(
                instruction=f"Determine if this summary contains information relevant to answering the question based on {question_analysis}. If relevant, include the full document text.",
                context=summary
            )
            if "relevant" in relevance_check.lower():
                relevant_documents.append(relevance_check)

        # Step 4: Resolve entities and construct reasoning chains
        reasoning_chains = await asyncio.gather(
            *[self.generate(
                instruction=f"Using the provided context, resolve mentions of the main entity ({question_analysis}) and construct a reasoning chain to answer the question.",
                context=doc
            ) for doc in relevant_documents]
        )

        # Step 5: Synthesize the final answer
        final_answer = await self.ensemble(
            instruction="Combine the reasoning chains into a coherent answer. Ensure the response is concise and directly addresses the question.",
            contexts=reasoning_chains
        )

        # Step 6: Refine the final answer for clarity and accuracy
        refined_answer = await self.revise(
            instruction="Refine the answer to ensure it is clear, accurate, and supported by the reasoning chains.",
            context=final_answer
        )

        return refined_answer