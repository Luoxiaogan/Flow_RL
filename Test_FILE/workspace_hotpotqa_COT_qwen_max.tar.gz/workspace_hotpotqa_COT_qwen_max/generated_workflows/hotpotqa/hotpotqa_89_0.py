# Workflow ID: hotpotqa_89_0
# Benchmark: hotpotqa
# Data Indices: [8]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information about Brentwood Cathedral
        brentwood_info = await self.generate(
            instruction="Identify all information about Brentwood Cathedral, focusing on its historical status "
                        "and whether it was known as the 'parish church of St Peter'. Provide a concise summary.",
            context=self.problem_text
        )

        # Step 2: Extract relevant information about Bradford Cathedral
        bradford_info = await self.generate(
            instruction="Identify all information about Bradford Cathedral, focusing on its historical status "
                        "and whether it was known as the 'parish church of St Peter'. Provide a concise summary.",
            context=self.problem_text
        )

        # Step 3: Analyze and refine the extracted information
        brentwood_analysis = await self.revise(
            instruction=f"Based on the following information about Brentwood Cathedral:\n{brentwood_info}\n"
                        "Determine whether it was historically known as the 'parish church of St Peter'. "
                        "Provide a clear and concise conclusion.",
            context=brentwood_info
        )

        bradford_analysis = await self.revise(
            instruction=f"Based on the following information about Bradford Cathedral:\n{bradford_info}\n"
                        "Determine whether it was historically known as the 'parish church of St Peter'. "
                        "Provide a clear and concise conclusion.",
            context=bradford_info
        )

        # Step 4: Compare the results using Ensemble
        final_answer = await self.ensemble(
            instruction="Compare the historical status of Brentwood Cathedral and Bradford Cathedral "
                        "regarding whether they were known as the 'parish church of St Peter'. "
                        "Provide a concise answer to the question: 'Was Brentwood Cathedral or Bradford Cathedral "
                        "known as the parish church of St Peter for most of its history?'",
            contexts=[brentwood_analysis, bradford_analysis]
        )

        return final_answer