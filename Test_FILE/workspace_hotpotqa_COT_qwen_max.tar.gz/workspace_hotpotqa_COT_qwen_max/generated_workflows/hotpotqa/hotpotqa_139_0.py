# Workflow ID: hotpotqa_139_0
# Benchmark: hotpotqa
# Data Indices: [165]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify relevant documents
        instruction_step1 = (
            "Analyze the provided context documents to identify which ones mention 'SkyJump Las Vegas' "
            "and its grand opening event. Focus on extracting key sentences or paragraphs that describe "
            "the event and any individuals involved, especially the mayor. Provide a concise summary of "
            "the relevant documents and their content."
        )
        relevant_docs_task = self.generate(instruction=instruction_step1, context=self.problem_text)

        # Step 2: Extract the mayor's name
        instruction_step2 = (
            "From the provided context documents, identify the name of the mayor who presided over the "
            "grand opening of SkyJump Las Vegas. Look for mentions of 'mayor,' 'presided,' or related terms. "
            "Ensure the name is clearly linked to the event. If multiple candidates are found, list them all."
        )
        mayor_name_task = self.generate(instruction=instruction_step2, context=self.problem_text)

        # Run steps 1 and 2 in parallel
        relevant_docs, mayor_name = await asyncio.gather(relevant_docs_task, mayor_name_task)

        # Step 3: Find the mayor's birthday
        instruction_step3 = (
            f"Using the identified mayor's name ({mayor_name}), search the provided context documents "
            "to find their birthday. Look for biographical details or mentions of their personal information. "
            "If multiple dates are mentioned, prioritize the most credible source."
        )
        mayor_birthday_task = self.generate(instruction=instruction_step3, context=self.problem_text)

        # Step 4: Validate and refine the reasoning chain
        instruction_step4 = (
            "Review the extracted information about the mayor's involvement in the SkyJump Las Vegas grand opening "
            "and their birthday. Ensure the reasoning chain is logical and consistent. If discrepancies are found, "
            "revise the information to correct errors or ambiguities."
        )
        validation_task = self.revise(instruction=instruction_step4, context=f"{relevant_docs}\n{mayor_name}\n{mayor_birthday_task}")

        # Run steps 3 and 4 in parallel
        mayor_birthday, validated_info = await asyncio.gather(mayor_birthday_task, validation_task)

        # Step 5: Summarize the final answer
        instruction_step5 = (
            "Condense the validated information into a concise answer. Include the name of the mayor, "
            "their birthday, and a brief explanation of how this information was derived from the documents."
        )
        final_answer = await self.summarize(instruction=instruction_step5, context=validated_info)

        return final_answer