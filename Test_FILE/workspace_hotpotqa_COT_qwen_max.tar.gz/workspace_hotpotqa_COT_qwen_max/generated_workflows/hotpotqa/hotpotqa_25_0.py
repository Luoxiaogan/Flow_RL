# Workflow ID: hotpotqa_25_0
# Benchmark: hotpotqa
# Data Indices: [335]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Analyze the question to identify entities and reasoning type
        question_analysis = await self.generate(
            instruction="Analyze the question to identify the main entities and the type of reasoning required (e.g., bridge, comparison, compositional). "
                        "Provide a detailed breakdown of the entities and reasoning type.",
            context=self.problem_text
        )

        # Step 2: Select relevant documents based on identified entities
        document_selection = await self.ensemble(
            instruction=f"Given the identified entities and reasoning type: {question_analysis}, "
                        "select the most relevant documents that contain information about these entities. "
                        "Explain why each document is relevant.",
            contexts=[doc for doc in self.problem_text.split("\n\n")]  # Split documents for ensemble
        )

        # Step 3: Extract relevant sentences or facts from the selected documents
        information_extraction = await self.generate(
            instruction=f"Extract sentences or facts from the following documents: {document_selection} "
                        "that are relevant to the entities and reasoning type. "
                        "Ensure the extracted information is concise and directly related to the question.",
            context=self.problem_text
        )

        # Step 4: Construct the reasoning chain by connecting facts across documents
        reasoning_chain = await self.generate(
            instruction=f"Using the extracted information: {information_extraction}, "
                        "construct a reasoning chain that connects the facts across documents. "
                        "Explain how the entities and facts are linked to answer the question.",
            context=self.problem_text
        )

        # Step 5: Synthesize the final answer
        answer_synthesis = await self.ensemble(
            instruction=f"Synthesize a concise answer using the reasoning chain: {reasoning_chain}. "
                        "Ensure the answer directly addresses the question and is supported by the extracted facts.",
            contexts=[question_analysis, document_selection, information_extraction, reasoning_chain]
        )

        # Step 6: Refine the answer for accuracy and completeness
        refined_answer = await self.revise(
            instruction="Critique and refine the following answer for accuracy, completeness, and clarity. "
                        "Ensure it is concise and directly addresses the question.",
            context=answer_synthesis
        )

        return refined_answer