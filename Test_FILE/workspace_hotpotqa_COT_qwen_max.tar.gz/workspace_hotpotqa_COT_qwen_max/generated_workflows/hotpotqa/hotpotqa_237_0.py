# Workflow ID: hotpotqa_237_0
# Benchmark: hotpotqa
# Data Indices: [73]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Identify Relevant Documents
        doc_identification_instruction = """
        Analyze the provided context documents and identify those that contain information about the film "Yes, Giorgio." 
        Specifically, look for documents that mention the cast or key individuals associated with the film. 
        Return a list of relevant document indices or names.
        """
        relevant_docs = await self.generate(instruction=doc_identification_instruction, context=self.problem_text)

        # Step 2: Extract Key Entities
        entity_extraction_instruction = f"""
        From the documents identified as relevant ({relevant_docs}), extract the name of the Italian singer who starred in "Yes, Giorgio." 
        Ensure the extraction is precise and supported by explicit mentions in the text.
        """
        singer_name = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 3: Resolve Entity Across Documents
        entity_resolution_instruction = f"""
        Find all documents that mention the singer {singer_name} and determine the year of their death. 
        If multiple years are mentioned, resolve any conflicts by prioritizing the most credible or explicitly stated information.
        """
        death_year_candidates = await asyncio.gather(
            self.generate(instruction=entity_resolution_instruction, context=self.problem_text),
            self.generate(instruction=entity_resolution_instruction, context=self.problem_text)
        )
        death_year = await self.ensemble(
            instruction="Evaluate the candidate answers and select the most accurate and well-supported year of death.",
            contexts=death_year_candidates
        )

        # Step 4: Refine and Finalize Answer
        refinement_instruction = f"""
        Review the selected death year ({death_year}) and ensure it is precise, accurate, and directly supported by the text. 
        If necessary, revise the answer to improve clarity or correctness.
        """
        final_answer = await self.revise(instruction=refinement_instruction, context=self.problem_text)

        return final_answer