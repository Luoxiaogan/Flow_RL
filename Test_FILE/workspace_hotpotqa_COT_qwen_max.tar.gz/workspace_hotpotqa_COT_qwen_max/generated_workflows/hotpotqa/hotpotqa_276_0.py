# Workflow ID: hotpotqa_276_0
# Benchmark: hotpotqa
# Data Indices: [184]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract entities and their contexts from the problem text
        entity_extraction_instruction = """
        Identify all entities mentioned in the question and locate their mentions across the provided documents. 
        For each entity, extract the sentences or phrases where they appear. Ensure you capture all relevant information 
        that could help connect these entities across documents. Provide the output as a structured list of entities 
        and their associated contexts.
        """
        entities_and_contexts = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Determine document relevance based on extracted entities
        relevance_filtering_instruction = f"""
        Evaluate the relevance of each document to the question based on the extracted entities and their contexts. 
        Rank the documents by their relevance to the question. Consider how well each document contributes to answering 
        the question or connecting the entities. Provide a ranked list of documents with explanations for their relevance.
        """
        relevant_documents = await self.ensemble(
            instruction=relevance_filtering_instruction,
            contexts=[entities_and_contexts, self.problem_text]
        )

        # Step 3: Construct the reasoning chain across documents
        reasoning_chain_instruction = f"""
        Using the ranked list of relevant documents and the extracted entities, construct a reasoning chain that connects 
        the entities and facts across documents. Explicitly state how the entities are related and how the facts lead to 
        the answer. Ensure the reasoning chain is clear, logical, and directly addresses the question. Provide the output 
        as a step-by-step explanation of the reasoning process.
        """
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=relevant_documents)

        # Step 4: Synthesize the final answer
        answer_synthesis_instruction = f"""
        Based on the constructed reasoning chain, extract the precise answer to the question. Ensure the answer is concise, 
        factual, and directly addresses the question. If the answer requires a specific text span, include it verbatim from 
        the documents. Provide the final answer in a clear and structured format.
        """
        final_answer = await self.summarize(instruction=answer_synthesis_instruction, context=reasoning_chain)

        # Step 5: Validate and refine the answer
        validation_instruction = f"""
        Review the synthesized answer against the original problem text to ensure accuracy and completeness. If the answer 
        is incomplete or inaccurate, refine it to better match the question's requirements. Provide the refined answer.
        """
        refined_answer = await self.revise(instruction=validation_instruction, context=final_answer)

        return refined_answer