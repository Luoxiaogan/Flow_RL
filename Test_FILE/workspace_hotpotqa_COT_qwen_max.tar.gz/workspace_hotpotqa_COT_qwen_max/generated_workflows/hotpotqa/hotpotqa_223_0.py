# Workflow ID: hotpotqa_223_0
# Benchmark: hotpotqa
# Data Indices: [391]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Identify Relevant Documents
        relevant_docs_instruction = (
            "Analyze the provided question and determine which documents contain "
            "information relevant to answering it. Provide a list of document indices."
        )
        relevant_docs = await self.generate(instruction=relevant_docs_instruction, context=self.problem_text)

        # Step 2: Extract and Resolve Entities
        entity_extraction_instruction = (
            f"Extract all entities mentioned in the question and the relevant documents ({relevant_docs}). "
            "Resolve any ambiguous mentions to ensure consistent entity tracking."
        )
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 3: Build Reasoning Chain
        reasoning_chain_instruction = (
            f"Using the resolved entities ({entities}) and the relevant documents ({relevant_docs}), "
            "construct a reasoning chain that connects the information needed to answer the question. "
            "Explicitly mention how the entities relate to each other and the documents."
        )
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 4: Extract Final Answer
        answer_extraction_instruction = (
            f"Based on the reasoning chain ({reasoning_chain}), extract the final answer as a concise text span. "
            "Ensure the answer directly addresses the question."
        )
        answer = await self.summarize(instruction=answer_extraction_instruction, context=self.problem_text)

        # Step 5: Validate and Refine Answer
        refinement_instruction = (
            f"Critique the extracted answer ({answer}) for accuracy and clarity. "
            "Refine it if necessary to ensure correctness and precision."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=self.problem_text)

        return refined_answer