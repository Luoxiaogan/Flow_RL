# Workflow ID: hotpotqa_161_0
# Benchmark: hotpotqa
# Data Indices: [339]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Parse the question and identify key entities
        entity_extraction_instruction = """
        Analyze the question and extract all key entities, including names, dates, and organizations. 
        Ensure you capture any specific details mentioned in the question that could help identify relevant documents.
        """
        extracted_entities = await self.generate(
            instruction=entity_extraction_instruction,
            context=self.problem_text
        )

        # Step 2: Select relevant documents based on extracted entities
        document_selection_instruction = f"""
        Using the extracted entities: {extracted_entities}, identify the documents that are most relevant to answering the question. 
        Focus on documents that explicitly mention these entities or related information.
        """
        relevant_documents = await self.generate(
            instruction=document_selection_instruction,
            context=self.problem_text
        )

        # Step 3: Extract relevant sentences from the selected documents
        information_extraction_instruction = f"""
        From the relevant documents: {relevant_documents}, extract sentences or phrases that explicitly mention the entities or provide related information. 
        Ensure you capture all details that could contribute to answering the question.
        """
        extracted_information = await self.generate(
            instruction=information_extraction_instruction,
            context=self.problem_text
        )

        # Step 4: Build a reasoning chain to connect the extracted information
        reasoning_chain_instruction = f"""
        Using the extracted information: {extracted_information}, construct a reasoning chain that connects the entities and their relationships. 
        Ensure the chain explicitly answers the question by logically linking the provided facts.
        """
        reasoning_chain = await self.generate(
            instruction=reasoning_chain_instruction,
            context=self.problem_text
        )

        # Step 5: Validate the reasoning chain against the question
        validation_instruction = f"""
        Validate the reasoning chain: {reasoning_chain} against the original question. 
        Ensure the chain provides a complete and accurate answer. If there are ambiguities or conflicts, suggest alternative interpretations.
        """
        validation_result = await self.revise(
            instruction=validation_instruction,
            context=reasoning_chain
        )

        # Step 6: Extract the final answer as a short text span
        final_answer_instruction = f"""
        From the validated reasoning chain: {validation_result}, extract the final answer as a concise text span or phrase. 
        Ensure the answer directly addresses the question.
        """
        final_answer = await self.generate(
            instruction=final_answer_instruction,
            context=self.problem_text
        )

        return final_answer