# Workflow ID: hotpotqa_312_0
# Benchmark: hotpotqa
# Data Indices: [245]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract relevant sentences mentioning key entities
        extraction_task = await self.generate(
            instruction="""
            Extract all sentences from the context documents that mention the following entities:
            - Hi-n-Dry
            - An alternative rock group that disbanded in 1999
            - A new band formed after the disbandment
            Ensure that the extracted sentences preserve their original meaning and context.
            """,
            context=self.problem_text
        )

        # Step 2: Identify the founder of Hi-n-Dry and the alternative rock group
        founder_and_group_task = await self.generate(
            instruction=f"""
            Based on the following extracted information:
            {extraction_task}
            
            Identify:
            - The founder of Hi-n-Dry
            - The alternative rock group that disbanded in 1999
            Provide clear reasoning for each identification.
            """,
            context=self.problem_text
        )

        # Step 3: Determine the new band formed after the disbandment
        new_band_task = await self.generate(
            instruction=f"""
            Based on the previous findings:
            {founder_and_group_task}
            
            Determine the name of the new band formed by members of the alternative rock group that disbanded in 1999.
            Explain the logical connection between the entities involved.
            """,
            context=self.problem_text
        )

        # Step 4: Summarize the reasoning chain and extract the final answer
        final_answer_task = await self.summarize(
            instruction=f"""
            Summarize the reasoning chain that led to the identification of the new band:
            - Founder of Hi-n-Dry: [Founder Name]
            - Alternative rock group that disbanded in 1999: [Group Name]
            - New band formed: [New Band Name]
            
            Extract the final answer (the name of the new band) and present it clearly.
            """,
            context=new_band_task
        )

        return final_answer_task