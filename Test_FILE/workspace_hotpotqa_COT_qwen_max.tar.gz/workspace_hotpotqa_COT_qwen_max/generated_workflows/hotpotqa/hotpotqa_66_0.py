# Workflow ID: hotpotqa_66_0
# Benchmark: hotpotqa
# Data Indices: [121]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Identify key entities and relevant documents
        entities_instruction = """Identify the key entities mentioned in the question. 
        These are typically names of people, organizations, or other significant nouns. 
        Ensure the entities are extracted accurately and completely."""
        entities = await self.generate(instruction=entities_instruction, context=self.problem_text)

        # Dynamically construct instructions for extracting relevant documents
        extract_docs_instruction = f"""For each entity in {entities}, identify which documents 
        contain relevant information about them. List the document numbers and provide a brief 
        summary of why they are relevant."""
        relevant_docs = await self.generate(instruction=extract_docs_instruction, context=self.problem_text)

        # Step 2: Extract facts about the entities in parallel
        extract_facts_instruction_template = """Extract all relevant facts about {entity} from the 
        provided documents. Include details such as titles won, achievements, partnerships, 
        and any other pertinent information. Organize the facts clearly and concisely."""
        
        # Prepare tasks for parallel execution
        tasks = []
        for entity in entities.split(", "):  # Assuming entities are comma-separated
            task = self.generate(
                instruction=extract_facts_instruction_template.format(entity=entity.strip()),
                context=relevant_docs
            )
            tasks.append(task)

        # Execute tasks in parallel
        facts_results = await asyncio.gather(*tasks)

        # Step 3: Compare and synthesize the extracted facts
        compare_instruction = f"""Compare the facts extracted for the entities: {entities}. 
        Specifically, determine who has won more titles based on the information provided. 
        Provide a clear and logical reasoning chain to support your conclusion."""
        comparison = await self.ensemble(instruction=compare_instruction, contexts=facts_results)

        # Step 4: Refine the final answer
        refine_instruction = """Refine the provided answer to ensure it is precise, well-supported, 
        and free of ambiguity. If necessary, revise the reasoning or clarify the conclusion."""
        final_answer = await self.revise(instruction=refine_instruction, context=comparison)

        return final_answer