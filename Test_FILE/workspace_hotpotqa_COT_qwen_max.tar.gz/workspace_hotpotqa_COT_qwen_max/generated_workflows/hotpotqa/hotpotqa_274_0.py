# Workflow ID: hotpotqa_274_0
# Benchmark: hotpotqa
# Data Indices: [19]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract professions of John Lydon and Jimi Jamison in parallel
        lydon_profession_task = self.generate(
            instruction="Identify the profession(s) of John Lydon from the provided documents. "
                        "Look for explicit mentions of his roles, such as singer, musician, or other occupations. "
                        "Provide a concise summary of his profession(s).",
            context=self.problem_text
        )

        jamison_profession_task = self.generate(
            instruction="Identify the profession(s) of Jimi Jamison from the provided documents. "
                        "Look for explicit mentions of his roles, such as singer, musician, or other occupations. "
                        "Provide a concise summary of his profession(s).",
            context=self.problem_text
        )

        # Execute tasks in parallel
        lydon_profession, jamison_profession = await asyncio.gather(lydon_profession_task, jamison_profession_task)

        # Step 2: Compare professions using Ensemble
        comparison_result = await self.ensemble(
            instruction="Compare the professions of John Lydon and Jimi Jamison. "
                        "Determine if they are the same or different. "
                        "If there are slight variations (e.g., 'singer' vs. 'musician'), consider them equivalent. "
                        "Provide a clear and concise conclusion.",
            contexts=[lydon_profession, jamison_profession]
        )

        # Step 3: Summarize the reasoning chain
        reasoning_summary = await self.summarize(
            instruction="Summarize the reasoning process used to determine whether John Lydon and Jimi Jamison "
                        "have the same profession. Include the extracted professions and the comparison result.",
            context=comparison_result
        )

        # Step 4: Final answer synthesis
        final_answer = await self.generate(
            instruction="Based on the reasoning summary, provide a final answer to the question: "
                        "'Did John Lydon and Jimi Jamison have the same profession?' "
                        "Answer with a clear 'Yes' or 'No', followed by a brief explanation.",
            context=reasoning_summary
        )

        return final_answer