# Workflow ID: hotpotqa_278_0
# Benchmark: hotpotqa
# Data Indices: [397]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio
        # Step 1: Extract entities and identify relevant documents
        entity_extraction_instruction = (
            "Extract all key entities mentioned in the question and their relationships. "
            "Identify which documents contain information about these entities. "
            "Provide a list of relevant documents and their associated entities."
        )
        entity_extraction = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Build reasoning chain
        reasoning_chain_instruction = (
            f"Given the extracted entities and relevant documents: {entity_extraction}\n"
            "Construct a reasoning chain that connects the entities to answer the question. "
            "For example, if the question asks about the release year of a film, trace the connection "
            "from the film to its director and then to the release year. Provide a step-by-step explanation."
        )
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 3: Extract precise answer
        answer_extraction_instruction = (
            f"Using the reasoning chain: {reasoning_chain}\n"
            "Extract the precise answer to the question. Ensure the answer is supported by specific sentences "
            "from the relevant documents. Provide the answer along with supporting evidence."
        )
        answer_extraction = await self.generate(instruction=answer_extraction_instruction, context=self.problem_text)

        # Step 4: Validate and refine the answer
        validation_instruction = (
            f"Review the extracted answer: {answer_extraction}\n"
            "Critique its accuracy and completeness based on the original documents. "
            "Refine the answer if necessary, ensuring it is fully supported by the text."
        )
        refined_answer = await self.revise(instruction=validation_instruction, context=self.problem_text)

        # Step 5: Ensemble to select the best answer (if multiple candidates exist)
        ensemble_instruction = (
            "Compare the refined answer with any alternative interpretations or candidates. "
            "Select the most accurate and well-supported answer based on the reasoning chain and document evidence."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[refined_answer])

        return final_answer