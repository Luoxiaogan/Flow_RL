# Workflow ID: hotpotqa_368_0
# Benchmark: hotpotqa
# Data Indices: [379]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Identify key entities and question type
        instruction_identify = """
        Analyze the question to determine the key entities and the type of reasoning required.
        - Key entities: Identify all named entities (people, organizations, locations, etc.) mentioned in the question.
        - Question type: Classify the question as one of the following:
          * Bridge: Requires connecting information across documents via a shared entity.
          * Comparison: Requires comparing properties of entities across documents.
          * Compositional: Requires combining multiple facts to derive the answer.
          * Date/Time: Requires extracting temporal information.
        Output the results in the following format:
        {
            "key_entities": ["Entity1", "Entity2", ...],
            "question_type": "Bridge|Comparison|Compositional|Date/Time"
        }
        """
        analysis = await self.generate(instruction=instruction_identify, context=self.problem_text)

        # Parse the analysis result
        import json
        analysis_data = json.loads(analysis)
        key_entities = analysis_data.get("key_entities", [])
        question_type = analysis_data.get("question_type", "")

        # Step 2: Extract relevant information from documents
        instruction_extract = f"""
        Based on the identified key entities ({', '.join(key_entities)}) and the question type ({question_type}), 
        extract relevant sentences or facts from the provided documents. Focus on:
        - Sentences mentioning the key entities.
        - Facts or relationships that could help answer the question.
        Output the extracted information as a list of sentences or facts.
        """
        extraction_tasks = [
            self.generate(instruction=instruction_extract, context=doc) 
            for doc in self.problem_text.split("\n\n")  # Assuming documents are separated by double newlines
        ]
        extracted_info = await asyncio.gather(*extraction_tasks)

        # Step 3: Build reasoning chains
        instruction_reason = f"""
        Using the extracted information, build a reasoning chain to answer the question. 
        - For Bridge questions: Identify the "bridge entity" that connects multiple documents.
        - For Comparison questions: Compare properties of the key entities across documents.
        - For Compositional questions: Combine multiple facts to derive the answer.
        - For Date/Time questions: Extract and organize temporal information.
        Output the reasoning chain as a clear, step-by-step explanation leading to the answer.
        """
        reasoning_chain = await self.generate(instruction=instruction_reason, context="\n".join(extracted_info))

        # Step 4: Synthesize the final answer
        instruction_synthesize = f"""
        Based on the reasoning chain provided, synthesize the final answer to the question. 
        Ensure the answer is precise and directly addresses the question. If multiple candidate answers exist, 
        choose the most supported one based on the reasoning chain.
        """
        candidates = [reasoning_chain]  # Add more candidates if needed
        final_answer = await self.ensemble(instruction=instruction_synthesize, contexts=candidates)

        # Step 5: Refine the final answer (optional)
        instruction_refine = """
        Review the final answer for clarity, accuracy, and completeness. Make any necessary refinements.
        """
        refined_answer = await self.revise(instruction=instruction_refine, context=final_answer)

        return refined_answer