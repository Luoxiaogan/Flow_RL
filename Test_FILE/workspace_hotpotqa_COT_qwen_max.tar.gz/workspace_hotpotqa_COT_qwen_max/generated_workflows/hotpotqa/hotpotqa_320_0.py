# Workflow ID: hotpotqa_320_0
# Benchmark: hotpotqa
# Data Indices: [9]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Identify entities and relationships in the question
        entity_extraction_instruction = """
        Analyze the question carefully and extract all key entities and their relationships.
        Entities may include people, places, organizations, or objects mentioned in the question.
        Relationships describe how these entities are connected (e.g., ownership, membership, causality).
        Format your response as a JSON object with two keys: "entities" (list of strings) and "relationships" (list of strings).
        """
        entities_and_relationships = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)
        import json
        entities_data = json.loads(entities_and_relationships)
        entities = entities_data.get("entities", [])
        relationships = entities_data.get("relationships", [])

        # Step 2: Select relevant documents based on extracted entities
        document_selection_instruction = f"""
        Given the following entities: {', '.join(entities)}
        and their relationships: {', '.join(relationships)},
        identify which documents from the provided context are most relevant to answering the question.
        Return the indices of the relevant documents as a JSON list.
        """
        relevant_documents = await self.generate(instruction=document_selection_instruction, context=self.problem_text)
        relevant_documents_indices = json.loads(relevant_documents)

        # Step 3: Extract relevant sentences from the selected documents
        extraction_tasks = []
        for idx in relevant_documents_indices:
            extraction_instruction = f"""
            From Document {idx}, extract sentences or facts that are relevant to the entities: {', '.join(entities)}.
            Focus on information that helps establish the relationships: {', '.join(relationships)}.
            """
            extraction_tasks.append(self.generate(instruction=extraction_instruction, context=self.problem_text))
        extracted_facts = await asyncio.gather(*extraction_tasks)

        # Step 4: Construct a reasoning chain using the extracted facts
        reasoning_chain_instruction = f"""
        Using the following extracted facts: {extracted_facts},
        construct a coherent reasoning chain that connects the entities: {', '.join(entities)}.
        Ensure the reasoning chain explicitly addresses the relationships: {', '.join(relationships)}.
        Format your response as a step-by-step explanation leading to the answer.
        """
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 5: Synthesize the final answer
        answer_synthesis_instruction = f"""
        Based on the reasoning chain: {reasoning_chain},
        generate a concise and accurate answer to the original question.
        Ensure the answer directly addresses the question and is supported by the reasoning chain.
        """
        final_answer = await self.generate(instruction=answer_synthesis_instruction, context=self.problem_text)

        return final_answer