# Workflow ID: hotpotqa_337_0
# Benchmark: hotpotqa
# Data Indices: [144]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract entities and classify question type
        question_analysis = await self.generate(
            instruction="Identify the primary entities mentioned in the question and classify the question type "
                        "(e.g., bridge, comparison, compositional). Provide the entities and classification.",
            context=self.problem_text
        )

        # Dynamically incorporate extracted entities into subsequent instructions
        entities_and_type = question_analysis.split("\n")  # Assuming structured output
        entities = entities_and_type[0].split(":")[1].strip()
        question_type = entities_and_type[1].split(":")[1].strip()

        # Step 2: Evaluate document relevance
        documents = [
            "Document 1", "Document 2", "Document 3", "Document 4", "Document 5",
            "Document 6", "Document 7", "Document 8", "Document 9", "Document 10"
        ]
        relevance_tasks = [
            self.generate(
                instruction=f"Evaluate the relevance of {doc} to the entities '{entities}' and question type '{question_type}'. "
                            f"Provide a score from 0 to 10.",
                context=self.problem_text
            )
            for doc in documents
        ]
        relevance_results = await asyncio.gather(*relevance_tasks)

        # Step 3: Select top relevant documents
        selected_documents = [
            doc for doc, result in zip(documents, relevance_results)
            if int(result.split(":")[1].strip()) > 5  # Threshold for relevance
        ]

        # Step 4: Construct reasoning chain
        reasoning_chain = await self.generate(
            instruction=f"Using the documents {', '.join(selected_documents)}, construct a reasoning chain "
                        f"that connects the entities '{entities}' to answer the question type '{question_type}'.",
            context=self.problem_text
        )

        # Step 5: Extract and summarize the answer
        answer = await self.summarize(
            instruction="Extract the final answer from the reasoning chain. Ensure the answer is concise and directly addresses the question.",
            context=reasoning_chain
        )

        return answer