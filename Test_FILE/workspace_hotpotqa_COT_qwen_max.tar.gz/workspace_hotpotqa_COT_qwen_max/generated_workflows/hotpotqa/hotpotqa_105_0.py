# Workflow ID: hotpotqa_105_0
# Benchmark: hotpotqa
# Data Indices: [173]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify key entities and relevant documents
        entity_extraction_instruction = (
            "Identify all key entities mentioned in the question and determine which documents "
            "contain relevant information about these entities. Provide a mapping of entities "
            "to their respective documents."
        )
        entity_document_mapping = await self.generate(
            instruction=entity_extraction_instruction,
            context=self.problem_text
        )

        # Step 2: Extract relevant information for each entity in parallel
        entities = ["Fairbanks International Airport", "Deadhorse Airport"]
        extraction_tasks = []
        for entity in entities:
            extraction_instruction = (
                f"For the entity '{entity}', extract specific information about its location "
                "from the relevant documents. Focus on geographic details such as region, area, "
                "or proximity to landmarks."
            )
            extraction_tasks.append(
                self.generate(instruction=extraction_instruction, context=entity_document_mapping)
            )
        entity_location_info = await asyncio.gather(*extraction_tasks)

        # Step 3: Perform cross-document reasoning
        reasoning_instruction = (
            "Compare the locations of the two entities based on the extracted information. "
            "Determine whether both entities are located on the North Slope of Alaska. "
            "Provide a clear explanation of your reasoning process."
        )
        reasoning_result = await self.generate(
            instruction=reasoning_instruction,
            context="\n".join(entity_location_info)
        )

        # Step 4: Synthesize the final answer
        synthesis_instruction = (
            "Based on the reasoning provided, synthesize a concise answer to the question. "
            "Include supporting facts from the documents to justify your conclusion."
        )
        final_answer = await self.generate(
            instruction=synthesis_instruction,
            context=reasoning_result
        )

        # Step 5: Refine the final answer if necessary
        refinement_instruction = (
            "Review the final answer and ensure it is clear, concise, and directly addresses "
            "the question. Make any necessary refinements to improve clarity or accuracy."
        )
        refined_answer = await self.revise(
            instruction=refinement_instruction,
            context=final_answer
        )

        return refined_answer