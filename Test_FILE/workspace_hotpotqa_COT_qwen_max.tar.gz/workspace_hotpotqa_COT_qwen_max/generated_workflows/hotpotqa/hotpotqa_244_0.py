# Workflow ID: hotpotqa_244_0
# Benchmark: hotpotqa
# Data Indices: [129]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract entities and their contexts from all documents
        entity_extraction_instruction = """
        Identify all key entities (people, places, events, etc.) mentioned in the question and locate their mentions across the provided documents. 
        For each entity, extract the sentences or phrases that describe its role, attributes, or relationships. 
        Ensure that the extraction is comprehensive and includes any indirect references to the entity.
        """
        entity_contexts = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Assess document relevance based on shared entities
        relevance_instruction = f"""
        Using the extracted entities and their contexts ({entity_contexts}), determine which documents are most relevant to answering the question. 
        Focus on documents that share entities or themes with the question. 
        Provide a brief explanation for why each document is relevant or irrelevant.
        """
        relevant_documents = await self.generate(instruction=relevance_instruction, context=self.problem_text)

        # Step 3: Construct reasoning chains across relevant documents
        reasoning_instruction = f"""
        Based on the relevant documents identified ({relevant_documents}), construct a logical reasoning chain that connects the information from these documents to answer the question. 
        Explicitly mention how entities or facts from one document relate to those in another. 
        Ensure that the chain is complete and leads directly to the answer.
        """
        reasoning_chain = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Synthesize the final answer
        synthesis_instruction = f"""
        Using the reasoning chain constructed ({reasoning_chain}), extract the precise answer to the question. 
        Ensure that the answer is concise and directly addresses the question. 
        If the question requires a yes/no answer or a specific fact, include only that information.
        """
        final_answer = await self.summarize(instruction=synthesis_instruction, context=self.problem_text)

        return final_answer