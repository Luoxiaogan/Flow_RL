# Workflow ID: hotpotqa_229_0
# Benchmark: hotpotqa
# Data Indices: [338]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Identify relevant documents for each entity
        instruction_identify = """Identify all documents that mention either 'Natalie Merchant' or 'Marian Gold'. 
        Extract the names of these documents along with brief summaries of how each entity is described in them."""
        relevant_docs = await self.generate(instruction=instruction_identify, context=self.problem_text)

        # Step 2: Extract professional scope for each entity
        instruction_extract_merchant = f"""Using the provided documents, summarize the professional activities and scope of 'Natalie Merchant'. 
        Focus on her roles, achievements, and any other relevant information indicating the breadth of her professional activities.
        Relevant Documents: {relevant_docs}"""
        merchant_scope = await self.generate(instruction=instruction_extract_merchant, context=self.problem_text)

        instruction_extract_gold = f"""Using the provided documents, summarize the professional activities and scope of 'Marian Gold'. 
        Focus on his roles, achievements, and any other relevant information indicating the breadth of his professional activities.
        Relevant Documents: {relevant_docs}"""
        gold_scope = await self.generate(instruction=instruction_extract_gold, context=self.problem_text)

        # Step 3: Compare the professional scopes
        instruction_compare = f"""Compare the professional scopes of 'Natalie Merchant' and 'Marian Gold' based on the following summaries:
        Natalie Merchant: {merchant_scope}
        Marian Gold: {gold_scope}
        Determine which individual has a wider scope of profession and explain your reasoning."""
        comparison_result = await self.ensemble(instruction=instruction_compare, contexts=[merchant_scope, gold_scope])

        return comparison_result