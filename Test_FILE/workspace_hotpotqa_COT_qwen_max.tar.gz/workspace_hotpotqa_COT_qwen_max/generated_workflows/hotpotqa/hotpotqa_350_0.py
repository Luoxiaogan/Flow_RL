# Workflow ID: hotpotqa_350_0
# Benchmark: hotpotqa
# Data Indices: [82]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Analyze the question to determine its type and extract key entities
        question_analysis = await self.generate(
            instruction="Analyze the question to determine its type (comparison, bridge, compositional). "
                        "Extract key entities and relationships mentioned in the question. "
                        "Provide the results in the following format: "
                        "{type: 'question_type', entities: ['entity1', 'entity2'], relationships: ['relationship1']}.",
            context=self.problem_text
        )

        # Parse the analysis result
        import json
        question_info = json.loads(question_analysis)
        question_type = question_info["type"]
        entities = question_info["entities"]
        relationships = question_info["relationships"]

        # Step 2: Filter relevant documents
        document_selection = await self.ensemble(
            instruction=f"Identify which documents contain information about the following entities and relationships: {entities + relationships}. "
                        "Select only the most relevant documents.",
            contexts=[self.problem_text] * 10  # Assuming 10 documents as per the example
        )

        # Extract selected document indices
        selected_docs = [i for i, doc in enumerate(document_selection.split("\n")) if "relevant" in doc.lower()]

        # Step 3: Extract information from selected documents
        async def extract_info(doc_index):
            return await self.generate(
                instruction=f"Extract all facts and relationships involving the entities {entities} from Document {doc_index + 1}. "
                            f"Focus on information relevant to the relationships {relationships}.",
                context=self.problem_text
            )
        
        extraction_tasks = [extract_info(i) for i in selected_docs]
        extracted_facts = await asyncio.gather(*extraction_tasks)

        # Step 4: Construct reasoning chain
        reasoning_chain = await self.generate(
            instruction=f"Synthesize the following extracted facts into a coherent reasoning chain: {extracted_facts}. "
                        f"Ensure the reasoning addresses the question type: {question_type}. "
                        "Provide a clear and logical explanation of how the facts lead to the answer.",
            context=self.problem_text
        )

        # Step 5: Generate the final answer
        final_answer = await self.generate(
            instruction=f"Based on the reasoning chain: {reasoning_chain}, provide the final answer to the question. "
                        "Ensure the answer is concise and directly addresses the question.",
            context=self.problem_text
        )

        # Optional Step 6: Validate and refine the answer
        refined_answer = await self.revise(
            instruction="Critique the following answer for accuracy and clarity. "
                        "Refine it if necessary to ensure correctness and precision.",
            context=final_answer
        )

        return refined_answer