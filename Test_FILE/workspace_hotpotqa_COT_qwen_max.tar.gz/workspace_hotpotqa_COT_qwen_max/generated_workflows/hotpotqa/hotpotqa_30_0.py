# Workflow ID: hotpotqa_30_0
# Benchmark: hotpotqa
# Data Indices: [301]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract entities from the question
        entity_extraction_instruction = """
        Identify all key entities mentioned in the question. These could include people, organizations, concepts, or specific attributes. 
        For each entity, provide a brief description or context clue that can help match it to relevant documents. 
        Ensure the output is structured as a list of entities with their descriptions.
        """
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Analyze each document for relevance
        document_analysis_instruction_template = f"""
        Analyze the provided document to determine its relevance to the question. 
        Focus on the following entities and their descriptions: {entities}. 
        If the document contains information about any of these entities, summarize the relevant parts. 
        If not, state that the document is irrelevant.
        """
        document_tasks = [
            self.generate(instruction=document_analysis_instruction_template, context=doc) 
            for doc in self.config['context_documents']
        ]
        document_results = await asyncio.gather(*document_tasks)

        # Step 3: Synthesize information across documents
        synthesis_instruction = """
        Compare the provided document summaries to identify connections between them. 
        Look for bridging entities or shared themes that link the documents together. 
        Construct a reasoning chain that explains how the information in these documents answers the question.
        """
        reasoning_chain = await self.ensemble(instruction=synthesis_instruction, contexts=document_results)

        # Step 4: Extract and refine the answer
        answer_extraction_instruction = """
        Based on the reasoning chain provided, extract the precise answer to the question. 
        Ensure the answer is a concise text span (entity name, phrase, or brief factual response). 
        If the answer is ambiguous or incomplete, indicate what additional information is needed.
        """
        raw_answer = await self.summarize(instruction=answer_extraction_instruction, context=reasoning_chain)

        refinement_instruction = """
        Review the extracted answer for accuracy and completeness. 
        Ensure it directly addresses the question and is supported by the reasoning chain. 
        If necessary, refine the answer to improve clarity or precision.
        """
        final_answer = await self.revise(instruction=refinement_instruction, context=raw_answer)

        return final_answer