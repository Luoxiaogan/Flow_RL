# Workflow ID: hotpotqa_146_0
# Benchmark: hotpotqa
# Data Indices: [145]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract Entities from the Question
        entity_extraction_instruction = """
        Analyze the question and extract all key entities (e.g., names, roles, franchises). 
        For each entity, determine its type (e.g., person, movie, franchise) and provide a brief description if possible.
        """
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Rank Documents by Relevance
        relevance_instruction = f"""
        Evaluate the relevance of each document to the extracted entities: {entities}.
        Assign a relevance score to each document based on how directly it mentions or relates to the entities.
        Return the top 3 most relevant documents for further analysis.
        """
        document_texts = [f"Document {i+1}" for i in range(10)]  # Placeholder for actual document texts
        relevant_documents = await self.ensemble(instruction=relevance_instruction, contexts=document_texts)

        # Step 3: Trace Relationships Between Entities
        fact_chaining_instruction = f"""
        Using the relevant documents: {relevant_documents}, trace the relationships between the extracted entities.
        Specifically, identify how {entities} are connected across the documents.
        For example, determine which franchise Carrie-Anne Moss is associated with and who created it.
        """
        reasoning_chain = await self.generate(instruction=fact_chaining_instruction, context=self.problem_text)

        # Step 4: Summarize the Answer
        summarization_instruction = f"""
        Condense the reasoning chain: {reasoning_chain} into a concise answer to the original question.
        Ensure the answer is specific and directly addresses the query.
        """
        answer = await self.summarize(instruction=summarization_instruction, context=self.problem_text)

        # Step 5: Validate the Answer
        validation_instruction = f"""
        Critically evaluate the answer: {answer}.
        Ensure it is accurate, supported by the context documents, and fully addresses the original question.
        If necessary, suggest improvements or corrections.
        """
        final_answer = await self.revise(instruction=validation_instruction, context=self.problem_text)

        return final_answer