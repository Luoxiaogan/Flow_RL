# Workflow ID: hotpotqa_11_0
# Benchmark: hotpotqa
# Data Indices: [251]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify key entities and analyze the question
        entity_extraction_instruction = (
            "Identify all key entities mentioned in the question, such as names of people, organizations, or objects. "
            "Focus on entities that are likely to appear in the provided documents. "
            "Output the entities in a list format."
        )
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Select relevant documents based on the identified entities
        document_selection_instruction = f(
            "Given the following entities: {entities}, identify which documents contain information about these entities. "
            "For each document, briefly summarize its relevance to the entities. "
            "Output the document numbers and their summaries in a structured format."
        )
        relevant_documents = await self.generate(instruction=document_selection_instruction, context=self.problem_text)

        # Step 3: Extract relationships between entities
        relationship_extraction_instruction = f(
            "Using the relevant documents ({relevant_documents}), extract the relationships between the entities. "
            "Focus on how the entities are connected and any additional information that helps answer the question. "
            "Output the relationships in a clear and concise format."
        )
        relationships = await self.generate(instruction=relationship_extraction_instruction, context=self.problem_text)

        # Step 4: Extract the precise answer
        answer_extraction_instruction = f(
            "Based on the relationships identified ({relationships}), extract the precise answer to the question. "
            "Ensure the answer is supported by specific sentences from the documents. "
            "Output the answer along with the supporting evidence."
        )
        answer = await self.generate(instruction=answer_extraction_instruction, context=self.problem_text)

        # Step 5: Validate and refine the answer
        refinement_instruction = (
            "Review the extracted answer and ensure it is accurate and concise. "
            "If necessary, revise the answer to improve clarity or correctness. "
            "Ensure the final output directly addresses the question."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=answer)

        return refined_answer