# Workflow ID: hotpotqa_63_0
# Benchmark: hotpotqa
# Data Indices: [208]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant documents and key information
        extraction_instruction = (
            "Identify the documents that contain information relevant to the question. "
            "Focus on the keywords in the question and extract sentences that mention these keywords. "
            "Ensure the extracted sentences include details about entities, locations, and relationships. "
            "If multiple documents are relevant, extract information from all of them."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Resolve entities and link information across documents
        entity_resolution_instruction = (
            "Analyze the extracted information to resolve entities mentioned across documents. "
            "Ensure that entities are correctly matched and linked. For example, confirm that mentions of 'NY 406' and 'US 20' "
            "refer to the same entities across different documents. Synthesize the information into a coherent set of facts."
        )
        resolved_entities = await self.ensemble(instruction=entity_resolution_instruction, contexts=[extracted_info])

        # Step 3: Construct the reasoning chain
        reasoning_chain_instruction = (
            "Using the resolved entities and synthesized facts, construct a logical reasoning chain to answer the question. "
            "Start with the primary entity mentioned in the question (e.g., 'NY 406') and follow the relationships "
            "to derive the final answer. Ensure the reasoning chain is explicit and step-by-step."
        )
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=resolved_entities)

        # Step 4: Refine and validate the final answer
        refinement_instruction = (
            "Refine the derived answer to ensure it is concise, accurate, and directly addresses the question. "
            "Validate the answer against the original problem text to ensure consistency. Format the answer appropriately."
        )
        final_answer = await self.revise(instruction=refinement_instruction, context=reasoning_chain)

        return final_answer