# Workflow ID: hotpotqa_222_0
# Benchmark: hotpotqa
# Data Indices: [261]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key entities and identify relevant documents
        entity_extraction_instruction = (
            "Identify all key entities mentioned in the question, including names, organizations, events, "
            "and relationships. Focus on entities like 'Dream Team,' 'O.J. Simpson trial,' 'children,' and 'reality TV series.'"
        )
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        document_selection_instruction = (
            f"Given the extracted entities: {entities}, identify which documents in the provided context "
            "are relevant to answering the question. Focus on documents that mention the 'Dream Team,' "
            "O.J. Simpson trial participants, and any related family members."
        )
        relevant_documents = await self.generate(instruction=document_selection_instruction, context=self.problem_text)

        # Step 2: Detect the bridge entity
        bridge_entity_instruction = (
            f"Using the relevant documents: {relevant_documents}, determine the 'bridge entity' that connects "
            "the 'Dream Team' to the children appearing in a reality TV series. This entity should be a person or "
            "organization mentioned in both contexts."
        )
        bridge_entity = await self.generate(instruction=bridge_entity_instruction, context=self.problem_text)

        # Step 3: Construct the reasoning chain
        reasoning_chain_instruction = (
            f"Given the bridge entity: {bridge_entity}, construct a reasoning chain that links the 'Dream Team' "
            "to the children appearing in a reality TV series. Include specific facts from the relevant documents "
            "to support each step of the chain."
        )
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 4: Extract the precise answer
        answer_extraction_instruction = (
            f"Based on the reasoning chain: {reasoning_chain}, extract the precise answer to the question. "
            "Ensure the answer is a short text span, such as a name or phrase, that directly answers the question."
        )
        answer = await self.generate(instruction=answer_extraction_instruction, context=self.problem_text)

        # Step 5: Validate and refine the answer
        validation_instruction = (
            f"Review the extracted answer: {answer} against the original problem text and reasoning chain. "
            "Ensure the answer is accurate, supported by evidence, and formatted correctly."
        )
        refined_answer = await self.revise(instruction=validation_instruction, context=answer)

        return refined_answer