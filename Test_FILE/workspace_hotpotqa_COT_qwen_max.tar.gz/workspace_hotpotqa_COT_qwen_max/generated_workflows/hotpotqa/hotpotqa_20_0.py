# Workflow ID: hotpotqa_20_0
# Benchmark: hotpotqa
# Data Indices: [376]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key entities and relationships from the question
        entity_extraction_instruction = (
            "Identify all key entities mentioned in the question and determine their relationships. "
            "Focus on entities that are likely to connect multiple documents or provide critical information. "
            "Format the output as a list of entities and their potential roles in the reasoning process."
        )
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Summarize relevant information from each document
        summarize_instruction = (
            f"Given the extracted entities: {entities}, summarize the key information from the document "
            "that relates to these entities. Focus on facts that could help answer the question. "
            "If no relevant information is found, return 'No relevant information'."
        )
        summaries = await asyncio.gather(
            *[self.summarize(instruction=summarize_instruction, context=doc) for doc in self.config['documents']]
        )

        # Step 3: Construct reasoning chains by combining summaries
        ensemble_instruction = (
            "Combine the provided summaries to construct a coherent reasoning chain. "
            "Identify the 'bridge entity' if applicable, and explain how the information connects across documents. "
            "If the question involves comparisons or compositions, synthesize the facts logically. "
            "Provide a clear explanation of the reasoning process."
        )
        reasoning_chain = await self.ensemble(instruction=ensemble_instruction, contexts=summaries)

        # Step 4: Extract the final answer based on the reasoning chain
        answer_extraction_instruction = (
            f"Based on the reasoning chain: {reasoning_chain}, extract the final answer to the question. "
            "Ensure the answer is precise, concise, and directly addresses the question. "
            "Format the answer as a short text span or a brief factual response."
        )
        final_answer = await self.generate(instruction=answer_extraction_instruction, context=self.problem_text)

        return final_answer