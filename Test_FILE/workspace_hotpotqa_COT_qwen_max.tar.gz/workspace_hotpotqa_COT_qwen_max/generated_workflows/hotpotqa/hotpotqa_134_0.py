# Workflow ID: hotpotqa_134_0
# Benchmark: hotpotqa
# Data Indices: [247]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify relevant documents and entities
        entity_extraction_instruction = """
        Extract all key entities and concepts mentioned in the question.
        Then, scan through all provided documents and identify which documents contain mentions of these entities or concepts.
        Provide a list of relevant documents along with the specific sentences where these entities are mentioned.
        """
        relevant_documents = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Resolve entities across documents
        entity_resolution_instruction = f"""
        Given the following relevant documents and entity mentions: {relevant_documents}
        Resolve any discrepancies in entity names across different documents.
        Create a mapping of entities that are mentioned differently but refer to the same thing.
        """
        entity_mapping = await self.generate(instruction=entity_resolution_instruction, context=self.problem_text)

        # Step 3: Construct reasoning chain
        reasoning_chain_instruction = f"""
        Using the resolved entities: {entity_mapping}
        Construct a reasoning chain that connects the information from different documents.
        If the question requires bridging entities, explain how they are connected.
        If the question requires comparing properties, provide a comparison.
        Ensure the reasoning chain leads to the answer.
        """
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 4: Extract the final answer
        answer_extraction_instruction = f"""
        Based on the following reasoning chain: {reasoning_chain}
        Extract the precise answer to the question.
        The answer should be a short text span, a yes/no answer, or a brief factual response.
        """
        final_answer = await self.summarize(instruction=answer_extraction_instruction, context=self.problem_text)

        return final_answer