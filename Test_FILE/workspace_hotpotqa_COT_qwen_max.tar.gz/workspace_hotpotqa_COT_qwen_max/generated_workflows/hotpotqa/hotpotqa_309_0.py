# Workflow ID: hotpotqa_309_0
# Benchmark: hotpotqa
# Data Indices: [139]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Parse the question to identify key entities and relationships
        question_analysis = await self.generate(
            instruction="""
            Analyze the question to identify:
            1. The main entities mentioned (e.g., characters, actors, shows).
            2. The type of relationship being asked (e.g., 'played what role', 'founded first').
            3. Any constraints or specific requirements for the answer.
            Return the findings in a structured format.
            """,
            context=self.problem_text
        )

        # Step 2: Identify relevant documents for each entity
        entities = await self.generate(
            instruction=f"""
            Based on the analysis: {question_analysis}
            Extract all entities mentioned in the question and generate a list of them.
            For each entity, determine which documents might contain relevant information.
            Return the entities and their associated documents as a mapping.
            """,
            context=self.problem_text
        )

        # Step 3: Extract relevant facts from the identified documents
        extraction_tasks = []
        for entity in entities.split("\n"):  # Assuming entities are newline-separated
            extraction_tasks.append(
                self.generate(
                    instruction=f"""
                    Extract all relevant information about the entity: {entity}.
                    Focus on facts that could help answer the original question: {self.problem_text}.
                    Include details such as roles, relationships, and other attributes.
                    """,
                    context=self.problem_text
                )
            )
        extracted_facts = await asyncio.gather(*extraction_tasks)

        # Step 4: Construct the reasoning chain
        reasoning_chain = await self.ensemble(
            instruction="""
            Combine the extracted facts into a coherent reasoning chain.
            Ensure that the chain connects the entities mentioned in the question.
            Highlight any intermediate steps or bridging entities.
            """,
            contexts=extracted_facts
        )

        # Step 5: Synthesize the final answer
        final_answer = await self.revise(
            instruction=f"""
            Based on the reasoning chain: {reasoning_chain}
            Synthesize a concise and accurate answer to the original question: {self.problem_text}.
            Ensure the answer is supported by the extracted facts and reasoning.
            """,
            context=self.problem_text
        )

        return final_answer