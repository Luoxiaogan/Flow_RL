# Workflow ID: hotpotqa_179_0
# Benchmark: hotpotqa
# Data Indices: [116]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract information about the entities in parallel
        entity_1_instruction = f"""
        Extract all relevant information about the Rahmi M. Koç Museum from the provided documents.
        Focus on its opening date or any chronological details that indicate when it was established.
        If there are multiple mentions, prioritize the most specific or earliest date mentioned.
        """
        entity_2_instruction = f"""
        Extract all relevant information about the Endem TV Tower from the provided documents.
        Focus on its opening date or any chronological details that indicate when it was established.
        If there are multiple mentions, prioritize the most specific or earliest date mentioned.
        """

        entity_1_info, entity_2_info = await asyncio.gather(
            self.generate(instruction=entity_1_instruction, context=self.problem_text),
            self.generate(instruction=entity_2_instruction, context=self.problem_text)
        )

        # Step 2: Compare the extracted information
        comparison_instruction = f"""
        Compare the opening dates of the Rahmi M. Koç Museum and the Endem TV Tower based on the following information:
        
        Rahmi M. Koç Museum: {entity_1_info}
        
        Endem TV Tower: {entity_2_info}
        
        Determine which one opened first. If the dates are ambiguous or missing, state that explicitly.
        Provide your reasoning step-by-step.
        """

        comparison_result = await self.ensemble(
            instruction=comparison_instruction,
            contexts=[entity_1_info, entity_2_info]
        )

        # Step 3: Generate the final answer
        final_answer_instruction = f"""
        Based on the comparison result, provide a concise answer to the question:
        "Which Istanbul landmark opened first, the Rahmi M. Koç Museum or the Endem TV Tower?"
        
        Comparison Result: {comparison_result}
        
        Ensure the answer is clear and directly addresses the question.
        """

        final_answer = await self.generate(instruction=final_answer_instruction, context=self.problem_text)

        return final_answer