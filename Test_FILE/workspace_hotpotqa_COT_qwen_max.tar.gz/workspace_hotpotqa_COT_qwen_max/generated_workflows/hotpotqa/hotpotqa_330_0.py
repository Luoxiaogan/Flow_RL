# Workflow ID: hotpotqa_330_0
# Benchmark: hotpotqa
# Data Indices: [40]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify relevant documents and extract key information
        extract_instruction = f"""
        Analyze the provided context documents to identify which ones mention 'Maa Aarki'. 
        Extract all relevant information about 'Maa Aarki', including its description, purpose, and any associated activities or entities.
        Ensure the output is structured and concise.
        """
        relevant_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Resolve the bridge entity connecting 'Maa Aarki' to the type of dance
        bridge_instruction = f"""
        Based on the extracted information about 'Maa Aarki', determine the type of dance it celebrates. 
        Look for explicit mentions of dance forms or related activities in the context of 'Maa Aarki'.
        If no direct mention is found, infer the most likely dance form based on contextual clues.
        """
        bridge_entity = await self.generate(instruction=bridge_instruction, context=relevant_info)

        # Step 3: Summarize the findings
        summarize_instruction = f"""
        Condense the information about 'Maa Aarki' and the associated dance form into a brief summary. 
        Focus on the key details required to answer the question: What form of dance does 'Maa Aarki' celebrate?
        """
        summary = await self.summarize(instruction=summarize_instruction, context=bridge_entity)

        # Step 4: Revise the summary for clarity and accuracy
        revise_instruction = f"""
        Review the summary and refine it to ensure clarity, accuracy, and completeness. 
        Remove any unnecessary details while retaining the essential information needed to answer the question.
        """
        refined_summary = await self.revise(instruction=revise_instruction, context=summary)

        # Step 5: Final synthesis using Ensemble to combine evidence
        ensemble_instruction = f"""
        Combine all available evidence to produce the final answer to the question: 
        What form of dance does 'Maa Aarki' celebrate? 
        Ensure the answer is precise and directly addresses the question.
        """
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[refined_summary])

        return final_answer