# Workflow ID: hotpotqa_287_0
# Benchmark: hotpotqa
# Data Indices: [140]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Analyze the question to identify key entities and question type
        question_analysis = await self.generate(
            instruction="Analyze the question to determine its type (bridge, comparison, or compositional) and extract key entities or concepts. "
                        "Provide a detailed breakdown of the entities and their potential relationships.",
            context=self.problem_text
        )

        # Step 2: Select relevant documents based on extracted entities
        document_selection = await self.generate(
            instruction=f"Based on the following analysis: {question_analysis}, "
                        "identify which documents from the provided context are most relevant to answering the question. "
                        "Focus on documents that mention the extracted entities or concepts.",
            context=self.problem_text
        )

        # Step 3: Identify bridge entities or key facts
        bridge_entity_identification = await self.generate(
            instruction=f"From the selected documents: {document_selection}, "
                        "identify the bridge entity or key facts that connect the information across documents. "
                        "If the question is a comparison or compositional type, focus on extracting relevant properties or facts.",
            context=self.problem_text
        )

        # Step 4: Construct reasoning chain
        reasoning_chain = await self.generate(
            instruction=f"Using the following information: {bridge_entity_identification}, "
                        "construct a reasoning chain that connects the facts across documents to answer the question. "
                        "Ensure the chain is logical and explicitly links the information.",
            context=self.problem_text
        )

        # Step 5: Extract the final answer
        answer_extraction = await self.generate(
            instruction=f"Based on the reasoning chain: {reasoning_chain}, "
                        "extract the precise answer span that directly answers the question. "
                        "Ensure the answer is concise and matches the expected format (short text, yes/no, or factual response).",
            context=self.problem_text
        )

        return answer_extraction