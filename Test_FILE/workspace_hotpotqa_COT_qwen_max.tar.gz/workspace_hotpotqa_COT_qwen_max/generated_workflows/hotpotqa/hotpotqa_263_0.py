# Workflow ID: hotpotqa_263_0
# Benchmark: hotpotqa
# Data Indices: [109]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify relevant documents
        relevance_instruction = """
        Analyze the provided document and determine its relevance to the question. 
        Consider whether the document contains entities, facts, or relationships that could help answer the question. 
        Provide a brief explanation of why the document is relevant or irrelevant.
        """
        relevance_tasks = [
            self.generate(instruction=relevance_instruction, context=doc) 
            for doc in self.problem_text['context_documents']
        ]
        relevance_results = await asyncio.gather(*relevance_tasks)
        
        # Filter relevant documents based on results
        relevant_docs = [
            doc for doc, result in zip(self.problem_text['context_documents'], relevance_results) 
            if "relevant" in result.lower()
        ]

        # Step 2: Extract entities and relationships
        extraction_instruction = f"""
        From the given text, extract all key entities (e.g., organizations, locations, people) and their relationships. 
        Focus on information that could be useful for answering the question: "{self.problem_text['question']}". 
        Provide the extracted information in a structured format, such as a list of entity-relationship pairs.
        """
        extraction_tasks = [
            self.generate(instruction=extraction_instruction, context=doc) 
            for doc in relevant_docs
        ]
        extraction_results = await asyncio.gather(*extraction_tasks)

        # Step 3: Build reasoning chain
        reasoning_instruction = f"""
        Combine the extracted facts from the provided documents to construct a reasoning chain that answers the question: "{self.problem_text['question']}".
        Ensure that the reasoning chain explicitly connects entities and relationships across documents.
        If there are multiple possible chains, prioritize the most logical and well-supported one.
        """
        reasoning_chain = await self.ensemble(instruction=reasoning_instruction, contexts=extraction_results)

        # Step 4: Synthesize the final answer
        synthesis_instruction = f"""
        Based on the reasoning chain provided, generate a concise and factual answer to the question: "{self.problem_text['question']}".
        Ensure the answer is precise, directly addresses the question, and includes supporting evidence if necessary.
        """
        final_answer = await self.summarize(instruction=synthesis_instruction, context=reasoning_chain)

        return final_answer