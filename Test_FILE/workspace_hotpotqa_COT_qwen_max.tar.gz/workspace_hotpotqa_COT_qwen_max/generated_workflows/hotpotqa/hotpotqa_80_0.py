# Workflow ID: hotpotqa_80_0
# Benchmark: hotpotqa
# Data Indices: [39]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify relevant documents
        relevance_instruction = """
        Analyze the provided document to determine its relevance to the question. 
        Specifically, check if the document mentions the entity or topic in the question 
        and provides useful context for answering it. Return 'Relevant' if the document 
        is pertinent, otherwise return 'Not Relevant'.
        """
        documents = [
            "Document 1: Military career of Mustafa Kemal Atatürk...",
            "Document 2: İzmir Atatürk Museum...",
            "Document 3: List of Mustafa Kemal Atatürk's awards...",
            "Document 4: Salih Bozok...",
            "Document 5: Mustafa (film)...",
            "Document 6: Mustafa Kemal Atatürk...",
            "Document 7: Gazi Mustafa Kemal Boulevard, Ankara...",
            "Document 8: Hüseyin Avni Zaimler...",
            "Document 9: Gazi Mustafa Kemal Boulevard...",
            "Document 10: Mustafa Kemal University..."
        ]
        relevance_tasks = [
            self.generate(instruction=relevance_instruction, context=doc) for doc in documents
        ]
        relevance_results = await asyncio.gather(*relevance_tasks)

        # Filter relevant documents
        relevant_documents = [doc for doc, result in zip(documents, relevance_results) if "Relevant" in result]

        # Step 2: Extract bridging entities and facts
        entity_extraction_instruction = f"""
        From the relevant documents, extract all mentions of the entity or topic in the question 
        and any bridging information that connects these mentions across documents. 
        Ensure that the extracted information is concise and directly supports answering the question.
        Original Problem: {self.problem_text}
        """
        bridging_info = await self.generate(instruction=entity_extraction_instruction, context="\n".join(relevant_documents))

        # Step 3: Construct reasoning chain and synthesize answer
        reasoning_instruction = f"""
        Using the extracted bridging information, construct a reasoning chain to answer the question. 
        Combine facts from multiple documents to derive the final answer. Ensure that the reasoning 
        process is logical and explicitly links the documents together.
        Bridging Information: {bridging_info}
        Original Problem: {self.problem_text}
        """
        reasoning_chain = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Extract and refine the final answer
        answer_extraction_instruction = f"""
        From the constructed reasoning chain, extract the precise answer to the question. 
        Ensure that the answer is concise and matches the expected format (e.g., date, name, etc.).
        Reasoning Chain: {reasoning_chain}
        Original Problem: {self.problem_text}
        """
        raw_answer = await self.generate(instruction=answer_extraction_instruction, context=self.problem_text)

        refinement_instruction = """
        Refine the extracted answer to ensure it is accurate, complete, and formatted correctly. 
        If necessary, adjust the phrasing to match the question's requirements.
        """
        final_answer = await self.revise(instruction=refinement_instruction, context=raw_answer)

        return final_answer