# Workflow ID: hotpotqa_291_0
# Benchmark: hotpotqa
# Data Indices: [383]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Analyze the question to identify entities, reasoning type, and answer format
        question_analysis_instruction = (
            "Analyze the given question to identify the following:\n"
            "- Key entities mentioned in the question\n"
            "- Type of reasoning required (e.g., bridge, comparison, compositional)\n"
            "- Expected answer format (e.g., short phrase, yes/no, numerical value)\n"
            "Provide a structured output with clear labels for each component."
        )
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 2: Identify relevant documents based on extracted entities and reasoning type
        relevance_instruction = f(
            "Given the following analysis of the question:\n{question_analysis}\n"
            "Evaluate each document in the context to determine its relevance to answering the question.\n"
            "Focus on documents that mention the key entities or provide information related to the reasoning type.\n"
            "Return a list of relevant documents along with justification for their relevance."
        )
        relevant_documents = await self.generate(instruction=relevance_instruction, context=self.problem_text)

        # Step 3: Identify bridge entities or relationships between relevant documents
        bridging_instruction = f(
            "Using the following relevant documents:\n{relevant_documents}\n"
            "Identify shared entities or relationships that connect the information across documents.\n"
            "Focus on entities that serve as bridges for multi-hop reasoning.\n"
            "Provide a detailed explanation of how these entities connect the documents."
        )
        bridging_entities = await self.generate(instruction=bridging_instruction, context=self.problem_text)

        # Step 4: Construct the reasoning chain to derive the answer
        reasoning_instruction = f(
            "Based on the following information:\n"
            "- Question analysis: {question_analysis}\n"
            "- Relevant documents: {relevant_documents}\n"
            "- Bridging entities: {bridging_entities}\n"
            "Construct a reasoning chain that connects the information to derive the answer.\n"
            "Ensure the chain explicitly explains how the facts lead to the conclusion."
        )
        reasoning_chain = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 5: Validate and refine the derived answer
        refinement_instruction = f(
            "Critique and refine the following reasoning chain:\n{reasoning_chain}\n"
            "Ensure the answer is accurate, complete, and directly addresses the question.\n"
            "If necessary, suggest improvements or corrections."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=reasoning_chain)

        # Step 6: Summarize the reasoning process for clarity
        summary_instruction = f(
            "Summarize the following reasoning process:\n{reasoning_chain}\n"
            "Focus on providing a concise explanation of how the answer was derived.\n"
            "Include key supporting facts and logical steps."
        )
        reasoning_summary = await self.summarize(instruction=summary_instruction, context=reasoning_chain)

        return refined_answer