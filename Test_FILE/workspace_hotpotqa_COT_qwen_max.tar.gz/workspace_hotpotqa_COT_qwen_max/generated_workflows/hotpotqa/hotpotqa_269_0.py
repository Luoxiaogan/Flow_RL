# Workflow ID: hotpotqa_269_0
# Benchmark: hotpotqa
# Data Indices: [203]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key entities and terms from the question
        entity_extraction_instruction = """
        Identify all key entities and terms mentioned in the question. Focus on:
        - Named entities (e.g., people, movies, organizations)
        - Descriptive phrases (e.g., "English-American actress and former model")
        - Any specific relationships or constraints implied by the question.
        Return the extracted entities and terms in a structured format.
        """
        extracted_entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Identify relevant documents based on extracted entities
        document_selection_instruction = f"""
        Using the extracted entities and terms: {extracted_entities}, analyze the provided context documents.
        Identify which documents contain information about:
        - The entities mentioned in the question
        - Any shared entities or connections between the documents
        Return a list of relevant documents and their key details.
        """
        relevant_documents = await self.generate(instruction=document_selection_instruction, context=self.problem_text)

        # Step 3: Resolve the shared entity (actress) across documents
        entity_resolution_instruction = f"""
        Based on the relevant documents: {relevant_documents}, identify the shared entity that satisfies the question's criteria:
        - An English-American actress and former model
        - Appeared in both "Gangster No. 1" and "Circle of Friends"
        Provide the name of the actress and any supporting evidence from the documents.
        """
        resolved_entity = await self.generate(instruction=entity_resolution_instruction, context=self.problem_text)

        # Step 4: Extract the specific answer (birth date) from the resolved entity's document
        answer_extraction_instruction = f"""
        Given the resolved entity: {resolved_entity}, locate the document that provides her birth date.
        Extract the birth date and ensure it matches the question's requirements.
        Return the precise answer span (e.g., "22 October 1972").
        """
        final_answer = await self.generate(instruction=answer_extraction_instruction, context=self.problem_text)

        return final_answer