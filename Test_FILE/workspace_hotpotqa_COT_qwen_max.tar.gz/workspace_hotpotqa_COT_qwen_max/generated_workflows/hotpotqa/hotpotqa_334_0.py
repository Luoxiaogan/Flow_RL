# Workflow ID: hotpotqa_334_0
# Benchmark: hotpotqa
# Data Indices: [243]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract relevant sentences mentioning key entities
        entities = ["Special Generation", "MC Hammer"]
        extraction_tasks = [
            self.generate(
                instruction=f"Extract all sentences from the context documents that explicitly mention '{entity}' and its relationships with other entities.",
                context=self.problem_text
            )
            for entity in entities
        ]
        extracted_sentences = await asyncio.gather(*extraction_tasks)

        # Step 2: Identify the bridge entity (song) connecting the two entities
        ensemble_instruction = """
        Analyze the provided sentences and identify the shared entity (likely a song title) that connects 'Special Generation' and 'MC Hammer'.
        Ensure the entity satisfies the following criteria:
        - It is a track that Special Generation provided background vocals for.
        - It is considered MC Hammer's signature song and most successful single.
        """
        bridge_entity = await self.ensemble(
            instruction=ensemble_instruction,
            contexts=extracted_sentences
        )

        # Step 3: Confirm the bridge entity matches the question criteria
        confirmation_instruction = f"""
        Verify that the identified entity '{bridge_entity}' satisfies the following criteria:
        - It is a track that Special Generation sang background vocals for.
        - It is MC Hammer's signature song and most successful single.
        Provide a concise confirmation or rejection based on the evidence.
        """
        confirmation = await self.generate(
            instruction=confirmation_instruction,
            context=self.problem_text
        )

        # Step 4: Summarize the reasoning chain into a concise answer
        summary_instruction = """
        Summarize the reasoning chain into a concise answer that directly addresses the question.
        Include the identified bridge entity and ensure the answer is supported by evidence from the context documents.
        """
        final_answer = await self.summarize(
            instruction=summary_instruction,
            context=confirmation
        )

        return final_answer