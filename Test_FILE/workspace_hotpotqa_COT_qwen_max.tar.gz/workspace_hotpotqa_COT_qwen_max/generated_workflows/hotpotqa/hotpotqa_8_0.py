# Workflow ID: hotpotqa_8_0
# Benchmark: hotpotqa
# Data Indices: [248]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify key entities and select relevant documents
        entity_extraction_instruction = (
            "Extract all named entities mentioned in the question. "
            "For each entity, identify which documents in the provided context contain relevant information. "
            "Return the entities and their associated document titles."
        )
        entity_document_mapping = await self.generate(
            instruction=entity_extraction_instruction,
            context=self.problem_text
        )

        # Step 2: Extract information about each entity
        entities_info = []
        tasks = []
        for line in entity_document_mapping.split("\n"):
            if not line.strip():
                continue
            entity, doc_titles = line.split(":")
            entity = entity.strip()
            doc_titles = [doc.strip() for doc in doc_titles.split(",")]
            for doc_title in doc_titles:
                instruction = (
                    f"Extract all relevant information about '{entity}' from the document titled '{doc_title}'. "
                    "Focus on details such as location, historical context, and relationships with other entities. "
                    "Provide the information in a structured format."
                )
                tasks.append(
                    self.generate(instruction=instruction, context=self.problem_text)
                )
        entity_details = await asyncio.gather(*tasks)

        # Step 3: Revise and refine extracted information
        refined_details = []
        for detail in entity_details:
            refinement_instruction = (
                "Review the provided information and ensure it is accurate and relevant to the question. "
                "Remove any extraneous details and clarify ambiguous statements."
            )
            refined_detail = await self.revise(instruction=refinement_instruction, context=detail)
            refined_details.append(refined_detail)

        # Step 4: Summarize information for reasoning
        summarized_details = []
        for detail in refined_details:
            summary_instruction = (
                "Summarize the key points from the provided information. "
                "Focus on the most critical facts needed to answer the question."
            )
            summary = await self.summarize(instruction=summary_instruction, context=detail)
            summarized_details.append(summary)

        # Step 5: Perform reasoning and synthesize the answer
        reasoning_instruction = (
            "Using the provided summaries, determine whether the Rahmi M. Koç Museum and the Milion are located in the same country. "
            "Compare the locations mentioned in the summaries and provide a clear 'Yes' or 'No' answer."
        )
        final_answer = await self.ensemble(instruction=reasoning_instruction, contexts=summarized_details)

        return final_answer