# Workflow ID: hotpotqa_68_0
# Benchmark: hotpotqa
# Data Indices: [291]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key entities and relationships from the question
        entity_extraction = await self.generate(
            instruction="Identify all key entities mentioned in the question and their relationships. "
                        "Focus on understanding what is being asked and which entities are central to answering it. "
                        "Provide a structured summary of the entities and their roles.",
            context=self.problem_text
        )

        # Step 2: Identify relevant documents containing information about the extracted entities
        document_selection = await self.generate(
            instruction=f"Based on the extracted entities: {entity_extraction}, "
                        "identify which documents contain relevant information. "
                        "For each entity, list the documents that mention it and explain why they are relevant. "
                        "If multiple documents are relevant, prioritize them based on their importance to the question.",
            context=self.problem_text
        )

        # Step 3: Construct reasoning chains across documents
        reasoning_chain = await self.generate(
            instruction=f"Using the relevant documents identified: {document_selection}, "
                        "build a logical chain of facts that connects the entities mentioned in the question. "
                        "Explain how the information in one document leads to or supports the information in another. "
                        "Ensure the reasoning chain directly addresses the question.",
            context=self.problem_text
        )

        # Step 4: Extract the final answer from the reasoning chain
        answer_extraction = await self.generate(
            instruction=f"Based on the reasoning chain constructed: {reasoning_chain}, "
                        "extract the final answer to the question. "
                        "Ensure the answer is concise and directly addresses the question. "
                        "If the answer requires a specific format (e.g., yes/no, entity name), adhere to it.",
            context=self.problem_text
        )

        # Step 5: Refine the answer for clarity and accuracy
        refined_answer = await self.revise(
            instruction="Review the extracted answer and ensure it is clear, accurate, and complete. "
                        "Correct any ambiguities or errors, and ensure it aligns with the reasoning chain.",
            context=answer_extraction
        )

        return refined_answer