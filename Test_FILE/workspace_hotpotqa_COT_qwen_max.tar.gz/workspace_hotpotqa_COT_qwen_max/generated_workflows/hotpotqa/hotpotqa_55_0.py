# Workflow ID: hotpotqa_55_0
# Benchmark: hotpotqa
# Data Indices: [125]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant documents and entities
        extract_instruction = (
            "Identify all entities and keywords in the question. "
            "Match these entities and keywords against the provided context documents. "
            "Return a list of documents that are relevant to answering the question, along with the key entities mentioned."
        )
        relevant_docs = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Resolve entities and establish connections
        resolve_instruction = (
            f"Given the relevant documents: {relevant_docs}, "
            "resolve entities across documents. Identify shared entities or relationships that connect the documents. "
            "For example, if one document mentions a person and another mentions their work, establish the connection."
        )
        resolved_entities = await self.generate(instruction=resolve_instruction, context=self.problem_text)

        # Step 3: Perform logical reasoning to derive the answer
        reason_instruction = (
            f"Using the resolved entities: {resolved_entities}, "
            "perform logical reasoning to answer the question. "
            "Extract specific facts such as dates, names, or properties that directly answer the question."
        )
        reasoning_result = await self.generate(instruction=reason_instruction, context=self.problem_text)

        # Step 4: Refine the result for clarity and accuracy
        refine_instruction = (
            f"Refine the following reasoning result: {reasoning_result}. "
            "Ensure the answer is precise, factually correct, and formatted appropriately."
        )
        refined_answer = await self.revise(instruction=refine_instruction, context=reasoning_result)

        # Step 5: Parallel execution for validation (optional)
        validate_instruction = (
            "Validate the refined answer by cross-referencing it with the original documents. "
            "Ensure all supporting facts are consistent and correctly cited."
        )
        validation_tasks = [
            self.generate(instruction=validate_instruction, context=self.problem_text),
            self.generate(instruction=validate_instruction, context=refined_answer)
        ]
        validation_results = await asyncio.gather(*validation_tasks)

        # Step 6: Synthesize final answer
        ensemble_instruction = (
            "Synthesize the final answer from the following validation results: "
            f"{validation_results}. Ensure the answer is concise and accurate."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=validation_results)

        return final_answer