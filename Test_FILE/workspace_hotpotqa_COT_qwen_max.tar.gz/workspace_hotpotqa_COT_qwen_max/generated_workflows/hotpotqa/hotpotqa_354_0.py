# Workflow ID: hotpotqa_354_0
# Benchmark: hotpotqa
# Data Indices: [384]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key entities and analyze the question
        analysis_instruction = """
        Analyze the question to determine the key entities and their relationships.
        Identify the type of reasoning required (e.g., bridge, comparison).
        Output the key entities and reasoning type in a structured format.
        """
        analysis_result = await self.generate(instruction=analysis_instruction, context=self.problem_text)

        # Step 2: Select relevant documents based on extracted entities
        document_selection_instruction = f"""
        Based on the following analysis: {analysis_result}
        Identify which documents contain information about the key entities.
        Provide a list of relevant document indices or names.
        """
        relevant_documents = await self.generate(instruction=document_selection_instruction, context=self.problem_text)

        # Step 3: Identify the bridge entity connecting the reasoning chain
        bridge_identification_instruction = f"""
        Using the relevant documents: {relevant_documents}
        Find the entity that connects the two parts of the question.
        Ensure the entity is explicitly mentioned in both contexts.
        """
        bridge_candidates = await asyncio.gather(
            self.generate(instruction=bridge_identification_instruction, context=self.problem_text),
            self.generate(instruction=bridge_identification_instruction, context=self.problem_text)
        )
        bridge_entity = await self.ensemble(
            instruction="Select the most plausible bridge entity based on evidence.",
            contexts=bridge_candidates
        )

        # Step 4: Construct the reasoning chain
        reasoning_chain_instruction = f"""
        Using the bridge entity: {bridge_entity}
        Construct a logical reasoning chain that connects the question to the answer.
        Ensure the chain is supported by the documents.
        """
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 5: Extract and refine the final answer
        answer_extraction_instruction = f"""
        From the reasoning chain: {reasoning_chain}
        Extract the precise answer to the question.
        Ensure the answer is concise and directly addresses the question.
        """
        final_answer = await self.summarize(instruction=answer_extraction_instruction, context=self.problem_text)

        return final_answer