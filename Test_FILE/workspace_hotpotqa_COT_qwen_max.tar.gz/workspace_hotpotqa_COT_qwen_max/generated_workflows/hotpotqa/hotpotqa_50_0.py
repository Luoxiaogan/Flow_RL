# Workflow ID: hotpotqa_50_0
# Benchmark: hotpotqa
# Data Indices: [369]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Identify key entities and analyze the question
        question_analysis = await self.generate(
            instruction="Identify the key entities mentioned in the question and analyze what specific attributes or roles are being compared.",
            context=self.problem_text
        )

        # Dynamically extract entities from the analysis
        entities = await self.generate(
            instruction=f"Extract the names of the entities from the following analysis: {question_analysis}. Ensure the entities are clearly separated.",
            context=self.problem_text
        )
        entities_list = [entity.strip() for entity in entities.split(",")]

        # Step 2: Select relevant documents and extract attributes for each entity
        async def process_entity(entity):
            # Find relevant documents for the entity
            relevant_docs = await self.generate(
                instruction=f"Find all documents that mention the entity '{entity}' and extract relevant sentences or paragraphs describing their roles or attributes.",
                context=self.problem_text
            )

            # Extract attributes for the entity
            attributes = await self.generate(
                instruction=f"From the following text about '{entity}', extract their key roles or attributes: {relevant_docs}. Focus on roles like 'writer,' 'journalist,' etc.",
                context=self.problem_text
            )

            # Refine the extracted attributes
            refined_attributes = await self.revise(
                instruction=f"Ensure the following attributes of '{entity}' are accurate and relevant to the question: {attributes}. Remove any irrelevant information.",
                context=self.problem_text
            )

            return entity, refined_attributes

        # Process entities in parallel
        results = await asyncio.gather(*(process_entity(entity) for entity in entities_list))
        entity_attributes = dict(results)

        # Step 3: Compare attributes and determine the answer
        comparison_result = await self.ensemble(
            instruction="Compare the attributes of the entities and determine which one satisfies the condition in the question. Provide a clear justification for your choice.",
            contexts=[f"{entity}: {attributes}" for entity, attributes in entity_attributes.items()]
        )

        # Step 4: Refine the final answer
        final_answer = await self.revise(
            instruction="Refine the following answer to ensure it is concise, accurate, and directly addresses the question: " + comparison_result,
            context=self.problem_text
        )

        return final_answer