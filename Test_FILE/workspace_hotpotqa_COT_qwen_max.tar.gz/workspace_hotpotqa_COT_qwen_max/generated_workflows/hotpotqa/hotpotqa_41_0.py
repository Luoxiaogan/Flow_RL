# Workflow ID: hotpotqa_41_0
# Benchmark: hotpotqa
# Data Indices: [76]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Parse the question to identify key entities and the type of information requested
        question_analysis = await self.generate(
            instruction="""Analyze the question to identify:
            - The primary entity being asked about (e.g., person, organization)
            - Any secondary or bridge entities mentioned
            - The specific type of information requested (e.g., date, location, property comparison)
            Ensure the analysis is detailed and includes all relevant details for downstream processing.""",
            context=self.problem_text
        )

        # Step 2: Identify relevant documents using ensemble selection
        document_selection = await self.ensemble(
            instruction=f"""Given the following analysis of the question: {question_analysis}
            Evaluate each document in the context and determine which ones are most relevant to answering the question.
            Relevance should be based on mentions of the primary entity and any bridge entities identified.
            Provide a ranked list of relevant documents.""",
            contexts=[doc for doc in self.problem_text.split("\n\n")]  # Split documents for ensemble
        )

        # Step 3: Summarize relevant information from the selected documents
        summary = await self.summarize(
            instruction=f"""Using the selected document(s): {document_selection}
            Summarize the key information related to the primary entity and any bridge entities.
            Focus on facts that directly address the question's request.""",
            context=document_selection
        )

        # Step 4: Extract the final answer
        answer_extraction = await self.generate(
            instruction=f"""Based on the following summary: {summary}
            Extract the precise answer to the question.
            Ensure the answer is concise, accurate, and supported by the text.""",
            context=summary
        )

        # Step 5: Refine the answer for clarity and correctness
        refined_answer = await self.revise(
            instruction="""Critique and refine the extracted answer to ensure:
            - It is grammatically correct and concise
            - It directly answers the question
            - It is supported by the provided context""",
            context=answer_extraction
        )

        return refined_answer