# Workflow ID: hotpotqa_359_0
# Benchmark: hotpotqa
# Data Indices: [4]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Analyze the question to identify type and key entities
        question_analysis = await self.generate(
            instruction="Analyze the question to determine its type (e.g., bridge, comparison, compositional) and extract key entities. "
                        "Provide a structured output with the question type and a list of key entities.",
            context=self.problem_text
        )

        # Dynamically construct instructions based on extracted entities
        entities = await self.generate(
            instruction="Extract all named entities (e.g., people, places, organizations, years) mentioned in the question. "
                        "Format the output as a JSON list of entities.",
            context=question_analysis
        )

        # Step 2: Identify relevant documents
        relevant_docs = await self.generate(
            instruction=f"Given the extracted entities: {entities}, identify which documents contain information "
                        "relevant to these entities. Provide a list of document indices or titles.",
            context=self.problem_text
        )

        # Step 3: Resolve shared entities and build reasoning chains
        reasoning_steps = await asyncio.gather(
            self.generate(
                instruction=f"For each entity in {entities}, extract relevant facts from the documents listed in {relevant_docs}. "
                            "Focus on connecting entities across documents to form a reasoning chain.",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"Identify any bridging entities that connect the documents in {relevant_docs}. "
                            "Explain how these entities relate to the question.",
                context=self.problem_text
            )
        )

        # Step 4: Synthesize the answer
        synthesized_answer = await self.ensemble(
            instruction="Combine the provided reasoning steps into a concise and coherent answer. "
                        "Ensure the answer directly addresses the question and includes supporting evidence.",
            contexts=reasoning_steps
        )

        # Step 5: Validate and refine the answer
        refined_answer = await self.revise(
            instruction="Review the synthesized answer for accuracy and clarity. "
                        "Refine the answer if necessary, ensuring it is precise and well-supported.",
            context=synthesized_answer
        )

        return refined_answer