# Workflow ID: hotpotqa_122_0
# Benchmark: hotpotqa
# Data Indices: [89]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract key entities and their details from the question and context
        entity_extraction_instruction = """
        Identify all named entities mentioned in the question and context documents.
        For each entity, extract relevant details such as birthdates, roles, or other distinguishing properties.
        Ensure the output is structured as a list of entities with their associated details.
        """
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Determine relevance of each document to the extracted entities
        relevance_instruction = f"""
        Analyze each document in the context and score its relevance to the following entities:
        {entities}
        Focus on documents that provide factual information about these entities.
        Return a list of relevant documents along with their relevance scores.
        """
        relevant_documents = await self.generate(instruction=relevance_instruction, context=self.problem_text)

        # Step 3: Extract specific facts from relevant documents
        fact_extraction_tasks = []
        for doc in relevant_documents.split("\n"):  # Assuming documents are newline-separated
            fact_extraction_instruction = f"""
            Extract all factual information related to the entities {entities} from the following document:
            {doc}
            Focus on properties like birthdates, roles, or other attributes that could help answer the question.
            Structure the output as a dictionary of entity-to-fact mappings.
            """
            fact_extraction_tasks.append(self.generate(instruction=fact_extraction_instruction, context=doc))
        
        # Execute fact extraction in parallel
        extracted_facts = await asyncio.gather(*fact_extraction_tasks)

        # Step 4: Compare facts and synthesize the answer
        comparison_instruction = f"""
        Given the following extracted facts about the entities {entities}:
        {extracted_facts}
        Perform the necessary comparisons or logical reasoning to answer the question.
        For example, if the question asks "Who was born earlier?", compare the birthdates of the entities.
        Ensure the reasoning process is explicit and the answer is concise.
        """
        answer = await self.ensemble(instruction=comparison_instruction, contexts=extracted_facts)

        return answer