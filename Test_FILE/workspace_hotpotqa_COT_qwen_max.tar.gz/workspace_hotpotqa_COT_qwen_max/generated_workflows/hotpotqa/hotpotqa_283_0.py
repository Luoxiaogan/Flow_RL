# Workflow ID: hotpotqa_283_0
# Benchmark: hotpotqa
# Data Indices: [1]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract the person associated with the order
        person_extraction = await self.generate(
            instruction="Identify the person known for giving the order to soldiers to conserve their limited stocks of ammunition. "
                        "Provide the name of the person and any relevant context from the documents.",
            context=self.problem_text
        )
        person_refined = await self.revise(
            instruction="Refine the extracted information to confirm the name of the person and their association with the order. "
                        "Ensure the output is precise and accurate.",
            context=person_extraction
        )

        # Step 2: Extract the birthplace of the identified person
        birthplace_extraction = await self.generate(
            instruction=f"Based on the identified person ({person_refined}), determine their birthplace. "
                        "Provide the name of the location and any supporting evidence from the documents.",
            context=self.problem_text
        )
        birthplace_refined = await self.revise(
            instruction="Refine the extracted birthplace information to ensure accuracy. "
                        "Confirm the location and its relevance to the identified person.",
            context=birthplace_extraction
        )

        # Step 3: Identify prep schools in the birthplace
        prep_schools_extraction = await self.generate(
            instruction=f"Find all prep schools located in {birthplace_refined}. "
                        "Provide the names of the schools and any supporting evidence from the documents.",
            context=self.problem_text
        )
        prep_schools_refined = await self.revise(
            instruction="Refine the list of prep schools to ensure accuracy. "
                        "Include only those explicitly mentioned in the context and confirm their relevance.",
            context=prep_schools_extraction
        )

        # Step 4: Synthesize the final answer
        final_answer = await self.ensemble(
            instruction="Combine the refined information about the person, their birthplace, and the prep schools. "
                        "Produce a concise answer to the question: 'Which two prep schools are located in the birthplace of the one known for the order given to soldiers to conserve their limited stocks of ammunition?'",
            contexts=[person_refined, birthplace_refined, prep_schools_refined]
        )

        return final_answer