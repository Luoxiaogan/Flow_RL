# Workflow ID: hotpotqa_76_0
# Benchmark: hotpotqa
# Data Indices: [57]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Understand the question and identify key entities
        question_analysis = await self.generate(
            instruction="Analyze the question to identify key entities, numerical requirements, and the type of information being requested. "
                        "Focus on extracting explicit details such as units of measurement, entities, and relationships.",
            context=self.problem_text
        )

        # Step 2: Evaluate document relevance
        documents = [
            "Document 1: W.A.K.O. World Championships 2005 (Szeged)...",
            "Document 2: Jody Santos...",
            "Document 3: International Biology Olympiad...",
            "Document 4: Parkrun...",
            "Document 5: Crescent Enterprises...",
            "Document 6: 5K run...",
            "Document 7: Centennial Beach...",
            "Document 8: Carlos St. James...",
            "Document 9: Doro (telecoms)...",
            "Document 10: Datamyne..."
        ]

        relevance_tasks = [
            self.generate(
                instruction=f"Assess the relevance of this document to the question. "
                            f"Consider whether it contains information about key entities or numerical data related to the query. "
                            f"Provide a score (0-10) and a brief justification.\n\n"
                            f"Question Analysis:\n{question_analysis}",
                context=doc
            )
            for doc in documents
        ]
        relevance_results = await asyncio.gather(*relevance_tasks)

        # Step 3: Select top relevant documents
        top_documents = await self.ensemble(
            instruction="Select the most relevant documents based on their scores and justifications. "
                        "Prioritize documents with high scores and clear relevance to the question.",
            contexts=relevance_results
        )

        # Step 4: Extract supporting facts from relevant documents
        fact_extraction_tasks = [
            self.generate(
                instruction=f"Extract all sentences or facts from this document that are relevant to the question. "
                            f"Focus on numerical data, entity mentions, and relationships.\n\n"
                            f"Question Analysis:\n{question_analysis}",
                context=doc
            )
            for doc in top_documents.split("\n---\n")  # Assuming documents are separated by "---"
        ]
        supporting_facts = await asyncio.gather(*fact_extraction_tasks)

        # Step 5: Reasoning and fact chaining
        reasoning = await self.generate(
            instruction=f"Combine the extracted facts into a coherent reasoning process to answer the question. "
                        f"Ensure all numerical conversions (e.g., kilometers to miles) are handled explicitly. "
                        f"Provide a step-by-step explanation of how the answer is derived.\n\n"
                        f"Supporting Facts:\n{' '.join(supporting_facts)}",
            context=self.problem_text
        )

        # Step 6: Extract the final answer
        final_answer = await self.summarize(
            instruction="Extract the precise answer from the reasoning process. "
                        "Ensure the answer is concise and matches the expected format (e.g., numerical value, entity name).",
            context=reasoning
        )

        return final_answer