# Workflow ID: hotpotqa_207_0
# Benchmark: hotpotqa
# Data Indices: [273]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract entities and classify reasoning type
        entity_extraction_instruction = """
        Analyze the question and extract all key entities mentioned. 
        Classify the reasoning type as one of the following:
        - Bridge: Requires connecting information across multiple documents via a shared entity.
        - Comparison: Requires comparing properties of entities across documents.
        - Compositional: Requires combining multiple facts to derive the answer.
        Provide the extracted entities and reasoning type in JSON format.
        """
        entity_data = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)
        
        # Dynamically incorporate extracted entities into subsequent instructions
        entities = eval(entity_data)  # Convert JSON string to dictionary
        key_entities = entities.get("entities", [])
        reasoning_type = entities.get("reasoning_type", "unknown")

        # Step 2: Select relevant documents
        document_selection_instruction = f"""
        Based on the extracted entities ({', '.join(key_entities)}) and reasoning type ({reasoning_type}), 
        identify which documents are relevant to answering the question. 
        Provide a list of document indices or titles that contain pertinent information.
        """
        relevant_documents = await self.generate(instruction=document_selection_instruction, context=self.problem_text)

        # Step 3: Construct reasoning chain
        reasoning_chain_instruction = f"""
        Using the relevant documents ({relevant_documents}) and the reasoning type ({reasoning_type}), 
        construct a reasoning chain that connects the key entities ({', '.join(key_entities)}).
        For bridge questions, identify the bridge entity.
        For comparison questions, extract comparable properties.
        For compositional questions, chain multiple facts together.
        Provide the reasoning chain in a structured format.
        """
        reasoning_chain = await self.revise(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 4: Extract the final answer
        answer_extraction_instruction = f"""
        Based on the reasoning chain ({reasoning_chain}), extract the precise answer span from the relevant documents.
        Ensure the answer is concise and directly addresses the question.
        """
        final_answer = await self.summarize(instruction=answer_extraction_instruction, context=self.problem_text)

        # Step 5: Validate the final answer (optional ensemble step)
        validation_instruction = f"""
        Validate the extracted answer ({final_answer}) against the reasoning chain ({reasoning_chain}).
        If multiple candidate answers exist, select the most accurate one.
        """
        validated_answer = await self.ensemble(instruction=validation_instruction, contexts=[final_answer, reasoning_chain])

        return validated_answer