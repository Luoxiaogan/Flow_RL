# Workflow ID: hotpotqa_113_0
# Benchmark: hotpotqa
# Data Indices: [209]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract entities and analyze the question
        question_analysis = await self.generate(
            instruction="Analyze the question to identify key entities, relationships, and the type of reasoning required (e.g., bridge, comparison). "
                        "Provide a structured breakdown of the question's components.",
            context=self.problem_text
        )

        # Step 2: Analyze each document for relevance
        documents = [f"Document {i+1}" for i in range(10)]  # Assuming 10 documents
        relevance_tasks = [
            self.generate(
                instruction=f"Determine if this document is relevant to the entities and relationships identified in the question. "
                            f"Key entities: {question_analysis}. Focus on finding connections between these entities.",
                context=f"{doc}: {getattr(self, f'document_{i+1}', '')}"
            )
            for i, doc in enumerate(documents)
        ]
        relevance_results = await asyncio.gather(*relevance_tasks)

        # Step 3: Synthesize information from relevant documents
        relevant_documents = [
            doc for doc, result in zip(documents, relevance_results) if "relevant" in result.lower()
        ]
        synthesis = await self.ensemble(
            instruction="Synthesize information from the following relevant documents to answer the question. "
                        "Build a reasoning chain that connects the entities and resolves the query. "
                        f"Relevant documents: {', '.join(relevant_documents)}. Key entities: {question_analysis}.",
            contexts=relevance_results
        )

        # Step 4: Extract and refine the final answer
        final_answer = await self.revise(
            instruction="Refine the synthesized information into a concise and precise answer. "
                        "Ensure the answer directly addresses the question and includes supporting facts if necessary.",
            context=synthesis
        )

        return final_answer