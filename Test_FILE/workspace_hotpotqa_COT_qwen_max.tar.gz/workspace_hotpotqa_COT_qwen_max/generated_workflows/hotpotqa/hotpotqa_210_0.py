# Workflow ID: hotpotqa_210_0
# Benchmark: hotpotqa
# Data Indices: [61]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Identify relevant documents
        relevant_docs_instruction = (
            "Identify all documents that mention 'Future and Emerging Technologies' or related projects. "
            "Focus on extracting document titles and key sentences that describe these technologies or projects."
        )
        relevant_docs = await self.generate(instruction=relevant_docs_instruction, context=self.problem_text)

        # Step 2: Extract key entities and facts
        entity_extraction_instruction = (
            f"From the following relevant documents:\n{relevant_docs}\n"
            "Extract key entities such as project names and their associated founding years or other relevant facts. "
            "Ensure the output is structured as a list of entities and their attributes."
        )
        extracted_entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 3: Refine reasoning chain
        reasoning_refinement_instruction = (
            f"Given the extracted entities and facts:\n{extracted_entities}\n"
            "Construct a logical reasoning chain to connect the entities and facts. "
            "Ensure the chain explicitly shows how the entities relate to each other and lead to the answer."
        )
        refined_reasoning = await self.revise(instruction=reasoning_refinement_instruction, context=extracted_entities)

        # Step 4: Ensemble to resolve ambiguities
        ensemble_instruction = (
            f"Given the following reasoning chain:\n{refined_reasoning}\n"
            "Evaluate the reasoning and determine the most accurate answer. "
            "If there are conflicting facts, resolve them based on the provided context."
        )
        candidate_answers = [refined_reasoning]  # Add more candidates if needed
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=candidate_answers)

        # Step 5: Summarize the final answer
        summarization_instruction = (
            f"From the following reasoning and decision:\n{final_answer}\n"
            "Extract the precise answer span that directly answers the question."
        )
        answer_span = await self.summarize(instruction=summarization_instruction, context=final_answer)

        return answer_span