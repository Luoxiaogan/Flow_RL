# Workflow ID: hotpotqa_57_0
# Benchmark: hotpotqa
# Data Indices: [87]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract Entities, Relationships, and Key Facts
        extraction_instruction = """
        Extract all named entities (people, organizations, locations, etc.), relationships, and key facts from the provided documents. 
        Ensure that the extraction is comprehensive and includes all potentially relevant information for multi-hop reasoning.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Identify Reasoning Type
        reasoning_type_instruction = f"""
        Analyze the question and determine the type of reasoning required. The reasoning types include:
        - Bridge: Connecting information through a shared entity across documents.
        - Comparison: Comparing properties or attributes of entities mentioned in different documents.
        - Compositional: Combining multiple facts to derive the answer.
        Use the extracted information: {extracted_info} to classify the reasoning type.
        """
        reasoning_type = await self.generate(instruction=reasoning_type_instruction, context=self.problem_text)

        # Step 3: Identify Bridge Entity or Shared Facts
        bridge_entity_instruction = f"""
        Based on the reasoning type identified as "{reasoning_type}", identify the bridge entity or shared facts that connect the documents. 
        For bridge questions, find the entity that links multiple documents. For comparison or compositional questions, identify the shared properties or facts.
        Use the extracted information: {extracted_info} to perform this task.
        """
        bridge_entity = await self.generate(instruction=bridge_entity_instruction, context=self.problem_text)

        # Step 4: Construct Reasoning Chain and Derive Answer
        reasoning_chain_instruction = f"""
        Using the identified bridge entity or shared facts: "{bridge_entity}", construct a reasoning chain to derive the answer. 
        Connect information across documents and synthesize the final response. Ensure that the reasoning chain is explicit and logical.
        """
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 5: Validate and Refine the Answer
        refinement_instruction = f"""
        Critique and refine the constructed reasoning chain: "{reasoning_chain}". 
        Cross-check the derived answer against the original documents to ensure accuracy and completeness. 
        If necessary, revise the answer to improve clarity and correctness.
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=reasoning_chain)

        return refined_answer