# Workflow ID: hotpotqa_234_0
# Benchmark: hotpotqa
# Data Indices: [45]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Parse the question to identify key entities and reasoning type
        question_analysis = await self.generate(
            instruction="Analyze the question to identify key entities and the type of reasoning required. "
                        "Output the entities and reasoning type in JSON format.",
            context=self.problem_text
        )
        
        # Dynamically incorporate extracted entities into subsequent instructions
        entities = json.loads(question_analysis)
        primary_entity = entities.get("primary_entity", "")
        secondary_entity = entities.get("secondary_entity", "")
        reasoning_type = entities.get("reasoning_type", "")

        # Step 2: Identify relevant documents containing information about the entities
        document_selection = await self.generate(
            instruction=f"Identify which documents contain information about {primary_entity} and {secondary_entity}. "
                        f"Output the document indices as a list in JSON format.",
            context=self.problem_text
        )
        relevant_documents = json.loads(document_selection)

        # Step 3: Extract specific facts from the relevant documents
        extraction_tasks = [
            self.generate(
                instruction=f"Extract all relevant information about {primary_entity} from Document {doc_index}.",
                context=self.problem_text
            )
            for doc_index in relevant_documents
        ]
        extracted_facts = await asyncio.gather(*extraction_tasks)

        # Step 4: Summarize the extracted facts for clarity
        summarization_tasks = [
            self.summarize(
                instruction=f"Condense the information about {primary_entity} from Document {doc_index}, "
                            f"focusing on key facts related to the question.",
                context=fact
            )
            for doc_index, fact in zip(relevant_documents, extracted_facts)
        ]
        summarized_facts = await asyncio.gather(*summarization_tasks)

        # Step 5: Construct the reasoning chain using Ensemble
        reasoning_chain = await self.ensemble(
            instruction=f"Combine the summarized facts to construct a reasoning chain that answers the question. "
                        f"Focus on connecting {primary_entity} and {secondary_entity} logically.",
            contexts=summarized_facts
        )

        # Step 6: Refine the final answer for clarity and correctness
        final_answer = await self.revise(
            instruction="Refine the reasoning chain into a concise and clear answer. "
                        "Ensure the response directly addresses the question.",
            context=reasoning_chain
        )

        return final_answer