# Workflow ID: hotpotqa_305_0
# Benchmark: hotpotqa
# Data Indices: [353]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Identify entities in the question
        entity_identification = await self.generate(
            instruction="Identify all named entities (people, organizations, etc.) mentioned in the question. "
                        "Return them as a comma-separated list.",
            context=self.problem_text
        )

        # Dynamically construct instructions for extracting relevant contexts
        entities = [entity.strip() for entity in entity_identification.split(",")]
        extraction_instructions = [
            f"Extract all sentences or paragraphs from the context documents that mention {entity}. "
            f"Focus on information related to their profession or roles."
            for entity in entities
        ]

        # Step 2: Extract relevant contexts for each entity
        extraction_tasks = [
            self.generate(instruction=instr, context=self.problem_text)
            for instr in extraction_instructions
        ]
        extracted_contexts = await asyncio.gather(*extraction_tasks)

        # Step 3: Analyze professions for each entity
        profession_analysis_tasks = [
            self.generate(
                instruction=f"Based on the provided context, determine the profession(s) of {entities[i]}. "
                            f"Provide a concise summary of their role or occupation.",
                context=extracted_contexts[i]
            )
            for i in range(len(entities))
        ]
        profession_results = await asyncio.gather(*profession_analysis_tasks)

        # Step 4: Compare professions and find commonalities
        comparison_instruction = (
            "Compare the professions of the following entities and identify any common roles or occupations. "
            "Provide a brief explanation of the shared profession(s)."
        )
        common_profession = await self.ensemble(
            instruction=comparison_instruction,
            contexts=profession_results
        )

        # Step 5: Refine the final answer
        final_answer = await self.revise(
            instruction="Refine the provided text to extract the precise answer span. "
                        "Ensure the response is concise and directly answers the question.",
            context=common_profession
        )

        return final_answer