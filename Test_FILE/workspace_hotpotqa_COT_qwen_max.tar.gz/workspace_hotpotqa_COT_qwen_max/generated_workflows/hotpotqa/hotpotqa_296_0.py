# Workflow ID: hotpotqa_296_0
# Benchmark: hotpotqa
# Data Indices: [2]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Analyze the question and identify key entities
        question_analysis = await self.generate(
            instruction="Analyze the question to identify key entities and their relationships. "
                        "Focus on understanding what information is being asked and how it might connect across documents. "
                        "Provide a structured breakdown of the entities and their potential connections.",
            context=self.problem_text
        )

        # Step 2: Filter documents for relevant mentions of key entities
        document_filtering = await self.generate(
            instruction=f"Based on the identified entities: {question_analysis}, "
                        "filter the context documents to find mentions of these entities. "
                        "For each document, extract sentences or paragraphs that contain relevant information. "
                        "Ensure the output includes the document name and the extracted text.",
            context=self.problem_text
        )

        # Step 3: Identify shared entities or relationships across documents
        entity_matching = await self.ensemble(
            instruction=f"Compare the extracted information from the filtered documents: {document_filtering}. "
                        "Identify shared entities or relationships that connect the documents. "
                        "Construct a reasoning chain that links the entities across documents. "
                        "If multiple connections are possible, evaluate their validity and select the most plausible one.",
            contexts=[document_filtering]
        )

        # Step 4: Construct and refine the reasoning chain
        reasoning_chain = await self.revise(
            instruction=f"Refine the reasoning chain: {entity_matching}. "
                        "Ensure the chain is logically consistent and supported by evidence from the context documents. "
                        "If necessary, revise the chain to address any inconsistencies or missing links.",
            context=entity_matching
        )

        # Step 5: Extract and summarize the final answer
        final_answer = await self.summarize(
            instruction=f"Extract the final answer from the refined reasoning chain: {reasoning_chain}. "
                        "Ensure the answer is concise, precise, and directly addresses the question. "
                        "Include supporting evidence from the context documents if required.",
            context=reasoning_chain
        )

        return final_answer