# Workflow ID: hotpotqa_258_0
# Benchmark: hotpotqa
# Data Indices: [385]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract entities and key facts from all documents
        extraction_instruction = """
        Extract all named entities (people, organizations, locations, dates, etc.) and key facts from the provided documents.
        Focus on information that could be relevant to answering the question. Format the output as a list of items.
        """
        extracted_facts = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Identify the reasoning type and construct a reasoning chain
        reasoning_instruction = f"""
        Analyze the extracted facts below and determine the reasoning type required to answer the question.
        Reasoning types include:
        - Bridge: Connecting information across documents through shared entities.
        - Comparison: Comparing properties of entities mentioned in different documents.
        - Compositional: Combining multiple facts to derive the answer.
        Based on the reasoning type, construct a reasoning chain that connects the relevant facts to answer the question.
        Extracted Facts: {extracted_facts}
        """
        reasoning_chain = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Synthesize an initial answer using the reasoning chain
        synthesis_instruction = f"""
        Using the reasoning chain below, synthesize an initial answer to the question. Ensure the answer is precise and supported by the facts.
        Reasoning Chain: {reasoning_chain}
        """
        initial_answer = await self.generate(instruction=synthesis_instruction, context=self.problem_text)

        # Step 4: Refine the initial answer
        refinement_instruction = f"""
        Review the initial answer below and refine it for accuracy, clarity, and completeness. Ensure it directly addresses the question.
        Initial Answer: {initial_answer}
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=self.problem_text)

        # Step 5: Resolve ambiguities or combine multiple reasoning paths if needed
        ensemble_instruction = f"""
        Evaluate the refined answer below. If there are multiple possible interpretations or reasoning paths, resolve ambiguities and provide the most accurate answer.
        Refined Answer: {refined_answer}
        """
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[refined_answer])

        return final_answer