# Workflow ID: hotpotqa_241_0
# Benchmark: hotpotqa
# Data Indices: [185]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Generate initial analysis to extract key entities and identify relevant documents
        initial_analysis = await self.generate(
            instruction="""
            Analyze the question and identify the key entities involved. 
            Extract the name of the painting and the painter mentioned in the question. 
            Determine which documents are likely to contain relevant information about the painting and the painter. 
            Provide a brief explanation of your reasoning.
            """,
            context=self.problem_text
        )

        # Step 2: Summarize relevant documents focusing on the painter and their biographical details
        summaries = await asyncio.gather(
            self.summarize(
                instruction=f"""
                Summarize the document focusing on the painter '{initial_analysis.split('painter: ')[-1].split()[0]}'. 
                Include any biographical details such as birth year, death year, or notable works. 
                Ensure the summary is concise and directly relevant to the question.
                """,
                context=doc
            )
            for doc in ["Document 3", "Document 4"]  # Dynamically select relevant documents
        )

        # Step 3: Ensemble candidate answers to synthesize the birth year of the painter
        ensemble_result = await self.ensemble(
            instruction="""
            Compare the provided summaries and extract the birth year of the painter. 
            If there are discrepancies, resolve them by prioritizing the most reliable source. 
            Provide a clear and concise answer with supporting reasoning.
            """,
            contexts=summaries
        )

        # Step 4: Revise the final answer to ensure precision and clarity
        final_answer = await self.revise(
            instruction="""
            Refine the provided answer to ensure it is precise, well-supported, and formatted correctly. 
            Include the birth year of the painter and a brief explanation of how it was derived.
            """,
            context=ensemble_result
        )

        return final_answer