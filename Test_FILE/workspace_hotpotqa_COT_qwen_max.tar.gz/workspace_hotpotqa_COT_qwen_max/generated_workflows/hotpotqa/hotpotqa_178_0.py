# Workflow ID: hotpotqa_178_0
# Benchmark: hotpotqa
# Data Indices: [222]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key entities (e.g., Robert I. Rotberg, Program, School)
        entity_extraction = await self.generate(
            instruction="Extract all entities mentioned in the question, including names of people, programs, and institutions.",
            context=self.problem_text
        )

        # Step 2: Identify relevant documents mentioning these entities
        relevant_documents = await asyncio.gather(
            *[self.generate(
                instruction=f"Identify documents that mention {entity} and summarize their relevance to the question.",
                context=self.problem_text
            ) for entity in ["Robert I. Rotberg", "Program on Intrastate Conflict, Conflict Prevention, and Conflict Resolution"]]
        )

        # Step 3: Summarize relationships between entities in relevant documents
        relationship_summary = await self.summarize(
            instruction=f"Summarize the relationships between the entities {entity_extraction} based on the following documents: {relevant_documents}.",
            context=self.problem_text
        )

        # Step 4: Construct reasoning chain to connect Robert I. Rotberg to the type of school
        reasoning_chain = await self.generate(
            instruction=f"Build a reasoning chain connecting Robert I. Rotberg to the type of school he is associated with, using the following summary: {relationship_summary}.",
            context=self.problem_text
        )

        # Step 5: Extract the precise answer span
        answer_extraction = await self.generate(
            instruction=f"Extract the precise answer span from the reasoning chain that identifies the type of school: {reasoning_chain}.",
            context=self.problem_text
        )

        # Step 6: Refine the answer for clarity and correctness
        refined_answer = await self.revise(
            instruction="Ensure the answer is clear, concise, and directly addresses the question.",
            context=answer_extraction
        )

        return refined_answer