# Workflow ID: hotpotqa_317_0
# Benchmark: hotpotqa
# Data Indices: [336]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio
        
        # Step 1: Identify key entities and analyze the question
        question_analysis = await self.generate(
            instruction="Analyze the question to identify key entities and what information is being asked for. "
                        "Extract the entities and describe the type of information required (e.g., birth date, nationality).",
            context=self.problem_text
        )
        
        # Step 2: Select relevant documents based on identified entities
        document_selection_tasks = [
            self.generate(
                instruction=f"Scan this document to determine if it contains information about the entities: {question_analysis}. "
                            "If relevant, summarize the key facts related to the entities.",
                context=document
            )
            for document in self.problem_text.split("\n\n")  # Assuming documents are separated by double newlines
        ]
        document_summaries = await asyncio.gather(*document_selection_tasks)
        
        # Step 3: Extract and cross-reference facts from relevant documents
        fact_extraction_tasks = [
            self.generate(
                instruction=f"Extract specific facts related to the entities: {question_analysis} from this summary. "
                            "Focus on information that directly answers the question.",
                context=summary
            )
            for summary in document_summaries if "relevant" in summary.lower()
        ]
        extracted_facts = await asyncio.gather(*fact_extraction_tasks)
        
        # Step 4: Synthesize the answer using Ensemble
        synthesized_answer = await self.ensemble(
            instruction="Combine the extracted facts to form a concise and accurate answer to the question. "
                        "Ensure the response directly addresses the question and includes all necessary details.",
            contexts=extracted_facts
        )
        
        # Step 5: Revise the answer for clarity and correctness
        final_answer = await self.revise(
            instruction="Review the synthesized answer for accuracy, clarity, and completeness. "
                        "Make any necessary improvements to ensure it is well-formatted and directly answers the question.",
            context=synthesized_answer
        )
        
        return final_answer