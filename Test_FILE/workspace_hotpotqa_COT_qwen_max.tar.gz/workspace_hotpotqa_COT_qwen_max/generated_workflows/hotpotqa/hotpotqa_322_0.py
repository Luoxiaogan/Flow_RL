# Workflow ID: hotpotqa_322_0
# Benchmark: hotpotqa
# Data Indices: [316]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Identify relevant documents and entities
        entity_extraction_instruction = """
        Identify all key entities mentioned in the question, including the names of songs, groups, and any other relevant terms.
        Focus on finding mentions of "Girls Aloud," "Beautiful 'Cause You Love Me," and any British music chart television programmes.
        """
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Extract information about the song and its performance
        song_info_instruction = f"""
        From the provided documents, extract detailed information about the song "Beautiful 'Cause You Love Me."
        Specifically, look for mentions of where the song was performed or appeared on television programmes.
        Use the following entities as a guide: {entities}.
        """
        song_info = await self.generate(instruction=song_info_instruction, context=self.problem_text)

        # Step 3: Identify the relevant programme and confirm its nature
        programme_info_instruction = f"""
        Based on the extracted information about the song "Beautiful 'Cause You Love Me," identify the British music chart television programme mentioned.
        Cross-reference with other documents to confirm that the programme is indeed a British music chart television show.
        Use the following song information as a guide: {song_info}.
        """
        programme_info = await self.generate(instruction=programme_info_instruction, context=self.problem_text)

        # Step 4: Parallelize document relevance checks
        relevant_docs_instruction = f"""
        Identify which documents are most relevant to answering the question based on the extracted entities and song information.
        Focus on documents mentioning "Girls Aloud," "Beautiful 'Cause You Love Me," and the identified programme.
        """
        relevant_docs_task = asyncio.create_task(self.generate(instruction=relevant_docs_instruction, context=self.problem_text))

        # Step 5: Summarize the answer
        summary_instruction = f"""
        Condense the extracted information into a concise answer that directly addresses the question.
        Ensure the answer specifies the British music chart television programme where "Girls Aloud" performed "Beautiful 'Cause You Love Me."
        Use the following programme information as a guide: {programme_info}.
        """
        summary_task = asyncio.create_task(self.summarize(instruction=summary_instruction, context=programme_info))

        # Wait for parallel tasks to complete
        relevant_docs, summary = await asyncio.gather(relevant_docs_task, summary_task)

        # Step 6: Finalize the answer
        final_answer_instruction = f"""
        Ensure the final answer is precise and factually correct.
        Incorporate the following relevant document information: {relevant_docs}.
        Finalize the answer based on the summary: {summary}.
        """
        final_answer = await self.revise(instruction=final_answer_instruction, context=summary)

        return final_answer