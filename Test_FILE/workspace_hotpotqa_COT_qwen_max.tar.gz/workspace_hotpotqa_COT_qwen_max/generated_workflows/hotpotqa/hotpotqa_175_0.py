# Workflow ID: hotpotqa_175_0
# Benchmark: hotpotqa
# Data Indices: [178]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify key entities and relevant documents
        entity_instruction = """
        Identify all key entities mentioned in the question. These could be names of people, companies, brands, or other important nouns. 
        Then, determine which documents contain information about these entities. 
        Provide a list of entities and their corresponding document numbers.
        """
        entities_and_docs = await self.generate(instruction=entity_instruction, context=self.problem_text)

        # Step 2: Extract relevant sentences and bridge entities
        extract_instruction = f"""
        Based on the identified entities and their corresponding documents ({entities_and_docs}), 
        extract sentences from these documents that mention the entities. 
        Look for sentences that connect or provide additional information about the entities.
        """
        extraction_tasks = [
            self.generate(instruction=extract_instruction, context=self.problem_text)
        ]
        extracted_sentences = await asyncio.gather(*extraction_tasks)

        # Step 3: Identify the bridge entity and chain information
        bridge_instruction = f"""
        From the extracted sentences ({extracted_sentences}), identify the bridge entity that connects the key entities across documents. 
        Then, trace the information chain to find the final answer. 
        Provide a reasoning chain that explains how the answer is derived.
        """
        reasoning_chain = await self.generate(instruction=bridge_instruction, context=self.problem_text)

        # Step 4: Summarize supporting facts
        summarize_instruction = f"""
        Summarize the key supporting facts from the reasoning chain ({reasoning_chain}). 
        Ensure the summary includes all necessary information to support the final answer.
        """
        supporting_facts = await self.summarize(instruction=summarize_instruction, context=reasoning_chain)

        # Step 5: Synthesize the final answer
        ensemble_instruction = f"""
        Based on the reasoning chain ({reasoning_chain}) and supporting facts ({supporting_facts}), 
        synthesize the final answer to the question. 
        Ensure the answer is concise and directly addresses the question.
        """
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[reasoning_chain, supporting_facts])

        return final_answer