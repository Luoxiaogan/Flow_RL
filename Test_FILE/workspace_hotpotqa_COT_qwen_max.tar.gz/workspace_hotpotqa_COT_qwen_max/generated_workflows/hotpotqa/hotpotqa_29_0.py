# Workflow ID: hotpotqa_29_0
# Benchmark: hotpotqa
# Data Indices: [258]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key terms from the question and match them against documents
        extract_instruction = (
            "Extract all key entities, names, and terms from the question. "
            "Then, identify which documents contain information about these entities. "
            "Provide a list of relevant documents along with the matching terms."
        )
        relevant_documents = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Identify relationships and bridge entities
        relationship_instruction = (
            f"Using the relevant documents identified: {relevant_documents}, "
            "analyze the relationships between the entities mentioned in the question. "
            "Look for shared entities, bridging terms, or contextual connections that link the documents. "
            "Provide a detailed explanation of how the entities are related."
        )
        relationships = await self.generate(instruction=relationship_instruction, context=self.problem_text)

        # Step 3: Summarize relevant information from each document
        summarize_instructions = [
            f"Summarize the information in this document related to the entities and relationships identified: {doc}. "
            "Focus on facts that contribute to answering the question."
            for doc in relevant_documents.split("\n") if doc.strip()
        ]
        summaries = await asyncio.gather(
            *[self.summarize(instruction=instr, context=self.problem_text) for instr in summarize_instructions]
        )

        # Step 4: Synthesize summaries into a reasoning chain
        synthesis_instruction = (
            "Given the following summaries from multiple documents, synthesize them into a coherent reasoning chain. "
            "Ensure the chain explicitly connects the entities mentioned in the question and leads to the answer."
        )
        reasoning_chain = await self.ensemble(instruction=synthesis_instruction, contexts=summaries)

        # Step 5: Extract the final answer
        answer_instruction = (
            f"Based on the reasoning chain: {reasoning_chain}, "
            "extract the precise answer to the question. Ensure the answer is concise and directly addresses the question."
        )
        final_answer = await self.generate(instruction=answer_instruction, context=self.problem_text)

        return final_answer