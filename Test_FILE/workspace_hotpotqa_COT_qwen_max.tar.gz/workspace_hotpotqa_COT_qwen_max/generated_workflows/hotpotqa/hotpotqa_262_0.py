# Workflow ID: hotpotqa_262_0
# Benchmark: hotpotqa
# Data Indices: [171]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Parse the question and identify key entities
        question_parsing_instruction = """
        Analyze the provided question thoroughly. Identify and extract all key entities mentioned explicitly in the question.
        Focus on names, titles, and relationships. Structure your output as follows:
        - Key Entities: [List of entities]
        - Question Type: [Describe the type of reasoning required, e.g., bridge, comparison, etc.]
        - Goal: [What the question is asking for]
        Ensure the output is precise and includes all relevant details.
        """
        question_analysis = await self.generate(instruction=question_parsing_instruction, context=self.problem_text)

        # Step 2: Identify relevant documents
        document_selection_instruction = f"""
        Using the analysis of the question provided below, scan all available documents to identify those that mention
        the key entities or are related to the goal of the question. Specifically, look for documents that connect:
        {question_analysis}
        Provide a list of document indices or titles that are relevant, along with a brief justification for each.
        """
        relevant_documents = await self.generate(instruction=document_selection_instruction, context=self.problem_text)

        # Step 3: Cross-reference entities and extract the answer
        answer_extraction_instruction = f"""
        Based on the relevant documents identified below, extract the specific information required to answer the question.
        Ensure the output directly addresses the goal stated in the question analysis.
        Relevant Documents: {relevant_documents}
        Extracted Information: [Provide the exact answer span or fact from the documents]
        Justification: [Explain why this information answers the question]
        """
        raw_answer = await self.generate(instruction=answer_extraction_instruction, context=self.problem_text)

        # Step 4: Verify and refine the answer
        refinement_instruction = f"""
        Review the extracted answer below and ensure it is accurate, concise, and directly addresses the question.
        If necessary, refine the answer to improve clarity or correctness.
        Extracted Answer: {raw_answer}
        Refined Answer: [Provide the final, polished answer]
        """
        final_answer = await self.revise(instruction=refinement_instruction, context=raw_answer)

        return final_answer