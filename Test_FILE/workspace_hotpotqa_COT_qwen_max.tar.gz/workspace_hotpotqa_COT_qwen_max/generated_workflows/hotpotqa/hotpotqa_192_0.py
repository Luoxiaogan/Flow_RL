# Workflow ID: hotpotqa_192_0
# Benchmark: hotpotqa
# Data Indices: [380]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify key entities and reasoning type
        entity_extraction = await self.generate(
            instruction="Extract key entities and determine the reasoning type (e.g., bridge entity, comparison). "
                        "Focus on identifying entities like films, producers, actors, and their relationships. "
                        "Ensure the output is structured as JSON with fields: 'entities' (list of strings) and 'reasoning_type' (string).",
            context=self.problem_text
        )
        import json
        entity_data = json.loads(entity_extraction)
        entities = entity_data.get("entities", [])
        reasoning_type = entity_data.get("reasoning_type", "")

        # Step 2: Extract relevant documents
        relevant_docs_task = await self.generate(
            instruction=f"Analyze all documents and identify which ones are relevant to the entities: {', '.join(entities)}. "
                        "Focus on documents that explicitly mention the entities or provide related context. "
                        "Return the relevant document texts as a list.",
            context=self.problem_text
        )
        relevant_docs = json.loads(relevant_docs_task)

        # Step 3: Find bridge entities or relationships
        bridge_info = await self.generate(
            instruction=f"Identify bridge entities or relationships that connect the key entities across the following documents: {relevant_docs}. "
                        "For example, find shared producers, actors, or other linking information. "
                        "Structure the output as JSON with fields: 'bridge_entities' (list of strings) and 'relationships' (list of strings).",
            context=self.problem_text
        )
        bridge_data = json.loads(bridge_info)
        bridge_entities = bridge_data.get("bridge_entities", [])
        relationships = bridge_data.get("relationships", [])

        # Step 4: Synthesize information using Ensemble
        synthesis = await self.ensemble(
            instruction=f"Combine information from the following documents: {relevant_docs}. "
                        f"Use the bridge entities ({bridge_entities}) and relationships ({relationships}) to derive the final answer. "
                        "Ensure the output is concise and directly answers the question.",
            contexts=relevant_docs
        )

        # Step 5: Refine and validate the answer
        refined_answer = await self.revise(
            instruction="Critique and refine the following answer to ensure it is precise, accurate, and supported by the context. "
                        "If necessary, correct any inconsistencies or ambiguities.",
            context=synthesis
        )

        return refined_answer