# Workflow ID: hotpotqa_373_0
# Benchmark: hotpotqa
# Data Indices: [368]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key entities and identify relevant documents
        entity_extraction_instruction = """
        Analyze the question and extract all key entities (e.g., people, places, organizations). 
        Identify which documents mention these entities and are likely relevant to answering the question. 
        Provide a list of entities and their associated documents.
        """
        entities_and_documents = await self.generate(
            instruction=entity_extraction_instruction,
            context=self.problem_text
        )

        # Step 2: Construct reasoning chains for bridge entities
        reasoning_chain_instruction = f"""
        Using the extracted entities and their associated documents from the previous step ({entities_and_documents}), 
        identify any "bridge entities" that connect multiple documents. 
        Construct reasoning chains that link these entities through intermediate steps. 
        If no bridge entities are found, proceed with direct fact chaining.
        """
        reasoning_chains = await self.generate(
            instruction=reasoning_chain_instruction,
            context=self.problem_text
        )

        # Step 3: Handle comparison or compositional reasoning
        comparison_composition_instruction = f"""
        Based on the reasoning chains constructed earlier ({reasoning_chains}), 
        determine if the question requires comparison or compositional reasoning. 
        For comparison questions, extract properties or facts about the entities being compared. 
        For compositional questions, combine multiple facts from different documents to derive the answer.
        """
        comparison_composition_results = await self.generate(
            instruction=comparison_composition_instruction,
            context=self.problem_text
        )

        # Step 4: Extract and refine the final answer
        answer_extraction_instruction = f"""
        Using the reasoning chains and comparison/compositional results ({comparison_composition_results}), 
        extract the precise answer span from the relevant document(s). 
        Ensure the answer directly addresses the question and is concise.
        """
        raw_answer = await self.generate(
            instruction=answer_extraction_instruction,
            context=self.problem_text
        )

        refinement_instruction = f"""
        Refine the extracted answer ({raw_answer}) to ensure it is accurate, concise, and directly addresses the question. 
        Remove any extraneous information and format the answer appropriately.
        """
        final_answer = await self.revise(
            instruction=refinement_instruction,
            context=raw_answer
        )

        return final_answer