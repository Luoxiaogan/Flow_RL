# Workflow ID: hotpotqa_130_0
# Benchmark: hotpotqa
# Data Indices: [341]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify entities and select relevant documents
        entities_instruction = """
        Identify all entities mentioned in the question. These could be mountain names, geographical features, or other key terms. 
        Then, determine which documents contain information about these entities. Provide a list of relevant documents for each entity.
        """
        entities_and_documents = await self.generate(instruction=entities_instruction, context=self.problem_text)

        # Step 2: Extract numerical/comparative facts about entities
        extract_facts_instruction_template = """
        Extract all numerical data or comparative facts about {entity} from the provided documents. 
        Focus on information such as elevation, height, or any other relevant measurements. 
        If no numerical data is available, extract descriptive comparisons or rankings.
        """
        entities = ["Nuptse", "Gasherbrum III"]  # Dynamically extracted in a real implementation
        extraction_tasks = [
            self.generate(
                instruction=extract_facts_instruction_template.format(entity=entity),
                context=entities_and_documents
            )
            for entity in entities
        ]
        extracted_facts = await asyncio.gather(*extraction_tasks)

        # Step 3: Build reasoning chains
        reasoning_instruction = f"""
        Using the extracted facts about {entities[0]} and {entities[1]}, construct a reasoning chain to determine which mountain is taller. 
        Compare the numerical values or descriptive information directly. If there are ambiguities, note them explicitly.
        """
        reasoning_chain = await self.generate(instruction=reasoning_instruction, context="\n".join(extracted_facts))

        # Step 4: Synthesize the final answer
        synthesis_instruction = """
        Based on the reasoning chain, provide a concise answer to the question. Ensure the answer is clear, factual, and supported by the extracted information.
        """
        final_answer = await self.generate(instruction=synthesis_instruction, context=reasoning_chain)

        return final_answer