# Workflow ID: hotpotqa_383_0
# Benchmark: hotpotqa
# Data Indices: [115]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Identify the document mentioning the live album and extract the singer's name
        instruction_step1 = """
        Analyze the provided context documents to identify which document mentions the live album 
        "Wanda Live! at Third Man Records". Extract the name of the singer associated with this album. 
        Ensure the output is clear and unambiguous.
        """
        singer_identification = await self.generate(instruction=instruction_step1, context=self.problem_text)

        # Step 2: Search for the singer's biographical details, specifically her birth year
        instruction_step2 = f"""
        Using the singer's name extracted in the previous step ({singer_identification}), analyze the context documents 
        to find biographical details about her. Specifically, focus on extracting her birth year. 
        If multiple documents mention her, prioritize the most authoritative source. 
        Ensure the output is precise and includes only the relevant information.
        """
        singer_biography = await self.generate(instruction=instruction_step2, context=self.problem_text)

        # Step 3: Revise the extracted information for accuracy and coherence
        instruction_step3 = """
        Review the extracted information about the singer's birth year. Ensure it is accurate, coherent, 
        and directly answers the question. If there are any ambiguities or inconsistencies, resolve them.
        """
        revised_answer = await self.revise(instruction=instruction_step3, context=singer_biography)

        # Step 4: Synthesize the results into a concise answer
        instruction_step4 = """
        Combine the information from the previous steps to produce a concise and accurate answer 
        to the question: "When was the American singer, songwriter born who's live album is Wanda Live! at Third Man Records?"
        Ensure the final output is in the format requested (e.g., a specific year).
        """
        final_answer = await self.ensemble(instruction=instruction_step4, contexts=[singer_identification, singer_biography, revised_answer])

        return final_answer