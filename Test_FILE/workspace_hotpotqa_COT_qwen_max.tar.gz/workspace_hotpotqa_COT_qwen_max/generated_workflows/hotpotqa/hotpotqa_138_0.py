# Workflow ID: hotpotqa_138_0
# Benchmark: hotpotqa
# Data Indices: [265]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify key entities and analyze the question
        entity_instruction = """
        Analyze the given question and identify all key entities mentioned. 
        For each entity, determine its type (e.g., person, location, organization) and any relationships between the entities.
        Provide a structured output with the entities and their relationships.
        """
        entities = await self.generate(instruction=entity_instruction, context=self.problem_text)

        # Step 2: Extract relevant information from documents
        extraction_instruction_template = f"""
        Given the following entities and their relationships: {entities}
        Extract all relevant sentences or facts from the provided documents that pertain to these entities.
        Ensure to capture any information that could help answer the question.
        """

        # Assuming we have a list of document texts
        documents = [
            "Blue Springs is a city located in the U.S. State of Missouri...", 
            "Kansas's 1st congressional district is a congressional district in the U.S. state of Kansas...", 
            "Motley is a city in Cass and Morrison counties in the U.S. state of Minnesota...", 
            "The Cabinet counties are ten counties in the southern part of the U.S. state of Michigan...", 
            "East Tennessee comprises approximately the eastern third of the U.S. state of Tennessee...", 
            "Casey Guernsey is a Republican politician and former member of the Missouri House of Representatives...", 
            "W. Lon Johnson was a Republican politician from the U.S. state of Washington...", 
            "Cass Lake is a glacially-formed lake in north central Minnesota in the United States...", 
            "Lee's Summit is a city located within the counties of Jackson (primarily) and Cass in the U.S. state of Missouri...", 
            "Robert T. Johnson is a Republican politician from Lee's Summit, Missouri..."
        ]

        extraction_tasks = [
            self.generate(instruction=extraction_instruction_template, context=doc) for doc in documents
        ]
        extracted_infos = await asyncio.gather(*extraction_tasks)

        # Step 3: Construct reasoning chain
        reasoning_instruction = """
        Given the following extracted information from multiple documents: {extracted_infos}
        Build a reasoning chain that connects the facts to answer the question.
        Ensure to track entity mentions across different contexts and resolve any ambiguities.
        Provide a clear and logical sequence of steps leading to the answer.
        """
        reasoning_chain = await self.ensemble(
            instruction=reasoning_instruction.format(extracted_infos=extracted_infos),
            contexts=extracted_infos
        )

        # Step 4: Formulate and refine the answer
        answer_instruction = """
        Based on the constructed reasoning chain: {reasoning_chain}
        Formulate a precise and concise answer to the question.
        Ensure the answer directly addresses the question and is supported by the reasoning chain.
        """
        initial_answer = await self.generate(instruction=answer_instruction.format(reasoning_chain=reasoning_chain), context=self.problem_text)

        refinement_instruction = """
        Review the following answer and ensure it is precise, concise, and directly addresses the question.
        Make any necessary refinements to improve clarity and accuracy.
        """
        final_answer = await self.revise(instruction=refinement_instruction, context=initial_answer)

        return final_answer