# Workflow ID: hotpotqa_91_0
# Benchmark: hotpotqa
# Data Indices: [364]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Identify relevant documents
        document_identification_instruction = (
            "Analyze the question and identify keywords, entities, or themes that can help locate relevant documents. "
            "Then, match these keywords against the provided context documents to determine which ones are most relevant. "
            "Return the indices or names of the relevant documents."
        )
        relevant_documents = await self.generate(instruction=document_identification_instruction, context=self.problem_text)

        # Step 2: Extract key information from relevant documents
        extraction_instruction = (
            f"Given the relevant documents identified as {relevant_documents}, extract key sentences or facts "
            "that directly contribute to answering the question. Focus on entities, dates, or relationships mentioned. "
            "Ensure the extracted information is concise and relevant."
        )
        extracted_facts = await self.summarize(instruction=extraction_instruction, context=self.problem_text)

        # Step 3: Build reasoning chains across documents
        reasoning_instruction = (
            f"Using the extracted facts: {extracted_facts}, build a logical reasoning chain to connect the information. "
            "If this is a bridge question, identify the bridge entity that links multiple documents. "
            "If this is a comparison question, compare the properties of the entities mentioned. "
            "Provide a clear step-by-step explanation of the reasoning process."
        )
        reasoning_chain = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Synthesize the final answer
        synthesis_instruction = (
            f"Based on the reasoning chain: {reasoning_chain}, synthesize the final answer. "
            "Ensure the answer is concise, accurate, and directly addresses the question. "
            "If the answer requires specific text spans, extract those spans verbatim from the documents."
        )
        candidate_answers = await asyncio.gather(
            self.generate(instruction=synthesis_instruction, context=self.problem_text),
            self.generate(instruction=synthesis_instruction, context=self.problem_text)  # Generate multiple candidates
        )

        # Step 5: Ensemble to select the best answer
        ensemble_instruction = (
            "Compare the following candidate answers and select the most accurate and concise one. "
            "Ensure the chosen answer satisfies all constraints of the question."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=candidate_answers)

        # Step 6: Validate and refine the final answer
        validation_instruction = (
            f"Review the final answer: {final_answer} against the original problem text. "
            "Critique and refine it to ensure it is fully accurate and adheres to the question's requirements."
        )
        refined_answer = await self.revise(instruction=validation_instruction, context=final_answer)

        return refined_answer