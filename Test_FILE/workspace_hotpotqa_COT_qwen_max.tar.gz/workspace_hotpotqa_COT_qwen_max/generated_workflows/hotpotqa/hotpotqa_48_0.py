# Workflow ID: hotpotqa_48_0
# Benchmark: hotpotqa
# Data Indices: [287]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key entities from the question
        entity_extraction_instruction = """
        Analyze the question and extract all key entities (e.g., names, places, organizations).
        Focus on entities that are likely to appear in the context documents.
        If there are multiple entities, list them clearly.
        """
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Match entities to documents and select relevant ones
        document_matching_instruction = f"""
        Given the following extracted entities: {entities}
        Match these entities against the provided context documents.
        Identify which documents mention these entities and are therefore relevant to answering the question.
        Return a list of document indices that contain the relevant information.
        """
        relevant_documents = await self.generate(instruction=document_matching_instruction, context=self.problem_text)

        # Step 3: Build reasoning chains across documents
        reasoning_instruction = f"""
        Based on the entities: {entities} and the relevant documents: {relevant_documents},
        construct a logical chain that connects the information across the documents.
        Explain how the entities relate to each other and what additional facts can be inferred.
        The goal is to derive an answer to the original question by synthesizing information from multiple sources.
        """
        reasoning_chain = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Extract the final answer
        answer_extraction_instruction = f"""
        From the constructed reasoning chain: {reasoning_chain},
        extract the final answer to the original question.
        Ensure the answer is precise and directly addresses the question.
        If the answer requires a specific fact (e.g., location, date), explicitly state it.
        """
        final_answer = await self.generate(instruction=answer_extraction_instruction, context=self.problem_text)

        return final_answer