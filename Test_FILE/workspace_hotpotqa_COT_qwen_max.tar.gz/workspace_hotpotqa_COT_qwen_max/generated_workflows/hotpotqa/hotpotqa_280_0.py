# Workflow ID: hotpotqa_280_0
# Benchmark: hotpotqa
# Data Indices: [95]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Analyze the question to identify key entities and relationships
        question_analysis = await self.generate(
            instruction="Identify the key entities and relationships mentioned in the question. "
                        "Focus on names, organizations, or specific terms that are central to the query. "
                        "Provide a structured summary of these elements.",
            context=self.problem_text
        )

        # Step 2: Extract relevant documents based on identified entities
        relevant_documents = await self.generate(
            instruction=f"Based on the following analysis: {question_analysis}, "
                        "identify which documents from the provided context contain information "
                        "about the key entities or relationships. Provide a list of document titles "
                        "and brief summaries of their relevance.",
            context=self.problem_text
        )

        # Step 3: Resolve entity ambiguities across documents
        entity_resolution = await self.generate(
            instruction=f"Given the following relevant documents: {relevant_documents}, "
                        "resolve any ambiguities in how the key entities are described. "
                        "Ensure that the entity mentioned in the question matches the context "
                        "in each document. Provide a clear explanation of your resolution process.",
            context=self.problem_text
        )

        # Step 4: Build reasoning chains across documents
        reasoning_chain = await self.generate(
            instruction=f"Using the resolved entities: {entity_resolution}, "
                        "construct a reasoning chain that connects the information across documents. "
                        "Explicitly state how each document contributes to answering the question. "
                        "Focus on logical connections and supporting evidence.",
            context=self.problem_text
        )

        # Step 5: Extract the final answer span
        answer_extraction = await self.generate(
            instruction=f"Based on the reasoning chain: {reasoning_chain}, "
                        "extract the precise answer span from the text that directly answers the question. "
                        "Ensure the answer is concise and supported by the reasoning.",
            context=self.problem_text
        )

        # Step 6: Refine the answer for accuracy and clarity
        refined_answer = await self.revise(
            instruction="Review the extracted answer and ensure it is accurate, well-formed, "
                        "and fully supported by the reasoning chain. Make any necessary refinements.",
            context=answer_extraction
        )

        return refined_answer