# Workflow ID: hotpotqa_181_0
# Benchmark: hotpotqa
# Data Indices: [92]

class Workflow:
    def __init__(self, config, problem) -> None:
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract mentions of Elsholtzia and Platycarya
        entity_extraction = await self.generate(
            instruction="Identify all mentions of 'Elsholtzia' and 'Platycarya' in the provided context documents. "
                        "For each entity, list the documents that contain relevant information about its geographic distribution.",
            context=self.problem_text
        )

        # Step 2: Extract geographic attributes for each entity (parallel execution)
        elsholtzia_task = self.generate(
            instruction=f"From the documents mentioning 'Elsholtzia', extract its geographic attributes. "
                        f"Specifically, determine if it is native to China and if it is also found in India. "
                        f"Provide a clear and concise summary of the findings.",
            context=entity_extraction
        )
        platycarya_task = self.generate(
            instruction=f"From the documents mentioning 'Platycarya', extract its geographic attributes. "
                        f"Specifically, determine if it is native to China and if it is also found in India. "
                        f"Provide a clear and concise summary of the findings.",
            context=entity_extraction
        )
        geographic_attributes = await asyncio.gather(elsholtzia_task, platycarya_task)

        # Step 3: Refine geographic attributes
        refined_elsholtzia = await self.revise(
            instruction="Review the geographic attributes of 'Elsholtzia'. "
                        "Ensure the information is accurate and directly addresses whether it is found in India.",
            context=geographic_attributes[0]
        )
        refined_platycarya = await self.revise(
            instruction="Review the geographic attributes of 'Platycarya'. "
                        "Ensure the information is accurate and directly addresses whether it is found in India.",
            context=geographic_attributes[1]
        )

        # Step 4: Compare geographic attributes using Ensemble
        comparison = await self.ensemble(
            instruction="Compare the geographic attributes of 'Elsholtzia' and 'Platycarya'. "
                        "Determine if both are found in India. Provide a clear conclusion.",
            contexts=[refined_elsholtzia, refined_platycarya]
        )

        # Step 5: Generate the final answer
        final_answer = await self.generate(
            instruction="Based on the comparison of geographic attributes, provide a concise final answer "
                        "to the question: 'Are Elsholtzia and Platycarya both found in India?'",
            context=comparison
        )

        return final_answer