# Workflow ID: hotpotqa_96_0
# Benchmark: hotpotqa
# Data Indices: [297]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract information about the entities in the question
        entity_extraction_instruction = """
        Identify the main entities mentioned in the question and extract all relevant information about them from the provided documents. 
        Focus on details such as their roles, relationships, achievements, and any other contextual information that could help answer the question.
        """
        entity_context = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Identify potential bridge entities
        bridge_entity_instruction = f"""
        Analyze the extracted information about the entities and identify potential "bridge entities" or shared concepts that connect them. 
        A bridge entity could be a common theme, activity, or object that links the two entities. 
        Provide a list of possible bridge entities along with supporting evidence from the documents.
        """
        bridge_entities = await self.generate(instruction=bridge_entity_instruction, context=entity_context)

        # Step 3: Construct reasoning chains for each bridge entity
        reasoning_chain_instruction = f"""
        For each identified bridge entity, construct a reasoning chain that connects the two entities mentioned in the question. 
        Use the extracted information and bridge entity analysis to form a coherent explanation of how the entities are related through the bridge entity.
        """
        reasoning_chains = await self.generate(instruction=reasoning_chain_instruction, context=bridge_entities)

        # Step 4: Select the best reasoning chain
        ensemble_instruction = """
        Evaluate the provided reasoning chains and select the most plausible and well-supported chain that answers the question. 
        Consider the strength of the evidence, clarity of the reasoning, and relevance to the question.
        """
        best_reasoning_chain = await self.ensemble(instruction=ensemble_instruction, contexts=[reasoning_chains])

        # Step 5: Synthesize the final answer
        answer_synthesis_instruction = f"""
        Based on the selected reasoning chain, extract the specific text span or fact that directly answers the question. 
        Ensure the response is concise, accurate, and supported by the documents.
        """
        final_answer = await self.generate(instruction=answer_synthesis_instruction, context=best_reasoning_chain)

        return final_answer