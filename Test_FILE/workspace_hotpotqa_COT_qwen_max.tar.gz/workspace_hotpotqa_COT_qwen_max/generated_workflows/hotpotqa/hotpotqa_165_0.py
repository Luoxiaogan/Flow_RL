# Workflow ID: hotpotqa_165_0
# Benchmark: hotpotqa
# Data Indices: [244]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Identify key entities in the question
        entities_extraction = await self.generate(
            instruction="Identify the key entities mentioned in the question. "
                        "These are typically proper nouns or specific names. "
                        "Return them as a comma-separated list.",
            context=self.problem_text
        )
        entities = [entity.strip() for entity in entities_extraction.split(",")]

        # Step 2: Extract relevant contexts for each entity
        async def extract_context(entity):
            return await self.generate(
                instruction=f"Extract all sentences or paragraphs from the context documents "
                            f"that mention the entity '{entity}'. Focus on information about "
                            f"religious organizations, conversions, or historical usage.",
                context=self.problem_text
            )

        contexts = await asyncio.gather(*(extract_context(entity) for entity in entities))

        # Step 3: Count religious organizations for each entity
        async def count_religious_organizations(context, entity):
            return await self.generate(
                instruction=f"Analyze the provided context for '{entity}' and count how many "
                            f"religious organizations are mentioned. Look for terms like 'church', "
                            f"'mosque', 'converted', or any reference to religious groups. "
                            f"Provide the count and a brief explanation.",
                context=context
            )

        org_counts = await asyncio.gather(
            *(count_religious_organizations(contexts[i], entities[i]) for i in range(len(entities)))
        )

        # Step 4: Compare the counts and build reasoning
        comparison = await self.ensemble(
            instruction="Compare the counts of religious organizations associated with each entity. "
                        "Explain which entity has been home to more religious organizations and why. "
                        "Use the provided counts and explanations to build a clear reasoning chain.",
            contexts=org_counts
        )

        # Step 5: Summarize the final answer
        final_answer = await self.summarize(
            instruction="Summarize the findings into a concise answer that directly addresses the question. "
                        "Include supporting facts from the documents to justify the conclusion.",
            context=comparison
        )

        return final_answer