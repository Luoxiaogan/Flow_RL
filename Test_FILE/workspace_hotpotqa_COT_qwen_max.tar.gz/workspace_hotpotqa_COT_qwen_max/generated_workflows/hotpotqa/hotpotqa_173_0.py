# Workflow ID: hotpotqa_173_0
# Benchmark: hotpotqa
# Data Indices: [278]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Document Selection
        doc_selection_instruction = """
        Analyze the question and identify which documents are relevant to answering it. 
        Look for keywords, entities, and semantic similarity between the question and document content. 
        Return a list of relevant document indices.
        """
        relevant_docs = await self.generate(instruction=doc_selection_instruction, context=self.problem_text)

        # Step 2: Entity and Relationship Extraction
        entity_extraction_instruction = f"""
        From the relevant documents ({relevant_docs}), extract key entities and their relationships. 
        Focus on entities mentioned in the question and how they connect across documents. 
        Provide a structured output detailing the entities and their relationships.
        """
        entity_relationships = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 3: Reasoning Chain Construction
        reasoning_chain_instruction = f"""
        Using the extracted entities and relationships ({entity_relationships}), construct a reasoning chain 
        that connects the information across documents. Identify the bridge entities or facts that link 
        different parts of the question. Provide a step-by-step reasoning process.
        """
        reasoning_chain = await self.ensemble(
            instruction=reasoning_chain_instruction,
            contexts=[self.problem_text, entity_relationships]
        )

        # Step 4: Answer Synthesis
        answer_synthesis_instruction = f"""
        Based on the reasoning chain ({reasoning_chain}), extract the specific answer to the question. 
        Ensure the answer is concise and directly addresses the question. If the answer is a text span, 
        provide the exact span from the documents. If it's a yes/no or factual response, state it clearly.
        """
        final_answer = await self.summarize(instruction=answer_synthesis_instruction, context=reasoning_chain)

        return final_answer