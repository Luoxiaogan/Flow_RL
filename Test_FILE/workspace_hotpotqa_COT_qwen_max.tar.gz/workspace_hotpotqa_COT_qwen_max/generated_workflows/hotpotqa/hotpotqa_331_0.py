# Workflow ID: hotpotqa_331_0
# Benchmark: hotpotqa
# Data Indices: [295]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key entities and relationships from the question
        entity_extraction_instruction = """
        Analyze the question and extract the following:
        1. The main subject (e.g., person, entity) being asked about.
        2. The specific context or event mentioned in the question.
        3. Any additional constraints or conditions (e.g., committed suicide).
        Ensure the output is structured clearly for further processing.
        """
        extracted_entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Identify relevant documents
        document_selection_instruction = f"""
        Based on the extracted entities: {extracted_entities}, analyze each document provided in the context.
        Determine which documents contain information related to the main subject, context, or conditions.
        Return a list of relevant document indices or titles.
        """
        relevant_documents = await self.generate(instruction=document_selection_instruction, context=self.problem_text)

        # Step 3: Perform cross-document inference
        inference_instruction = f"""
        Using the relevant documents: {relevant_documents}, connect information across them to build a reasoning chain.
        Specifically, link the main subject to the context and conditions mentioned in the question.
        Synthesize the information into a coherent narrative that leads to the answer.
        """
        reasoning_chain = await self.ensemble(
            instruction=inference_instruction,
            contexts=[self.problem_text] * len(relevant_documents.split(","))
        )

        # Step 4: Extract and refine the answer
        answer_extraction_instruction = """
        From the synthesized reasoning chain, extract the precise answer span that directly answers the question.
        Ensure the output is concise and matches the expected format (e.g., entity name, phrase).
        """
        raw_answer = await self.generate(instruction=answer_extraction_instruction, context=reasoning_chain)

        refinement_instruction = """
        Critique and refine the extracted answer to ensure accuracy and clarity.
        Verify that it satisfies all constraints mentioned in the question.
        """
        final_answer = await self.revise(instruction=refinement_instruction, context=raw_answer)

        return final_answer