# Workflow ID: hotpotqa_363_0
# Benchmark: hotpotqa
# Data Indices: [38]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify Relevant Documents
        document_selection_instruction = """
        Analyze the provided question and identify which documents from the context are most likely to contain relevant information. 
        Consider the entities mentioned in the question and match them to entities in the documents. 
        Provide a list of document names that are relevant to answering the question.
        """
        relevant_documents = await self.generate(
            instruction=document_selection_instruction,
            context=self.problem_text
        )

        # Step 2: Extract and Match Entities Across Documents
        entity_resolution_instruction = f"""
        Using the relevant documents identified as {relevant_documents}, extract all key entities mentioned in these documents. 
        Match entities across different documents to identify shared references (e.g., the same person, movie, or event mentioned in multiple places). 
        Provide a mapping of entities and their mentions across documents.
        """
        entity_mapping = await self.generate(
            instruction=entity_resolution_instruction,
            context=self.problem_text
        )

        # Step 3: Construct Reasoning Chains
        reasoning_chain_instruction = f"""
        Based on the entity mapping {entity_mapping}, construct a reasoning chain to answer the question. 
        Start by identifying the primary entity in the question and trace its relationships across the relevant documents. 
        Explicitly describe the logical steps connecting the entities and facts to arrive at the answer.
        """
        reasoning_chains = await asyncio.gather(
            self.generate(
                instruction=reasoning_chain_instruction,
                context=self.problem_text
            ),
            self.generate(
                instruction=reasoning_chain_instruction,
                context=self.problem_text
            )
        )

        # Step 4: Select or Synthesize the Best Reasoning Chain
        ensemble_instruction = """
        Evaluate the provided reasoning chains and select the most coherent and accurate one. 
        If both chains are partially correct, synthesize them into a single improved chain.
        """
        best_reasoning_chain = await self.ensemble(
            instruction=ensemble_instruction,
            contexts=reasoning_chains
        )

        # Step 5: Extract the Final Answer
        answer_extraction_instruction = f"""
        From the reasoning chain {best_reasoning_chain}, extract the precise answer to the question. 
        Ensure the answer is concise and directly addresses the question.
        """
        final_answer = await self.summarize(
            instruction=answer_extraction_instruction,
            context=self.problem_text
        )

        # Optional Step 6: Refine the Final Answer
        refinement_instruction = """
        Review the extracted answer and ensure it is accurate, complete, and properly formatted. 
        Make any necessary refinements to improve clarity or correctness.
        """
        refined_answer = await self.revise(
            instruction=refinement_instruction,
            context=final_answer
        )

        return refined_answer