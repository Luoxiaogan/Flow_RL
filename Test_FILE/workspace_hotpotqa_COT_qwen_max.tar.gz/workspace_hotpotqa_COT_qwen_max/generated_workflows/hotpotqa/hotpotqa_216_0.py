# Workflow ID: hotpotqa_216_0
# Benchmark: hotpotqa
# Data Indices: [7]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio
        # Step 1: Evaluate document relevance
        documents = self.problem_text.split("\n\n")  # Assuming documents are separated by double newlines
        relevance_tasks = [
            self.generate(
                instruction=f"""
                    Evaluate the relevance of the following document to the question.
                    Question: {self.problem_text.split('QUESTION:')[1].strip()}
                    Document: {doc}
                    Provide a brief explanation of why this document is relevant or irrelevant.
                """,
                context=doc
            )
            for doc in documents
        ]
        relevance_results = await asyncio.gather(*relevance_tasks)

        # Step 2: Extract relevant documents
        relevant_docs = [doc for doc, result in zip(documents, relevance_results) if "relevant" in result.lower()]

        # Step 3: Track entities and build reasoning chain
        entity_extraction_tasks = [
            self.generate(
                instruction=f"""
                    Extract all entities mentioned in the document and their relationships.
                    Document: {doc}
                    Focus on entities that are likely to be connected to the question.
                """,
                context=doc
            )
            for doc in relevant_docs
        ]
        entity_results = await asyncio.gather(*entity_extraction_tasks)

        # Step 4: Synthesize information using ensemble
        reasoning_chain = await self.ensemble(
            instruction=f"""
                Combine the extracted entities and their relationships into a coherent reasoning chain.
                Entities: {entity_results}
                Question: {self.problem_text.split('QUESTION:')[1].strip()}
                Build a step-by-step reasoning process that leads to the answer.
            """,
            contexts=entity_results
        )

        # Step 5: Extract the final answer
        final_answer = await self.summarize(
            instruction=f"""
                Summarize the reasoning chain into a concise answer to the question.
                Reasoning Chain: {reasoning_chain}
                Question: {self.problem_text.split('QUESTION:')[1].strip()}
                Ensure the answer is precise and directly addresses the question.
            """,
            context=reasoning_chain
        )

        return final_answer