# Workflow ID: hotpotqa_375_0
# Benchmark: hotpotqa
# Data Indices: [148]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract the name of the free agent signed by the Lakers for the 2001-02 season
        extract_free_agent = await self.generate(
            instruction="Identify the name of the free agent signed by the Los Angeles Lakers during the offseason before the 2001-02 NBA season. "
                        "Carefully analyze the provided documents for mentions of the Lakers' offseason activities and focus on extracting the exact name of the free agent. "
                        "If multiple candidates are mentioned, list all potential names.",
            context=self.problem_text
        )

        # Step 2: Resolve ambiguity among candidate free agents using Ensemble
        resolved_free_agent = await self.ensemble(
            instruction="Given the following candidate names extracted from the documents, determine the most likely free agent signed by the Los Angeles Lakers before the 2001-02 season. "
                        "Use contextual clues and cross-reference information across documents to select the correct entity.",
            contexts=[extract_free_agent]
        )

        # Step 3: Identify the college basketball affiliation of the resolved free agent
        college_info = await self.generate(
            instruction=f"Find the college where {resolved_free_agent} played basketball. "
                        "Search the provided documents for any mention of {resolved_free_agent}'s college basketball career. "
                        "Extract the exact name of the college or university associated with this player.",
            context=self.problem_text
        )

        # Step 4: Refine the answer to ensure clarity and correctness
        refined_answer = await self.revise(
            instruction="Ensure the following answer is concise, accurate, and directly addresses the question. "
                        "Remove any extraneous information and focus solely on the college basketball affiliation of the player.",
            context=college_info
        )

        return refined_answer