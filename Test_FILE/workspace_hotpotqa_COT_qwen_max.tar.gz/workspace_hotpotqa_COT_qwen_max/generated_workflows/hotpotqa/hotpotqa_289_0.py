# Workflow ID: hotpotqa_289_0
# Benchmark: hotpotqa
# Data Indices: [103]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key entities and relationships
        entity_extraction = await self.generate(
            instruction="Identify all key entities mentioned in the question and context documents. "
                        "Focus on named entities such as people, organizations, and concepts. "
                        "Provide a structured list of these entities and their potential relationships.",
            context=self.problem_text
        )

        # Step 2: Identify relevant documents
        document_selection = await self.generate(
            instruction=f"Given the extracted entities: {entity_extraction}, "
                        "analyze each document in the context and identify which ones contain information "
                        "about these entities. Provide a list of relevant documents with explanations.",
            context=self.problem_text
        )

        # Step 3: Identify bridge entities
        bridge_entity_identification = await self.generate(
            instruction=f"Using the extracted entities: {entity_extraction} and the relevant documents: {document_selection}, "
                        "identify any 'bridge entities' that connect different pieces of information. "
                        "For example, an entity that appears in multiple documents and links them logically. "
                        "Explain why this entity is important for answering the question.",
            context=self.problem_text
        )

        # Step 4: Construct reasoning chain
        reasoning_chain = await self.generate(
            instruction=f"Based on the extracted entities: {entity_extraction}, relevant documents: {document_selection}, "
                        f"and bridge entities: {bridge_entity_identification}, construct a logical reasoning chain. "
                        "Step through how the information connects to answer the question. "
                        "Ensure the chain is explicit and leaves no gaps in reasoning.",
            context=self.problem_text
        )

        # Step 5: Synthesize candidate answers
        candidate_answers = await asyncio.gather(
            self.generate(
                instruction=f"Using the reasoning chain: {reasoning_chain}, "
                            "extract a concise answer to the question. Ensure the answer is precise and factually correct.",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"Re-examine the reasoning chain: {reasoning_chain} and consider alternative interpretations. "
                            "Extract another concise answer if possible.",
                context=self.problem_text
            )
        )

        # Step 6: Select the best answer
        final_answer = await self.ensemble(
            instruction="Evaluate the candidate answers and select the most accurate one. "
                        "Consider factual correctness, relevance to the question, and logical consistency.",
            contexts=candidate_answers
        )

        # Step 7: Refine the final answer
        refined_answer = await self.revise(
            instruction="Refine the selected answer to ensure clarity, precision, and correctness. "
                        "Correct any grammatical issues or ambiguities.",
            context=final_answer
        )

        return refined_answer