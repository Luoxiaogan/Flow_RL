# Workflow ID: hotpotqa_15_0
# Benchmark: hotpotqa
# Data Indices: [50]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key entities from the question
        entity_extraction_instruction = """
        Analyze the given question carefully and extract all key entities or concepts that are crucial for answering it.
        Focus on identifying proper nouns, organizations, people, or specific terms mentioned in the question.
        Format your output as a JSON object where keys are entity types (e.g., "person", "organization") and values are lists of entities.
        """
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Identify relevant documents based on extracted entities
        document_identification_instruction = f"""
        Using the extracted entities: {entities}, scan through all the provided documents and identify which ones mention these entities.
        Provide a concise summary of which documents are relevant to each entity.
        Format your output as a JSON object where keys are entity names and values are lists of relevant document indices or titles.
        """
        relevant_documents = await self.generate(instruction=document_identification_instruction, context=self.problem_text)

        # Step 3: Extract supporting facts from relevant documents
        fact_extraction_tasks = []
        for doc_info in json.loads(relevant_documents).values():
            for doc in doc_info:
                fact_extraction_instruction = f"""
                From the document titled "{doc}", extract sentences or facts that are relevant to the entities mentioned in the question.
                Focus on information that could directly contribute to answering the question.
                """
                task = self.summarize(instruction=fact_extraction_instruction, context=self.problem_text)
                fact_extraction_tasks.append(task)
        supporting_facts = await asyncio.gather(*fact_extraction_tasks)

        # Step 4: Synthesize information to build reasoning chains
        synthesis_instruction = f"""
        Given the following supporting facts: {supporting_facts},
        synthesize the information to build a coherent reasoning chain that connects the entities and answers the question.
        Ensure that the reasoning is logical and explicitly links all necessary pieces of information.
        """
        reasoning_chain = await self.ensemble(instruction=synthesis_instruction, contexts=supporting_facts)

        # Step 5: Refine the final answer
        refinement_instruction = f"""
        Critique and refine the following reasoning chain: {reasoning_chain}.
        Ensure the final answer is precise, concise, and directly addresses the question.
        If the question expects a specific format (e.g., a short text span), make sure the answer adheres to that format.
        """
        final_answer = await self.revise(instruction=refinement_instruction, context=reasoning_chain)

        return final_answer