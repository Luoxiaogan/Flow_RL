# Workflow ID: hotpotqa_114_0
# Benchmark: hotpotqa
# Data Indices: [176]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Identify key entities and question type
        question_analysis = await self.generate(
            instruction="Analyze the question to determine its type (e.g., bridge, comparison, compositional) and extract key entities. "
                        "Provide a detailed explanation of the reasoning behind the classification and list all identified entities.",
            context=self.problem_text
        )

        # Step 2: Select relevant documents
        relevant_docs = await self.generate(
            instruction=f"Based on the extracted entities from the previous step ({question_analysis}), "
                        "identify which documents in the provided context are relevant to answering the question. "
                        "Explain why each document is relevant and how it contributes to solving the problem.",
            context=self.problem_text
        )

        # Step 3: Resolve entities and establish cross-document links
        resolved_entities = await self.generate(
            instruction=f"Resolve entity mentions across the relevant documents identified in the previous step ({relevant_docs}). "
                        "For each entity, determine how it is referenced in different documents and establish connections between them. "
                        "Provide a detailed explanation of the relationships between entities.",
            context=self.problem_text
        )

        # Step 4: Construct reasoning chain
        reasoning_chain = await self.generate(
            instruction=f"Using the resolved entities and their relationships from the previous step ({resolved_entities}), "
                        "construct a reasoning chain that leads to the answer. "
                        "Explain each step of the reasoning process in detail and justify how the chain connects the question to the answer.",
            context=self.problem_text
        )

        # Step 5: Extract precise answer span
        answer_extraction = await self.generate(
            instruction=f"Based on the reasoning chain constructed in the previous step ({reasoning_chain}), "
                        "extract the precise answer span from the relevant documents. "
                        "Ensure the answer is concise and directly addresses the question.",
            context=self.problem_text
        )

        # Step 6: Refine and finalize the answer
        refined_answer = await self.revise(
            instruction="Critique and refine the extracted answer to ensure accuracy and clarity. "
                        "Verify that the answer is supported by the reasoning chain and relevant documents.",
            context=answer_extraction
        )

        return refined_answer