# Workflow ID: hotpotqa_31_0
# Benchmark: hotpotqa
# Data Indices: [207]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify entities and extract relevant contexts
        entities_extraction_instruction = """
        Identify all entities mentioned in the question. Then, for each entity, extract all relevant sentences or paragraphs from the provided context documents that describe or define the entity. Return the extracted information in a structured format.
        """
        entities_context = await self.generate(instruction=entities_extraction_instruction, context=self.problem_text)

        # Step 2: Classify the reasoning type
        reasoning_type_instruction = f"""
        Based on the extracted contexts for the entities ({entities_context}), classify the reasoning type required to answer the question. Specifically, determine whether the question is a bridge, comparison, or compositional type. Provide a brief explanation for your classification.
        """
        reasoning_type = await self.generate(instruction=reasoning_type_instruction, context=self.problem_text)

        # Step 3: Perform cross-document inference
        inference_instruction = f"""
        Using the extracted contexts for the entities ({entities_context}) and the identified reasoning type ({reasoning_type}), analyze whether each entity satisfies the condition specified in the question. For example, if the question asks whether two entities share a property, determine whether each entity possesses that property based on the provided contexts. Return your findings in a structured format.
        """
        inference_results = await self.generate(instruction=inference_instruction, context=self.problem_text)

        # Step 4: Synthesize the final answer
        synthesis_instruction = f"""
        Based on the inference results ({inference_results}), synthesize a concise answer to the original question. Ensure the answer directly addresses the question and provides sufficient justification based on the evidence from the context documents.
        """
        final_answer = await self.generate(instruction=synthesis_instruction, context=self.problem_text)

        # Optional: Refine the final answer
        refinement_instruction = """
        Review the final answer and ensure it is clear, concise, and fully supported by the evidence. If necessary, revise the answer to improve its quality.
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        return refined_answer