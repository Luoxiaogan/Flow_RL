# Workflow ID: hotpotqa_277_0
# Benchmark: hotpotqa
# Data Indices: [16]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify entities and select relevant documents
        entity_identification = await self.generate(
            instruction="Identify the entities mentioned in the question and determine which documents contain relevant information about these entities. "
                        "Focus on the entities 'Stone Soup' and 'Amazing Heroes'. "
                        "Return the list of relevant documents for each entity.",
            context=self.problem_text
        )

        # Step 2: Extract founding years for each entity
        stone_soup_facts = self.generate(
            instruction=f"Extract the founding year of 'Stone Soup' magazine from the relevant documents. "
                        f"Use the following context: {entity_identification}. "
                        f"Ensure the extracted information is precise and directly related to the founding year.",
            context=self.problem_text
        )
        amazing_heroes_facts = self.generate(
            instruction=f"Extract the founding year of 'Amazing Heroes' magazine from the relevant documents. "
                        f"Use the following context: {entity_identification}. "
                        f"Ensure the extracted information is precise and directly related to the founding year.",
            context=self.problem_text
        )

        # Execute fact extraction in parallel
        extracted_facts = await asyncio.gather(stone_soup_facts, amazing_heroes_facts)

        # Step 3: Compare founding years and synthesize the answer
        comparison_result = await self.ensemble(
            instruction="Compare the founding years of 'Stone Soup' and 'Amazing Heroes' magazines. "
                        "Determine which magazine was founded first and provide a clear answer. "
                        "If there is ambiguity or missing information, indicate that explicitly.",
            contexts=extracted_facts
        )

        # Step 4: Refine the final answer (optional)
        final_answer = await self.revise(
            instruction="Refine the provided answer to ensure it is concise, clear, and correctly formatted. "
                        "The answer should directly address the question: 'Which magazine was founded first, Stone Soup or Amazing Heroes?'",
            context=comparison_result
        )

        return final_answer