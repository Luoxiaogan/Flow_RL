# Workflow ID: hotpotqa_64_0
# Benchmark: hotpotqa
# Data Indices: [254]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract entities and relationships
        entity_extraction_instruction = (
            "Identify all entities (bands, record labels, locations, etc.) and their relationships "
            "from the provided context documents. Focus on connections between entities across documents. "
            "Format the output as a list of entities and their associated relationships."
        )
        entities_and_relationships = await self.generate(
            instruction=entity_extraction_instruction,
            context=self.problem_text
        )

        # Step 2: Analyze the question
        question_analysis_instruction = (
            "Analyze the question to determine the type of reasoning required (e.g., bridge entity, "
            "comparison, or compositional fact chaining). Identify the target entity or relationship "
            "being queried. Format the output as a concise summary of the reasoning type and target."
        )
        question_analysis = await self.generate(
            instruction=question_analysis_instruction,
            context=self.problem_text
        )

        # Step 3: Identify the bridge entity (if applicable)
        bridge_entity_candidates = await self.generate(
            instruction=f"Based on the extracted entities and relationships: {entities_and_relationships}, "
                        f"identify potential bridge entities that connect multiple documents. "
                        f"List these candidates along with their relevance scores.",
            context=self.problem_text
        )
        best_bridge_entity = await self.ensemble(
            instruction="Evaluate the candidate bridge entities and select the most relevant one "
                        "based on their ability to connect the documents and address the question.",
            contexts=[bridge_entity_candidates]
        )

        # Step 4: Synthesize the answer
        answer_synthesis_instruction = (
            f"Using the identified bridge entity: {best_bridge_entity}, synthesize the final answer "
            f"to the question. Ensure the answer is precise and aligns with the question's requirements. "
            f"Extract the relevant text span or derive the response from the context documents."
        )
        synthesized_answer = await self.generate(
            instruction=answer_synthesis_instruction,
            context=self.problem_text
        )

        # Step 5: Validate and refine the answer
        refinement_instruction = (
            f"Validate the synthesized answer: {synthesized_answer} by cross-referencing it with the "
            f"original documents. Refine the answer if necessary to ensure accuracy and completeness."
        )
        final_answer = await self.revise(
            instruction=refinement_instruction,
            context=synthesized_answer
        )

        return final_answer