# Workflow ID: hotpotqa_129_0
# Benchmark: hotpotqa
# Data Indices: [357]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Identify relevant documents
        identify_docs_instruction = """
        Analyze the question and identify which documents contain information relevant to answering it.
        Focus on entities, locations, and relationships mentioned in the question.
        Provide a list of document names or indices that are most likely to contain the required information.
        """
        relevant_docs = await self.generate(instruction=identify_docs_instruction, context=self.problem_text)

        # Step 2: Extract key information from relevant documents
        extract_info_instruction = f"""
        Based on the following relevant documents: {relevant_docs}
        Extract key details about the hotel/casino/RV park in question, including its size, location, and distinguishing features.
        Ensure the extracted information directly addresses the question.
        """
        summaries = await asyncio.gather(
            *(self.summarize(instruction=extract_info_instruction, context=doc) for doc in relevant_docs.split(", "))
        )

        # Step 3: Synthesize information across documents
        synthesize_instruction = """
        Combine the provided summaries to form a coherent understanding of the hotel/casino/RV park.
        Resolve any conflicts or ambiguities by leveraging all available context.
        Ensure the synthesized information directly answers the question.
        """
        synthesized_info = await self.ensemble(instruction=synthesize_instruction, contexts=summaries)

        # Step 4: Generate the final answer
        answer_instruction = """
        Based on the synthesized information, provide a concise and accurate answer to the question.
        Format the answer as a short text span or numerical value, depending on the question type.
        """
        final_answer = await self.generate(instruction=answer_instruction, context=synthesized_info)

        return final_answer