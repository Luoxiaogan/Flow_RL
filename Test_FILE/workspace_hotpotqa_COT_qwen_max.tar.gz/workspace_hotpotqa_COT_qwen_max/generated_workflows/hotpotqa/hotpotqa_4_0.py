# Workflow ID: hotpotqa_4_0
# Benchmark: hotpotqa
# Data Indices: [272]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Analyze the question and extract key entities
        question_analysis = await self.generate(
            instruction="""Analyze the question and identify the key entities and relationships.
            Extract all important names, dates, and events mentioned in the question.
            Provide the results in a structured format, such as a list or JSON object.""",
            context=self.problem_text
        )

        # Step 2: Identify relevant documents based on entity mentions
        document_selection = await self.ensemble(
            instruction=f"""Select the documents that are most relevant to the question.
            Use the following key entities identified from the question: {question_analysis}.
            Prioritize documents that mention these entities and are likely to contain the answer.
            Provide a brief justification for each selected document.""",
            contexts=[doc for doc in self.problem_text.split("\n\n") if doc.strip()]  # Split documents
        )

        # Step 3: Identify the bridge entity and extract relevant facts
        bridge_entity_extraction = await self.generate(
            instruction=f"""Identify the 'bridge entity' that connects the key entities in the question.
            Using the relevant documents ({document_selection}), find the shared entity or event
            that links the entities together. Extract all relevant facts about this bridge entity.""",
            context=self.problem_text
        )

        # Step 4: Synthesize the extracted facts into a concise answer
        final_answer = await self.summarize(
            instruction=f"""Condense the following information into a concise answer to the question.
            Information: {bridge_entity_extraction}
            Ensure the answer directly addresses the question and includes all necessary details.""",
            context=self.problem_text
        )

        return final_answer