# Workflow ID: hotpotqa_56_0
# Benchmark: hotpotqa
# Data Indices: [286]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Analyze the question to extract entities and reasoning type
        question_analysis = await self.generate(
            instruction="Analyze the question to identify key entities and classify the reasoning type (bridge, comparison, or compositional). "
                        "Provide the extracted entities and reasoning type in a structured format.",
            context=self.problem_text
        )

        # Dynamically incorporate extracted entities into subsequent instructions
        entities = await self.generate(
            instruction=f"Extract all entities mentioned in the question and their relationships. Entities: {question_analysis}",
            context=self.problem_text
        )

        # Step 2: Identify relevant documents containing the entities
        document_selection = await self.generate(
            instruction=f"Identify which documents contain information about the following entities: {entities}. "
                        "List the relevant documents and briefly explain why they are relevant.",
            context=self.problem_text
        )

        # Step 3: Resolve the bridge entity (if applicable)
        bridge_entity_candidates = await self.generate(
            instruction=f"Based on the entities and documents identified, propose candidate bridge entities that connect the documents. "
                        "Explain the reasoning behind each candidate.",
            context=document_selection
        )

        # Use Ensemble to select the best bridge entity
        bridge_entity = await self.ensemble(
            instruction="Evaluate the candidate bridge entities and select the most plausible one based on evidence from the documents. "
                        "Provide the selected bridge entity and justification.",
            contexts=bridge_entity_candidates.split("\n")  # Split candidates into a list
        )

        # Step 4: Construct the reasoning chain
        reasoning_chain = await self.generate(
            instruction=f"Using the selected bridge entity ({bridge_entity}), construct a reasoning chain that connects the documents. "
                        "Extract relevant facts and synthesize them into a coherent explanation.",
            context=self.problem_text
        )

        # Step 5: Extract the final answer
        final_answer = await self.summarize(
            instruction="Summarize the reasoning chain to extract the precise answer to the question. "
                        "Ensure the answer is concise and directly addresses the question.",
            context=reasoning_chain
        )

        return final_answer