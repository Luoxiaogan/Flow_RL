# Workflow ID: hotpotqa_170_0
# Benchmark: hotpotqa
# Data Indices: [149]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify relevant documents and extract publication frequencies
        instruction_entity_extraction = """
        Identify the documents that mention the magazines "Fucsia" and "Pronto".
        Extract the publication frequency (e.g., monthly, weekly) for each magazine.
        Provide the extracted information in the following format:
        - Magazine: [Name]
        - Publication Frequency: [Frequency]
        Ensure the output is precise and includes only the relevant information.
        """
        entity_extraction_task = await self.generate(instruction=instruction_entity_extraction, context=self.problem_text)

        # Step 2: Parse and refine the extracted information
        instruction_refinement = f"""
        Refine the extracted information about the magazines "Fucsia" and "Pronto".
        Ensure the publication frequencies are clearly stated and formatted as follows:
        - Magazine: [Name]
        - Publication Frequency: [Frequency]
        If there are ambiguities or missing details, attempt to resolve them using the context.
        """
        refined_info = await self.revise(instruction=instruction_refinement, context=entity_extraction_task)

        # Step 3: Compare publication frequencies
        instruction_comparison = """
        Compare the publication frequencies of the two magazines.
        Use the following guidelines:
        - Weekly is more frequent than monthly.
        - If both have the same frequency, state that explicitly.
        Provide the result of the comparison in a clear and concise manner.
        """
        comparison_result = await self.ensemble(
            instruction=instruction_comparison,
            contexts=[refined_info]
        )

        # Step 4: Generate the final answer
        instruction_final_answer = f"""
        Based on the comparison result, generate the final answer to the question:
        "Which magazine is published more frequently, Fucsia or Pronto?"
        Ensure the answer is precise and includes the reasoning behind the conclusion.
        """
        final_answer = await self.generate(instruction=instruction_final_answer, context=comparison_result)

        return final_answer