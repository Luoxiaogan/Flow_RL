# Workflow ID: hotpotqa_73_0
# Benchmark: hotpotqa
# Data Indices: [77]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Identify relevant documents and extract key entities
        doc_selection_instruction = """
        Analyze the provided context documents and identify which ones are relevant to answering the question. 
        Focus on matching entities, locations, and keywords from the question with the content of each document. 
        Return a list of relevant document indices along with brief explanations of why they are relevant.
        """
        relevant_docs = await self.generate(instruction=doc_selection_instruction, context=self.problem_text)

        # Step 2: Extract entities and relationships from relevant documents
        entity_extraction_instruction = f"""
        From the relevant documents identified in the previous step ({relevant_docs}), extract all key entities, 
        their relationships, and any factual information that could help answer the question. 
        Pay special attention to bridging entities that connect multiple documents.
        """
        entity_info = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 3: Build the reasoning chain
        reasoning_chain_instruction = f"""
        Using the extracted entities and relationships ({entity_info}), construct a reasoning chain that connects 
        the entities mentioned in the question to the final answer. Ensure that each step in the chain is supported 
        by evidence from the context documents. If multiple chains are possible, evaluate them and select the most logical one.
        """
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 4: Synthesize and finalize the answer
        answer_synthesis_instruction = f"""
        Based on the reasoning chain constructed in the previous step ({reasoning_chain}), extract the final answer 
        in the required format. Ensure that the answer is concise, accurate, and directly addresses the question.
        """
        final_answer = await self.summarize(instruction=answer_synthesis_instruction, context=self.problem_text)

        return final_answer