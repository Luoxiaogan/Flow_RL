# Workflow ID: hotpotqa_243_0
# Benchmark: hotpotqa
# Data Indices: [126]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify key entities and locate relevant documents
        entity_extraction_instruction = """
        Identify all named entities mentioned in the question. Focus on proper nouns such as names of people, places, or organizations.
        Return the entities as a comma-separated list.
        """
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        document_selection_instruction = f"""
        Given the following entities: {entities}, identify which documents in the provided context contain information about these entities.
        Return the document titles as a comma-separated list.
        """
        relevant_documents = await self.generate(instruction=document_selection_instruction, context=self.problem_text)

        # Step 2: Extract relevant facts about each entity
        fact_extraction_instruction = f"""
        For each of the following entities: {entities}, extract all relevant facts from the documents listed here: {relevant_documents}.
        Focus on facts that help answer the question: Were the entities Soviets? Organize the facts by entity.
        """
        extracted_facts = await self.generate(instruction=fact_extraction_instruction, context=self.problem_text)

        # Step 3: Compare and synthesize information
        comparison_instruction = f"""
        Based on the following extracted facts: {extracted_facts}, determine if both entities satisfy the condition stated in the question.
        Provide a clear and concise analysis of your reasoning.
        """
        comparison_result = await self.generate(instruction=comparison_instruction, context=self.problem_text)

        # Step 4: Generate and refine the final answer
        answer_instruction = """
        Based on the analysis provided, generate a concise and precise answer to the original question.
        Ensure the answer directly addresses the question and is supported by the reasoning provided.
        """
        initial_answer = await self.generate(instruction=answer_instruction, context=comparison_result)

        refinement_instruction = """
        Review the following answer and refine it for clarity, correctness, and conciseness.
        Ensure the final answer is well-formulated and directly addresses the question.
        """
        final_answer = await self.revise(instruction=refinement_instruction, context=initial_answer)

        return final_answer