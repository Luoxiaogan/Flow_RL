# Workflow ID: hotpotqa_35_0
# Benchmark: hotpotqa
# Data Indices: [262]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Entity Identification
        entity_extraction_instruction = (
            "Extract all entities mentioned in the context documents that are relevant to the question. "
            "Focus on identifying the jazz singer and the gospel song 'Come Ye'. "
            "Provide a list of potential candidates for each entity type."
        )
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Bridge Entity Resolution
        bridge_entity_instruction = (
            f"From the extracted entities: {entities}, "
            "identify the bridge entity that connects the jazz singer to the gospel song 'Come Ye'. "
            "Refine the list to confirm the most likely candidate for the jazz singer."
        )
        bridge_entity = await self.revise(instruction=bridge_entity_instruction, context=entities)

        # Step 3: Fact Chaining
        reasoning_chain_instruction = (
            f"Given the bridge entity: {bridge_entity}, "
            "construct a reasoning chain to find the birth year of the identified jazz singer. "
            "Trace the connection between the jazz singer and the song 'Come Ye', then locate the birth year."
        )
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 4: Answer Extraction
        answer_extraction_instruction = (
            f"From the reasoning chain: {reasoning_chain}, "
            "extract the precise birth year of the jazz singer. Ensure the answer is concise and accurate."
        )
        answer = await self.summarize(instruction=answer_extraction_instruction, context=reasoning_chain)

        # Step 5: Validation and Ensemble
        validation_instruction = (
            "Validate the extracted answer by comparing it against alternative interpretations or reasoning paths. "
            "Ensure the birth year corresponds to the correct jazz singer and aligns with the context documents."
        )
        validation_paths = await asyncio.gather(
            self.generate(instruction=validation_instruction, context=reasoning_chain),
            self.revise(instruction=validation_instruction, context=answer)
        )
        final_answer = await self.ensemble(instruction="Select the most accurate and consistent birth year.", contexts=validation_paths)

        return final_answer