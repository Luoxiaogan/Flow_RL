# Workflow ID: hotpotqa_60_0
# Benchmark: hotpotqa
# Data Indices: [28]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Identify key entities in the question
        entity_extraction_instruction = """
        Analyze the question and extract all key entities (e.g., names, organizations, events). 
        Focus on entities that are likely to appear in the context documents. 
        Provide the extracted entities as a comma-separated list.
        """
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Extract relevant sentences mentioning these entities
        document_selection_instruction = f"""
        From the provided context documents, extract all sentences that mention any of the following entities: {entities}.
        Ensure the extracted sentences are complete and retain their original meaning.
        """
        relevant_sentences = await self.generate(instruction=document_selection_instruction, context=self.problem_text)

        # Step 3: Identify the bridge entity
        bridge_entity_instruction = f"""
        Using the extracted sentences, identify the "bridge entity" that connects the entities mentioned in the question.
        For example, if the question asks about a relationship between two entities, determine the intermediate entity that links them.
        Provide the bridge entity as a single phrase or sentence.
        """
        bridge_entity = await self.generate(instruction=bridge_entity_instruction, context=relevant_sentences)

        # Step 4: Construct the reasoning chain
        reasoning_chain_instruction = f"""
        Based on the bridge entity ({bridge_entity}), construct a reasoning chain that leads to the answer.
        Trace the relationships between entities step by step, using evidence from the context documents.
        Provide the reasoning chain as a sequence of connected statements.
        """
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=relevant_sentences)

        # Step 5: Extract the final answer
        answer_extraction_instruction = f"""
        Using the reasoning chain ({reasoning_chain}), extract the final answer to the question.
        The answer should be a concise text span (e.g., an entity name, phrase, or fact) that directly addresses the question.
        """
        raw_answer = await self.generate(instruction=answer_extraction_instruction, context=self.problem_text)

        # Step 6: Refine the answer for clarity and correctness
        refinement_instruction = f"""
        Review the extracted answer ({raw_answer}) and refine it for clarity, accuracy, and conciseness.
        Ensure the refined answer directly answers the question and is supported by the context documents.
        """
        final_answer = await self.revise(instruction=refinement_instruction, context=raw_answer)

        return final_answer