# Workflow ID: hotpotqa_301_0
# Benchmark: hotpotqa
# Data Indices: [30]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract entities and relationships
        extraction_instruction = """
        Extract all key entities (e.g., people, albums, songs) and their relationships (e.g., "included a cameo by") from the provided documents. 
        Focus on entities and relationships that are relevant to the question. Format the output as a list of entity-relationship pairs.
        """
        entities_and_relationships = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Select relevant documents
        document_selection_instruction = f"""
        Based on the extracted entities and relationships ({entities_and_relationships}), identify which documents are most relevant to answering the question. 
        Compare the documents and select the ones that contain information about the album "Two Lanes of Freedom" and its features.
        """
        relevant_documents = await self.ensemble(instruction=document_selection_instruction, contexts=[self.problem_text])

        # Step 3: Construct reasoning chain
        reasoning_chain_instruction = f"""
        Using the selected documents ({relevant_documents}), construct a reasoning chain that connects the entities and relationships to answer the question. 
        Specifically, determine which male country singer played guitar on the album "Two Lanes of Freedom." 
        Provide a detailed explanation of the reasoning process.
        """
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 4: Synthesize the answer
        answer_synthesis_instruction = f"""
        Based on the reasoning chain ({reasoning_chain}), extract the specific answer to the question. 
        Ensure the answer is concise and directly addresses the question.
        """
        final_answer = await self.summarize(instruction=answer_synthesis_instruction, context=self.problem_text)

        return final_answer