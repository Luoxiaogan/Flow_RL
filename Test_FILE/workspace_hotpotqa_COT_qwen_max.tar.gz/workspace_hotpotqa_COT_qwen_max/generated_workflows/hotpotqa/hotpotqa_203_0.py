# Workflow ID: hotpotqa_203_0
# Benchmark: hotpotqa
# Data Indices: [111]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Identify entities and select relevant documents
        entity_identification_instruction = """
        Identify all entities mentioned in the question and find the documents that contain information about these entities.
        List the entities and the corresponding document titles.
        """
        entity_doc_mapping = await self.generate(instruction=entity_identification_instruction, context=self.problem_text)

        # Step 2: Resolve entities and link across documents
        entity_resolution_instruction = f"""
        Given the following entity-document mapping: {entity_doc_mapping}
        Resolve any ambiguities in entity mentions and establish connections between entities across different documents.
        Provide a clear explanation of how entities are linked.
        """
        entity_linking = await self.generate(instruction=entity_resolution_instruction, context=self.problem_text)

        # Step 3: Perform reasoning and synthesize the answer
        reasoning_instruction = f"""
        Based on the resolved entities and their links: {entity_linking}
        Perform the necessary reasoning to answer the question. If the question involves comparison, extract relevant properties and compare them.
        Synthesize the final answer based on the reasoning.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and finalize the answer
        validation_instruction = f"""
        Validate the following synthesized answer: {reasoning_result}
        Ensure that it accurately addresses the question and is supported by the provided documents.
        Finalize the answer in a clear and concise manner.
        """
        final_answer = await self.revise(instruction=validation_instruction, context=reasoning_result)

        return final_answer