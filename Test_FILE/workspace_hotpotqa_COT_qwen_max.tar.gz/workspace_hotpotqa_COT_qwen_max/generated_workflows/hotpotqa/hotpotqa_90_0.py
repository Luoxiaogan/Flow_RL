# Workflow ID: hotpotqa_90_0
# Benchmark: hotpotqa
# Data Indices: [199]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract information about Christian Soucy
        soucy_info = await self.generate(
            instruction="Extract all relevant information about Christian Soucy from the provided context. "
                        "Focus on his career highlights, notable achievements, and any unique traits. "
                        "If there are comparisons to other athletes, include those as well.",
            context=self.problem_text
        )

        # Step 2: Extract information about 'Field of Dreams' characters
        field_of_dreams_info = await self.generate(
            instruction="Extract all relevant information about characters from the movie 'Field of Dreams'. "
                        "Include details about their roles, significance in the story, and any unique traits. "
                        "Pay special attention to characters who had brief appearances or limited impact.",
            context=self.problem_text
        )

        # Step 3: Compare and identify the comparable character
        comparable_character = await self.ensemble(
            instruction="Compare the extracted information about Christian Soucy and the 'Field of Dreams' characters. "
                        "Identify the character from 'Field of Dreams' who shares a comparable trait with Christian Soucy, "
                        "such as a brief appearance or limited impact. Provide a clear justification for your choice.",
            contexts=[soucy_info, field_of_dreams_info]
        )

        # Step 4: Refine the reasoning and validate the answer
        refined_answer = await self.revise(
            instruction="Review the reasoning provided in the previous step. "
                        "Ensure the comparison is logically sound and the answer is precise. "
                        "If necessary, revise the explanation to make it more concise and accurate.",
            context=comparable_character
        )

        return refined_answer