# Workflow ID: hotpotqa_279_0
# Benchmark: hotpotqa
# Data Indices: [330]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify question type and extract key entities
        question_analysis = await self.generate(
            instruction="Analyze the question to determine its type (e.g., bridge, comparison, compositional) and extract key entities or concepts. "
                        "Provide a structured output with the question type and a list of key entities.",
            context=self.problem_text
        )

        # Dynamically parse the question analysis to extract entities
        entities = [entity.strip() for entity in question_analysis.split("Key Entities:")[1].split(",")]

        # Step 2: Identify relevant documents for each entity
        document_selection_tasks = []
        for entity in entities:
            task = self.generate(
                instruction=f"Identify which documents mention the entity '{entity}'. "
                            "Provide a list of document names and brief explanations of their relevance.",
                context=self.problem_text
            )
            document_selection_tasks.append(task)
        
        document_relevance = await asyncio.gather(*document_selection_tasks)

        # Step 3: Resolve entities and construct reasoning chains
        reasoning_chain_tasks = []
        for i, entity in enumerate(entities):
            task = self.generate(
                instruction=f"Using the documents relevant to '{entity}', extract facts and construct a reasoning chain. "
                            "Focus on connecting information across documents to answer the question.",
                context=document_relevance[i]
            )
            reasoning_chain_tasks.append(task)
        
        reasoning_chains = await asyncio.gather(*reasoning_chain_tasks)

        # Step 4: Synthesize information using Ensemble
        synthesized_answer = await self.ensemble(
            instruction="Synthesize the reasoning chains into a single coherent answer. "
                        "Ensure the answer directly addresses the question and is supported by evidence from the documents.",
            contexts=reasoning_chains
        )

        # Step 5: Refine the answer if needed
        final_answer = await self.revise(
            instruction="Review the synthesized answer for clarity, accuracy, and completeness. "
                        "Refine it if necessary to ensure it is a precise and well-supported response.",
            context=synthesized_answer
        )

        return final_answer