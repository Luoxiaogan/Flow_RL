# Workflow ID: hotpotqa_333_0
# Benchmark: hotpotqa
# Data Indices: [250]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Analyze the question to identify type and key entities
        question_analysis = await self.generate(
            instruction="Analyze the question to determine its type (e.g., bridge, comparison, compositional) and extract key entities or terms. "
                        "Provide a structured output with the question type and a list of entities.",
            context=self.problem_text
        )

        # Dynamically construct instructions for subsequent steps
        question_type = "bridge"  # Placeholder; parse from question_analysis in real implementation
        entities = ["Völuspá", "Poetic Edda"]  # Placeholder; extract from question_analysis

        # Step 2: Select relevant documents based on extracted entities
        document_selection_tasks = [
            self.generate(
                instruction=f"Identify if this document contains information about {entity}. "
                            f"Focus on explicit mentions or closely related concepts.",
                context=document
            )
            for entity in entities for document in self.problem_text.split("\n\n")  # Assume documents are separated by double newlines
        ]
        document_selection_results = await asyncio.gather(*document_selection_tasks)

        # Filter relevant documents
        relevant_documents = [doc for doc, result in zip(self.problem_text.split("\n\n"), document_selection_results) if "relevant" in result.lower()]

        # Step 3: Resolve entities and build reasoning chains
        reasoning_chain = await self.generate(
            instruction=f"Using the following documents, build a reasoning chain to answer the question. "
                        f"Documents:\n{' '.join(relevant_documents)}\n"
                        f"Entities: {', '.join(entities)}\n"
                        f"Question Type: {question_type}\n"
                        f"Ensure the reasoning chain connects all relevant information explicitly.",
            context=self.problem_text
        )

        # Step 4: Refine the reasoning chain
        refined_reasoning = await self.revise(
            instruction="Critique and improve the reasoning chain. Ensure logical consistency, completeness, and clarity.",
            context=reasoning_chain
        )

        # Step 5: Extract the final answer
        final_answer = await self.generate(
            instruction="Extract the precise answer span from the refined reasoning chain. "
                        "The answer should be a short text span, yes/no response, or brief factual statement.",
            context=refined_reasoning
        )

        return final_answer