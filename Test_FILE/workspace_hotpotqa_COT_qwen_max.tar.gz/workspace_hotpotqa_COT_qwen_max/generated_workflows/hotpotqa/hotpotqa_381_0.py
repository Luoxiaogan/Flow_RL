# Workflow ID: hotpotqa_381_0
# Benchmark: hotpotqa
# Data Indices: [217]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract information about Joshua Wanume Kibedi
        kibedi_info = await self.generate(
            instruction="Identify the document that mentions Joshua Wanume Kibedi, his role as Foreign Minister, "
                        "and the years he served. Also, determine the President of Uganda during his tenure.",
            context=self.problem_text
        )

        # Step 2: Refine the extracted information for clarity and accuracy
        refined_kibedi_info = await self.revise(
            instruction="Refine the extracted information about Joshua Wanume Kibedi to clearly state "
                        "his years of service as Foreign Minister and the name of the President of Uganda "
                        "he served under.",
            context=kibedi_info
        )

        # Step 3: Identify the President's tenure years
        president_info_task = self.generate(
            instruction="Locate the document that provides information about the President of Uganda "
                        "mentioned in the previous step. Extract the years during which they served as President.",
            context=self.problem_text
        )

        # Step 4: Parallelize additional checks for cross-document validation
        validation_tasks = [
            self.generate(
                instruction="Verify the years of service for the President of Uganda by cross-referencing "
                            "multiple documents.",
                context=self.problem_text
            ),
            self.generate(
                instruction="Check if there are any discrepancies or additional details about the President's "
                            "tenure in other documents.",
                context=self.problem_text
            )
        ]

        # Execute tasks in parallel
        president_info, *validation_results = await asyncio.gather(president_info_task, *validation_tasks)

        # Step 5: Synthesize findings to construct the final answer
        final_answer = await self.ensemble(
            instruction="Combine the refined information about Joshua Wanume Kibedi's service years, "
                        "the President of Uganda's tenure, and any validation results to construct a concise answer. "
                        "Ensure the answer directly addresses the question.",
            contexts=[refined_kibedi_info, president_info] + validation_results
        )

        return final_answer