# Workflow ID: hotpotqa_298_0
# Benchmark: hotpotqa
# Data Indices: [212]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Parse the question to identify key entities and reasoning type
        question_analysis = await self.generate(
            instruction="""Analyze the question to identify the main entities and the type of reasoning required (e.g., bridge, comparison, compositional). 
            Extract all relevant entities and their relationships explicitly. Ensure the output is structured as a JSON object with keys 'entities' and 'reasoning_type'.""",
            context=self.problem_text
        )

        # Step 2: Determine relevant documents based on extracted entities
        document_relevance = await self.generate(
            instruction=f"""Based on the extracted entities {question_analysis}, evaluate the relevance of each document provided in the context. 
            For each document, provide a brief justification for its relevance or irrelevance to the question. Structure the output as a JSON object with document titles as keys and relevance scores as values.""",
            context=self.problem_text
        )

        # Step 3: Resolve entity ambiguities across documents
        entity_resolution = await self.revise(
            instruction=f"""Critique and refine the entity resolution process based on the extracted entities {question_analysis} and document relevance {document_relevance}. 
            Identify any ambiguities in entity mentions across documents and resolve them. Provide a clear mapping of entities across documents.""",
            context=document_relevance
        )

        # Step 4: Construct the reasoning chain
        reasoning_chain = await self.generate(
            instruction=f"""Using the resolved entities {entity_resolution}, construct a step-by-step reasoning chain that connects the documents to answer the question. 
            Explicitly mention the intermediate facts or 'bridge entities' that link the documents. Ensure the reasoning chain is logical and complete.""",
            context=self.problem_text
        )

        # Step 5: Extract the final answer
        answer_extraction = await self.summarize(
            instruction=f"""Based on the reasoning chain {reasoning_chain}, extract the final answer to the question. 
            Ensure the answer is concise, precise, and directly addresses the question.""",
            context=self.problem_text
        )

        # Step 6: Validate the final answer
        final_answer = await self.ensemble(
            instruction=f"""Compare the extracted answer {answer_extraction} with the reasoning chain {reasoning_chain} and the original documents. 
            Select the most accurate and well-supported answer.""",
            contexts=[answer_extraction, reasoning_chain]
        )

        return final_answer