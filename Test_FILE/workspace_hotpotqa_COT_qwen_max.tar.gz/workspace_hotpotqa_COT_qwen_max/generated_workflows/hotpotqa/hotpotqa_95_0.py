# Workflow ID: hotpotqa_95_0
# Benchmark: hotpotqa
# Data Indices: [319]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio
        
        # Step 1: Entity and Relationship Extraction
        entity_extraction_instruction = """
        Identify all entities mentioned in the question and extract relevant information about them from the provided documents. 
        Focus on relationships, categories, and any descriptive details that might help answer the question.
        """
        entities_info = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)
        
        # Step 2: Document Selection
        document_selection_instruction = f"""
        Given the extracted entities and their information: {entities_info}
        Evaluate which documents contain relevant information about these entities. 
        Return the indices or names of the most pertinent documents.
        """
        document_candidates = [f"Document {i+1}" for i in range(10)]  # Assuming 10 documents for illustration
        relevant_documents = await self.ensemble(instruction=document_selection_instruction, contexts=document_candidates)
        
        # Step 3: Reasoning Chain Construction
        reasoning_chain_instruction = f"""
        Using the relevant documents: {relevant_documents}
        Construct a reasoning chain that connects the entities mentioned in the question across these documents.
        Synthesize the information to form a coherent explanation that leads to the answer.
        """
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)
        
        # Step 4: Answer Extraction
        answer_extraction_instruction = f"""
        Based on the reasoning chain: {reasoning_chain}
        Extract the final answer to the question in a concise format. Ensure it is directly supported by the documents.
        """
        extracted_answer = await self.summarize(instruction=answer_extraction_instruction, context=reasoning_chain)
        
        # Step 5: Validation and Refinement
        validation_instruction = f"""
        Review the extracted answer: {extracted_answer}
        Validate its accuracy and refine it if necessary. Ensure it is well-supported by the documents and addresses the question fully.
        """
        final_answer = await self.revise(instruction=validation_instruction, context=extracted_answer)
        
        return final_answer