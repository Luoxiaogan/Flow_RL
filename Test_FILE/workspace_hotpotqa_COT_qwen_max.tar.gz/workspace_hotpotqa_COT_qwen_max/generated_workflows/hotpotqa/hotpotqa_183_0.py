# Workflow ID: hotpotqa_183_0
# Benchmark: hotpotqa
# Data Indices: [230]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Identify key entities and relationships
        entity_extraction_instruction = (
            "Extract all key entities and relationships mentioned in the question. "
            "Focus on identifying bridge entities that connect multiple documents. "
            "Provide the output in a structured format."
        )
        entities_and_relationships = await self.generate(
            instruction=entity_extraction_instruction,
            context=self.problem_text
        )

        # Step 2: Document selection
        document_selection_instruction = (
            f"Given the extracted entities and relationships: {entities_and_relationships}, "
            "identify which documents are most relevant to answering the question. "
            "Score each document based on relevance and provide a ranked list."
        )
        document_scores = await asyncio.gather(
            *[self.generate(instruction=document_selection_instruction, context=doc) 
              for doc in self.problem_text.split("\n\n") if doc.strip()]
        )
        selected_documents = await self.ensemble(
            instruction="Select the top 2-3 most relevant documents based on the scores provided.",
            contexts=document_scores
        )

        # Step 3: Reasoning chain construction
        reasoning_chain_instruction = (
            f"Using the selected documents: {selected_documents}, "
            "construct a reasoning chain that connects the information across documents. "
            "Ensure the chain explicitly mentions how entities and facts are linked."
        )
        reasoning_chain = await self.generate(
            instruction=reasoning_chain_instruction,
            context=self.problem_text
        )

        # Step 4: Answer extraction
        answer_extraction_instruction = (
            f"From the reasoning chain: {reasoning_chain}, "
            "extract the final answer to the question. Ensure the answer is concise and directly addresses the question."
        )
        raw_answer = await self.summarize(
            instruction=answer_extraction_instruction,
            context=self.problem_text
        )

        # Step 5: Refinement
        refinement_instruction = (
            f"Refine the following answer for clarity and correctness: {raw_answer}. "
            "Ensure it is well-formatted and free of ambiguity."
        )
        final_answer = await self.revise(
            instruction=refinement_instruction,
            context=raw_answer
        )

        return final_answer