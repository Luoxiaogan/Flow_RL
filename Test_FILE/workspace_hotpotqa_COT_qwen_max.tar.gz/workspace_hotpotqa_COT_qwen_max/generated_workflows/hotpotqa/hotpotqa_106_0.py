# Workflow ID: hotpotqa_106_0
# Benchmark: hotpotqa
# Data Indices: [88]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key entities from the question
        entity_extraction_instruction = """
        Extract all key entities mentioned in the question. 
        Focus on named entities such as people, organizations, or specific concepts. 
        Return the entities as a comma-separated list.
        """
        entities = await self.generate(instruction=entity_extraction_instruction, context=self.problem_text)

        # Step 2: Identify relevant documents
        document_selection_instruction = f"""
        Given the extracted entities: {entities}, 
        identify which documents mention these entities. 
        Return a list of document IDs or titles that are relevant to the question.
        """
        relevant_documents = await self.generate(instruction=document_selection_instruction, context=self.problem_text)

        # Step 3: Build a reasoning chain using the bridge entity
        reasoning_chain_instruction = f"""
        Using the relevant documents: {relevant_documents}, 
        build a reasoning chain to connect the entities mentioned in the question. 
        Focus on finding the "bridge entity" that links multiple documents. 
        Provide a step-by-step explanation of how the entities are connected.
        """
        reasoning_chain = await self.generate(instruction=reasoning_chain_instruction, context=self.problem_text)

        # Step 4: Synthesize information from multiple documents
        synthesis_instruction = f"""
        Given the reasoning chain: {reasoning_chain}, 
        synthesize the information from the relevant documents to answer the question. 
        Ensure the answer is supported by evidence from the text.
        """
        candidate_answers = await asyncio.gather(
            self.generate(instruction=synthesis_instruction, context=self.problem_text),
            self.generate(instruction=synthesis_instruction, context=self.problem_text)
        )
        final_answer = await self.ensemble(
            instruction="Select the most accurate and well-supported answer.", 
            contexts=candidate_answers
        )

        # Step 5: Refine and extract the final answer
        refinement_instruction = """
        Refine the answer to ensure it is concise and directly addresses the question. 
        Extract the precise answer span from the text.
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        return refined_answer