# Workflow ID: drop_169_0
# Benchmark: drop
# Data Indices: [744, 126]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information from the passage and question
        extraction_instruction = """
        Extract all relevant information from the passage and question. Include:
        - Numerical values and their associated entities
        - Key entities (people, places, organizations, etc.)
        - Relationships between entities
        - Contextual clues that might affect the answer
        - Any implicit information that needs to be inferred
        Ensure the extraction is exhaustive and precise.
        """
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Perform reasoning or calculation based on extracted information
        reasoning_instruction = f"""
        Using the extracted information: {extraction}
        Perform the necessary reasoning or calculations to answer the question. This may involve:
        - Arithmetic operations (addition, subtraction, etc.)
        - Counting occurrences
        - Comparing values
        - Extracting specific spans of text
        Clearly outline the reasoning steps and provide the final answer.
        """
        reasoning = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Validate and refine the derived answer
        validation_instruction = f"""
        Critique and refine the following solution: {reasoning}
        Check for:
        - Consistency with the passage
        - Accuracy of calculations or reasoning
        - Completeness of information considered
        Provide a refined answer if necessary.
        """
        refined_answer = await self.revise(instruction=validation_instruction, context=reasoning)

        # Step 4: Compile the final answer
        final_instruction = f"""
        Given the refined answer: {refined_answer}
        Compile the final answer in the required format. If multiple interpretations exist, select the most appropriate one based on the context.
        Ensure the output adheres to the expected answer type (number, date, text span, etc.).
        """
        final_answer = await self.generate(instruction=final_instruction, context=self.problem_text)

        return final_answer