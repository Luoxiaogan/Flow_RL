# Workflow ID: drop_379_0
# Benchmark: drop
# Data Indices: [478, 514]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the passage
        extract_instruction = """
        Thoroughly analyze the provided passage and extract all relevant information, including:
        - Entities (people, teams, organizations, etc.)
        - Numerical values and their associated contexts
        - Relationships between entities and events
        - Temporal information (dates, times, sequences)
        Ensure that no relevant detail is missed and organize the extracted information clearly.
        """
        extraction_task = self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its type and intent
        question_analysis_instruction = """
        Carefully analyze the question and determine its type and intent. Specifically:
        - Identify if the question involves arithmetic operations (e.g., addition, subtraction), counting, comparison, or span extraction.
        - Clarify what specific information or reasoning is required to answer the question.
        - Provide a detailed breakdown of the steps needed to arrive at the answer.
        """
        analysis_task = self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Execute Steps 1 and 2 in parallel
        extraction, analysis = await asyncio.gather(extraction_task, analysis_task)

        # Step 3: Perform reasoning based on the question type
        reasoning_instruction = f"""
        Using the extracted information: {extraction}
        And the question analysis: {analysis}
        Perform the necessary reasoning to answer the question. Follow these guidelines:
        - If the question involves arithmetic, perform the required calculations step by step.
        - If the question involves counting, ensure all relevant occurrences are considered.
        - If the question involves comparison, clearly compare the relevant values or entities.
        - If the question involves span extraction, identify the exact text span that answers the question.
        Provide a detailed explanation of the reasoning process and the final answer.
        """
        reasoning = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the answer
        refine_instruction = """
        Critique the provided reasoning and answer. Specifically:
        - Check for any logical errors or inconsistencies.
        - Ensure the answer is supported by the extracted information and aligns with the question intent.
        - Refine the answer to make it clearer, more concise, and accurate.
        """
        refined_answer = await self.revise(instruction=refine_instruction, context=reasoning)

        # Final Output
        return refined_answer