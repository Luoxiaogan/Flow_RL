# Workflow ID: drop_275_0
# Benchmark: drop
# Data Indices: [23, 26]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio
        
        # Step 1: Initial Extraction
        extraction_instruction = (
            "Extract all numerical values, entities, dates, and key phrases from the passage. "
            "Include any information that could be relevant to answering questions about the passage. "
            "Format the output as a structured list."
        )
        extracted_data = await self.generate(instruction=extraction_instruction, context=self.problem_text)
        
        # Step 2: Question Analysis
        analysis_instruction = (
            f"Analyze the question and determine its type (arithmetic, counting, comparison, selection, span extraction). "
            f"Identify the intent of the question (e.g., sum, difference, specific value, etc.). "
            f"Use the following extracted data for context: {extracted_data}. "
            f"Provide a clear explanation of the reasoning process."
        )
        question_analysis = await self.generate(instruction=analysis_instruction, context=self.problem_text)
        
        # Step 3: Parallel Reasoning Paths
        arithmetic_instruction = (
            f"Perform any required arithmetic operations using the extracted numerical values: {extracted_data}. "
            f"Follow the reasoning outlined in the question analysis: {question_analysis}."
        )
        counting_instruction = (
            f"Count the occurrences of specific entities or events mentioned in the question. "
            f"Use the extracted data: {extracted_data} and reasoning: {question_analysis}."
        )
        comparison_instruction = (
            f"Compare values or entities based on the criteria specified in the question. "
            f"Use the extracted data: {extracted_data} and reasoning: {question_analysis}."
        )
        selection_instruction = (
            f"Select the correct entity or event based on the focus of the question. "
            f"Use the extracted data: {extracted_data} and reasoning: {question_analysis}."
        )
        span_extraction_instruction = (
            f"Extract the exact text span from the passage that answers the question. "
            f"Use the extracted data: {extracted_data} and reasoning: {question_analysis}."
        )
        
        results = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=counting_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text),
            self.generate(instruction=selection_instruction, context=self.problem_text),
            self.generate(instruction=span_extraction_instruction, context=self.problem_text)
        )
        
        # Step 4: Synthesis and Final Answer
        synthesis_instruction = (
            "Evaluate the results from the parallel reasoning paths and select the most appropriate answer. "
            "Ensure the final output is formatted correctly and aligns with the question's requirements."
        )
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=results)
        
        return final_answer