# Workflow ID: drop_259_0
# Benchmark: drop
# Data Indices: [686, 205]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant entities, numbers, and spans from the passage
        extraction_instruction = """
        Extract all numerical values, dates, entity names, and relevant text spans from the passage. 
        Ensure you capture every instance explicitly mentioned, even if they seem redundant. 
        Organize the extracted information into categories: numbers, dates, entities, and spans.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its type and intent
        question_analysis_instruction = f"""
        Analyze the question to determine its type and intent. Specifically:
        - Identify if it involves arithmetic (e.g., addition, subtraction), counting, comparison, selection, or span extraction.
        - Determine the specific entities or values the question refers to.
        - Provide a clear breakdown of what needs to be computed or extracted.
        Use the following extracted information as context: {extracted_info}.
        """
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Spawn parallel reasoning paths based on the question type
        reasoning_paths = []
        reasoning_instructions = [
            "Compute the sum of all relevant numerical values.",
            "Compute the difference between relevant numerical values.",
            "Count the occurrences of specific entities or events.",
            "Compare two or more values and determine which is greater/longer/more.",
            "Extract the exact text span or entity name requested by the question."
        ]
        for instruction in reasoning_instructions:
            reasoning_paths.append(
                self.generate(
                    instruction=f"Based on the question analysis ({question_analysis}), {instruction}",
                    context=self.problem_text
                )
            )
        reasoning_results = await asyncio.gather(*reasoning_paths)

        # Step 4: Use Ensemble to decide the best answer
        ensemble_instruction = f"""
        Evaluate the following candidate answers and select the most appropriate one based on the question analysis ({question_analysis}).
        Ensure the selected answer is consistent with the extracted information ({extracted_info}) and the question's intent.
        Candidate Answers: {reasoning_results}
        """
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=reasoning_results)

        # Step 5: Refine the final answer for clarity and correctness
        refinement_instruction = f"""
        Refine the following answer to ensure it is clear, concise, and fully supported by the passage. 
        Resolve any ambiguities or inconsistencies. Final Answer: {final_answer}
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        return refined_answer