# Workflow ID: drop_43_0
# Benchmark: drop
# Data Indices: [260, 665]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant entities, numbers, and relationships
        extraction_instruction = (
            "Thoroughly analyze the passage and extract ALL relevant entities, numerical values, "
            "and their relationships. Pay special attention to entities mentioned in the question "
            "and any associated numerical or contextual details. Ensure no information is missed."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_analysis_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Carefully analyze the question and determine its intent. Identify whether the question "
            "requires an arithmetic operation, counting, comparison, selection, or span extraction. "
            "Provide a clear explanation of the reasoning behind your determination."
        )
        question_intent = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Generate the solution based on the question intent
        solution_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            f"And the question intent analysis: {question_intent}\n"
            "Solve the problem step by step. If the question involves arithmetic, perform the required "
            "calculation. If it involves counting, tally the occurrences. If it involves comparison, "
            "evaluate the relationships. If it involves span extraction, identify the exact text span. "
            "Ensure the solution is accurate and well-reasoned."
        )
        solution = await self.generate(instruction=solution_instruction, context=self.problem_text)

        # Step 4: Validate and refine the solution
        refinement_instruction = (
            f"Review the generated solution: {solution}\n"
            "Critique and refine it to ensure accuracy. Cross-check the answer against the passage "
            "and address any ambiguities, implicit information, or errors. Provide a revised version "
            "of the solution if necessary."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=solution)

        # Step 5: Summarize the final answer
        summarization_instruction = (
            f"Condense the refined solution: {refined_solution}\n"
            "into a concise, final answer. Remove any extraneous details while preserving clarity "
            "and correctness."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_solution)

        return final_answer