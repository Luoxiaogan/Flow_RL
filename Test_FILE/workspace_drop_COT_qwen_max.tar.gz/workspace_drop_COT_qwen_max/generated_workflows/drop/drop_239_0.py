# Workflow ID: drop_239_0
# Benchmark: drop
# Data Indices: [178, 555]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract relevant information from the passage
        extraction_instruction = (
            "Carefully analyze the passage and question. "
            "Extract all relevant entities, numerical values, and relationships. "
            "Focus on information that directly addresses the question. "
            "For example, identify entities mentioned in the question, their associated values, "
            "and any implicit relationships or events described in the passage."
        )
        extracted_info = await self.generate(
            instruction=extraction_instruction,
            context=self.problem_text
        )

        # Step 2: Perform reasoning based on the extracted information
        reasoning_instruction = (
            f"Based on the following extracted information: {extracted_info}\n"
            "Perform the necessary reasoning to answer the question. "
            "If the question involves arithmetic, calculate the required value. "
            "If it involves counting, count the occurrences of the specified entity or event. "
            "If it involves comparison, determine which entity satisfies the condition. "
            "If it involves span extraction, identify the exact text span that answers the question. "
            "Provide a detailed explanation of your reasoning process."
        )
        reasoning_result = await self.generate(
            instruction=reasoning_instruction,
            context=self.problem_text
        )

        # Step 3: Refine the reasoning result
        refinement_instruction = (
            "Critique and refine the following reasoning result: "
            f"{reasoning_result}\n"
            "Ensure the reasoning is accurate and addresses the question fully. "
            "Correct any errors, resolve ambiguities, and clarify the explanation if needed."
        )
        refined_result = await self.revise(
            instruction=refinement_instruction,
            context=reasoning_result
        )

        # Step 4: Summarize the final answer
        summarization_instruction = (
            "Condense the following refined result into a concise, final answer: "
            f"{refined_result}\n"
            "Ensure the answer directly addresses the question and is presented in a clear format."
        )
        final_answer = await self.summarize(
            instruction=summarization_instruction,
            context=refined_result
        )

        return final_answer