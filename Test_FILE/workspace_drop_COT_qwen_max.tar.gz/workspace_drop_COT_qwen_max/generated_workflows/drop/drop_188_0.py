# Workflow ID: drop_188_0
# Benchmark: drop
# Data Indices: [647, 476]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio
        
        # Step 1: Extract relevant information from the passage
        extract_instruction = """
        Extract all entities, numerical values, and relationships mentioned in the passage. 
        Focus on information that could be relevant to answering questions about counts, comparisons, 
        arithmetic operations, or specific spans of text. Ensure no detail is missed.
        """
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)
        
        # Step 2: Analyze the question to determine its type
        analyze_instruction = f"""
        Analyze the question and classify it into one of the following categories:
        - Arithmetic Operations (e.g., addition, subtraction, multiplication, division)
        - Counting (e.g., how many times, how many different)
        - Comparison (e.g., which is greater, longer, more)
        - Selection (e.g., which team won, what happened first/last)
        - Span Extraction (e.g., who did, what was the name of)
        Use the extracted information: {extracted_info} to guide your analysis.
        """
        question_analysis = await self.generate(instruction=analyze_instruction, context=self.problem_text)
        
        # Step 3: Perform reasoning based on the question type
        reasoning_instruction = f"""
        Based on the question analysis: {question_analysis}, perform the necessary reasoning:
        - For Arithmetic Operations, extract relevant numbers and their associated entities, then perform the required calculation.
        - For Counting, identify all instances of the requested item and count them.
        - For Comparison, evaluate multiple candidates and select the appropriate one.
        - For Selection, identify the correct entity or event based on the criteria provided.
        - For Span Extraction, locate the exact text span that answers the question.
        Use the extracted information: {extracted_info} to guide your reasoning.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)
        
        # Step 4: Refine the answer for accuracy and clarity
        refine_instruction = f"""
        Review the reasoning result: {reasoning_result} and ensure it is accurate, well-formatted, 
        and directly addresses the question. Correct any errors or ambiguities.
        """
        final_answer = await self.revise(instruction=refine_instruction, context=reasoning_result)
        
        return final_answer