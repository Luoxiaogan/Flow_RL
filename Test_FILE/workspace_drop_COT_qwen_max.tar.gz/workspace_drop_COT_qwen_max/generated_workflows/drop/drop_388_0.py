# Workflow ID: drop_388_0
# Benchmark: drop
# Data Indices: [631, 48]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (entities, numbers, relationships)
        extract_instruction = """Extract ALL relevant entities, numerical values, and relationships from the passage and question. 
        Ensure you capture every detail, including implicit information, pronoun references, and multi-hop connections. 
        Format your response as a structured list or table for clarity."""
        extraction_task = self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Analyze question intent
        intent_instruction = """Analyze the intent of the question. Determine whether it requires arithmetic operations, counting, comparison, selection, or span extraction. 
        Provide a clear explanation of the reasoning process and categorize the question type."""
        intent_task = self.generate(instruction=intent_instruction, context=self.problem_text)

        # Run extraction and intent analysis in parallel
        extraction, intent = await asyncio.gather(extraction_task, intent_task)

        # Step 3: Perform reasoning or calculation
        reasoning_instruction = f"""Based on the extracted information: {extraction}
        And the identified question intent: {intent}
        Perform the required reasoning or calculation to arrive at the answer. 
        Follow a step-by-step approach, clearly showing how each piece of information contributes to the solution."""
        reasoning = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the answer
        refine_instruction = f"""Validate the following reasoning and answer: {reasoning}
        Cross-check it with the original passage and question to ensure accuracy. 
        If any errors or ambiguities are found, refine the answer accordingly."""
        refined_answer = await self.revise(instruction=refine_instruction, context=reasoning)

        # Step 5: Finalize output
        finalize_instruction = """Condense the final answer into the required format (number, text span, etc.). 
        Ensure the output is concise, accurate, and directly addresses the question."""
        final_answer = await self.summarize(instruction=finalize_instruction, context=refined_answer)

        return final_answer