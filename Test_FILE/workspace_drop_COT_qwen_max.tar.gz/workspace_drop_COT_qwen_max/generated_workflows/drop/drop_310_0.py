# Workflow ID: drop_310_0
# Benchmark: drop
# Data Indices: [108, 458]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract key entities, numerical values, and relationships
        extraction_instruction = """
        Carefully analyze the passage and question. Extract all entities, numerical values, 
        dates, and their relationships. Ensure that each numerical value is associated with 
        its corresponding entity or context. Provide the output in a structured format.
        """
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question type and reasoning strategy
        analysis_instruction = f"""
        Based on the extracted information: {extraction}
        Analyze the question type (arithmetic, counting, comparison, selection, span extraction). 
        Determine the specific reasoning strategy required to answer the question. 
        Provide a detailed plan for solving the problem.
        """
        analysis = await self.generate(instruction=analysis_instruction, context=self.problem_text)

        # Step 3: Parallel reasoning paths
        arithmetic_instruction = f"""
        Perform any arithmetic operations (addition, subtraction, etc.) required to solve the problem. 
        Use the extracted numerical values and their associations: {extraction}. 
        Show your calculations step-by-step.
        """
        counting_instruction = f"""
        Count the occurrences or entities mentioned in the question. 
        Use the extracted information: {extraction}. 
        Ensure that all relevant instances are included.
        """
        comparison_instruction = f"""
        Compare the entities or values mentioned in the question. 
        Use the extracted information: {extraction}. 
        Determine which entity or value satisfies the condition.
        """
        span_extraction_instruction = f"""
        Locate the exact text span in the passage that answers the question. 
        Use the extracted information: {extraction}. 
        Ensure that the span is precise and complete.
        """

        arithmetic_result, counting_result, comparison_result, span_result = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=counting_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text),
            self.generate(instruction=span_extraction_instruction, context=self.problem_text)
        )

        # Step 4: Synthesize results using Ensemble
        synthesis_instruction = f"""
        Evaluate and synthesize the following reasoning paths:
        - Arithmetic Result: {arithmetic_result}
        - Counting Result: {counting_result}
        - Comparison Result: {comparison_result}
        - Span Extraction Result: {span_result}
        Select the most appropriate result based on the question type and reasoning strategy. 
        Ensure consistency and accuracy.
        """
        synthesis = await self.ensemble(
            instruction=synthesis_instruction,
            contexts=[arithmetic_result, counting_result, comparison_result, span_result]
        )

        # Step 5: Final refinement
        refinement_instruction = f"""
        Refine the synthesized result: {synthesis}
        Ensure that the final answer is concise, accurate, and formatted appropriately. 
        Address any ambiguities or inconsistencies.
        """
        final_answer = await self.revise(instruction=refinement_instruction, context=synthesis)

        return final_answer