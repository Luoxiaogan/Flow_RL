# Workflow ID: drop_185_0
# Benchmark: drop
# Data Indices: [446, 523]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract relevant information from the passage
        extract_instruction = """
        Extract all numerical values, entities, and relationships mentioned in the passage.
        Include explicit and implicit information, such as counts, measurements, dates, and named entities.
        Organize the extracted information clearly, associating numbers with their corresponding entities.
        """
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_intent_instruction = f"""
        Analyze the question to determine its intent. Identify whether the question requires:
        - Arithmetic operations (e.g., sum, difference, multiplication, division)
        - Counting (e.g., how many times, how many different)
        - Comparison (e.g., greater than, less than, longest, shortest)
        - Span extraction (e.g., names, phrases, or specific text spans)
        - Other reasoning (e.g., inference, coreference resolution).
        Use the following extracted information for context: {extracted_info}
        """
        question_intent = await self.generate(instruction=question_intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question intent
        reasoning_instruction = f"""
        Based on the question intent ({question_intent}), perform the necessary reasoning steps:
        - For arithmetic operations, calculate the result using the extracted numerical values.
        - For counting, count the relevant occurrences or entities.
        - For comparisons, compare the relevant values or entities.
        - For span extraction, identify the exact text span that answers the question.
        Ensure all reasoning steps are clearly explained and justified.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the reasoning output
        refine_instruction = f"""
        Critique and refine the reasoning output ({reasoning_result}).
        Cross-check the result against the passage and the question to ensure accuracy.
        Identify and correct any errors or inconsistencies.
        """
        refined_result = await self.revise(instruction=refine_instruction, context=reasoning_result)

        # Step 5: Summarize the final answer
        summarize_instruction = f"""
        Condense the refined reasoning ({refined_result}) into a concise, final answer.
        Ensure the answer directly addresses the question and is supported by the passage.
        """
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_result)

        # Step 6: Handle ambiguity (if necessary)
        # If multiple interpretations or candidate answers exist, use Ensemble to decide
        if "multiple" in refined_result.lower() or "ambiguous" in refined_result.lower():
            ensemble_instruction = f"""
            Evaluate the following candidate answers and select the best one:
            - Candidate 1: {final_answer}
            - Candidate 2: [Alternative interpretation or calculation]
            Justify the selection based on the passage and the question.
            """
            final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[final_answer, self.problem_text])

        return final_answer