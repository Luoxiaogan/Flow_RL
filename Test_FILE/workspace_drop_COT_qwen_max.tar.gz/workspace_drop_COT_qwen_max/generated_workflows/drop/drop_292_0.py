# Workflow ID: drop_292_0
# Benchmark: drop
# Data Indices: [177, 795]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant entities, numerical values, and relationships
        extraction_instruction = (
            "Extract all entities, numerical values, and their relationships from the passage and question. "
            "Identify the type of question being asked (e.g., arithmetic, counting, comparison, selection). "
            "Provide the extracted information in a structured format."
        )
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Perform reasoning or calculation based on the extracted information
        reasoning_instruction = (
            f"Based on the following extracted information: {extraction} "
            "Perform the required reasoning or calculation to answer the question. "
            "If the question involves arithmetic, perform the necessary operations. "
            "If it involves counting, count the relevant occurrences. "
            "If it involves comparison, compare the relevant values. "
            "If it involves selection, identify the correct entity or span. "
            "Provide the reasoning process and the intermediate results."
        )
        reasoning = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Validate and refine the reasoning output
        refinement_instruction = (
            f"Critique and refine the following reasoning output: {reasoning} "
            "Ensure that the reasoning process is accurate and addresses the question fully. "
            "Correct any ambiguities, errors, or omissions in the reasoning."
        )
        refined_reasoning = await self.revise(instruction=refinement_instruction, context=reasoning)

        # Step 4: Summarize the refined reasoning into a concise final answer
        summarization_instruction = (
            f"Condense the following refined reasoning into a concise final answer: {refined_reasoning} "
            "Ensure the final answer directly addresses the question and is presented clearly."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_reasoning)

        return final_answer