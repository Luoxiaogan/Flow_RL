# Workflow ID: drop_109_0
# Benchmark: drop
# Data Indices: [302, 717]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the passage and question
        extract_instruction = """
        Carefully analyze the provided passage and question. 
        Identify all entities (people, teams, events, etc.), numerical values, dates, and relationships mentioned. 
        Highlight any explicit or implicit connections between these elements. 
        Format your output as a structured list of findings.
        """
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Identify the question intent and refine the extracted information
        refine_instruction = f"""
        Based on the following extracted information: {extracted_info}
        Determine the type of reasoning required by the question. 
        Common types include arithmetic operations (addition, subtraction, etc.), counting, comparison, selection, and span extraction. 
        Refine the extracted information to focus on elements relevant to the question's intent.
        """
        refined_info = await self.revise(instruction=refine_instruction, context=extracted_info)

        # Step 3: Perform reasoning based on the question intent
        reasoning_tasks = []
        reasoning_instruction_template = """
        Given the refined information: {refined_info}
        Perform the required reasoning step for the identified question type. 
        If the question involves arithmetic, calculate the result using the relevant numbers. 
        If it involves comparison, evaluate the relationship between the entities. 
        If it involves span extraction, identify the exact phrase or entity from the passage that answers the question.
        """
        reasoning_instruction = reasoning_instruction_template.format(refined_info=refined_info)
        reasoning_tasks.append(self.generate(instruction=reasoning_instruction, context=self.problem_text))

        # Execute reasoning tasks in parallel
        reasoning_results = await asyncio.gather(*reasoning_tasks)

        # Step 4: Synthesize the final answer
        synthesis_instruction = f"""
        Given the following reasoning results: {reasoning_results}
        Combine them into a single, coherent answer that directly addresses the question. 
        Ensure the output format matches the expected answer type (number, date, text span, etc.).
        """
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=reasoning_results)

        return final_answer