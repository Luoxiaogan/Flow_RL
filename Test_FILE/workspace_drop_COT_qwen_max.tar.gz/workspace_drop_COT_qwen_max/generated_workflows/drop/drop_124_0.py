# Workflow ID: drop_124_0
# Benchmark: drop
# Data Indices: [792, 222]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Analyze the question to determine its intent
        question_analysis = await self.generate(
            instruction="Analyze the question to determine its intent (e.g., span extraction, counting, arithmetic, comparison). "
                        "Identify key entities, numerical values, or temporal references mentioned in the question. "
                        "Provide a detailed breakdown of what the question is asking and how to approach solving it.",
            context=self.problem_text
        )

        # Step 2: Extract relevant information from the passage
        extraction_instruction = f"Based on the following question analysis: {question_analysis}, " \
                                 "extract all relevant information from the passage. " \
                                 "Include entities, numerical values, temporal references, and their contexts. " \
                                 "Ensure no relevant occurrence is missed."
        extracted_info = await self.generate(
            instruction=extraction_instruction,
            context=self.problem_text
        )

        # Step 3: Perform reasoning or calculation
        reasoning_instruction = f"Using the extracted information: {extracted_info}, " \
                                "perform the necessary reasoning or calculation to answer the question. " \
                                "If the question involves arithmetic, compute the required value. " \
                                "If it involves counting, count the relevant occurrences. " \
                                "If it involves comparison, compare the values and determine the result."
        reasoning_result = await self.generate(
            instruction=reasoning_instruction,
            context=self.problem_text
        )

        # Step 4: Validate and refine intermediate results
        refined_result = await self.revise(
            instruction="Review the following reasoning result for accuracy and coherence. "
                        "Ensure all steps are logically sound and the answer matches the question's requirements.",
            context=reasoning_result
        )

        # Step 5: Synthesize the final answer
        final_answer = await self.ensemble(
            instruction="Evaluate the following refined result and synthesize the final answer. "
                        "Ensure the answer is clear, concise, and directly addresses the question.",
            contexts=[refined_result, extracted_info]
        )

        return final_answer