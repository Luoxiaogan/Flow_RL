# Workflow ID: drop_335_0
# Benchmark: drop
# Data Indices: [761, 429]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract entities, relationships, and numerical values
        extraction_instruction = """
        Analyze the provided passage and question thoroughly. Identify all entities, numerical values, dates, and relationships mentioned. 
        Provide a structured breakdown of the information, including:
        - Key entities (people, places, objects)
        - Numerical values and their associated entities
        - Relationships between entities (e.g., who did what, what happened when)
        - Any implicit or explicit comparisons or calculations
        Ensure the output is comprehensive and unambiguous.
        """
        extraction_task = self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Perform numerical reasoning and calculations
        reasoning_instruction = """
        Using the extracted information, perform any necessary numerical reasoning to answer the question. 
        This may include:
        - Arithmetic operations (addition, subtraction, multiplication, division)
        - Counting occurrences of specific entities or events
        - Comparisons (greater than, less than, equal to)
        - Logical deductions based on the provided data
        Clearly show the steps of your reasoning and provide intermediate results.
        """
        reasoning_task = self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Run extraction and reasoning in parallel
        extraction_result, reasoning_result = await asyncio.gather(extraction_task, reasoning_task)

        # Step 3: Validate and refine the reasoning result
        validation_instruction = f"""
        Review the numerical reasoning results below and validate their correctness based on the original problem text.
        Identify any errors or inconsistencies and suggest corrections. Ensure the reasoning aligns with the question's intent.
        Reasoning Results: {reasoning_result}
        """
        refined_reasoning = await self.revise(instruction=validation_instruction, context=reasoning_result)

        # Step 4: Synthesize the final answer
        synthesis_instruction = f"""
        Based on the validated reasoning results, synthesize a clear and concise answer to the question. 
        Ensure the answer directly addresses the question and is formatted appropriately (e.g., number, date, text span).
        Validated Reasoning: {refined_reasoning}
        """
        final_answer = await self.generate(instruction=synthesis_instruction, context=self.problem_text)

        return final_answer