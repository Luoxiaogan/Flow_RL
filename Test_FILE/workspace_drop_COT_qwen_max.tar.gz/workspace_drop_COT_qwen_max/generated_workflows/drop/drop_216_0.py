# Workflow ID: drop_216_0
# Benchmark: drop
# Data Indices: [129, 325]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information from the passage and question
        extraction_instruction = (
            "Extract all numerical values, entities, and their relationships from the passage and question. "
            "Identify any implicit information or contextual clues that might be relevant to answering the question. "
            "Format the output as a structured list of key-value pairs, where keys are entities or concepts and values are associated details."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question type
        question_analysis_instruction = (
            f"Based on the extracted information:\n{extracted_info}\n"
            "Determine the type of reasoning required to answer the question. "
            "Classify the question into one of the following categories: arithmetic operation, counting, comparison, or span extraction. "
            "Provide a detailed explanation of the reasoning pattern needed."
        )
        question_type = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Execute reasoning based on the question type
        reasoning_result = None
        if "arithmetic operation" in question_type.lower():
            reasoning_instruction = (
                f"Perform the necessary arithmetic operations using the extracted information:\n{extracted_info}\n"
                "Clearly explain each step of the calculation and provide the final result."
            )
            reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)
        elif "counting" in question_type.lower():
            reasoning_instruction = (
                f"Count the relevant occurrences or entities based on the extracted information:\n{extracted_info}\n"
                "Clearly explain the counting process and provide the final count."
            )
            reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)
        elif "comparison" in question_type.lower():
            options = await asyncio.gather(
                self.generate(instruction="Identify the first option to compare.", context=self.problem_text),
                self.generate(instruction="Identify the second option to compare.", context=self.problem_text)
            )
            comparison_instruction = (
                f"Compare the following options:\nOption 1: {options[0]}\nOption 2: {options[1]}\n"
                "Determine which option satisfies the question's criteria and explain the reasoning."
            )
            reasoning_result = await self.ensemble(instruction=comparison_instruction, contexts=options)
        elif "span extraction" in question_type.lower():
            reasoning_instruction = (
                f"Extract the relevant text span from the passage based on the extracted information:\n{extracted_info}\n"
                "Ensure the span directly answers the question and provide it verbatim."
            )
            reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the reasoning result
        refinement_instruction = (
            f"Review the reasoning result:\n{reasoning_result}\n"
            "Identify any errors, ambiguities, or areas for improvement. "
            "Refine the result to ensure accuracy and clarity."
        )
        refined_result = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"Condense the refined reasoning result:\n{refined_result}\n"
            "Provide the final answer in the required format (number, date, text span, etc.)."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_result)

        return final_answer