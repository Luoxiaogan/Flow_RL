# Workflow ID: drop_126_0
# Benchmark: drop
# Data Indices: [592, 341]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant entities, numbers, and relationships
        extraction_instruction = (
            "Carefully analyze the passage and question. Identify all entities, numerical values, "
            "and their relationships. Resolve any ambiguous references (e.g., pronouns, partial names). "
            "Ensure that every number is correctly associated with its corresponding entity. "
            "Format the output as a structured list of findings."
        )
        extracted_data = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Perform reasoning based on the extracted data
        reasoning_instruction = (
            f"Using the following extracted information: {extracted_data}. "
            "Determine what the question is asking for and perform the necessary reasoning. "
            "If the question involves arithmetic, count occurrences, compare values, or extract spans, "
            "provide a step-by-step solution. Ensure that all calculations and inferences are explicit."
        )
        reasoning_output = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Validate and refine the reasoning output
        refinement_instruction = (
            "Critique the following reasoning output for accuracy and completeness. "
            "Check for correct entity-number associations, logical consistency, and alignment with the question's intent. "
            "If errors or ambiguities are found, provide corrections and improvements."
        )
        refined_output = await self.revise(instruction=refinement_instruction, context=reasoning_output)

        # Step 4: Summarize the final answer
        summarization_instruction = (
            "Condense the following refined reasoning into a concise answer that directly addresses the question. "
            "Ensure the answer is clear, precise, and formatted appropriately."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_output)

        return final_answer