# Workflow ID: drop_178_0
# Benchmark: drop
# Data Indices: [168, 383]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the passage
        extraction_instruction = (
            "Extract all entities, numerical values, and relationships from the passage. "
            "Include explicit and implicit information. Format the output as a structured list."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question intent
        question_intent_instruction = (
            f"Given the extracted information: {extracted_info}\n"
            "Interpret the question to determine its intent. "
            "Identify if it requires arithmetic, counting, comparison, selection, or span extraction. "
            "Provide a clear analysis of the reasoning steps needed to answer the question."
        )
        question_analysis = await self.generate(instruction=question_intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question intent
        reasoning_instruction = (
            f"Based on the question analysis: {question_analysis}\n"
            "Perform the required reasoning steps. If arithmetic is needed, calculate the result. "
            "If counting is needed, count the relevant occurrences. If comparison is needed, compare values. "
            "If span extraction is needed, extract the relevant text span. Provide intermediate results."
        )
        reasoning_results = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Generate multiple candidate solutions (if applicable)
        candidate_generation_instruction = (
            f"Based on the reasoning results: {reasoning_results}\n"
            "Generate multiple plausible answers if the question allows for ambiguity. "
            "Provide justification for each candidate solution."
        )
        candidate_solutions = await self.generate(instruction=candidate_generation_instruction, context=self.problem_text)

        # Step 5: Synthesize the final answer using Ensemble
        ensemble_instruction = (
            f"Given the candidate solutions: {candidate_solutions}\n"
            "Evaluate and synthesize the best answer. Consider relevance, accuracy, and alignment with the question. "
            "Provide the final answer along with a confidence score."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[candidate_solutions])

        # Step 6: Revise the final answer for accuracy
        revision_instruction = (
            f"Review the final answer: {final_answer}\n"
            "Critique and refine it to ensure accuracy and alignment with the passage and question. "
            "Fix any errors or inconsistencies."
        )
        revised_answer = await self.revise(instruction=revision_instruction, context=final_answer)

        return revised_answer