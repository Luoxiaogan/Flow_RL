# Workflow ID: drop_174_0
# Benchmark: drop
# Data Indices: [743, 296]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract all relevant information from the passage
        extraction_instruction = """
        Extract ALL relevant information from the passage that could help answer the question. 
        Include numerical values, entities, relationships, and contextual clues. 
        Ensure nothing is missed and provide the information in a structured format.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question's intent and refine the extracted information
        refinement_instruction = f"""
        Analyze the question's intent based on the extracted information: {extracted_info}.
        Determine if the question requires arithmetic operations, counting, comparison, or span extraction.
        Refine the extracted information into a structured format that aligns with the question's intent.
        """
        refined_analysis = await self.revise(instruction=refinement_instruction, context=extracted_info)

        # Step 3: Perform reasoning or calculation based on the refined analysis
        reasoning_instruction = f"""
        Based on the refined analysis: {refined_analysis}, perform the required reasoning or calculation.
        If the question involves arithmetic, perform the necessary operations.
        If it involves counting, ensure all relevant instances are considered.
        If it involves comparison, clearly state which entity is greater or lesser.
        If it involves span extraction, provide the exact text span from the passage.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and finalize the answer using Ensemble
        validation_instruction = """
        Evaluate the reasoning result and ensure it aligns with the question and passage context.
        If there are multiple candidate answers, compare them and select the most appropriate one.
        """
        final_answer = await self.ensemble(instruction=validation_instruction, contexts=[reasoning_result, extracted_info])

        return final_answer