# Workflow ID: drop_331_0
# Benchmark: drop
# Data Indices: [329, 122]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (entities, numbers, spans)
        extract_instruction = """
        Extract all relevant entities, numerical values, dates, and text spans from the passage. 
        Ensure you capture both explicit and implicit references. 
        Organize the extracted information clearly for downstream processing.
        """
        extract_context = self.problem_text
        extracted_info = await self.generate(instruction=extract_instruction, context=extract_context)

        # Step 2: Analyze question intent (parallelizable)
        intent_instruction = f"""
        Analyze the question to determine its intent. Classify the question into one of the following categories:
        - Arithmetic (e.g., sum, difference, product, quotient)
        - Counting (e.g., how many times, how many different)
        - Comparison (e.g., greater, less, longer, shorter)
        - Selection (e.g., who, what, which)
        - Span Extraction (e.g., name, phrase, event)
        Use the following extracted information to guide your analysis: {extracted_info}
        """
        intent_context = self.problem_text
        question_intent = await self.generate(instruction=intent_instruction, context=intent_context)

        # Step 3: Perform reasoning based on question intent
        reasoning_instruction_template = f"""
        Based on the question intent ({question_intent}), perform the necessary reasoning using the extracted information: {extracted_info}.
        Follow these guidelines:
        - For arithmetic operations, perform the required calculations.
        - For counting, count the relevant occurrences accurately.
        - For comparisons, evaluate all candidates and select the correct one.
        - For selection or span extraction, identify the most relevant entity or span.
        Provide the final answer in the required format (number, date, text span, etc.).
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction_template, context=self.problem_text)

        # Step 4: Refine the answer
        refine_instruction = f"""
        Refine the following answer to ensure it is precise, accurate, and matches the question's requirements:
        {reasoning_result}
        Pay attention to formatting and ensure the answer aligns with the expected type (number, date, span, etc.).
        """
        refined_answer = await self.revise(instruction=refine_instruction, context=reasoning_result)

        return refined_answer