# Workflow ID: drop_180_0
# Benchmark: drop
# Data Indices: [93, 775]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information from the passage
        extraction_instruction = """
        Extract all numerical values, entities, and relevant spans from the passage. 
        Ensure you capture all potential data points that could be relevant for answering the question. 
        Include any mentions of scores, counts, dates, names, or other key information.
        """
        extracted_data = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Understand the question intent
        intent_instruction = f"""
        Analyze the question to determine its intent. Specifically:
        - Identify if the question requires arithmetic operations (e.g., addition, subtraction).
        - Check if it involves counting occurrences or comparing values.
        - Determine if it seeks a specific text span or entity.
        - Consider any implicit information that needs to be inferred.
        Use the following extracted data as reference: {extracted_data}
        """
        question_intent = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question intent
        reasoning_instruction = f"""
        Based on the question intent ({question_intent}), perform the necessary reasoning:
        - If the question requires arithmetic, calculate the result using the extracted numerical values.
        - If it involves comparison, identify the relevant values and determine the relationship.
        - If it seeks a text span, refine the extracted spans to match the question's requirements.
        Ensure your reasoning process is clear and logical.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=extracted_data)

        # Step 4: Refine the reasoning result if needed
        refinement_instruction = """
        Critique and refine the reasoning result to ensure accuracy and clarity. 
        Correct any errors, clarify ambiguous statements, and ensure the result aligns with the question intent.
        """
        refined_result = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Summarize the final answer
        summary_instruction = """
        Condense the reasoning process into a final answer. 
        Ensure the answer is concise, accurate, and formatted appropriately for the question type.
        """
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_result)

        return final_answer