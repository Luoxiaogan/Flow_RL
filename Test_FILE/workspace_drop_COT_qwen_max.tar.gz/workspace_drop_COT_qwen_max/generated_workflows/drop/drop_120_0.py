# Workflow ID: drop_120_0
# Benchmark: drop
# Data Indices: [240, 474]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the passage
        extract_instruction = (
            "Extract all entities, numerical values, dates, and their relationships from the passage. "
            "Include explicit mentions as well as implicit information inferred from context. "
            "Organize the extracted information clearly, ensuring no details are missed."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Understand the question intent
        question_intent_instruction = (
            "Analyze the question carefully and determine its intent. Identify the type of reasoning required "
            "(e.g., arithmetic operation, comparison, span extraction). Specify the entities or values involved "
            "and how they relate to the extracted information."
        )
        question_intent = await self.generate(instruction=question_intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning/calculation
        reasoning_instruction = (
            f"Based on the extracted information: {extracted_info} and the question intent: {question_intent}, "
            "perform the necessary reasoning or calculation to derive the answer. If the question involves "
            "arithmetic, show the computation step-by-step. If it involves selection, justify the choice."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine and validate the answer
        refine_instruction = (
            f"Review the reasoning result: {reasoning_result}. Ensure it is accurate, consistent with the passage, "
            "and resolves any ambiguities. Correct any errors or inconsistencies."
        )
        refined_answer = await self.revise(instruction=refine_instruction, context=reasoning_result)

        # Step 5: Handle ambiguity (if needed)
        # Check if there are multiple plausible answers
        ambiguity_check_instruction = (
            "Determine if there are multiple plausible answers based on the passage. If so, list all candidates."
        )
        ambiguity_check = await self.generate(instruction=ambiguity_check_instruction, context=self.problem_text)

        if "multiple" in ambiguity_check.lower():
            ensemble_instruction = (
                f"Evaluate the following candidate answers: {ambiguity_check}. Select the most appropriate answer "
                "based on consistency with the passage and the question intent."
            )
            final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[refined_answer, ambiguity_check])
        else:
            final_answer = refined_answer

        return final_answer