# Workflow ID: drop_383_0
# Benchmark: drop
# Data Indices: [128, 614]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract all relevant entities, numbers, and relationships from the passage
        extraction_instruction = """
        Extract all entities, numerical values, and their relationships from the passage. 
        Pay special attention to:
        - Names of people, places, organizations, and events
        - Numerical values (counts, scores, dates, etc.)
        - Relationships between entities (e.g., who did what, what happened when)
        Ensure completeness and accuracy.
        """
        extracted_data = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Interpret the question and determine its type
        question_analysis_instruction = f"""
        Analyze the question and classify its type based on the following categories:
        - Arithmetic (addition, subtraction, multiplication, division)
        - Counting (how many times, how many different)
        - Comparison (greater than, less than, equal to)
        - Span Extraction (who did X, what was the name of Y)
        - Other (miscellaneous reasoning)
        Use the extracted data: {extracted_data} to inform your classification.
        """
        question_type = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or calculation based on the question type
        reasoning_instruction = f"""
        Based on the question type ({question_type}), perform the necessary reasoning or calculation:
        - For arithmetic questions, compute the result using the extracted numerical values.
        - For counting questions, count the occurrences of relevant entities or events.
        - For comparison questions, compare the relevant values or entities.
        - For span extraction questions, identify the exact text span that answers the question.
        Use the extracted data: {extracted_data} to ensure accuracy.
        """
        reasoning_results = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine the reasoning results if necessary
        refinement_instruction = f"""
        Refine the reasoning results ({reasoning_results}) to ensure they are precise and directly address the question.
        If the answer involves a text span, ensure it is an exact match from the passage.
        If the answer involves a calculation, double-check the arithmetic.
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=reasoning_results)

        # Step 5: Summarize the final answer
        summarization_instruction = f"""
        Condense the refined answer ({refined_answer}) into a concise response that directly answers the question.
        Ensure the response is clear, accurate, and formatted appropriately.
        """
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_answer)

        return final_answer