# Workflow ID: drop_65_0
# Benchmark: drop
# Data Indices: [121, 352]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract all relevant information (entities, numbers, relationships)
        extraction_instruction = (
            "Thoroughly analyze the passage and extract all numerical values, entities, "
            "and their relationships. Include any contextual clues about comparisons, "
            "counts, or arithmetic operations. Ensure no relevant detail is missed."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Understand the question intent
        question_intent_instruction = (
            f"Given the extracted information: {extracted_info}\n"
            "Interpret the question's intent. Determine whether it requires counting, "
            "comparison, arithmetic operations, span extraction, or another type of reasoning. "
            "Provide a clear breakdown of what needs to be done to answer the question."
        )
        question_intent = await self.generate(instruction=question_intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or calculation
        reasoning_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            f"And the interpreted question intent: {question_intent}\n"
            "Perform the necessary reasoning or calculations step by step. Clearly associate "
            "numbers with their respective entities and justify each step logically."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the answer
        validation_instruction = (
            f"Review the reasoning result: {reasoning_result}\n"
            "Cross-check it with the original passage to ensure accuracy. Identify and correct "
            "any inconsistencies, ambiguities, or errors. Provide a refined version of the answer."
        )
        refined_answer = await self.revise(instruction=validation_instruction, context=reasoning_result)

        # Step 5: Finalize the output
        finalize_instruction = (
            f"Condense the refined answer: {refined_answer}\n"
            "Into a concise, well-formatted response that directly answers the question. "
            "Ensure clarity and precision without losing important details."
        )
        final_output = await self.summarize(instruction=finalize_instruction, context=refined_answer)

        return final_output