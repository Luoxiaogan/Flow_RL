# Workflow ID: drop_206_0
# Benchmark: drop
# Data Indices: [688, 788]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all numerical values, entities, and their relationships
        extraction_instruction = """
        Thoroughly analyze the passage and extract all numerical values, entities, and their relationships. 
        Identify which numbers correspond to which entities (e.g., player names, team names). 
        Include any contextual information that links numbers to specific events or descriptions.
        Ensure no relevant information is missed.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_analysis_instruction = f"""
        Analyze the question in detail to determine its intent. Based on the extracted information: {extracted_info},
        identify whether the question requires arithmetic operations (e.g., addition, subtraction), counting,
        comparison, or span extraction. Provide a clear breakdown of what needs to be done to answer the question.
        """
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Construct the answer based on the analysis
        answer_construction_instruction = f"""
        Using the extracted information: {extracted_info}, and the question analysis: {question_analysis},
        construct the answer. Perform any necessary calculations, comparisons, or extractions as indicated by the analysis.
        Ensure that the answer is precise and directly addresses the question.
        """
        answer = await self.generate(instruction=answer_construction_instruction, context=self.problem_text)

        # Step 4: Validate and refine the answer
        validation_instruction = f"""
        Review the constructed answer: {answer} for correctness. Verify numerical accuracy, proper entity association,
        and alignment with the question's intent. Make any necessary refinements to ensure the answer is robust and accurate.
        """
        refined_answer = await self.revise(instruction=validation_instruction, context=answer)

        # Step 5: Ensemble decision (if needed)
        # If there are multiple interpretations or ambiguities, use ensemble to decide
        ensemble_instruction = f"""
        Evaluate the refined answer: {refined_answer} against alternative interpretations, if any exist.
        Synthesize the best possible answer based on all available information.
        """
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[refined_answer])

        return final_answer