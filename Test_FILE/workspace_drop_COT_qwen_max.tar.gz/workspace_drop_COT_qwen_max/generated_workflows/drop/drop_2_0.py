# Workflow ID: drop_2_0
# Benchmark: drop
# Data Indices: [755, 100]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract relevant entities, numbers, and relationships
        extraction_instruction = (
            "Extract all relevant entities, numerical values, and their relationships from the passage. "
            "Focus on identifying teams, players, scores, dates, and any other factual information. "
            "Ensure no important detail is missed."
        )
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_analysis_instruction = (
            "Analyze the question to determine its intent. Identify whether the question is asking for a count, "
            "a comparison, a span extraction, or a calculation. Provide a detailed breakdown of what is being asked."
        )
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform reasoning and calculations
        reasoning_instruction = (
            f"Based on the extracted information: {extraction} and the question analysis: {question_analysis}, "
            "perform the required reasoning. If the question involves arithmetic operations, calculate the result. "
            "If it involves a comparison, evaluate the entities or values. Ensure all steps are clearly explained."
        )
        reasoning = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the reasoning
        validation_instruction = (
            "Review the reasoning process and ensure it is accurate. If there are any ambiguities or implicit "
            "information, refine the answer to address them. Provide a detailed explanation of any changes made."
        )
        refined_reasoning = await self.revise(instruction=validation_instruction, context=reasoning)

        # Step 5: Synthesize the final answer
        synthesis_instruction = (
            "Condense the reasoning into a concise final answer that directly addresses the question. "
            "Ensure the answer is clear, accurate, and formatted appropriately."
        )
        final_answer = await self.summarize(instruction=synthesis_instruction, context=refined_reasoning)

        return final_answer