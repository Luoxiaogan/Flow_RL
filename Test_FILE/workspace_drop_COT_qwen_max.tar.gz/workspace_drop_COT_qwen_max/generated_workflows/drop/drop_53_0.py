# Workflow ID: drop_53_0
# Benchmark: drop
# Data Indices: [559, 361]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Analyze the question to determine its type and requirements
        question_analysis = await self.generate(
            instruction="Analyze the question to determine the type of reasoning required (e.g., arithmetic, counting, comparison, span extraction). "
                        "Identify key entities, numbers, and relationships mentioned in the question. "
                        "Provide a structured breakdown of the question's intent.",
            context=self.problem_text
        )

        # Step 2: Extract relevant information from the passage
        information_extraction = await self.generate(
            instruction=f"Based on the following question analysis: {question_analysis}, "
                        "extract all relevant facts from the passage. "
                        "Include numerical values, entities, and their relationships. "
                        "Ensure precise entity-number association.",
            context=self.problem_text
        )

        # Step 3: Perform reasoning and calculations
        reasoning_calculation = await self.generate(
            instruction=f"Using the extracted information: {information_extraction}, "
                        "perform the necessary reasoning or calculations to answer the question. "
                        "Follow the structured breakdown from the question analysis. "
                        "If arithmetic is required, show the step-by-step calculation. "
                        "If span extraction is needed, provide the exact text span from the passage.",
            context=self.problem_text
        )

        # Step 4: Validate and refine the reasoning
        validation_refinement = await self.revise(
            instruction="Critique the following reasoning or calculation: {reasoning_calculation}. "
                        "Check for errors such as incorrect entity-number associations, logical mistakes, or missing steps. "
                        "Refine the reasoning to ensure accuracy.",
            context=reasoning_calculation
        )

        # Step 5: Synthesize the final answer
        final_answer = await self.summarize(
            instruction="Condense the refined reasoning into a concise answer that directly addresses the question. "
                        "Ensure the output is clear and formatted appropriately.",
            context=validation_refinement
        )

        return final_answer