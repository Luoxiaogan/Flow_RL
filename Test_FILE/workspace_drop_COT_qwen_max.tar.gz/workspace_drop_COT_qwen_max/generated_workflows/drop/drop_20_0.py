# Workflow ID: drop_20_0
# Benchmark: drop
# Data Indices: [779, 322]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract relevant information from the passage
        extraction_instruction = """
        Extract all numerical values, entities, and relationships from the passage that could be relevant to answering the question. 
        Include explicit mentions as well as any implicit information that can be inferred from the context. 
        Format the output as a structured list for clarity.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        analysis_instruction = f"""
        Analyze the question to determine its intent. Specifically:
        - Identify whether the question requires arithmetic operations (e.g., addition, subtraction), counting, comparison, or span extraction.
        - Use the following extracted information to guide your reasoning: {extracted_info}.
        - Provide a detailed breakdown of how the question should be approached.
        """
        question_analysis = await self.generate(instruction=analysis_instruction, context=self.problem_text)

        # Step 3: Perform the required reasoning based on the question intent
        reasoning_instruction = f"""
        Based on the following question analysis: {question_analysis},
        perform the required reasoning to arrive at the answer. Ensure you:
        - Correctly associate numbers with their respective entities.
        - Handle implicit information and multi-hop inference as needed.
        - Clearly explain each step of the reasoning process.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the reasoning result
        refinement_instruction = f"""
        Critique and refine the following reasoning result: {reasoning_result}.
        Specifically:
        - Check for any ambiguities or errors in entity-number association.
        - Ensure the reasoning aligns with the question intent.
        - Suggest improvements if necessary and provide the revised reasoning.
        """
        refined_reasoning = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Summarize the refined reasoning into a concise final answer
        summary_instruction = f"""
        Condense the following refined reasoning: {refined_reasoning}, into a concise and clear final answer.
        Ensure the answer directly addresses the question and is formatted appropriately (e.g., number, text span, comparative statement).
        """
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_reasoning)

        return final_answer