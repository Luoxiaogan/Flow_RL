# Workflow ID: drop_156_0
# Benchmark: drop
# Data Indices: [312, 149]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information from the passage and question
        extraction_instruction = (
            "Carefully analyze the provided passage and question. "
            "Extract all entities, numerical values, dates, and their relationships. "
            "Pay special attention to pronouns and ambiguous references, resolving them where possible. "
            "Format the extracted information clearly, grouping related items together."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Determine the type of reasoning required and perform calculations
        reasoning_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Determine the type of reasoning required to answer the question (e.g., arithmetic, counting, comparison, selection, span extraction). "
            "Perform the necessary calculations or logical steps to arrive at the answer. "
            "Ensure that all steps are clearly documented and justified."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Validate and refine the reasoning process
        refinement_instruction = (
            f"Review the following reasoning process:\n{reasoning_result}\n"
            "Critique and refine it to ensure accuracy. "
            "Check for correct entity-number associations, proper handling of ambiguous references, and adherence to the question's intent. "
            "Provide a revised version of the reasoning process if necessary."
        )
        refined_reasoning = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 4: Condense the refined reasoning into a concise answer
        summarization_instruction = (
            f"Based on the following refined reasoning:\n{refined_reasoning}\n"
            "Produce a concise and well-formatted final answer. "
            "Ensure the answer matches the expected type (number, date, text span, etc.) and is directly responsive to the question."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_reasoning)

        return final_answer