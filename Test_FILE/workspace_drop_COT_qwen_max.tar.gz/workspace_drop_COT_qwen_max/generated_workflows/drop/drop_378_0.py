# Workflow ID: drop_378_0
# Benchmark: drop
# Data Indices: [353, 164]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract relevant information (numerical values, entities, relationships)
        extraction_instruction = (
            "Carefully analyze the passage and question to extract ALL numerical values, "
            "entities, and relationships mentioned. Provide this information in a structured format "
            "for further processing."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Understand the question intent
        intent_instruction = (
            "Based on the extracted information and the question, determine the type of reasoning "
            "required (e.g., arithmetic operation, counting, comparison, span extraction). Provide a "
            "detailed analysis of what the question is asking for."
        )
        question_intent = await self.generate(instruction=intent_instruction, context=extracted_info)

        # Step 3: Perform reasoning/calculation
        reasoning_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            f"And the question intent: {question_intent}\n"
            "Perform the necessary reasoning or calculation to arrive at the answer. Ensure that all "
            "steps are clearly explained and supported by evidence from the passage."
        )
        raw_answer = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the answer
        refine_instruction = (
            "Review the provided answer to ensure it is accurate, well-supported by the passage, "
            "and fully addresses the question. Make any necessary corrections or clarifications."
        )
        refined_answer = await self.revise(instruction=refine_instruction, context=raw_answer)

        # Step 5: Finalize the answer
        finalize_instruction = (
            "Condense the refined answer into a concise, final response that directly answers the question. "
            "Ensure the response is clear and unambiguous."
        )
        final_answer = await self.summarize(instruction=finalize_instruction, context=refined_answer)

        return final_answer