# Workflow ID: drop_161_0
# Benchmark: drop
# Data Indices: [754, 265]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant entities, numbers, and relationships
        extraction_instruction = (
            "Extract all entities, numbers, dates, and relationships from the passage. "
            "Organize them in a structured format for easy reference. "
            "Ensure no information is missed."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its type and requirements
        question_analysis_instruction = (
            "Analyze the question in detail. Determine its type (e.g., arithmetic, counting, comparison, span extraction). "
            "Identify what specific information is being asked for. "
            f"Use the following extracted information as context: {extracted_info}."
        )
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question type
        arithmetic_instruction = (
            "Perform any required arithmetic operations (addition, subtraction, etc.) using the extracted numbers. "
            "Ensure the operations align with the question's intent."
        )
        counting_instruction = (
            "Count the occurrences of specific entities or events mentioned in the question. "
            "Ensure accuracy by cross-referencing with the extracted information."
        )
        comparison_instruction = (
            "Compare multiple entities or values as required by the question. "
            "Determine the correct answer based on the comparison."
        )
        span_extraction_instruction = (
            "Identify the exact text span from the passage that answers the question. "
            "Ensure the span is precise and directly answers the question."
        )

        # Run arithmetic, counting, and comparison operations in parallel
        arithmetic_result, counting_result, comparison_result, span_result = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=extracted_info),
            self.generate(instruction=counting_instruction, context=extracted_info),
            self.generate(instruction=comparison_instruction, context=extracted_info),
            self.generate(instruction=span_extraction_instruction, context=extracted_info)
        )

        # Step 4: Validate and refine results
        validation_instruction = (
            "Validate the results from the arithmetic, counting, comparison, and span extraction steps. "
            "Refine them to ensure consistency with the passage and question intent."
        )
        refined_results = await self.revise(
            instruction=validation_instruction,
            context=f"Arithmetic: {arithmetic_result}\nCounting: {counting_result}\nComparison: {comparison_result}\nSpan: {span_result}"
        )

        # Step 5: Synthesize the final answer
        synthesis_instruction = (
            "Synthesize the final answer from the refined results. "
            "Ensure the answer is coherent, accurate, and directly addresses the question."
        )
        final_answer = await self.ensemble(
            instruction=synthesis_instruction,
            contexts=[arithmetic_result, counting_result, comparison_result, span_result, refined_results]
        )

        return final_answer