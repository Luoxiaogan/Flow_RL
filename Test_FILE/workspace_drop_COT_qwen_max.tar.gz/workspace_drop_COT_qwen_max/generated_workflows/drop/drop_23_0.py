# Workflow ID: drop_23_0
# Benchmark: drop
# Data Indices: [363, 737]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Initial Extraction
        extraction_instruction = (
            "Extract all relevant entities, numerical values, dates, and spans from the passage. "
            "Include any information that could be relevant to answering questions about the passage. "
            "Format the output as a structured list."
        )
        extracted_data = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Question Analysis
        question_analysis_instruction = (
            "Analyze the question and classify it into one of the following types: "
            "arithmetic, counting, comparison, selection, or span extraction. "
            "Provide reasoning for your classification. Examples of each type are as follows: "
            "- Arithmetic: 'How many total...', 'What is the difference...' "
            "- Counting: 'How many times...', 'How many different...' "
            "- Comparison: 'Which is greater...', 'Who had more...' "
            "- Selection: 'Which team won...', 'What happened first...' "
            "- Span Extraction: 'Who did...', 'What was the name of...' "
            "Output the classification and reasoning."
        )
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Task-Specific Operations
        # Dynamically construct instructions based on question type
        if "arithmetic" in question_analysis.lower():
            task_instruction = (
                f"Perform the required arithmetic operation using the extracted data: {extracted_data}. "
                "Ensure the calculation aligns with the question intent. Provide the final result."
            )
            task_result = await self.generate(instruction=task_instruction, context=self.problem_text)

        elif "counting" in question_analysis.lower():
            task_instruction = (
                f"Count the occurrences of the relevant entities or events using the extracted data: {extracted_data}. "
                "Ensure the count aligns with the question intent. Provide the final count."
            )
            task_result = await self.generate(instruction=task_instruction, context=self.problem_text)

        elif "comparison" in question_analysis.lower():
            options = extracted_data.split("\n")  # Split extracted data into options
            task_instruction = (
                "Compare the provided options and determine which satisfies the question's criteria. "
                "Options are as follows:\n" + "\n".join(options)
            )
            task_result = await self.ensemble(instruction=task_instruction, contexts=options)

        elif "selection" in question_analysis.lower():
            task_instruction = (
                f"Select the correct entity or event based on the question's criteria using the extracted data: {extracted_data}. "
                "Provide the selected answer."
            )
            task_result = await self.generate(instruction=task_instruction, context=self.problem_text)

        elif "span extraction" in question_analysis.lower():
            task_instruction = (
                f"Extract the exact text span from the passage that answers the question. "
                "Use the extracted data: {extracted_data} as a reference."
            )
            task_result = await self.generate(instruction=task_instruction, context=self.problem_text)

        else:
            task_result = "Unable to determine the question type."

        # Step 4: Final Answer Synthesis
        refinement_instruction = (
            f"Refine the following result to ensure clarity, correctness, and alignment with the question: {task_result}. "
            "Correct any errors or ambiguities."
        )
        refined_result = await self.revise(instruction=refinement_instruction, context=task_result)

        summary_instruction = (
            f"Summarize the refined result into a concise answer: {refined_result}. "
            "Ensure the summary directly addresses the question."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_result)

        return final_answer