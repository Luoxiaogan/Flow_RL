# Workflow ID: drop_81_0
# Benchmark: drop
# Data Indices: [229, 88]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract relevant information from the passage and question
        extraction_instruction = (
            "Extract all entities, numerical values, relationships, and reasoning cues from the passage and question. "
            "Organize the extracted information into categories: entities, numbers, events, and relationships. "
            "Ensure no relevant detail is missed."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its type
        question_analysis_instruction = (
            f"Given the extracted information: {extracted_info}\n"
            "Analyze the question to determine its type. Classify it as one of the following: "
            "arithmetic (e.g., sum, difference), counting, comparison, selection, or span extraction. "
            "Provide reasoning for the classification."
        )
        question_type = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Execute parallel reasoning paths based on question type
        arithmetic_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Perform any required arithmetic operations such as addition, subtraction, or multiplication. "
            "Show all steps and ensure accuracy."
        )
        counting_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Count the number of occurrences or instances as specified in the question. "
            "Provide a clear tally and explanation."
        )
        comparison_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Compare the relevant entities or values as specified in the question. "
            "Determine which is greater, longer, more, etc., and explain the reasoning."
        )
        selection_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Select the correct entity, span, or value as specified in the question. "
            "Provide justification for the selection."
        )

        # Execute reasoning paths in parallel
        reasoning_results = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=counting_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text),
            self.generate(instruction=selection_instruction, context=self.problem_text)
        )

        # Step 4: Refine and validate the results
        refinement_instruction = (
            "Critique and refine the following reasoning results. Ensure correctness, handle ambiguities, "
            "and improve clarity where needed. Provide the refined results."
        )
        refined_results = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction, context=result) for result in reasoning_results]
        )

        # Step 5: Synthesize the final answer using Ensemble
        ensemble_instruction = (
            "Evaluate the following refined results and synthesize the final answer. "
            "Select the most appropriate result based on the question type and reasoning quality. "
            "Provide the final answer with justification."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=refined_results)

        return final_answer