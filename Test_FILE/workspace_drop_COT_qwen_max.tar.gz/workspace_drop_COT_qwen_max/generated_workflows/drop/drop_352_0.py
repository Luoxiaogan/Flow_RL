# Workflow ID: drop_352_0
# Benchmark: drop
# Data Indices: [269, 675]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Initial Extraction
        extraction_instruction = (
            "Extract all entities, numerical values, and relationships from the passage and question. "
            "Ensure that all potentially relevant information is captured, including implicit references. "
            "Format the output clearly for further processing."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Entity-Value Association
        association_instruction = (
            f"Refine the following extracted information: {extracted_info}. "
            "Associate numerical values with their corresponding entities. "
            "Resolve any ambiguous references or partial names using the context of the passage. "
            "Ensure that each number is correctly linked to its entity."
        )
        refined_info = await self.revise(instruction=association_instruction, context=extracted_info)

        # Step 3: Reasoning and Calculation
        reasoning_instruction = (
            f"Given the refined information: {refined_info}, analyze the question and determine the required operation. "
            "Perform any necessary calculations (e.g., addition, subtraction, comparison). "
            "If the question involves counting, ensure all relevant instances are considered. "
            "Provide a clear and accurate solution based on the question's intent."
        )
        solution = await self.generate(instruction=reasoning_instruction, context=refined_info)

        # Step 4: Validation and Refinement
        validation_instruction = (
            f"Validate the following solution: {solution}. "
            "Ensure that the answer is consistent with the passage and question. "
            "Check for any errors in numerical reasoning, entity association, or implicit information handling. "
            "Refine the solution if necessary."
        )
        validated_solution = await self.revise(instruction=validation_instruction, context=solution)

        # Step 5: Final Output
        summarization_instruction = (
            f"Summarize the final answer: {validated_solution}. "
            "Ensure the output is concise, clear, and directly answers the question. "
            "Format the answer appropriately based on its type (number, text span, etc.)."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=validated_solution)

        return final_answer