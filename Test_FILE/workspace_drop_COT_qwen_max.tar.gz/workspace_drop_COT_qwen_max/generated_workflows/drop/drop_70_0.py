# Workflow ID: drop_70_0
# Benchmark: drop
# Data Indices: [261, 680]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract relevant information from the passage
        extraction_instruction = (
            "Thoroughly analyze the provided passage and extract all entities, numbers, "
            "and their relationships. Identify any implicit references (e.g., pronouns) "
            "and associate them with their corresponding entities. Ensure no relevant "
            "information is missed."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Interpret the question's intent
        intent_instruction = (
            f"Given the following extracted information: {extracted_info}\n"
            "Analyze the question and determine its intent. Does it require arithmetic "
            "operations (e.g., addition, subtraction), counting, comparison, or span extraction? "
            "Provide a clear interpretation of what the question is asking."
        )
        question_intent = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question's intent
        reasoning_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            f"And the interpreted question intent: {question_intent}\n"
            "Solve the problem step by step. Perform any required arithmetic operations, "
            "count occurrences, compare values, or extract the relevant text span. Ensure "
            "the reasoning process is explicit and accurate."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the result
        validation_instruction = (
            f"Review the following reasoning result: {reasoning_result}\n"
            "Critique it for accuracy and correctness. Cross-reference it with the original "
            "passage and question to ensure no errors exist. Provide a refined version if necessary."
        )
        refined_result = await self.revise(instruction=validation_instruction, context=reasoning_result)

        # Step 5: Handle ambiguity with Ensemble if needed
        # Check if there are multiple plausible answers
        ambiguity_check = (
            f"Determine if the following result: {refined_result}\n"
            "is ambiguous or if multiple plausible answers exist. If so, generate alternative "
            "solutions for evaluation."
        )
        alternatives = await self.generate(instruction=ambiguity_check, context=self.problem_text)

        if "alternative" in alternatives.lower():
            ensemble_instruction = (
                "Evaluate the following candidate solutions and select the best one. "
                "Ensure the chosen solution aligns with the original passage and question."
            )
            final_answer = await self.ensemble(
                instruction=ensemble_instruction,
                contexts=[refined_result, alternatives]
            )
        else:
            final_answer = refined_result

        # Step 6: Summarize the final result
        summary_instruction = (
            f"Condense the following answer: {final_answer}\n"
            "into a concise and clear format suitable for the DROP benchmark. Ensure the "
            "summary preserves all critical information."
        )
        summarized_answer = await self.summarize(instruction=summary_instruction, context=final_answer)

        return summarized_answer