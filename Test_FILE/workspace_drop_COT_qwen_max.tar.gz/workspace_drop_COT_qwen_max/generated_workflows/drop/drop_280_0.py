# Workflow ID: drop_280_0
# Benchmark: drop
# Data Indices: [409, 740]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information from the passage
        extraction_instruction = (
            "Thoroughly analyze the passage and extract all entities, actions, and numerical values. "
            "List them in a structured format, associating each number with its corresponding entity or action. "
            "Include any relationships or dependencies between entities mentioned in the text."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Understand the question intent
        question_intent_instruction = (
            f"Given the extracted information: {extracted_info}\n"
            "Analyze the question to determine what it is asking for. "
            "Identify if the question requires arithmetic operations (e.g., addition, subtraction), comparison, counting, or span extraction. "
            "Provide a clear breakdown of the reasoning process needed to answer the question."
        )
        question_analysis = await self.generate(instruction=question_intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or calculation
        reasoning_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            f"And the question analysis: {question_analysis}\n"
            "Perform the necessary reasoning or calculations to answer the question. "
            "If the question involves arithmetic, show the step-by-step calculations. "
            "If it involves comparison, clearly state the basis of the comparison. "
            "If it involves span extraction, provide the exact span from the passage."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the answer
        refinement_instruction = (
            f"Review the reasoning result: {reasoning_result}\n"
            "Critique and refine the answer to ensure it is accurate, complete, and directly addresses the question. "
            "Ensure the answer aligns with the passage and question intent. "
            "If any errors or ambiguities are found, correct them."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Final synthesis
        synthesis_instruction = (
            f"Summarize the refined answer: {refined_answer}\n"
            "Condense it into a concise response that directly answers the question. "
            "Ensure the final output is clear, precise, and formatted appropriately."
        )
        final_answer = await self.summarize(instruction=synthesis_instruction, context=refined_answer)

        return final_answer