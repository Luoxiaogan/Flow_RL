# Workflow ID: drop_390_0
# Benchmark: drop
# Data Indices: [428, 40]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information from the passage
        extraction_instruction = (
            "Extract all entities, numerical values, dates, and their relationships from the passage. "
            "Identify key components such as people, teams, scores, events, and their associations. "
            "Ensure you capture ALL potential information that could be relevant to answering the question."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine the reasoning strategy
        question_analysis_instruction = (
            f"Analyze the question and determine the type of reasoning required. "
            f"Based on the extracted information: {extracted_info}, identify whether the question involves "
            f"arithmetic operations, counting, comparison, selection, or span extraction. "
            f"Provide a detailed reasoning strategy and any constraints or conditions mentioned in the question."
        )
        reasoning_strategy = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Execute parallel reasoning paths
        arithmetic_instruction = (
            f"If the question requires arithmetic operations, perform the necessary calculations using the extracted numbers. "
            f"Ensure you associate each number with its corresponding entity or event. "
            f"Reasoning strategy: {reasoning_strategy}"
        )
        counting_instruction = (
            f"If the question requires counting, count the occurrences of specific entities or events mentioned in the question. "
            f"Ensure you do not miss any instance and correctly associate counts with their respective entities. "
            f"Reasoning strategy: {reasoning_strategy}"
        )
        comparison_instruction = (
            f"If the question requires comparison, compare the numerical values or attributes of entities mentioned in the question. "
            f"Ensure you clearly state which entity or event satisfies the comparison condition. "
            f"Reasoning strategy: {reasoning_strategy}"
        )
        selection_instruction = (
            f"If the question requires selection, identify the correct entity or event based on the conditions mentioned in the question. "
            f"Ensure you provide the exact name or description of the selected item. "
            f"Reasoning strategy: {reasoning_strategy}"
        )
        span_extraction_instruction = (
            f"If the question requires span extraction, extract the exact text span from the passage that answers the question. "
            f"Ensure the span is complete and directly addresses the question. "
            f"Reasoning strategy: {reasoning_strategy}"
        )

        reasoning_results = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=counting_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text),
            self.generate(instruction=selection_instruction, context=self.problem_text),
            self.generate(instruction=span_extraction_instruction, context=self.problem_text)
        )

        # Step 4: Ensemble decision to select the best result
        ensemble_instruction = (
            f"Evaluate the following reasoning results and select the most appropriate answer. "
            f"Ensure the selected answer aligns with the question's requirements and reasoning strategy. "
            f"Reasoning results: {reasoning_results}"
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=reasoning_results)

        # Step 5: Refine the final answer
        refinement_instruction = (
            f"Refine the final answer to ensure clarity, correctness, and adherence to the question's requirements. "
            f"Final answer before refinement: {final_answer}"
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        return refined_answer