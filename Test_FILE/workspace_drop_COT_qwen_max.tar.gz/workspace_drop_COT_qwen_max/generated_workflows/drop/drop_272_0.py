# Workflow ID: drop_272_0
# Benchmark: drop
# Data Indices: [228, 125]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Comprehensive Extraction
        extraction_instruction = (
            "Extract all relevant entities, numbers, dates, and relationships from the passage and question. "
            "Categorize the extracted information into groups such as entities, numerical values, temporal references, and actions. "
            "Ensure no critical information is missed."
        )
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Question Analysis
        question_analysis_instruction = (
            "Analyze the question to determine its intent. Classify the question into one of the following categories: "
            "arithmetic operation, comparison, selection, span extraction, or implicit inference. "
            "Provide a detailed reasoning plan for answering the question based on the extracted information."
        )
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Reasoning Execution
        reasoning_instruction = (
            f"Based on the extracted information: {extraction} and the question analysis: {question_analysis}, "
            "execute the appropriate reasoning steps. "
            "For arithmetic operations, perform calculations using the relevant numbers. "
            "For comparisons, compare the relevant numerical or temporal values. "
            "For selections, identify the correct entity or span based on context. "
            "For span extraction, directly extract the relevant text span. "
            "Provide the intermediate results for validation."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validation and Refinement
        validation_instruction = (
            "Validate the intermediate results by cross-checking them against the passage and question. "
            "Identify any inconsistencies or ambiguities. Provide a refined version of the results if needed."
        )
        refined_result = await self.revise(instruction=validation_instruction, context=reasoning_result)

        # Step 5: Final Answer Synthesis
        synthesis_instruction = (
            "Combine the validated results into a coherent final answer. "
            "Condense the reasoning process into a concise response that directly answers the question."
        )
        final_answer = await self.summarize(instruction=synthesis_instruction, context=refined_result)

        return final_answer