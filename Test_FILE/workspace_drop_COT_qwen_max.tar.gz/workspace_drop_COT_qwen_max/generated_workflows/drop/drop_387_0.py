# Workflow ID: drop_387_0
# Benchmark: drop
# Data Indices: [611, 468]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information
        extraction = await self.generate(
            instruction="Extract all numerical values, entities, and relationships mentioned in the passage. "
                        "Focus on information that could be relevant to answering the question. "
                        "Ensure no relevant detail is missed.",
            context=self.problem_text
        )

        # Step 2: Analyze and associate entities
        association = await self.generate(
            instruction=f"Given the extracted information:\n{extraction}\n"
                        "Associate each numerical value with its corresponding entity or context. "
                        "Identify any ambiguous references and resolve them using the passage context.",
            context=self.problem_text
        )

        # Step 3: Perform reasoning
        reasoning = await self.generate(
            instruction=f"Based on the associated data:\n{association}\n"
                        "Determine the type of reasoning required (e.g., arithmetic, counting, comparison). "
                        "Perform the necessary calculations or evaluations step-by-step. "
                        "Ensure the reasoning aligns with the question's intent.",
            context=self.problem_text
        )

        # Step 4: Validate and refine
        refinement = await self.revise(
            instruction="Critique the reasoning process and output. "
                        "Identify any errors, ambiguities, or missing steps. "
                        "Refine the output to ensure accuracy and completeness.",
            context=reasoning
        )

        # Step 5: Synthesize the final answer
        results = await asyncio.gather(
            self.generate(
                instruction=f"Provide the final answer based on the refined reasoning:\n{refinement}\n"
                            "Ensure the answer is concise and directly addresses the question.",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"Double-check the reasoning and provide an alternative interpretation if needed:\n{refinement}",
                context=self.problem_text
            )
        )

        final_answer = await self.ensemble(
            instruction="Evaluate the provided answers and select the most accurate one. "
                        "If both answers are valid, synthesize them into a single response.",
            contexts=results
        )

        return final_answer