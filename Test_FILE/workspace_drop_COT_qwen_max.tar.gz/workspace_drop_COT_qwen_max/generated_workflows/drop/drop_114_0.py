# Workflow ID: drop_114_0
# Benchmark: drop
# Data Indices: [666, 71]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the passage and question
        extract_instruction = """
        Extract all entities, numerical values, dates, and events mentioned in the passage and question. 
        Organize them into categories: entities (people, teams, locations), numbers (with associated context), 
        dates (with associated events), and actions/events (with participants and outcomes).
        """
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Understand the question intent
        intent_instruction = f"""
        Analyze the question to determine its type and intent. Possible types include:
        - Arithmetic operations (e.g., addition, subtraction, counting)
        - Comparisons (e.g., greater than, earlier than)
        - Span extraction (e.g., identifying specific entities or phrases)
        - Temporal ordering (e.g., determining which event happened first/last)
        Use the following extracted information to guide your analysis: {extracted_info}.
        Clearly state the type of reasoning required to answer the question.
        """
        question_intent = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or calculation based on intent
        reasoning_instruction = f"""
        Based on the identified question intent ({question_intent}), perform the necessary reasoning or calculation:
        - For arithmetic operations, extract and associate numbers with their entities, then compute the result.
        - For comparisons, identify the entities or events being compared and evaluate their attributes.
        - For span extraction, locate the exact text span that answers the question.
        - For temporal ordering, determine the sequence of events based on the context.
        Use the extracted information: {extracted_info} to derive the answer.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the result
        refine_instruction = f"""
        Critique and refine the following reasoning result: {reasoning_result}.
        Ensure the answer is accurate, complete, and directly addresses the question. 
        If necessary, correct any errors or ambiguities in the reasoning process.
        """
        refined_result = await self.revise(instruction=refine_instruction, context=reasoning_result)

        # Step 5: Finalize the output
        finalize_instruction = f"""
        Summarize the refined result: {refined_result} into a concise, final answer. 
        Ensure the output is clear, unambiguous, and directly responds to the question.
        """
        final_answer = await self.summarize(instruction=finalize_instruction, context=refined_result)

        return final_answer