# Workflow ID: drop_392_0
# Benchmark: drop
# Data Indices: [64, 46]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all relevant numerical values, entities, and spans
        extract_instruction = """
        Extract all numerical values, entities, and relevant text spans from the passage.
        Include any information that could be relevant to answering the question.
        Organize the extracted data into categories such as numbers, entities, and spans.
        """
        extracted_data = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Analyze the question intent
        analyze_instruction = f"""
        Analyze the question to determine the type of reasoning required.
        Identify whether the question involves arithmetic operations, counting, comparison, selection, or span extraction.
        Based on the extracted data: {extracted_data}, determine the specific entities or values involved in the reasoning process.
        """
        question_intent = await self.generate(instruction=analyze_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or calculation
        reasoning_instruction = f"""
        Based on the question intent: {question_intent}, perform the necessary reasoning or calculation.
        If the question involves arithmetic operations, compute the result using the relevant numbers.
        If the question involves counting, count the occurrences of the specified entities or events.
        If the question involves comparison, compare the relevant values or spans to determine the correct answer.
        If the question involves span extraction, identify the exact text span that answers the question.
        Ensure the reasoning process is clear and well-documented.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine and validate the answer
        refine_instruction = f"""
        Critique and refine the following reasoning result: {reasoning_result}.
        Ensure the answer aligns with the question's requirements and the passage's context.
        Correct any errors or ambiguities in the reasoning process.
        """
        refined_answer = await self.revise(instruction=refine_instruction, context=reasoning_result)

        # Step 5: Summarize the final answer
        summarize_instruction = f"""
        Summarize the reasoning process and present the final answer in a concise format.
        Ensure the answer directly addresses the question and is supported by the passage.
        """
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_answer)

        return final_answer