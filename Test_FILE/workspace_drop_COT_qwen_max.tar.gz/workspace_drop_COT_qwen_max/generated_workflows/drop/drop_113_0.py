# Workflow ID: drop_113_0
# Benchmark: drop
# Data Indices: [162, 345]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all relevant entities, numbers, and relationships
        extraction_instruction = (
            "Extract all numerical values, named entities, and their relationships from the passage. "
            "Include details such as who performed actions, what quantities are mentioned, and how they relate to each other. "
            "Format the output as a structured list of key-value pairs or sentences."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question and map it to the extracted entities
        question_analysis_instruction = (
            f"Given the extracted information: {extracted_info}, analyze the question and determine its intent. "
            "Identify whether the question requires arithmetic operations, comparison, counting, or span extraction. "
            "Provide a clear explanation of the reasoning process."
        )
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Generate multiple reasoning paths in parallel
        arithmetic_instruction = (
            f"Based on the extracted information: {extracted_info} and question analysis: {question_analysis}, "
            "perform any required arithmetic operations (addition, subtraction, etc.) to compute the answer. "
            "Explain the steps clearly."
        )
        comparison_instruction = (
            f"Based on the extracted information: {extracted_info} and question analysis: {question_analysis}, "
            "compare the relevant entities and determine which one satisfies the question's condition. "
            "Explain the reasoning process."
        )
        span_extraction_instruction = (
            f"Based on the extracted information: {extracted_info} and question analysis: {question_analysis}, "
            "identify the exact text span from the passage that answers the question. "
            "Ensure the span is precise and directly addresses the question."
        )

        reasoning_paths = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text),
            self.generate(instruction=span_extraction_instruction, context=self.problem_text)
        )

        # Step 4: Ensemble decision-making to select the best answer
        ensemble_instruction = (
            "Evaluate the following candidate solutions and select the most accurate and relevant one. "
            "If there are conflicts or ambiguities, resolve them by prioritizing the solution that aligns best with the question's intent. "
            "Provide a justification for your choice."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=reasoning_paths)

        # Step 5: Refine the final answer for clarity and correctness
        refinement_instruction = (
            f"Refine the following answer: {final_answer} to ensure clarity, correctness, and completeness. "
            "Correct any errors, improve phrasing, and ensure it directly addresses the question."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        return refined_answer