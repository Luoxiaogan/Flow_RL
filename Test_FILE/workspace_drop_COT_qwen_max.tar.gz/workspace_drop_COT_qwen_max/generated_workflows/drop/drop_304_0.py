# Workflow ID: drop_304_0
# Benchmark: drop
# Data Indices: [517, 613]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all relevant entities, numerical values, and relationships
        extraction_instruction = (
            "Carefully analyze the passage and extract ALL relevant entities, numerical values, "
            "and their relationships. Include any mentions of people, teams, events, dates, or numbers, "
            "and describe how they relate to each other. Ensure nothing is missed."
        )
        entities_and_values = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Understand the question intent
        question_intent_instruction = (
            "Analyze the question and determine its intent. Identify whether the question requires "
            "an arithmetic operation (e.g., sum, difference), a comparison (e.g., greater than, less than), "
            "a count (e.g., how many times), or a span extraction (e.g., who, what). Provide a clear "
            "description of the reasoning required to answer the question."
        )
        question_intent = await self.generate(instruction=question_intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question intent
        reasoning_instruction = (
            f"Given the extracted information: {entities_and_values}, and the question intent: {question_intent}, "
            "perform the necessary reasoning to answer the question. If the question involves arithmetic, "
            "calculate the result step by step. If it involves comparison, evaluate all relevant candidates. "
            "If it requires span extraction, identify the exact text span that answers the question."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine the output for precision and formatting
        refinement_instruction = (
            "Review the reasoning result and refine it to ensure it is precise, well-formatted, "
            "and directly answers the question. Remove any unnecessary details and ensure clarity."
        )
        final_answer = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        return final_answer