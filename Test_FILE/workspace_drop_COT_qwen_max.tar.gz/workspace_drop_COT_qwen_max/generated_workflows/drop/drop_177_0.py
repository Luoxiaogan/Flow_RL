# Workflow ID: drop_177_0
# Benchmark: drop
# Data Indices: [580, 633]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Identify the question type and key components
        question_analysis = await self.generate(
            instruction="Analyze the question to determine its type (e.g., arithmetic, counting, comparison, selection, span extraction). "
                        "Identify the entities, numerical values, and relationships mentioned in the question.",
            context=self.problem_text
        )

        # Step 2: Extract relevant entities and numerical values from the passage
        entity_extraction = await self.generate(
            instruction=f"Based on the question analysis: {question_analysis}, "
                        "extract all relevant entities, numerical values, and their relationships from the passage. "
                        "Ensure no relevant information is missed.",
            context=self.problem_text
        )

        # Step 3: Perform reasoning or calculation based on the extracted information
        reasoning_tasks = []
        reasoning_instruction = f"Using the extracted information: {entity_extraction}, " \
                                "perform the necessary reasoning or calculations to answer the question. " \
                                "For arithmetic questions, calculate the result. " \
                                "For comparison questions, compare the relevant entities or values. " \
                                "For span extraction, identify the exact text span that answers the question."
        reasoning_tasks.append(self.generate(instruction=reasoning_instruction, context=self.problem_text))

        # Execute reasoning tasks in parallel if there are multiple approaches
        reasoning_results = await asyncio.gather(*reasoning_tasks)

        # Step 4: Validate and refine the generated answers
        refinement_tasks = []
        for result in reasoning_results:
            refinement_tasks.append(
                self.revise(
                    instruction="Critically evaluate the generated answer. "
                                "Ensure it is accurate, contextually appropriate, and fully addresses the question. "
                                "Refine the answer if necessary.",
                    context=result
                )
            )
        refined_answers = await asyncio.gather(*refinement_tasks)

        # Step 5: Synthesize the final answer
        final_answer = await self.summarize(
            instruction="Condense the refined answers into a concise and clear final response. "
                        "Ensure the response directly answers the question and includes only the necessary information.",
            context="\n".join(refined_answers)
        )

        return final_answer