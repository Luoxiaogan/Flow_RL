# Workflow ID: drop_190_0
# Benchmark: drop
# Data Indices: [413, 211]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all numerical values and associated entities
        extraction_instruction = (
            "Thoroughly analyze the provided passage and extract ALL numerical values along with their associated entities, "
            "units, and any contextual information that might be relevant to answering a question. Ensure no information is missed. "
            "Format the output as a list of key-value pairs, where the key is the entity or context, and the value is the numerical data."
        )
        extracted_data = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_analysis_instruction = (
            "Carefully analyze the question and determine its intent. Specifically, identify whether the question requires: "
            "1. Arithmetic operations (e.g., addition, subtraction, multiplication, division), "
            "2. Counting specific occurrences, "
            "3. Comparison between entities, "
            "4. Selection of specific information, or "
            "5. Span extraction. Provide a detailed explanation of the reasoning behind your determination."
        )
        question_intent = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or calculation based on the question intent
        reasoning_instruction = (
            f"Based on the extracted data: {extracted_data} and the question intent: {question_intent}, "
            "perform the necessary reasoning or calculations to arrive at the answer. If the question involves arithmetic, "
            "clearly show the steps of the calculation. If it involves comparison or selection, provide a justification for "
            "the chosen answer. Ensure the output is precise and directly addresses the question."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine the computed answer
        refinement_instruction = (
            "Critically review the computed answer and ensure it is accurate, complete, and directly addresses the question. "
            "If there are any ambiguities or potential errors, revise the answer accordingly. Provide a clear explanation "
            "of any changes made during this refinement process."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Summarize the final response
        summarization_instruction = (
            "Condense the reasoning and final answer into a concise, clear response. Ensure the summary includes the final "
            "answer and briefly mentions the key steps or reasoning used to arrive at it."
        )
        final_response = await self.summarize(instruction=summarization_instruction, context=refined_answer)

        return final_response