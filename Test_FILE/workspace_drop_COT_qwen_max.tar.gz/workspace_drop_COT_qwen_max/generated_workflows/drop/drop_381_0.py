# Workflow ID: drop_381_0
# Benchmark: drop
# Data Indices: [18, 209]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all relevant numerical values, entities, and relationships
        extraction_instruction = (
            "Thoroughly analyze the passage and extract all numerical values, entities, "
            "and their relationships. Include details such as measurements, counts, dates, "
            "and any other quantitative or qualitative information. Ensure no relevant "
            "information is missed."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine the required reasoning type
        question_analysis_instruction = (
            f"Given the extracted information: {extracted_info}\n"
            "Analyze the question to determine the type of reasoning required. "
            "Identify whether the task involves arithmetic operations (e.g., sum, difference), "
            "comparison (e.g., greater than, less than), counting occurrences, or extracting "
            "a specific span of text. Provide a clear breakdown of the question's intent."
        )
        question_intent = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform the reasoning or calculation based on the question intent
        reasoning_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            f"and the question intent: {question_intent}\n"
            "Perform the necessary reasoning or calculation to answer the question. "
            "If the task involves arithmetic, show the calculation steps. If it involves "
            "comparison, explicitly compare the relevant values. If it involves counting, "
            "enumerate all relevant occurrences. If it involves span extraction, identify "
            "the exact text span that answers the question."
        )
        candidate_answer = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the candidate answer
        refinement_instruction = (
            f"Review the candidate answer: {candidate_answer}\n"
            "Cross-reference it with the passage to ensure accuracy. Refine the answer if "
            "necessary, correcting any errors or ambiguities. Ensure the final answer is "
            "consistent with the passage and the question intent."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=candidate_answer)

        # Step 5: Finalize the output
        final_instruction = (
            f"Format the refined answer: {refined_answer}\n"
            "Ensure it is presented in the appropriate format based on the question type "
            "(e.g., a number, a date, or a text span). Return the final answer."
        )
        final_answer = await self.generate(instruction=final_instruction, context=refined_answer)

        return final_answer