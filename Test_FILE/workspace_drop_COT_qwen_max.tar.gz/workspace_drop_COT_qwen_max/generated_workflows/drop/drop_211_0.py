# Workflow ID: drop_211_0
# Benchmark: drop
# Data Indices: [142, 704]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Stage 1: Information Extraction
        extract_instruction = (
            "Thoroughly analyze the provided passage and question. "
            "Extract all relevant entities, numerical values, dates, and textual spans. "
            "Identify relationships between entities and any implicit information that could help answer the question. "
            "Organize the extracted information clearly for subsequent reasoning steps."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Stage 2: Parallel Analysis Paths
        # Path 1: Numerical Reasoning (Arithmetic Operations)
        arithmetic_instruction = (
            f"Using the extracted information: {extracted_info}, determine if the question requires arithmetic reasoning. "
            "If so, perform the necessary calculations (addition, subtraction, multiplication, division) step by step. "
            "Clearly state the result of the computation."
        )
        arithmetic_result = self.generate(instruction=arithmetic_instruction, context=self.problem_text)

        # Path 2: Span Extraction and Entity Tracking
        span_extraction_instruction = (
            f"Using the extracted information: {extracted_info}, determine if the question requires identifying a specific span or entity. "
            "Track pronouns and partial names to resolve references. "
            "Provide the exact span or entity name as the answer."
        )
        span_result = self.generate(instruction=span_extraction_instruction, context=self.problem_text)

        # Path 3: Comparison and Ranking
        comparison_instruction = (
            f"Using the extracted information: {extracted_info}, determine if the question involves comparing entities or events. "
            "Compare based on explicit or implicit criteria (e.g., size, time, quantity). "
            "State which entity or event satisfies the comparison condition."
        )
        comparison_result = self.generate(instruction=comparison_instruction, context=self.problem_text)

        # Execute all paths in parallel
        results = await asyncio.gather(arithmetic_result, span_result, comparison_result)

        # Stage 3: Synthesis (Ensemble Decision)
        ensemble_instruction = (
            "Evaluate the following candidate solutions and select the most appropriate one. "
            "Ensure the chosen solution directly answers the question and aligns with the extracted information. "
            "If multiple solutions are valid, synthesize them into a single coherent answer."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Stage 4: Final Refinement
        refine_instruction = (
            "Review the provided answer and ensure it is clear, concise, and correctly formatted. "
            "Correct any errors or ambiguities. Ensure the final output matches the expected answer type (number, date, span, etc.)."
        )
        refined_answer = await self.revise(instruction=refine_instruction, context=final_answer)

        return refined_answer