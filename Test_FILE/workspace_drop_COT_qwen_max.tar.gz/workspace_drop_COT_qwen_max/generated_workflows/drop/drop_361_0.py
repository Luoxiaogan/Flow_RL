# Workflow ID: drop_361_0
# Benchmark: drop
# Data Indices: [224, 732]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the passage and question
        extract_instruction = (
            "Thoroughly analyze the passage and question. "
            "Extract all entities, numbers, dates, and their relationships. "
            "Also determine the intent of the question (e.g., arithmetic, comparison, span extraction)."
        )
        question_intent_instruction = (
            "Identify the intent of the question. "
            "Determine if it requires arithmetic operations, counting, comparison, selection, or span extraction."
        )

        extract_task = self.generate(instruction=extract_instruction, context=self.problem_text)
        intent_task = self.generate(instruction=question_intent_instruction, context=self.problem_text)
        extracted_info, question_intent = await asyncio.gather(extract_task, intent_task)

        # Step 2: Refine and organize extracted data
        refine_instruction = (
            f"Organize the following extracted information into structured components: {extracted_info}. "
            "Ensure entity-number mappings are accurate and group related information logically."
        )
        refined_data = await self.revise(instruction=refine_instruction, context=extracted_info)

        # Step 3: Perform reasoning based on question intent
        reasoning_instruction = (
            f"Using the refined data: {refined_data}, and the identified question intent: {question_intent}, "
            "perform the necessary reasoning. This may include arithmetic operations, comparisons, or span extraction. "
            "Provide a clear step-by-step explanation of the reasoning process."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Synthesize results using Ensemble
        synthesis_instruction = (
            "Evaluate the reasoning result and ensure it aligns with the question intent. "
            "If there are multiple possible answers or interpretations, select the most appropriate one. "
            "Provide a concise final answer."
        )
        final_answer = await self.ensemble(
            instruction=synthesis_instruction,
            contexts=[refined_data, reasoning_result]
        )

        return final_answer