# Workflow ID: drop_285_0
# Benchmark: drop
# Data Indices: [734, 736]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract all entities, numbers, dates, and relevant spans
        extraction_instruction = """
        Extract all entities, numerical values, dates, and relevant text spans from the passage.
        Organize them into categories: entities, numbers, dates, and spans.
        Ensure no information is missed and provide a comprehensive list.
        """
        extracted_data = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Understand the question and classify its type
        question_instruction = f"""
        Analyze the question to determine its type and intent. Classify it into one of the following categories:
        - Arithmetic Operations (addition, subtraction, multiplication, division)
        - Counting (how many times, how many different)
        - Comparison (greater than, less than, equal to)
        - Selection (which team, who did)
        - Span Extraction (exact phrase or entity name)
        Also, extract any constraints or specific requirements from the question.
        Given extracted data: {extracted_data}
        """
        question_analysis = await self.generate(instruction=question_instruction, context=self.problem_text)

        # Step 3: Parallel reasoning paths based on question type
        arithmetic_instruction = f"""
        Perform any required arithmetic operations using the extracted numbers.
        Ensure calculations are accurate and relevant to the question.
        Given extracted data: {extracted_data}
        Question analysis: {question_analysis}
        """
        counting_instruction = f"""
        Count the occurrences of specific entities or events as required by the question.
        Ensure counts are accurate and relevant to the question.
        Given extracted data: {extracted_data}
        Question analysis: {question_analysis}
        """
        comparison_instruction = f"""
        Compare values as required by the question and determine the appropriate answer.
        Ensure comparisons are accurate and relevant to the question.
        Given extracted data: {extracted_data}
        Question analysis: {question_analysis}
        """
        selection_instruction = f"""
        Identify the correct entity or event as required by the question.
        Ensure selection is accurate and relevant to the question.
        Given extracted data: {extracted_data}
        Question analysis: {question_analysis}
        """
        span_extraction_instruction = f"""
        Extract the exact span from the passage as required by the question.
        Ensure the span is accurate and relevant to the question.
        Given extracted data: {extracted_data}
        Question analysis: {question_analysis}
        """

        arithmetic_result, counting_result, comparison_result, selection_result, span_extraction_result = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=counting_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text),
            self.generate(instruction=selection_instruction, context=self.problem_text),
            self.generate(instruction=span_extraction_instruction, context=self.problem_text)
        )

        # Step 4: Refine results from each reasoning path
        refined_arithmetic = await self.revise(instruction="Refine the arithmetic result for accuracy.", context=arithmetic_result)
        refined_counting = await self.revise(instruction="Refine the counting result for accuracy.", context=counting_result)
        refined_comparison = await self.revise(instruction="Refine the comparison result for accuracy.", context=comparison_result)
        refined_selection = await self.revise(instruction="Refine the selection result for accuracy.", context=selection_result)
        refined_span_extraction = await self.revise(instruction="Refine the span extraction result for accuracy.", context=span_extraction_result)

        # Step 5: Final answer selection using Ensemble
        ensemble_instruction = f"""
        Evaluate the refined results from each reasoning path and select the final answer.
        Ensure the selected answer is the most accurate and relevant to the question.
        Refined arithmetic result: {refined_arithmetic}
        Refined counting result: {refined_counting}
        Refined comparison result: {refined_comparison}
        Refined selection result: {refined_selection}
        Refined span extraction result: {refined_span_extraction}
        """
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[
            refined_arithmetic,
            refined_counting,
            refined_comparison,
            refined_selection,
            refined_span_extraction
        ])

        return final_answer