# Workflow ID: drop_284_0
# Benchmark: drop
# Data Indices: [777, 13]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the passage
        extraction_instruction = (
            "Extract all relevant facts, entities, numbers, dates, and relationships from the passage. "
            "Focus on information that could be useful for answering questions about the passage. "
            "Include explicit mentions of comparisons, counts, totals, and any numerical reasoning elements."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to understand its intent
        question_intent_instruction = (
            f"Given the extracted information: {extracted_info}\n"
            "Analyze the question and determine its intent. Identify whether the question requires "
            "arithmetic operations (e.g., addition, subtraction), counting, comparison, span extraction, "
            "or another type of reasoning. Provide a clear directive on how to proceed with solving the question."
        )
        question_analysis = await self.generate(instruction=question_intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question's intent
        reasoning_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            f"And the analysis of the question: {question_analysis}\n"
            "Perform the necessary reasoning steps to answer the question. If the question involves arithmetic, "
            "calculate the result using the relevant numbers. If it involves comparison, compare the relevant "
            "entities or values. If it involves span extraction, identify the exact text span from the passage."
        )
        reasoning_output = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the reasoning output
        refinement_instruction = (
            f"Review the reasoning output: {reasoning_output}\n"
            "Critique and refine it to ensure accuracy and alignment with the question's intent. "
            "Check for errors in calculations, misinterpretations of the passage, or incomplete answers. "
            "Provide a revised version of the reasoning output."
        )
        refined_output = await self.revise(instruction=refinement_instruction, context=reasoning_output)

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"Condense the refined reasoning output: {refined_output}\n"
            "Summarize it into a concise final answer that directly addresses the question. "
            "Ensure the answer is clear, accurate, and formatted appropriately."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_output)

        return final_answer