# Workflow ID: drop_399_0
# Benchmark: drop
# Data Indices: [453, 289]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all relevant information from the passage
        extraction_instruction = (
            "Thoroughly analyze the provided passage and extract all entities, numbers, and their relationships. "
            "Include any implicit information that can be inferred from the context. "
            "Organize the extracted information in a structured format for easy reference."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question intent
        question_intent_instruction = (
            f"Given the extracted information: {extracted_info}\n"
            "Carefully analyze the question and determine its intent. "
            "Identify whether the question requires arithmetic operations, counting, comparison, selection, or span extraction. "
            "Provide a clear explanation of the reasoning process required to answer the question."
        )
        question_intent = await self.generate(instruction=question_intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question intent
        reasoning_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            f"And the identified question intent: {question_intent}\n"
            "Solve the problem step by step. Perform any necessary calculations, count occurrences, compare values, "
            "or extract relevant spans from the passage. Ensure the reasoning process is thorough and accurate."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Explore alternative reasoning paths (if applicable)
        alternative_reasoning_instruction = (
            f"Consider alternative interpretations of the question based on the extracted information: {extracted_info}\n"
            "Explore different reasoning paths and provide alternative solutions. "
            "Ensure each path is logically consistent with the passage and question intent."
        )
        alternative_reasoning = await self.generate(instruction=alternative_reasoning_instruction, context=self.problem_text)

        # Step 5: Synthesize the final answer using Ensemble
        ensemble_instruction = (
            "Evaluate the provided reasoning results and select the most accurate and relevant answer. "
            "Ensure the final answer directly addresses the question and aligns with the passage context."
        )
        final_answer = await self.ensemble(
            instruction=ensemble_instruction,
            contexts=[reasoning_result, alternative_reasoning]
        )

        # Step 6: Revise the final answer for accuracy
        revision_instruction = (
            "Critique the final answer for accuracy, clarity, and alignment with the question intent. "
            "Make any necessary refinements to ensure the answer is precise and well-supported by the passage."
        )
        revised_answer = await self.revise(instruction=revision_instruction, context=final_answer)

        return revised_answer