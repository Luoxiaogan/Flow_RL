# Workflow ID: drop_164_0
# Benchmark: drop
# Data Indices: [80, 156]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information from the passage
        extract_instruction = (
            "Extract all numerical values, entities, and relationships from the passage. "
            "Include any implicit information that might be relevant to answering questions. "
            "Format the output as a list of key-value pairs, where the key describes the entity or relationship, "
            "and the value is the associated number or description."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine the reasoning type
        analyze_instruction = (
            "Analyze the question and determine the type of reasoning required. "
            "Possible types include arithmetic operations (addition, subtraction), counting, comparison, "
            "and span extraction. Provide a detailed explanation of the reasoning type and any specific "
            "entities or numbers involved."
        )
        question_analysis = await self.generate(instruction=analyze_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or calculation based on the question type
        reasoning_instruction = (
            f"Based on the extracted information: {extracted_info} and the question analysis: {question_analysis}, "
            "perform the necessary reasoning or calculations to answer the question. "
            "For arithmetic operations, show the calculation steps. For counting, list the occurrences. "
            "For comparisons, clearly state which entity or value satisfies the condition. "
            "For span extraction, provide the exact text span from the passage."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine the result to ensure accuracy and clarity
        refine_instruction = (
            "Critique and refine the reasoning result. Ensure all calculations are accurate, "
            "all entities are correctly associated with their numbers, and the answer is clear and concise. "
            "If there are any ambiguities or potential errors, address them explicitly."
        )
        refined_result = await self.revise(instruction=refine_instruction, context=reasoning_result)

        # Step 5: Summarize the reasoning process and present the final answer
        summarize_instruction = (
            "Condense the reasoning process into a concise summary. Include the final answer "
            "in a clear and unambiguous format. If the answer involves a number, ensure it is boxed. "
            "If the answer is a text span, ensure it is quoted."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_result)

        return final_answer