# Workflow ID: drop_264_0
# Benchmark: drop
# Data Indices: [676, 392]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all relevant entities, numbers, and spans
        extraction_instruction = (
            "Carefully read the passage and question. "
            "Extract all named entities, numerical values, dates, and relevant text spans. "
            "Ensure each number is associated with its corresponding entity or context. "
            "If there are multiple similar entities, clearly distinguish them. "
            "Provide the output in a structured format."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Perform reasoning over the extracted information
        reasoning_instruction = (
            f"Using the extracted information: {extracted_info}, analyze the question. "
            "Determine what type of reasoning is required (e.g., arithmetic, counting, comparison). "
            "Perform the necessary calculations or logical deductions step by step. "
            "Clearly explain your reasoning process and provide the final answer."
        )
        reasoning_output = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Refine the reasoning output
        refinement_instruction = (
            "Review the reasoning output critically. "
            "Check for accuracy in calculations, entity-number associations, and implicit inferences. "
            "Correct any errors or ambiguities. "
            "Ensure the final answer is precise and directly addresses the question."
        )
        refined_output = await self.revise(instruction=refinement_instruction, context=reasoning_output)

        # Step 4: Synthesize final answer if needed
        # If ambiguity remains, use ensemble to decide between multiple options
        final_answer = refined_output
        if "?" in refined_output:  # Placeholder for detecting ambiguity
            ensemble_instruction = (
                "Evaluate the provided reasoning outputs. "
                "Select the most accurate and complete answer, or synthesize a new one if needed."
            )
            final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[reasoning_output, refined_output])

        return final_answer