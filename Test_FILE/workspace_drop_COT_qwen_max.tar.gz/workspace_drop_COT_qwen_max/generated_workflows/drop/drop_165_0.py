# Workflow ID: drop_165_0
# Benchmark: drop
# Data Indices: [671, 712]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant entities, numbers, and relationships
        extraction_instruction = (
            "Extract all entities, numerical values, dates, and relationships from the passage and question. "
            "Ensure that each entity is associated with its corresponding values or events. "
            "Organize the extracted information clearly for further reasoning."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its type
        question_analysis_instruction = (
            f"Given the extracted information: {extracted_info}\n"
            "Analyze the question to determine its type. "
            "Classify the question as one of the following: arithmetic operation, counting, comparison, selection, or span extraction. "
            "Provide a clear reasoning strategy for solving the question based on its type."
        )
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Execute parallel reasoning paths
        arithmetic_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Perform any required arithmetic operations (addition, subtraction, etc.) using the numerical values. "
            "Clearly show the calculations and provide the result."
        )
        counting_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Count the occurrences of specific entities or events mentioned in the question. "
            "Provide the count along with a brief explanation."
        )
        comparison_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Compare the specified entities or values as requested in the question. "
            "Provide the comparison result with supporting evidence."
        )
        selection_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Select the specific span or entity that answers the question. "
            "Ensure the selection is accurate and directly addresses the question."
        )

        reasoning_tasks = [
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=counting_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text),
            self.generate(instruction=selection_instruction, context=self.problem_text),
        ]
        reasoning_results = await asyncio.gather(*reasoning_tasks)

        # Step 4: Synthesize results using Ensemble
        synthesis_instruction = (
            "Evaluate the results from the following reasoning paths: arithmetic, counting, comparison, and selection. "
            "Determine which result best answers the question based on its type and requirements. "
            "Provide the final answer with a clear justification."
        )
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=reasoning_results)

        # Step 5 (Optional): Refine the final answer
        refinement_instruction = (
            "Review the final answer for clarity and correctness. "
            "Make any necessary refinements to ensure the answer is precise and well-formulated."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        return refined_answer