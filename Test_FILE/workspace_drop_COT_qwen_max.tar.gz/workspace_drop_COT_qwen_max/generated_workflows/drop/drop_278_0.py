# Workflow ID: drop_278_0
# Benchmark: drop
# Data Indices: [451, 748]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all relevant information from the passage
        extraction_instruction = (
            "Extract all entities, numerical values, dates, and relationships from the passage. "
            "Focus on information that could be relevant to answering questions about counts, "
            "arithmetic operations, comparisons, or span extraction."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_analysis_instruction = (
            "Analyze the question to determine what type of reasoning is required. "
            "Identify if the question involves arithmetic operations (e.g., addition, subtraction), "
            "counting, comparison, span extraction, or other types of reasoning. "
            "Provide a detailed breakdown of the question's intent."
        )
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Execute reasoning based on the question analysis
        reasoning_instruction = (
            f"Using the extracted information: {extracted_info}, and the question analysis: {question_analysis}, "
            "solve the problem step by step. Perform any necessary calculations, comparisons, or span extractions. "
            "Ensure the reasoning process is clear and well-supported by the passage."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the result
        refinement_instruction = (
            "Critique the reasoning result and refine it for accuracy. Ensure the answer aligns with the "
            "question's intent and is fully supported by the passage. Correct any errors or ambiguities."
        )
        refined_result = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Optional Step 5: Summarize the reasoning process
        summary_instruction = (
            "Summarize the reasoning process and the final answer in a concise format. "
            "Include key steps and justifications."
        )
        summary = await self.summarize(instruction=summary_instruction, context=refined_result)

        # Return the final refined result
        return refined_result