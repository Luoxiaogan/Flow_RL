# Workflow ID: drop_18_0
# Benchmark: drop
# Data Indices: [58, 691]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Analyze the question to determine its intent
        question_analysis_instruction = """
        Analyze the question to determine its intent. Identify whether the question requires arithmetic operations (addition, subtraction, etc.), counting, comparison, selection, or span extraction. 
        Extract any numerical values, entities, or keywords mentioned in the question that will guide subsequent steps.
        """
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 2: Extract relevant information from the passage
        passage_parsing_instruction = f"""
        Based on the following analysis of the question: {question_analysis}
        Extract all relevant information from the passage that matches the identified entities, numerical values, or keywords. Ensure no relevant occurrence is missed.
        """
        passage_data = await self.generate(instruction=passage_parsing_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question intent
        reasoning_instruction = f"""
        Using the extracted information: {passage_data}
        Perform the required reasoning based on the intent identified in the question analysis: {question_analysis}.
        - For arithmetic operations, compute the result using the relevant numbers.
        - For counting, tally occurrences of the specified entities or events.
        - For comparison, evaluate multiple entities or values and determine which satisfies the condition.
        - For selection, identify the entity or event that matches the criteria.
        - For span extraction, directly extract the relevant text span from the passage.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine the result
        refinement_instruction = f"""
        Critique and refine the following reasoning result: {reasoning_result}
        Ensure the answer is accurate, complete, and aligns with the question's requirements. Correct any errors or ambiguities.
        """
        refined_result = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Summarize the final output
        summarization_instruction = f"""
        Condense the following refined result into a concise and clear final answer: {refined_result}
        Ensure the output is suitable for the DROP benchmark and directly answers the question.
        """
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_result)

        return final_answer