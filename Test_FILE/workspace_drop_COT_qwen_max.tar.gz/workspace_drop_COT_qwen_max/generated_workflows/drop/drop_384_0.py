# Workflow ID: drop_384_0
# Benchmark: drop
# Data Indices: [241, 120]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract relevant information from the passage
        extraction_instruction = (
            "Extract all numerical values, entities, and their relationships from the passage. "
            "Include details such as names, dates, events, and any associated numbers. "
            "Format the output as a structured list for easy reference."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_analysis_instruction = (
            "Analyze the question to determine its intent. "
            "Identify whether the question requires arithmetic operations, comparison, counting, selection, or span extraction. "
            "Provide a clear explanation of the reasoning process required to answer the question."
        )
        question_intent = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question intent
        reasoning_instruction = (
            f"Based on the following extracted information: {extracted_info} "
            f"and the identified question intent: {question_intent}, "
            "perform the necessary reasoning to answer the question. "
            "If the question involves arithmetic, calculate the result. "
            "If it involves comparison, compare the relevant entities or values. "
            "If it requires span extraction, identify the exact text span that answers the question. "
            "Provide a detailed explanation of the reasoning process."
        )
        reasoning_output = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the reasoning output
        refinement_instruction = (
            "Critique and refine the following reasoning output to ensure accuracy and clarity. "
            "Verify that the reasoning is well-supported by the passage and addresses the question intent. "
            "Make any necessary corrections or improvements."
        )
        refined_output = await self.revise(instruction=refinement_instruction, context=reasoning_output)

        # Step 5: Summarize the reasoning into a concise answer
        summarization_instruction = (
            "Condense the following reasoning into a concise, final answer. "
            "Ensure the answer is clear, relevant, and directly addresses the question."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_output)

        return final_answer