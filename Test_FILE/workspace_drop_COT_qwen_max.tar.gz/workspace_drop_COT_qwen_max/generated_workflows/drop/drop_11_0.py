# Workflow ID: drop_11_0
# Benchmark: drop
# Data Indices: [270, 227]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information from the passage
        extraction_instruction = """
        Extract all relevant entities, numerical values, dates, and spans from the passage. 
        Include both explicit and implicit information. Pay attention to:
        - Entities (e.g., teams, players, countries)
        - Numerical values (e.g., scores, counts, measurements)
        - Dates and time-related information
        - Relationships between entities and numbers
        Organize the extracted information in a structured format for easy reference.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_analysis_instruction = f"""
        Analyze the question and determine its intent. Based on the extracted information:
        {extracted_info}
        Classify the question into one of the following categories:
        - Arithmetic operations (e.g., sum, difference, product)
        - Counting (e.g., number of occurrences, distinct items)
        - Comparison (e.g., greater than, less than, equal to)
        - Span extraction (e.g., entity names, phrases)
        Provide a clear explanation of the reasoning behind your classification.
        """
        question_intent = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question intent
        reasoning_instruction = f"""
        Based on the question intent:
        {question_intent}
        Use the extracted information:
        {extracted_info}
        Perform the necessary reasoning to answer the question. Follow these guidelines:
        - For arithmetic operations, summarize the relevant numbers and compute the result.
        - For counting, count the occurrences of the specified entities or events.
        - For comparison, compare the relevant numerical values or spans.
        - For span extraction, identify and extract the requested text span.
        Provide a detailed explanation of the reasoning process.
        """
        reasoning_output = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine and validate the reasoning output
        refinement_instruction = f"""
        Critique and refine the reasoning output:
        {reasoning_output}
        Address any ambiguities, inconsistencies, or errors. Ensure the reasoning is accurate and robust.
        Provide a revised version of the reasoning output with improvements highlighted.
        """
        refined_output = await self.revise(instruction=refinement_instruction, context=reasoning_output)

        # Step 5: Synthesize the final answer
        synthesis_instruction = f"""
        Condense the refined reasoning output:
        {refined_output}
        Into a concise final answer that directly addresses the question. Ensure clarity and relevance.
        Format the answer appropriately (e.g., numerical value, date, text span).
        """
        final_answer = await self.summarize(instruction=synthesis_instruction, context=refined_output)

        return final_answer