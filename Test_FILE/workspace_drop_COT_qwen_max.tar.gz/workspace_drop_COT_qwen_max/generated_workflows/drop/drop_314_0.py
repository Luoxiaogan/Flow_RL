# Workflow ID: drop_314_0
# Benchmark: drop
# Data Indices: [150, 380]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all relevant numerical values, entities, and relationships
        extraction_instruction = (
            "Extract all numerical values, entities, and their relationships from the passage. "
            "Include explicit and implicit information. Format the output as a structured list."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_analysis_instruction = (
            "Analyze the question to determine its intent. "
            "Identify whether the question requires arithmetic operations, counting, comparison, span extraction, or another type of reasoning. "
            "Provide a clear explanation of the reasoning process needed to answer the question."
        )
        question_intent = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question intent
        reasoning_instruction = (
            f"Based on the extracted information: {extracted_info} and the question intent: {question_intent}, "
            "perform the necessary reasoning to answer the question. "
            "Include all steps of the reasoning process and ensure the answer is accurate and complete."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the reasoning process or final answer
        refinement_instruction = (
            "Critique and refine the reasoning process or the final answer. "
            "Ensure the reasoning is accurate, address any ambiguities, and improve clarity. "
            "If necessary, suggest corrections or improvements."
        )
        refined_result = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Summarize the final answer
        summarization_instruction = (
            "Condense the reasoning into a concise final answer that directly addresses the question. "
            "Ensure the answer is clear, accurate, and formatted appropriately."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_result)

        return final_answer