# Workflow ID: drop_144_0
# Benchmark: drop
# Data Indices: [330, 244]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract relevant entities, numbers, and relationships
        extraction_instruction = """
        Extract all relevant entities, numerical values, dates, and relationships from the passage and question. 
        Pay special attention to:
        - Entities mentioned in the question
        - Numbers and their associated entities
        - Implicit relationships or references (e.g., pronouns, partial names)
        Format the output as a structured list of key-value pairs.
        """
        extracted_data = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Interpret the question's intent
        question_intent_instruction = f"""
        Analyze the question to determine its intent and type. Specifically:
        - Classify the question type (e.g., arithmetic, counting, comparison, selection, span extraction)
        - Identify what specific information is being asked for
        - Use the extracted data: {extracted_data}
        Provide a clear explanation of the reasoning behind your classification.
        """
        question_analysis = await self.generate(instruction=question_intent_instruction, context=self.problem_text)

        # Step 3: Parallel reasoning paths
        arithmetic_instruction = f"""
        Perform any required arithmetic operations (e.g., addition, subtraction) based on the question and extracted data: {extracted_data}.
        Ensure you associate numbers with their correct entities and explain each step.
        """
        counting_instruction = f"""
        Count the occurrences or distinct entities relevant to the question using the extracted data: {extracted_data}.
        Clearly specify what is being counted and why.
        """
        comparison_instruction = f"""
        Compare entities or values as required by the question using the extracted data: {extracted_data}.
        Explain the basis of the comparison and the conclusion.
        """
        span_extraction_instruction = f"""
        Extract the exact text span that answers the question from the passage using the extracted data: {extracted_data}.
        Ensure the span is precise and directly addresses the question.
        """

        # Run reasoning paths in parallel
        reasoning_results = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=counting_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text),
            self.generate(instruction=span_extraction_instruction, context=self.problem_text)
        )

        # Step 4: Validate and refine results
        refinement_instruction = f"""
        Critique and refine the following reasoning results to ensure accuracy and resolve ambiguities:
        - Arithmetic: {reasoning_results[0]}
        - Counting: {reasoning_results[1]}
        - Comparison: {reasoning_results[2]}
        - Span Extraction: {reasoning_results[3]}
        Use the extracted data: {extracted_data} and the question analysis: {question_analysis} to guide your critique.
        """
        refined_results = await self.revise(instruction=refinement_instruction, context="\n".join(reasoning_results))

        # Step 5: Final decision
        ensemble_instruction = f"""
        Evaluate the refined results and select or synthesize the best answer:
        - Refined Results: {refined_results}
        Use the question analysis: {question_analysis} to determine the most appropriate answer.
        """
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=refined_results.split("\n"))

        return final_answer