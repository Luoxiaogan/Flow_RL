# Workflow ID: drop_340_0
# Benchmark: drop
# Data Indices: [687, 535]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information from the passage
        extraction_instruction = """
        Analyze the provided passage and extract all relevant information that could help answer the question. 
        Include entities, numerical values, dates, and relationships between them. 
        Organize the extracted information clearly and categorically.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine the reasoning type
        question_analysis_instruction = f"""
        Analyze the question and determine what type of reasoning is required to answer it. 
        Consider whether the question involves arithmetic operations, counting, comparison, selection, or span extraction. 
        Map the question to the extracted information provided below:
        {extracted_info}
        """
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Explore multiple reasoning paths in parallel
        arithmetic_instruction = f"""
        If the question requires arithmetic operations, perform the necessary calculations using the extracted information:
        {extracted_info}
        Ensure your calculations are accurate and explain your reasoning step-by-step.
        """

        counting_instruction = f"""
        If the question requires counting occurrences or instances, count the relevant items using the extracted information:
        {extracted_info}
        Provide a clear explanation of your counting process.
        """

        comparison_instruction = f"""
        If the question requires comparison, compare the relevant entities or values using the extracted information:
        {extracted_info}
        Clearly state which entity or value is greater, smaller, or equal.
        """

        selection_instruction = f"""
        If the question requires selecting a specific entity or value, identify the correct choice using the extracted information:
        {extracted_info}
        Justify your selection with evidence from the passage.
        """

        span_extraction_instruction = f"""
        If the question requires extracting a text span, identify the exact span from the passage that answers the question:
        {extracted_info}
        Ensure the span is complete and directly addresses the question.
        """

        # Execute reasoning paths in parallel
        reasoning_results = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=counting_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text),
            self.generate(instruction=selection_instruction, context=self.problem_text),
            self.generate(instruction=span_extraction_instruction, context=self.problem_text)
        )

        # Step 4: Synthesize results using Ensemble
        synthesis_instruction = """
        Evaluate the following reasoning results and select the most accurate and relevant answer to the question. 
        Provide a justification for your choice based on accuracy, relevance, and completeness.
        """
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=reasoning_results)

        # Step 5 (Optional): Refine the final answer if needed
        refinement_instruction = """
        Review the final answer and refine it if it seems incomplete, ambiguous, or incorrect. 
        Provide a revised version that is clear, concise, and fully addresses the question.
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        return refined_answer