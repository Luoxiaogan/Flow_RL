# Workflow ID: drop_106_0
# Benchmark: drop
# Data Indices: [135, 643]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all touchdown passes and their yardages
        extraction_instruction = """
        Carefully read the passage and extract EVERY instance where a touchdown pass is mentioned. 
        For each touchdown pass, identify:
        - The players involved (quarterback and receiver)
        - The yardage of the touchdown pass
        Format the output as a list of tuples, where each tuple contains:
        (Quarterback, Receiver, Yardage)
        If no touchdown passes are mentioned, return an empty list.
        """
        raw_extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Revise and refine the extracted information
        revise_instruction = f"""
        Review the following extracted information about touchdown passes:
        {raw_extraction}
        Ensure that:
        - Each entry correctly identifies a touchdown pass
        - The yardage is accurately captured as a number
        - Any incomplete or ambiguous entries are corrected or removed
        Return the revised list in the same format.
        """
        refined_extraction = await self.revise(instruction=revise_instruction, context=raw_extraction)

        # Step 3: Determine the longest touchdown pass
        ensemble_instruction = f"""
        Given the following list of touchdown passes and their yardages:
        {refined_extraction}
        Compare the yardages and determine which one is the longest.
        Return the yardage of the longest touchdown pass.
        If there are ties, return any one of the tied values.
        If no valid touchdown passes are found, return 'No valid touchdown passes found'.
        """
        longest_touchdown_pass = await self.ensemble(instruction=ensemble_instruction, contexts=[refined_extraction])

        return longest_touchdown_pass