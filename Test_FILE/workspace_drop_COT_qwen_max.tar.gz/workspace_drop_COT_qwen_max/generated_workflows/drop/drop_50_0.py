# Workflow ID: drop_50_0
# Benchmark: drop
# Data Indices: [339, 186]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant entities, numbers, and relationships
        extraction_instruction = (
            "Carefully analyze the passage and extract all entities, numerical values, and their relationships. "
            "Include explicit mentions as well as inferred connections. Format the output clearly for further analysis."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_analysis_instruction = (
            f"Given the extracted information: {extracted_info}\n"
            "Analyze the question to determine its type (e.g., arithmetic, counting, comparison, selection, span extraction). "
            "Identify any ambiguities or coreference issues that need resolution."
        )
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Generate parallel reasoning paths
        arithmetic_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Perform arithmetic operations (addition, subtraction, etc.) if applicable. Provide intermediate steps and final results."
        )
        counting_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Count occurrences of specific entities or events mentioned in the question. Provide clear explanations for each count."
        )
        comparison_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Compare entities based on the criteria specified in the question. Clearly state which entity satisfies the condition."
        )
        span_extraction_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Extract the exact text span from the passage that answers the question. Ensure the span is concise and accurate."
        )

        reasoning_paths = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=counting_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text),
            self.generate(instruction=span_extraction_instruction, context=self.problem_text)
        )

        # Step 4: Validate and refine results
        refinement_instructions = [
            f"Review the following reasoning path: {path}\n"
            "Validate its correctness and resolve any ambiguities. Refine the result if necessary."
            for path in reasoning_paths
        ]
        refined_results = await asyncio.gather(
            *[self.revise(instruction=instr, context=self.problem_text) for instr in refinement_instructions]
        )

        # Step 5: Final decision using ensemble
        ensemble_instruction = (
            "Evaluate the following refined results and select the most accurate and complete answer. "
            "Provide justification for your choice."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=refined_results)

        return final_answer