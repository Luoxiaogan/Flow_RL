# Workflow ID: drop_135_0
# Benchmark: drop
# Data Indices: [3, 593]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio
        
        # Step 1: Extract relevant information from the passage
        extraction_instruction = """
        Extract all numerical values, entities, events, and relationships between them from the passage. 
        Focus on information that could potentially answer the question. 
        Format your output as a structured list of key-value pairs or bullet points.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)
        
        # Step 2: Analyze the question to determine its intent
        question_intent_instruction = f"""
        Analyze the question to determine its intent. 
        Identify whether the question requires arithmetic operations (e.g., addition, subtraction), 
        counting, comparison, selection, or span extraction. 
        Use the following extracted information for context: {extracted_info}.
        Provide a clear explanation of the question's intent.
        """
        question_intent = await self.generate(instruction=question_intent_instruction, context=self.problem_text)
        
        # Step 3: Perform reasoning or calculation based on the question intent
        reasoning_instruction = f"""
        Based on the identified intent of the question ({question_intent}), 
        perform the necessary reasoning or calculations using the extracted information: {extracted_info}. 
        If the question involves arithmetic operations, show the step-by-step calculation. 
        If it involves counting, comparison, or selection, clearly explain the process. 
        If it requires span extraction, identify the exact text span that answers the question.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)
        
        # Step 4: Validate and refine the answer
        refinement_instruction = f"""
        Validate and refine the following reasoning result: {reasoning_result}. 
        Ensure that the answer is accurate, complete, and directly addresses the question. 
        If there are any ambiguities or errors, correct them and provide a revised answer.
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=reasoning_result)
        
        # Step 5: Final answer assembly (if multiple reasoning paths were explored)
        # Use ensemble to select the best answer if needed
        final_answer = refined_answer  # Default to refined answer if no ensemble is needed
        
        return final_answer