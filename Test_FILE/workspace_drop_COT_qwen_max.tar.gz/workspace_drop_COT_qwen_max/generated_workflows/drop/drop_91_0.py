# Workflow ID: drop_91_0
# Benchmark: drop
# Data Indices: [598, 549]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant numerical values, entities, and relationships
        extraction_instruction = (
            "Extract all numerical values, entities, and their relationships from the passage and question. "
            "Include both explicit and implicit information. Ensure no relevant detail is missed."
        )
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its type
        question_analysis_instruction = (
            "Analyze the question to determine its type. Possible types include arithmetic operations, counting, "
            "comparison, and span extraction. Provide a clear classification and reasoning for the type."
        )
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Execute reasoning based on the question type
        reasoning_instruction_template = (
            "Based on the question type identified as {question_type}, perform the required reasoning. "
            "Use the extracted information: {extraction}. Ensure the reasoning is step-by-step and accurate."
        )

        # Parallel execution for independent operations
        reasoning_tasks = []
        if "arithmetic" in question_analysis:
            reasoning_instruction = reasoning_instruction_template.format(
                question_type="arithmetic", extraction=extraction
            )
            reasoning_tasks.append(self.generate(instruction=reasoning_instruction, context=self.problem_text))
        elif "counting" in question_analysis:
            reasoning_instruction = reasoning_instruction_template.format(
                question_type="counting", extraction=extraction
            )
            reasoning_tasks.append(self.generate(instruction=reasoning_instruction, context=self.problem_text))
        elif "comparison" in question_analysis:
            reasoning_instruction = reasoning_instruction_template.format(
                question_type="comparison", extraction=extraction
            )
            reasoning_tasks.append(self.generate(instruction=reasoning_instruction, context=self.problem_text))
        elif "span extraction" in question_analysis:
            reasoning_instruction = reasoning_instruction_template.format(
                question_type="span extraction", extraction=extraction
            )
            reasoning_tasks.append(self.generate(instruction=reasoning_instruction, context=self.problem_text))

        reasoning_results = await asyncio.gather(*reasoning_tasks)

        # Step 4: Validate and refine intermediate results
        refinement_instruction = (
            "Critique and refine the following reasoning result: {result}. "
            "Ensure accuracy and alignment with the question intent."
        )
        refined_results = [
            await self.revise(instruction=refinement_instruction.format(result=result), context=self.problem_text)
            for result in reasoning_results
        ]

        # Step 5: Synthesize the final answer
        synthesis_instruction = (
            "Synthesize the refined results into a final answer. Ensure the answer adheres to the question's requirements."
        )
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=refined_results)

        return final_answer