# Workflow ID: drop_376_0
# Benchmark: drop
# Data Indices: [607, 332]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all relevant numerical values and entities
        extract_instruction = """
        Extract all numerical values, entities, and their relationships from the passage.
        Include:
        - Numbers (with units if applicable)
        - Names of people, teams, or other entities
        - Relationships between entities and numbers (e.g., who scored how many points)
        Organize the information clearly for further reasoning.
        """
        extraction = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Analyze the question intent
        analyze_instruction = f"""
        Analyze the question to determine the type of reasoning required.
        Consider the following categories:
        - Arithmetic operations (e.g., sum, difference, multiplication)
        - Counting (e.g., how many times something occurred)
        - Comparison (e.g., which is greater, who had more)
        - Selection (e.g., which team won, what happened first)
        - Span extraction (e.g., who did something, what was the name of something)
        Based on the question, identify the specific reasoning task and any constraints.
        Relevant extracted information: {extraction}
        """
        analysis = await self.generate(instruction=analyze_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question intent
        reasoning_instruction = f"""
        Using the extracted information and the analysis of the question intent, perform the required reasoning.
        - If the question involves arithmetic, compute the result step by step.
        - If the question involves counting, count the relevant occurrences.
        - If the question involves comparison, compare the relevant values.
        - If the question involves selection, identify the correct entity or event.
        - If the question involves span extraction, extract the relevant text span.
        Ensure the reasoning process is clear and logical.
        Relevant extracted information: {extraction}
        Question analysis: {analysis}
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the result
        refine_instruction = f"""
        Review the reasoning result to ensure it is accurate and consistent with the passage.
        Correct any errors or ambiguities in the result.
        Provide the final answer in a concise format.
        Reasoning result: {reasoning_result}
        """
        refined_result = await self.revise(instruction=refine_instruction, context=reasoning_result)

        # Step 5: Final output
        return refined_result