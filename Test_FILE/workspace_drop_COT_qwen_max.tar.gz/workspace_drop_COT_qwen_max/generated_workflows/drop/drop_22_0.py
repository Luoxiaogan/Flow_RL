# Workflow ID: drop_22_0
# Benchmark: drop
# Data Indices: [207, 268]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio
        
        # Step 1: Extract relevant information from the passage
        extract_instruction = """
        Extract all numerical values, entities, and their relationships from the passage. 
        Categorize the extracted information as follows:
        - Numerical values: Include all numbers mentioned in the passage.
        - Entities: Include names of people, teams, locations, or other relevant objects.
        - Relationships: Describe how the numerical values are associated with the entities.
        Ensure no information is missed and provide the output in a structured format.
        """
        extraction = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine the reasoning type
        analyze_instruction = f"""
        Analyze the question to determine the type of reasoning required. 
        Classify the question into one of the following categories:
        - Arithmetic: Involves addition, subtraction, multiplication, or division.
        - Counting: Requires counting occurrences of specific entities or events.
        - Comparison: Involves comparing values or entities.
        - Selection: Requires selecting an entity or span based on specific criteria.
        - Span Extraction: Requires extracting a text span from the passage.
        Provide the reasoning type and any specific details needed to answer the question.
        """
        question_analysis = await self.generate(instruction=analyze_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question type
        reasoning_instruction = f"""
        Based on the extracted information: {extraction}
        And the question analysis: {question_analysis}
        Perform the required reasoning operation step by step. 
        If the question involves arithmetic, perform the calculation explicitly. 
        If it involves counting, count the occurrences accurately. 
        If it involves comparison, compare the values clearly. 
        If it involves selection or span extraction, identify the correct entity or span.
        Provide the result in a clear and structured format.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the result
        validate_instruction = f"""
        Validate the reasoning result: {reasoning_result}
        Cross-check it against the passage and question to ensure accuracy. 
        If there are discrepancies or ambiguities, refine the result accordingly.
        """
        refined_result = await self.revise(instruction=validate_instruction, context=reasoning_result)

        # Step 5: Summarize the final answer
        summarize_instruction = """
        Summarize the final answer in a concise and clear format. 
        Ensure the answer directly addresses the question and includes all necessary details.
        """
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_result)

        return final_answer