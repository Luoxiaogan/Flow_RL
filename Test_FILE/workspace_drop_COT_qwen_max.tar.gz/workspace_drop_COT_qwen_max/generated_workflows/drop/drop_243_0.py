# Workflow ID: drop_243_0
# Benchmark: drop
# Data Indices: [181, 505]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract relevant information from the passage
        extraction_instruction = (
            "Extract all entities, numerical values, and relationships from the passage that are relevant to the question. "
            "Ensure you capture all potential data points needed for reasoning, including implicit information."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Infer the type of reasoning required
        intent_instruction = (
            f"Based on the extracted information: {extracted_info}, analyze the question to determine the type of reasoning required. "
            "Identify whether the question involves counting, arithmetic operations (e.g., addition, subtraction), comparison, span extraction, or another reasoning task."
        )
        reasoning_intent = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Perform the required reasoning or calculation
        reasoning_instruction = (
            f"Given the reasoning intent: {reasoning_intent}, and the extracted information: {extracted_info}, "
            "perform the necessary reasoning or calculation to answer the question. Ensure the reasoning is explicit and step-by-step."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the result
        refinement_instruction = (
            f"Critique and refine the following reasoning result: {reasoning_result}. "
            "Ensure the reasoning aligns with the question's intent and the extracted information. Correct any errors or ambiguities."
        )
        refined_result = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Handle ambiguity with parallel exploration and ensemble decision
        alternative_approach_instruction = (
            f"Consider alternative interpretations or approaches to the question based on the extracted information: {extracted_info}. "
            "Provide a plausible alternative solution."
        )
        alternative_result = await self.generate(instruction=alternative_approach_instruction, context=self.problem_text)

        # Ensemble to select the best result
        ensemble_instruction = (
            "Compare the following results and select the most accurate and well-reasoned answer: "
            f"Result 1: {refined_result}, Result 2: {alternative_result}."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[refined_result, alternative_result])

        return final_answer