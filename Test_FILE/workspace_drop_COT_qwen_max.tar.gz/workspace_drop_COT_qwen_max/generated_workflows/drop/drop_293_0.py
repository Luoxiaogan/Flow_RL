# Workflow ID: drop_293_0
# Benchmark: drop
# Data Indices: [210, 225]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information from the passage
        extract_instruction = (
            "Identify and extract all entities, numbers, dates, and key phrases from the passage. "
            "Ensure you capture all potential answers to the question, including numerical values, events, "
            "and relationships between entities. Format your output as a structured list."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its type and intent
        question_analysis_instruction = (
            "Analyze the question to determine its type and intent. Identify whether it requires arithmetic operations, "
            "counting, comparison, selection, or span extraction. Resolve any ambiguous references or pronouns by linking "
            "them to specific entities in the passage. Provide a clear explanation of the reasoning process."
        )
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or calculation based on the question type
        reasoning_instruction = (
            f"Using the extracted information: {extracted_info} and the question analysis: {question_analysis}, "
            "perform the necessary reasoning or calculations to answer the question. If the question involves arithmetic, "
            "show the steps for addition, subtraction, or comparison. If it involves counting, ensure all relevant "
            "occurrences are included. If it involves comparison, clearly state the basis for comparison. Format your "
            "output as a detailed explanation followed by the final answer."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the answer
        validation_instruction = (
            f"Critique and refine the following reasoning result: {reasoning_result}. Ensure the answer is accurate, "
            "logically consistent, and supported by the passage. Handle any implicit information or edge cases. Provide "
            "a revised version of the answer if necessary."
        )
        refined_answer = await self.revise(instruction=validation_instruction, context=reasoning_result)

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"Condense the following refined answer into a concise and clear format: {refined_answer}. Ensure the final "
            "output directly addresses the question and includes only the most relevant information."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_answer)

        return final_answer