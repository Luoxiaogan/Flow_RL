# Workflow ID: drop_281_0
# Benchmark: drop
# Data Indices: [52, 220]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Analyze the problem to determine the question type and extract relevant information
        analysis = await self.generate(
            instruction="""
            Analyze the problem to determine the type of reasoning required. 
            Identify whether the question involves arithmetic operations, counting, comparison, selection, or span extraction.
            Extract all relevant entities, numbers, dates, or spans mentioned in the passage and associate them with their context.
            Return a structured summary of the question type and extracted information.
            """,
            context=self.problem_text
        )

        # Step 2: Dynamically construct instructions based on the identified question type
        reasoning_instructions = f"""
        Based on the following analysis: {analysis}
        Perform the necessary reasoning steps to answer the question. 
        If the question involves arithmetic operations, extract relevant numbers and perform the specified operation.
        If the question involves comparisons, identify the entities being compared and their associated values.
        If the question involves span extraction, focus on identifying the exact phrase or entity requested.
        """

        # Step 3: Perform reasoning steps in parallel if multiple paths are possible
        reasoning_tasks = [
            self.generate(
                instruction=reasoning_instructions,
                context=self.problem_text
            )
        ]

        reasoning_results = await asyncio.gather(*reasoning_tasks)

        # Step 4: Refine intermediate outputs to ensure accuracy
        refined_results = await asyncio.gather(
            *[self.revise(
                instruction="Refine the reasoning output to ensure accuracy and completeness.",
                context=result
            ) for result in reasoning_results]
        )

        # Step 5: Synthesize results using Ensemble to produce the final answer
        final_answer = await self.ensemble(
            instruction="Synthesize the refined results into a concise and accurate final answer.",
            contexts=refined_results
        )

        return final_answer