# Workflow ID: drop_123_0
# Benchmark: drop
# Data Indices: [720, 33]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information (parallel execution)
        extract_instruction = (
            "Extract all numerical values, entities, and relationships from the passage and question. "
            "Include any relevant context that could help answer the question. "
            "Format the output as a structured list of key-value pairs."
        )
        interpret_instruction = (
            "Analyze the question to determine its intent. "
            "Identify whether the question requires arithmetic, counting, comparison, selection, or span extraction. "
            "Provide a clear explanation of the reasoning process."
        )
        extraction, interpretation = await asyncio.gather(
            self.generate(instruction=extract_instruction, context=self.problem_text),
            self.generate(instruction=interpret_instruction, context=self.problem_text)
        )

        # Step 2: Perform reasoning based on interpreted intent
        reasoning_instruction = (
            f"Based on the extracted information: {extraction}\n"
            f"And the interpreted intent: {interpretation}\n"
            "Perform the required reasoning to answer the question. "
            "If the question involves arithmetic, calculate the result. "
            "If it involves counting, count occurrences of specific entities. "
            "If it involves comparison, compare values and determine the correct answer. "
            "If it involves span extraction, identify and extract the relevant text span. "
            "Provide a detailed explanation of the reasoning process."
        )
        reasoning = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Validate and refine the reasoning output
        refine_instruction = (
            "Critique and refine the following reasoning output to ensure accuracy and clarity. "
            "Address any potential ambiguities or errors. "
            "Provide suggestions for improvement if necessary."
        )
        refined_reasoning = await self.revise(instruction=refine_instruction, context=reasoning)

        # Step 4: Finalize the answer
        summarize_instruction = (
            "Condense the refined reasoning into a concise, final answer. "
            "Ensure the output directly addresses the question and is easy to understand."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_reasoning)

        return final_answer