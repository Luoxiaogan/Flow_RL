# Workflow ID: drop_137_0
# Benchmark: drop
# Data Indices: [495, 597]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Initial Extraction
        extraction_instruction = """
        Extract all relevant entities, numerical values, dates, and spans from the passage and question. 
        For entities, include names of people, teams, places, and objects. 
        For numerical values, include counts, scores, measurements, and statistics. 
        For dates, include years, months, days, and relative time references. 
        For spans, include phrases or sentences that directly relate to the question. 
        Organize the extracted information into categories for easy reference.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Question Analysis
        analysis_instruction = f"""
        Analyze the question to determine its intent. Based on the extracted information:
        {extracted_info}
        Identify whether the question requires arithmetic operations, counting, comparison, selection, or span extraction. 
        Provide a detailed breakdown of the reasoning steps needed to answer the question.
        """
        question_analysis = await self.generate(instruction=analysis_instruction, context=self.problem_text)

        # Step 3: Parallel Reasoning Paths
        arithmetic_instruction = f"""
        If the question involves arithmetic operations, perform the necessary calculations using the extracted numerical values.
        Ensure all numbers are correctly associated with their entities and operations. 
        Provide a step-by-step explanation of the calculations.
        """
        counting_instruction = f"""
        If the question involves counting, count the relevant occurrences of entities, events, or items mentioned in the passage.
        Ensure no instances are missed and provide a clear tally.
        """
        comparison_instruction = f"""
        If the question involves comparison, compare the relevant entities, values, or spans based on the extracted information.
        Clearly state which is greater, longer, more frequent, or otherwise superior.
        """
        selection_instruction = f"""
        If the question involves selection, identify the correct entity, value, or span that satisfies the question's criteria.
        Ensure the selection is justified by the passage.
        """
        span_extraction_instruction = f"""
        If the question involves span extraction, extract the exact text span from the passage that answers the question.
        Ensure the span is complete and directly addresses the question.
        """

        # Execute reasoning paths in parallel
        reasoning_paths = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=counting_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text),
            self.generate(instruction=selection_instruction, context=self.problem_text),
            self.generate(instruction=span_extraction_instruction, context=self.problem_text)
        )

        # Step 4: Ensemble to Select Best Answer
        ensemble_instruction = f"""
        Evaluate the following reasoning paths and select the most accurate and comprehensive answer:
        Path 1 (Arithmetic): {reasoning_paths[0]}
        Path 2 (Counting): {reasoning_paths[1]}
        Path 3 (Comparison): {reasoning_paths[2]}
        Path 4 (Selection): {reasoning_paths[3]}
        Path 5 (Span Extraction): {reasoning_paths[4]}
        Ensure the chosen answer aligns with the question's intent and is supported by the passage.
        """
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=reasoning_paths)

        # Step 5: Final Refinement
        refinement_instruction = f"""
        Critique and refine the following answer to ensure it is precise, accurate, and well-supported by the passage:
        {final_answer}
        Verify that all entities, values, and spans are correctly associated and that the answer fully addresses the question.
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        return refined_answer