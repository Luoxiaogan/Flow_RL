# Workflow ID: drop_299_0
# Benchmark: drop
# Data Indices: [421, 587]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the passage and question
        extraction_instruction = (
            "Thoroughly analyze the passage and question. "
            "Extract all relevant entities, numerical values, dates, and relationships. "
            "Include implicit information and resolve any ambiguous references. "
            "Format the output as a structured list of key-value pairs."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Understand the question intent
        intent_instruction = (
            f"Given the extracted information: {extracted_info}, "
            "analyze the question to determine its type. "
            "Classify it as one of the following: arithmetic, counting, comparison, selection, span extraction. "
            "Provide a detailed explanation of the reasoning behind the classification."
        )
        question_intent = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question type
        reasoning_instruction = (
            f"Using the extracted information: {extracted_info}, and the question intent: {question_intent}, "
            "perform the necessary reasoning to answer the question. "
            "For arithmetic questions, calculate the result. "
            "For counting questions, count the relevant occurrences. "
            "For comparison questions, compare the relevant values. "
            "For selection questions, identify the correct entity or span. "
            "For span extraction questions, extract the relevant text span. "
            "Provide a step-by-step explanation of the reasoning process."
        )
        reasoning_output = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the reasoning output
        refinement_instruction = (
            f"Review the reasoning output: {reasoning_output}. "
            "Critique and refine it for accuracy and clarity. "
            "Ensure all steps are logically sound and the final result directly answers the question. "
            "Correct any errors or omissions."
        )
        refined_output = await self.revise(instruction=refinement_instruction, context=reasoning_output)

        # Step 5: Summarize the answer
        summary_instruction = (
            f"Condense the refined output: {refined_output} into a concise answer. "
            "Ensure the answer directly addresses the question and is formatted appropriately. "
            "For numerical answers, provide only the number. "
            "For span extraction, provide the exact text span."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_output)

        return final_answer