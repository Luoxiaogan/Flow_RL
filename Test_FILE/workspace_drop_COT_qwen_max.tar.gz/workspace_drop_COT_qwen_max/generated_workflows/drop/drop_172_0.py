# Workflow ID: drop_172_0
# Benchmark: drop
# Data Indices: [639, 578]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract entities, numerical values, and relationships from the passage
        extraction_instruction = (
            "Extract all entities, numerical values, and their relationships from the passage. "
            "Include explicit and implicit information, resolving any ambiguous references. "
            "Format the output as a structured list for easy reference."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its type
        question_analysis_instruction = (
            "Analyze the question to determine its type. "
            "Possible types include arithmetic operations (addition, subtraction, etc.), counting, comparison, selection, and span extraction. "
            "Provide a clear classification and reasoning for the identified type."
        )
        question_type = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Generate candidate solutions in parallel based on the question type
        arithmetic_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "perform all possible arithmetic operations (addition, subtraction, multiplication, division) "
            "that could answer the question. Include intermediate steps and reasoning."
        )
        comparison_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "compare all relevant entities and their associated values. "
            "Determine which entity satisfies the comparison criteria."
        )
        span_extraction_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "identify all potential text spans that answer the question. "
            "Ensure spans are precise and directly relevant to the query."
        )

        # Execute candidate generation in parallel
        candidates = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text),
            self.generate(instruction=span_extraction_instruction, context=self.problem_text)
        )

        # Step 4: Validate and refine candidate solutions
        refinement_instruction = (
            "Validate the provided candidate solutions against the passage and question intent. "
            "Refine any ambiguous or incomplete responses. Ensure the final output is accurate and well-supported."
        )
        refined_candidates = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction, context=candidate) for candidate in candidates]
        )

        # Step 5: Select the best solution using Ensemble
        ensemble_instruction = (
            "Evaluate the provided candidate solutions and select the best one. "
            "Consider accuracy, relevance to the question, and alignment with the passage. "
            "Provide a justification for the selected solution."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_candidates)

        return final_solution