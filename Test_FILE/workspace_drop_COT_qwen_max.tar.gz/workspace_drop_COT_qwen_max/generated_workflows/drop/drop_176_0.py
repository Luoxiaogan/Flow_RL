# Workflow ID: drop_176_0
# Benchmark: drop
# Data Indices: [436, 491]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information from the passage
        extraction_instruction = (
            "Thoroughly analyze the provided passage to extract all entities, numerical values, dates, "
            "and relationships. Ensure no relevant detail is missed. Organize the extracted information "
            "in a structured format for easy reference."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_analysis_instruction = (
            f"Given the extracted information: {extracted_info}\n"
            "Carefully analyze the question to determine its intent. Identify whether the question requires "
            "arithmetic operations (e.g., addition, subtraction), counting, comparison, selection, or span extraction. "
            "Provide a clear breakdown of the reasoning process."
        )
        question_intent = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Generate candidate solutions
        candidate_instructions = []
        if "arithmetic" in question_intent.lower():
            candidate_instructions.append(
                f"Perform all possible arithmetic operations (addition, subtraction, etc.) using the numbers "
                f"in the extracted information: {extracted_info}. Ensure calculations align with the question intent."
            )
        if "counting" in question_intent.lower():
            candidate_instructions.append(
                f"Count all relevant occurrences mentioned in the extracted information: {extracted_info}. "
                "Ensure the count aligns with the question's requirements."
            )
        if "comparison" in question_intent.lower():
            candidate_instructions.append(
                f"Compare the relevant entities or values in the extracted information: {extracted_info}. "
                "Determine which is greater, longer, or more, as specified by the question."
            )
        if "selection" in question_intent.lower():
            candidate_instructions.append(
                f"Select the appropriate entity, value, or span from the extracted information: {extracted_info}. "
                "Ensure the selection matches the question's criteria."
            )
        if "span extraction" in question_intent.lower():
            candidate_instructions.append(
                f"Extract the relevant text span from the passage based on the extracted information: {extracted_info}. "
                "Ensure the span directly answers the question."
            )

        # Generate candidate solutions in parallel
        candidate_tasks = [
            self.generate(instruction=instr, context=self.problem_text) for instr in candidate_instructions
        ]
        candidate_solutions = await asyncio.gather(*candidate_tasks)

        # Step 4: Ensemble decision to select the best solution
        ensemble_instruction = (
            "Evaluate the following candidate solutions and select the best one. "
            "Consider the following criteria:\n"
            "- Consistency with the passage\n"
            "- Alignment with the question intent\n"
            "- Logical coherence and correctness\n"
            f"Candidate solutions: {candidate_solutions}"
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=candidate_solutions)

        # Step 5: Refine the final solution
        refinement_instruction = (
            f"Refine the selected solution: {final_solution}\n"
            "Ensure it adheres to formatting requirements, resolves any ambiguities, and is presented clearly."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=final_solution)

        return refined_solution