# Workflow ID: drop_142_0
# Benchmark: drop
# Data Indices: [767, 784]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract all relevant information from the passage
        extraction_instruction = """
        Extract ALL numerical values, entities, and relationships from the passage that could be relevant to answering the question. 
        Include details about who performed actions, what actions were performed, and any associated quantities or measurements. 
        Ensure no information is omitted, even if it seems minor.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_analysis_instruction = f"""
        Analyze the question to determine its intent. Specifically:
        - Identify if the question requires arithmetic operations (e.g., addition, subtraction), counting, comparison, or span extraction.
        - Based on the following extracted information: {extracted_info}
        Provide clear guidance on how to proceed with solving the question.
        """
        question_intent = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question intent
        reasoning_instruction = f"""
        Using the extracted information: {extracted_info}
        And the question intent analysis: {question_intent}
        Perform the necessary reasoning to answer the question. This may involve:
        - Arithmetic operations (e.g., calculating differences, sums)
        - Counting occurrences of specific entities or events
        - Comparing values or entities
        - Extracting specific spans of text as answers
        Ensure the reasoning process is thorough and leaves no ambiguity.
        """
        reasoning_output = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine the reasoning output
        refinement_instruction = f"""
        Critique and refine the following reasoning output: {reasoning_output}
        Ensure the reasoning is accurate, complete, and directly addresses the question. 
        Correct any errors or ambiguities, and provide a polished version of the reasoning.
        """
        refined_output = await self.revise(instruction=refinement_instruction, context=reasoning_output)

        # Step 5: Handle multiple candidate answers (if necessary)
        ensemble_instruction = f"""
        If there are multiple candidate answers, evaluate and select the best one based on the following refined reasoning: {refined_output}
        Ensure the selected answer aligns perfectly with the question's requirements.
        """
        final_answer_candidates = [refined_output]  # Default to single candidate
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=final_answer_candidates)

        # Step 6: Summarize the final answer
        summary_instruction = f"""
        Condense the following reasoning and answer into a concise, clear response: {final_answer}
        Ensure the response directly answers the question without unnecessary elaboration.
        """
        summarized_answer = await self.summarize(instruction=summary_instruction, context=final_answer)

        return summarized_answer