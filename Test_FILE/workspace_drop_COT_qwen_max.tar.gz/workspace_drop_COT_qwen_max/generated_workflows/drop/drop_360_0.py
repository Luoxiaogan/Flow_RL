# Workflow ID: drop_360_0
# Benchmark: drop
# Data Indices: [551, 731]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the passage and question
        extraction_instruction = """
        Extract all key information from the passage and question. Focus on identifying:
        - Entities (people, teams, organizations, etc.)
        - Numbers, dates, and other quantitative data
        - Relationships between entities and numbers
        - Implicit or contextual information that may be relevant to answering the question.
        Ensure the extraction is exhaustive and includes all potential candidates for reasoning.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Associate numbers with their respective entities
        association_instruction = f"""
        Given the extracted information: {extracted_info}
        Associate each number or date with its corresponding entity. Pay special attention to:
        - Disambiguating similar entities (e.g., multiple field goals of different lengths)
        - Ensuring correct pairing of numbers with their respective entities
        - Handling cases where numbers might be implied or indirectly referenced.
        Provide a clear mapping of entities to their associated numbers.
        """
        entity_number_mapping = await self.generate(instruction=association_instruction, context=self.problem_text)

        # Step 3: Analyze the question and formulate a reasoning strategy
        reasoning_instruction = f"""
        Analyze the question type and formulate a reasoning strategy based on the following:
        - Extracted information: {extracted_info}
        - Entity-number mapping: {entity_number_mapping}
        Determine whether the question requires:
        - Arithmetic operations (addition, subtraction, etc.)
        - Counting occurrences of specific entities or events
        - Comparison between entities or values
        - Span extraction (e.g., names, phrases)
        - Multi-hop inference or implicit reasoning.
        Provide a step-by-step plan to answer the question.
        """
        reasoning_strategy = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Generate parallel reasoning paths
        arithmetic_instruction = f"""
        Given the reasoning strategy: {reasoning_strategy}
        Perform arithmetic operations if required. Focus on:
        - Adding, subtracting, or comparing numbers as per the strategy
        - Ensuring calculations are based on correctly associated entities.
        """
        counting_instruction = f"""
        Given the reasoning strategy: {reasoning_strategy}
        Count occurrences of specific entities or events as required. Ensure:
        - All relevant instances are included
        - Similar entities are correctly distinguished.
        """
        comparison_instruction = f"""
        Given the reasoning strategy: {reasoning_strategy}
        Compare entities or values as required. Focus on:
        - Determining greater, lesser, or equal relationships
        - Handling ties or ambiguities.
        """
        span_extraction_instruction = f"""
        Given the reasoning strategy: {reasoning_strategy}
        Extract the relevant text span (name, phrase, etc.) as required. Ensure:
        - The span directly answers the question
        - Ambiguous references are resolved.
        """
        reasoning_paths = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=counting_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text),
            self.generate(instruction=span_extraction_instruction, context=self.problem_text)
        )

        # Step 5: Synthesize results and select the final answer
        synthesis_instruction = f"""
        Evaluate the following reasoning paths and select the most accurate and contextually appropriate answer:
        - Arithmetic Path: {reasoning_paths[0]}
        - Counting Path: {reasoning_paths[1]}
        - Comparison Path: {reasoning_paths[2]}
        - Span Extraction Path: {reasoning_paths[3]}
        Ensure the final answer aligns with the question intent and uses all available information effectively.
        """
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=reasoning_paths)

        return final_answer