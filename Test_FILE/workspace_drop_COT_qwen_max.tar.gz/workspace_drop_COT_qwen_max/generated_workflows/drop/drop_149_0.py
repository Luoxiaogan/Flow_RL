# Workflow ID: drop_149_0
# Benchmark: drop
# Data Indices: [617, 575]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all relevant entities, numbers, and relationships
        extraction_instruction = """
        Extract all entities, numerical values, dates, and relationships from the passage. 
        Organize them into categories such as 'Entities', 'Numbers', 'Dates', and 'Relationships'. 
        Ensure no information is missed and provide a structured output.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_analysis_instruction = f"""
        Analyze the question to determine its intent. Use the following extracted information:
        {extracted_info}
        Identify whether the question requires arithmetic operations, counting, comparison, span extraction, or another reasoning type. 
        Provide a clear interpretation of what the question is asking.
        """
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Generate multiple reasoning paths in parallel
        arithmetic_instruction = f"""
        Perform arithmetic operations if applicable. Use the extracted information:
        {extracted_info}
        Solve any addition, subtraction, multiplication, or division required by the question.
        """
        counting_instruction = f"""
        Count occurrences or tally specific items if applicable. Use the extracted information:
        {extracted_info}
        Ensure all instances are accounted for and provide the total count.
        """
        comparison_instruction = f"""
        Compare entities, values, or dates if applicable. Use the extracted information:
        {extracted_info}
        Determine which entity is greater, smaller, or otherwise satisfies the comparison criteria.
        """
        span_extraction_instruction = f"""
        Extract specific text spans if applicable. Use the extracted information:
        {extracted_info}
        Identify the exact phrase, name, or sentence that answers the question.
        """

        reasoning_paths = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=counting_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text),
            self.generate(instruction=span_extraction_instruction, context=self.problem_text)
        )

        # Step 4: Synthesize results using Ensemble
        synthesis_instruction = """
        Evaluate the following reasoning paths and select the most coherent and relevant answer. 
        Ensure the chosen answer directly addresses the question and is supported by the passage.
        """
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=reasoning_paths)

        # Step 5: Refine the final answer
        refinement_instruction = """
        Critique and refine the following answer to ensure clarity, accuracy, and completeness. 
        Correct any errors or ambiguities and provide the final polished response.
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        return refined_answer