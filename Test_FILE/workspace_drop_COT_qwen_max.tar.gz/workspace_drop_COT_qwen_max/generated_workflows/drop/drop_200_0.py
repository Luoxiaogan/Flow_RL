# Workflow ID: drop_200_0
# Benchmark: drop
# Data Indices: [75, 67]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the passage and question
        extraction_instruction = (
            "Carefully analyze the passage and question. "
            "Extract all relevant entities, numbers, dates, and relationships. "
            "Identify how each number or entity relates to the question being asked. "
            "Provide a structured summary of your findings."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Perform reasoning based on the extracted information
        reasoning_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Answer the question using the given data. "
            "If the question involves arithmetic, perform the necessary calculations. "
            "If it involves comparison, clearly state which value is greater or lesser. "
            "If it requires span extraction, identify the exact text span from the passage. "
            "Ensure your reasoning is step-by-step and easy to follow."
        )
        reasoning_output = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Validate and refine the reasoning output
        validation_instruction = (
            "Critique the following reasoning output:\n"
            f"{reasoning_output}\n"
            "Ensure it correctly answers the question and aligns with the extracted information. "
            "If there are errors or ambiguities, revise the output to improve clarity and accuracy."
        )
        refined_output = await self.revise(instruction=validation_instruction, context=reasoning_output)

        # Step 4: Handle ambiguity with ensemble if necessary
        # Check if the refined output contains conflicting interpretations
        ambiguity_check_instruction = (
            "Determine if the following output contains conflicting interpretations or unresolved ambiguities:\n"
            f"{refined_output}\n"
            "If so, provide alternative reasoning paths or interpretations."
        )
        ambiguity_check = await self.generate(instruction=ambiguity_check_instruction, context=self.problem_text)

        if "conflict" in ambiguity_check.lower() or "alternative" in ambiguity_check.lower():
            # Generate alternative reasoning paths
            alternative_1 = await self.generate(
                instruction="Provide one possible interpretation or reasoning path.",
                context=self.problem_text
            )
            alternative_2 = await self.generate(
                instruction="Provide a different interpretation or reasoning path.",
                context=self.problem_text
            )

            # Use Ensemble to decide the best answer
            ensemble_instruction = (
                "Evaluate the following reasoning outputs and select the best one:\n"
                f"Option 1: {alternative_1}\n"
                f"Option 2: {alternative_2}\n"
                "Choose the option that best answers the question and aligns with the extracted information."
            )
            final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[alternative_1, alternative_2])
        else:
            # No ambiguity detected; use the refined output as the final answer
            final_answer = refined_output

        return final_answer