# Workflow ID: drop_210_0
# Benchmark: drop
# Data Indices: [102, 461]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract key information (entities, numbers, relationships)
        extraction_instruction = """
        Extract all relevant entities, numerical values, and their relationships from the passage and question.
        Include explicit mentions and infer implicit relationships where necessary.
        Format the output as a structured list or table for clarity.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Interpret the question's intent
        intent_instruction = f"""
        Analyze the question to determine its intent. Classify the task as one of the following:
        - Arithmetic operation (e.g., addition, subtraction, multiplication, division)
        - Counting (e.g., how many times, how many different)
        - Comparison (e.g., which is greater, who had more)
        - Span extraction (e.g., who did, what was the name of)
        - Other (specify).
        Use the extracted information: {extracted_info} to guide your analysis.
        """
        question_intent = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the interpreted intent
        reasoning_instruction = f"""
        Based on the extracted information: {extracted_info} and the question intent: {question_intent},
        perform the necessary reasoning to answer the question. Include all steps explicitly:
        - For arithmetic operations, show the calculation process.
        - For counting, list the items being counted.
        - For comparisons, provide the basis of comparison.
        - For span extraction, highlight the exact span with context.
        Ensure the reasoning is thorough and leaves no ambiguity.
        """
        reasoning_output = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the reasoning output
        refinement_instruction = f"""
        Critique the reasoning output: {reasoning_output}.
        Identify any errors, ambiguities, or omissions. Refine the output to ensure accuracy and alignment with the question's requirements.
        Provide a revised version of the reasoning output.
        """
        refined_output = await self.revise(instruction=refinement_instruction, context=reasoning_output)

        # Step 5: Finalize the answer
        summarization_instruction = f"""
        Condense the refined reasoning output: {refined_output} into a concise answer.
        Ensure the answer directly addresses the question and is presented in the required format (e.g., number, date, text span).
        """
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_output)

        return final_answer