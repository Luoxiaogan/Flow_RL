# Workflow ID: drop_250_0
# Benchmark: drop
# Data Indices: [376, 25]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Core problem-solving logic for DROP-style questions.
        """
        import asyncio

        # Step 1: Extract key information (parallelizable)
        extract_instruction = (
            "Extract all numerical values, entities, and relevant relationships from the passage and question. "
            "Include explicit and implicit information that could be relevant to answering the question."
        )
        analysis_instruction = (
            "Analyze the question to determine its intent. Identify whether the question requires arithmetic operations, "
            "counting, comparison, span extraction, or another type of reasoning. Provide a detailed breakdown of the reasoning steps."
        )
        extract_task = self.generate(instruction=extract_instruction, context=self.problem_text)
        analysis_task = self.generate(instruction=analysis_instruction, context=self.problem_text)
        extracted_info, question_analysis = await asyncio.gather(extract_task, analysis_task)

        # Step 2: Perform reasoning or calculation
        reasoning_instruction = (
            f"Given the extracted information: {extracted_info}\n"
            f"And the question analysis: {question_analysis}\n"
            "Perform the necessary reasoning or calculation to answer the question. Ensure all steps are clearly explained."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Validate and refine results
        refine_instruction = (
            "Critique and refine the following result to ensure accuracy, clarity, and completeness. "
            "Correct any errors or ambiguities and ensure the result directly addresses the question."
        )
        refined_result = await self.revise(instruction=refine_instruction, context=reasoning_result)

        # Step 4: Finalize answer
        summarize_instruction = (
            "Condense the following result into a concise, final answer. Ensure the answer is clear, precise, and directly responds to the question."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_result)

        return final_answer