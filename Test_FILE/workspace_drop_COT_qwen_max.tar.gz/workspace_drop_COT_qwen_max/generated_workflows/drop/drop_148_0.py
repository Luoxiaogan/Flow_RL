# Workflow ID: drop_148_0
# Benchmark: drop
# Data Indices: [776, 566]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract relevant information from the passage
        extraction_instruction = """
        Extract all relevant entities, numerical values, dates, and relationships from the passage.
        Include any information that could potentially answer the question.
        Format your response as a structured list of key-value pairs.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_intent_instruction = f"""
        Analyze the question to determine its intent. Specifically:
        - Identify whether the question requires arithmetic operations, counting, comparison, selection, or span extraction.
        - Provide a detailed explanation of the reasoning steps needed to answer the question.
        - Use the following extracted information as context: {extracted_info}.
        """
        question_intent = await self.generate(instruction=question_intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question intent
        reasoning_instruction = f"""
        Based on the identified question intent, perform the necessary reasoning steps to answer the question.
        Use the following extracted information: {extracted_info}.
        Follow the reasoning strategy outlined in the question intent analysis: {question_intent}.
        Ensure your response is clear, concise, and directly addresses the question.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine the answer
        refinement_instruction = f"""
        Critique and refine the following reasoning result: {reasoning_result}.
        Ensure the final answer is accurate, concise, and directly addresses the question.
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Handle ambiguities with Ensemble (if necessary)
        ambiguity_check_instruction = f"""
        Evaluate whether there are multiple plausible interpretations of the question or reasoning steps.
        If so, generate alternative reasoning paths and their corresponding answers.
        """
        ambiguity_check = await self.generate(instruction=ambiguity_check_instruction, context=self.problem_text)

        if "alternative" in ambiguity_check.lower():
            # Generate alternative reasoning paths in parallel
            alternatives = ambiguity_check.split("Alternative")[1:]  # Split into individual alternatives
            reasoning_tasks = [
                self.generate(instruction=f"Reason through the following path: {alt}", context=self.problem_text)
                for alt in alternatives
            ]
            alternative_results = await asyncio.gather(*reasoning_tasks)

            # Use Ensemble to select the best answer
            ensemble_instruction = """
            Evaluate the following candidate answers and select the most accurate and relevant one.
            """
            final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=alternative_results)
        else:
            final_answer = refined_answer

        return final_answer