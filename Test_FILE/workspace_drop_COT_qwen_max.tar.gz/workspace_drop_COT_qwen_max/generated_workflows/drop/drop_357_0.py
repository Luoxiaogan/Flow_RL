# Workflow ID: drop_357_0
# Benchmark: drop
# Data Indices: [494, 626]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Analyze the question to determine its type and intent
        question_analysis_instruction = (
            "Analyze the question to determine its type and intent. "
            "Identify whether the question requires arithmetic operations, counting, comparison, selection, or span extraction. "
            "Provide a clear classification and any relevant details about what needs to be extracted or calculated."
        )
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 2: Extract numerical values and associated entities
        extraction_instruction = (
            "Extract all numerical values and associated entities from the passage. "
            "Ensure each number is correctly linked to its corresponding entity or event. "
            "Format the output as a list of pairs: (entity, value)."
        )
        raw_extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 3: Refine the extraction for accuracy
        refinement_instruction = (
            f"Review the extracted data: {raw_extraction}. "
            "Ensure all numbers are accurately associated with their entities. "
            "Correct any errors or ambiguities in the associations."
        )
        refined_extraction = await self.revise(instruction=refinement_instruction, context=raw_extraction)

        # Step 4: Perform reasoning based on the question type
        reasoning_instruction_template = (
            "Based on the question analysis: {question_analysis}, and the refined extraction: {refined_extraction}, "
            "perform the required reasoning. If the question involves arithmetic, calculate the result. "
            "If it involves counting, count the occurrences. If it involves comparison, compare the relevant values. "
            "For span extraction, identify the exact text span that answers the question."
        )
        reasoning_instruction = reasoning_instruction_template.format(
            question_analysis=question_analysis,
            refined_extraction=refined_extraction
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 5: Synthesize the final answer
        synthesis_instruction = (
            f"Condense the reasoning result: {reasoning_result} into a concise final answer. "
            "Ensure the answer is in the correct format (number, date, text span, etc.) and directly addresses the question."
        )
        final_answer = await self.summarize(instruction=synthesis_instruction, context=reasoning_result)

        return final_answer