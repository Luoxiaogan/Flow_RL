# Workflow ID: drop_80_0
# Benchmark: drop
# Data Indices: [113, 401]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract key information from the passage and question
        extract_instruction = """
        Extract all relevant entities, numerical values, dates, and relationships from the passage and question. 
        Ensure you capture all occurrences of numbers, their associated entities, and any contextual clues about their relationships. 
        Pay special attention to ambiguous references and resolve them if possible. 
        Format the output as a structured summary.
        """
        extract_task = self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Clarify the intent of the question
        clarify_instruction = """
        Analyze the question to determine what type of reasoning or computation is required. 
        Identify whether the task involves arithmetic operations (addition, subtraction, etc.), counting, comparison, or span extraction. 
        Provide a clear explanation of the question's intent and how it relates to the extracted information.
        """
        clarify_task = self.generate(instruction=clarify_instruction, context=self.problem_text)

        # Run steps 1 and 2 in parallel
        extracted_data, clarified_intent = await asyncio.gather(extract_task, clarify_task)

        # Step 3: Perform reasoning/computation based on clarified intent
        reasoning_instruction = f"""
        Using the extracted data: {extracted_data}
        And the clarified intent: {clarified_intent}
        Perform the necessary reasoning or computation to answer the question. 
        If the task involves arithmetic, calculate the result. 
        If it involves comparison, compare the relevant entities or values. 
        If it requires span extraction, identify the specific text span that answers the question. 
        Provide a detailed explanation of your reasoning process.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine the answer
        refine_instruction = f"""
        Review the reasoning result: {reasoning_result}
        Ensure the answer is accurate, complete, and properly formatted. 
        Resolve any ambiguities or incorrect associations. 
        If necessary, revise the answer to better align with the question's intent.
        """
        refined_answer = await self.revise(instruction=refine_instruction, context=reasoning_result)

        # Step 5: Summarize the final answer
        summarize_instruction = f"""
        Condense the refined answer: {refined_answer}
        Into a concise, clear response that directly addresses the question. 
        Ensure the output is well-structured and easy to understand.
        """
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_answer)

        return final_answer