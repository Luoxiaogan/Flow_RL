# Workflow ID: drop_369_0
# Benchmark: drop
# Data Indices: [627, 299]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all relevant information (entities, numbers, key phrases)
        extract_instruction = (
            "Extract all numerical values, entity names (e.g., teams, players), and key phrases "
            "from the passage. Organize them clearly, associating numbers with their respective entities."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Analyze the question intent
        analyze_instruction = (
            "Determine what the question is asking for. Identify if it requires arithmetic operations "
            "(e.g., sum, difference), counting, comparison, or span extraction. Specify the expected answer type."
        )
        question_intent = await self.generate(instruction=analyze_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question intent
        reasoning_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            f"and the question intent: {question_intent}\n"
            "Perform the necessary reasoning to arrive at the answer. If the question involves arithmetic, "
            "show the calculation steps. If it involves comparison, evaluate all candidates. If it requires "
            "span extraction, identify the correct entity or phrase."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine the answer
        refine_instruction = (
            "Critique and improve the following answer to ensure it is accurate, concise, and properly formatted. "
            "Ensure it aligns with the question intent and uses the correct terminology."
        )
        refined_answer = await self.revise(instruction=refine_instruction, context=reasoning_result)

        return refined_answer