# Workflow ID: drop_136_0
# Benchmark: drop
# Data Indices: [200, 695]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all relevant information from the passage and question
        extraction_instruction = (
            "Extract all numerical values, entities, and relationships from the passage and question. "
            "Identify which numbers are associated with which entities and provide a structured summary."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question type and reasoning requirements
        question_analysis_instruction = (
            f"Given the following extracted information: {extracted_info}\n"
            "Determine the type of reasoning required to answer the question (e.g., arithmetic, comparison, span extraction). "
            "Provide a detailed breakdown of the steps needed to solve the problem."
        )
        reasoning_plan = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform parallel reasoning based on the question type
        reasoning_tasks = []
        if "arithmetic" in reasoning_plan.lower():
            # Parallel computation for arithmetic operations
            sum_instruction = (
                f"Using the extracted information: {extracted_info}\n"
                "Compute the sum of all relevant numerical values."
            )
            difference_instruction = (
                f"Using the extracted information: {extracted_info}\n"
                "Compute the difference between relevant numerical values."
            )
            reasoning_tasks.append(self.generate(instruction=sum_instruction, context=self.problem_text))
            reasoning_tasks.append(self.generate(instruction=difference_instruction, context=self.problem_text))
        elif "comparison" in reasoning_plan.lower():
            # Parallel evaluation for comparison questions
            compare_instruction_1 = (
                f"Using the extracted information: {extracted_info}\n"
                "Compare the first entity's value with the second entity's value."
            )
            compare_instruction_2 = (
                f"Using the extracted information: {extracted_info}\n"
                "Compare the second entity's value with the first entity's value."
            )
            reasoning_tasks.append(self.generate(instruction=compare_instruction_1, context=self.problem_text))
            reasoning_tasks.append(self.generate(instruction=compare_instruction_2, context=self.problem_text))
        else:
            # Default span extraction
            span_instruction = (
                f"Using the extracted information: {extracted_info}\n"
                "Identify the exact text span that answers the question."
            )
            reasoning_tasks.append(self.generate(instruction=span_instruction, context=self.problem_text))

        # Execute parallel reasoning tasks
        reasoning_results = await asyncio.gather(*reasoning_tasks)

        # Step 4: Ensemble decision to synthesize the best answer
        ensemble_instruction = (
            "Evaluate the following candidate solutions and select the most accurate and consistent answer. "
            "Provide a justification for your choice."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=reasoning_results)

        # Step 5: Refine the final answer
        refinement_instruction = (
            "Refine the following answer to ensure it is concise, accurate, and properly formatted. "
            "Correct any errors or ambiguities."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        return refined_answer