# Workflow ID: drop_4_0
# Benchmark: drop
# Data Indices: [313, 196]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information from the passage
        extraction_instruction = """
        Extract all relevant entities, numerical values, dates, and relationships from the passage. 
        Ensure you capture:
        - All numbers and their associated entities or contexts.
        - All named entities (people, places, organizations).
        - Relationships between entities (e.g., who did what, when, and where).
        Format your output as a structured list for clarity.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Parse the question to determine its intent
        question_instruction = f"""
        Analyze the question and determine its intent. Classify the question into one of the following categories:
        - Arithmetic: Requires addition, subtraction, multiplication, or division.
        - Comparison: Requires comparing two values or entities.
        - Selection: Requires selecting an entity or span from the passage.
        - Span Extraction: Requires extracting a specific phrase or sentence from the passage.
        Provide a clear explanation of the question's intent and any specific constraints.
        Extracted Information: {extracted_info}
        """
        question_intent = await self.generate(instruction=question_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or calculation based on the question's intent
        reasoning_instruction = f"""
        Based on the question's intent, perform the required reasoning or calculation. Use the extracted information to guide your reasoning.
        Question Intent: {question_intent}
        Extracted Information: {extracted_info}
        Ensure your reasoning is step-by-step and transparent.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the result
        refinement_instruction = f"""
        Critique the reasoning result and refine it if necessary. Ensure:
        - All calculations are accurate.
        - All comparisons are valid.
        - All selections or extractions are correct.
        Provide a revised version of the result if needed.
        Reasoning Result: {reasoning_result}
        """
        refined_result = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Summarize the final answer
        summary_instruction = f"""
        Condense the refined result into a concise final answer. Ensure the answer directly addresses the question and is easy to understand.
        Refined Result: {refined_result}
        """
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_result)

        return final_answer