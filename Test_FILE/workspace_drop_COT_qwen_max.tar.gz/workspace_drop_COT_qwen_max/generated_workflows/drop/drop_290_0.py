# Workflow ID: drop_290_0
# Benchmark: drop
# Data Indices: [257, 115]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant entities, numerical values, and relationships
        extraction_instruction = (
            "Extract all entities, numerical values, and their relationships from the passage and question. "
            "Ensure you capture every detail that might be relevant for answering the question."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Determine the type of reasoning required
        reasoning_instruction = (
            f"Based on the extracted information: {extracted_info}, analyze the question to determine the type of reasoning required. "
            "Identify whether the question involves arithmetic operations, counting, comparison, selection, or span extraction. "
            "Provide a detailed explanation of your reasoning."
        )
        reasoning_type = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Perform parallel reasoning based on the identified type
        if "arithmetic" in reasoning_type or "counting" in reasoning_type:
            # Parallel computation of potential answers
            calc_instruction_1 = (
                f"Using the extracted information: {extracted_info}, perform a direct calculation to answer the question. "
                "Show all steps clearly."
            )
            calc_instruction_2 = (
                f"Using the extracted information: {extracted_info}, infer the answer indirectly by analyzing relationships and context. "
                "Show all steps clearly."
            )
            results = await asyncio.gather(
                self.generate(instruction=calc_instruction_1, context=self.problem_text),
                self.generate(instruction=calc_instruction_2, context=self.problem_text)
            )
            # Ensemble to decide the best answer
            ensemble_instruction = (
                "Compare the two candidate answers provided. Evaluate their accuracy, consistency with the context, "
                "and alignment with the question's intent. Select the best answer and explain your reasoning."
            )
            final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=results)
        else:
            # Handle comparison, selection, or span extraction
            selection_instruction = (
                f"Using the extracted information: {extracted_info}, identify the correct answer by comparing options or extracting the relevant span. "
                "Ensure the answer is precise and well-supported by the context."
            )
            final_answer = await self.generate(instruction=selection_instruction, context=self.problem_text)

        # Step 4: Validate and refine the answer
        refinement_instruction = (
            f"Review the computed answer: {final_answer}. Critique its accuracy, completeness, and alignment with the question's intent. "
            "Refine the answer if necessary and provide a detailed explanation of any changes."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        # Step 5: Summarize the final output
        summary_instruction = (
            f"Condense the reasoning and present the final answer in a clear and concise format. "
            "Ensure the output is easy to understand and directly addresses the question."
        )
        final_output = await self.summarize(instruction=summary_instruction, context=refined_answer)

        return final_output