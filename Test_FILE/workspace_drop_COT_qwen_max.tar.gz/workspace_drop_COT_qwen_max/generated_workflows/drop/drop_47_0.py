# Workflow ID: drop_47_0
# Benchmark: drop
# Data Indices: [410, 556]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information (entities, numbers, relationships)
        extract_instruction = """
        Analyze the provided passage and question thoroughly. Identify and extract all relevant entities, numbers, and their relationships. 
        Specifically, focus on numerical values, entities (e.g., teams, people, locations), and any contextual information that connects them. 
        Format the output clearly, grouping related information together.
        """
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Understand the question's intent
        intent_instruction = f"""
        Given the extracted information: {extracted_info}, analyze the question to determine its intent. 
        Identify whether the question requires arithmetic operations (e.g., addition, subtraction), comparisons, counting, span extraction, or other reasoning types. 
        Provide a clear breakdown of the reasoning steps needed to answer the question.
        """
        question_intent = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning (parallel execution for multiple paths)
        reasoning_instruction = f"""
        Using the extracted information: {extracted_info} and the identified question intent: {question_intent}, perform the necessary reasoning steps. 
        For arithmetic operations, calculate the result step by step. For comparisons, compare the relevant entities or values. 
        For span extraction, identify the exact text span that answers the question. Ensure all steps are clearly documented.
        """
        reasoning_results = await asyncio.gather(
            self.generate(instruction=reasoning_instruction, context=self.problem_text),
            self.generate(instruction=reasoning_instruction, context=self.problem_text)  # Optional second path
        )

        # Step 4: Synthesize the final answer
        ensemble_instruction = f"""
        Evaluate the reasoning results: {reasoning_results}. Select the most accurate and complete answer based on the question's requirements. 
        If there are discrepancies, resolve them by prioritizing the result that aligns best with the extracted information and question intent.
        """
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=reasoning_results)

        # Step 5 (Optional): Refine the final answer
        refine_instruction = f"""
        Review the final answer: {final_answer}. Ensure it is clear, concise, and directly addresses the question. 
        Make any necessary improvements to enhance readability or correctness.
        """
        refined_answer = await self.revise(instruction=refine_instruction, context=final_answer)

        return refined_answer