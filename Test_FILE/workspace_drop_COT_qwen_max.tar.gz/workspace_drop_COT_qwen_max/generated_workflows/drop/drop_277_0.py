# Workflow ID: drop_277_0
# Benchmark: drop
# Data Indices: [700, 395]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Analyze the question to determine the reasoning type and extract key entities
        question_analysis_instruction = (
            "Analyze the question to determine the type of reasoning required (e.g., arithmetic, counting, comparison, span extraction). "
            "Identify and extract all relevant entities, numerical values, and relationships mentioned in the question. "
            "Provide a structured summary of the findings."
        )
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 2: Extract relevant information from the passage
        extraction_instruction = (
            f"Based on the following question analysis: {question_analysis}\n"
            "Extract all relevant information from the passage that could contribute to answering the question. "
            "Include numerical values, dates, spans, and contextual relationships. "
            "Organize the extracted information clearly."
        )
        passage_extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or calculation based on the extracted information
        reasoning_instruction = (
            f"Using the extracted information: {passage_extraction}\n"
            "Perform the necessary reasoning or calculation to answer the question. "
            "If the question involves arithmetic, compute the result step by step. "
            "If it involves span extraction, identify the correct span. "
            "Provide a clear and concise answer."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the answer
        refinement_instruction = (
            f"Review the following reasoning result: {reasoning_result}\n"
            "Cross-check it against the passage to ensure accuracy. "
            "Refine the answer if needed, addressing any ambiguities or implicit information."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=self.problem_text)

        # Step 5: Synthesize the final answer
        final_synthesis_instruction = (
            f"Combine the refined answer: {refined_answer}\n"
            "with the earlier extracted information and reasoning steps. "
            "Produce a final, coherent answer that directly addresses the question."
        )
        final_answer = await self.generate(instruction=final_synthesis_instruction, context=self.problem_text)

        return final_answer