# Workflow ID: drop_374_0
# Benchmark: drop
# Data Indices: [706, 151]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant numerical values, entities, and their relationships
        extraction_instruction = """
        Extract all numerical values, entities, and their relationships from the passage. 
        Identify any mentions of scores, counts, measurements, dates, or other quantitative data. 
        Associate each number with its corresponding entity or event. 
        Provide the output in a structured format.
        """
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_analysis_instruction = f"""
        Analyze the question to determine its intent. 
        Identify whether the question requires arithmetic operations (addition, subtraction, etc.), counting, comparison, selection, or span extraction. 
        Based on the following extracted information: {extraction}
        Provide a clear explanation of the question's intent and the type of reasoning required.
        """
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Create parallel reasoning paths
        arithmetic_instruction = f"""
        If the question involves arithmetic operations, perform the necessary calculations using the extracted information: {extraction}.
        Ensure all calculations are accurate and explain each step clearly.
        """
        counting_instruction = f"""
        If the question involves counting, count the relevant occurrences based on the extracted information: {extraction}.
        Ensure no instances are missed and explain the counting process.
        """
        comparison_instruction = f"""
        If the question involves comparison, compare the relevant entities or values based on the extracted information: {extraction}.
        Clearly state which entity or value is greater, lesser, or equal.
        """
        selection_instruction = f"""
        If the question involves selection, select the appropriate entity or value based on the extracted information: {extraction}.
        Explain why the selected entity or value is correct.
        """
        span_extraction_instruction = f"""
        If the question involves span extraction, extract the relevant text span based on the extracted information: {extraction}.
        Ensure the span directly answers the question.
        """

        # Run parallel reasoning paths
        results = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=counting_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text),
            self.generate(instruction=selection_instruction, context=self.problem_text),
            self.generate(instruction=span_extraction_instruction, context=self.problem_text)
        )

        # Step 4: Ensemble decision to select the best answer
        ensemble_instruction = f"""
        Evaluate the following reasoning paths and select the most accurate and relevant answer based on the question's intent: {question_analysis}.
        Reasoning paths:
        - Arithmetic: {results[0]}
        - Counting: {results[1]}
        - Comparison: {results[2]}
        - Selection: {results[3]}
        - Span Extraction: {results[4]}
        Provide the final answer and explain why it was chosen.
        """
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 5: Refine the final answer
        refinement_instruction = f"""
        Refine the following answer to ensure it is concise, accurate, and directly addresses the question: {final_answer}.
        Remove any unnecessary details while preserving the core information.
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        return refined_answer