# Workflow ID: drop_0_0
# Benchmark: drop
# Data Indices: [730, 304]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract all relevant entities, numbers, dates, and relationships
        extraction_instruction = (
            "Extract all entities, numbers, dates, and relationships mentioned in the passage. "
            "Include details about how entities are related to numbers or events. "
            "Provide this information in a structured format."
        )
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Identify the intent of the question
        intent_instruction = (
            "Analyze the question and determine its intent. "
            "The intent could be one of the following: arithmetic operation (addition, subtraction, etc.), "
            "counting, comparison, selection, or span extraction. "
            "Provide a clear explanation of the intent and what needs to be done to answer the question."
        )
        intent = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Execute reasoning based on the identified intent
        reasoning_instruction_template = (
            "Based on the identified intent ({intent}), perform the necessary reasoning to answer the question. "
            "Use the extracted information: {extraction}. "
            "If the intent involves arithmetic, perform the calculation step by step. "
            "If it involves comparison, evaluate all relevant options. "
            "If it involves span extraction, isolate the exact text span that answers the question. "
            "Provide a clear and detailed reasoning process."
        )
        reasoning_instruction = reasoning_instruction_template.format(intent=intent, extraction=extraction)
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the result
        refinement_instruction = (
            "Critique the reasoning result and refine it if necessary. "
            "Ensure the answer aligns with the passage and question. "
            "Correct any errors or ambiguities in the reasoning process."
        )
        refined_result = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Summarize the final answer
        summary_instruction = (
            "Condense the refined result into a concise and clear final answer. "
            "Ensure the answer directly addresses the question and is easy to understand."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_result)

        return final_answer