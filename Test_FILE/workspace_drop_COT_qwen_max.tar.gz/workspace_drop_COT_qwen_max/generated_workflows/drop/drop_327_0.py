# Workflow ID: drop_327_0
# Benchmark: drop
# Data Indices: [557, 713]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all relevant information from the passage
        extraction_instruction = """
        Extract all numerical values, entities, and their relationships from the passage. 
        Include explicit and implicit information, such as counts, dates, names, and actions. 
        Format the output as a structured list for easy reference.
        """
        extraction_task = self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its type and intent
        question_analysis_instruction = """
        Analyze the question to determine its type (e.g., arithmetic, counting, comparison, span extraction). 
        Identify the specific entities, values, or spans involved in the question. 
        Provide a clear breakdown of what needs to be calculated, counted, or compared.
        """
        question_analysis_task = self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Run extraction and question analysis in parallel
        extraction, question_analysis = await asyncio.gather(extraction_task, question_analysis_task)

        # Step 3: Perform reasoning or calculation based on the question type
        reasoning_instruction = f"""
        Using the extracted information: {extraction}
        And the question analysis: {question_analysis}
        Perform the necessary reasoning or calculation to answer the question. 
        If the question involves arithmetic, compute the result step by step. 
        If it involves counting, count the relevant occurrences accurately. 
        If it involves comparison, compare the specified values or spans. 
        Ensure the reasoning process is clear and logical.
        """
        reasoning = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the reasoning output
        refinement_instruction = """
        Review the reasoning output for accuracy and completeness. 
        Correct any errors, resolve ambiguities, and ensure the result aligns with the question's intent. 
        If necessary, re-examine the extracted information or adjust the calculations.
        """
        refined_reasoning = await self.revise(instruction=refinement_instruction, context=reasoning)

        # Step 5: Summarize the final answer
        summarization_instruction = """
        Condense the refined reasoning into a concise and coherent final answer. 
        Ensure the answer directly addresses the question and includes all necessary details.
        """
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_reasoning)

        return final_answer