# Workflow ID: drop_86_0
# Benchmark: drop
# Data Indices: [630, 751]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information (entities, numbers, relationships)
        extraction_instruction = (
            "Carefully analyze the passage and question to extract ALL relevant entities, numerical values, "
            "and their relationships. Include explicit mentions and any implicit information that can be inferred. "
            "Format the output as a structured list of key-value pairs where keys are entities or events, "
            "and values are associated numbers or descriptions."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Interpret the question's intent
        intent_instruction = (
            "Analyze the question to determine its intent. Identify whether the task involves "
            "arithmetic operations (e.g., addition, subtraction), comparison (e.g., greater than, less than), "
            "counting, or span extraction. Provide a clear explanation of the reasoning steps required to answer "
            "the question based on the extracted information."
        )
        question_intent = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question type
        reasoning_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            f"And the question intent: {question_intent}\n"
            "Perform the necessary reasoning steps to compute the answer. If the task involves arithmetic, "
            "show the calculation explicitly. If it involves comparison, evaluate the conditions and provide "
            "the result. For span extraction, identify the exact text from the passage that answers the question."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine the computed answer
        refinement_instruction = (
            f"Review the reasoning result: {reasoning_result}\n"
            "Ensure the answer is accurate, complete, and directly addresses the question. Correct any errors, "
            "clarify ambiguous points, and format the final answer appropriately."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Summarize the reasoning process (optional, for validation)
        summary_instruction = (
            "Summarize the entire reasoning process, including the extracted information, question intent, "
            "and the steps taken to arrive at the final answer. Ensure the summary is concise but comprehensive."
        )
        reasoning_summary = await self.summarize(instruction=summary_instruction, context=self.problem_text)

        # Return the final answer
        return refined_answer