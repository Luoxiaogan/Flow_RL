# Workflow ID: drop_336_0
# Benchmark: drop
# Data Indices: [293, 599]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant entities, numbers, and relationships
        extract_instruction = (
            "Thoroughly analyze the passage and extract all entities, numerical values, dates, and their relationships. "
            "Ensure no relevant information is missed. Format the output clearly, grouping related information together."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its type and intent
        question_analysis_instruction = (
            "Carefully analyze the question to determine its type (e.g., arithmetic, counting, comparison, span extraction) "
            "and intent. Provide a detailed breakdown of what is being asked and how it relates to the passage."
        )
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or calculations based on the question type
        reasoning_instruction = (
            f"Using the extracted information: {extracted_info} and the question analysis: {question_analysis}, "
            "perform the necessary reasoning or calculations to answer the question. Ensure all steps are clearly explained."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the candidate answer
        validation_instruction = (
            "Validate the reasoning result against the passage and question. Identify any discrepancies or ambiguities. "
            "Refine the answer if necessary to ensure accuracy and completeness."
        )
        refined_answer = await self.revise(instruction=validation_instruction, context=reasoning_result)

        # Step 5: Compile the final answer
        final_answer_instruction = (
            "Compile the final answer in the required format (number, date, text span, etc.). Ensure the answer is concise "
            "and directly addresses the question."
        )
        final_answer = await self.summarize(instruction=final_answer_instruction, context=refined_answer)

        return final_answer