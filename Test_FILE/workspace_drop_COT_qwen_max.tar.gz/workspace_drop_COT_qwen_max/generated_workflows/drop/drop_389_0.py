# Workflow ID: drop_389_0
# Benchmark: drop
# Data Indices: [574, 653]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Initial Extraction
        extraction_instruction = (
            "Carefully analyze the passage and question. Extract all entities, numerical values, "
            "temporal references, and relationships between them. Organize the information clearly, "
            "ensuring no details are missed. Focus on the question's intent to guide the extraction."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Refinement and Association
        refinement_instruction = (
            f"Refine the following extracted information: {extracted_info}. Ensure correct "
            "association between entities and their corresponding values or spans. Resolve any "
            "ambiguities or partial references by leveraging context from the passage."
        )
        refined_info = await self.revise(instruction=refinement_instruction, context=extracted_info)

        # Step 3: Reasoning and Calculation
        reasoning_instruction = (
            f"Based on the refined information: {refined_info}, determine the question's intent "
            "(e.g., arithmetic operation, comparison, span extraction). Perform the required "
            "reasoning or calculation step-by-step. Ensure all intermediate steps are clear and logical."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=refined_info)

        # Optional Parallel Paths for Validation
        validation_instruction_1 = (
            f"Validate the reasoning result: {reasoning_result} by cross-checking with the original passage. "
            "Ensure all calculations or extractions are accurate and consistent with the context."
        )
        validation_instruction_2 = (
            f"Provide an alternative reasoning path for the result: {reasoning_result}. "
            "Re-evaluate the extracted information and perform the reasoning again independently."
        )
        validation_results = await asyncio.gather(
            self.generate(instruction=validation_instruction_1, context=reasoning_result),
            self.generate(instruction=validation_instruction_2, context=reasoning_result)
        )

        # Step 4: Ensemble Decision
        ensemble_instruction = (
            f"Compare the following reasoning results: {validation_results}. Select the most accurate "
            "and consistent result based on the passage and question. Provide a final answer with justification."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=validation_results)

        return final_answer