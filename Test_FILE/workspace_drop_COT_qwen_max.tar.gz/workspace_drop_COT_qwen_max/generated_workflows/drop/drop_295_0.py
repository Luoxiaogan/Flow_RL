# Workflow ID: drop_295_0
# Benchmark: drop
# Data Indices: [235, 202]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant entities, numbers, and relationships
        extraction_instruction = (
            "Carefully analyze the passage and question. "
            "Extract all relevant entities, numerical values, and relationships. "
            "Focus on identifying: "
            "- Named entities (people, teams, groups, etc.) "
            "- Numerical values and their associated contexts "
            "- Relationships between entities and numbers "
            "Format the output as a structured list for clarity."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Perform reasoning based on the extracted information
        reasoning_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "determine the correct answer to the question. "
            "Follow these guidelines: "
            "- For counting questions, count the occurrences of the specified entity or condition. "
            "- For arithmetic questions, perform the required calculations using the extracted numbers. "
            "- For comparison questions, evaluate which entity satisfies the condition. "
            "- For span extraction, identify the exact text span that answers the question. "
            "Provide a clear and concise answer with justification."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Validate the reasoning result
        validation_instruction = (
            f"Review the reasoning result: {reasoning_result}. "
            "Critique its accuracy and alignment with the question intent. "
            "Ensure the answer correctly addresses the question and is supported by the passage. "
            "If necessary, suggest refinements or corrections."
        )
        validated_result = await self.revise(instruction=validation_instruction, context=reasoning_result)

        # Step 4: Handle ambiguity or multiple reasoning paths if needed
        # Check if there are multiple plausible answers
        ensemble_instruction = (
            f"Evaluate the following options: {reasoning_result} and {validated_result}. "
            "Decide on the best answer based on accuracy, completeness, and alignment with the question. "
            "Synthesize the final answer if needed."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[reasoning_result, validated_result])

        return final_answer