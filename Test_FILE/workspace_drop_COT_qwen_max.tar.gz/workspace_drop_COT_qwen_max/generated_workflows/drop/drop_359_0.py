# Workflow ID: drop_359_0
# Benchmark: drop
# Data Indices: [219, 274]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Analyze the question to understand its intent
        question_analysis = await self.generate(
            instruction="Analyze the question to determine its type and reasoning requirements. "
                        "Identify whether the question involves counting, arithmetic operations, span extraction, "
                        "comparison, or another reasoning task. Provide a detailed breakdown of the question's intent.",
            context=self.problem_text
        )

        # Step 2: Extract relevant information from the passage
        info_extraction = await self.generate(
            instruction=f"Based on the following question analysis: {question_analysis}, "
                        "extract all relevant entities, numbers, and contextual details from the passage. "
                        "Ensure that no potentially relevant information is missed.",
            context=self.problem_text
        )

        # Step 3: Perform reasoning based on the extracted information
        reasoning_result = await self.generate(
            instruction=f"Using the extracted information: {info_extraction}, "
                        f"and the question analysis: {question_analysis}, "
                        "perform the necessary reasoning to answer the question. "
                        "This may involve counting occurrences, performing arithmetic operations, "
                        "extracting a specific text span, or comparing values. "
                        "Provide a clear and concise answer.",
            context=self.problem_text
        )

        # Step 4: Validate and refine the answer
        refined_answer = await self.revise(
            instruction="Critique and refine the following answer to ensure it accurately addresses the question's intent "
                        "and aligns with the passage's context. Correct any ambiguities, errors, or inconsistencies.",
            context=reasoning_result
        )

        # Step 5: Synthesize final output (optional ensemble step if multiple candidates exist)
        final_answer = await self.ensemble(
            instruction="Evaluate the following candidate answers and select the best one based on coherence, "
                        "relevance, and alignment with the question's intent.",
            contexts=[reasoning_result, refined_answer]
        )

        return final_answer