# Workflow ID: drop_393_0
# Benchmark: drop
# Data Indices: [618, 283]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information from the passage
        extract_instruction = (
            "Thoroughly extract all numerical values, entities, and relationships from the passage. "
            "Include explicit associations between numbers and their respective entities. "
            "Pay attention to implicit or ambiguous references and resolve them using context."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Understand the question intent
        intent_instruction = (
            f"Given the extracted information: {extracted_info}\n"
            "Analyze the question to determine the required reasoning type. "
            "Identify whether the task involves arithmetic operations (e.g., addition, subtraction), counting, comparison, or span extraction. "
            "Provide clear guidance on how to proceed based on the detected reasoning pattern."
        )
        question_intent = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the detected intent
        reasoning_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            f"And the identified reasoning type: {question_intent}\n"
            "Perform the necessary calculations or logical reasoning to derive the answer. "
            "Ensure that all numbers are correctly associated with their entities and that the reasoning process is step-by-step."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine and validate the output
        refine_instruction = (
            f"Review the reasoning result: {reasoning_result}\n"
            "Critique and refine the answer to ensure it aligns with the question intent and extracted information. "
            "Correct any errors or ambiguities in the reasoning process."
        )
        refined_output = await self.revise(instruction=refine_instruction, context=reasoning_result)

        # Step 5: Finalize the answer
        summarize_instruction = (
            f"Condense the refined output: {refined_output}\n"
            "Provide a concise, final answer that directly addresses the question."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_output)

        return final_answer