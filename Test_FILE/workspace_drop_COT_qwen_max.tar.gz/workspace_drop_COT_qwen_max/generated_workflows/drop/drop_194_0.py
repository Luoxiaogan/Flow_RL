# Workflow ID: drop_194_0
# Benchmark: drop
# Data Indices: [576, 247]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract relevant information
        extraction_instruction = (
            "Given the passage and the question, extract all relevant entities, numerical values, "
            "and relationships. Focus on identifying entities mentioned in the question and their "
            "associated data. Include any implicit or contextual information that might be relevant."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze and associate entities
        analysis_instruction = (
            f"Based on the extracted information: {extracted_info}, analyze and associate entities "
            "with their corresponding numerical values or spans. Resolve any ambiguous references "
            "and ensure correct entity-number pairing."
        )
        analyzed_info = await self.generate(instruction=analysis_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or calculation
        reasoning_instruction = (
            f"Using the analyzed information: {analyzed_info}, perform the required reasoning or calculation "
            "to answer the question. Follow the question's intent (e.g., arithmetic, counting, comparison) "
            "and provide a clear, step-by-step solution."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the answer
        refinement_instruction = (
            f"Critique and refine the following answer: {reasoning_result}. Ensure it aligns with the "
            "question's intent and the passage's context. Correct any errors or inconsistencies."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Handle ambiguities or multiple candidates (if needed)
        ambiguity_check_instruction = (
            f"Check if the refined answer: {refined_answer} contains any ambiguities or multiple candidates. "
            "If so, generate alternative interpretations or solutions."
        )
        ambiguity_check = await self.generate(instruction=ambiguity_check_instruction, context=self.problem_text)

        if "multiple" in ambiguity_check.lower():
            alternatives = ambiguity_check.split("\n")  # Assuming alternatives are separated by newlines
            ensemble_instruction = (
                f"Evaluate and synthesize the best response from the following candidates: {alternatives}. "
                "Consider the question's intent and the passage's context."
            )
            final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=alternatives)
        else:
            final_answer = refined_answer

        return final_answer