# Workflow ID: drop_39_0
# Benchmark: drop
# Data Indices: [473, 355]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all relevant information from the passage
        extract_instruction = """
        Extract ALL numerical values, dates, entities, and their relationships from the passage.
        Organize them into categories: numbers, entities, events, and relationships.
        Ensure no information is missed, as this will form the basis for reasoning.
        """
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Identify the question type and reasoning pattern
        question_type_instruction = f"""
        Analyze the question to determine its type and reasoning requirements.
        Possible types include: arithmetic operations (addition, subtraction, etc.), counting, comparison, selection, and span extraction.
        Based on the extracted information: {extracted_info}, map the question to the appropriate reasoning pattern.
        """
        reasoning_pattern = await self.generate(instruction=question_type_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the identified pattern
        reasoning_instruction = f"""
        Using the extracted information: {extracted_info} and the reasoning pattern: {reasoning_pattern},
        perform the necessary calculations, counts, comparisons, or selections.
        Ensure the reasoning process is step-by-step and transparent.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the result
        validation_instruction = f"""
        Critique the reasoning result: {reasoning_result}.
        Ensure it accurately addresses the question and aligns with the extracted information: {extracted_info}.
        Refine any ambiguities or errors in the reasoning process.
        """
        refined_result = await self.revise(instruction=validation_instruction, context=reasoning_result)

        # Step 5: Summarize the final answer
        summary_instruction = """
        Condense the refined result into a concise, clear answer that directly addresses the question.
        Ensure the format matches the expected answer type (number, date, text span, etc.).
        """
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_result)

        return final_answer