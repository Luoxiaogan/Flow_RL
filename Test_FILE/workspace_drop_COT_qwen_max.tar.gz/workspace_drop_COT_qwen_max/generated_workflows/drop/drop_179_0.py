# Workflow ID: drop_179_0
# Benchmark: drop
# Data Indices: [117, 7]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information from the passage
        extraction_instruction = (
            "Extract all entities, numerical values, dates, and their relationships from the passage. "
            "Include any implicit information that can be inferred from the context. "
            "Format the output as a structured list of key-value pairs where keys are entities or concepts, "
            "and values are associated details."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its type and intent
        question_analysis_instruction = (
            f"Given the extracted information: {extracted_info}, analyze the question to determine its type "
            "(e.g., arithmetic, counting, comparison, span extraction) and intent. "
            "Identify the specific entities, numbers, or spans involved in the question. "
            "Provide a clear breakdown of what needs to be calculated or extracted."
        )
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform reasoning and calculations
        reasoning_instruction = (
            f"Based on the question analysis: {question_analysis}, perform the necessary reasoning or calculations. "
            "If the question involves arithmetic operations, show the step-by-step computation. "
            "If it involves counting, list all relevant occurrences. "
            "If it involves comparison, clearly state the values being compared and the result. "
            "Ensure the output is precise and directly answers the question."
        )
        reasoning_results = await asyncio.gather(
            self.generate(instruction=reasoning_instruction, context=self.problem_text),
            self.generate(instruction=reasoning_instruction, context=self.problem_text)  # Parallel reasoning paths
        )

        # Step 4: Ensemble to select or synthesize the best result
        ensemble_instruction = (
            "Evaluate the following reasoning results and select the most accurate and coherent answer. "
            "If both results are valid, synthesize them into a single refined answer. "
            "Ensure the final output aligns with the question's intent and is supported by the extracted information."
        )
        final_reasoning = await self.ensemble(instruction=ensemble_instruction, contexts=reasoning_results)

        # Step 5: Validate and refine the answer
        refinement_instruction = (
            f"Critique the following answer: {final_reasoning}. Ensure it is accurate, coherent, and fully "
            "addresses the question. If necessary, revise the answer to improve clarity or correctness."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_reasoning)

        # Step 6: Compile the final answer
        compilation_instruction = (
            f"Condense the refined answer: {refined_answer} into a concise and clear final response. "
            "Ensure the format matches the expected answer type (number, text span, etc.)."
        )
        final_answer = await self.summarize(instruction=compilation_instruction, context=refined_answer)

        return final_answer