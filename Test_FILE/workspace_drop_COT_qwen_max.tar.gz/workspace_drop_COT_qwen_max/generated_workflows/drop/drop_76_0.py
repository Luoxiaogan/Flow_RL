# Workflow ID: drop_76_0
# Benchmark: drop
# Data Indices: [649, 500]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the passage
        extraction_instruction = """
        Extract all entities, numerical values, and relationships mentioned in the passage. 
        Include timestamps, scores, distances, and any other relevant data. 
        Organize the information clearly and label each piece of data with its context.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Understand the question intent
        question_intent_instruction = f"""
        Analyze the question and determine what type of reasoning is required. 
        Identify whether the question involves arithmetic operations, comparisons, span extraction, or other reasoning patterns. 
        Map the question to the extracted information: {extracted_info}. 
        Provide a clear plan for solving the question.
        """
        reasoning_plan = await self.generate(instruction=question_intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or calculation
        reasoning_instruction = f"""
        Based on the reasoning plan: {reasoning_plan}, perform the necessary calculations or reasoning steps. 
        Use the extracted information: {extracted_info} to derive the answer. 
        Ensure the reasoning process is step-by-step and explicitly justified.
        """
        preliminary_answer = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the answer
        refinement_instruction = f"""
        Critique the preliminary answer: {preliminary_answer}. 
        Check for accuracy, consistency with the passage, and alignment with the question intent. 
        Refine the answer if necessary, providing a clear explanation for any changes.
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=preliminary_answer)

        # Step 5: Handle ambiguities and edge cases (if necessary)
        # Use Ensemble to decide between multiple candidate answers or resolve ambiguities
        ensemble_instruction = f"""
        Evaluate the refined answer: {refined_answer} against the passage and question. 
        If there are multiple possible answers or ambiguities, synthesize the best response. 
        Ensure the final answer is unambiguous and fully supported by the passage.
        """
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[refined_answer, self.problem_text])

        # Step 6: Output the final answer
        return final_answer