# Workflow ID: drop_298_0
# Benchmark: drop
# Data Indices: [572, 758]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Initial Extraction
        extraction_instruction = (
            "Extract all relevant information from the passage and question. "
            "Identify entities, numerical values, relationships, and any implicit or explicit constraints. "
            "Focus on details that could help answer the question."
        )
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Question Analysis (Parallelizable with Step 1)
        question_analysis_instruction = (
            "Analyze the question to determine its type and intent. "
            "Classify the question as one of the following: arithmetic, counting, comparison, selection, or span extraction. "
            "Provide reasoning for the classification."
        )
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Combine results from Step 1 and Step 2 for further processing
        combined_context = f"Extracted Information:\n{extraction}\n\nQuestion Analysis:\n{question_analysis}"

        # Step 3: Reasoning and Calculation
        reasoning_instruction = (
            f"Based on the extracted information and question analysis:\n{combined_context}\n"
            "Perform the necessary reasoning or calculation to answer the question. "
            "For arithmetic questions, compute the required operation. "
            "For counting questions, count the relevant occurrences. "
            "For comparison questions, compare the specified attributes. "
            "For selection questions, identify the correct entity or event. "
            "For span extraction questions, extract the exact text span."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validation and Refinement
        refinement_instruction = (
            f"Validate and refine the following answer:\n{reasoning_result}\n"
            "Ensure all relevant information is considered, and there are no logical errors. "
            "Improve clarity and correctness if needed."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Final Answer
        summarization_instruction = (
            f"Condense the following refined answer into a concise, final response:\n{refined_answer}\n"
            "Format the output clearly and ensure it directly answers the question."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_answer)

        return final_answer