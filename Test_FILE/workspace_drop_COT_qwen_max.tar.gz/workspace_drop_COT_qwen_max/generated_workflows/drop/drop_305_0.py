# Workflow ID: drop_305_0
# Benchmark: drop
# Data Indices: [250, 650]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract relevant information (entities, numbers, relationships)
        extract_instruction = """
        Extract all relevant entities, numbers, and their relationships from the passage and question.
        Resolve ambiguous references (e.g., pronouns, partial names) and associate numbers with their corresponding entities.
        Format the output as a structured list or table for clarity.
        """
        extract_task = self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Interpret the question intent
        intent_instruction = """
        Analyze the question to determine its intent. Identify whether it requires:
        - Arithmetic operations (e.g., sum, difference)
        - Counting occurrences
        - Comparison between entities
        - Span extraction (e.g., entity names, phrases)
        Provide a clear explanation of the reasoning process and expected output format.
        """
        intent_task = self.generate(instruction=intent_instruction, context=self.problem_text)

        # Run extraction and intent interpretation in parallel
        extract_result, intent_result = await asyncio.gather(extract_task, intent_task)

        # Step 3: Perform reasoning based on the question intent
        reasoning_instruction = f"""
        Based on the extracted information: {extract_result}
        And the interpreted question intent: {intent_result}
        Perform the necessary reasoning steps to answer the question. This may include:
        - Arithmetic calculations (e.g., sum, difference)
        - Counting specific occurrences
        - Comparing entities based on given criteria
        - Extracting relevant text spans
        Provide a detailed step-by-step explanation of the reasoning process and the final result.
        """
        reasoning_task = self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Synthesize and validate the answer
        synthesis_instruction = f"""
        Evaluate the following reasoning result: {reasoning_task}
        Ensure the answer is consistent, accurate, and fully addresses the question.
        If there are multiple interpretations or conflicting results, synthesize them into a single coherent answer.
        """
        synthesis_task = self.ensemble(instruction=synthesis_instruction, contexts=[reasoning_task])

        # Run reasoning and synthesis in sequence
        reasoning_result = await reasoning_task
        synthesis_result = await synthesis_task

        # Step 5: Revise for accuracy and formatting
        revise_instruction = f"""
        Critique and refine the following answer: {synthesis_result}
        Ensure it is accurate, formatted correctly, and fully addresses the question.
        Provide suggestions for improvement if necessary.
        """
        final_answer = await self.revise(instruction=revise_instruction, context=synthesis_result)

        return final_answer