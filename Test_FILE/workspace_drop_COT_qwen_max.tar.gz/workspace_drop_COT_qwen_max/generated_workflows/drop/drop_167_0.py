# Workflow ID: drop_167_0
# Benchmark: drop
# Data Indices: [558, 600]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all relevant information from the passage
        extraction_instruction = """
        Extract ALL numerical values, entities, and their relationships from the passage. 
        Include details about who performed actions, quantities, measurements, dates, and any other relevant data. 
        Format the output as a structured list or table for clarity.
        """
        extracted_data = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine reasoning type
        question_analysis_instruction = f"""
        Analyze the question and determine the type of reasoning required. 
        Possible reasoning types include arithmetic operations (addition, subtraction, etc.), counting, comparison, and span extraction. 
        Based on the question, specify the exact task to be performed using the following extracted data: {extracted_data}.
        """
        reasoning_type = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or calculation
        reasoning_instruction = f"""
        Based on the reasoning type identified ({reasoning_type}), perform the required operation using the extracted data ({extracted_data}). 
        For arithmetic operations, calculate the result. For counting, count occurrences. For comparison, compare values. 
        For span extraction, return the exact text span. Ensure the output is clear and concise.
        """
        initial_answer = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the answer
        refinement_instruction = f"""
        Critique and refine the following answer: {initial_answer}. 
        Ensure it is accurate, complete, and directly addresses the question. 
        If there are any ambiguities or errors, correct them.
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=initial_answer)

        # Step 5: Final answer selection (if multiple candidates exist)
        final_instruction = f"""
        Evaluate the refined answer ({refined_answer}) and ensure it is the best possible response. 
        If there are multiple interpretations or answers, select the most appropriate one based on the question and passage context.
        """
        final_answer = await self.ensemble(instruction=final_instruction, contexts=[refined_answer])

        return final_answer