# Workflow ID: drop_36_0
# Benchmark: drop
# Data Indices: [506, 101]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract all relevant information from the passage and question
        extraction_instruction = (
            "Carefully analyze the passage and question to extract ALL relevant entities, "
            "numerical values, dates, and relationships. Ensure no information is missed. "
            "Format the output clearly, grouping related information."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Understand the question intent
        intent_instruction = (
            f"Given the extracted information: {extracted_info}\n"
            "Analyze the question to determine its intent. Identify whether the question "
            "requires arithmetic operations, counting, comparison, selection, or span extraction. "
            "Provide a clear and concise explanation of the reasoning required to answer the question."
        )
        question_intent = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or calculation (parallel execution for multiple paths)
        reasoning_tasks = []
        if "arithmetic" in question_intent.lower():
            arithmetic_instruction = (
                f"Using the extracted numerical values: {extracted_info}\n"
                "Perform the necessary arithmetic operations (addition, subtraction, etc.) "
                "to compute the answer. Show all steps clearly."
            )
            reasoning_tasks.append(self.generate(instruction=arithmetic_instruction, context=self.problem_text))
        if "comparison" in question_intent.lower():
            comparison_instruction = (
                f"Using the extracted entities and values: {extracted_info}\n"
                "Compare the relevant entities or values to determine which is greater, earlier, etc. "
                "Provide a clear justification for the comparison."
            )
            reasoning_tasks.append(self.generate(instruction=comparison_instruction, context=self.problem_text))
        if "selection" in question_intent.lower() or "span extraction" in question_intent.lower():
            selection_instruction = (
                f"Using the extracted spans and entities: {extracted_info}\n"
                "Select the most appropriate span or entity as the answer. Ensure the selection "
                "is directly supported by the passage."
            )
            reasoning_tasks.append(self.generate(instruction=selection_instruction, context=self.problem_text))

        # Execute reasoning tasks in parallel
        reasoning_results = await asyncio.gather(*reasoning_tasks)

        # Step 4: Refine and validate results
        refinement_tasks = [
            self.revise(
                instruction=f"Review and refine the following result: {result}\n"
                "Ensure it aligns with the question intent and is logically consistent with the passage.",
                context=self.problem_text
            )
            for result in reasoning_results
        ]
        refined_results = await asyncio.gather(*refinement_tasks)

        # Step 5: Finalize the answer using Ensemble
        ensemble_instruction = (
            "Evaluate the following candidate answers and select the best one based on "
            "coherence, correctness, and alignment with the question intent."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=refined_results)

        return final_answer