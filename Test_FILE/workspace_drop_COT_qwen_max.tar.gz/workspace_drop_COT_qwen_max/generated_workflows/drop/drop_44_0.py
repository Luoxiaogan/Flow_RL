# Workflow ID: drop_44_0
# Benchmark: drop
# Data Indices: [781, 4]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract key information from the passage
        extraction_instruction = """
        Extract ALL relevant information from the passage, including:
        - Entities (people, teams, places, etc.)
        - Numbers (with their associated context)
        - Dates
        - Relevant text spans (phrases, sentences, etc.)
        Ensure no information is missed and organize the output clearly.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Understand the question intent
        question_intent_instruction = f"""
        Analyze the question and determine its type. Possible types include:
        - Arithmetic (addition, subtraction, etc.)
        - Counting (how many times, how many different, etc.)
        - Comparison (greater, longer, more, etc.)
        - Selection (which team, who did, etc.)
        - Span extraction (who, what, where, etc.)
        Based on the question, identify the specific task to perform and any constraints.
        Extracted information from the passage: {extracted_info}
        """
        question_intent = await self.generate(instruction=question_intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question type
        reasoning_instruction = f"""
        Using the extracted information and the question intent, perform the required reasoning step-by-step.
        - For arithmetic questions, perform the specified operation (e.g., addition, subtraction).
        - For counting questions, count the relevant occurrences.
        - For comparison questions, compare the relevant values.
        - For selection questions, identify the correct entity or span.
        - For span extraction questions, extract the exact text span.
        Extracted information: {extracted_info}
        Question intent: {question_intent}
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the reasoning result
        refinement_instruction = f"""
        Critique and refine the reasoning result to ensure accuracy. Check for:
        - Correct association of numbers with entities
        - Proper handling of implicit information
        - Logical consistency
        - Adherence to the question intent
        Reasoning result: {reasoning_result}
        """
        refined_result = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Final answer extraction
        final_answer_instruction = f"""
        Extract the final answer in the required format (number, date, span, etc.) based on the refined reasoning result.
        Ensure the answer is concise and directly addresses the question.
        Refined reasoning result: {refined_result}
        """
        final_answer = await self.generate(instruction=final_answer_instruction, context=self.problem_text)

        return final_answer