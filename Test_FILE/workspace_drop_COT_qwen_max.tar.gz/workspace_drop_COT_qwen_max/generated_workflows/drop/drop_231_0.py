# Workflow ID: drop_231_0
# Benchmark: drop
# Data Indices: [66, 511]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information from the passage
        extract_instruction = """
        Analyze the provided passage thoroughly and extract all relevant entities, numerical values, and their relationships. 
        Focus on identifying key information such as counts, measurements, dates, and any explicit or implicit associations between entities and numbers. 
        Ensure that no critical detail is missed, as this information will be used for subsequent reasoning.
        """
        extract_task = self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Understand the question intent
        question_instruction = """
        Analyze the provided question and determine the type of reasoning required to answer it. 
        Identify whether the question involves arithmetic operations, counting, comparison, span extraction, or another form of reasoning. 
        Provide a clear interpretation of what the question is asking and specify the expected output format (e.g., number, text span, comparative statement).
        """
        question_task = self.generate(instruction=question_instruction, context=self.problem_text)

        # Execute Steps 1 and 2 in parallel
        extracted_info, question_intent = await asyncio.gather(extract_task, question_task)

        # Step 3: Perform reasoning based on the question intent
        reasoning_instruction = f"""
        Using the extracted information: {extracted_info}
        And the question interpretation: {question_intent}
        Perform the required reasoning to answer the question. 
        If the question involves arithmetic, calculate the result step by step. 
        If it involves comparison, evaluate the relevant entities or values. 
        If it requires span extraction, identify the exact text span that answers the question. 
        Ensure that the reasoning process is thorough and accurate.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine the reasoning result
        refine_instruction = f"""
        Critique and refine the following reasoning result: {reasoning_result}
        Check for any errors, ambiguities, or missing details. 
        Ensure that the answer aligns with the question intent and is supported by the extracted information. 
        Provide a revised version of the reasoning result if necessary.
        """
        refined_result = await self.revise(instruction=refine_instruction, context=reasoning_result)

        # Step 5: Finalize the answer
        finalize_instruction = f"""
        Condense the refined reasoning result: {refined_result}
        Into a concise and clear final answer. 
        Ensure that the answer directly addresses the question and is presented in the expected format (e.g., number, text span, comparative statement).
        """
        final_answer = await self.summarize(instruction=finalize_instruction, context=refined_result)

        return final_answer