# Workflow ID: drop_229_0
# Benchmark: drop
# Data Indices: [590, 622]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information (numbers, entities, relationships) in parallel with question analysis
        extract_instruction = (
            "Extract all numerical values, entities, and their relationships from the passage. "
            "Include counts, measurements, and any associated contextual information. "
            "Format the output as a structured list for easy reference."
        )
        question_analysis_instruction = (
            "Analyze the question to determine its intent. Identify whether it requires arithmetic operations, "
            "counting, comparison, selection, or span extraction. Provide a clear explanation of the reasoning pattern needed."
        )
        extract_task = self.generate(instruction=extract_instruction, context=self.problem_text)
        question_analysis_task = self.generate(instruction=question_analysis_instruction, context=self.problem_text)
        extracted_info, question_intent = await asyncio.gather(extract_task, question_analysis_task)

        # Step 2: Perform reasoning based on the question intent
        reasoning_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            f"And the question intent: {question_intent}\n"
            "Perform the necessary reasoning to answer the question. This may involve arithmetic operations, "
            "counting occurrences, comparing values, or selecting the correct span. Ensure all steps are clearly explained."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Refine reasoning if ambiguity arises
        refine_instruction = (
            f"Review the reasoning result: {reasoning_result}\n"
            "Refine the reasoning process if there are any ambiguities, implicit references, or incomplete associations. "
            "Ensure the final reasoning is accurate and complete."
        )
        refined_result = await self.revise(instruction=refine_instruction, context=reasoning_result)

        # Step 4: Synthesize or select the best answer
        synthesis_instruction = (
            f"Given the refined reasoning: {refined_result}\n"
            "Synthesize or select the best answer. If there are multiple candidate answers, evaluate them based on "
            "relevance, correctness, and completeness. Provide the final answer in the required format."
        )
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=[refined_result])

        return final_answer