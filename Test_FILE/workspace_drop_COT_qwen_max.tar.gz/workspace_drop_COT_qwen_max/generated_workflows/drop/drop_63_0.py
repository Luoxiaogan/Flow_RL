# Workflow ID: drop_63_0
# Benchmark: drop
# Data Indices: [521, 623]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract relevant information from the passage
        extraction_instruction = """Extract all numerical values, entities, and spans from the passage that could potentially answer the question. Ensure you capture all relevant data points, including counts, measurements, names, and relationships."""
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Interpret the question's intent
        intent_instruction = f"""Based on the question, determine what type of reasoning is required (e.g., arithmetic operation, comparison, counting, span extraction). Use the following extracted information for context: {extracted_info}."""
        question_intent = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning/calculation based on the question's intent
        reasoning_instruction = f"""Using the extracted information ({extracted_info}) and the interpreted intent ({question_intent}), perform the necessary reasoning or calculation to answer the question. Ensure your reasoning is step-by-step and transparent."""
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine and validate the answer
        refinement_instruction = f"""Critique and refine the following reasoning result to ensure it is accurate, well-formulated, and directly addresses the question: {reasoning_result}. Correct any errors or ambiguities."""
        refined_answer = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Summarize the refined answer into a concise output
        summarization_instruction = f"""Condense the following refined answer into a concise and clear response that directly answers the question: {refined_answer}."""
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_answer)

        return final_answer