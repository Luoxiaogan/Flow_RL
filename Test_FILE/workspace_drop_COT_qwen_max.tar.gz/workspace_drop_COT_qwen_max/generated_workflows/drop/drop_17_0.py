# Workflow ID: drop_17_0
# Benchmark: drop
# Data Indices: [315, 583]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the passage and question
        extraction_instruction = (
            "Carefully extract all entities, numerical values, and relationships mentioned in the passage and the question. "
            "Organize the information clearly, associating each number or entity with its corresponding context. "
            "Ensure no relevant detail is missed."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Interpret the question's intent
        intent_instruction = (
            "Analyze the question carefully to determine its intent. Identify whether the question requires arithmetic operations, "
            "counting, comparison, span extraction, or another type of reasoning. Provide a detailed explanation of the reasoning "
            "strategy needed to answer the question based on the extracted information."
        )
        question_intent = await self.generate(instruction=intent_instruction, context=extracted_info)

        # Step 3: Perform reasoning or calculation
        reasoning_instruction = (
            f"Using the extracted information: {extracted_info} and the interpreted question intent: {question_intent}, "
            "perform the necessary reasoning or calculation step-by-step. Ensure all steps are clearly explained and logically "
            "consistent. If the question involves arithmetic, show the calculations explicitly. If it involves selection or comparison, "
            "justify the choice with evidence from the passage."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the result
        refinement_instruction = (
            "Review the reasoning result and refine it if necessary. Check for accuracy, logical consistency, and completeness. "
            "Ensure the result directly answers the question and is supported by evidence from the passage. If there are any "
            "ambiguities or missing details, address them explicitly."
        )
        refined_result = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Synthesize the final answer
        synthesis_instruction = (
            "Condense the refined result into a concise and accurate final answer. Ensure the answer is clear, unambiguous, and "
            "directly addresses the question. If multiple interpretations or solutions were considered, select the most appropriate one."
        )
        final_answer = await self.summarize(instruction=synthesis_instruction, context=refined_result)

        return final_answer