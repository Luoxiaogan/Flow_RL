# Workflow ID: drop_62_0
# Benchmark: drop
# Data Indices: [99, 188]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the passage
        extract_instruction = """
        Extract all relevant numerical values, entities, and their relationships from the passage.
        Identify any mentions of teams, players, dates, scores, or other significant details.
        Organize the information clearly for subsequent reasoning steps.
        """
        extract_context = self.problem_text

        # Step 2: Interpret the question's intent
        interpret_instruction = """
        Analyze the question to determine its intent. Classify the question type as one of the following:
        - Arithmetic operation (e.g., addition, subtraction, counting)
        - Comparison (e.g., greater than, less than, earliest/latest)
        - Selection (e.g., which team/player/event)
        - Span extraction (e.g., identify a specific phrase or entity)
        Provide a clear explanation of the reasoning required to answer the question.
        """
        interpret_context = self.problem_text

        # Run extraction and interpretation in parallel
        extract_task = self.generate(instruction=extract_instruction, context=extract_context)
        interpret_task = self.generate(instruction=interpret_instruction, context=interpret_context)
        extracted_info, question_intent = await asyncio.gather(extract_task, interpret_task)

        # Step 3: Perform reasoning based on the question intent
        reasoning_instruction = f"""
        Using the extracted information: {extracted_info}
        And the interpreted question intent: {question_intent}
        Perform the necessary reasoning to answer the question. Follow these guidelines:
        - For arithmetic operations, calculate the result step by step.
        - For comparisons, evaluate all relevant entities/values and determine the correct answer.
        - For selections, identify the specific entity or event requested.
        - For span extraction, locate and extract the exact text span from the passage.
        Ensure the reasoning process is thorough and leaves no ambiguity.
        """
        reasoning_context = self.problem_text
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=reasoning_context)

        # Step 4: Refine the reasoning result
        refine_instruction = f"""
        Critique and refine the following reasoning result: {reasoning_result}
        Ensure the answer is accurate, complete, and directly addresses the question.
        Resolve any ambiguities or inconsistencies in the reasoning process.
        """
        refined_result = await self.revise(instruction=refine_instruction, context=reasoning_result)

        # Step 5: Summarize the final answer
        summarize_instruction = f"""
        Condense the refined reasoning result: {refined_result}
        Into a concise and accurate final answer. Ensure the answer is clear and directly responds to the question.
        """
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_result)

        return final_answer