# Workflow ID: drop_258_0
# Benchmark: drop
# Data Indices: [546, 668]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information from the passage and question
        extract_instruction = (
            "Extract all entities, numerical values, and their relationships from the passage and question. "
            "Identify what the question is asking for and note any key terms or phrases."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Analyze the question intent
        intent_instruction = (
            f"Based on the extracted information: {extracted_info}, analyze the question intent. "
            "Determine whether the task involves arithmetic operations, counting, comparison, or span extraction. "
            "Provide a clear directive for the next steps."
        )
        question_intent = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning and calculation in parallel
        reasoning_instruction = (
            f"Given the extracted information: {extracted_info} and the question intent: {question_intent}, "
            "perform the necessary reasoning and calculations to answer the question. "
            "Include all intermediate steps and explain your reasoning process."
        )
        validation_instruction = (
            f"Validate the reasoning and calculations performed: {reasoning_instruction}. "
            "Check for consistency, accuracy, and alignment with the question intent."
        )

        reasoning_result, validation_result = await asyncio.gather(
            self.generate(instruction=reasoning_instruction, context=self.problem_text),
            self.generate(instruction=validation_instruction, context=self.problem_text)
        )

        # Step 4: Refine the final answer
        refine_instruction = (
            f"Refine the reasoning result: {reasoning_result} based on the validation feedback: {validation_result}. "
            "Ensure the final answer is accurate, concise, and directly addresses the question."
        )
        refined_answer = await self.revise(instruction=refine_instruction, context=reasoning_result)

        # Step 5: Handle ambiguity (if necessary)
        ensemble_instruction = (
            f"Evaluate the refined answer: {refined_answer} against possible alternative interpretations. "
            "If multiple valid answers exist, select the most appropriate one based on context."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[refined_answer, validation_result])

        return final_answer