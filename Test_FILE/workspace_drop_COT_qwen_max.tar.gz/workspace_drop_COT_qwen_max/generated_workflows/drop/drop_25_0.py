# Workflow ID: drop_25_0
# Benchmark: drop
# Data Indices: [603, 51]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information
        extraction_instruction = (
            "Extract all numerical values, entities, and spans from the passage and question. "
            "Categorize the extracted information into numbers, entities, and relationships. "
            "Ensure no relevant information is missed."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Understand question intent
        intent_instruction = (
            f"Analyze the question to determine the type of reasoning required (e.g., arithmetic, comparison, selection). "
            f"Map the question to the extracted information: {extracted_info}. "
            "Provide a clear interpretation of what needs to be done."
        )
        question_intent = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning
        reasoning_instruction = (
            f"Based on the question intent: {question_intent}, perform the necessary reasoning steps. "
            "For arithmetic operations, calculate sums, differences, or other operations. "
            "For comparisons, evaluate which entity or value satisfies the condition. "
            "For selections, choose the correct entity or span based on the context."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine
        refinement_instruction = (
            f"Critique and refine the reasoning output: {reasoning_result}. "
            "Ensure the result is accurate, complete, and directly addresses the question."
        )
        refined_result = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Final output
        summary_instruction = (
            f"Summarize the final answer: {refined_result} in a concise format. "
            "Ensure it directly addresses the question and is easy to understand."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_result)

        return final_answer