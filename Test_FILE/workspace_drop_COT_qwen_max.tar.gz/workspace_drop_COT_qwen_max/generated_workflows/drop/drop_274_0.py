# Workflow ID: drop_274_0
# Benchmark: drop
# Data Indices: [367, 246]

```python
class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information from the passage and question
        extraction_instruction = (
            "Extract all numerical values, entities, relationships, and implicit references from the passage and question. "
            "Ensure you capture all occurrences of similar entities (e.g., multiple field goals, ages, percentages). "
            "Organize the extracted information clearly, associating numbers with their respective entities or contexts."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question intent and classify the reasoning type
        analysis_instruction = (
            f"Based on the extracted information: {extracted_info}, analyze the question to determine the required reasoning type. "
            "Classify the question as one of the following: arithmetic (addition/subtraction), counting, comparison, selection, or span extraction. "
            "Provide a clear explanation of the reasoning type and the specific task to be performed."
        )
        question_analysis = await self.generate(instruction=analysis_instruction, context=self.problem_text)

        # Step 3: Perform the reasoning/calculation based on the question type
        reasoning_instruction = (
            f"Given the question analysis: {question_analysis}, perform the required reasoning or calculation step-by-step. "
            "If the task involves arithmetic, show the calculation explicitly. If it involves counting, list all relevant occurrences. "
            "For comparisons, clearly state the entities being compared and the result. For span extraction, provide the exact text span."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the intermediate results
        refinement_instruction = (
            f"Review the reasoning result: {reasoning_result} for accuracy and completeness. "
            "Check for proper entity-number association, correct calculations, and logical consistency. "
            "Refine the result if necessary, providing a corrected version."
        )
        refined_result = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Finalize the answer by summarizing the result
        summary_instruction = (
            f"Condense the refined result: {refined_result} into a concise answer format. "
            "Ensure the answer is clear, accurate, and directly addresses the question. "
            "Preserve key numerical values, entities, or text spans as needed."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_result)

        return final_answer
```