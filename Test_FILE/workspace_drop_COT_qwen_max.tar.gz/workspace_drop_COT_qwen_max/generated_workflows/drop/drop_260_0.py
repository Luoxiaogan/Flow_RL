# Workflow ID: drop_260_0
# Benchmark: drop
# Data Indices: [507, 651]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the passage
        passage_extraction_task = self.generate(
            instruction="Extract all entities, numbers, and relationships mentioned in the passage. "
                        "Include contextual details such as who performed what action, when, and where. "
                        "Format the output as a structured list.",
            context=self.problem_text
        )

        # Step 2: Analyze the question to determine its intent
        question_intent_task = self.generate(
            instruction="Analyze the question to determine its intent. "
                        "Identify whether the question requires counting, arithmetic operations, comparison, "
                        "span extraction, or another type of reasoning. "
                        "Provide a clear summary of the expected reasoning steps.",
            context=self.problem_text
        )

        # Execute both tasks in parallel
        passage_info, question_intent = await asyncio.gather(passage_extraction_task, question_intent_task)

        # Step 3: Combine extracted information with question intent
        combined_context = await self.ensemble(
            instruction="Merge the extracted passage information with the question intent. "
                        "Ensure that the reasoning aligns with the question's requirements. "
                        "If there are multiple possible interpretations, prioritize the most relevant one.",
            contexts=[passage_info, question_intent]
        )

        # Step 4: Perform reasoning to compute the answer
        reasoning_result = await self.generate(
            instruction=f"Given the following combined context:\n{combined_context}\n"
                        "Perform the required reasoning steps to compute the answer. "
                        "If arithmetic operations are needed, show the calculations explicitly. "
                        "If the task involves span extraction, ensure the correct span is identified. "
                        "Format the final answer clearly.",
            context=self.problem_text
        )

        # Step 5: Refine the generated answer
        final_answer = await self.revise(
            instruction="Critique and refine the provided answer. "
                        "Ensure it is accurate, concise, and directly addresses the question. "
                        "Correct any errors or ambiguities.",
            context=reasoning_result
        )

        # Step 6: Return the final answer
        return final_answer