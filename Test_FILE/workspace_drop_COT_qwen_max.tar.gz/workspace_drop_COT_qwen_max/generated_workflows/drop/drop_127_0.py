# Workflow ID: drop_127_0
# Benchmark: drop
# Data Indices: [190, 690]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract relevant information and analyze the question
        extract_task = self.generate(
            instruction="Extract all entities, numbers, dates, and relationships from the passage. "
                        "Ensure no information is missed and ambiguous references are clarified.",
            context=self.problem_text
        )
        question_analysis_task = self.generate(
            instruction="Analyze the question to determine its intent (e.g., arithmetic, comparison, span extraction). "
                        "Identify what type of reasoning is required to answer the question.",
            context=self.problem_text
        )

        # Execute extraction and analysis in parallel
        extracted_info, question_intent = await asyncio.gather(extract_task, question_analysis_task)

        # Step 2: Refine entity-number associations
        refined_info = await self.revise(
            instruction=f"Refine the extracted information to ensure accurate association between entities and their "
                        f"corresponding numbers or dates. Focus on resolving ambiguities and implicit references.\n"
                        f"Extracted Info: {extracted_info}",
            context=self.problem_text
        )

        # Step 3: Perform reasoning and calculation based on question intent
        if "arithmetic" in question_intent.lower():
            reasoning_result = await self.generate(
                instruction=f"Based on the refined information, perform the required arithmetic operations to answer "
                            f"the question. Ensure all steps are clearly explained.\n"
                            f"Refined Info: {refined_info}\nQuestion Intent: {question_intent}",
                context=self.problem_text
            )
        elif "comparison" in question_intent.lower():
            reasoning_result = await self.ensemble(
                instruction=f"Evaluate and compare the options provided in the refined information to determine "
                            f"which satisfies the question's requirements.\n"
                            f"Refined Info: {refined_info}\nQuestion Intent: {question_intent}",
                contexts=[refined_info, question_intent]
            )
        elif "span extraction" in question_intent.lower():
            reasoning_result = await self.generate(
                instruction=f"Identify and extract the exact text span from the passage that answers the question. "
                            f"Ensure the span is precise and directly addresses the question.\n"
                            f"Refined Info: {refined_info}\nQuestion Intent: {question_intent}",
                context=self.problem_text
            )
        else:
            reasoning_result = await self.generate(
                instruction=f"Based on the refined information and question intent, provide a complete and accurate "
                            f"answer to the question. Ensure the reasoning process is clear and logical.\n"
                            f"Refined Info: {refined_info}\nQuestion Intent: {question_intent}",
                context=self.problem_text
            )

        # Step 4: Summarize the final answer
        final_answer = await self.summarize(
            instruction=f"Condense the reasoning process into a concise final answer. Ensure the answer is clear, "
                        f"correct, and formatted appropriately.\n"
                        f"Reasoning Result: {reasoning_result}",
            context=self.problem_text
        )

        return final_answer