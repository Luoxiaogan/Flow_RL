# Workflow ID: drop_201_0
# Benchmark: drop
# Data Indices: [702, 198]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract relevant information (numbers, entities, relationships)
        extraction_instruction = (
            "Thoroughly analyze the passage and question to extract all relevant numerical values, "
            "entities, and their relationships. Identify ambiguous references (e.g., pronouns) and "
            "associate each number with its corresponding entity. Provide the results in a structured format."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Understand the question intent (arithmetic, comparison, span extraction, etc.)
        intent_instruction = (
            f"Based on the extracted information: {extracted_info}, determine the type of reasoning "
            "required to answer the question. Examples include arithmetic operations (addition, subtraction), "
            "counting, comparison, selection, or span extraction. Clearly specify the reasoning type."
        )
        reasoning_type = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the identified type
        reasoning_instruction = (
            f"Using the extracted information: {extracted_info} and the reasoning type: {reasoning_type}, "
            "solve the problem step-by-step. If the reasoning involves arithmetic, show all calculations. "
            "If it involves selection or span extraction, clearly justify your choice."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the reasoning process or final answer
        refinement_instruction = (
            f"Critique and refine the following reasoning process or answer: {reasoning_result}. "
            "Ensure all steps are accurate, resolve any ambiguities, and confirm the final answer is correct."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: (Optional) Handle multiple interpretations using Ensemble
        # If the question allows for multiple interpretations, generate alternative solutions in parallel
        async def alternative_solution(path_name):
            alt_instruction = (
                f"Consider an alternative interpretation of the question: {path_name}. "
                f"Using the extracted information: {extracted_info}, provide a solution."
            )
            return await self.generate(instruction=alt_instruction, context=self.problem_text)

        alternative_solutions = await asyncio.gather(
            alternative_solution("Interpretation A"),
            alternative_solution("Interpretation B")
        )

        if alternative_solutions:
            ensemble_instruction = (
                "Evaluate and select the best solution among the following options: "
                f"{[refined_answer] + alternative_solutions}. Justify your choice."
            )
            final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[refined_answer] + alternative_solutions)
        else:
            final_answer = refined_answer

        # Step 6: Summarize the final answer if needed
        summary_instruction = (
            f"Condense the following answer into a concise response: {final_answer}. "
            "Ensure it directly addresses the question."
        )
        concise_answer = await self.summarize(instruction=summary_instruction, context=final_answer)

        return concise_answer