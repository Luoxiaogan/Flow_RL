# Workflow ID: drop_66_0
# Benchmark: drop
# Data Indices: [232, 503]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Initial Analysis - Extract relevant information
        extraction_instruction = """
        Analyze the passage and question thoroughly. Identify and extract all relevant information, including:
        - Numerical values and their associated entities
        - Key entities mentioned in the question
        - Relationships between entities (e.g., comparisons, sequences)
        - Implicit information that may require inference
        Format the extracted information clearly and concisely.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Reasoning and Calculation - Perform the required operation
        reasoning_instruction = f"""
        Based on the following extracted information:
        {extracted_info}
        Determine the type of reasoning required to answer the question. Perform the necessary calculations or reasoning steps, such as:
        - Arithmetic operations (addition, subtraction, etc.)
        - Counting occurrences of specific entities
        - Comparing values or entities
        - Selecting specific spans of text
        Ensure the reasoning process is clear and step-by-step. Provide the final result.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Validation and Refinement - Critique and refine the result
        refinement_instruction = f"""
        Review the following reasoning result:
        {reasoning_result}
        Critique its accuracy and alignment with the question's intent. Check for:
        - Correct association of numbers with entities
        - Proper handling of implicit information
        - Logical consistency in the reasoning process
        Refine the result if necessary and provide the improved version.
        """
        refined_result = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 4: Final Output - Summarize the refined result
        summarization_instruction = """
        Condense the following refined result into a concise, final answer that directly addresses the question:
        Ensure the output is clear, accurate, and formatted appropriately.
        """
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_result)

        return final_answer