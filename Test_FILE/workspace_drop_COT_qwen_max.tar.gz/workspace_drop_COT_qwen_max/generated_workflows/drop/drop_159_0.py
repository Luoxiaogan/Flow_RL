# Workflow ID: drop_159_0
# Benchmark: drop
# Data Indices: [215, 609]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the passage
        extraction_instruction = (
            "Carefully analyze the provided passage and extract all numerical values, entities, "
            "and their relationships. Ensure you capture every detail that could be relevant "
            "to answering questions about the passage."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Understand the question intent
        intent_instruction = (
            f"Given the extracted information: {extracted_info}\n"
            "Analyze the question and determine its intent. Identify whether the question requires "
            "arithmetic operations, counting, comparison, or span extraction. Provide a clear plan "
            "for how to proceed based on the question's requirements."
        )
        question_intent = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question intent
        reasoning_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            f"And the identified question intent: {question_intent}\n"
            "Perform the necessary reasoning steps to answer the question. Follow the plan outlined "
            "in the question intent and ensure all calculations or comparisons are accurate."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine the answer
        refinement_instruction = (
            f"Review the reasoning result: {reasoning_result}\n"
            "Critique and refine the answer to ensure it is accurate, complete, and consistent with "
            "the passage and the question. Correct any errors or ambiguities."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"Condense the refined answer: {refined_answer}\n"
            "into a concise and clear format suitable for submission. Ensure the final answer directly "
            "addresses the question without unnecessary details."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_answer)

        return final_answer