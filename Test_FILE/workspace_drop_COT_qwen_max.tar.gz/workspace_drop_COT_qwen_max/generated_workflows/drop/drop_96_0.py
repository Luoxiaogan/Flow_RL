# Workflow ID: drop_96_0
# Benchmark: drop
# Data Indices: [252, 785]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all relevant information (numbers, entities, spans)
        extraction_instruction = (
            "Extract all numerical values, entities, and text spans from the passage that could be relevant to answering the question. "
            "Ensure you capture all instances, even if they seem similar. Organize the extracted information clearly."
        )
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_analysis_instruction = (
            f"Given the extracted information: {extraction}\n"
            "Analyze the question to determine its intent. Identify whether the question requires arithmetic operations, comparisons, counting, or span extraction. "
            "Provide a clear explanation of the reasoning steps needed to answer the question."
        )
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question intent
        reasoning_instruction = (
            f"Based on the extracted information: {extraction}\n"
            f"And the analysis of the question: {question_analysis}\n"
            "Perform the required reasoning steps to compute the answer. If the question involves arithmetic, show the calculation. "
            "If it involves comparison, clearly state which entity or value satisfies the condition. "
            "If it involves span extraction, provide the exact span from the passage."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine the answer to ensure correctness
        refinement_instruction = (
            f"Review the reasoning result: {reasoning_result}\n"
            "Critique and refine the answer to ensure it aligns with the question's requirements. Check for errors in calculations, comparisons, or span selection. "
            "Provide the final refined answer."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Final synthesis (if multiple candidates exist)
        # In this case, we assume only one reasoning path, but Ensemble can be used for more complex scenarios
        final_answer = refined_answer

        return final_answer