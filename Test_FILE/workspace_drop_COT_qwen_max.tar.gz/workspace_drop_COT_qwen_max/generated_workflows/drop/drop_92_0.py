# Workflow ID: drop_92_0
# Benchmark: drop
# Data Indices: [63, 243]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information from the passage and question
        extraction_instruction = (
            "Extract all entities, numerical values, dates, and relationships mentioned in the passage and question. "
            "Identify the type of question being asked (e.g., arithmetic, counting, comparison, selection, span extraction). "
            "Provide a structured summary of the extracted information."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Dynamically construct instructions for reasoning
        reasoning_instruction = (
            f"Based on the extracted information: {extracted_info}, determine the reasoning steps required to answer the question. "
            "If the question involves arithmetic operations, specify the numbers and operations needed. "
            "If it involves counting, identify the entities to be counted. "
            "For comparisons, specify the entities or values to be compared. "
            "For span extraction, identify the exact text span to be extracted."
        )
        reasoning_steps = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Execute reasoning steps in parallel
        arithmetic_instruction = (
            f"Perform any arithmetic operations specified in the reasoning steps: {reasoning_steps}. "
            "Ensure all calculations are accurate and aligned with the question intent."
        )
        counting_instruction = (
            f"Count the occurrences of entities or events specified in the reasoning steps: {reasoning_steps}. "
            "Ensure no instances are missed."
        )
        comparison_instruction = (
            f"Compare the entities or values specified in the reasoning steps: {reasoning_steps}. "
            "Clearly state which is greater, lesser, or equal."
        )
        span_extraction_instruction = (
            f"Extract the exact text span specified in the reasoning steps: {reasoning_steps}. "
            "Ensure the span is precise and directly answers the question."
        )

        results = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=counting_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text),
            self.generate(instruction=span_extraction_instruction, context=self.problem_text)
        )

        # Step 4: Ensemble to decide the best solution
        ensemble_instruction = (
            "Evaluate the candidate solutions provided. "
            "Select the one that best answers the question based on the reasoning steps and extracted information."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 5: Refine and summarize the final answer
        refinement_instruction = (
            "Refine the final answer to ensure clarity and accuracy. "
            "Correct any ambiguities or errors."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        summary_instruction = (
            "Summarize the refined answer into a concise format. "
            "Ensure the output directly addresses the question."
        )
        summarized_answer = await self.summarize(instruction=summary_instruction, context=refined_answer)

        return summarized_answer