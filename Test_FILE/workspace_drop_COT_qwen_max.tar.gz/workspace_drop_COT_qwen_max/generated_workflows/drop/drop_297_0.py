# Workflow ID: drop_297_0
# Benchmark: drop
# Data Indices: [359, 497]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract relevant information from the passage and question
        extraction_instruction = """
        Extract all relevant entities, numbers, dates, and spans from the passage and question.
        Include explicit mentions as well as any implicit information that might be inferred.
        Organize the extracted information clearly, associating numbers and spans with their respective entities.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Understand the question's intent
        intent_instruction = f"""
        Analyze the question to determine its intent. Specifically:
        - Identify if the question requires arithmetic operations (e.g., addition, subtraction).
        - Check if it involves counting occurrences of entities or events.
        - Determine if it requires comparison (e.g., greater than, less than).
        - Assess if it involves selecting a specific entity, span, or value.
        - Note any span extraction requirements.
        Use the following extracted information for context: {extracted_info}.
        Provide a clear summary of the question's intent.
        """
        question_intent = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question's intent
        reasoning_instruction = f"""
        Based on the question's intent ({question_intent}) and the extracted information ({extracted_info}):
        - Perform the required arithmetic operations, if applicable.
        - Count occurrences of entities or events, if applicable.
        - Compare values or spans, if applicable.
        - Select the correct entity, span, or value, if applicable.
        - Extract the requested span, if applicable.
        Provide a detailed reasoning process and the intermediate results.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine and validate the reasoning output
        refinement_instruction = f"""
        Review the reasoning result ({reasoning_result}) and ensure it aligns with the passage and question context.
        Address any ambiguities, missing information, or inconsistencies.
        Provide a refined and validated answer.
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Synthesize final answer if multiple reasoning paths exist
        final_instruction = f"""
        Synthesize the refined answer ({refined_answer}) into a concise and accurate final response.
        Ensure the answer directly addresses the question and is consistent with the passage.
        """
        final_answer = await self.ensemble(instruction=final_instruction, contexts=[refined_answer])

        return final_answer