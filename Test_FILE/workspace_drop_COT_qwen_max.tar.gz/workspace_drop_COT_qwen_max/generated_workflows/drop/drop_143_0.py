# Workflow ID: drop_143_0
# Benchmark: drop
# Data Indices: [208, 640]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Initial Analysis (Extract Relevant Information)
        initial_analysis_instruction = """
        Analyze the provided passage and question to identify all relevant information.
        Extract entities, numerical values, dates, and relationships between them.
        Understand the intent of the question and determine what type of reasoning is required (e.g., arithmetic, counting, comparison, selection, span extraction).
        Organize the extracted information in a structured format for further processing.
        """
        extracted_info = await self.generate(instruction=initial_analysis_instruction, context=self.problem_text)

        # Step 2: Reasoning and Calculation
        reasoning_instruction = f"""
        Based on the following extracted information: {extracted_info}
        Perform the necessary reasoning or calculation to answer the question.
        If the question involves arithmetic operations, clearly show the steps and calculations.
        If the question involves counting, ensure all relevant occurrences are considered.
        If the question involves comparison, explicitly compare the relevant entities or values.
        If the question involves selection, identify the correct entity or span based on the context.
        Provide the result of your reasoning in a clear and structured format.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Validation and Refinement
        validation_instruction = f"""
        Review the following reasoning result: {reasoning_result}
        Validate its accuracy by cross-checking with the original passage and extracted information.
        Identify and resolve any ambiguities, errors, or inconsistencies.
        Refine the result to ensure it is correct and complete.
        """
        refined_result = await self.revise(instruction=validation_instruction, context=reasoning_result)

        # Step 4: Final Answer Compilation
        final_answer_instruction = f"""
        Summarize the following refined result: {refined_result}
        Condense it into a concise final answer that directly addresses the question.
        Ensure the answer is clear, accurate, and formatted appropriately.
        """
        final_answer = await self.summarize(instruction=final_answer_instruction, context=refined_result)

        return final_answer