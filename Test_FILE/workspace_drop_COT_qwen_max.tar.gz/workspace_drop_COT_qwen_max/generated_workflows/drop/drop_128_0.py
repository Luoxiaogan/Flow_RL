# Workflow ID: drop_128_0
# Benchmark: drop
# Data Indices: [362, 375]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract relevant information from the passage and question
        extract_instruction = (
            "Extract all numerical values, entities, and key phrases from the passage and question. "
            "Ensure you capture relationships between entities and any implicit information. "
            "Format the output as a structured list."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        analyze_instruction = (
            f"Given the extracted information: {extracted_info}\n"
            "Analyze the question to determine its intent. "
            "Classify the question into one of the following categories: arithmetic, counting, comparison, selection, or span extraction. "
            "Provide reasoning for your classification."
        )
        question_intent = await self.generate(instruction=analyze_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or extraction based on the question intent
        reasoning_instruction = (
            f"Based on the question intent: {question_intent}\n"
            f"Using the extracted information: {extracted_info}\n"
            "Perform the required reasoning or extraction. "
            "For arithmetic questions, compute the result step by step. "
            "For comparison questions, compare the relevant entities or values. "
            "For span extraction, identify the exact text span that answers the question. "
            "Format the output clearly."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine and validate the result
        refine_instruction = (
            f"Review the reasoning result: {reasoning_result}\n"
            "Critique and refine the result to ensure accuracy. "
            "Check for any errors in calculation, comparison, or span identification. "
            "Provide the refined result."
        )
        refined_result = await self.revise(instruction=refine_instruction, context=reasoning_result)

        # Step 5: Finalize the answer
        finalize_instruction = (
            f"Condense the refined result: {refined_result}\n"
            "Summarize the final answer in a concise format suitable for the question. "
            "Ensure the answer is clear and directly addresses the question."
        )
        final_answer = await self.summarize(instruction=finalize_instruction, context=refined_result)

        return final_answer