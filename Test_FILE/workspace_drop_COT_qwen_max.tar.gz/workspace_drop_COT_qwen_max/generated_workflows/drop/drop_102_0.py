# Workflow ID: drop_102_0
# Benchmark: drop
# Data Indices: [487, 236]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information from the passage and question
        extraction_instruction = (
            "Thoroughly analyze the passage and question to extract all relevant information. "
            "Identify numerical values, entities, relationships, and implicit cues. "
            "Ensure that each number is associated with its corresponding entity or context."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Interpret the question's intent
        question_intent_instruction = (
            f"Based on the extracted information: {extracted_info}, determine the intent of the question. "
            "Classify the task as one of the following: arithmetic operation, counting, comparison, span extraction, or selection. "
            "Provide clear reasoning for your classification."
        )
        question_intent = await self.generate(instruction=question_intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or calculation based on the question type
        reasoning_instruction = (
            f"Given the question intent: {question_intent}, and the extracted information: {extracted_info}, "
            "perform the necessary reasoning or calculation. If the task involves arithmetic, explicitly compute the result. "
            "If it involves span extraction or selection, locate and extract the exact span or entity."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the result
        validation_instruction = (
            f"Review the reasoning result: {reasoning_result}. Critique its accuracy and logical consistency. "
            "Cross-reference with the passage to ensure correctness. Refine the result if necessary."
        )
        refined_result = await self.revise(instruction=validation_instruction, context=reasoning_result)

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"Condense the refined result: {refined_result} into a concise, well-structured response. "
            "Ensure the output adheres to the expected format (e.g., number, date, text span)."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_result)

        return final_answer