# Workflow ID: drop_332_0
# Benchmark: drop
# Data Indices: [364, 569]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract relevant information from the passage and question
        extraction_task = self.generate(
            instruction="Extract all numerical values, entities, and their relationships from the passage. "
                        "Ensure you capture every detail, including implicit connections and context.",
            context=self.problem_text
        )
        question_intent_task = self.generate(
            instruction="Analyze the question to determine its type (e.g., arithmetic, counting, comparison, span extraction). "
                        "Identify what specific information is being asked for and how it relates to the passage.",
            context=self.problem_text
        )

        # Execute these tasks in parallel
        extracted_info, question_intent = await asyncio.gather(extraction_task, question_intent_task)

        # Step 2: Perform reasoning based on the question type
        reasoning_instruction = f"""
        Based on the following information:
        - Extracted Passage Details: {extracted_info}
        - Question Intent: {question_intent}

        Perform the necessary reasoning steps to answer the question. 
        If the question involves arithmetic operations, calculate the result step by step. 
        If it involves span extraction, identify the exact text span from the passage. 
        Ensure your reasoning is clear, logical, and fully supported by the passage.
        """
        reasoning_result = await self.generate(
            instruction=reasoning_instruction,
            context=self.problem_text
        )

        # Step 3: Validate and refine the reasoning
        refined_reasoning = await self.revise(
            instruction="Review the reasoning steps and ensure they are accurate and aligned with the question intent. "
                       "Correct any errors or inconsistencies.",
            context=reasoning_result
        )

        # Step 4: Summarize the final answer
        final_answer = await self.summarize(
            instruction="Condense the reasoning into a concise answer format. "
                       "Ensure the answer directly addresses the question and is supported by the passage.",
            context=refined_reasoning
        )

        return final_answer