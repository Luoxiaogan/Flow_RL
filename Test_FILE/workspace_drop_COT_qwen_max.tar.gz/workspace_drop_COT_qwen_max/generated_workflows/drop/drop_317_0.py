# Workflow ID: drop_317_0
# Benchmark: drop
# Data Indices: [94, 145]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Comprehensive Extraction
        extraction_instruction = """
        Extract all entities, numerical values, and their relationships from the passage. 
        Ensure you capture ALL relevant information, including implicit references and contextual associations. 
        Organize the extracted data in a structured format for easy reference.
        """
        extracted_data = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Question Understanding and Categorization
        categorization_instruction = f"""
        Analyze the question to determine its type. Possible types include:
        - Arithmetic operations (addition, subtraction, multiplication, division)
        - Counting instances of specific entities or events
        - Comparison between entities or values
        - Selection of specific spans of text
        - Other reasoning tasks
        
        Based on the extracted data: {extracted_data}, classify the question and provide reasoning about its intent.
        """
        question_analysis = await self.generate(instruction=categorization_instruction, context=self.problem_text)

        # Step 3: Parallel Reasoning Paths
        arithmetic_instruction = f"""
        If the question involves arithmetic operations, calculate the required value using the extracted data: {extracted_data}.
        Ensure you associate numbers with their respective entities and perform the correct operation (sum, difference, etc.).
        """
        comparison_instruction = f"""
        If the question involves comparison, compare the relevant entities or values from the extracted data: {extracted_data}.
        Determine which entity is greater, lesser, or if they are equal, and provide the reasoning behind your conclusion.
        """
        span_extraction_instruction = f"""
        If the question requires extracting a specific span of text, identify the exact phrase or sentence from the passage that answers the question.
        Ensure the span is contextually accurate and directly addresses the question.
        """

        # Execute reasoning paths in parallel
        arithmetic_result, comparison_result, span_extraction_result = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text),
            self.generate(instruction=span_extraction_instruction, context=self.problem_text)
        )

        # Step 4: Ensemble Decision-Making
        ensemble_instruction = f"""
        Evaluate the results from the following reasoning paths:
        - Arithmetic Result: {arithmetic_result}
        - Comparison Result: {comparison_result}
        - Span Extraction Result: {span_extraction_result}
        
        Select the most appropriate result based on the question's intent and the extracted data: {extracted_data}.
        Ensure the final answer is coherent, accurate, and directly addresses the question.
        """
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[arithmetic_result, comparison_result, span_extraction_result])

        # Step 5: Final Refinement
        refinement_instruction = f"""
        Review the final answer: {final_answer} for clarity, correctness, and alignment with the question's requirements.
        Make any necessary revisions to ensure the response is polished and precise.
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        return refined_answer