# Workflow ID: drop_220_0
# Benchmark: drop
# Data Indices: [733, 314]

```python
class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all relevant information from the passage
        extract_instruction = """
        Extract ALL relevant information from the passage that could help answer the question. 
        Include entities (people, places, organizations), numerical values, dates, and relationships between them. 
        Ensure no detail is missed, as even minor information might be crucial for answering the question.
        """
        extract_task = self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_instruction = """
        Analyze the question to determine what type of reasoning is required. 
        Identify whether the question involves arithmetic operations (e.g., addition, subtraction), counting, comparison, span extraction, or another type of reasoning. 
        Provide a detailed breakdown of the question's intent and how it relates to the passage.
        """
        question_task = self.generate(instruction=question_instruction, context=self.problem_text)

        # Run extraction and question analysis in parallel
        extracted_info, question_analysis = await asyncio.gather(extract_task, question_task)

        # Step 3: Perform reasoning or calculation based on the question intent
        reasoning_instruction = f"""
        Using the extracted information: {extracted_info}
        And the question analysis: {question_analysis}
        Perform the necessary reasoning or calculation to answer the question. 
        If the question involves arithmetic operations, perform the calculations explicitly. 
        If it involves counting, count the relevant occurrences accurately. 
        If it involves comparison, compare the relevant values or entities. 
        If it involves span extraction, identify the exact text span that answers the question.
        Ensure the reasoning process is clear and logical.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the answer
        refine_instruction = f"""
        Review the reasoning result: {reasoning_result}
        Ensure the answer is accurate, clear, and directly addresses the question. 
        Correct any errors, clarify ambiguities, and improve the phrasing if necessary. 
        Provide the refined answer in a concise format.
        """
        refined_answer = await self.revise(instruction=refine_instruction, context=reasoning_result)

        # Step 5: Summarize the final answer
        summarize_instruction = """
        Summarize the final answer in a concise format that directly addresses the question. 
        Ensure the answer is easy to understand and leaves no room for misinterpretation.
        """
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_answer)

        return final_answer
```