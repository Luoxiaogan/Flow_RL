# Workflow ID: drop_122_0
# Benchmark: drop
# Data Indices: [452, 749]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract Key Information
        extraction_instruction = (
            "Thoroughly analyze the provided passage and extract all entities, numerical values, "
            "and their relationships. Ensure no relevant information is missed. Format the output "
            "as a structured list or table for clarity."
        )
        key_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze Question Intent
        intent_instruction = (
            "Carefully analyze the question and determine its type. Classify it as one of the following: "
            "arithmetic operation, counting, comparison, selection, or span extraction. Provide a detailed "
            "reasoning plan for answering the question based on the extracted information."
        )
        question_intent = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Perform Reasoning (Parallel Execution)
        reasoning_instruction_template = (
            "Based on the extracted information and the question intent, perform the necessary reasoning steps. "
            "For arithmetic operations, show all calculations step-by-step. For counting, ensure all relevant "
            "occurrences are considered. For comparisons, clearly state the basis of comparison. For span "
            "extraction, provide the exact text span with its context. Use the following extracted information: {key_info}"
        )
        reasoning_instruction = reasoning_instruction_template.format(key_info=key_info)
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine Results
        refine_instruction = (
            "Review the reasoning results and validate their accuracy. Correct any errors, clarify ambiguous "
            "statements, and ensure the answer aligns with the question intent. Provide a revised version of the results."
        )
        refined_result = await self.revise(instruction=refine_instruction, context=reasoning_result)

        # Step 5: Summarize and Finalize
        summarize_instruction = (
            "Condense the refined results into a concise and clear answer. Ensure the response directly addresses "
            "the question and includes all necessary details (e.g., numbers, spans, or comparisons)."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_result)

        # Step 6: Handle Ambiguities (if needed)
        ambiguity_check = "Check if there are multiple valid interpretations or results. If so, list them."
        potential_ambiguities = await self.generate(instruction=ambiguity_check, context=final_answer)
        if "multiple" in potential_ambiguities.lower():
            ensemble_instruction = (
                "Evaluate the provided options and select the most accurate and relevant answer. "
                "Consider the context of the question and the original passage."
            )
            final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[final_answer, potential_ambiguities])

        return final_answer