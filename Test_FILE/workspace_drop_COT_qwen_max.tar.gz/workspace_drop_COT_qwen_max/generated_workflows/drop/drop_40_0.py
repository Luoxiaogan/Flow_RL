# Workflow ID: drop_40_0
# Benchmark: drop
# Data Indices: [789, 684]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all relevant entities, numbers, and relationships
        extraction_instruction = (
            "Extract all entities, numerical values, dates, and their relationships from the passage. "
            "Include explicit and implicit information. Format the output as a structured list."
        )
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_analysis_instruction = (
            "Analyze the question to determine its intent. "
            "Identify whether it requires arithmetic operations, counting, comparison, selection, or span extraction. "
            "Provide a detailed reasoning plan to solve the question."
        )
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or calculation based on the question analysis
        reasoning_instruction = (
            f"Based on the extracted information: {extraction} and the question analysis: {question_analysis}, "
            "perform the necessary reasoning or calculation. Include all steps and intermediate results."
        )
        reasoning = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the reasoning
        validation_instruction = (
            "Critique the reasoning process and refine the results if necessary. "
            "Ensure all calculations are accurate and all entities are correctly associated with their values."
        )
        refined_reasoning = await self.revise(instruction=validation_instruction, context=reasoning)

        # Step 5: Synthesize the final answer
        synthesis_instruction = (
            "Condense the refined reasoning into a concise answer that directly addresses the question. "
            "Ensure the output is clear and formatted appropriately."
        )
        final_answer = await self.summarize(instruction=synthesis_instruction, context=refined_reasoning)

        return final_answer