# Workflow ID: drop_371_0
# Benchmark: drop
# Data Indices: [273, 320]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract relevant information from the passage and question
        extraction_instruction = """
        Analyze the provided passage and question thoroughly. Extract all numerical values, entities, and their relationships. 
        Identify any implicit information or inferred relationships. Format the output clearly, grouping related information together.
        """
        extracted_data = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Understand the question and determine its intent
        question_analysis_instruction = f"""
        Based on the extracted data: {extracted_data}, analyze the question to determine its intent. 
        Identify whether the question requires arithmetic operations (e.g., addition, subtraction), comparison, counting, or span extraction. 
        Provide a clear explanation of the reasoning required to answer the question.
        """
        question_intent = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or calculation based on the question intent
        reasoning_instruction = f"""
        Using the extracted data: {extracted_data} and the identified question intent: {question_intent}, 
        perform the necessary reasoning or calculation to answer the question. 
        If the question involves arithmetic, compute the result step by step. 
        If it involves comparison, compare the relevant entities or values. 
        If it involves span extraction, locate and return the exact text span from the passage. 
        Ensure the output is precise and directly addresses the question.
        """
        raw_answer = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the output
        refinement_instruction = f"""
        Review the following answer: {raw_answer}. Ensure it is accurate, well-formulated, and directly addresses the question. 
        Correct any errors or ambiguities. Improve clarity and conciseness without losing essential information.
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=raw_answer)

        # Step 5: Summarize the final answer
        summarization_instruction = """
        Condense the provided answer into a concise, clear format. Ensure it retains all critical information and is easy to understand.
        """
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_answer)

        return final_answer