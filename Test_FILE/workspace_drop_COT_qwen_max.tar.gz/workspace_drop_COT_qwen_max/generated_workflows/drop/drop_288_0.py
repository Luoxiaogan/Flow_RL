# Workflow ID: drop_288_0
# Benchmark: drop
# Data Indices: [482, 194]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information from the passage
        extraction_instruction = """
        Analyze the provided passage and extract all relevant information that could help answer the question. 
        This includes:
        - Numerical values and their associated entities (e.g., "58.9% White American")
        - Entities and their relationships (e.g., "Spain fighting wars with France, the Netherlands, and England")
        - Implicit or explicit facts (e.g., "Henry IV converted to Catholicism in 1593")
        Ensure that the extraction is exhaustive and includes ALL possible relevant details.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Understand the question's intent
        question_analysis_instruction = f"""
        Given the extracted information: {extracted_info}
        Analyze the question and determine its intent. Specifically:
        - Identify whether the question requires arithmetic operations (e.g., sum, difference), counting, comparison, or span extraction.
        - Determine the exact operation or reasoning required to answer the question.
        Provide a clear explanation of the question's intent and the approach needed to solve it.
        """
        question_intent = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Generate multiple candidate solutions in parallel
        arithmetic_instruction = f"""
        Based on the extracted information: {extracted_info}
        Perform any necessary arithmetic operations (e.g., addition, subtraction) to compute the answer.
        Ensure that all numerical values are correctly associated with their entities.
        """
        counting_instruction = f"""
        Based on the extracted information: {extracted_info}
        Count the occurrences of relevant entities or events as required by the question.
        Ensure that the count is accurate and accounts for all instances.
        """
        comparison_instruction = f"""
        Based on the extracted information: {extracted_info}
        Compare the relevant entities or values as required by the question.
        Determine which entity is greater, lesser, or if they are equal.
        """
        span_extraction_instruction = f"""
        Based on the extracted information: {extracted_info}
        Extract the relevant text span that directly answers the question.
        Ensure that the span is precise and fully addresses the question.
        """

        # Execute reasoning paths in parallel
        results = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=counting_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text),
            self.generate(instruction=span_extraction_instruction, context=self.problem_text)
        )

        # Step 4: Ensemble decision to select the best solution
        ensemble_instruction = f"""
        Evaluate the following candidate solutions and select the one that best answers the question:
        - Arithmetic Solution: {results[0]}
        - Counting Solution: {results[1]}
        - Comparison Solution: {results[2]}
        - Span Extraction Solution: {results[3]}
        Choose the solution that aligns most closely with the question's intent and provides the most accurate answer.
        """
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 5: Refine the final answer
        refinement_instruction = f"""
        Critique and refine the following answer to ensure clarity, accuracy, and completeness:
        {final_answer}
        Address any ambiguities, inconsistencies, or missing details. Provide the final polished answer.
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        return refined_answer