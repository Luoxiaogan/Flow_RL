# Workflow ID: drop_60_0
# Benchmark: drop
# Data Indices: [480, 28]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the passage
        extract_instruction = """
        Extract all relevant entities, numerical values, dates, and their relationships from the passage. 
        Identify which numbers or dates are associated with specific entities or events. 
        Provide the information in a structured format, such as a list or table.
        """
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_analysis_instruction = f"""
        Analyze the question to determine what it is asking for. 
        Identify whether the question requires arithmetic operations (e.g., sum, difference), counting, comparison, 
        or span extraction. Use the following extracted information as context: {extracted_info}.
        """
        question_intent = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question intent
        reasoning_instruction = f"""
        Based on the question intent ({question_intent}), perform the required reasoning using the extracted information ({extracted_info}).
        If the question involves arithmetic operations, calculate the result step by step. 
        If it involves counting, ensure all relevant instances are considered. 
        If it involves comparison, clearly state which entity or value is greater/smaller. 
        If it involves span extraction, provide the exact text span from the passage.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine and validate the reasoning result
        refine_instruction = f"""
        Critique and refine the reasoning result ({reasoning_result}). 
        Ensure the answer aligns with the question and the extracted information. 
        Correct any errors or inconsistencies.
        """
        refined_result = await self.revise(instruction=refine_instruction, context=reasoning_result)

        # Step 5: Handle ambiguity if necessary
        ensemble_instruction = f"""
        If there are multiple interpretations or conflicting results, evaluate and select the most appropriate answer. 
        Use the following information for evaluation: {refined_result}.
        """
        final_result = await self.ensemble(instruction=ensemble_instruction, contexts=[refined_result])

        # Step 6: Summarize the final answer
        summarize_instruction = f"""
        Summarize the final result ({final_result}) into a concise answer. 
        Ensure the answer directly addresses the question and is easy to understand.
        """
        final_answer = await self.summarize(instruction=summarize_instruction, context=final_result)

        return final_answer