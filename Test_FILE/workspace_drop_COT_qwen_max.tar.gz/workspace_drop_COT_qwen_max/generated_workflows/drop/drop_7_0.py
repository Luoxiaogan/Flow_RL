# Workflow ID: drop_7_0
# Benchmark: drop
# Data Indices: [418, 358]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information from the passage
        extraction_instruction = """
        Thoroughly analyze the provided passage and extract ALL relevant information that could help answer the question. 
        This includes:
        - Numerical values and their associated entities
        - Key events and their participants
        - Relationships between entities (e.g., who did what, when, and where)
        - Any implicit or explicit comparisons
        Ensure that no potentially useful information is omitted.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Understand the question intent
        question_intent_instruction = f"""
        Given the extracted information: {extracted_info}
        Analyze the question and determine its intent. Specifically:
        - Identify whether the question requires arithmetic operations (e.g., addition, subtraction), comparisons (e.g., greater than, less than), counting, or span extraction.
        - Determine which extracted elements are relevant to answering the question.
        - Formulate a clear reasoning path to arrive at the answer.
        Provide a detailed breakdown of your analysis.
        """
        question_analysis = await self.generate(instruction=question_intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning/computation
        reasoning_instruction = f"""
        Based on the question analysis: {question_analysis}
        Perform the necessary reasoning or computation to answer the question. This may involve:
        - Arithmetic operations (e.g., summing values, finding differences)
        - Comparisons (e.g., determining which value is greater)
        - Selecting specific spans from the text
        Ensure that all steps are clearly documented and justified.
        """
        reasoning_results = await asyncio.gather(
            self.generate(instruction=reasoning_instruction, context=self.problem_text),
            self.generate(instruction=reasoning_instruction, context=self.problem_text)  # Parallel computation
        )

        # Step 4: Validate and refine results
        refinement_instruction = f"""
        Review the following candidate answers: {reasoning_results}
        Validate them against the original passage and question. Specifically:
        - Check for consistency with the extracted information
        - Ensure that the reasoning aligns with the question intent
        - Refine any discrepancies or ambiguities
        Provide a revised and polished final answer.
        """
        refined_answers = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction, context=result) for result in reasoning_results]
        )

        # Step 5: Ensemble final answer
        ensemble_instruction = f"""
        Evaluate the following refined answers: {refined_answers}
        Select the best answer based on:
        - Accuracy and relevance to the question
        - Consistency with the passage and extracted information
        - Clarity and completeness of the reasoning
        Provide the final answer.
        """
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=refined_answers)

        return final_answer