# Workflow ID: drop_294_0
# Benchmark: drop
# Data Indices: [192, 763]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract relevant information from the passage
        extraction_instruction = (
            "Carefully analyze the passage and extract all entities, numerical values, "
            "and their relationships. Ensure you capture every detail that could be relevant "
            "to answering the question. Format your response as a structured list."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its type and required reasoning
        question_analysis_instruction = (
            f"Given the extracted information: {extracted_info}\n"
            "Analyze the question to determine its type (e.g., arithmetic, counting, comparison, selection, span extraction). "
            "Outline the specific reasoning steps needed to answer the question. "
            "Provide a clear classification and plan."
        )
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or calculation based on the question type
        reasoning_instruction = (
            f"Based on the question analysis: {question_analysis}\n"
            "Perform the necessary reasoning or calculations step by step. "
            "Ensure you associate numbers with their corresponding entities correctly. "
            "If the question involves multiple steps, explain each step clearly."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Optional: Explore alternative reasoning paths in parallel
        alternative_reasoning_instruction = (
            f"Explore an alternative approach to solving the question, using the extracted information: {extracted_info}. "
            "Ensure this approach is distinct from the primary reasoning path."
        )
        results = await asyncio.gather(
            self.generate(instruction=reasoning_instruction, context=self.problem_text),
            self.generate(instruction=alternative_reasoning_instruction, context=self.problem_text)
        )

        # Step 4: Validate and refine the results
        refinement_instruction = (
            f"Review the reasoning results: {results}\n"
            "Critique and refine them to ensure accuracy, clarity, and alignment with the question intent. "
            "Correct any errors or ambiguities."
        )
        refined_results = [await self.revise(instruction=refinement_instruction, context=result) for result in results]

        # Step 5: Final answer selection
        final_selection_instruction = (
            f"Compare the refined results: {refined_results}\n"
            "Select the most accurate and relevant answer based on the question requirements. "
            "Provide justification for your choice."
        )
        final_answer = await self.ensemble(instruction=final_selection_instruction, contexts=refined_results)

        return final_answer