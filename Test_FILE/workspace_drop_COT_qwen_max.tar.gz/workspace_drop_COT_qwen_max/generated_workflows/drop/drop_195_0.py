# Workflow ID: drop_195_0
# Benchmark: drop
# Data Indices: [648, 652]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all entities, numerical values, and key relationships
        extraction_instruction = (
            "Thoroughly analyze the provided passage and extract all entities, numerical values, "
            "and their relationships. Ensure no relevant information is missed. Organize the extracted "
            "data into categories such as entities, numbers, and events. Provide clear associations between "
            "numbers and their corresponding entities."
        )
        extraction_task = self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_analysis_instruction = (
            "Carefully analyze the question and determine its intent. Identify whether the question "
            "requires counting, arithmetic operations, comparison, span extraction, or another type of reasoning. "
            "Provide a clear explanation of the reasoning steps needed to answer the question based on the extracted data."
        )
        question_analysis_task = self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Execute extraction and question analysis in parallel
        extraction_result, question_analysis_result = await asyncio.gather(extraction_task, question_analysis_task)

        # Step 3: Perform reasoning or calculation based on the question intent
        reasoning_instruction = (
            f"Using the extracted data:\n{extraction_result}\n"
            f"And the question analysis:\n{question_analysis_result}\n"
            "Perform the necessary reasoning or calculation to answer the question. Follow the reasoning steps "
            "outlined in the question analysis and ensure the answer is accurate and complete. If the question "
            "involves arithmetic, show the calculation steps. If it involves span extraction, provide the exact text."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the answer
        refinement_instruction = (
            f"Review the following answer:\n{reasoning_result}\n"
            "Critique it for accuracy, completeness, and clarity. Refine the answer if necessary, ensuring it "
            "is well-formatted and directly addresses the question. Highlight any assumptions or ambiguities."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Handle ambiguities or edge cases using Ensemble (if needed)
        ambiguity_check_instruction = (
            f"Given the refined answer:\n{refined_answer}\n"
            "Evaluate whether there are any ambiguities or alternative interpretations. If multiple answers "
            "are possible, provide them as separate options. Otherwise, confirm the single best answer."
        )
        ensemble_result = await self.ensemble(
            instruction=ambiguity_check_instruction,
            contexts=[refined_answer]
        )

        # Step 6: Return the final answer
        return ensemble_result