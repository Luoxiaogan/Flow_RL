# Workflow ID: drop_51_0
# Benchmark: drop
# Data Indices: [86, 280]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the passage
        extraction_instruction = (
            "Extract all relevant entities, numbers, dates, and relationships from the passage. "
            "Include all numerical values with their associated entities (e.g., '22.7%' is associated with 'under the age of 18'). "
            "Also, identify any contextual relationships (e.g., 'which team scored how many points')."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_analysis_instruction = (
            f"Analyze the question and determine its intent. Consider the following possibilities:\n"
            "- Does it require arithmetic operations (e.g., addition, subtraction)?\n"
            "- Does it involve comparison (e.g., greater/less)?\n"
            "- Does it require selecting a specific entity or span?\n"
            "Use the following extracted information to guide your analysis:\n{extracted_info}"
        )
        question_intent = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question intent
        reasoning_instruction = (
            f"Based on the question intent analysis:\n{question_intent}\n"
            "Perform the required reasoning using the extracted information:\n{extracted_info}\n"
            "Ensure the reasoning is grounded in the context of the passage."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine the answer
        refinement_instruction = (
            "Refine the following reasoning result to ensure it is concise, accurate, and formatted appropriately:\n"
            f"{reasoning_result}\n"
            "Remove any ambiguity, verify numerical correctness, and ensure proper entity association."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Return the final answer
        return refined_answer