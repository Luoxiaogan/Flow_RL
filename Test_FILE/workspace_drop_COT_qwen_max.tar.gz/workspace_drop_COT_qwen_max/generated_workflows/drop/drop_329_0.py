# Workflow ID: drop_329_0
# Benchmark: drop
# Data Indices: [425, 276]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant entities, numbers, and relationships
        extraction_instruction = """
        Extract all entities, numerical values, and their relationships from the passage. 
        Include details such as who performed actions, what those actions were, and any associated numbers or dates. 
        Ensure no information is missed, even if it seems minor.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_analysis_instruction = f"""
        Analyze the question and determine its intent based on the following categories:
        - Arithmetic Operations: Addition, subtraction, multiplication, division.
        - Counting: How many times something occurred or how many entities are involved.
        - Comparison: Which entity has more/less, greater/smaller, earlier/later.
        - Span Extraction: Identifying specific text spans (names, phrases, etc.) that answer the question.
        Use the extracted information: {extracted_info} to guide your analysis.
        """
        question_intent = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question's intent
        reasoning_instruction = f"""
        Based on the question's intent: {question_intent}, perform the necessary reasoning using the extracted information: {extracted_info}.
        If the question involves arithmetic operations, calculate the result step by step.
        If it involves counting, count the relevant occurrences accurately.
        If it involves comparison, compare the relevant entities or values.
        If it involves span extraction, extract the exact text span that answers the question.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the reasoning result
        refinement_instruction = f"""
        Critique and refine the reasoning result: {reasoning_result}.
        Ensure the answer aligns with the question's intent and the passage's context.
        Correct any inaccuracies or ambiguities.
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Compile the final answer
        final_instruction = f"""
        Summarize the refined answer: {refined_answer} into a concise and clear format.
        Ensure the final output directly answers the question without unnecessary details.
        """
        final_answer = await self.summarize(instruction=final_instruction, context=refined_answer)

        return final_answer