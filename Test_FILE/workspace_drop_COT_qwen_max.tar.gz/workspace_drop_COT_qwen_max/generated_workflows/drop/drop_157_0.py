# Workflow ID: drop_157_0
# Benchmark: drop
# Data Indices: [318, 238]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information from the passage and question
        extraction_instruction = """
        Thoroughly analyze the provided passage and question. Extract ALL relevant information, including:
        - Numerical values and their associated entities or contexts
        - Named entities (people, teams, locations, etc.)
        - Relationships between entities (e.g., "A scored X points against B")
        - Keywords indicating operations (e.g., "total," "difference," "greater than")
        Ensure the extraction is exhaustive and structured for easy reference.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Interpret the question intent
        intent_instruction = f"""
        Using the extracted information: {extracted_info}
        Analyze the question to determine its intent. Specifically:
        - Identify if the question requires arithmetic operations (e.g., sum, difference)
        - Check for comparisons (e.g., "greater than," "less than")
        - Look for counting tasks (e.g., "how many times")
        - Detect span extraction requests (e.g., "who did," "what happened")
        Provide a clear directive on what needs to be computed or identified based on the question.
        """
        question_intent = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Generate multiple reasoning paths in parallel
        arithmetic_instruction = f"""
        Given the extracted information: {extracted_info}
        And the question intent: {question_intent}
        Perform any required arithmetic operations (e.g., addition, subtraction). Provide the result with clear justification.
        """
        comparison_instruction = f"""
        Given the extracted information: {extracted_info}
        And the question intent: {question_intent}
        Perform any required comparisons (e.g., "greater than," "less than"). Provide the result with clear justification.
        """
        span_extraction_instruction = f"""
        Given the extracted information: {extracted_info}
        And the question intent: {question_intent}
        Identify and extract the requested text span (e.g., entity name, phrase). Provide the result with clear justification.
        """

        # Execute reasoning paths in parallel
        reasoning_results = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text),
            self.generate(instruction=span_extraction_instruction, context=self.problem_text)
        )

        # Step 4: Ensemble decision to select the best answer
        ensemble_instruction = f"""
        Evaluate the following candidate answers:
        - Arithmetic Result: {reasoning_results[0]}
        - Comparison Result: {reasoning_results[1]}
        - Span Extraction Result: {reasoning_results[2]}
        Select the most appropriate answer based on the question intent and provide a justification.
        """
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=reasoning_results)

        # Step 5: Optional refinement for clarity and correctness
        refinement_instruction = f"""
        Review the final answer: {final_answer}
        Refine it for clarity, correctness, and completeness. Ensure it directly addresses the question.
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        return refined_answer