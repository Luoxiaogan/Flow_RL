# Workflow ID: drop_97_0
# Benchmark: drop
# Data Indices: [433, 354]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all relevant numerical values and entities
        extraction_instruction = (
            "Extract all numerical values, entities (e.g., names, teams), and their relationships "
            "from the passage. Include counts, measurements, and any other quantitative data."
        )
        extracted_data = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Interpret the question
        question_interpretation_instruction = (
            f"Given the extracted data: {extracted_data}, analyze the question to determine "
            "the type of reasoning required (e.g., counting, arithmetic, comparison). "
            "Identify which entities or values are relevant to answering the question."
        )
        question_analysis = await self.generate(instruction=question_interpretation_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or calculation
        reasoning_instruction = (
            f"Using the extracted data: {extracted_data} and the question analysis: {question_analysis}, "
            "perform the necessary reasoning or calculation to answer the question. "
            "If the question involves counting, count the relevant occurrences. "
            "If it involves arithmetic, perform the required operations (e.g., addition, subtraction)."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the result
        refinement_instruction = (
            f"Critique and refine the reasoning result: {reasoning_result}. "
            "Ensure the answer is accurate and consistent with the passage and question."
        )
        refined_result = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Summarize the final answer
        summarization_instruction = (
            f"Condense the refined result: {refined_result} into a concise final answer. "
            "Ensure the response directly addresses the question and is easy to understand."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_result)

        return final_answer