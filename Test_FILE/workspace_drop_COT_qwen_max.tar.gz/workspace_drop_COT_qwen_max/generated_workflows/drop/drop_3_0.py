# Workflow ID: drop_3_0
# Benchmark: drop
# Data Indices: [287, 396]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant numerical values, entities, and spans
        extraction_instruction = """
        Extract ALL numerical values, dates, entity names, and key phrases from the passage.
        Include their context to ensure proper association with entities.
        Format the output as a structured list for easy reference.
        """
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine the reasoning type
        question_analysis_instruction = f"""
        Analyze the question to determine the type of reasoning required.
        Consider the following categories: arithmetic operations, counting, comparison, selection, span extraction.
        Provide a detailed breakdown of what the question is asking for and how it relates to the extracted information:
        {extraction}
        """
        reasoning_type = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or calculation based on the analysis
        reasoning_instruction = f"""
        Based on the reasoning type identified: {reasoning_type}, perform the necessary calculations or reasoning.
        Use the extracted information: {extraction} to derive the answer.
        Ensure that all steps are clearly explained and justified.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the result
        validation_instruction = f"""
        Validate the reasoning result: {reasoning_result} against the original passage.
        Identify and resolve any ambiguities or inconsistencies.
        Provide a refined version of the result if necessary.
        """
        refined_result = await self.revise(instruction=validation_instruction, context=reasoning_result)

        # Step 5: Final answer selection (if multiple candidates exist)
        final_selection_instruction = f"""
        Evaluate the refined result: {refined_result} and ensure it directly answers the question.
        If multiple candidates exist, select the most coherent and relevant one.
        """
        final_answer = await self.ensemble(instruction=final_selection_instruction, contexts=[refined_result])

        return final_answer