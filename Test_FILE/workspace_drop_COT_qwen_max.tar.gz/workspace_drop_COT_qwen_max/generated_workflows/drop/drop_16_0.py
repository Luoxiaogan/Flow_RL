# Workflow ID: drop_16_0
# Benchmark: drop
# Data Indices: [72, 258]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract question intent and key information
        question_intent = await self.generate(
            instruction="Analyze the question to determine its type (e.g., arithmetic, counting, comparison, span extraction). "
                        "Identify the key entities and data points needed to answer the question.",
            context=self.problem_text
        )

        # Step 2: Extract numerical values, entities, and relationships
        extract_values_task = self.generate(
            instruction="Extract all numerical values and associated entities from the passage. "
                        "For example, if the passage mentions '10-4 Eagles', extract 'Eagles' and '10'.",
            context=self.problem_text
        )
        extract_entities_task = self.generate(
            instruction="Extract all named entities (e.g., teams, players, demographic groups) and their relationships "
                        "from the passage. Ensure each entity is clearly linked to relevant data.",
            context=self.problem_text
        )

        # Run extraction tasks in parallel
        extracted_values, extracted_entities = await asyncio.gather(extract_values_task, extract_entities_task)

        # Step 3: Associate entities with relevant data
        refined_data = await self.revise(
            instruction=f"Refine the extracted information by associating entities with their corresponding data points. "
                        f"Ensure each entity is correctly linked to its numerical values or relationships. "
                        f"Use the following inputs:\nExtracted Values: {extracted_values}\nExtracted Entities: {extracted_entities}",
            context=self.problem_text
        )

        # Step 4: Perform reasoning based on question type
        reasoning_instruction = (
            f"Based on the question intent ({question_intent}), perform the required reasoning. "
            f"If the question involves arithmetic, calculate the result using the provided data. "
            f"If it involves counting, tally the occurrences. For comparisons, evaluate which entity satisfies the condition. "
            f"For span extraction, isolate the relevant text span."
        )
        reasoning_result = await self.generate(
            instruction=reasoning_instruction,
            context=refined_data
        )

        # Step 5: Validate and refine the answer
        refined_answer = await self.revise(
            instruction="Critique the reasoning result to ensure it aligns with the question's intent and is consistent with the passage. "
                        "Resolve any ambiguities or inconsistencies.",
            context=reasoning_result
        )

        # Step 6: Handle multiple interpretations (if necessary)
        candidate_answers = [refined_answer]
        if "multiple interpretations" in refined_answer.lower():
            ensemble_result = await self.ensemble(
                instruction="Evaluate the candidate answers and select the most appropriate one based on the passage and question intent.",
                contexts=candidate_answers
            )
            final_answer = ensemble_result
        else:
            final_answer = refined_answer

        # Step 7: Summarize the final answer
        summary = await self.summarize(
            instruction="Produce a concise, well-formatted final answer based on the refined reasoning result.",
            context=final_answer
        )

        return summary