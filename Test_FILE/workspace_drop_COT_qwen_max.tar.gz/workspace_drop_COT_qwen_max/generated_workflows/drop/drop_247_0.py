# Workflow ID: drop_247_0
# Benchmark: drop
# Data Indices: [61, 538]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract all relevant entities, numbers, and relationships from the passage
        extraction_task = await self.generate(
            instruction="Extract all entities, numerical values, dates, and their relationships from the passage. "
                        "Ensure you capture all mentions of people, places, organizations, events, and any associated data. "
                        "Include contextual clues that link numbers to specific entities or events.",
            context=self.problem_text
        )
        refined_extraction = await self.revise(
            instruction="Review the extracted information for completeness and accuracy. "
                        "Ensure all relevant details are captured and correctly associated with their respective entities.",
            context=extraction_task
        )

        # Step 2: Analyze the question to determine its intent
        question_analysis = await self.generate(
            instruction="Analyze the question to determine its intent. "
                        "Identify whether the question requires arithmetic operations, counting, comparison, selection, or span extraction. "
                        "Provide a clear breakdown of the reasoning steps needed to answer the question.",
            context=self.problem_text
        )

        # Step 3: Perform reasoning based on the question type
        reasoning_tasks = [
            self.generate(
                instruction=f"Given the extracted information: {refined_extraction} and the question analysis: {question_analysis}, "
                            "perform the necessary reasoning steps to compute the answer. "
                            "If the question involves arithmetic, perform the required calculations. "
                            "If it involves counting, tally the relevant occurrences. "
                            "For comparisons, evaluate the relationships between entities. "
                            "For selections, identify the correct entity or event. "
                            "For span extraction, extract the exact text span that answers the question.",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"Double-check the reasoning process using the extracted information: {refined_extraction}. "
                            "Ensure all steps are logically sound and consistent with the passage.",
                context=self.problem_text
            )
        ]
        reasoning_results = await asyncio.gather(*reasoning_tasks)

        # Step 4: Resolve ambiguities and select the best solution
        final_answer = await self.ensemble(
            instruction="Evaluate the reasoning results and select the most accurate and complete solution. "
                        "If there are discrepancies, resolve them by referring back to the passage and the extracted information. "
                        "Ensure the final answer directly addresses the question.",
            contexts=reasoning_results
        )

        # Step 5: Format the final output
        formatted_answer = await self.summarize(
            instruction="Condense the final answer into a concise and clear format. "
                        "Ensure it directly answers the question and matches the expected answer type (number, date, text span, etc.).",
            context=final_answer
        )

        return formatted_answer