# Workflow ID: drop_205_0
# Benchmark: drop
# Data Indices: [606, 571]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract Entities and Numbers
        extract_instruction = (
            "Extract all entities (teams, players, events) and numerical values from the passage. "
            "For each entity, associate it with its context and any related numbers. "
            "Format the output as a structured list."
        )
        entity_extraction_task = self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Analyze the Question
        analyze_instruction = (
            "Analyze the question to determine its type (e.g., arithmetic, comparison, span extraction). "
            "Identify the specific entities and numbers relevant to answering the question. "
            "Provide a detailed breakdown of the question's intent."
        )
        question_analysis_task = self.generate(instruction=analyze_instruction, context=self.problem_text)

        # Execute Steps 1 and 2 in parallel
        entity_extraction, question_analysis = await asyncio.gather(entity_extraction_task, question_analysis_task)

        # Step 3: Reasoning Execution
        reasoning_instruction = (
            f"Based on the extracted entities and numbers:\n{entity_extraction}\n"
            f"And the question analysis:\n{question_analysis}\n"
            "Perform the required reasoning to answer the question. If the question involves arithmetic, "
            "perform the calculation. If it involves comparison, compare the relevant values. "
            "If it requires span extraction, retrieve the exact text span. Format the reasoning step-by-step."
        )
        reasoning_task = self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validation and Refinement
        refine_instruction = (
            "Critique the reasoning and ensure the answer is accurate. If any errors are found, refine the result. "
            "Provide the corrected answer along with an explanation of any changes made."
        )
        refinement_task = self.revise(instruction=refine_instruction, context=await reasoning_task)

        # Step 5: Final Answer Compilation
        summarize_instruction = (
            "Condense the reasoning and refined answer into a clear, concise final answer. "
            "Ensure the output directly addresses the question."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=await refinement_task)

        return final_answer