# Workflow ID: drop_99_0
# Benchmark: drop
# Data Indices: [342, 53]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information from the passage
        extract_instruction = """
        Extract all entities, numerical values, dates, and their relationships from the passage. 
        Identify actions or events associated with these entities and values. 
        Organize the information in a structured format, associating each number or date with its corresponding entity or event.
        """
        extraction_task = self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Analyze the question
        analyze_instruction = """
        Analyze the question to determine the type of reasoning required (e.g., arithmetic, counting, comparison, span extraction). 
        Identify the specific entities, values, or spans referenced in the question. 
        If the question involves numerical reasoning, specify the required operations (e.g., addition, subtraction).
        """
        analysis_task = self.generate(instruction=analyze_instruction, context=self.problem_text)

        # Run extraction and analysis in parallel
        extraction, analysis = await asyncio.gather(extraction_task, analysis_task)

        # Step 3: Construct the solution
        solution_instruction = f"""
        Using the extracted information: {extraction}
        And the question analysis: {analysis}
        Solve the problem step by step. Perform any required arithmetic operations, count occurrences, compare values, or extract spans as needed. 
        Ensure the solution aligns with the question's intent and the passage's context.
        """
        solution = await self.generate(instruction=solution_instruction, context=self.problem_text)

        # Step 4: Validate and refine the solution
        refine_instruction = f"""
        Review the solution: {solution}
        Verify that it correctly answers the question based on the passage. 
        Check for accurate entity-number associations, ensure all relevant information is considered, and confirm that implicit information is handled appropriately.
        Refine the solution if necessary.
        """
        refined_solution = await self.revise(instruction=refine_instruction, context=solution)

        # Step 5: Summarize the final answer
        summarize_instruction = """
        Condense the refined solution into a concise format suitable for submission. 
        Ensure the answer directly addresses the question and is presented clearly.
        """
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_answer