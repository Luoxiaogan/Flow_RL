# Workflow ID: drop_303_0
# Benchmark: drop
# Data Indices: [360, 305]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio
        
        # Step 1: Extract key information from the passage and question
        context_extraction = await self.generate(
            instruction="""Extract all key entities (e.g., players, teams), numerical values, and their relationships from the passage and question. 
            Organize this information into structured categories such as 'Entities', 'Numerical Values', 'Events', and 'Relationships'. 
            Ensure no relevant detail is missed.""",
            context=self.problem_text
        )
        
        # Step 2: Identify the question intent
        question_intent = await self.generate(
            instruction=f"""Analyze the question to determine its intent. Classify the question into one of the following categories: 
            - Counting (e.g., 'How many times...')
            - Arithmetic (e.g., 'What is the total...', 'How many more...')
            - Comparison (e.g., 'Which is greater...', 'Who had more...')
            - Span Extraction (e.g., 'Who did...', 'What was the name of...')
            - Other (specify).
            Provide reasoning for the classification and outline the required steps to answer the question based on the extracted context: {context_extraction}.""",
            context=self.problem_text
        )
        
        # Step 3: Perform reasoning or calculation
        reasoning_result = await self.generate(
            instruction=f"""Based on the identified question intent ({question_intent}), perform the necessary reasoning or calculation. 
            Follow these steps:
            - For counting questions, extract all occurrences of the relevant entity and count them.
            - For arithmetic questions, associate numbers with their respective entities and perform the required operation.
            - For span extraction questions, locate the exact text span that answers the question.
            - For comparison questions, compare the relevant entities or values.
            Ensure the reasoning process is clear and justified.""",
            context=self.problem_text
        )
        
        # Step 4: Validate and refine the answer
        refined_answer = await self.revise(
            instruction="""Critique the generated answer for accuracy and completeness. 
            Cross-reference it with the passage and question to ensure correctness. 
            Refine the answer if necessary, providing justification for any changes.""",
            context=reasoning_result
        )
        
        # Step 5: Final synthesis (if multiple interpretations exist)
        final_answer = await self.ensemble(
            instruction="""Evaluate the refined answer against any alternative interpretations or reasoning paths. 
            Select the most accurate and well-supported answer.""",
            contexts=[refined_answer, reasoning_result]
        )
        
        return final_answer