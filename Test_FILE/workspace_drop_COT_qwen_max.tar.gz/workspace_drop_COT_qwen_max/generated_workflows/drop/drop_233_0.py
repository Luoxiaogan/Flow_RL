# Workflow ID: drop_233_0
# Benchmark: drop
# Data Indices: [759, 694]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all relevant entities, numbers, and relationships
        extraction_instruction = (
            "Extract all entities, numerical values, and their relationships from the passage. "
            "Ensure you capture all potential data points that could be relevant to answering the question. "
            "Format the output as a structured list of key-value pairs where keys are entities or events, "
            "and values are associated numbers or descriptions."
        )
        extracted_data = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its type and requirements
        question_analysis_instruction = (
            f"Given the extracted data: {extracted_data}, analyze the question to determine its type. "
            "Identify whether it requires arithmetic operations, counting, comparison, selection, or span extraction. "
            "Output the type of question and any specific constraints or requirements."
        )
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or calculation based on the question type
        reasoning_instruction = (
            f"Based on the question analysis: {question_analysis}, perform the required reasoning or calculation. "
            "If the question involves arithmetic operations, perform the necessary calculations. "
            "If it involves counting, count the occurrences of the specified entities or events. "
            "If it involves comparison, compare the relevant values or entities. "
            "Ensure the output is accurate and clearly explains the reasoning process."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the reasoning result
        refinement_instruction = (
            f"Critique and refine the reasoning result: {reasoning_result}. "
            "Check for any errors, ambiguities, or inconsistencies. "
            "Ensure the final output is accurate and directly addresses the question."
        )
        refined_result = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Summarize the refined result into a concise final answer
        summarization_instruction = (
            f"Summarize the refined result: {refined_result} into a concise final answer. "
            "Ensure the output is clear, direct, and fully addresses the question."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_result)

        return final_answer