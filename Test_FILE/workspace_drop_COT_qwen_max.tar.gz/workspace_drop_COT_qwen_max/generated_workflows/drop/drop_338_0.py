# Workflow ID: drop_338_0
# Benchmark: drop
# Data Indices: [174, 742]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the passage
        extraction_instruction = (
            "Extract all entities, numerical values, and their relationships from the passage. "
            "Ensure you capture every detail that could be relevant to answering a question about the passage."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_analysis_instruction = (
            f"Given the extracted information: {extracted_info}\n"
            "Analyze the question to determine its type and intent. "
            "Identify whether the question requires arithmetic operations, counting, comparison, selection, or span extraction. "
            "Provide clear reasoning for your conclusion."
        )
        question_intent = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Generate potential solutions based on the question type
        solution_instructions = []
        if "arithmetic" in question_intent.lower():
            solution_instructions.append(
                "Perform all possible arithmetic operations (addition, subtraction, etc.) using the extracted numerical values. "
                "Explain each calculation step-by-step."
            )
        if "counting" in question_intent.lower():
            solution_instructions.append(
                "Count the occurrences of specific entities or events mentioned in the question. "
                "Provide a detailed breakdown of your counting process."
            )
        if "comparison" in question_intent.lower():
            solution_instructions.append(
                "Compare the numerical values or attributes of different entities. "
                "Clearly state which entity is greater, longer, more, etc."
            )
        if "selection" in question_intent.lower():
            solution_instructions.append(
                "Identify the correct entity, event, or attribute based on the question. "
                "Justify your selection with evidence from the passage."
            )
        if "span extraction" in question_intent.lower():
            solution_instructions.append(
                "Extract the relevant text span that answers the question. "
                "Ensure the span is precise and directly addresses the question."
            )

        # Execute potential solutions in parallel
        potential_solutions = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in solution_instructions]
        )

        # Step 4: Ensemble decision-making to select the best solution
        ensemble_instruction = (
            "Evaluate the following candidate solutions and select the most accurate and contextually appropriate answer. "
            "Provide a justification for your choice."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=potential_solutions)

        # Step 5: Refine the final answer
        refinement_instruction = (
            "Refine the provided answer to ensure it is precise, well-formulated, and directly addresses the question. "
            "Correct any errors or ambiguities."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        return refined_answer