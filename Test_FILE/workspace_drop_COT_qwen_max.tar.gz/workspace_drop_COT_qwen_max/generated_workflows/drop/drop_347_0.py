# Workflow ID: drop_347_0
# Benchmark: drop
# Data Indices: [199, 284]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract entities and numerical values
        extract_entities_instruction = (
            "Extract all entities (e.g., players, teams) and numerical values (e.g., distances, scores) "
            "from the passage. Organize them into a structured format where each entity is associated "
            "with its corresponding numerical values or actions."
        )
        extract_entities_task = self.generate(instruction=extract_entities_instruction, context=self.problem_text)

        # Step 2: Analyze the question
        analyze_question_instruction = (
            "Analyze the question to determine its type (e.g., arithmetic, counting, comparison, span extraction). "
            "Identify the key components of the question, such as the target entity, action, or numerical operation."
        )
        analyze_question_task = self.generate(instruction=analyze_question_instruction, context=self.problem_text)

        # Run extraction and analysis in parallel
        entities, question_analysis = await asyncio.gather(extract_entities_task, analyze_question_task)

        # Step 3: Perform reasoning or calculation
        reasoning_instruction = (
            f"Based on the extracted entities and question analysis:\n"
            f"Entities: {entities}\n"
            f"Question Analysis: {question_analysis}\n"
            "Perform the required reasoning or calculation to answer the question. "
            "For numerical questions, filter and compare values. For span extraction questions, "
            "match entities to actions described in the passage."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine the answer
        refine_instruction = (
            f"Refine the following reasoning result to ensure it is concise and directly addresses the question:\n"
            f"{reasoning_result}\n"
            "Validate that the answer aligns with the extracted information and question intent."
        )
        refined_answer = await self.revise(instruction=refine_instruction, context=reasoning_result)

        # Step 5: Summarize the final answer
        summarize_instruction = (
            f"Condense the refined answer into a clear and concise format suitable for the question:\n"
            f"{refined_answer}"
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_answer)

        return final_answer