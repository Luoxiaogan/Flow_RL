# Workflow ID: drop_312_0
# Benchmark: drop
# Data Indices: [112, 414]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract and understand the key components of the problem
        problem_understanding = await self.generate(
            instruction="Analyze the passage and question. Identify the main entities, numerical values, and the type of reasoning required (e.g., arithmetic, counting, comparison, span extraction).",
            context=self.problem_text
        )

        # Step 2: Classify the reasoning pattern and extract relevant information
        reasoning_pattern = await self.generate(
            instruction=f"Based on the analysis: {problem_understanding}, determine the specific reasoning pattern required to answer the question. Examples include 'sum', 'difference', 'count', 'comparison', or 'span extraction'.",
            context=self.problem_text
        )

        # Parallel extraction of relevant entities and numerical values
        entities_extraction = self.generate(
            instruction=f"Extract all entities mentioned in the passage that are relevant to the question. Use the reasoning pattern: {reasoning_pattern}.",
            context=self.problem_text
        )
        numerical_extraction = self.generate(
            instruction=f"Extract all numerical values from the passage that are relevant to the question. Use the reasoning pattern: {reasoning_pattern}.",
            context=self.problem_text
        )
        extraction_results = await asyncio.gather(entities_extraction, numerical_extraction)
        entities, numerical_values = extraction_results

        # Step 3: Perform the reasoning based on the identified pattern
        reasoning_result = await self.generate(
            instruction=f"Using the reasoning pattern: {reasoning_pattern}, and the extracted entities: {entities}, and numerical values: {numerical_values}, perform the required operation to answer the question.",
            context=self.problem_text
        )

        # Step 4: Synthesize the final answer
        final_answer = await self.summarize(
            instruction="Condense the reasoning result into a concise and clear answer to the question.",
            context=reasoning_result
        )

        # Optional refinement step if the answer seems ambiguous or incomplete
        refined_answer = await self.revise(
            instruction="Review the final answer and refine it if necessary. Ensure clarity, accuracy, and completeness.",
            context=final_answer
        )

        return refined_answer