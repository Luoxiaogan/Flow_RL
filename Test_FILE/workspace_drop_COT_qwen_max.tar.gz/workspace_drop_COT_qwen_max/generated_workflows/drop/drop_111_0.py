# Workflow ID: drop_111_0
# Benchmark: drop
# Data Indices: [381, 158]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all relevant information from the passage
        extraction_instruction = (
            "Extract all numerical values, entities, and their relationships from the passage. "
            "Include any implicit information that can be inferred from the context. "
            "Format the output as a structured list of key-value pairs where keys are entities "
            "and values are associated numbers or descriptions."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_intent_instruction = (
            f"Given the extracted information: {extracted_info}, analyze the question to determine its intent. "
            "Classify the question into one of the following categories: "
            "arithmetic operation (e.g., addition, subtraction), counting, comparison, span extraction. "
            "Provide a detailed explanation of the reasoning process."
        )
        question_intent = await self.generate(instruction=question_intent_instruction, context=self.problem_text)

        # Step 3: Perform the core reasoning based on the question intent
        reasoning_instruction = (
            f"Based on the question intent: {question_intent}, perform the required reasoning using the extracted information: {extracted_info}. "
            "If the question involves arithmetic operations, calculate the result step by step. "
            "If it involves counting, count the relevant occurrences. "
            "If it involves comparison, compare the relevant numerical values. "
            "If it involves span extraction, identify the exact text span from the passage. "
            "Provide a detailed breakdown of the reasoning process."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the result
        validation_instruction = (
            f"Validate the reasoning result: {reasoning_result} against the original passage. "
            "Check for completeness, correctness, and alignment with the question intent. "
            "If any issues are found, refine the result accordingly."
        )
        refined_result = await self.revise(instruction=validation_instruction, context=reasoning_result)

        # Step 5: Compile the final answer
        final_answer_instruction = (
            f"Compile the refined result: {refined_result} into a concise answer format. "
            "Ensure the answer directly addresses the question and is presented in a clear, unambiguous manner."
        )
        final_answer = await self.generate(instruction=final_answer_instruction, context=self.problem_text)

        return final_answer