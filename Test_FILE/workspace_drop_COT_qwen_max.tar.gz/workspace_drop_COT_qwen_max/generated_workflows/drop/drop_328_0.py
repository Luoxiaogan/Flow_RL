# Workflow ID: drop_328_0
# Benchmark: drop
# Data Indices: [520, 393]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract key information from the passage and question
        extraction_instruction = (
            "Analyze the passage and question to identify all relevant entities, numbers, and relationships. "
            "Determine what the question is asking and categorize the reasoning type (e.g., counting, arithmetic, comparison, span extraction)."
        )
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Refine the extracted information
        refinement_instruction = (
            f"Review the following extracted information: {extraction}. "
            "Ensure it accurately captures the key details from the passage and aligns with the question intent. "
            "Clarify any ambiguities or missing details."
        )
        refined_info = await self.revise(instruction=refinement_instruction, context=extraction)

        # Step 3: Perform reasoning based on the identified type
        reasoning_type_instruction = (
            f"Based on the refined information: {refined_info}, determine the reasoning type and perform the necessary computation. "
            "For counting or arithmetic operations, calculate the result. "
            "For comparisons, evaluate the options. "
            "For span extraction, isolate the relevant text."
        )
        reasoning_result = await self.generate(instruction=reasoning_type_instruction, context=self.problem_text)

        # Step 4: Handle ambiguous cases with Ensemble
        ensemble_instruction = (
            f"Evaluate the following reasoning result: {reasoning_result}. "
            "If there are multiple interpretations or solutions, synthesize the best option."
        )
        ensemble_result = await self.ensemble(instruction=ensemble_instruction, contexts=[reasoning_result])

        # Step 5: Finalize the answer
        final_instruction = (
            f"Combine the refined information: {refined_info} and the ensemble result: {ensemble_result}. "
            "Generate a clear and concise final answer that directly addresses the question."
        )
        final_answer = await self.revise(instruction=final_instruction, context=ensemble_result)

        return final_answer