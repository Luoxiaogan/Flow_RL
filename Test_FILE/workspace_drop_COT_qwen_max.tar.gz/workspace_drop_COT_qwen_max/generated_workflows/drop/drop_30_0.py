# Workflow ID: drop_30_0
# Benchmark: drop
# Data Indices: [430, 356]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract relevant entities, numbers, and relationships
        extraction_instruction = """
        Extract all relevant entities, numerical values, and their relationships from the passage. 
        Include counts, dates, names, and any other information that could be relevant to answering questions. 
        Format the output as a structured list for easy reference.
        """
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_intent_instruction = f"""
        Analyze the question to determine its intent. Identify whether the question requires counting, arithmetic operations, comparisons, span extraction, or another type of reasoning. 
        Use the following extracted information as context: {extraction}.
        Provide a clear explanation of the reasoning process needed to answer the question.
        """
        question_intent = await self.generate(instruction=question_intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question intent
        reasoning_instruction = f"""
        Based on the question intent and the extracted information, perform the required reasoning to answer the question. 
        Follow these steps:
        1. Clearly identify the entities and numbers involved.
        2. Apply the appropriate reasoning (e.g., count occurrences, perform arithmetic, compare values, extract spans).
        3. Provide a detailed explanation of the reasoning process.
        Extracted Information: {extraction}
        Question Intent: {question_intent}
        """
        reasoning = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine the reasoning result
        refinement_instruction = f"""
        Critique and refine the reasoning result to ensure accuracy and alignment with the passage and question. 
        Check for errors in entity-number association, arithmetic, or logical consistency. 
        Provide a revised version of the reasoning result.
        Original Reasoning: {reasoning}
        """
        refined_reasoning = await self.revise(instruction=refinement_instruction, context=reasoning)

        # Step 5: Summarize the refined reasoning into a concise answer
        summary_instruction = f"""
        Condense the refined reasoning into a concise answer that directly addresses the question. 
        Ensure the answer is clear, accurate, and supported by the passage. 
        Refined Reasoning: {refined_reasoning}
        """
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_reasoning)

        # Step 6: Handle ambiguity with Ensemble (if necessary)
        ensemble_instruction = f"""
        Evaluate the final answer and determine if there are any ambiguities or alternative interpretations. 
        If multiple plausible answers exist, synthesize or select the best candidate based on the passage and question.
        Final Answer: {final_answer}
        """
        contexts = [final_answer]
        ambiguous_check = await self.generate(instruction=ensemble_instruction, context=self.problem_text)
        if "ambiguity" in ambiguous_check.lower():
            final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=contexts)

        return final_answer