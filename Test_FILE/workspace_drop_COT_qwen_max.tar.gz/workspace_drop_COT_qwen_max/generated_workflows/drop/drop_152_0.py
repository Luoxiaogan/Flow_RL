# Workflow ID: drop_152_0
# Benchmark: drop
# Data Indices: [161, 699]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract relevant information from the passage
        extraction_instruction = (
            "Extract all entities, numerical values, and relationships from the passage "
            "that could be relevant to answering the question. Organize them by type "
            "(e.g., field goals, touchdowns, players, scores) and associate each value "
            "with its corresponding entity or event."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine reasoning type
        reasoning_instruction = (
            "Analyze the question to determine the type of reasoning required. "
            "Classify the question as one of the following types: counting, arithmetic, comparison, span extraction. "
            "Provide a detailed reasoning plan based on the classification."
        )
        reasoning_plan = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the identified type
        reasoning_tasks = []
        if "counting" in reasoning_plan.lower():
            counting_instruction = (
                f"Based on the extracted information: {extracted_info}, count the number of relevant occurrences "
                "or events specified in the question. Provide the total count."
            )
            reasoning_tasks.append(self.generate(instruction=counting_instruction, context=self.problem_text))
        elif "arithmetic" in reasoning_plan.lower():
            arithmetic_instruction = (
                f"Using the extracted information: {extracted_info}, perform the required arithmetic operation "
                "(addition, subtraction, etc.) to compute the answer. Show your work step by step."
            )
            reasoning_tasks.append(self.generate(instruction=arithmetic_instruction, context=self.problem_text))
        elif "comparison" in reasoning_plan.lower():
            comparison_instruction = (
                f"Compare the relevant entities or values from the extracted information: {extracted_info}. "
                "Determine which is greater, longer, or more as specified in the question."
            )
            reasoning_tasks.append(self.generate(instruction=comparison_instruction, context=self.problem_text))
        elif "span extraction" in reasoning_plan.lower():
            span_extraction_instruction = (
                f"Identify the exact text span from the passage that answers the question. "
                "Ensure the span is concise and directly addresses the query."
            )
            reasoning_tasks.append(self.generate(instruction=span_extraction_instruction, context=self.problem_text))

        # Execute reasoning tasks in parallel
        reasoning_results = await asyncio.gather(*reasoning_tasks)

        # Step 4: Refine and validate the answer
        refinement_instruction = (
            "Review the reasoning results and refine the answer to ensure it is accurate, concise, "
            "and directly addresses the question. Correct any inconsistencies or ambiguities."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context="\n".join(reasoning_results))

        # Step 5: Output the final answer
        final_instruction = (
            "Condense the refined answer into a clear and concise response that directly answers the question. "
            "Ensure the format matches the expected answer type (number, date, text span, etc.)."
        )
        final_answer = await self.summarize(instruction=final_instruction, context=refined_answer)

        return final_answer