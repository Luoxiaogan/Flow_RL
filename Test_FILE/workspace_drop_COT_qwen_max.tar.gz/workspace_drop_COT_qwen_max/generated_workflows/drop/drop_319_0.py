# Workflow ID: drop_319_0
# Benchmark: drop
# Data Indices: [78, 739]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (entities, numbers, spans, etc.)
        extraction_instruction = """
        Thoroughly analyze the passage and question to extract ALL relevant information. 
        This includes:
        - Entities (people, teams, organizations, etc.)
        - Numbers (with their associated context)
        - Dates and time-related information
        - Key phrases or spans that might directly answer the question
        Ensure no relevant detail is missed. Format the output as a structured list.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Understand the question intent and classify it
        classification_instruction = f"""
        Based on the extracted information: {extracted_info}
        Determine the type of question being asked. Classify it into one of the following categories:
        - Arithmetic (addition, subtraction, multiplication, division)
        - Counting (how many times, how many different)
        - Comparison (greater than, less than, longest, shortest)
        - Selection (which team, who did, what happened first/last)
        - Span Extraction (directly extract a phrase or entity)
        Provide a detailed explanation of the reasoning behind the classification.
        """
        question_intent = await self.generate(instruction=classification_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question type
        reasoning_instruction = f"""
        Using the extracted information: {extracted_info}
        And the determined question intent: {question_intent}
        Perform the necessary reasoning steps to arrive at the answer. 
        For example:
        - If the question is arithmetic, perform the required calculations.
        - If the question is counting, count the relevant occurrences.
        - If the question is comparative, compare the relevant values.
        - If the question is selection-based, identify the correct entity or event.
        - If the question requires span extraction, extract the exact span.
        Provide a step-by-step breakdown of the reasoning process.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine the reasoning result
        refinement_instruction = f"""
        Critique and refine the following reasoning result: {reasoning_result}
        Ensure:
        - All steps are logically sound
        - No relevant information is overlooked
        - The final answer aligns with the question intent
        Provide the refined reasoning and final answer.
        """
        refined_result = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Final answer assembly
        final_answer_instruction = f"""
        Summarize the refined reasoning result: {refined_result}
        Present the final answer in a clear and concise format, ensuring it directly addresses the question.
        """
        final_answer = await self.summarize(instruction=final_answer_instruction, context=refined_result)

        return final_answer