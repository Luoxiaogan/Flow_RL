# Workflow ID: drop_79_0
# Benchmark: drop
# Data Indices: [670, 310]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract question intent and relevant entities/values
        question_intent = await self.generate(
            instruction="""
            Analyze the question and determine its intent. Identify whether the question requires:
            - Arithmetic operations (e.g., addition, subtraction, multiplication, division)
            - Counting occurrences of specific entities or events
            - Comparison between entities or values
            - Span extraction (e.g., names, phrases, or specific text segments)
            - Multi-hop reasoning (combining information from multiple parts of the passage)
            
            Additionally, extract all relevant entities, numerical values, or text spans from the passage that may help answer the question. Ensure you capture ALL instances, even if they seem ambiguous or repetitive.
            """,
            context=self.problem_text
        )

        # Step 2: Associate entities with their corresponding values/spans
        entity_association = await self.generate(
            instruction=f"""
            Using the extracted information: {question_intent}
            Match each entity or event with its corresponding numerical value or text span from the passage. Ensure correct associations by considering context and proximity within the passage. If there are multiple similar entities, clearly distinguish them based on additional descriptors or context clues.
            """,
            context=self.problem_text
        )

        # Step 3: Perform reasoning and calculation
        reasoning_result = await self.generate(
            instruction=f"""
            Based on the question intent and entity-value associations: {entity_association}
            Perform the required reasoning or calculation step-by-step:
            - For arithmetic operations, compute the result using the associated numerical values.
            - For counting, tally the occurrences of the specified entities or events.
            - For comparisons, determine which entity or value satisfies the comparison criteria.
            - For span extraction, identify the exact text span that answers the question.
            - For multi-hop reasoning, combine information from multiple parts of the passage to derive the answer.
            
            Provide a detailed explanation of your reasoning process.
            """,
            context=self.problem_text
        )

        # Step 4: Validate and refine the reasoning
        refined_result = await self.revise(
            instruction="""
            Review the reasoning process and result provided. Check for:
            - Correctness of calculations or counts
            - Accuracy of entity-value associations
            - Logical consistency of multi-hop reasoning
            - Ambiguities or missing information that could affect the answer
            
            Refine the result if necessary, providing corrections or clarifications.
            """,
            context=reasoning_result
        )

        # Step 5: Summarize the final answer
        final_answer = await self.summarize(
            instruction="""
            Condense the reasoning process and result into a concise final answer that directly addresses the question. Ensure the answer is clear, unambiguous, and formatted appropriately (e.g., numerical value, text span, comparative statement).
            """,
            context=refined_result
        )

        return final_answer