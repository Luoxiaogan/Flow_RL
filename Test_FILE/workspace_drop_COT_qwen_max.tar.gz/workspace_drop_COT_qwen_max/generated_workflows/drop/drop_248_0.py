# Workflow ID: drop_248_0
# Benchmark: drop
# Data Indices: [504, 752]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract Key Information
        extraction_instruction = (
            "Extract all relevant numerical values, entities, and relationships from the passage. "
            "Focus on information that could be related to the question. "
            "For example, extract counts, dates, names, and any associated context."
        )
        extracted_data = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Understand Question Intent
        question_intent_instruction = (
            "Analyze the question and determine its intent. "
            "Identify whether the question requires arithmetic operations (e.g., addition, subtraction), "
            "counting, comparison, span extraction, or multi-hop inference. "
            "Provide a clear explanation of the reasoning task required."
        )
        question_intent = await self.generate(instruction=question_intent_instruction, context=self.problem_text)

        # Step 3: Perform Reasoning
        reasoning_instruction = (
            f"Using the extracted data: {extracted_data}\n"
            f"And the question intent: {question_intent}\n"
            "Perform the required reasoning to answer the question. "
            "This may involve arithmetic calculations, entity tracking, or multi-hop inference. "
            "Ensure all steps are clearly explained and justified."
        )
        reasoning_output = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine and Validate
        refinement_instruction = (
            "Critique and refine the reasoning output. "
            "Check for accuracy, completeness, and logical consistency. "
            "Correct any errors or ambiguities in the reasoning process."
        )
        refined_output = await self.revise(instruction=refinement_instruction, context=reasoning_output)

        # Step 5: Final Answer Synthesis
        synthesis_instruction = (
            "Condense the refined reasoning into a concise final answer. "
            "Ensure the answer directly addresses the question and is presented clearly."
        )
        final_answer = await self.summarize(instruction=synthesis_instruction, context=refined_output)

        return final_answer