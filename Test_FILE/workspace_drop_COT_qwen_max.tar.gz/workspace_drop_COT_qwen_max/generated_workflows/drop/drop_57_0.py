# Workflow ID: drop_57_0
# Benchmark: drop
# Data Indices: [347, 65]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant numerical data and entities
        extraction_instruction = (
            "Extract all numerical values, dates, and entities from the passage. "
            "Include any contextual information that associates these values with specific events, people, or objects. "
            "Format the output as a list of key-value pairs where the key is the entity/event and the value is the associated number/date."
        )
        extracted_data = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine reasoning type
        question_intent_instruction = (
            f"Given the extracted data: {extracted_data}, analyze the question to determine the type of reasoning required. "
            "Identify whether the question involves arithmetic operations (addition, subtraction, etc.), counting, comparison, selection, or span extraction. "
            "Provide a clear description of the reasoning steps needed to answer the question."
        )
        reasoning_plan = await self.generate(instruction=question_intent_instruction, context=self.problem_text)

        # Step 3: Associate numbers with entities/events
        association_instruction = (
            f"Using the extracted data: {extracted_data}, associate each numerical value with its corresponding entity or event. "
            "Ensure that ambiguous references are resolved by cross-referencing the passage. "
            "Provide a detailed mapping of entities to their associated values."
        )
        entity_value_mapping = await self.generate(instruction=association_instruction, context=self.problem_text)

        # Step 4: Execute reasoning steps
        reasoning_execution_instruction = (
            f"Based on the reasoning plan: {reasoning_plan} and the entity-value mapping: {entity_value_mapping}, "
            "perform the necessary calculations or comparisons to answer the question. "
            "Show all intermediate steps and ensure correctness by verifying each operation against the passage."
        )
        reasoning_result = await self.generate(instruction=reasoning_execution_instruction, context=self.problem_text)

        # Step 5: Synthesize the final answer
        synthesis_instruction = (
            f"Summarize the reasoning steps: {reasoning_result} and provide the final answer in the required format. "
            "If multiple interpretations are possible, evaluate each option and select the most appropriate one."
        )
        final_answer = await self.generate(instruction=synthesis_instruction, context=self.problem_text)

        return final_answer