# Workflow ID: drop_301_0
# Benchmark: drop
# Data Indices: [204, 697]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information
        extraction_instruction = """
        Carefully analyze the provided passage and question. Extract all entities, numbers, and relationships that could be relevant to answering the question. Include:
        - All numerical values mentioned in the passage
        - The entities (people, teams, events) associated with these numbers
        - Any actions or events described in the passage
        - Contextual clues that link numbers to specific entities or events
        Ensure that the extraction is exhaustive and includes ALL potential candidates, even if their relevance is uncertain.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Associate numbers with entities
        association_instruction = f"""
        Using the extracted information: {extracted_info}
        Associate each numerical value with its corresponding entity or event. For example:
        - Link "3-yard TD run" to the correct player or team
        - Identify which numbers correspond to defensive touchdowns, field goals, etc.
        Provide a clear mapping of numbers to entities, ensuring no ambiguity remains.
        """
        associated_info = await self.generate(instruction=association_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question type
        reasoning_instruction = f"""
        Based on the associated information: {associated_info}
        Analyze the question and determine the required reasoning operation:
        - For counting questions, count the occurrences of the specified entity or event
        - For arithmetic questions, perform the required calculation (addition, subtraction, etc.)
        - For comparison questions, compare the relevant values and determine the correct answer
        - For span extraction, identify the exact text span that answers the question
        Ensure the reasoning process is thorough and explicitly state the final result.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Summarize the final answer
        summary_instruction = """
        Condense the reasoning result into a concise and clear answer. Ensure the output directly addresses the question and is easy to understand.
        """
        final_answer = await self.summarize(instruction=summary_instruction, context=reasoning_result)

        return final_answer