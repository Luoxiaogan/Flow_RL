# Workflow ID: drop_238_0
# Benchmark: drop
# Data Indices: [237, 655]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Understand the question and passage context
        understanding_instruction = """
        Analyze the provided passage and question thoroughly. Identify the type of question being asked (e.g., arithmetic operation, counting, comparison, selection, span extraction). 
        Highlight the key entities, numbers, and relationships mentioned in the passage that are relevant to answering the question. 
        Provide a detailed breakdown of the question's intent and the corresponding parts of the passage that need to be considered.
        """
        understanding_result = await self.generate(instruction=understanding_instruction, context=self.problem_text)

        # Step 2: Extract relevant information
        extraction_instruction = f"""
        Based on the following analysis: {understanding_result}
        Extract all relevant numerical values, entities, and contextual clues from the passage. Ensure that each number is correctly associated with its corresponding entity or event. 
        Organize the extracted information in a structured format, such as a list or table, for easy reference in subsequent steps.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 3: Perform reasoning and calculations
        reasoning_instruction = f"""
        Using the extracted information: {extracted_info}
        Perform the necessary reasoning or calculations to answer the question. If the question involves arithmetic operations, count occurrences, compare values, or select specific spans of text, provide a step-by-step explanation of how you arrived at the answer. 
        Ensure that your reasoning is clear and well-supported by the passage.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the answer
        refinement_instruction = f"""
        Review the following reasoning and answer: {reasoning_result}
        Identify any ambiguities, errors, or missing details in the reasoning process. Refine the answer to ensure it is accurate, complete, and well-supported by the passage. 
        If necessary, revise the reasoning steps to address any issues identified.
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Summarize the final answer
        summary_instruction = """
        Condense the final answer into a concise and clear format. Ensure that the answer directly addresses the question and is supported by the passage. 
        If the question requires a specific format (e.g., a number, a text span), ensure that the answer adheres to that format.
        """
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_answer)

        return final_answer