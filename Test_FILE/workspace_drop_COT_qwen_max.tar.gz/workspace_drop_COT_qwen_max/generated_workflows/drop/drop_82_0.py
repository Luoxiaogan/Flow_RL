# Workflow ID: drop_82_0
# Benchmark: drop
# Data Indices: [278, 0]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract relevant information from the passage and question
        extraction_instruction = """
        Analyze the provided passage and question to identify:
        - All entities mentioned (e.g., teams, players, demographic groups).
        - All numerical values and their associated entities.
        - Key relationships and contextual clues.
        - The specific intent of the question (e.g., arithmetic, counting, comparison, span extraction).
        Format the output as a structured summary.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate reasoning paths in parallel
        arithmetic_instruction = f"""
        Using the extracted information: {extracted_info}
        Perform any necessary arithmetic operations (e.g., addition, subtraction) to answer the question.
        Clearly show the calculation steps and the final result.
        """
        counting_instruction = f"""
        Using the extracted information: {extracted_info}
        Count the occurrences of relevant events or entities mentioned in the question.
        Provide the count and explain how it was derived.
        """
        comparison_instruction = f"""
        Using the extracted information: {extracted_info}
        Compare the relevant entities or values as specified in the question.
        Clearly state which is greater/lesser or if they are equal.
        """
        span_extraction_instruction = f"""
        Using the extracted information: {extracted_info}
        Extract the relevant span or phrase from the passage that answers the question.
        Ensure the extracted span directly addresses the question.
        """

        # Execute reasoning paths in parallel
        reasoning_results = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=counting_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text),
            self.generate(instruction=span_extraction_instruction, context=self.problem_text)
        )

        # Step 3: Ensemble to select the best solution
        ensemble_instruction = """
        Evaluate the following candidate solutions and select the one that best answers the question.
        Consider the accuracy, relevance, and completeness of each solution.
        """
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=reasoning_results)

        # Step 4: Refine the final solution
        refinement_instruction = """
        Critique and refine the provided solution to ensure correctness and clarity.
        Address any ambiguities or inconsistencies.
        """
        refined_solution = await self.revise(instruction=refinement_instruction, context=final_solution)

        return refined_solution