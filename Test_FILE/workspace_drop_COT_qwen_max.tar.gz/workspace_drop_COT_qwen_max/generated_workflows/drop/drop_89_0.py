# Workflow ID: drop_89_0
# Benchmark: drop
# Data Indices: [119, 548]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Initial Analysis - Extract key information
        extraction_instruction = (
            "Carefully analyze the passage and question. "
            "Identify all entities, numerical values, temporal references, and their relationships. "
            "Focus on understanding the intent of the question and extracting relevant spans or numbers."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Entity-Value Association - Refine extracted information
        refinement_instruction = (
            f"Refine the following extracted information: {extracted_info}. "
            "Ensure that numerical values or spans are correctly associated with their corresponding entities. "
            "Resolve any ambiguities or pronoun references by linking them to the correct entities."
        )
        refined_info = await self.revise(instruction=refinement_instruction, context=extracted_info)

        # Step 3: Reasoning and Calculation - Perform the required reasoning
        reasoning_instruction = (
            f"Based on the refined information: {refined_info}, "
            "perform the reasoning required by the question. "
            "This may involve arithmetic operations, comparisons, or selecting specific spans. "
            "Clearly explain your reasoning steps and provide the final answer."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=refined_info)

        # Step 4: Final Answer Validation - Validate and finalize the answer
        validation_instruction = (
            "Evaluate the reasoning result and ensure it is accurate and complete. "
            "If there are multiple plausible answers, select the best one based on the context."
        )
        final_answer = await self.ensemble(instruction=validation_instruction, contexts=[refined_info, reasoning_result])

        return final_answer