# Workflow ID: drop_95_0
# Benchmark: drop
# Data Indices: [595, 773]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Analyze the question to determine its type
        question_analysis = await self.generate(
            instruction="Analyze the question to determine its type. "
                        "Identify whether it requires arithmetic operations (addition, subtraction, etc.), "
                        "counting, comparison, selection, or span extraction. "
                        "Provide a clear explanation of the question type and any specific requirements.",
            context=self.problem_text
        )

        # Step 2: Extract relevant information from the passage
        info_extraction = await self.generate(
            instruction=f"Based on the following question analysis: {question_analysis}, "
                        "extract all relevant information from the passage. "
                        "Include numerical values, entities, dates, or spans of text that are pertinent to answering the question. "
                        "Ensure no relevant details are missed and associate numbers with their corresponding entities.",
            context=self.problem_text
        )

        # Step 3: Perform reasoning and calculation
        reasoning_result = await self.generate(
            instruction=f"Using the extracted information: {info_extraction}, "
                        "perform the necessary reasoning steps to answer the question. "
                        "If the question involves arithmetic, calculate the required value. "
                        "If it involves span extraction, identify the exact text span. "
                        "Ensure the reasoning process is clear and logical.",
            context=self.problem_text
        )

        # Step 4: Validate and refine the answer
        refined_answer = await self.revise(
            instruction="Critically evaluate the following reasoning result: "
                        f"{reasoning_result}. "
                        "Check for consistency, resolve any ambiguities, and ensure the answer aligns with the passage and question. "
                        "Refine the answer if necessary.",
            context=self.problem_text
        )

        # Step 5: Compile the final answer
        final_answer = await self.summarize(
            instruction="Condense the following refined answer into a concise, final response: "
                        f"{refined_answer}. "
                        "Ensure the final answer directly addresses the question and is in the required format.",
            context=self.problem_text
        )

        return final_answer