# Workflow ID: drop_266_0
# Benchmark: drop
# Data Indices: [537, 786]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant entities, numerical values, and relationships
        extraction_instruction = """
        Analyze the provided passage and extract ALL relevant entities, numerical values, and their relationships. 
        Ensure that you associate each value with its corresponding entity or action. 
        Include any implicit information that can be inferred from the context. 
        Format your output as a structured list or table for clarity.
        """
        extracted_data = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Interpret the question and determine its intent
        question_interpretation_instruction = f"""
        Given the following extracted data: {extracted_data}
        Analyze the question and determine its intent. Specifically:
        - Identify whether the question requires arithmetic operations, counting, comparison, span extraction, or other reasoning.
        - Specify the exact entities, values, or spans involved in answering the question.
        - Provide a clear plan for how to proceed with solving the question based on its intent.
        """
        question_analysis = await self.generate(instruction=question_interpretation_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or calculation based on the question's intent
        reasoning_instruction = f"""
        Based on the following question analysis: {question_analysis}
        Perform the necessary reasoning or calculation to answer the question. Follow these steps:
        - If the question involves arithmetic operations, compute the required sum, difference, or comparison.
        - If the question involves counting, count the relevant occurrences or filter based on specified criteria.
        - If the question involves span extraction, identify and return the exact text span that answers the question.
        - Ensure your reasoning process is clear and step-by-step. Format your final answer appropriately.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the reasoning result
        refinement_instruction = f"""
        Critique and refine the following reasoning result: {reasoning_result}
        Check for any errors, inconsistencies, or ambiguities. If necessary, revise the result to improve accuracy and clarity.
        Ensure the final output directly answers the question and aligns with the extracted data.
        """
        refined_result = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Final decision or synthesis (if multiple reasoning paths exist)
        # Optional: Use Ensemble if there are multiple candidate solutions
        final_answer = refined_result  # Default to refined result if no ensemble is needed

        return final_answer