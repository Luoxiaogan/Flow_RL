# Workflow ID: drop_218_0
# Benchmark: drop
# Data Indices: [434, 778]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information from the passage
        extraction_instruction = (
            "Extract all entities, numbers, dates, and relationships mentioned in the passage. "
            "Focus on information that could potentially answer the question. "
            "Ensure no relevant details are missed."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question's intent
        intent_analysis_instruction = (
            f"Based on the extracted information: {extracted_info}, analyze the question's intent. "
            "Determine if the question requires arithmetic operations, counting, comparison, selection, or span extraction. "
            "Provide a detailed breakdown of the reasoning approach needed to answer the question."
        )
        question_intent = await self.generate(instruction=intent_analysis_instruction, context=self.problem_text)

        # Step 3: Execute parallel reasoning paths
        arithmetic_instruction = (
            f"Perform any required arithmetic operations using the extracted information: {extracted_info}. "
            "Include addition, subtraction, multiplication, or division as needed."
        )
        counting_instruction = (
            f"Count occurrences of specific entities or events based on the extracted information: {extracted_info}. "
            "Ensure all relevant instances are included."
        )
        comparison_instruction = (
            f"Compare entities or values mentioned in the extracted information: {extracted_info}. "
            "Identify which entity satisfies the condition specified in the question."
        )
        span_extraction_instruction = (
            f"Identify the exact text span from the passage that answers the question. "
            "Ensure the span is concise and directly addresses the question."
        )

        # Run parallel reasoning paths
        results = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=counting_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text),
            self.generate(instruction=span_extraction_instruction, context=self.problem_text)
        )

        # Step 4: Ensemble decision-making
        ensemble_instruction = (
            "Evaluate the following candidate solutions and select the most accurate and relevant one. "
            "Ensure the chosen solution fully addresses the question's requirements."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 5: Refine the final answer
        refinement_instruction = (
            "Refine the provided answer to ensure it is concise, accurate, and properly formatted. "
            "Correct any errors or ambiguities."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        return refined_answer