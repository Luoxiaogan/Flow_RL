# Workflow ID: drop_151_0
# Benchmark: drop
# Data Indices: [55, 106]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all relevant information from the passage and question
        extraction_instruction = (
            "Extract all numerical values, entities, and relationships mentioned in the passage and question. "
            "Organize them clearly, associating numbers with their respective entities or events. "
            "Include any implicit information that can be inferred from the context."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Understand the question's intent
        intent_instruction = (
            "Analyze the question to determine its intent. "
            "Identify whether the question requires arithmetic operations (e.g., addition, subtraction), "
            "counting, comparison, selection, or span extraction. "
            "Provide a clear explanation of the reasoning strategy needed to answer the question."
        )
        question_intent = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question's intent
        reasoning_instruction = (
            f"Based on the extracted information: {extracted_info} and the question intent: {question_intent}, "
            "perform the necessary reasoning to answer the question. "
            "If the question involves arithmetic operations, show the calculations step-by-step. "
            "If it involves comparisons, clearly state the basis of comparison. "
            "For span extraction, identify the exact text span that answers the question."
        )
        reasoning_output = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the reasoning output
        refinement_instruction = (
            "Critique the reasoning output for accuracy and completeness. "
            "Ensure that all relevant information has been considered and that the reasoning aligns with the question's intent. "
            "Refine the output if necessary, providing a corrected version."
        )
        refined_output = await self.revise(instruction=refinement_instruction, context=reasoning_output)

        # Step 5: Ensemble multiple approaches (if needed)
        # Check if there are multiple plausible answers or interpretations
        ensemble_instruction = (
            "If there are multiple plausible answers or interpretations, evaluate and synthesize them. "
            "Select the most appropriate answer based on the extracted information and question intent."
        )
        final_output = await self.ensemble(instruction=ensemble_instruction, contexts=[refined_output])

        # Step 6: Summarize the final answer
        summary_instruction = (
            "Condense the final reasoning into a concise answer that directly addresses the question. "
            "Ensure the answer is clear, precise, and formatted appropriately."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=final_output)

        return final_answer