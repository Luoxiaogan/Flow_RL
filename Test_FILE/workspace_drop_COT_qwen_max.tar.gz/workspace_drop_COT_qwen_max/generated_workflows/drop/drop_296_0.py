# Workflow ID: drop_296_0
# Benchmark: drop
# Data Indices: [14, 674]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract relevant information from the passage
        extraction_instruction = """
        Extract all numerical values, entities, and relationships mentioned in the passage.
        Format the output as a structured list of key-value pairs or bullet points.
        Ensure that each number is associated with its corresponding entity or context.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_analysis_instruction = f"""
        Analyze the question to determine its intent. Specifically:
        - Identify if the question requires arithmetic operations, counting, comparison, selection, or span extraction.
        - Highlight any entities, numbers, or relationships relevant to answering the question.
        - Use the following extracted information as context: {extracted_info}.
        """
        question_intent = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Parallel reasoning paths based on question intent
        async def arithmetic_operations():
            instruction = f"""
            Perform any required arithmetic operations (addition, subtraction, etc.) using the extracted numbers.
            Ensure that each operation is justified and aligned with the question's intent.
            Relevant context: {extracted_info}
            Question intent: {question_intent}
            """
            return await self.generate(instruction=instruction, context=self.problem_text)

        async def comparisons():
            instruction = f"""
            Compare relevant entities or values based on the question's intent.
            Ensure that the comparison is logical and supported by the passage.
            Relevant context: {extracted_info}
            Question intent: {question_intent}
            """
            return await self.generate(instruction=instruction, context=self.problem_text)

        async def span_extraction():
            instruction = f"""
            Extract the exact text span from the passage that answers the question.
            Ensure that the span is minimal yet complete and directly addresses the question.
            Relevant context: {extracted_info}
            Question intent: {question_intent}
            """
            return await self.generate(instruction=instruction, context=self.problem_text)

        # Execute reasoning paths in parallel
        reasoning_results = await asyncio.gather(
            arithmetic_operations(),
            comparisons(),
            span_extraction()
        )

        # Step 4: Validate and refine results
        refinement_tasks = [
            self.revise(
                instruction=f"Refine the following result to ensure accuracy and alignment with the question: {result}",
                context=self.problem_text
            )
            for result in reasoning_results
        ]
        refined_results = await asyncio.gather(*refinement_tasks)

        # Step 5: Synthesize the final answer
        synthesis_instruction = """
        Evaluate the provided options and select the most accurate and relevant answer.
        If multiple answers are valid, synthesize them into a single coherent response.
        """
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=refined_results)

        return final_answer