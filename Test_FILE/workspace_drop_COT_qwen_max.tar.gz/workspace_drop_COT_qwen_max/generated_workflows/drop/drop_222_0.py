# Workflow ID: drop_222_0
# Benchmark: drop
# Data Indices: [632, 110]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract all relevant numerical values, entities, and relationships
        extraction_instruction = (
            "Thoroughly analyze the passage and question to extract ALL relevant numerical values, "
            "entities, and their relationships. Pay special attention to the question's intent, "
            "which may involve counting, arithmetic operations, or comparisons. Ensure no "
            "information is missed and ambiguous references are noted."
        )
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Refine extracted information by associating values with entities
        refinement_instruction = (
            f"Given the following extracted information: {extraction}\n"
            "Refine it by associating numerical values with their corresponding entities. "
            "Resolve any ambiguous references and ensure each number is correctly linked to its entity."
        )
        refined_data = await self.revise(instruction=refinement_instruction, context=extraction)

        # Step 3: Perform reasoning and calculation
        reasoning_instruction = (
            f"Using the refined data: {refined_data}\n"
            "Perform the required reasoning to answer the question. This may involve arithmetic "
            "operations (addition, subtraction, etc.), counting occurrences, comparing values, or "
            "extracting specific spans. Ensure the reasoning aligns with the question's intent."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=refined_data)

        # Step 4: Validate and select the best answer using Ensemble
        validation_instruction = (
            "Evaluate the following reasoning results and select the most accurate and complete answer. "
            "If there are discrepancies, resolve them by considering the original problem context."
        )
        validation_results = await asyncio.gather(
            self.generate(instruction=reasoning_instruction, context=refined_data),
            self.revise(instruction=refinement_instruction, context=refined_data)
        )
        final_answer = await self.ensemble(instruction=validation_instruction, contexts=validation_results)

        # Step 5: Summarize the final answer
        summarization_instruction = (
            f"Condense the following reasoning result into a concise answer: {final_answer}\n"
            "Ensure the format matches the expected output type (number, text span, etc.)."
        )
        final_output = await self.summarize(instruction=summarization_instruction, context=final_answer)

        return final_output