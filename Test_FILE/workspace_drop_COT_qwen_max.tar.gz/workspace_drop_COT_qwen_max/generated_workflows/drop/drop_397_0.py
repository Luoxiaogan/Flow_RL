# Workflow ID: drop_397_0
# Benchmark: drop
# Data Indices: [729, 746]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant numerical values, entities, and relationships (parallelizable)
        extraction_instruction = """
        Extract ALL numerical values, entities, and their relationships from the passage. 
        Include explicit and implicit information. Format the output as a structured list 
        with clear associations between numbers and entities.
        """
        question_analysis_instruction = """
        Analyze the question to determine its intent. Identify whether the question requires 
        arithmetic operations (e.g., addition, subtraction), counting, comparison, span extraction, 
        or other reasoning patterns. Provide a detailed breakdown of the reasoning required.
        """

        # Run extraction and question analysis in parallel
        extraction_task = self.generate(instruction=extraction_instruction, context=self.problem_text)
        question_analysis_task = self.generate(instruction=question_analysis_instruction, context=self.problem_text)
        extraction, question_analysis = await asyncio.gather(extraction_task, question_analysis_task)

        # Step 2: Perform reasoning based on the question analysis
        reasoning_instruction = f"""
        Using the extracted information: {extraction}
        And the question analysis: {question_analysis}
        Perform the necessary reasoning to answer the question. Follow these steps:
        1. Identify the relevant data points from the extraction.
        2. Apply the reasoning pattern identified in the question analysis.
        3. Clearly show all intermediate steps and calculations.
        4. Provide the final result in a structured format.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Validate and refine the result
        refinement_instruction = f"""
        Critique the reasoning result: {reasoning_result}
        Ensure it accurately answers the question and aligns with the original problem text. 
        Correct any errors, clarify ambiguities, and improve the presentation of the result.
        """
        refined_result = await self.revise(instruction=refinement_instruction, context=self.problem_text)

        # Step 4: Summarize the final answer
        summary_instruction = f"""
        Condense the refined result: {refined_result}
        Into a concise final answer that directly addresses the question. Ensure clarity and precision.
        """
        final_answer = await self.summarize(instruction=summary_instruction, context=self.problem_text)

        return final_answer