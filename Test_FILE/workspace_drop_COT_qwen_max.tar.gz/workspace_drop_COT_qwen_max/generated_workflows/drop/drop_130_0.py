# Workflow ID: drop_130_0
# Benchmark: drop
# Data Indices: [444, 677]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the passage
        extract_instruction = (
            "Identify and list all entities, numbers, dates, and relationships mentioned in the passage. "
            "Ensure you capture all relevant details, including implicit information. "
            "Format the output as a structured list for easy reference."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        analyze_instruction = (
            "Analyze the question to determine its intent. Specifically: "
            "- Identify if the question requires arithmetic operations (e.g., addition, subtraction). "
            "- Check if it involves counting occurrences or comparing values. "
            "- Determine if it seeks a text span or a comparative answer. "
            "Provide a clear explanation of the question's requirements."
        )
        question_intent = await self.generate(instruction=analyze_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or calculation based on the question intent
        reasoning_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            f"and the question intent: {question_intent}\n"
            "Solve the problem step by step. If the question involves arithmetic, perform the necessary calculations. "
            "If it involves counting, tally the relevant occurrences. For comparisons, clearly state the basis of comparison. "
            "For span extraction, identify the exact text span corresponding to the answer."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the intermediate results
        refine_instruction = (
            "Critique and refine the following reasoning result to ensure accuracy and alignment with the question intent. "
            "Check for potential errors in entity-number association, ambiguous references, or incorrect calculations. "
            "Provide a revised version of the reasoning result."
        )
        refined_result = await self.revise(instruction=refine_instruction, context=reasoning_result)

        # Step 5: Finalize the answer
        finalize_instruction = (
            "Condense the following refined reasoning result into a concise, final answer. "
            "Ensure the answer directly addresses the question and is formatted appropriately."
        )
        final_answer = await self.summarize(instruction=finalize_instruction, context=refined_result)

        return final_answer