# Workflow ID: drop_344_0
# Benchmark: drop
# Data Indices: [340, 710]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract and Organize Relevant Information
        extraction_instruction = (
            "Thoroughly analyze the provided passage and question. Identify and extract all entities, "
            "numerical values, relationships, and implicit information. Organize the extracted data into "
            "categories such as entities, numbers, and events. Ensure no relevant detail is missed."
        )
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Classify the Question Intent
        classification_instruction = (
            f"Based on the extracted information: {extraction}, determine the type of question being asked. "
            "Categorize it as one of the following: arithmetic operation, counting, comparison, selection, "
            "or span extraction. Provide a clear explanation of the reasoning behind your classification."
        )
        question_intent = await self.generate(instruction=classification_instruction, context=self.problem_text)

        # Step 3: Solve the Problem Based on Question Intent
        solving_instruction = (
            f"Using the extracted information: {extraction}, and the identified question intent: {question_intent}, "
            "solve the problem step by step. Perform any necessary calculations, count occurrences, compare values, "
            "or extract relevant spans. Ensure the solution is accurate and directly addresses the question."
        )
        solution = await self.generate(instruction=solving_instruction, context=self.problem_text)

        # Step 4: Validate and Refine the Solution
        refinement_instruction = (
            f"Review the solution: {solution}. Check for consistency, correctness, and alignment with the question intent. "
            "Identify any errors or ambiguities and refine the solution accordingly. Provide a revised version of the solution."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=solution)

        # Step 5: Assemble the Final Answer
        final_instruction = (
            f"Condense the refined solution: {refined_solution} into a clear and concise final answer. "
            "Ensure the answer directly addresses the question and is formatted appropriately."
        )
        final_answer = await self.summarize(instruction=final_instruction, context=refined_solution)

        return final_answer