# Workflow ID: drop_261_0
# Benchmark: drop
# Data Indices: [515, 1]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract relevant information (parallelizable)
        extract_instruction = (
            "Extract all numerical values, entities, and relationships from the passage. "
            "Include any dates, counts, measurements, and their associated entities. "
            "Organize the information clearly for downstream reasoning."
        )
        interpret_instruction = (
            "Analyze the question and determine its intent. "
            "Classify the question type (e.g., arithmetic, counting, comparison, span extraction). "
            "Identify the specific reasoning pattern required."
        )

        # Run extraction and interpretation in parallel
        extract_task = self.generate(instruction=extract_instruction, context=self.problem_text)
        interpret_task = self.generate(instruction=interpret_instruction, context=self.problem_text)
        extracted_info, question_intent = await asyncio.gather(extract_task, interpret_task)

        # Step 2: Perform reasoning based on the question intent
        reasoning_instruction = (
            f"Given the extracted information: {extracted_info}\n"
            f"And the question intent: {question_intent}\n"
            "Perform the necessary reasoning to answer the question. "
            "If the question involves arithmetic, perform the calculation. "
            "If it involves counting, count the relevant occurrences. "
            "If it involves comparison, compare the relevant entities. "
            "If it involves span extraction, identify the correct span."
        )
        reasoning_output = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Refine the reasoning output
        refine_instruction = (
            "Critique and refine the following reasoning output. "
            "Ensure all steps are logically sound and address potential ambiguities. "
            "Correct any errors or inconsistencies."
        )
        refined_output = await self.revise(instruction=refine_instruction, context=reasoning_output)

        # Step 4: Summarize the answer
        summarize_instruction = (
            "Condense the refined reasoning into a concise answer that directly addresses the question. "
            "Ensure the answer is clear, accurate, and complete."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_output)

        # Step 5: Handle ambiguities or conflicts (if necessary)
        ambiguity_instruction = (
            "Evaluate the following candidate answers and synthesize the best solution. "
            "Resolve any ambiguities or conflicts based on the passage and question context."
        )
        if "conflict" in refined_output.lower():  # Example condition for ambiguity
            candidates = [final_answer, reasoning_output]  # Example candidates
            final_answer = await self.ensemble(instruction=ambiguity_instruction, contexts=candidates)

        return final_answer