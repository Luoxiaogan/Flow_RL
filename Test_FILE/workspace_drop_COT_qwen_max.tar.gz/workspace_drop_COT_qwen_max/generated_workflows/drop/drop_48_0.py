# Workflow ID: drop_48_0
# Benchmark: drop
# Data Indices: [70, 407]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information from the passage and question
        extraction_instruction = (
            "Carefully analyze the provided passage and question. "
            "Extract all entities (e.g., names, teams, events), numerical values, and their relationships. "
            "Ensure you capture every detail that might be relevant to answering the question. "
            "Format your output as a structured list of key-value pairs where keys are entities or events "
            "and values are associated numerical data or descriptions."
        )
        extracted_data = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Associate numerical values with their corresponding entities or events
        association_instruction = (
            f"Given the extracted data: {extracted_data}, "
            "associate each numerical value with its corresponding entity or event. "
            "Ensure that the associations are logically consistent with the context of the passage. "
            "Format your output as a structured mapping of entities to their associated values."
        )
        associated_data = await self.generate(instruction=association_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or calculation based on the question
        reasoning_instruction = (
            f"Using the associated data: {associated_data}, "
            "analyze the question and perform the required reasoning or calculation. "
            "This may involve arithmetic operations (e.g., addition, subtraction), comparisons, "
            "or extracting specific spans of text. Provide a detailed explanation of your reasoning process."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the reasoning result
        validation_instruction = (
            f"Review the reasoning result: {reasoning_result}. "
            "Check for logical consistency and correctness. If there are any errors or ambiguities, "
            "revise the result to ensure it accurately answers the question."
        )
        refined_result = await self.revise(instruction=validation_instruction, context=reasoning_result)

        # Step 5: Synthesize the final answer
        synthesis_instruction = (
            f"Condense the refined result: {refined_result} into a concise answer. "
            "Ensure the answer directly addresses the question and is formatted appropriately."
        )
        final_answer = await self.summarize(instruction=synthesis_instruction, context=refined_result)

        return final_answer