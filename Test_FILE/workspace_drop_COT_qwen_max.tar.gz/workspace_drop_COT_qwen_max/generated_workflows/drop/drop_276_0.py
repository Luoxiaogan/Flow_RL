# Workflow ID: drop_276_0
# Benchmark: drop
# Data Indices: [291, 462]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Phase 1: Extract Relevant Information
        extraction_instruction = (
            "Carefully analyze the passage and question. "
            "Extract all entities, numerical values, and their relationships. "
            "Include explicit and implicit information, such as entity-number associations, temporal sequences, and comparative relationships. "
            "Organize the extracted information clearly for further reasoning."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Phase 2: Analyze Question and Determine Reasoning Strategy
        reasoning_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Analyze the question type (e.g., arithmetic, counting, comparison, selection, span extraction). "
            "Determine the specific reasoning steps required to answer the question. "
            "Provide a clear plan for solving the problem, including any necessary calculations, comparisons, or selections."
        )
        reasoning_plan = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Phase 3: Parallel Solution Approaches
        # Approach 1: Direct Span Extraction
        span_extraction_instruction = (
            f"Using the extracted information:\n{extracted_info}\n"
            "Identify the exact text span from the passage that directly answers the question. "
            "If no direct span exists, indicate that explicitly."
        )

        # Approach 2: Numerical Reasoning (if applicable)
        numerical_reasoning_instruction = (
            f"Using the extracted information:\n{extracted_info}\n"
            "Perform any necessary arithmetic operations, comparisons, or counts to derive the answer. "
            "Show your work step-by-step and provide the final result."
        )

        # Execute both approaches in parallel
        span_result, numerical_result = await asyncio.gather(
            self.generate(instruction=span_extraction_instruction, context=self.problem_text),
            self.generate(instruction=numerical_reasoning_instruction, context=self.problem_text)
        )

        # Phase 4: Ensemble Decision
        ensemble_instruction = (
            "Evaluate the following candidate solutions:\n"
            f"1. Span Extraction Result: {span_result}\n"
            f"2. Numerical Reasoning Result: {numerical_result}\n"
            "Select the most accurate and contextually appropriate answer. "
            "If neither solution is satisfactory, indicate that explicitly."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[span_result, numerical_result])

        # Phase 5: Optional Refinement
        refinement_instruction = (
            f"Review the final answer: {final_answer}\n"
            "Ensure it aligns perfectly with the question intent and problem context. "
            "Make any necessary refinements to improve clarity or accuracy."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        return refined_answer