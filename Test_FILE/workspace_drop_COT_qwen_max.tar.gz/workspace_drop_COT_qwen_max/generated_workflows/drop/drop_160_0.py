# Workflow ID: drop_160_0
# Benchmark: drop
# Data Indices: [518, 415]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information from the passage and question
        extraction_instruction = """
        Carefully analyze the passage and question to extract ALL relevant information. 
        Include entities, numerical values, relationships, and contextual clues. 
        Ensure nothing is missed, as this information will be critical for answering the question. 
        Format the output clearly, grouping related information together.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        intent_instruction = f"""
        Based on the extracted information: {extracted_info}, analyze the question to determine its intent. 
        Identify whether the question requires arithmetic operations, counting, comparison, selection, or span extraction. 
        Provide a clear explanation of the reasoning process and categorize the question type.
        """
        question_intent = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or computation based on the question's intent
        reasoning_instruction = f"""
        Using the extracted information: {extracted_info} and the identified intent: {question_intent}, 
        perform the required reasoning or computation. Follow these guidelines:
        - For arithmetic operations, calculate the result step-by-step.
        - For counting, count occurrences of the specified entity or event.
        - For comparison, compare the relevant values carefully.
        - For selection, identify the correct entity or event.
        - For span extraction, extract the exact phrase or sentence from the passage. 
        Format the output clearly and include all intermediate steps.
        """
        reasoning_results = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Optional: Handle ambiguity with parallel reasoning paths
        alternative_instruction = f"""
        Consider alternative interpretations of the question based on the extracted information: {extracted_info}. 
        Perform reasoning for each interpretation and generate candidate answers. 
        """
        alternative_results = await self.generate(instruction=alternative_instruction, context=self.problem_text)

        # Step 4: Select the best result using ensemble if ambiguity exists
        ensemble_instruction = f"""
        Evaluate the reasoning results: {reasoning_results} and alternative results: {alternative_results}. 
        Select the best answer based on consistency with the passage, clarity, and adherence to the question's requirements. 
        If there are multiple valid answers, choose the most precise one.
        """
        candidate_answers = [reasoning_results, alternative_results]
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=candidate_answers)

        # Step 5: Validate and refine the answer
        validation_instruction = f"""
        Validate the selected answer: {final_answer} against the passage and question. 
        Ensure it is consistent with the context and meets the question's requirements. 
        If necessary, refine the answer to improve clarity or correctness.
        """
        validated_answer = await self.revise(instruction=validation_instruction, context=final_answer)

        return validated_answer