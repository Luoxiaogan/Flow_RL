# Workflow ID: drop_339_0
# Benchmark: drop
# Data Indices: [76, 547]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract relevant information from the passage
        extraction_instruction = (
            "Extract all key entities, numerical values, dates, and events mentioned in the passage. "
            "Organize them clearly, associating each value or event with its corresponding entity or context."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its type
        question_analysis_instruction = (
            f"Given the extracted information: {extracted_info}\n"
            "Analyze the question and determine its type. Possible types include arithmetic operations, "
            "counting, comparison, selection, or span extraction. Provide a clear explanation of the question's intent."
        )
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question type
        reasoning_instruction = (
            f"Based on the question analysis: {question_analysis}\n"
            f"And the extracted information: {extracted_info}\n"
            "Perform the required reasoning to answer the question. Ensure the reasoning process is step-by-step "
            "and explicitly references the relevant parts of the passage."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the answer
        refinement_instruction = (
            f"Review the reasoning result: {reasoning_result}\n"
            "Critique and refine the answer to ensure it aligns with the question's intent and the passage's context. "
            "Correct any errors or ambiguities."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Handle ambiguities with ensemble if necessary
        ambiguity_check_instruction = (
            f"Check if the refined answer: {refined_answer}\n"
            "contains any ambiguities or multiple plausible interpretations. If so, generate alternative answers."
        )
        ambiguity_check = await self.generate(instruction=ambiguity_check_instruction, context=self.problem_text)

        if "ambiguity" in ambiguity_check.lower():
            alternatives = await asyncio.gather(
                self.generate(instruction="Generate an alternative answer based on the first interpretation.", context=self.problem_text),
                self.generate(instruction="Generate an alternative answer based on the second interpretation.", context=self.problem_text)
            )
            final_answer = await self.ensemble(
                instruction="Select the best answer based on relevance and consistency with the passage.",
                contexts=alternatives
            )
        else:
            final_answer = refined_answer

        return final_answer