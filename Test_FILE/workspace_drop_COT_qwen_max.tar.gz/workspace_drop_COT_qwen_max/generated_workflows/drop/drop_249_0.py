# Workflow ID: drop_249_0
# Benchmark: drop
# Data Indices: [540, 457]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all relevant entities, numbers, and relationships
        extraction_instruction = (
            "Extract all entities, numerical values, and their relationships from the passage and question. "
            "Ensure you capture every detail that could be relevant to answering the question. "
            "Organize the information clearly, associating numbers with their respective entities."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question and determine its intent
        analysis_instruction = (
            f"Given the extracted information: {extracted_info}, analyze the question to determine its intent. "
            "Identify whether the question requires arithmetic operations, counting, comparison, selection, or span extraction. "
            "Highlight which extracted entities and numbers are relevant to the question."
        )
        question_analysis = await self.generate(instruction=analysis_instruction, context=self.problem_text)

        # Step 3: Parallel reasoning paths based on question type
        arithmetic_instruction = (
            f"Using the extracted information: {extracted_info} and the question analysis: {question_analysis}, "
            "perform any required arithmetic operations (addition, subtraction, multiplication, division). "
            "Provide the result along with a clear explanation of the calculation."
        )
        counting_instruction = (
            f"Using the extracted information: {extracted_info} and the question analysis: {question_analysis}, "
            "count the number of occurrences or instances relevant to the question. "
            "Provide the count along with a justification."
        )
        comparison_instruction = (
            f"Using the extracted information: {extracted_info} and the question analysis: {question_analysis}, "
            "compare the relevant entities or numbers as specified in the question. "
            "State which is greater, lesser, or if they are equal, with reasoning."
        )
        span_extraction_instruction = (
            f"Using the extracted information: {extracted_info} and the question analysis: {question_analysis}, "
            "identify the text span or entity name that answers the question. "
            "Ensure the span is concise and directly addresses the question."
        )

        arithmetic_result, counting_result, comparison_result, span_result = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=counting_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text),
            self.summarize(instruction=span_extraction_instruction, context=self.problem_text)
        )

        # Step 4: Ensemble decision-making to synthesize results
        ensemble_instruction = (
            "Evaluate the following candidate answers and select the most appropriate one based on the question's intent. "
            "If multiple answers are valid, synthesize them into a coherent final answer.\n"
            f"Arithmetic Result: {arithmetic_result}\n"
            f"Counting Result: {counting_result}\n"
            f"Comparison Result: {comparison_result}\n"
            f"Span Extraction Result: {span_result}"
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[arithmetic_result, counting_result, comparison_result, span_result])

        # Step 5: Refine the final answer
        refinement_instruction = (
            f"Refine the following answer to ensure it is clear, concise, and fully addresses the question: {final_answer}. "
            "Remove any ambiguities or unnecessary details."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        return refined_answer