# Workflow ID: drop_10_0
# Benchmark: drop
# Data Indices: [60, 147]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all relevant numerical values, entities, and relationships
        extraction_instruction = (
            "Extract all numerical values, associated entities, and their relationships from the passage and question. "
            "Focus on identifying numbers, units, entities, and any implicit or explicit relationships between them. "
            "Format the output clearly, associating each number with its corresponding entity."
        )
        extraction_task = self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_analysis_instruction = (
            "Analyze the question to determine its intent. Identify whether the question requires: "
            "- Arithmetic operations (e.g., addition, subtraction, multiplication, division) "
            "- Comparison (e.g., greater than, less than, equal to) "
            "- Counting (e.g., how many times, how many different) "
            "- Span extraction (e.g., who did, what was the name of) "
            "Provide a clear explanation of the question's intent and any specific constraints."
        )
        question_analysis_task = self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Execute extraction and question analysis in parallel
        extraction_result, question_analysis_result = await asyncio.gather(extraction_task, question_analysis_task)

        # Step 3: Perform reasoning or calculation based on the question's intent
        reasoning_instruction = (
            f"Given the extracted information: {extraction_result}\n"
            f"And the question analysis: {question_analysis_result}\n"
            "Perform the required reasoning or calculation to answer the question. "
            "If the question involves arithmetic, compute the result using the extracted numbers. "
            "If it involves comparison, compare the relevant entities or values. "
            "If it requires span extraction, identify the correct span from the passage. "
            "Ensure the output is accurate and aligns with the question's requirements."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the generated answer
        refinement_instruction = (
            f"Review the following answer: {reasoning_result}\n"
            "Critique and refine it to ensure accuracy, clarity, and alignment with the question's requirements. "
            "If there are any ambiguities or errors, correct them. "
            "Format the refined answer appropriately."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Optional Step 5: Summarize the final answer for clarity
        summary_instruction = (
            f"Summarize the following answer: {refined_answer}\n"
            "Ensure the summary is concise, clear, and retains all essential information."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_answer)

        return final_answer