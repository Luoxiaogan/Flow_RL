# Workflow ID: drop_324_0
# Benchmark: drop
# Data Indices: [669, 107]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract relevant entities, numerical values, and relationships
        extraction_instruction = (
            "Extract all entities, numerical values, and relationships mentioned in the passage and question. "
            "Include details about who performed what actions, quantities, and any comparisons or temporal information."
        )
        extraction_result = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question type and reasoning requirements
        analysis_instruction = (
            "Analyze the question type and determine the reasoning required. "
            "Identify if the question involves arithmetic operations, counting, comparison, selection, or span extraction. "
            "Provide a detailed breakdown of the reasoning steps needed to answer the question."
        )
        analysis_result = await self.generate(instruction=analysis_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the identified question type
        reasoning_instruction = (
            f"Given the extracted information: {extraction_result}\n"
            f"And the analysis of the question type: {analysis_result}\n"
            "Perform the required reasoning step-by-step. "
            "If the question involves arithmetic, show the calculations. "
            "If it involves counting, list all relevant occurrences. "
            "If it involves comparison, clearly state which entities are being compared and the result. "
            "If it involves span extraction, provide the exact text span from the passage."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the reasoning result
        refinement_instruction = (
            "Critique and refine the reasoning result to ensure accuracy and completeness. "
            "Check for any missing steps, incorrect associations, or unresolved ambiguities. "
            "Ensure the final result directly answers the question."
        )
        refined_result = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Synthesize and finalize the answer
        synthesis_instruction = (
            "Synthesize the refined result into a concise and accurate final answer. "
            "Ensure the answer is consistent with the extracted information and reasoning steps. "
            "Format the answer appropriately based on the question type (e.g., number, date, text span)."
        )
        contexts = [extraction_result, analysis_result, reasoning_result, refined_result]
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=contexts)

        return final_answer