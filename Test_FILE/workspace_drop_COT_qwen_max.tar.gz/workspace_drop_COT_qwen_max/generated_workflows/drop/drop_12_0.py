# Workflow ID: drop_12_0
# Benchmark: drop
# Data Indices: [316, 530]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Understand the question context
        question_intent = await self.generate(
            instruction="Analyze the question to determine its intent. "
                        "Identify whether the question requires counting, arithmetic operations, comparison, "
                        "or span extraction. Provide a clear description of the reasoning task.",
            context=self.problem_text
        )

        # Step 2: Extract relevant information from the passage
        relevant_info = await self.generate(
            instruction=f"Based on the question intent: {question_intent}, "
                        "extract all relevant entities, numbers, or spans from the passage. "
                        "Ensure no relevant information is missed and associate numbers with their respective entities.",
            context=self.problem_text
        )

        # Step 3: Perform reasoning based on the question type
        reasoning_output = await self.generate(
            instruction=f"Using the extracted information: {relevant_info}, "
                        "perform the required reasoning to answer the question. "
                        "This may involve counting occurrences, performing arithmetic operations, "
                        "comparing values, or extracting spans. Provide a detailed step-by-step solution.",
            context=self.problem_text
        )

        # Step 4: Validate and refine the reasoning output
        refined_output = await self.revise(
            instruction="Critique the reasoning output for accuracy and completeness. "
                        "Ensure the answer aligns with the question's requirements and is free of errors.",
            context=reasoning_output
        )

        # Step 5: Summarize the final answer
        final_answer = await self.summarize(
            instruction="Condense the refined reasoning output into a concise, final answer. "
                        "Ensure the response is clear, accurate, and directly addresses the question.",
            context=refined_output
        )

        return final_answer