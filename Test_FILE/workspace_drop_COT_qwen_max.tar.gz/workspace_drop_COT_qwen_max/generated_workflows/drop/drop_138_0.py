# Workflow ID: drop_138_0
# Benchmark: drop
# Data Indices: [484, 573]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract Relevant Information
        extract_instruction = """
        Extract all relevant information from the passage that could help answer the question. 
        This includes numerical values, entities, dates, and any other data points mentioned in the text. 
        Ensure that you capture all occurrences of similar entities and associate them correctly with their respective values.
        """
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Analyze the Question
        analyze_instruction = f"""
        Analyze the question to determine what type of reasoning or operation is required. 
        Identify whether the question requires arithmetic operations, comparisons, selection, or span extraction. 
        Use the following extracted information to guide your analysis: {extracted_info}
        """
        question_analysis = await self.generate(instruction=analyze_instruction, context=self.problem_text)

        # Step 3: Perform Reasoning/Calculation
        reasoning_instruction = f"""
        Based on the analysis of the question, perform the necessary reasoning or calculations. 
        Use the extracted information and the question analysis to guide your steps. 
        Ensure that you handle any ambiguities or implicit information appropriately.
        Extracted Information: {extracted_info}
        Question Analysis: {question_analysis}
        """
        preliminary_answer = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine and Verify
        refine_instruction = f"""
        Review and refine the preliminary answer to ensure accuracy and completeness. 
        Check if the answer makes sense in the context of the passage and the question. 
        Correct any errors or omissions.
        Preliminary Answer: {preliminary_answer}
        """
        refined_answer = await self.revise(instruction=refine_instruction, context=preliminary_answer)

        # Step 5: Compile Final Answer
        summarize_instruction = f"""
        Compile the refined answer into a concise and clear format. 
        Ensure that the final output directly addresses the question and is easy to understand.
        Refined Answer: {refined_answer}
        """
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_answer)

        return final_answer