# Workflow ID: drop_54_0
# Benchmark: drop
# Data Indices: [56, 82]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant entities, numbers, and relationships
        extraction_instruction = """
        Extract all entities, numerical values, dates, and relationships mentioned in the passage. 
        Include partial names, pronouns, and any implicit information that can be inferred. 
        Organize the extracted data in a structured format for easy reference.
        """
        extracted_data = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its type and intent
        question_analysis_instruction = f"""
        Analyze the question to determine its type (arithmetic, counting, comparison, selection, span extraction). 
        Identify the specific information being requested and map it to the extracted data provided below.
        Extracted Data: {extracted_data}
        """
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or calculation based on the question type
        reasoning_instruction = f"""
        Based on the question analysis, perform the necessary reasoning or calculation. 
        Use the extracted data and follow the steps required to arrive at the answer. 
        Ensure all calculations are accurate and all entities are correctly associated with their values.
        Question Analysis: {question_analysis}
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the result
        validation_instruction = f"""
        Validate the reasoning result against the original passage and question. 
        Check for accuracy, consistency, and alignment with the problem's requirements. 
        Refine the result if necessary to ensure correctness.
        Reasoning Result: {reasoning_result}
        """
        refined_result = await self.revise(instruction=validation_instruction, context=self.problem_text)

        # Step 5: Summarize the final answer
        summarization_instruction = f"""
        Summarize the refined result into a concise answer format. 
        Ensure the answer directly addresses the question and is presented clearly.
        Refined Result: {refined_result}
        """
        final_answer = await self.summarize(instruction=summarization_instruction, context=self.problem_text)

        return final_answer