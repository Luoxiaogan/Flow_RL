# Workflow ID: drop_107_0
# Benchmark: drop
# Data Indices: [772, 134]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract relevant information from the passage
        extraction_instruction = """
        Extract all numerical values, entities, and events from the passage. 
        For each numerical value, associate it with the relevant entity or event. 
        Include any temporal information (e.g., quarters, halves) and ensure no data is omitted.
        """
        extracted_data = await self.generate(
            instruction=extraction_instruction,
            context=self.problem_text
        )

        # Step 2: Analyze the question to determine its intent
        question_intent_instruction = f"""
        Analyze the question to determine its intent. Specifically:
        - Identify whether the question requires arithmetic operations (e.g., sum, difference), counting, comparison, selection, or span extraction.
        - Use the following extracted data to guide your analysis: {extracted_data}.
        - Provide a clear explanation of the reasoning process required to answer the question.
        """
        question_intent = await self.generate(
            instruction=question_intent_instruction,
            context=self.problem_text
        )

        # Step 3: Perform reasoning or calculation based on the question intent
        reasoning_instruction = f"""
        Based on the question intent ({question_intent}), perform the necessary reasoning or calculation:
        - If the question involves arithmetic operations, compute the required sum, difference, or other operation.
        - If the question involves counting, tally the occurrences of the relevant entities or events.
        - If the question involves comparison, determine which entity satisfies the condition (e.g., longest, most).
        - If the question involves selection or span extraction, identify the specific text span or entity.
        Ensure the reasoning process is clearly explained and supported by the extracted data.
        """
        reasoning_result = await self.generate(
            instruction=reasoning_instruction,
            context=self.problem_text
        )

        # Step 4: Validate and refine the answer
        refinement_instruction = f"""
        Critique and refine the following reasoning result: {reasoning_result}.
        Ensure the answer is accurate, well-supported by the passage, and formatted appropriately for the question type.
        """
        refined_answer = await self.revise(
            instruction=refinement_instruction,
            context=reasoning_result
        )

        return refined_answer