# Workflow ID: drop_132_0
# Benchmark: drop
# Data Indices: [89, 771]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract all relevant entities, numbers, and spans from the passage
        extraction_instruction = """
        Extract ALL relevant entities, numerical values, dates, and text spans from the passage.
        Include explicit and implicit information referenced in the question.
        Organize the extracted data into categories: entities, numbers, dates, and spans.
        """
        extracted_data = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its type and intent
        analysis_instruction = f"""
        Given the extracted data: {extracted_data}
        Analyze the question to determine its type and intent. Identify whether the task involves:
        - Arithmetic operations (addition, subtraction, etc.)
        - Counting specific occurrences
        - Comparing values
        - Selecting entities or spans
        Provide a clear explanation of the question's intent and how to proceed.
        """
        question_intent = await self.revise(instruction=analysis_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or calculation based on the identified intent
        reasoning_instruction = f"""
        Using the extracted data: {extracted_data}
        And the question intent: {question_intent}
        Perform the necessary reasoning or calculation to arrive at the answer.
        If the task involves arithmetic, explicitly show the computation steps.
        If the task involves span extraction, identify the exact text span.
        """
        preliminary_answer = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the answer
        refinement_instruction = f"""
        Critique and refine the following preliminary answer: {preliminary_answer}
        Ensure it aligns with the question's requirements and uses the extracted data correctly.
        Correct any errors in entity-number association or implicit inference.
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=self.problem_text)

        # Step 5: Handle ambiguities (if needed) using Ensemble
        # Generate alternative interpretations if ambiguity exists
        alternatives = await asyncio.gather(
            self.generate(instruction=f"Provide an alternative interpretation of the answer: {preliminary_answer}", context=self.problem_text),
            self.generate(instruction=f"Re-evaluate the reasoning steps for potential errors: {reasoning_instruction}", context=self.problem_text)
        )
        final_instruction = f"""
        Evaluate and select the best answer among the following options:
        Option 1: {refined_answer}
        Option 2: {alternatives[0]}
        Option 3: {alternatives[1]}
        Provide a justification for your choice.
        """
        final_answer = await self.ensemble(instruction=final_instruction, contexts=[refined_answer, *alternatives])

        return final_answer