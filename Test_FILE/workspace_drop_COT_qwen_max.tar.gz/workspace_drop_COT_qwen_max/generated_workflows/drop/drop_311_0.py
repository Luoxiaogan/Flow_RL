# Workflow ID: drop_311_0
# Benchmark: drop
# Data Indices: [615, 195]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract relevant information
        extraction_instruction = (
            "Extract all entities, numerical values, and relationships from the passage and question. "
            "Focus on identifying: "
            "- Numerical values and their associated entities (e.g., '17-yard TD run' -> 'Chris Johnson'). "
            "- Key phrases or spans that might answer the question. "
            "- Implicit information or inferred relationships."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze and associate entities
        analysis_instruction = (
            f"Given the extracted information: {extracted_info}\n"
            "Analyze and associate numerical values or spans with their respective entities. "
            "For example, if the question asks about 'yards,' identify all yard-related numbers and their contexts. "
            "Ensure no relevant occurrence is missed."
        )
        analyzed_info = await self.generate(instruction=analysis_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or calculation
        reasoning_instruction = (
            f"Based on the analyzed information: {analyzed_info}\n"
            "Perform the required reasoning or calculation to answer the question. "
            "Follow these guidelines: "
            "- For arithmetic operations, sum, subtract, or compare numbers as needed. "
            "- For counting, count occurrences of specific entities or events. "
            "- For span extraction, identify the exact text span that answers the question. "
            "Provide a clear and step-by-step explanation of your reasoning."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Revise and validate the answer
        revision_instruction = (
            f"Review the reasoning result: {reasoning_result}\n"
            "Critique and refine the answer to ensure it aligns with the question's intent and the extracted information. "
            "Check for: "
            "- Correct entity-number associations. "
            "- Logical consistency in calculations or comparisons. "
            "- Clarity and completeness of the answer."
        )
        revised_answer = await self.revise(instruction=revision_instruction, context=reasoning_result)

        # Step 5: Finalize the answer
        summarization_instruction = (
            f"Condense the revised answer: {revised_answer}\n"
            "Provide a concise and clear final answer. "
            "Ensure the answer directly addresses the question and is easy to understand."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=revised_answer)

        return final_answer