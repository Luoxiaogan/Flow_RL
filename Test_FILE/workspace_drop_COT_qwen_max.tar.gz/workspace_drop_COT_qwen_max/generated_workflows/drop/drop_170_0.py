# Workflow ID: drop_170_0
# Benchmark: drop
# Data Indices: [486, 445]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information
        extraction_instruction = (
            "Extract all numerical values, entities, and key phrases from the passage and question. "
            "Associate each number or entity with its corresponding context in the passage. "
            "Pay special attention to any implicit relationships or references."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze question intent
        intent_instruction = (
            "Determine the intent of the question. Is it asking for a sum, difference, count, comparison, or specific entity? "
            "Provide a clear explanation of what the question is asking for and how it relates to the extracted information."
        )
        question_intent = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning
        reasoning_instruction = (
            f"Using the extracted information: {extracted_info} and the question intent: {question_intent}, "
            "perform the required reasoning to answer the question. If the question involves arithmetic, "
            "explicitly calculate the result. If it involves comparison, clearly state the criteria and the result. "
            "If it involves span extraction, identify the exact text span that answers the question."
        )
        reasoning_output = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine
        refinement_instruction = (
            "Critique the reasoning output and refine it if necessary. Ensure all calculations are accurate, "
            "comparisons are clear, and span extractions are precise. Address any ambiguities or missing details."
        )
        refined_output = await self.revise(instruction=refinement_instruction, context=reasoning_output)

        # Step 5: Finalize answer
        summarization_instruction = (
            "Condense the refined reasoning into a concise final answer. Ensure the output is clear, "
            "accurate, and directly addresses the question."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_output)

        return final_answer