# Workflow ID: drop_197_0
# Benchmark: drop
# Data Indices: [724, 327]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract Relevant Information
        extraction_instruction = (
            "Thoroughly analyze the passage and question to extract all relevant entities, numerical values, "
            "dates, and relationships. Ensure no critical information is missed. Organize the extracted data "
            "in a structured format for easy reference."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze Question Intent
        intent_instruction = (
            f"Based on the extracted information: {extracted_info}, determine the type of reasoning required "
            "to answer the question. Identify whether the question involves arithmetic operations (e.g., addition, "
            "subtraction), counting, comparison, selection, or span extraction. Provide a clear analysis of the "
            "question's intent and the specific task to be performed."
        )
        question_intent = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Perform Reasoning or Calculation
        reasoning_instruction = (
            f"Using the extracted information: {extracted_info}, and the analyzed question intent: {question_intent}, "
            "perform the necessary reasoning or calculation to answer the question. If the question involves arithmetic, "
            "ensure all relevant numbers are correctly associated with their entities before performing calculations. "
            "If the question involves span extraction, ensure the correct entity or phrase is identified. Provide a "
            "step-by-step solution leading to the final answer."
        )
        raw_answer = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and Refine Answer
        refinement_instruction = (
            f"Review the generated answer: {raw_answer}. Critique its accuracy, completeness, and formatting. "
            "Ensure the answer directly addresses the question and is consistent with the extracted information. "
            "Refine the answer if necessary to improve clarity or correctness."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=raw_answer)

        return refined_answer