# Workflow ID: drop_71_0
# Benchmark: drop
# Data Indices: [166, 132]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information from the passage
        extract_instruction = """Extract all numerical values, entities, and relationships mentioned in the passage.
        Ensure to capture implicit information and potential inferences that could be relevant to answering questions."""
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Analyze the question to understand its intent
        analyze_instruction = """Analyze the given question to determine what it is asking for.
        Identify if it requires arithmetic operations, counting, comparison, selection, or span extraction.
        Provide a structured breakdown of the question's requirements."""
        question_analysis = await self.generate(instruction=analyze_instruction, context=self.problem_text)

        # Step 3: Associate numbers with their respective entities
        association_instruction = f"""Given the extracted information: {extracted_info}
        Associate each numerical value with its corresponding entity from the passage.
        Ensure accurate mapping and resolve any ambiguous references."""
        entity_number_association = await self.revise(instruction=association_instruction, context=extracted_info)

        # Step 4: Perform required operations based on question analysis
        operation_instruction = f"""Based on the question analysis: {question_analysis}
        And the entity-number associations: {entity_number_association}
        Perform the necessary calculations or comparisons to derive the answer.
        Follow a step-by-step reasoning approach to ensure accuracy."""
        calculated_result = await self.generate(instruction=operation_instruction, context=entity_number_association)

        # Step 5: Synthesize the final answer
        synthesis_instruction = f"""Given the performed operations: {calculated_result}
        Synthesize the final answer in a clear and concise manner.
        Ensure the answer directly addresses the question asked."""
        final_answer = await self.generate(instruction=synthesis_instruction, context=calculated_result)

        # Optional: If multiple interpretations exist, use Ensemble to decide the best solution
        ensemble_instruction = """Evaluate the provided candidate answers and select the most accurate one.
        Consider the context and the original problem statement to make the best decision."""
        candidates = [final_answer]  # In case we have multiple candidates from different paths
        final_synthesized_answer = await self.ensemble(instruction=ensemble_instruction, contexts=candidates)

        return final_synthesized_answer