# Workflow ID: drop_175_0
# Benchmark: drop
# Data Indices: [84, 584]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Analyze the question to determine its intent and type
        question_analysis = await self.generate(
            instruction="Analyze the question to determine its intent and type. "
                        "Identify whether it requires arithmetic operations (addition, subtraction, etc.), "
                        "counting, comparison, selection, or span extraction. "
                        "Provide a detailed breakdown of what is being asked.",
            context=self.problem_text
        )

        # Step 2: Extract relevant entities, numbers, and relationships from the passage
        extract_entities_task = self.generate(
            instruction="Extract all named entities (people, teams, organizations, etc.) from the passage. "
                        "Ensure each entity is clearly identified and disambiguated if necessary.",
            context=self.problem_text
        )
        extract_numbers_task = self.generate(
            instruction="Extract all numerical values from the passage. "
                        "Associate each number with its corresponding entity or context in the passage. "
                        "If the association is ambiguous, provide possible interpretations.",
            context=self.problem_text
        )
        entities, numbers = await asyncio.gather(extract_entities_task, extract_numbers_task)

        # Step 3: Revise the extracted information for accuracy and completeness
        revised_entities = await self.revise(
            instruction=f"Review the extracted entities: {entities}. "
                        "Ensure all relevant entities are included and correctly associated with their context. "
                        "Resolve any ambiguities or missing information.",
            context=self.problem_text
        )
        revised_numbers = await self.revise(
            instruction=f"Review the extracted numbers: {numbers}. "
                        "Ensure all numerical values are accurately associated with their entities or context. "
                        "Resolve any ambiguities or inconsistencies.",
            context=self.problem_text
        )

        # Step 4: Perform the required reasoning based on the question type
        reasoning = await self.generate(
            instruction=f"Based on the question analysis: {question_analysis}, "
                        f"and the revised information: entities ({revised_entities}) and numbers ({revised_numbers}), "
                        "perform the required reasoning step-by-step. "
                        "For arithmetic operations, show intermediate calculations. "
                        "For comparisons, clearly state the basis of the comparison. "
                        "For span extraction, provide the exact text span with context.",
            context=self.problem_text
        )

        # Step 5: Synthesize the final answer
        final_answer = await self.summarize(
            instruction=f"Condense the reasoning results: {reasoning} "
                        "into a concise, final answer. Ensure the answer directly addresses the question "
                        "and includes all necessary details (e.g., units, entities, spans).",
            context=self.problem_text
        )

        return final_answer