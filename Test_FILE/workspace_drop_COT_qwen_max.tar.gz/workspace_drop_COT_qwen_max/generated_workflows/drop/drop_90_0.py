# Workflow ID: drop_90_0
# Benchmark: drop
# Data Indices: [159, 456]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the passage
        extract_instruction = """
        Extract all entities, numerical values, and their relationships from the passage. 
        Include details such as names, dates, scores, distances, and any other relevant data. 
        Organize the extracted information in a structured format for easy reference.
        """
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_analysis_instruction = f"""
        Analyze the question to determine its intent. The question may involve:
        - Arithmetic operations (e.g., addition, subtraction, multiplication, division)
        - Counting occurrences of specific entities or events
        - Comparisons between values or spans
        - Extraction of specific text spans (e.g., names, phrases)
        Based on the question, identify the type of reasoning required and provide a clear directive for the next steps.
        Extracted Information: {extracted_info}
        """
        question_intent = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question intent
        reasoning_instruction = f"""
        Perform the reasoning required to answer the question based on its intent:
        - If arithmetic is needed, perform the necessary calculations using the extracted numbers.
        - If counting is needed, count the occurrences of the specified entities or events.
        - If comparison is needed, compare the relevant values or spans.
        - If span extraction is needed, identify and extract the relevant text spans.
        Ensure the reasoning process is detailed and accurate.
        Question Intent: {question_intent}
        Extracted Information: {extracted_info}
        """
        reasoning_output = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the reasoning output
        refine_instruction = f"""
        Critique and refine the reasoning output to ensure accuracy and clarity. 
        Address any ambiguities, inconsistencies, or errors in the reasoning process.
        Provide a polished version of the reasoning output.
        Reasoning Output: {reasoning_output}
        """
        refined_output = await self.revise(instruction=refine_instruction, context=reasoning_output)

        # Step 5: Synthesize the final answer
        final_instruction = f"""
        Synthesize the final answer based on the refined reasoning output. 
        Ensure the answer is concise, accurate, and directly addresses the question.
        If multiple reasoning paths were explored, select the most appropriate one.
        Refined Output: {refined_output}
        """
        final_answer = await self.ensemble(instruction=final_instruction, contexts=[refined_output])

        return final_answer