# Workflow ID: drop_5_0
# Benchmark: drop
# Data Indices: [464, 793]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract all relevant information from the passage
        extraction = await self.generate(
            instruction="Extract all numerical values, entities, and their relationships from the passage. "
                        "Ensure you capture every detail, including implicit information. "
                        "Format your output as a structured list of findings.",
            context=self.problem_text
        )

        # Step 2: Analyze the question to determine its intent
        question_analysis = await self.generate(
            instruction=f"Analyze the question to determine its intent. "
                        f"Based on the extracted information: {extraction}, "
                        f"identify whether the question requires arithmetic operations, counting, comparison, "
                        f"selection, or span extraction. Provide a clear explanation of the reasoning process.",
            context=self.problem_text
        )

        # Step 3: Perform reasoning based on the question's intent
        reasoning = await self.generate(
            instruction=f"Using the extracted information: {extraction} and the question analysis: {question_analysis}, "
                        f"perform the required reasoning step-by-step. Ensure all calculations and comparisons are "
                        f"accurate and explicitly justified.",
            context=self.problem_text
        )

        # Step 4: Validate and refine the reasoning
        refined_reasoning = await self.revise(
            instruction="Validate and refine the reasoning provided. Check for accuracy, completeness, "
                        "and alignment with the original passage and question. Correct any errors or ambiguities.",
            context=reasoning
        )

        # Step 5: Handle ambiguity with parallel exploration and ensemble decision
        ambiguous_interpretations = await asyncio.gather(
            self.generate(
                instruction=f"Interpret the question and reasoning in one possible way: {refined_reasoning}. "
                            f"Focus on one plausible interpretation and justify it.",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"Interpret the question and reasoning in another possible way: {refined_reasoning}. "
                            f"Focus on a different plausible interpretation and justify it.",
                context=self.problem_text
            )
        )
        final_interpretation = await self.ensemble(
            instruction="Evaluate the provided interpretations and select the most accurate and contextually "
                        "appropriate one. Justify your decision.",
            contexts=ambiguous_interpretations
        )

        # Step 6: Summarize the final answer
        final_answer = await self.summarize(
            instruction="Condense the final reasoning into a concise and clear answer. Ensure the output is "
                        "directly responsive to the question and includes all necessary details.",
            context=final_interpretation
        )

        return final_answer