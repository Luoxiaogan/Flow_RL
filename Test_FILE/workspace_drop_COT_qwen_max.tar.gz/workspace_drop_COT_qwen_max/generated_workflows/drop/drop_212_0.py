# Workflow ID: drop_212_0
# Benchmark: drop
# Data Indices: [562, 32]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the passage
        extraction_instruction = """
        Extract all numerical values, entities, and relationships mentioned in the passage. 
        Include explicit numbers, dates, names, and any other relevant information. 
        Organize the extracted information clearly for further analysis.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_intent_instruction = f"""
        Analyze the question to determine its intent. Specifically:
        - Identify if the question requires arithmetic operations (addition, subtraction, etc.), counting, comparison, span extraction, or multi-hop inference.
        - Use the following extracted information to guide your analysis: {extracted_info}.
        Provide a clear explanation of the question's requirements.
        """
        question_intent = await self.generate(instruction=question_intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or calculation based on the question intent
        reasoning_instruction = f"""
        Based on the question intent analysis ({question_intent}), perform the necessary reasoning or calculation:
        - If the question involves arithmetic, compute the result step-by-step.
        - If it involves counting, count the occurrences of the relevant entities or events.
        - If it involves comparison, compare the relevant values and state which is greater/longer/more.
        - If it involves span extraction, identify the exact text span that answers the question.
        Use the extracted information ({extracted_info}) to ensure accuracy.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the answer
        refinement_instruction = f"""
        Critically review the reasoning result ({reasoning_result}) and refine it if necessary:
        - Ensure all calculations are correct.
        - Resolve any ambiguities or inconsistencies.
        - Verify that the answer directly addresses the question intent ({question_intent}).
        Provide the refined answer in a clear and concise format.
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Finalize the output
        finalization_instruction = """
        Summarize the refined answer into a concise, well-structured response. 
        Ensure the response is easy to understand and directly answers the question.
        """
        final_answer = await self.summarize(instruction=finalization_instruction, context=refined_answer)

        return final_answer