# Workflow ID: drop_306_0
# Benchmark: drop
# Data Indices: [516, 634]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract all relevant entities, numerical values, and relationships
        extraction_instruction = """
        Extract all entities, numerical values, and their relationships from the passage. 
        Include names, dates, events, and any associated numbers or descriptions. 
        Organize the information clearly for further reasoning.
        """
        extracted_data = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_analysis_instruction = f"""
        Analyze the question to determine its intent. Identify whether the task involves:
        - Arithmetic operations (e.g., addition, subtraction, difference)
        - Counting (e.g., how many times, how many different)
        - Comparison (e.g., greater than, less than, earliest, latest)
        - Span extraction (e.g., who did, what was the name of)
        Use the following extracted data for context: {extracted_data}
        """
        question_intent = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Parallel reasoning paths based on question intent
        arithmetic_instruction = f"""
        Perform any required arithmetic operations based on the extracted data: {extracted_data}.
        Follow the question intent: {question_intent}. Provide the result of the calculation.
        """
        counting_instruction = f"""
        Count the relevant occurrences or entities based on the extracted data: {extracted_data}.
        Follow the question intent: {question_intent}. Provide the count.
        """
        comparison_instruction = f"""
        Compare the relevant values or spans based on the extracted data: {extracted_data}.
        Follow the question intent: {question_intent}. Provide the comparison result.
        """
        span_extraction_instruction = f"""
        Extract the exact text span that answers the question based on the extracted data: {extracted_data}.
        Follow the question intent: {question_intent}. Provide the span.
        """

        # Execute parallel reasoning paths
        results = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=counting_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text),
            self.generate(instruction=span_extraction_instruction, context=self.problem_text)
        )

        # Step 4: Synthesize results using Ensemble
        synthesis_instruction = f"""
        Synthesize the results from the following reasoning paths:
        - Arithmetic: {results[0]}
        - Counting: {results[1]}
        - Comparison: {results[2]}
        - Span Extraction: {results[3]}
        Determine the most appropriate answer based on the question intent: {question_intent}.
        """
        synthesized_answer = await self.ensemble(instruction=synthesis_instruction, contexts=results)

        # Step 5: Validate the final answer
        validation_instruction = f"""
        Validate the synthesized answer: {synthesized_answer}.
        Ensure it is accurate and well-supported by the original problem text.
        Correct any inconsistencies or errors.
        """
        final_answer = await self.revise(instruction=validation_instruction, context=synthesized_answer)

        return final_answer