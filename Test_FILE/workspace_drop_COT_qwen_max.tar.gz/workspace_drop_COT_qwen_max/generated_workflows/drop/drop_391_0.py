# Workflow ID: drop_391_0
# Benchmark: drop
# Data Indices: [765, 79]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information from the passage
        extract_instruction = """
        Thoroughly analyze the given passage and extract ALL relevant information that could potentially answer the question. 
        Include:
        - All numerical values with their associated entities or events
        - Dates, times, or durations
        - Names of people, teams, locations, or other entities
        - Key phrases or spans of text that might be relevant to answering the question
        Ensure that no important information is missed, even if it seems ambiguous or indirectly related.
        """
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its type and intent
        question_analysis_instruction = f"""
        Carefully analyze the question and determine its type and intent. Specifically:
        - Identify whether the question requires arithmetic operations (e.g., addition, subtraction), counting, comparison, selection, or span extraction.
        - Determine what specific information from the passage is needed to answer the question.
        - If the question involves multiple steps (e.g., identify an entity and then perform a calculation), outline those steps clearly.
        Use the following extracted information as reference: {extracted_info}.
        """
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question type
        reasoning_instruction = f"""
        Based on the question analysis provided below, perform the necessary reasoning to arrive at the answer:
        - If the question requires arithmetic operations, calculate the required sum, difference, or other operation using the extracted numerical values.
        - If the question requires counting, count the occurrences of the specified entity or event.
        - If the question requires comparison, compare the relevant values or spans and determine which is greater, longer, earlier, etc.
        - If the question requires selection, identify the correct entity, event, or span from the passage.
        - If the question requires span extraction, directly extract the relevant text span.
        Question Analysis: {question_analysis}
        Extracted Information: {extracted_info}
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine and validate the answer
        refine_instruction = f"""
        Review the following reasoning result and refine it to ensure accuracy and completeness:
        - Verify that all relevant information has been considered.
        - Resolve any ambiguities or inconsistencies.
        - Ensure the answer aligns with the question's intent and requirements.
        Reasoning Result: {reasoning_result}
        """
        refined_answer = await self.revise(instruction=refine_instruction, context=reasoning_result)

        # Step 5: Summarize the final answer
        summarize_instruction = """
        Condense the refined answer into a concise, clear, and complete response suitable for submission. 
        Ensure the answer directly addresses the question and is presented in the expected format (number, date, text span, etc.).
        """
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_answer)

        return final_answer