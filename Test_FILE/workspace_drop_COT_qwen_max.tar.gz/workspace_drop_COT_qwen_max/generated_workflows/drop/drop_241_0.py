# Workflow ID: drop_241_0
# Benchmark: drop
# Data Indices: [74, 39]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information from the passage
        extract_instruction = (
            "Thoroughly analyze the provided passage and extract ALL relevant information that could be useful "
            "in answering the question. This includes but is not limited to numerical values, entities, dates, "
            "and any contextual clues. Ensure that you capture every detail that might be pertinent to the question."
        )
        extract_task = self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Understand the question intent
        question_instruction = (
            "Analyze the question and determine what it is asking for. Identify whether the question requires "
            "arithmetic operations (e.g., addition, subtraction), counting, comparison, selection, or span extraction. "
            "Provide a clear explanation of the reasoning process needed to arrive at the answer."
        )
        question_task = self.generate(instruction=question_instruction, context=self.problem_text)

        # Run extraction and question analysis in parallel
        extracted_info, question_analysis = await asyncio.gather(extract_task, question_task)

        # Step 3: Perform reasoning/calculation based on the question intent
        reasoning_instruction = (
            f"Based on the following extracted information: {extracted_info}\n"
            f"And the following analysis of the question: {question_analysis}\n"
            "Perform the necessary reasoning or calculation to answer the question. "
            "If the question involves arithmetic operations, carefully perform the calculations. "
            "If it involves counting, ensure that you count all relevant occurrences. "
            "For comparisons, clearly state which entity or value is greater. "
            "For selection, identify the correct span or entity from the text."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine and validate the reasoning result
        refine_instruction = (
            "Review the following reasoning result and ensure that it is accurate and coherent. "
            "Correct any errors or ambiguities, and provide a refined version of the answer."
        )
        refined_result = await self.revise(instruction=refine_instruction, context=reasoning_result)

        # Step 5: Summarize the final answer
        summarize_instruction = (
            "Condense the following refined result into a clear and concise answer that directly addresses the question. "
            "Ensure that the final output is easy to understand and leaves no room for ambiguity."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_result)

        return final_answer