# Workflow ID: drop_262_0
# Benchmark: drop
# Data Indices: [170, 16]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract entities and numerical values
        extraction_instruction = """
        Extract all entities (e.g., players, teams, actions) and numerical values (e.g., scores, distances) 
        from the passage. Categorize them into relevant groups such as field goals, touchdowns, players, 
        and other significant events. Ensure no information is missed and maintain clear associations 
        between entities and their corresponding values.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question
        question_analysis_instruction = f"""
        Analyze the question to determine its type (arithmetic, counting, comparison, span extraction, etc.) 
        and intent. Use the following extracted information: {extracted_info}. Identify what the question 
        is asking for and map it to the relevant entities and numerical values. Provide a clear breakdown 
        of the reasoning steps required to answer the question.
        """
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Compute the answer
        # Generate multiple approaches to solving the problem
        arithmetic_instruction = f"""
        Perform any necessary arithmetic operations (addition, subtraction, etc.) based on the question 
        analysis: {question_analysis}. Use the extracted information: {extracted_info} to compute the answer.
        """
        comparison_instruction = f"""
        Compare entities or values as required by the question analysis: {question_analysis}. Use the 
        extracted information: {extracted_info} to determine the correct answer.
        """
        span_extraction_instruction = f"""
        Identify the exact text span (entity name, phrase, etc.) that answers the question based on the 
        question analysis: {question_analysis}. Use the extracted information: {extracted_info}.
        """

        results = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text),
            self.generate(instruction=span_extraction_instruction, context=self.problem_text)
        )

        # Step 4: Ensemble to select the best result
        ensemble_instruction = f"""
        Evaluate the following candidate solutions and select the best one based on correctness, relevance, 
        and completeness. Candidates: {results}. Ensure the selected answer aligns with the question intent 
        and the extracted information: {extracted_info}.
        """
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 5: Validate and refine the answer
        refinement_instruction = f"""
        Critique and refine the following answer: {final_answer}. Ensure it is accurate, complete, and 
        consistent with the original passage: {self.problem_text}. Make any necessary corrections.
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        return refined_answer