# Workflow ID: drop_282_0
# Benchmark: drop
# Data Indices: [365, 2]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the passage and question
        extract_instruction = """
        Extract all entities, numerical values, dates, and relationships mentioned in the passage and question. 
        Organize the information into categories: entities (e.g., players, teams), numerical values (e.g., scores, counts), 
        temporal references (e.g., years, quarters), and relationships (e.g., who scored what, when events occurred).
        Ensure no information is missed, as it may be critical for answering the question.
        """
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Interpret the question intent
        interpret_instruction = f"""
        Analyze the question to determine the type of reasoning required. Possible reasoning types include:
        - Arithmetic operations (e.g., addition, subtraction, finding differences)
        - Counting (e.g., how many times something occurred)
        - Comparison (e.g., which is greater, longer, or more)
        - Selection (e.g., which entity satisfies a condition)
        - Span extraction (e.g., identifying exact phrases or names from the passage)
        Based on the question, identify the reasoning type and provide a clear directive for the next steps.
        Extracted information for reference: {extracted_info}
        """
        question_intent = await self.generate(instruction=interpret_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the identified intent
        reasoning_instruction = f"""
        Using the extracted information and the identified reasoning type, perform the necessary reasoning steps.
        For arithmetic operations, identify the relevant numbers and perform the required calculations.
        For counting, enumerate all occurrences of the specified entities or events.
        For comparison, evaluate the relative values or properties of the entities involved.
        For selection, identify the entity or event that satisfies the given condition.
        For span extraction, locate the exact text span from the passage that answers the question.
        Extracted information: {extracted_info}
        Question intent: {question_intent}
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Synthesize the result into a concise answer
        synthesize_instruction = f"""
        Summarize the reasoning result into a clear and concise answer. Ensure the answer directly addresses the question.
        If the reasoning involves multiple steps, present the final conclusion without unnecessary intermediate details.
        Reasoning result: {reasoning_result}
        """
        final_answer = await self.summarize(instruction=synthesize_instruction, context=reasoning_result)

        # Step 5: Refine the answer if needed
        refine_instruction = f"""
        Review the synthesized answer for clarity, completeness, and correctness. If any ambiguities or errors are found, 
        refine the answer to ensure it accurately reflects the reasoning and the passage content.
        Final answer for review: {final_answer}
        """
        refined_answer = await self.revise(instruction=refine_instruction, context=final_answer)

        return refined_answer