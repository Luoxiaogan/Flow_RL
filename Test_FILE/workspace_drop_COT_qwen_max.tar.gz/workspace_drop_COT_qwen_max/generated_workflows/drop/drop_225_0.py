# Workflow ID: drop_225_0
# Benchmark: drop
# Data Indices: [672, 263]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information from the passage
        extraction_instruction = (
            "Thoroughly analyze the provided passage and extract all numerical values, "
            "entities, and their relationships. Pay special attention to any implicit "
            "information or context that might be relevant to answering questions. "
            "Format the output as a structured list of key-value pairs where keys are "
            "entities or concepts, and values are associated numbers or descriptions."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Understand the question and determine its intent
        question_instruction = (
            "Carefully interpret the question and determine its intent. Identify whether "
            "the question requires arithmetic operations (e.g., addition, subtraction), "
            "counting, comparison, span extraction, or another type of reasoning. Provide "
            "a clear explanation of the question's requirements and any specific constraints."
        )
        question_analysis = await self.generate(instruction=question_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or calculation based on the question intent
        reasoning_instruction = (
            f"Using the extracted information: {extracted_info}, and the question analysis: {question_analysis}, "
            "perform the required reasoning or calculation. If the question involves arithmetic, "
            "explicitly show the steps and operations. If it involves span extraction, clearly "
            "identify the relevant text span. Ensure the output is accurate and well-justified."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the reasoning result
        refinement_instruction = (
            "Critique the provided reasoning result and refine it for accuracy and clarity. "
            "Check for any errors, ambiguities, or missing details. Ensure the refined result "
            "is consistent with the extracted information and the question's requirements."
        )
        refined_result = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Handle ambiguity with ensemble decision-making
        alternative_instruction = (
            "Consider alternative interpretations or calculations based on the extracted "
            "information and question analysis. Generate one or more alternative solutions "
            "that could potentially answer the question."
        )
        alternative_result = await self.generate(instruction=alternative_instruction, context=self.problem_text)

        final_instruction = (
            "Evaluate the refined result and any alternative solutions. Select the best "
            "answer based on accuracy, relevance, and consistency with the passage and question. "
            "Provide a justification for your selection."
        )
        final_answer = await self.ensemble(
            instruction=final_instruction,
            contexts=[refined_result, alternative_result]
        )

        # Step 6: Summarize the final answer
        summary_instruction = (
            "Condense the final answer into a concise, readable format. Ensure the output "
            "directly addresses the question and is easy to understand."
        )
        summarized_answer = await self.summarize(instruction=summary_instruction, context=final_answer)

        return summarized_answer