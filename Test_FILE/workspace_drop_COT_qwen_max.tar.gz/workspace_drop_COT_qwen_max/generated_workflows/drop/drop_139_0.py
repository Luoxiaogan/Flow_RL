# Workflow ID: drop_139_0
# Benchmark: drop
# Data Indices: [187, 297]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract relevant information from the passage
        extraction_instruction = """
        Extract all numerical values, entities, and spans from the passage that could potentially answer the question. 
        Identify relationships between entities and numbers, including implicit or inferred information. 
        Format the output as a structured list of key-value pairs, where keys are entities and values are associated data.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Interpret the question's intent
        interpretation_instruction = f"""
        Analyze the question to determine its intent. Identify whether the question requires arithmetic operations, 
        counting, comparison, selection, or span extraction. Use the following extracted information as context: 
        {extracted_info}.
        Provide a clear description of the reasoning steps needed to answer the question.
        """
        question_intent = await self.generate(instruction=interpretation_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question intent
        reasoning_instruction = f"""
        Based on the question intent described here: {question_intent}, perform the required reasoning using the 
        extracted information: {extracted_info}. Solve step-by-step and provide intermediate results where applicable. 
        Ensure the reasoning aligns with the question's requirements.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the reasoning output
        refinement_instruction = f"""
        Critique and refine the following reasoning output: {reasoning_result}. Ensure the result is accurate, 
        complete, and aligned with the question's intent and the passage's context. Correct any errors or ambiguities.
        """
        refined_result = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Summarize the final answer
        summarization_instruction = f"""
        Compress the following refined reasoning into a concise answer format suitable for the question: 
        {refined_result}. Ensure the answer is clear, precise, and directly addresses the question.
        """
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_result)

        return final_answer