# Workflow ID: drop_358_0
# Benchmark: drop
# Data Indices: [331, 368]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant entities, numbers, and relationships
        extraction_instruction = """Extract ALL entities, numerical values, dates, and their relationships from the passage. 
        Include any implicit information that could be relevant for answering questions. Format the output as a structured list."""
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its type and requirements
        question_analysis_instruction = f"""Analyze the question to determine its type (arithmetic, counting, comparison, span extraction, etc.). 
        Identify what specific information is being asked for. Use the extracted information below to guide your analysis.
        Extracted Information: {extracted_info}"""
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform reasoning in parallel paths
        arithmetic_instruction = f"""If the question involves arithmetic operations, identify the numbers involved and perform the required operation. 
        Use the extracted information below to guide your reasoning.
        Extracted Information: {extracted_info}
        Question Analysis: {question_analysis}"""
        counting_instruction = f"""If the question involves counting, count the occurrences or distinct entities as specified. 
        Use the extracted information below to guide your reasoning.
        Extracted Information: {extracted_info}
        Question Analysis: {question_analysis}"""
        comparison_instruction = f"""If the question involves comparison, compare values or spans based on the context. 
        Use the extracted information below to guide your reasoning.
        Extracted Information: {extracted_info}
        Question Analysis: {question_analysis}"""
        span_extraction_instruction = f"""If the question involves span extraction, identify the exact text span that answers the question. 
        Use the extracted information below to guide your reasoning.
        Extracted Information: {extracted_info}
        Question Analysis: {question_analysis}"""

        reasoning_tasks = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=counting_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text),
            self.generate(instruction=span_extraction_instruction, context=self.problem_text)
        )

        # Step 4: Synthesize results using Ensemble
        synthesis_instruction = """Evaluate the candidate solutions below and select the most appropriate answer. 
        Ensure the selected answer aligns with the question's intent and is supported by the extracted information."""
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=reasoning_tasks)

        # Step 5: Refine the final answer
        refinement_instruction = """Revise the answer to ensure clarity, accuracy, and alignment with the question's intent. 
        Remove any unnecessary details and format the answer appropriately."""
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        return refined_answer