# Workflow ID: drop_37_0
# Benchmark: drop
# Data Indices: [114, 292]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract entities, numbers, and relationships
        extraction_instruction = (
            "Extract all entities, numbers, dates, and their relationships from the passage. "
            "Ensure that each number or date is associated with its corresponding entity or event. "
            "Format the output as a structured list for clarity."
        )
        extracted_data = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question and classify its type
        question_analysis_instruction = (
            f"Given the extracted data: {extracted_data}, analyze the question and classify its type. "
            "Possible types include arithmetic operations, counting, comparison, selection, and span extraction. "
            "Provide a clear explanation of the question's intent and how it should be approached."
        )
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Parallel reasoning paths
        arithmetic_instruction = (
            f"Perform arithmetic operations as required by the question. Use the extracted data: {extracted_data}. "
            "Calculate sums, differences, products, or other operations as specified."
        )
        counting_instruction = (
            f"Count occurrences of specific entities or events as required by the question. Use the extracted data: {extracted_data}. "
            "Ensure that each count is accurate and associated with the correct entity."
        )
        comparison_instruction = (
            f"Compare two or more entities or values as required by the question. Use the extracted data: {extracted_data}. "
            "Determine which is greater, lesser, or equal, and provide the result."
        )
        selection_instruction = (
            f"Select the correct entity or event based on the question's criteria. Use the extracted data: {extracted_data}. "
            "Provide a clear justification for your selection."
        )
        span_extraction_instruction = (
            f"Extract the exact text span that answers the question. Use the extracted data: {extracted_data}. "
            "Ensure that the span is precise and directly addresses the question."
        )

        arithmetic_result, counting_result, comparison_result, selection_result, span_result = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=counting_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text),
            self.generate(instruction=selection_instruction, context=self.problem_text),
            self.generate(instruction=span_extraction_instruction, context=self.problem_text)
        )

        # Step 4: Ensemble decision
        ensemble_instruction = (
            "Evaluate the results from the following reasoning paths and select the most relevant one: "
            f"Arithmetic Result: {arithmetic_result}, Counting Result: {counting_result}, "
            f"Comparison Result: {comparison_result}, Selection Result: {selection_result}, "
            f"Span Extraction Result: {span_result}. Ensure that the final answer is consistent and accurate."
        )
        ensemble_result = await self.ensemble(instruction=ensemble_instruction, contexts=[
            arithmetic_result, counting_result, comparison_result, selection_result, span_result
        ])

        # Step 5: Final answer refinement
        refinement_instruction = (
            f"Refine the final answer: {ensemble_result}. Ensure that it is concise, accurate, and formatted appropriately. "
            "Check for any ambiguity and resolve uncertainties if present."
        )
        final_answer = await self.revise(instruction=refinement_instruction, context=ensemble_result)

        return final_answer