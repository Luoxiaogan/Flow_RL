# Workflow ID: drop_147_0
# Benchmark: drop
# Data Indices: [532, 490]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract relevant information and analyze the question
        extraction_instruction = (
            "Carefully read the passage and question. Identify all entities, numerical values, "
            "and their relationships. Determine the type of question being asked (e.g., arithmetic, "
            "counting, comparison, span extraction). Provide a detailed breakdown of the relevant "
            "information needed to answer the question."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Perform intermediate reasoning or calculation
        reasoning_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Perform the necessary reasoning or calculations to answer the question. If the question "
            "involves arithmetic operations, compute the result. If it involves entity tracking or "
            "multi-hop inference, associate numbers with their respective entities and provide the "
            "final computed value or identified span."
        )
        intermediate_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Validate and refine the intermediate result
        refinement_instruction = (
            f"Review the intermediate result: {intermediate_result}\n"
            "Critique its accuracy and completeness. Ensure all implicit information is accounted for "
            "and correct any errors. Provide a refined version of the result."
        )
        refined_result = await self.revise(instruction=refinement_instruction, context=intermediate_result)

        # Step 4: Synthesize the final answer
        synthesis_instruction = (
            f"Condense the refined result: {refined_result}\n"
            "Provide a concise and clear answer that directly addresses the question. Ensure the "
            "answer format matches the expected type (number, date, text span, etc.)."
        )
        final_answer = await self.summarize(instruction=synthesis_instruction, context=refined_result)

        return final_answer