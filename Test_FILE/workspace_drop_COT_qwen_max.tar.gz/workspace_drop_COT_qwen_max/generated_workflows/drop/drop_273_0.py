# Workflow ID: drop_273_0
# Benchmark: drop
# Data Indices: [337, 242]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract relevant information (numbers, entities, relationships)
        extraction_instruction = """
        Carefully analyze the passage and question. Extract ALL relevant numerical values, entities, 
        and relationships. Ensure no information is missed. If the question involves multiple entities 
        or numbers, clearly label each one. Provide the output in a structured format.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Associate numbers with entities
        association_instruction = f"""
        Using the extracted information: {extracted_info}, associate each number with its corresponding 
        entity or context from the passage. Ensure that numbers are correctly attributed to avoid confusion. 
        Provide the output in a clear, structured format.
        """
        associated_info = await self.generate(instruction=association_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question type
        reasoning_instruction = f"""
        Based on the associated information: {associated_info}, perform the reasoning required to answer 
        the question. This may involve arithmetic operations (addition, subtraction, etc.), comparisons 
        (greater than, less than), or span extraction (identifying specific text). Clearly explain the 
        reasoning process and provide the final result.
        """
        reasoning_output = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Revise and refine the reasoning output
        revision_instruction = f"""
        Critique the reasoning output: {reasoning_output}. Identify any errors, ambiguities, or missing 
        details. Refine the output to ensure accuracy and alignment with the question's intent. Provide 
        the revised output in a clear and concise manner.
        """
        refined_output = await self.revise(instruction=revision_instruction, context=reasoning_output)

        # Step 5: Summarize the final answer
        summary_instruction = f"""
        Condense the refined output: {refined_output} into a concise final answer. Ensure the answer is 
        clear, accurate, and directly addresses the question. If the question requires a text span, ensure 
        the exact span is provided.
        """
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_output)

        return final_answer