# Workflow ID: drop_380_0
# Benchmark: drop
# Data Indices: [678, 722]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information from the passage
        extract_instruction = """
        Extract ALL numerical values, entities, and their relationships from the passage. 
        Ensure that each number is associated with the correct entity or event. 
        For example, if the passage mentions 'Colt McCoy completed 299 yards', explicitly link '299' to 'Colt McCoy'. 
        Include any implicit information that can be inferred from the context.
        """
        extract_task = self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_intent_instruction = """
        Analyze the question to determine its intent. Identify whether the question requires:
        - Arithmetic operations (e.g., addition, subtraction, multiplication, division)
        - Counting specific occurrences or entities
        - Comparison between entities or values
        - Extraction of a text span (e.g., an entity name or phrase)
        Provide a detailed breakdown of the reasoning required to answer the question.
        """
        question_intent_task = self.generate(instruction=question_intent_instruction, context=self.problem_text)

        # Run extraction and question analysis in parallel
        extracted_info, question_intent = await asyncio.gather(extract_task, question_intent_task)

        # Step 3: Perform reasoning based on the question intent
        reasoning_instruction = f"""
        Using the extracted information: {extracted_info}
        And the question intent analysis: {question_intent}
        Solve the problem step by step. Follow these guidelines:
        - If the question involves arithmetic, perform the necessary calculations explicitly.
        - If it involves counting, tally the relevant occurrences accurately.
        - If it involves comparison, evaluate the relationships between entities or values.
        - If it involves span extraction, identify the exact text span that answers the question.
        Provide a clear and justified answer.
        """
        reasoning_task = self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the reasoning
        refine_instruction = """
        Critique the reasoning process and refine the answer. Ensure that:
        - All numerical values are correctly associated with their entities.
        - Any ambiguities in entity references are resolved.
        - Implicit information is properly accounted for.
        - The final answer aligns with the question intent.
        """
        refined_answer = await self.revise(instruction=refine_instruction, context=await reasoning_task)

        # Step 5: Synthesize results if multiple reasoning paths exist
        final_instruction = """
        Synthesize the results from the reasoning and refinement steps into a single, coherent answer. 
        Ensure the final output is concise, accurate, and directly addresses the question.
        """
        final_answer = await self.ensemble(instruction=final_instruction, contexts=[refined_answer])

        return final_answer