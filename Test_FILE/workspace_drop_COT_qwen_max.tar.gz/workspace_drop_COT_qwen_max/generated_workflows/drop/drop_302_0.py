# Workflow ID: drop_302_0
# Benchmark: drop
# Data Indices: [660, 394]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the passage
        extract_instruction = """
        Extract all entities, numerical values, dates, and relationships mentioned in the passage. 
        For each extracted item, include its context (e.g., what the number refers to, who performed an action).
        Ensure no relevant information is missed, as this will be used for downstream reasoning.
        """
        interpret_instruction = """
        Analyze the question and determine its type. Possible types include:
        - Arithmetic (e.g., sum, difference, multiplication, division)
        - Counting (e.g., how many times, how many different)
        - Comparison (e.g., greater than, less than, earliest, latest)
        - Span Extraction (e.g., who did something, what happened)
        Provide a clear explanation of the question's intent and reasoning requirements.
        """

        # Run extraction and interpretation in parallel
        extract_task = self.generate(instruction=extract_instruction, context=self.problem_text)
        interpret_task = self.generate(instruction=interpret_instruction, context=self.problem_text)
        extracted_info, question_intent = await asyncio.gather(extract_task, interpret_task)

        # Step 2: Perform reasoning based on the question intent
        reasoning_instruction = f"""
        Based on the following extracted information:
        {extracted_info}
        
        And the interpreted question intent:
        {question_intent}
        
        Perform the necessary reasoning steps to answer the question. Follow these guidelines:
        - For arithmetic questions, identify the relevant numbers and perform the required operation.
        - For counting questions, count the occurrences of the specified entities or events.
        - For comparison questions, compare the relevant numerical values or spans.
        - For span extraction questions, locate the exact text span that answers the question.
        Ensure all reasoning steps are clearly explained and justified.
        """
        reasoning_output = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Refine the reasoning output
        refine_instruction = """
        Critique and refine the provided reasoning output. Address any ambiguities, inconsistencies, 
        or missing details. Ensure the reasoning is accurate and directly answers the question.
        """
        refined_output = await self.revise(instruction=refine_instruction, context=reasoning_output)

        # Step 4: Summarize the final answer
        summarize_instruction = """
        Condense the refined reasoning into a concise final answer. Ensure the answer is clear, 
        complete, and directly addresses the question.
        """
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_output)

        return final_answer