# Workflow ID: drop_154_0
# Benchmark: drop
# Data Indices: [41, 216]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information from the passage and question
        extraction_instruction = (
            "Carefully analyze the provided passage and question. "
            "Extract all numerical values, entities, and their relationships. "
            "Include any relevant context that might be needed for reasoning. "
            "Format the output as a structured list of key-value pairs."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Interpret the question's intent
        intent_instruction = (
            "Analyze the question to determine its intent. "
            "Identify the type of reasoning required (e.g., arithmetic operation, counting, comparison, span extraction). "
            "Provide a detailed explanation of the reasoning steps needed to answer the question."
        )
        question_intent = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on extracted information and intent
        reasoning_instruction = (
            f"Using the following extracted information: {extracted_info} "
            f"and the interpreted question intent: {question_intent}, "
            "perform the required reasoning step by step. "
            "Ensure all calculations and logical deductions are clearly explained. "
            "If multiple interpretations are possible, provide all plausible solutions."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the solution
        refinement_instruction = (
            "Critique the provided reasoning and solution. "
            "Check for accuracy, consistency, and completeness. "
            "Refine the solution if necessary, addressing any ambiguities or errors."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Finalize the answer
        final_instruction = (
            "Condense the refined solution into a concise answer. "
            "Ensure the answer is in the correct format (number, text span, etc.) as required by the question."
        )
        final_answer = await self.summarize(instruction=final_instruction, context=refined_solution)

        return final_answer