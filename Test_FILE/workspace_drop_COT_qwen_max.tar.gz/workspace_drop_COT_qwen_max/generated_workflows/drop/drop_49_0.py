# Workflow ID: drop_49_0
# Benchmark: drop
# Data Indices: [707, 725]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant entities, numbers, and relationships
        extraction_instruction = (
            "Extract all numerical values, entities, and their relationships from the passage. "
            "Focus on information that could be relevant to answering the question. "
            "For numerical values, include their associated context (e.g., 'field goal of 25 yards')."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze and associate extracted information with the question
        analysis_instruction = (
            f"Given the extracted information: {extracted_info}\n"
            "Analyze the question and determine what specific information is being asked for. "
            "If the question involves numerical reasoning, identify the relevant numbers and their context. "
            "If the question involves span extraction, identify the relevant text spans."
        )
        analysis = await self.generate(instruction=analysis_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or calculation
        reasoning_instruction = (
            f"Based on the analysis: {analysis}\n"
            "Perform the necessary reasoning or calculation to answer the question. "
            "For arithmetic questions, explicitly show the steps of the calculation. "
            "For span extraction, provide the exact text span that answers the question."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the result
        refinement_instruction = (
            f"Review the reasoning result: {reasoning_result}\n"
            "Critique its accuracy and completeness. "
            "Ensure that the answer correctly addresses the question and resolves any ambiguities. "
            "Refine the result if necessary."
        )
        refined_result = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Final synthesis (if needed)
        final_instruction = (
            "Evaluate the refined result and ensure it is the best possible answer. "
            "If there are multiple candidate solutions, select the most accurate one."
        )
        final_answer = await self.ensemble(instruction=final_instruction, contexts=[refined_result])

        return final_answer