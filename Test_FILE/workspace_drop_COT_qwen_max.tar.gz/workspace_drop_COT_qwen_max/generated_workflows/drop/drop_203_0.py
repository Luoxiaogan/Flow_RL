# Workflow ID: drop_203_0
# Benchmark: drop
# Data Indices: [218, 529]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract relevant information from the passage and question
        extraction_instruction = """
        Extract all numerical values, entities, and their relationships from the passage and question.
        Include any implicit information that might be relevant to answering the question.
        Format your response as a structured list of key-value pairs.
        """
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_analysis_instruction = f"""
        Analyze the question and determine its intent based on the following categories:
        - Arithmetic Operations (e.g., addition, subtraction)
        - Counting (e.g., how many times, how many different)
        - Comparison (e.g., greater than, less than)
        - Span Extraction (e.g., who did, what was the name of)
        Use the extracted information: {extraction}
        Provide a clear explanation of the question's intent and any specific constraints.
        """
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform parallel reasoning based on the question intent
        reasoning_tasks = []
        if "arithmetic" in question_analysis.lower():
            arithmetic_instruction = f"""
            Perform the required arithmetic operation using the extracted numerical values: {extraction}.
            Clearly show your calculations and provide the final result.
            """
            reasoning_tasks.append(self.generate(instruction=arithmetic_instruction, context=self.problem_text))
        if "counting" in question_analysis.lower():
            counting_instruction = f"""
            Count the occurrences of the specified entities or events based on the extracted information: {extraction}.
            Provide the total count and explain your reasoning.
            """
            reasoning_tasks.append(self.generate(instruction=counting_instruction, context=self.problem_text))
        if "comparison" in question_analysis.lower():
            comparison_instruction = f"""
            Compare the specified entities or values based on the extracted information: {extraction}.
            Determine which is greater, longer, or more, and explain your reasoning.
            """
            reasoning_tasks.append(self.generate(instruction=comparison_instruction, context=self.problem_text))
        if "span extraction" in question_analysis.lower():
            span_extraction_instruction = f"""
            Extract the relevant text span from the passage based on the extracted information: {extraction}.
            Ensure the span directly answers the question and explain your choice.
            """
            reasoning_tasks.append(self.generate(instruction=span_extraction_instruction, context=self.problem_text))

        reasoning_results = await asyncio.gather(*reasoning_tasks)

        # Step 4: Validate and refine the reasoning results
        refinement_tasks = []
        for result in reasoning_results:
            refinement_instruction = f"""
            Critique and refine the following reasoning result: {result}.
            Ensure accuracy, resolve ambiguities, and improve clarity.
            """
            refinement_tasks.append(self.revise(instruction=refinement_instruction, context=self.problem_text))

        refined_results = await asyncio.gather(*refinement_tasks)

        # Step 5: Synthesize the final answer
        synthesis_instruction = f"""
        Evaluate and synthesize the refined reasoning results: {refined_results}.
        Select the most appropriate answer based on the question's intent and provide a clear explanation.
        """
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=refined_results)

        return final_answer