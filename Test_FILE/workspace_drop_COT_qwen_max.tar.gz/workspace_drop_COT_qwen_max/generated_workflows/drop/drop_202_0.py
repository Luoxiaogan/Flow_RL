# Workflow ID: drop_202_0
# Benchmark: drop
# Data Indices: [797, 324]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Analyze the question to determine its type and extract key elements
        question_analysis_instruction = (
            "Analyze the question to determine its type (e.g., arithmetic, counting, comparison, selection, span extraction). "
            "Extract key entities, numerical values, or spans referenced in the question. "
            "Provide a detailed breakdown of the question's intent and requirements."
        )
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 2: Extract relevant information from the passage
        passage_extraction_instruction = (
            f"Based on the following question analysis: {question_analysis} "
            "Extract all relevant information from the passage that pertains to the question. "
            "Identify entities, numerical values, and their relationships. Resolve any ambiguous references (e.g., pronouns)."
        )
        passage_extraction = await self.generate(instruction=passage_extraction_instruction, context=self.problem_text)

        # Step 3: Perform reasoning and calculation based on the question type
        reasoning_instruction = (
            f"Given the question analysis: {question_analysis} and the extracted passage information: {passage_extraction}, "
            "Perform the necessary reasoning to answer the question. "
            "For arithmetic questions, perform calculations. For counting questions, count occurrences. "
            "For comparison questions, compare values. For selection questions, identify the correct entity or span. "
            "For span extraction questions, extract the exact text span that answers the question."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the reasoning process
        validation_instruction = (
            f"Review the reasoning result: {reasoning_result}. "
            "Critique and refine the reasoning process to ensure accuracy. "
            "Correct any errors or ambiguities in the reasoning."
        )
        refined_reasoning = await self.revise(instruction=validation_instruction, context=reasoning_result)

        # Step 5: Condense the reasoning into a concise final answer
        summarization_instruction = (
            f"Condense the refined reasoning: {refined_reasoning} into a concise final answer. "
            "Ensure the answer directly addresses the question and is presented clearly."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_reasoning)

        return final_answer