# Workflow ID: drop_346_0
# Benchmark: drop
# Data Indices: [719, 794]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract relevant information from the passage
        extraction_instruction = """
        Extract all numerical values, entities, and their relationships from the passage. 
        Ensure you capture all potentially relevant data, including counts, measurements, names, and events. 
        Format the output clearly, associating each number with its corresponding entity or event.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question intent
        question_intent_instruction = f"""
        Analyze the question to determine its type (e.g., arithmetic, counting, comparison, selection, span extraction). 
        Based on the extracted information: {extracted_info}, identify what specific information is required to answer the question. 
        Provide a clear breakdown of the reasoning process needed to arrive at the answer.
        """
        question_analysis = await self.generate(instruction=question_intent_instruction, context=self.problem_text)

        # Step 3: Perform calculation or selection
        reasoning_instruction = f"""
        Using the extracted information: {extracted_info} and the question analysis: {question_analysis}, 
        perform the necessary reasoning to answer the question. 
        If the question involves arithmetic operations, calculate the result step by step. 
        If it involves selection or span extraction, identify the correct entity or text span. 
        Ensure your reasoning is explicit and leaves no ambiguity.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the answer
        refinement_instruction = f"""
        Critique and refine the reasoning result: {reasoning_result}. 
        Ensure the answer aligns with the question intent and the passage context. 
        Correct any errors or ambiguities in the reasoning process.
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Summarize the final answer
        summary_instruction = """
        Condense the final answer into a concise format suitable for submission. 
        Ensure the output is clear, accurate, and directly addresses the question.
        """
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_answer)

        return final_answer