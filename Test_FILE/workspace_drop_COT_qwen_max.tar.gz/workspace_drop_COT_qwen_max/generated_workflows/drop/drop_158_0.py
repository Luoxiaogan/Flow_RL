# Workflow ID: drop_158_0
# Benchmark: drop
# Data Indices: [637, 231]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract relevant information from the problem text
        extraction_instruction = """
        Extract all relevant information from the passage and question, including:
        - Numerical values and their associated entities
        - Key entities (people, teams, events, etc.)
        - Relationships between entities
        - The specific query intent (e.g., arithmetic, counting, comparison, span extraction)
        Ensure the extraction is exhaustive and leaves no relevant detail unaccounted for.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question type and outline reasoning steps
        analysis_instruction = f"""
        Based on the extracted information: {extracted_info}
        Analyze the question type and determine the required reasoning steps:
        - If the question involves arithmetic, specify the operation (addition, subtraction, etc.) and operands.
        - If the question involves counting, specify what to count.
        - If the question involves comparison, specify the entities or values to compare.
        - If the question involves span extraction, specify the target span.
        Provide a clear plan for solving the problem.
        """
        reasoning_plan = await self.generate(instruction=analysis_instruction, context=self.problem_text)

        # Step 3: Execute reasoning paths in parallel
        arithmetic_instruction = f"""
        Perform any required arithmetic operations based on the reasoning plan: {reasoning_plan}
        Ensure calculations are accurate and consistent with the passage.
        """
        counting_instruction = f"""
        Count the occurrences of the specified entities or events based on the reasoning plan: {reasoning_plan}
        Ensure all instances are accounted for.
        """
        comparison_instruction = f"""
        Compare the specified values or spans based on the reasoning plan: {reasoning_plan}
        Ensure the comparison is logical and supported by the passage.
        """
        span_extraction_instruction = f"""
        Extract the specified text span based on the reasoning plan: {reasoning_plan}
        Ensure the span is accurate and directly answers the question.
        """

        results = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=counting_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text),
            self.generate(instruction=span_extraction_instruction, context=self.problem_text)
        )

        # Step 4: Synthesize or select the best answer
        synthesis_instruction = f"""
        Evaluate the following candidate solutions and select the best one based on the question intent:
        - Arithmetic result: {results[0]}
        - Counting result: {results[1]}
        - Comparison result: {results[2]}
        - Span extraction result: {results[3]}
        Ensure the selected answer is consistent with the passage and reasoning plan: {reasoning_plan}
        """
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=results)

        # Step 5: Refine the final output
        refinement_instruction = f"""
        Refine the final answer: {final_answer}
        Ensure it is concise, accurate, and formatted appropriately for the question type.
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        return refined_answer