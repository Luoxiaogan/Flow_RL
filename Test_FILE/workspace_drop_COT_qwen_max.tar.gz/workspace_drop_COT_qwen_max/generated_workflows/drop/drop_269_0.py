# Workflow ID: drop_269_0
# Benchmark: drop
# Data Indices: [36, 689]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all relevant information from the passage
        extract_instruction = (
            "Identify and extract all entities, numbers, dates, and spans mentioned in the passage. "
            "Ensure you capture all potential candidates that could answer the question. "
            "Format the output as a structured list for clarity."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Understand the core intent of the question
        summarize_instruction = (
            "Analyze the question to determine its core intent. "
            "Classify the question into one of the following categories: counting, arithmetic operation, comparison, span extraction, or other. "
            "Provide a brief explanation of the reasoning behind the classification."
        )
        question_intent = await self.summarize(instruction=summarize_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or calculation based on the question intent
        reasoning_instruction = (
            f"Given the extracted information: {extracted_info}\n"
            f"and the question intent: {question_intent}\n"
            "Perform the necessary reasoning or calculation to answer the question. "
            "Ensure you associate numbers with their respective entities or contexts. "
            "Explain your reasoning step-by-step and provide the final answer clearly."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the answer
        revise_instruction = (
            "Critique the provided reasoning and answer. "
            "Check for accuracy, coherence with the passage, and alignment with the question intent. "
            "Refine the answer if necessary and provide the final version."
        )
        refined_answer = await self.revise(instruction=revise_instruction, context=reasoning_result)

        # Step 5: Handle ambiguities or multiple candidates (if applicable)
        ensemble_instruction = (
            "Evaluate the refined answer against any alternative interpretations or candidates. "
            "Select the best candidate based on coherence with the passage and question intent. "
            "If no ambiguities exist, confirm the refined answer as the final result."
        )
        final_answer = await self.ensemble(
            instruction=ensemble_instruction,
            contexts=[refined_answer, extracted_info, question_intent]
        )

        return final_answer