# Workflow ID: drop_173_0
# Benchmark: drop
# Data Indices: [723, 390]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract Relevant Information
        extraction_instruction = """
        Identify and extract all relevant entities, numerical values, dates, and relationships from the passage and question. 
        Focus on information that could be necessary to answer the question. 
        Organize the extracted data clearly, associating numbers with their corresponding entities where applicable.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze Question Intent
        analysis_instruction = f"""
        Analyze the question to determine the type of reasoning required. 
        Based on the extracted information: {extracted_info}, classify the question into one of the following categories:
        - Arithmetic (addition, subtraction, multiplication, division)
        - Counting (how many times, how many different)
        - Comparison (greater than, less than, equal to)
        - Span Extraction (entity names, phrases)
        - Other (specify).
        Provide a clear explanation of the reasoning process needed to answer the question.
        """
        question_analysis = await self.generate(instruction=analysis_instruction, context=self.problem_text)

        # Step 3: Perform Reasoning or Calculation
        reasoning_instruction = f"""
        Based on the analysis: {question_analysis}, perform the required reasoning or calculation to answer the question. 
        Use the extracted information: {extracted_info} to ensure accuracy. 
        If the question involves arithmetic, compute the result step by step. 
        If it involves span extraction, identify the exact text span that answers the question. 
        Ensure the output is clear, concise, and directly addresses the question.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and Refine
        validation_instruction = f"""
        Critique and refine the result: {reasoning_result}. 
        Check for accuracy, completeness, and proper formatting. 
        Ensure that numbers are correctly associated with their entities and that the output matches the question intent. 
        If any issues are found, revise the result accordingly.
        """
        refined_result = await self.revise(instruction=validation_instruction, context=reasoning_result)

        # Step 5: Ensemble Multiple Approaches (Optional)
        ensemble_instruction = f"""
        If there are multiple plausible interpretations or approaches, evaluate and synthesize the best solution. 
        Consider the refined result: {refined_result} and any alternative approaches. 
        Select the most accurate and well-supported answer.
        """
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[refined_result])

        return final_answer