# Workflow ID: drop_254_0
# Benchmark: drop
# Data Indices: [442, 163]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract relevant information from the passage
        extraction_instruction = (
            "Thoroughly analyze the provided passage and extract ALL entities, numerical values, "
            "and their relationships. Ensure you capture every detail that might be relevant to answering "
            "the question. Organize the extracted information clearly and label each piece of data."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_intent_instruction = (
            f"Based on the extracted information: {extracted_info}, analyze the question to determine "
            "its intent. Identify whether the question requires arithmetic operations, counting, comparison, "
            "span extraction, or other forms of reasoning. Provide a clear explanation of the reasoning "
            "process needed to answer the question."
        )
        question_analysis = await self.generate(instruction=question_intent_instruction, context=self.problem_text)

        # Step 3: Perform the required reasoning or calculation
        reasoning_instruction = (
            f"Using the extracted information: {extracted_info} and the question analysis: {question_analysis}, "
            "perform the necessary reasoning or calculation to answer the question. If the task involves "
            "arithmetic operations, show the step-by-step calculation. If it involves span extraction, "
            "clearly identify the relevant text span. Ensure the reasoning process is thorough and accurate."
        )
        initial_answer = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the initial answer
        refinement_instruction = (
            f"Review the initial answer: {initial_answer}. Critique its accuracy and completeness. "
            "Cross-check the reasoning process with the extracted information and question analysis. "
            "Correct any errors and provide a refined version of the answer."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=initial_answer)

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"Condense the refined answer: {refined_answer} into a concise and clear format suitable "
            "for submission. Ensure the final answer directly addresses the question and is easy to understand."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_answer)

        return final_answer