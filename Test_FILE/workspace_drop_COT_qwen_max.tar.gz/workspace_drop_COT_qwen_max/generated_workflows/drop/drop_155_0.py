# Workflow ID: drop_155_0
# Benchmark: drop
# Data Indices: [54, 762]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant numerical and temporal information
        extraction_instruction = (
            "Extract all numerical values and their associated entities from the passage. "
            "Also extract any temporal information such as dates, durations, or time-related phrases. "
            "Ensure that each number is linked to its corresponding entity or context."
        )
        extracted_data = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine the required operation
        question_analysis_instruction = (
            f"Given the extracted data: {extracted_data}, analyze the question to determine the required operation. "
            "Identify whether the task involves arithmetic (e.g., addition, subtraction), counting, comparison, or span extraction. "
            "Provide clear reasoning about the intent of the question and how it relates to the extracted data."
        )
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform the required calculations or logical reasoning
        calculation_instruction = (
            f"Based on the question analysis: {question_analysis}, perform the necessary calculations or logical reasoning. "
            "Use the extracted data to compute the answer step by step. "
            "If the question involves arithmetic, show the intermediate steps. "
            "If it involves span extraction, clearly identify the relevant text span."
        )
        calculation_result = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Validate and refine the results
        validation_instruction = (
            f"Review the calculation result: {calculation_result} against the original passage. "
            "Check for any inconsistencies, ambiguities, or errors in the reasoning process. "
            "Revise the result if necessary to ensure accuracy and alignment with the passage."
        )
        refined_result = await self.revise(instruction=validation_instruction, context=calculation_result)

        # Step 5: Synthesize the final answer
        final_synthesis_instruction = (
            f"Combine the refined result: {refined_result} into a concise final answer. "
            "Ensure the answer directly addresses the question and is presented in the expected format (number, date, text span, etc.)."
        )
        final_answer = await self.generate(instruction=final_synthesis_instruction, context=self.problem_text)

        return final_answer