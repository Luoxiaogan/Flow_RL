# Workflow ID: drop_223_0
# Benchmark: drop
# Data Indices: [756, 488]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Initial Analysis - Understand the question and identify reasoning type
        initial_analysis_instruction = """
        Analyze the question to determine the type of reasoning required. 
        Identify whether the question involves arithmetic operations, counting, comparison, selection, or span extraction.
        Extract key entities, numbers, and relationships mentioned in the question.
        Provide a clear summary of the question's intent and the type of information needed from the passage.
        """
        analysis = await self.generate(instruction=initial_analysis_instruction, context=self.problem_text)

        # Step 2: Information Extraction - Extract relevant occurrences and associations
        extraction_instruction = f"""
        Based on the following analysis: {analysis}
        Extract all relevant occurrences of entities, numbers, and their associations from the passage.
        Ensure that each number is correctly associated with its respective entity or event.
        Provide a structured list of extracted information.
        """
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 3: Reasoning and Calculation - Perform necessary reasoning or calculation
        reasoning_instruction = f"""
        Using the extracted information: {extraction}
        Perform the necessary reasoning or calculation based on the question's intent identified in the analysis: {analysis}.
        If the question involves arithmetic operations, compute the result using the extracted numbers.
        If the question involves counting, count the occurrences of specific entities or events.
        If the question involves comparison, compare values or entities based on the extracted information.
        Provide the intermediate result or reasoning steps.
        """
        reasoning = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Answer Synthesis - Refine and finalize the answer
        synthesis_instruction = f"""
        Based on the reasoning and calculation: {reasoning}
        Synthesize the final answer in the required format (number, date, text span, or comparative answer).
        Ensure the answer is accurate, concise, and directly addresses the question.
        """
        answer = await self.revise(instruction=synthesis_instruction, context=reasoning)

        return answer