# Workflow ID: drop_235_0
# Benchmark: drop
# Data Indices: [68, 769]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract relevant information from the passage
        extract_instruction = """
        Extract all relevant information from the passage that could potentially answer the question. 
        Include numerical values, entities, relationships, and any implicit or explicit context. 
        Ensure that the relationships between entities and their associated values are preserved.
        """
        extract_task = self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Understand the question
        question_instruction = """
        Analyze the question to determine the type of reasoning required (e.g., arithmetic, comparison, span extraction). 
        Identify the specific entities, values, or spans involved. Provide a clear directive on what needs to be computed or extracted.
        """
        question_task = self.generate(instruction=question_instruction, context=self.problem_text)

        # Run extraction and question understanding in parallel
        extracted_info, question_analysis = await asyncio.gather(extract_task, question_task)

        # Step 3: Perform reasoning based on the question type
        reasoning_instruction = f"""
        Based on the following question analysis: {question_analysis}
        And the extracted information: {extracted_info}
        Perform the necessary reasoning to answer the question. This may involve arithmetic operations, counting, comparison, selection, or span extraction.
        Ensure that the reasoning process is clear, logical, and aligned with the question's requirements.
        """
        reasoning_task = self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the answer
        refine_instruction = f"""
        Critique and refine the following reasoning result: {reasoning_task}
        Ensure that the answer is accurate, complete, and well-formatted. Check for correctness, coherence, and alignment with the question.
        """
        refined_answer = await self.revise(instruction=refine_instruction, context=reasoning_task)

        # Step 5: Summarize the final answer
        summarize_instruction = """
        Condense the refined answer into a concise, final response that directly addresses the question. 
        Ensure that the response is clear, precise, and formatted appropriately.
        """
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_answer)

        return final_answer