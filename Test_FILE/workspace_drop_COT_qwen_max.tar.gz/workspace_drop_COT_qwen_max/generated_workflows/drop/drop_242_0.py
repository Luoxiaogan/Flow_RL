# Workflow ID: drop_242_0
# Benchmark: drop
# Data Indices: [764, 307]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information from the passage and question
        extraction_instruction = (
            "Extract all relevant entities, numbers, dates, and spans from the passage and question. "
            "Ensure you capture all potential candidates for reasoning, including numerical values, named entities, "
            "temporal references, and any other information that might be relevant to answering the question."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_intent_instruction = (
            "Analyze the question and determine its intent. Is it asking for a count, a comparison, a span, "
            "a calculation, or something else? Provide a detailed explanation of what the question is asking for."
        )
        question_intent = await self.generate(instruction=question_intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question intent
        reasoning_instruction = (
            f"Based on the extracted information: {extracted_info} and the question intent: {question_intent}, "
            "perform the required reasoning. This could involve arithmetic operations, comparisons, or selecting "
            "the correct span from the extracted information. Provide a detailed step-by-step reasoning process."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine and validate the reasoning output
        refine_instruction = (
            "Critique and refine the reasoning output. Ensure that the answer aligns with the question intent "
            "and is logically consistent with the passage. Correct any errors or inconsistencies."
        )
        refined_result = await self.revise(instruction=refine_instruction, context=reasoning_result)

        # Step 5: Summarize the final answer
        summarize_instruction = (
            "Condense the final reasoning into a concise answer. Ensure clarity and avoid redundancy. "
            "The answer should directly address the question and be easy to understand."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_result)

        return final_answer