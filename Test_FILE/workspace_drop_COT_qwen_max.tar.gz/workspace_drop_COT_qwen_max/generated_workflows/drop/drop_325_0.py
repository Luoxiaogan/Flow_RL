# Workflow ID: drop_325_0
# Benchmark: drop
# Data Indices: [550, 524]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information from the passage
        extraction_instruction = (
            "Thoroughly analyze the provided passage and extract all numerical values, entities, "
            "and their relationships. For each number, clearly associate it with the entity or event "
            "it refers to. Ensure no relevant information is missed."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Understand the question and determine its intent
        question_analysis_instruction = (
            f"Given the extracted information: {extracted_info}\n"
            "Analyze the question to determine what type of reasoning or operation is required. "
            "Identify whether the question involves arithmetic operations (e.g., addition, subtraction), "
            "counting, comparison, or span extraction. Provide a clear explanation of the reasoning steps needed."
        )
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform reasoning to compute or infer the answer
        reasoning_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            f"And the question analysis: {question_analysis}\n"
            "Perform the necessary reasoning steps to compute or infer the answer. Follow the reasoning steps "
            "carefully, ensuring all calculations are accurate and all inferences are logically sound. "
            "Provide the final answer in the required format (e.g., number, date, text span)."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the computed answer
        refinement_instruction = (
            f"Review the computed answer: {reasoning_result}\n"
            "Critique it for accuracy and clarity. Ensure the answer aligns with the question's requirements. "
            "If any errors or ambiguities are found, correct them and provide a refined version of the answer."
        )
        final_answer = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        return final_answer