# Workflow ID: drop_14_0
# Benchmark: drop
# Data Indices: [255, 185]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant numerical values and entities
        extract_instruction = (
            "Identify all numerical values and named entities in the passage that are relevant to the question. "
            "Ensure that each number is associated with its corresponding entity or context. "
            "Organize the results clearly for further reasoning."
        )
        extraction = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Analyze the question type and reasoning requirements
        analyze_instruction = (
            f"Based on the extracted information: {extraction}, analyze the question to determine the type of reasoning required. "
            "Classify the question as one of the following: arithmetic operation, counting, comparison, selection, or span extraction. "
            "Provide a detailed explanation of the reasoning steps needed to answer the question."
        )
        analysis = await self.generate(instruction=analyze_instruction, context=self.problem_text)

        # Step 3: Perform the reasoning steps
        reasoning_instruction = (
            f"Using the analysis: {analysis}, perform the necessary reasoning steps to answer the question. "
            "If the question involves arithmetic operations, calculate the result step by step. "
            "If it involves counting, ensure all relevant instances are considered. "
            "For comparisons, clearly state which entity or value satisfies the condition. "
            "For span extraction, provide the exact text span from the passage."
        )
        reasoning = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine the reasoning result
        refine_instruction = (
            f"Review the reasoning result: {reasoning}. Ensure that all steps are accurate and complete. "
            "Correct any errors or omissions. Provide a refined version of the reasoning result."
        )
        refined_reasoning = await self.revise(instruction=refine_instruction, context=reasoning)

        # Step 5: Summarize the final answer
        summarize_instruction = (
            f"Based on the refined reasoning: {refined_reasoning}, extract the final answer. "
            "Ensure the answer is concise, clear, and directly addresses the question."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_reasoning)

        # Step 6: Resolve ambiguities using ensemble (if necessary)
        candidates = [reasoning, refined_reasoning, final_answer]
        ensemble_instruction = (
            "Evaluate the candidate answers and select the most accurate and complete one. "
            "If there are discrepancies, resolve them by referring back to the passage and question."
        )
        final_output = await self.ensemble(instruction=ensemble_instruction, contexts=candidates)

        return final_output