# Workflow ID: drop_56_0
# Benchmark: drop
# Data Indices: [460, 90]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information (entities, numbers, relationships)
        extraction_instruction = (
            "Thoroughly analyze the passage and question to extract all relevant entities, numerical values, "
            "and relationships. Identify implicit information that may require inference. Ensure no important "
            "details are missed. Format the output as a structured list for clarity."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze question intent (arithmetic, comparison, span extraction, etc.)
        analysis_instruction = (
            f"Given the extracted information: {extracted_info}\n"
            "Determine the type of reasoning required to answer the question. Specifically identify if the task "
            "involves arithmetic operations, comparisons, counting, or span extraction. Provide a clear reasoning plan."
        )
        reasoning_plan = await self.generate(instruction=analysis_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the identified type
        reasoning_instruction = (
            f"Using the reasoning plan: {reasoning_plan}\n"
            "Execute the required reasoning steps. For arithmetic operations, perform calculations explicitly. "
            "For comparisons, evaluate the criteria thoroughly. For span extraction, ensure precise entity tracking. "
            "Provide a detailed explanation of the reasoning process and the final answer."
        )
        reasoning_results = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine the output to ensure correctness and clarity
        refinement_instruction = (
            f"Review the reasoning results: {reasoning_results}\n"
            "Critique and refine the answer to ensure it is clear, correct, and directly addresses the question. "
            "Correct any ambiguities or errors in the reasoning process."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=reasoning_results)

        return refined_answer