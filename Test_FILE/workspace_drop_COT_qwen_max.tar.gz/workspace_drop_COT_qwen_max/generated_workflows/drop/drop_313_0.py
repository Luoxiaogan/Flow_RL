# Workflow ID: drop_313_0
# Benchmark: drop
# Data Indices: [426, 502]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1 & 2: Parallel Question Analysis and Passage Extraction
        question_analysis_instruction = """
        Analyze the question to determine its intent (e.g., counting, arithmetic, comparison, selection, span extraction).
        Identify key entities, numerical values, and relationships mentioned in the question.
        Provide a structured summary of the question's requirements.
        """
        passage_extraction_instruction = """
        Extract all relevant information from the passage that pertains to the question.
        Focus on identifying entities, numerical values, and their associations.
        Ensure exhaustive extraction to avoid missing critical data.
        Organize the extracted information in a structured format.
        """

        question_analysis, passage_extraction = await asyncio.gather(
            self.generate(instruction=question_analysis_instruction, context=self.problem_text),
            self.generate(instruction=passage_extraction_instruction, context=self.problem_text)
        )

        # Step 3: Numerical Reasoning
        reasoning_instruction = f"""
        Based on the question analysis: {question_analysis}
        And the extracted information: {passage_extraction}
        Perform the required reasoning to answer the question. This may involve:
        - Counting occurrences of specific entities or events
        - Performing arithmetic operations like addition, subtraction, etc.
        - Comparing entities based on given criteria
        Provide a detailed reasoning process and the final result.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validation and Refinement
        validation_instruction = f"""
        Validate the reasoning result: {reasoning_result}
        Ensure it aligns with the question intent and extracted information.
        Address any ambiguities or inconsistencies.
        Provide a refined version of the result if necessary.
        """
        refined_result = await self.revise(instruction=validation_instruction, context=reasoning_result)

        # Step 5: Final Answer Compilation
        final_answer_instruction = f"""
        Compile the final answer based on the refined result: {refined_result}
        Ensure the answer is concise, clear, and includes necessary context.
        """
        final_answer = await self.summarize(instruction=final_answer_instruction, context=refined_result)

        return final_answer