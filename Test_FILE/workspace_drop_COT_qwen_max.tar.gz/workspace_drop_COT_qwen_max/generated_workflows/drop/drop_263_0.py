# Workflow ID: drop_263_0
# Benchmark: drop
# Data Indices: [508, 498]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the passage
        extraction_instruction = """
        Extract all relevant entities, numerical values, and relationships from the passage. 
        Focus on entities mentioned in the question and their associated attributes. 
        Organize the extracted information clearly, associating each value with its corresponding entity.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Understand the question intent
        intent_instruction = f"""
        Analyze the question to determine its intent. Common intents include:
        - Arithmetic operations (e.g., sum, difference, product)
        - Counting occurrences of entities or events
        - Comparison of numerical values or textual spans
        - Extraction of specific text spans
        Use the following extracted information to guide your analysis:
        {extracted_info}
        Clearly specify the reasoning strategy required to answer the question.
        """
        question_intent = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the intent
        reasoning_instruction = f"""
        Based on the interpreted intent:
        {question_intent}
        Perform the required reasoning using the extracted information:
        {extracted_info}
        Ensure the reasoning process is step-by-step and verifiable. Include intermediate results if applicable.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the answer
        refinement_instruction = f"""
        Critique and refine the following reasoning result:
        {reasoning_result}
        Ensure the answer aligns with the question's requirements. Check for:
        - Correct entity-number associations
        - Accurate arithmetic calculations
        - Proper span extraction
        Provide a revised and polished version of the answer.
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Finalize the output
        summarization_instruction = f"""
        Condense the following refined answer into a concise and precise format suitable for submission:
        {refined_answer}
        Ensure clarity and accuracy in the final output.
        """
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_answer)

        return final_answer