# Workflow ID: drop_131_0
# Benchmark: drop
# Data Indices: [334, 249]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract key information (entities, numbers, relationships)
        extraction_instruction = """
        Extract all relevant entities, numerical values, and their relationships from the passage and question.
        Focus on identifying:
        - Entities (e.g., teams, players, locations)
        - Numerical values (e.g., scores, counts, measurements)
        - Relationships between entities and numbers (e.g., which number belongs to which entity)
        Ensure the extraction is exhaustive and precise.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_analysis_instruction = f"""
        Analyze the question to determine its intent. Specifically:
        - Identify whether the question requires arithmetic (e.g., addition, subtraction), counting, comparison, or span extraction.
        - Provide reasoning about the type of operation or extraction needed.
        Use the following extracted information for context: {extracted_info}
        """
        question_intent = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question intent
        reasoning_instruction = f"""
        Based on the question intent ({question_intent}), perform the necessary reasoning steps:
        - If the question involves arithmetic, calculate the result using the extracted numbers.
        - If the question involves counting, count occurrences of specific entities or events.
        - If the question involves comparison, compare values or spans.
        - If the question involves span extraction, identify and return the relevant text span.
        Use the following extracted information for context: {extracted_info}
        """
        reasoning_output = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the reasoning output
        refinement_instruction = f"""
        Critique and refine the reasoning output ({reasoning_output}) to ensure it is accurate and aligns with the question's requirements.
        Specifically:
        - Verify that all calculations are correct.
        - Ensure all entities and numbers are correctly associated.
        - Confirm that the output addresses the question's intent.
        """
        refined_output = await self.revise(instruction=refinement_instruction, context=reasoning_output)

        # Step 5: Summarize the answer
        summary_instruction = f"""
        Condense the refined output ({refined_output}) into a concise and clear answer.
        Ensure the final response directly addresses the question and is easy to understand.
        """
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_output)

        return final_answer