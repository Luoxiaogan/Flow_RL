# Workflow ID: drop_121_0
# Benchmark: drop
# Data Indices: [290, 214]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract Key Information
        extraction_instruction = (
            "Extract all numerical values, named entities, and their relationships from the passage. "
            "Ensure you capture every instance of relevant data, including dates, counts, measurements, "
            "and any associated entities. Format your output as a structured list for clarity."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze Question Intent
        intent_instruction = (
            f"Given the following extracted information: {extracted_info}\n"
            "Analyze the question to determine its intent. Identify whether the question requires "
            "arithmetic operations (e.g., addition, subtraction), comparisons (e.g., greater than, less than), "
            "counting, span extraction, or other forms of reasoning. Provide a clear explanation of the intent."
        )
        question_intent = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Perform Reasoning
        reasoning_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            f"And the identified question intent: {question_intent}\n"
            "Perform the necessary reasoning steps to answer the question. If arithmetic is required, "
            "compute the result. If comparison is needed, compare the relevant values. If span extraction "
            "is required, identify the exact text span. Ensure your reasoning is clear and step-by-step."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and Refine
        refinement_instruction = (
            f"Review the following reasoning result: {reasoning_result}\n"
            "Critique and refine it for accuracy. Check for correct entity-number associations, "
            "verify calculations, and resolve any ambiguities. Provide the refined output."
        )
        refined_result = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Final Answer Synthesis
        final_instruction = (
            f"Synthesize the final answer based on the refined result: {refined_result}\n"
            "Ensure the answer is concise, accurate, and directly addresses the question. If multiple "
            "candidate answers exist, select the best one or merge them into a coherent response."
        )
        final_answer = await self.ensemble(instruction=final_instruction, contexts=[refined_result])

        return final_answer