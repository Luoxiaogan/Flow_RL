# Workflow ID: drop_100_0
# Benchmark: drop
# Data Indices: [790, 127]

class Workflow:
    def __init__(self, config, problem) -> None:
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract key components from the question and passage
        instruction_extract = (
            "Analyze the question and identify the key entities, numbers, and relationships. "
            "Then, extract all relevant information from the passage that pertains to these elements."
        )
        extracted_info = await self.generate(instruction=instruction_extract, context=self.problem_text)

        # Step 2: Perform initial reasoning based on the extracted information
        instruction_reason = (
            f"Based on the extracted information: {extracted_info}, "
            "perform the necessary reasoning steps to answer the question. "
            "This may involve arithmetic operations, comparisons, or selecting specific spans of text."
        )
        reasoning_result = await self.generate(instruction=instruction_reason, context=self.problem_text)

        # Step 3: Refine and validate the reasoning result
        instruction_refine = (
            f"Review the reasoning result: {reasoning_result}. "
            "Ensure that it accurately addresses the question and is supported by the passage. "
            "Correct any errors or ambiguities."
        )
        refined_result = await self.revise(instruction=instruction_refine, context=reasoning_result)

        # Step 4: Generate alternative reasoning paths (if applicable)
        instruction_alternative = (
            "Consider alternative approaches to answering the question. "
            "For example, if the question involves a comparison, consider both entities being compared."
        )
        alternative_result = await self.generate(instruction=instruction_alternative, context=self.problem_text)

        # Step 5: Ensemble to select the best solution
        instruction_ensemble = (
            "Evaluate the following candidate solutions: "
            f"Primary Result: {refined_result}, Alternative Result: {alternative_result}. "
            "Select the most accurate and complete solution based on the question and passage."
        )
        final_result = await self.ensemble(
            instruction=instruction_ensemble,
            contexts=[refined_result, alternative_result]
        )

        # Step 6: Summarize the final result (if necessary)
        instruction_summarize = (
            f"Condense the final result: {final_result} into a concise and clear answer. "
            "Ensure the format matches the expected answer type (number, text span, etc.)."
        )
        summarized_result = await self.summarize(instruction=instruction_summarize, context=final_result)

        return summarized_result