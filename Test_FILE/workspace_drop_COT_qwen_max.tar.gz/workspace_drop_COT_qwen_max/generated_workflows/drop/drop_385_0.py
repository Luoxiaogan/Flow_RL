# Workflow ID: drop_385_0
# Benchmark: drop
# Data Indices: [349, 366]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Understand the question and passage
        question_intent = await self.generate(
            instruction="Analyze the question and determine its type (e.g., comparison, arithmetic, counting, span extraction). "
                        "Identify key entities, numbers, or phrases mentioned in the question that need to be located in the passage. "
                        "Provide a detailed breakdown of what the question is asking for.",
            context=self.problem_text
        )

        # Step 2: Extract relevant information from the passage
        extracted_data = await self.generate(
            instruction=f"Based on the question analysis: {question_intent}, "
                        "extract all relevant numerical values, entities, or text spans from the passage. "
                        "Ensure that each extracted item is clearly associated with its context (e.g., which entity a number belongs to).",
            context=self.problem_text
        )

        # Step 3: Perform reasoning based on the question type
        reasoning_result = await self.generate(
            instruction=f"Using the extracted data: {extracted_data}, "
                        "perform the necessary reasoning to answer the question. "
                        "For comparisons, calculate which value is greater. "
                        "For arithmetic, perform the required operation (addition, subtraction, etc.). "
                        "For span extraction, identify the exact phrase or entity requested.",
            context=self.problem_text
        )

        # Step 4: Refine the reasoning result if needed
        refined_result = await self.revise(
            instruction="Review the reasoning result and ensure it accurately addresses the question. "
                        "Resolve any ambiguities or inconsistencies. "
                        "If necessary, re-examine the passage for additional context.",
            context=reasoning_result
        )

        # Step 5: Summarize the final answer
        final_answer = await self.summarize(
            instruction="Condense the refined reasoning result into a concise, final answer. "
                        "Ensure the answer directly addresses the question and is formatted appropriately.",
            context=refined_result
        )

        return final_answer