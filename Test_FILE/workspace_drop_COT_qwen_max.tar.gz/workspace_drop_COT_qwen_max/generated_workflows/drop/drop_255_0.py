# Workflow ID: drop_255_0
# Benchmark: drop
# Data Indices: [133, 338]

class Workflow:
    def __init__(self, config, problem) -> None:
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio
        
        # Step 1: Extract all relevant information from the passage
        extraction_instruction = """
        Extract ALL relevant information from the passage that could help answer the question. 
        Include numerical values, entities, relationships, and any implicit information. 
        Format the extraction clearly, associating numbers with their respective entities or contexts.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)
        
        # Step 2: Analyze the question to determine the required reasoning
        question_analysis_instruction = f"""
        Analyze the question in detail to determine the type of reasoning required. 
        Identify whether the question involves arithmetic operations, counting, comparison, span extraction, or other reasoning patterns.
        Given the extracted information: {extracted_info}
        Specify the exact entities, numbers, or relationships involved in the reasoning process.
        """
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)
        
        # Step 3: Perform reasoning or calculations
        reasoning_instruction = f"""
        Based on the analysis of the question: {question_analysis}
        Perform the necessary reasoning or calculations to derive the answer. 
        If the question involves arithmetic operations, perform the calculations step by step. 
        If it involves comparisons or selections, clearly justify the choice. 
        Ensure all steps are logical and traceable.
        """
        reasoning_results = await asyncio.gather(
            self.generate(instruction=reasoning_instruction, context=self.problem_text),
            self.generate(instruction=reasoning_instruction, context=self.problem_text)  # Parallel path for robustness
        )
        
        # Step 4: Synthesize the results
        synthesis_instruction = f"""
        Evaluate and synthesize the following reasoning results into a single coherent answer:
        Result 1: {reasoning_results[0]}
        Result 2: {reasoning_results[1]}
        Ensure the final answer directly addresses the question and is consistent with the extracted information.
        """
        synthesized_answer = await self.ensemble(instruction=synthesis_instruction, contexts=reasoning_results)
        
        # Step 5: Refine the final answer
        refinement_instruction = f"""
        Critique and refine the following answer to ensure clarity, correctness, and completeness:
        Answer: {synthesized_answer}
        Make sure the refined answer is concise, accurate, and directly responds to the question.
        """
        final_answer = await self.revise(instruction=refinement_instruction, context=synthesized_answer)
        
        return final_answer