# Workflow ID: drop_75_0
# Benchmark: drop
# Data Indices: [602, 489]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract all relevant information from the passage and question
        extract_instruction = """
        Extract all numerical values, entities, and their relationships from the passage and question. 
        Identify any arithmetic operations (addition, subtraction, etc.), comparisons, or spans requested by the question.
        Ensure that each extracted value is associated with its corresponding entity or context.
        """
        extraction = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Refine the extracted information for accuracy and completeness
        refine_instruction = f"""
        Review the following extracted information: {extraction}
        Correct any errors, fill in missing details, and ensure that all entities and values are accurately associated.
        Highlight any ambiguities or potential misinterpretations.
        """
        refined_info = await self.revise(instruction=refine_instruction, context=extraction)

        # Step 3: Summarize the refined information for clarity
        summarize_instruction = f"""
        Condense the following refined information: {refined_info}
        Retain only the most relevant details needed to answer the question.
        Organize the information in a structured format for further reasoning.
        """
        summarized_info = await self.summarize(instruction=summarize_instruction, context=refined_info)

        # Step 4: Analyze the question type and perform reasoning
        analyze_instruction = f"""
        Based on the summarized information: {summarized_info}
        Determine the type of reasoning required to answer the question (e.g., arithmetic, comparison, span extraction).
        If arithmetic is required, specify the operation (addition, subtraction, etc.) and operands.
        If comparison is required, specify the entities or values to compare.
        If span extraction is required, identify the exact span to extract.
        """
        reasoning_paths = await self.generate(instruction=analyze_instruction, context=summarized_info)

        # Step 5: Execute reasoning paths in parallel
        arithmetic_instruction = f"""
        Perform any arithmetic operations specified in the reasoning paths: {reasoning_paths}
        Ensure that all calculations are accurate and properly documented.
        """
        comparison_instruction = f"""
        Perform any comparisons specified in the reasoning paths: {reasoning_paths}
        Clearly state which entity or value is greater, smaller, or equal.
        """
        span_extraction_instruction = f"""
        Extract any text spans specified in the reasoning paths: {reasoning_paths}
        Ensure that the extracted span is precise and matches the question's requirements.
        """

        arithmetic_result, comparison_result, span_result = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=reasoning_paths),
            self.generate(instruction=comparison_instruction, context=reasoning_paths),
            self.generate(instruction=span_extraction_instruction, context=reasoning_paths)
        )

        # Step 6: Ensemble to select the best answer
        ensemble_instruction = f"""
        Evaluate the following results:
        Arithmetic Result: {arithmetic_result}
        Comparison Result: {comparison_result}
        Span Extraction Result: {span_result}
        Select the most appropriate answer based on the question type and reasoning paths.
        """
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[arithmetic_result, comparison_result, span_result])

        return final_answer