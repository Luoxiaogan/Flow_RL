# Workflow ID: drop_64_0
# Benchmark: drop
# Data Indices: [143, 245]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract all relevant information from the passage
        extraction_instruction = """
        Extract all numerical values, entities, and their relationships from the passage. 
        Include details such as names, dates, events, and any associated numbers. 
        Format the output as a list of key-value pairs where the key is the entity or event, 
        and the value is the associated number or description.
        """
        extracted_data = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question and determine what is being asked
        question_analysis_instruction = f"""
        Analyze the question and determine what type of answer is required. 
        Use the following categories to classify the question: 
        - Arithmetic Operation (e.g., sum, difference, count)
        - Comparison (e.g., greater than, less than)
        - Span Extraction (e.g., name, phrase)
        - Other (specify). 
        Based on the extracted data: {extracted_data}, provide a structured interpretation of the question.
        """
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or calculation to derive the answer
        reasoning_instruction = f"""
        Using the extracted data: {extracted_data} and the question analysis: {question_analysis}, 
        perform the necessary reasoning or calculation to derive the answer. 
        If the question requires an arithmetic operation, show the calculation steps. 
        If it requires a comparison, specify the entities being compared and the result. 
        If it requires span extraction, provide the exact text span from the passage. 
        Format the output clearly and concisely.
        """
        preliminary_answer = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine the answer for accuracy
        refinement_instruction = f"""
        Critique the preliminary answer: {preliminary_answer} against the original problem text. 
        Ensure that all numerical values and entities are correctly associated. 
        Refine the answer if necessary to improve accuracy and clarity.
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=preliminary_answer)

        # Step 5: Summarize the final answer
        summarization_instruction = """
        Condense the refined answer into a concise, final response that directly addresses the question. 
        Ensure the output is clear, accurate, and formatted appropriately.
        """
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_answer)

        return final_answer