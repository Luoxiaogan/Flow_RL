# Workflow ID: drop_171_0
# Benchmark: drop
# Data Indices: [766, 73]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information (entities, numbers, relationships)
        extraction_instruction = (
            "Extract all relevant entities, numerical values, and relationships from the passage and question. "
            "Ensure you capture all potential data points needed for reasoning, including explicit and implicit information."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Understand the question intent
        intent_instruction = (
            f"Given the extracted information: {extracted_info}\n"
            "Interpret the question and determine what type of reasoning is required. "
            "Classify the question into one of the following categories: arithmetic, comparison, counting, or span extraction. "
            "Provide a detailed analysis of the reasoning steps needed to answer the question."
        )
        question_intent = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question intent
        reasoning_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            f"And the question intent analysis: {question_intent}\n"
            "Perform the necessary reasoning steps to answer the question. "
            "If the question involves arithmetic, calculate the result using the extracted numbers. "
            "If the question involves comparison, compare the relevant entities or values. "
            "If the question involves span extraction, identify the exact text span that answers the question. "
            "Provide a detailed explanation of your reasoning process."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine the answer
        refine_instruction = (
            f"Review the reasoning result: {reasoning_result}\n"
            "Critique and refine the answer to ensure it is accurate, concise, and directly addresses the question. "
            "Correct any errors or ambiguities in the reasoning process."
        )
        refined_answer = await self.revise(instruction=refine_instruction, context=reasoning_result)

        # Step 5: Summarize the final answer
        summarize_instruction = (
            f"Given the refined answer: {refined_answer}\n"
            "Condense the final reasoning into a concise answer format. "
            "Ensure the answer is clear and directly responds to the question."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_answer)

        return final_answer