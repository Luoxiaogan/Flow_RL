# Workflow ID: drop_265_0
# Benchmark: drop
# Data Indices: [608, 659]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all numerical values, entities, and relationships from the passage
        extraction_instruction = """
        Extract all numerical values, entities (e.g., names, teams, events), and relationships (e.g., who scored what, when something happened) from the passage. 
        Ensure that the extraction is exhaustive and includes all potentially relevant information. Format the output as a structured list or table for clarity.
        """
        extracted_data = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_analysis_instruction = f"""
        Analyze the question to determine its intent. Specifically:
        - Identify if the question involves arithmetic (e.g., addition, subtraction), counting, comparison, selection, or span extraction.
        - Map the question to a reasoning strategy (e.g., summing numbers, comparing values, extracting a specific text span).
        - Use the following extracted data as context: {extracted_data}.
        Provide a clear and concise summary of the reasoning strategy to be applied.
        """
        reasoning_strategy = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform the reasoning based on the strategy
        reasoning_instruction = f"""
        Based on the reasoning strategy identified ({reasoning_strategy}), perform the necessary calculations or extractions using the extracted data ({extracted_data}).
        Ensure that all steps are clearly documented and justified. If multiple approaches are possible, evaluate them and select the most appropriate one.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine the answer for clarity and correctness
        refinement_instruction = f"""
        Review and refine the reasoning result ({reasoning_result}) to ensure clarity, correctness, and completeness. 
        Address any ambiguities, inconsistencies, or missing details. Format the final answer appropriately based on the question type (e.g., numerical value, text span).
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Parallelize independent operations where possible
        # Example: If there are multiple reasoning paths, execute them in parallel
        # results = await asyncio.gather(
        #     self.generate(instruction="Approach 1...", context=...),
        #     self.generate(instruction="Approach 2...", context=...)
        # )
        # final = await self.ensemble(instruction="Select best...", contexts=results)

        return refined_answer