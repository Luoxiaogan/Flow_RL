# Workflow ID: drop_19_0
# Benchmark: drop
# Data Indices: [422, 91]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the passage
        extract_instruction = (
            "Thoroughly analyze the passage and extract all relevant entities, numerical values, dates, "
            "and spans. Ensure no information is missed and associate each value with its corresponding entity."
        )
        extract_task = self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        analyze_instruction = (
            "Carefully analyze the question and determine its intent. Identify whether the question requires "
            "arithmetic operations (e.g., addition, subtraction), counting, comparison, span extraction, or "
            "other reasoning. Provide a clear explanation of the reasoning steps needed to answer the question."
        )
        analyze_task = self.generate(instruction=analyze_instruction, context=self.problem_text)

        # Execute extraction and analysis in parallel
        extracted_info, question_intent = await asyncio.gather(extract_task, analyze_task)

        # Step 3: Perform reasoning based on the question intent
        reasoning_instruction = (
            f"Using the extracted information: {extracted_info}, and the question intent: {question_intent}, "
            "perform the necessary reasoning to answer the question. If the question involves arithmetic, "
            "show the calculation steps. If it involves counting, ensure all relevant instances are considered. "
            "If it involves comparison, clearly state the basis of comparison. If it involves span extraction, "
            "ensure the correct span is identified."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine the reasoning result
        refine_instruction = (
            "Critique and refine the reasoning result to ensure accuracy and alignment with the question intent. "
            "Correct any errors, clarify ambiguities, and ensure the result is well-supported by the passage."
        )
        refined_result = await self.revise(instruction=refine_instruction, context=reasoning_result)

        # Step 5: Handle ambiguity with Ensemble if necessary
        ensemble_instruction = (
            "Evaluate the refined result and any alternative interpretations. If there are multiple plausible "
            "answers, compare them and select the most appropriate one based on the passage and question intent."
        )
        final_candidates = [refined_result]  # Default candidate
        if "multiple plausible answers" in refined_result:
            alternative_task = self.generate(
                instruction="Generate an alternative interpretation or answer based on the passage.",
                context=self.problem_text
            )
            alternative_result = await alternative_task
            final_candidates.append(alternative_result)
        final_result = await self.ensemble(instruction=ensemble_instruction, contexts=final_candidates)

        # Step 6: Summarize the final answer
        summarize_instruction = (
            "Condense the final reasoning into a concise and clear answer. Ensure the answer directly addresses "
            "the question and is supported by the passage."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=final_result)

        return final_answer