# Workflow ID: drop_46_0
# Benchmark: drop
# Data Indices: [589, 635]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract relevant information from the passage
        extraction_instruction = """
        Extract all entities, numerical values, and their relationships from the passage. 
        Include counts, dates, names, and any other information that could be relevant to answering questions. 
        Organize the extracted information clearly, associating each number with its corresponding entity or context.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Identify the question's intent
        intent_instruction = f"""
        Analyze the question to determine its intent. Common intents include:
        - Arithmetic operations (e.g., sum, difference, count)
        - Comparisons (e.g., greater than, less than)
        - Span extraction (e.g., names, phrases)
        - Multi-hop inference (e.g., combining information from multiple sentences)
        Based on the question, identify the specific intent and explain why this intent is relevant. 
        Use the extracted information below to guide your analysis:
        {extracted_info}
        """
        question_intent = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the identified intent
        reasoning_instruction = f"""
        Using the extracted information and the identified question intent, perform the required reasoning to answer the question. 
        Follow these steps:
        1. If the intent is arithmetic, perform the necessary calculations (e.g., sum, difference).
        2. If the intent is comparison, compare the relevant values and determine the correct answer.
        3. If the intent is span extraction, extract the exact text span that answers the question.
        4. If the intent is multi-hop inference, combine information from multiple parts of the passage to derive the answer.
        Ensure the reasoning process is clear and the answer is accurate. 
        Extracted Information:
        {extracted_info}
        Identified Intent:
        {question_intent}
        """
        raw_answer = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the answer
        refinement_instruction = f"""
        Critique and refine the following answer to ensure it is accurate, complete, and directly addresses the question. 
        Verify that the answer aligns with the passage's context and the question's intent. 
        If there are ambiguities or errors, resolve them by revisiting the extracted information and reasoning process.
        Raw Answer:
        {raw_answer}
        Extracted Information:
        {extracted_info}
        Identified Intent:
        {question_intent}
        """
        final_answer = await self.revise(instruction=refinement_instruction, context=raw_answer)

        return final_answer