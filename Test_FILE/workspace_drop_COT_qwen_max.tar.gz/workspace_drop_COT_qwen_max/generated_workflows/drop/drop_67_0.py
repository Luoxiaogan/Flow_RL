# Workflow ID: drop_67_0
# Benchmark: drop
# Data Indices: [140, 768]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract relevant information from the passage and question
        extraction_instruction = """
        Extract all numerical values, entities, and key phrases from the passage and question.
        Ensure you capture all potential data points that might be relevant for reasoning.
        Format the output as a structured list for clarity.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Interpret the question's intent
        intent_instruction = f"""
        Analyze the question to determine its intent. The possible intents include:
        - Arithmetic operations (addition, subtraction, etc.)
        - Counting occurrences
        - Comparisons (greater than, less than, etc.)
        - Span extraction (entity names, phrases, etc.)
        Use the following extracted information to guide your analysis:
        {extracted_info}
        Provide a clear explanation of the question's intent.
        """
        question_intent = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the interpreted intent
        reasoning_instruction = f"""
        Based on the interpreted question intent ({question_intent}), perform the necessary reasoning.
        Use the extracted information ({extracted_info}) to calculate or derive the answer.
        Ensure numbers are correctly associated with their entities and handle any implicit information.
        Provide a detailed step-by-step reasoning process.
        """
        reasoning_output = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the reasoning output
        refinement_instruction = f"""
        Critique and refine the reasoning output ({reasoning_output}).
        Check for accuracy, logical consistency, and handling of ambiguities or implicit information.
        Ensure the final output aligns with the question's intent.
        """
        refined_output = await self.revise(instruction=refinement_instruction, context=reasoning_output)

        # Step 5: Summarize the refined reasoning into a concise answer
        summary_instruction = f"""
        Condense the refined reasoning ({refined_output}) into a concise answer format.
        Ensure the answer directly addresses the question and is presented clearly.
        """
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_output)

        return final_answer