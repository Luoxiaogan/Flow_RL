# Workflow ID: drop_27_0
# Benchmark: drop
# Data Indices: [715, 585]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract key entities, numbers, and relationships
        extraction_instruction = (
            "Extract all key entities, numerical values, and their relationships from the passage. "
            "Focus on identifying entities (e.g., players, teams), numerical values (e.g., scores, distances), "
            "and their associations with specific events or actions. Also, determine the type of reasoning "
            "required to answer the question (e.g., arithmetic, counting, comparison)."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Decompose the question into actionable steps
        decomposition_instruction = (
            f"Given the following extracted information: {extracted_info}\n"
            "Break down the question into actionable steps. Identify what needs to be done to answer the question. "
            "For example, if the question involves arithmetic operations, specify how to perform the calculation. "
            "If the question requires span extraction or comparison, specify how to locate and compare the relevant spans or entities."
        )
        question_breakdown = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 3: Generate parallel reasoning paths
        arithmetic_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Perform any necessary arithmetic operations (e.g., addition, subtraction) to answer the question. "
            "Ensure that all calculations are accurate and relevant to the question."
        )
        span_extraction_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Identify and extract the relevant text spans or entities that answer the question. "
            "Ensure that the spans are precise and directly address the question."
        )

        # Execute arithmetic and span extraction in parallel
        arithmetic_result, span_extraction_result = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=span_extraction_instruction, context=self.problem_text)
        )

        # Step 4: Synthesize results using Ensemble
        ensemble_instruction = (
            "Evaluate the following reasoning paths and select the most accurate and relevant answer:\n"
            f"1. Arithmetic Result: {arithmetic_result}\n"
            f"2. Span Extraction Result: {span_extraction_result}\n"
            "Choose the result that best answers the question based on the provided instructions."
        )
        synthesized_result = await self.ensemble(instruction=ensemble_instruction, contexts=[arithmetic_result, span_extraction_result])

        # Step 5: Refine the final answer
        refinement_instruction = (
            f"Refine the following answer to ensure it directly addresses the question and is well-formulated:\n"
            f"{synthesized_result}\n"
            "Ensure the final output is precise, clear, and adheres to the required format (e.g., number, text span, or comparative statement)."
        )
        final_answer = await self.revise(instruction=refinement_instruction, context=synthesized_result)

        return final_answer