# Workflow ID: drop_58_0
# Benchmark: drop
# Data Indices: [309, 311]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Initial Analysis - Extract relevant information
        extraction_instruction = (
            "Carefully analyze the passage and question. "
            "Extract all relevant entities, numerical values, and their relationships. "
            "Identify what the question is asking for and highlight key facts that will help answer it."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Refine Entity-Value Associations
        refinement_instruction = (
            f"Given the extracted information: {extracted_info}, "
            "refine the associations between entities and their corresponding numerical values. "
            "Ensure that each number is correctly linked to its entity and resolve any ambiguities."
        )
        refined_info = await self.revise(instruction=refinement_instruction, context=extracted_info)

        # Step 3: Perform Reasoning or Calculation
        reasoning_instruction = (
            f"Based on the refined information: {refined_info}, "
            "determine the type of reasoning required (e.g., arithmetic, counting, comparison). "
            "Perform the necessary calculations or logical steps to arrive at the answer."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=refined_info)

        # Step 4: Final Answer Synthesis
        synthesis_instruction = (
            f"Condense the reasoning result: {reasoning_result} into a concise answer. "
            "Ensure the answer matches the format required by the question (e.g., number, text span, comparison)."
        )
        final_answer = await self.summarize(instruction=synthesis_instruction, context=reasoning_result)

        return final_answer