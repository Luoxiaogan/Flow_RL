# Workflow ID: drop_98_0
# Benchmark: drop
# Data Indices: [30, 799]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract Key Information
        extraction_instruction = (
            "Extract all entities, numerical values, dates, and relationships from the passage and question. "
            "Identify potential data points relevant to answering the question."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze Question Intent
        question_analysis_instruction = (
            "Analyze the question to determine its type. "
            "Classify it as one of the following: arithmetic operation, counting, comparison, selection, span extraction. "
            "Provide a detailed breakdown of what the question is asking."
        )
        question_intent = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform Reasoning (Parallel Execution)
        reasoning_tasks = []

        # Arithmetic Operations
        arithmetic_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "identify relevant numerical values and perform any required arithmetic operations (addition, subtraction, etc.)."
        )
        reasoning_tasks.append(self.generate(instruction=arithmetic_instruction, context=self.problem_text))

        # Counting
        counting_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "count the number of occurrences of the specified entity or event."
        )
        reasoning_tasks.append(self.generate(instruction=counting_instruction, context=self.problem_text))

        # Comparison
        comparison_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "compare the specified values or entities to determine which satisfies the condition."
        )
        reasoning_tasks.append(self.generate(instruction=comparison_instruction, context=self.problem_text))

        # Selection / Span Extraction
        selection_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "identify the correct entity, phrase, or span that answers the question."
        )
        reasoning_tasks.append(self.generate(instruction=selection_instruction, context=self.problem_text))

        # Execute reasoning tasks in parallel
        reasoning_results = await asyncio.gather(*reasoning_tasks)

        # Step 4: Synthesize Results
        synthesis_instruction = (
            "Evaluate the reasoning results and synthesize the most accurate and relevant answer. "
            "Ensure the answer aligns with the question intent and extracted information."
        )
        synthesized_answer = await self.ensemble(instruction=synthesis_instruction, contexts=reasoning_results)

        # Step 5: Refine the Answer
        refinement_instruction = (
            "Critique and refine the synthesized answer. Ensure it is clear, accurate, and directly addresses the question."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=synthesized_answer)

        # Step 6: Summarize the Final Answer
        summary_instruction = (
            "Condense the refined answer into a concise, final response. "
            "Ensure the output is in the correct format (number, date, text span, etc.)."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_answer)

        return final_answer