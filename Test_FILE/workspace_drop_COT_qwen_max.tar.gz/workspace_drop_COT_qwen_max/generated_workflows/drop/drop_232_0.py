# Workflow ID: drop_232_0
# Benchmark: drop
# Data Indices: [439, 335]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract key information from the passage
        extraction_instruction = """
        Extract all relevant entities, numerical values, dates, and spans from the passage.
        Associate each value or span with its corresponding entity or context.
        Ensure no information is missed and provide the output in a structured format.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_analysis_instruction = f"""
        Analyze the question to determine its intent. Based on the extracted information:
        {extracted_info}
        Identify whether the question requires arithmetic operations, counting, comparison, selection, or span extraction.
        Provide a clear explanation of the reasoning process and the expected output format.
        """
        question_intent = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or calculation based on the question intent
        reasoning_instruction = f"""
        Based on the question intent:
        {question_intent}
        Perform the necessary reasoning or calculation using the extracted information:
        {extracted_info}
        Ensure the result is accurate and consistent with the passage and question.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the result
        refinement_instruction = f"""
        Critique and refine the following result:
        {reasoning_result}
        Ensure it is accurate, consistent with the passage and question, and addresses any ambiguities or errors.
        Provide a detailed explanation of the refinement process.
        """
        refined_result = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Finalize the answer
        finalization_instruction = f"""
        Condense the refined result into a concise final answer:
        {refined_result}
        Ensure the answer is in the required format (number, date, text span) and directly addresses the question.
        """
        final_answer = await self.summarize(instruction=finalization_instruction, context=refined_result)

        return final_answer