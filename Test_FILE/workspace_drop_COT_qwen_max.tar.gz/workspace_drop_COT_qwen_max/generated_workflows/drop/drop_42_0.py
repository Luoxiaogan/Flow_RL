# Workflow ID: drop_42_0
# Benchmark: drop
# Data Indices: [272, 531]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information from the passage
        extraction_instruction = (
            "Thoroughly analyze the provided passage and extract ALL relevant information, including "
            "entities, numerical values, dates, and their relationships. Ensure no detail is missed. "
            "Format the extracted information clearly for subsequent reasoning."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Understand the question's intent
        question_intent_instruction = (
            f"Given the following extracted information:\n{extracted_info}\n"
            "Carefully analyze the question and determine its intent. Identify whether the question "
            "requires arithmetic operations, counting, comparison, selection, or span extraction. "
            "Provide a clear explanation of the reasoning process."
        )
        question_intent = await self.generate(instruction=question_intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning/calculation based on the question's intent
        reasoning_instruction = (
            f"Using the extracted information:\n{extracted_info}\nand the identified question intent:\n{question_intent}\n"
            "Perform the necessary reasoning or calculations to answer the question. If the question involves "
            "multiple steps, execute each step systematically. Provide intermediate results and explain your logic."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine and validate the answer
        refinement_instruction = (
            f"Review the following reasoning result:\n{reasoning_result}\n"
            "Critique and refine it to ensure accuracy and completeness. Check for consistency with the passage "
            "and verify that no relevant information was overlooked. Correct any errors or ambiguities."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Finalize the answer
        finalization_instruction = (
            f"Condense the following refined answer:\n{refined_answer}\n"
            "into a concise and clear final response. Ensure the answer directly addresses the question."
        )
        final_answer = await self.summarize(instruction=finalization_instruction, context=refined_answer)

        return final_answer