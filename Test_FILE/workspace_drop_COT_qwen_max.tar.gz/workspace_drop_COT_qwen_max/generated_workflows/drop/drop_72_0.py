# Workflow ID: drop_72_0
# Benchmark: drop
# Data Indices: [179, 787]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (entities, numbers, dates, spans)
        extract_instruction = (
            "Extract all relevant entities, numerical values, dates, and text spans from the passage and question. "
            "Associate each number with its corresponding entity and context. Format the output clearly."
        )
        extract_task = self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Understand question intent
        intent_instruction = (
            "Analyze the question to determine its intent. Classify the question into one of the following types: "
            "arithmetic (addition, subtraction, etc.), counting, comparison, selection, or span extraction. "
            "Provide reasoning for the classification."
        )
        intent_task = self.generate(instruction=intent_instruction, context=self.problem_text)

        # Run Steps 1 and 2 in parallel
        extract_result, intent_result = await asyncio.gather(extract_task, intent_task)

        # Step 3: Perform reasoning/calculation based on question type
        reasoning_instruction = (
            f"Based on the extracted information: {extract_result}\n"
            f"And the identified question intent: {intent_result}\n"
            "Perform the necessary reasoning or calculation to answer the question. "
            "For arithmetic questions, show the calculation steps. For counting, list all relevant instances. "
            "For comparisons, provide a clear justification. For selections, identify the correct entity. "
            "For span extraction, provide the exact text span."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the result
        refine_instruction = (
            "Review the reasoning and result provided. Ensure the answer is accurate, complete, and aligned "
            "with the question intent and extracted information. Correct any errors or ambiguities."
        )
        refined_result = await self.revise(instruction=refine_instruction, context=reasoning_result)

        # Step 5: Finalize the answer
        finalize_instruction = (
            "Condense the reasoning and result into a concise final answer. "
            "Remove unnecessary details while preserving clarity and accuracy."
        )
        final_answer = await self.summarize(instruction=finalize_instruction, context=refined_result)

        return final_answer