# Workflow ID: drop_186_0
# Benchmark: drop
# Data Indices: [463, 459]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Initial Analysis - Extract entities, numbers, dates, and relationships
        initial_analysis_instruction = (
            "Thoroughly analyze the provided passage and question. "
            "Extract all relevant entities, numerical values, dates, and their relationships. "
            "Categorize the information clearly (e.g., entities, numbers, events). "
            "Ensure no important detail is missed."
        )
        initial_analysis = await self.generate(instruction=initial_analysis_instruction, context=self.problem_text)

        # Step 2: Identify Question Intent
        intent_instruction = (
            f"Based on the following extracted information: {initial_analysis}\n"
            "Determine the type of reasoning required to answer the question. "
            "Classify the question as one of the following: arithmetic operation, counting, comparison, span extraction, or other. "
            "Provide clear justification for your classification."
        )
        intent = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Parallel Reasoning Paths
        arithmetic_instruction = (
            f"Using the extracted information: {initial_analysis}\n"
            "Perform any necessary arithmetic operations (e.g., addition, subtraction). "
            "Show all steps and calculations explicitly."
        )
        counting_instruction = (
            f"Using the extracted information: {initial_analysis}\n"
            "Count the occurrences of specific entities or events mentioned in the question. "
            "Clearly list each occurrence and the total count."
        )
        comparison_instruction = (
            f"Using the extracted information: {initial_analysis}\n"
            "Compare values, dates, or spans as required by the question. "
            "Clearly state which is greater, lesser, or if they are equal."
        )
        span_extraction_instruction = (
            f"Using the extracted information: {initial_analysis}\n"
            "Extract the relevant text span that answers the question. "
            "Ensure the span is precise and directly addresses the query."
        )

        # Execute reasoning paths in parallel
        results = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=counting_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text),
            self.generate(instruction=span_extraction_instruction, context=self.problem_text)
        )

        # Step 4: Result Synthesis
        synthesis_instruction = (
            f"Given the following reasoning paths:\n"
            f"- Arithmetic: {results[0]}\n"
            f"- Counting: {results[1]}\n"
            f"- Comparison: {results[2]}\n"
            f"- Span Extraction: {results[3]}\n"
            "Synthesize the most appropriate answer based on the question's intent. "
            "Justify your choice with clear reasoning."
        )
        synthesized_result = await self.ensemble(instruction=synthesis_instruction, contexts=results)

        # Step 5: Final Refinement
        refinement_instruction = (
            f"Refine the following synthesized result: {synthesized_result}\n"
            "Ensure the answer is clear, concise, and directly addresses the question. "
            "Correct any ambiguities or errors."
        )
        final_answer = await self.revise(instruction=refinement_instruction, context=synthesized_result)

        return final_answer