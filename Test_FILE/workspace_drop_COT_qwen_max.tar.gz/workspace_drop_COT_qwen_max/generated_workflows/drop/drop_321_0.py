# Workflow ID: drop_321_0
# Benchmark: drop
# Data Indices: [92, 262]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information from the passage and question
        extraction_instruction = (
            "Extract all entities, numerical values, and key phrases from the passage and question. "
            "Identify relationships between entities and numbers. "
            "Include any implicit information that might be relevant to answering the question."
        )
        question_analysis_instruction = (
            "Analyze the question to determine its intent. "
            "Classify the question into one of the following categories: "
            "arithmetic operation, counting, comparison, span extraction, or other. "
            "Provide reasoning for the classification."
        )
        extraction, question_analysis = await asyncio.gather(
            self.generate(instruction=extraction_instruction, context=self.problem_text),
            self.generate(instruction=question_analysis_instruction, context=self.problem_text)
        )

        # Step 2: Perform reasoning based on the question's intent
        reasoning_instruction = (
            f"Given the extracted information: {extraction}\n"
            f"And the question analysis: {question_analysis}\n"
            "Perform the necessary reasoning or calculation to answer the question. "
            "If the question involves arithmetic, perform the required operations. "
            "If it involves counting, count the relevant occurrences. "
            "If it involves span extraction, identify the exact text span that answers the question. "
            "Ensure the reasoning process is clear and logical."
        )
        reasoning = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Validate and refine the generated answer
        refinement_instruction = (
            f"Review the reasoning: {reasoning}\n"
            "Critique and refine the answer to ensure it aligns with the question's requirements and the passage's context. "
            "Resolve any ambiguities or inconsistencies. "
            "Ensure the final answer is accurate and complete."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=reasoning)

        # Step 4: Summarize the refined answer into a concise response
        summary_instruction = (
            f"Condense the refined answer: {refined_answer}\n"
            "Provide a concise, final response that directly answers the question. "
            "Ensure the response is clear and unambiguous."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_answer)

        return final_answer