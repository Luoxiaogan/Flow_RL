# Workflow ID: drop_215_0
# Benchmark: drop
# Data Indices: [481, 50]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (entities, dates, events) from the passage
        extract_instruction = (
            "Carefully extract all entities, dates, and events mentioned in the passage. "
            "For each entity, associate it with its corresponding attributes (e.g., treaties with their dates). "
            "Ensure no relevant information is missed and format the output as a structured list."
        )
        extract_task = self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Understand the question intent
        interpret_instruction = (
            "Analyze the question and determine what type of information is being requested. "
            "Identify whether the question requires comparison, counting, arithmetic, or span extraction. "
            "Provide a clear explanation of the reasoning process needed to answer the question."
        )
        interpret_task = self.generate(instruction=interpret_instruction, context=self.problem_text)

        # Run extraction and interpretation in parallel
        extracted_info, interpretation = await asyncio.gather(extract_task, interpret_task)

        # Step 3: Perform reasoning/comparison based on extracted information
        reasoning_instruction = (
            f"Using the extracted information: {extracted_info}, and the interpretation: {interpretation}, "
            "perform the necessary reasoning or calculation to answer the question. "
            "If the question involves comparison, explicitly compare the relevant values (e.g., dates). "
            "Provide a detailed step-by-step explanation of the reasoning process."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine and validate the reasoning
        refine_instruction = (
            f"Review the reasoning process: {reasoning_result}. "
            "Critique and refine the reasoning to ensure accuracy and completeness. "
            "Correct any errors and provide an improved version of the reasoning."
        )
        refined_reasoning = await self.revise(instruction=refine_instruction, context=reasoning_result)

        # Step 5: Summarize the final answer
        summarize_instruction = (
            f"Condense the refined reasoning: {refined_reasoning} into a concise, final answer. "
            "Ensure the answer directly addresses the question and is presented in a clear, unambiguous format."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_reasoning)

        return final_answer