# Workflow ID: drop_41_0
# Benchmark: drop
# Data Indices: [579, 348]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information from the passage
        extraction_instruction = (
            "Thoroughly analyze the passage and extract ALL relevant information that could answer the question. "
            "Include numerical values, entities, events, and their relationships. Ensure no detail is missed."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_analysis_instruction = (
            f"Given the extracted information: {extracted_info}\n"
            "Analyze the question to determine its intent. Identify whether it requires arithmetic operations, counting, comparison, span extraction, or another reasoning type. "
            "Provide a clear explanation of the question's requirements."
        )
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Generate multiple reasoning approaches in parallel
        arithmetic_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Perform any required arithmetic operations (addition, subtraction, etc.) based on the question analysis. "
            "Clearly explain your reasoning and calculations."
        )
        counting_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Count the occurrences of relevant entities or events as specified by the question. "
            "Ensure all instances are accounted for and explain your process."
        )
        comparison_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Compare the relevant entities or values as specified by the question. "
            "Clearly state which is greater, lesser, or if they are equal, and explain your reasoning."
        )
        span_extraction_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Identify and extract the exact text span that answers the question. "
            "Ensure the span is directly supported by the passage."
        )

        reasoning_results = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=counting_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text),
            self.generate(instruction=span_extraction_instruction, context=self.problem_text),
        )

        # Step 4: Synthesize the best result using Ensemble
        ensemble_instruction = (
            "Evaluate the following reasoning results and select the one that best answers the question. "
            "Consider accuracy, relevance to the question, and alignment with the passage. "
            "If multiple results are valid, synthesize them into a single coherent answer."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=reasoning_results)

        # Step 5: Refine the final answer for clarity and correctness
        refinement_instruction = (
            f"Review the final answer: {final_answer}\n"
            "Refine it for clarity, correctness, and completeness. Ensure it directly addresses the question and is fully supported by the passage."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        return refined_answer