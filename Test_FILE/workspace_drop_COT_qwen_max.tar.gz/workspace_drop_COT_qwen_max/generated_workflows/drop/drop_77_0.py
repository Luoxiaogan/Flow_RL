# Workflow ID: drop_77_0
# Benchmark: drop
# Data Indices: [223, 351]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Understand the question context
        question_understanding_instruction = (
            "Analyze the question and determine its type: arithmetic operation, counting, comparison, selection, or span extraction. "
            "Identify any specific entities, numerical values, or spans mentioned in the question. "
            "Clarify whether the question requires explicit information from the passage or implicit inference."
        )
        question_context = await self.generate(instruction=question_understanding_instruction, context=self.problem_text)

        # Step 2: Extract relevant information from the passage
        extraction_instruction = (
            f"Based on the following question analysis: {question_context}, "
            "extract all relevant entities, numerical values, dates, or text spans from the passage. "
            "Ensure that each extracted piece of information is clearly associated with its corresponding entity or event. "
            "If there are multiple similar entities, distinguish them carefully."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 3: Perform reasoning and calculation
        reasoning_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "perform the necessary reasoning or calculations to answer the question. "
            "This may involve arithmetic operations, comparisons, counting, or selecting the correct span. "
            "Provide a clear explanation of the reasoning process."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the result
        refinement_instruction = (
            f"Review the following reasoning result: {reasoning_result}. "
            "Ensure that the answer aligns with the question's requirements and resolves any ambiguities. "
            "Refine the result if necessary, ensuring clarity and accuracy."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Generate the final answer
        final_answer_instruction = (
            f"Based on the refined result: {refined_answer}, "
            "synthesize the final answer in a concise and accurate format. "
            "Ensure that the answer directly addresses the question."
        )
        final_answer = await self.generate(instruction=final_answer_instruction, context=self.problem_text)

        return final_answer