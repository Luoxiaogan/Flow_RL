# Workflow ID: drop_368_0
# Benchmark: drop
# Data Indices: [295, 509]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant entities, numbers, dates, and relationships
        extract_instruction = (
            "Thoroughly analyze the passage and extract all entities, numerical values, dates, "
            "and their relationships. Ensure you capture every detail mentioned explicitly or implicitly. "
            "Organize the extracted information clearly."
        )
        extract_entities = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its type and intent
        question_analysis_instruction = (
            "Carefully analyze the question to determine its type (e.g., arithmetic operation, counting, "
            "comparison, selection, span extraction). Identify what exactly is being asked (e.g., sum, difference, "
            "specific entity, date). Provide a clear breakdown of the question's requirements."
        )
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform reasoning/calculation based on the question type
        reasoning_instruction = (
            f"Using the extracted information: {extract_entities}, and the question analysis: {question_analysis}, "
            "perform the necessary reasoning or calculation. Follow these steps:\n"
            "- If the question involves arithmetic, compute the required sum, difference, or other operation.\n"
            "- If the question involves counting, count the relevant occurrences accurately.\n"
            "- If the question involves comparison, compare the relevant values and state the result.\n"
            "- If the question involves selection, identify the correct entity or span.\n"
            "Ensure your reasoning is transparent and traceable back to the passage."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the result
        validation_instruction = (
            f"Review the reasoning result: {reasoning_result}. Cross-check it against the passage and question. "
            "Refine the answer if needed to ensure accuracy and completeness. Address any ambiguities or missing details."
        )
        refined_answer = await self.revise(instruction=validation_instruction, context=reasoning_result)

        # Step 5: Final output
        final_instruction = (
            f"Condense the refined answer: {refined_answer} into the final response format. Ensure it directly "
            "answers the question and adheres to the expected format (e.g., number, date, text span)."
        )
        final_answer = await self.summarize(instruction=final_instruction, context=refined_answer)

        return final_answer