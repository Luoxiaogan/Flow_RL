# Workflow ID: drop_234_0
# Benchmark: drop
# Data Indices: [664, 136]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant entities, numbers, and relationships
        extraction_instruction = """
        Analyze the provided passage and question thoroughly. Identify and extract ALL entities, numerical values, dates, and their relationships.
        Include implicit information inferred from context. Format the output clearly with labels for each extracted item.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Interpret the question's intent
        question_instruction = f"""
        Based on the extracted information: {extracted_info}, determine the intent of the question.
        Specify whether the task involves arithmetic operations, counting, comparison, span extraction, or another type of reasoning.
        Provide a clear explanation of the reasoning process.
        """
        question_intent = await self.generate(instruction=question_instruction, context=self.problem_text)

        # Step 3: Perform reasoning and calculations in parallel
        reasoning_paths = [
            f"Perform addition or aggregation based on the extracted information: {extracted_info}",
            f"Perform subtraction or comparison based on the extracted information: {extracted_info}",
            f"Extract spans or resolve entities based on the extracted information: {extracted_info}"
        ]
        reasoning_tasks = [
            self.generate(instruction=path, context=self.problem_text)
            for path in reasoning_paths
        ]
        reasoning_results = await asyncio.gather(*reasoning_tasks)

        # Step 4: Resolve ambiguities using Ensemble
        ensemble_instruction = f"""
        Evaluate the following reasoning results and select the most plausible answer:
        Results: {reasoning_results}
        Ensure the selected answer aligns with the question's intent: {question_intent}.
        """
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=reasoning_results)

        # Step 5: Refine the final answer
        refine_instruction = f"""
        Revise the following answer to ensure it is concise, accurate, and properly formatted:
        Answer: {final_answer}
        """
        refined_answer = await self.revise(instruction=refine_instruction, context=final_answer)

        return refined_answer