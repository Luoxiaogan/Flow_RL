# Workflow ID: drop_88_0
# Benchmark: drop
# Data Indices: [141, 389]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all relevant information from the passage and question
        extraction_task = self.generate(
            instruction="Extract all numerical values, entities, and key phrases from the passage and question. "
                        "Identify relationships between entities and numbers, and associate each number with its corresponding entity. "
                        "Include any implicit information that might be relevant to answering the question.",
            context=self.problem_text
        )

        # Step 2: Analyze the question to determine the type of reasoning required
        question_analysis_task = self.generate(
            instruction="Analyze the question to determine the type of reasoning required (e.g., arithmetic, comparison, span extraction). "
                        "Provide a detailed breakdown of the question intent and specify what needs to be done to answer it.",
            context=self.problem_text
        )

        # Run extraction and analysis in parallel
        extraction, question_analysis = await asyncio.gather(extraction_task, question_analysis_task)

        # Step 3: Perform reasoning based on the question intent
        reasoning_instruction = (
            f"Based on the extracted information: {extraction}\n"
            f"And the question analysis: {question_analysis}\n"
            "Perform the required reasoning to answer the question. "
            "If the question involves arithmetic operations, compute the result. "
            "If it involves comparison, evaluate the candidates. "
            "If it involves span extraction, identify the exact text span."
        )
        reasoning_output = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine and validate the reasoning output
        refinement_instruction = (
            f"Critique and refine the following reasoning output: {reasoning_output}\n"
            "Ensure the answer is accurate, well-reasoned, and aligns with the question intent. "
            "Correct any errors or ambiguities."
        )
        refined_output = await self.revise(instruction=refinement_instruction, context=reasoning_output)

        # Step 5: Summarize the refined output if necessary
        final_answer = await self.summarize(
            instruction="Condense the refined output into a concise and clear final answer.",
            context=refined_output
        )

        return final_answer