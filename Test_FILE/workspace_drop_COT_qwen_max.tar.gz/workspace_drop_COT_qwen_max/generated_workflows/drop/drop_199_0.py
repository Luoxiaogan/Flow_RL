# Workflow ID: drop_199_0
# Benchmark: drop
# Data Indices: [760, 565]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key entities, values, and relationships
        extraction_instruction = """
        Analyze the passage and question to extract all relevant entities, numerical values, and relationships. 
        Identify what the question is asking for and categorize the problem type (e.g., arithmetic, comparison, span extraction).
        Provide a structured summary of the extracted information.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Associate entities with their values
        association_instruction = f"""
        Using the extracted information: {extracted_info}
        Map each entity mentioned in the question to its corresponding value(s) or span(s) from the passage.
        Ensure all associations are explicit and unambiguous.
        """
        entity_value_mapping = await self.generate(instruction=association_instruction, context=self.problem_text)

        # Step 3: Determine reasoning strategy based on question type
        reasoning_instruction = f"""
        Based on the extracted information: {extracted_info} and entity-value mapping: {entity_value_mapping}
        Identify the reasoning strategy required to answer the question. For example:
        - Arithmetic operations (addition, subtraction, etc.)
        - Counting occurrences
        - Comparing values
        - Extracting spans
        Provide a detailed plan for solving the problem.
        """
        reasoning_strategy = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Generate candidate solutions using parallel execution
        solution_instruction_template = f"""
        Using the reasoning strategy: {reasoning_strategy}
        Solve the problem step by step. Ensure all calculations, comparisons, or extractions are accurate.
        """

        # Parallel execution for robustness
        candidate_solutions = await asyncio.gather(
            self.generate(instruction=solution_instruction_template + " Approach 1: Direct calculation", context=self.problem_text),
            self.generate(instruction=solution_instruction_template + " Approach 2: Alternative reasoning path", context=self.problem_text)
        )

        # Step 5: Ensemble to select the best solution
        ensemble_instruction = f"""
        Evaluate the following candidate solutions and select the most accurate one:
        Solution 1: {candidate_solutions[0]}
        Solution 2: {candidate_solutions[1]}
        Ensure the final answer aligns with the question requirements and extracted information.
        """
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=candidate_solutions)

        # Step 6: Validate and refine the final solution
        refinement_instruction = f"""
        Critique and refine the following solution: {final_solution}
        Ensure it is accurate, complete, and formatted correctly according to the question type.
        """
        refined_solution = await self.revise(instruction=refinement_instruction, context=final_solution)

        return refined_solution