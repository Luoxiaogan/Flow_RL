# Workflow ID: drop_345_0
# Benchmark: drop
# Data Indices: [286, 124]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information from the passage and question
        extract_instruction = (
            "Thoroughly analyze the passage and question. "
            "Extract all entities, numerical values, relationships, and implicit reasoning cues. "
            "Format the output as a structured summary, clearly labeling each piece of information."
        )
        extract_context = self.problem_text
        extraction_task = self.generate(instruction=extract_instruction, context=extract_context)

        # Step 2: Analyze the question intent and perform reasoning
        reason_instruction = (
            "Based on the extracted information, determine what the question is asking for. "
            "Perform any necessary calculations, comparisons, or selections to derive the answer. "
            "Provide a clear explanation of your reasoning process."
        )
        reasoning_task = self.generate(instruction=reason_instruction, context=self.problem_text)

        # Run extraction and reasoning in parallel
        extracted_info, reasoning_output = await asyncio.gather(extraction_task, reasoning_task)

        # Step 3: Refine the output to ensure correctness and clarity
        refine_instruction = (
            f"Given the reasoning output: {reasoning_output}, refine it to ensure clarity, correctness, and alignment with the question intent. "
            "If necessary, correct any errors or ambiguities in the reasoning process."
        )
        refined_output = await self.revise(instruction=refine_instruction, context=reasoning_output)

        # Step 4: Handle ambiguities or conflicting interpretations (if needed)
        ambiguity_check_instruction = (
            f"Analyze the refined output: {refined_output} for any ambiguities or conflicting interpretations. "
            "If multiple valid answers exist, provide them as separate options."
        )
        ambiguity_check = await self.generate(instruction=ambiguity_check_instruction, context=refined_output)

        # If ambiguities exist, use Ensemble to resolve them
        if "option" in ambiguity_check.lower():
            ensemble_instruction = (
                "Evaluate the following candidate solutions and select the most appropriate one. "
                "Provide a justification for your choice."
            )
            final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[refined_output, ambiguity_check])
        else:
            final_answer = refined_output

        return final_answer