# Workflow ID: drop_134_0
# Benchmark: drop
# Data Indices: [83, 750]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all relevant entities, numbers, and relationships
        extraction_instruction = (
            "Extract all numerical values, entities, dates, and their relationships from the passage. "
            "Include explicit mentions as well as any implicit information that can be inferred. "
            "Organize the extracted data into categories such as 'entities', 'numbers', 'dates', and 'relationships'."
        )
        extracted_data = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Understand the question and formulate a reasoning strategy
        strategy_instruction = (
            f"Given the extracted data: {extracted_data}, analyze the question to determine its intent. "
            "Identify whether the question requires arithmetic operations, comparisons, counting, or span extraction. "
            "Provide a detailed reasoning strategy that outlines the steps needed to answer the question."
        )
        reasoning_strategy = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Execute parallel reasoning paths based on the strategy
        reasoning_tasks = []
        if "arithmetic" in reasoning_strategy.lower():
            arithmetic_instruction = (
                f"Perform the required arithmetic operations using the extracted data: {extracted_data}. "
                "Ensure that all calculations are accurate and explain each step."
            )
            reasoning_tasks.append(self.generate(instruction=arithmetic_instruction, context=self.problem_text))
        
        if "comparison" in reasoning_strategy.lower():
            comparison_instruction = (
                f"Compare the relevant entities or values from the extracted data: {extracted_data}. "
                "Clearly explain which entity or value is greater, smaller, or equal."
            )
            reasoning_tasks.append(self.generate(instruction=comparison_instruction, context=self.problem_text))
        
        if "counting" in reasoning_strategy.lower():
            counting_instruction = (
                f"Count the occurrences or instances specified in the question using the extracted data: {extracted_data}. "
                "Ensure that no instances are missed and explain the counting process."
            )
            reasoning_tasks.append(self.generate(instruction=counting_instruction, context=self.problem_text))
        
        if "span extraction" in reasoning_strategy.lower():
            span_instruction = (
                f"Extract the relevant text span from the passage based on the question and the extracted data: {extracted_data}. "
                "Ensure that the span accurately answers the question."
            )
            reasoning_tasks.append(self.generate(instruction=span_instruction, context=self.problem_text))

        # Execute all reasoning tasks in parallel
        reasoning_results = await asyncio.gather(*reasoning_tasks)

        # Step 4: Synthesize results and select the best answer
        synthesis_instruction = (
            "Evaluate the following reasoning results and select the most accurate answer. "
            "If there are conflicting interpretations, resolve them based on the extracted data and the question's intent."
        )
        synthesized_answer = await self.ensemble(instruction=synthesis_instruction, contexts=reasoning_results)

        # Step 5: Refine the final answer for clarity and correctness
        refinement_instruction = (
            "Review the synthesized answer and refine it for clarity, accuracy, and completeness. "
            "Ensure that the final answer directly addresses the question."
        )
        final_answer = await self.revise(instruction=refinement_instruction, context=synthesized_answer)

        return final_answer