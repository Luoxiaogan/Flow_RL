# Workflow ID: drop_181_0
# Benchmark: drop
# Data Indices: [432, 10]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract key information from the passage
        extraction_instruction = (
            "Extract all numerical values, entities, and relationships mentioned in the passage. "
            "Focus on potential answer candidates such as numbers, dates, or named entities. "
            "Ensure completeness and accuracy."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question intent
        question_analysis_instruction = (
            "Interpret the question and determine its intent. "
            "Identify whether the question involves arithmetic, counting, comparison, selection, or span extraction. "
            "Provide a clear explanation of the reasoning required to answer the question."
        )
        question_intent = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question intent
        reasoning_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            f"and the question intent: {question_intent}\n"
            "Perform the necessary reasoning to answer the question. "
            "Include all steps of the reasoning process and ensure clarity and precision."
        )
        reasoning_output = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine the reasoning output
        refinement_instruction = (
            "Critique and refine the provided reasoning output. "
            "Ensure the answer is precise, accurate, and directly addresses the question. "
            "Correct any errors or ambiguities."
        )
        refined_output = await self.revise(instruction=refinement_instruction, context=reasoning_output)

        # Step 5: Summarize the final answer
        summary_instruction = (
            "Condense the refined reasoning into a concise final answer. "
            "Ensure clarity and remove any unnecessary details. "
            "The final answer should directly address the question."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_output)

        return final_answer