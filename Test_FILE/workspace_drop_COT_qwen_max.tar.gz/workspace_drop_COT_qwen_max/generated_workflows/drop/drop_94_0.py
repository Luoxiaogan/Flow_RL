# Workflow ID: drop_94_0
# Benchmark: drop
# Data Indices: [692, 45]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Initial Analysis and Extraction
        extraction_instruction = (
            "Thoroughly analyze the provided passage and question. "
            "Extract all numerical values, entities, relationships, and implicit reasoning patterns. "
            "Ensure no relevant information is missed. Format the output clearly."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Question Understanding and Strategy Formulation
        strategy_instruction = (
            f"Based on the extracted information: {extracted_info}, analyze the question. "
            "Determine the type of reasoning required (e.g., arithmetic, comparison, span extraction). "
            "Outline the steps needed to solve the problem. Be explicit and detailed."
        )
        reasoning_strategy = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Parallel Reasoning Paths
        arithmetic_instruction = (
            f"Using the extracted information: {extracted_info}, perform any required arithmetic operations. "
            "Show step-by-step calculations and ensure accuracy."
        )
        comparison_instruction = (
            f"Using the extracted information: {extracted_info}, compare entities or values as needed. "
            "Highlight differences or similarities explicitly."
        )
        span_extraction_instruction = (
            f"Using the extracted information: {extracted_info}, identify and extract relevant text spans. "
            "Ensure the spans are precise and contextually correct."
        )

        reasoning_paths = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text),
            self.generate(instruction=span_extraction_instruction, context=self.problem_text)
        )

        # Step 4: Synthesis and Validation
        synthesis_instruction = (
            "Evaluate the following reasoning paths and synthesize the correct result. "
            "Ensure the final answer aligns with the question's requirements."
        )
        final_result = await self.ensemble(instruction=synthesis_instruction, contexts=reasoning_paths)

        # Step 5: Final Output Refinement
        refinement_instruction = (
            "Refine the final output to ensure it is concise, accurate, and formatted appropriately. "
            "Remove any unnecessary details while preserving the essential information."
        )
        refined_output = await self.revise(instruction=refinement_instruction, context=final_result)

        return refined_output