# Workflow ID: drop_52_0
# Benchmark: drop
# Data Indices: [27, 116]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information (entities, numbers, relationships)
        extraction_instruction = (
            "Carefully analyze the passage and question. "
            "Extract all entities, numerical values, and their relationships. "
            "Pay special attention to any numerical values associated with specific entities "
            "or events mentioned in the question."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Perform reasoning based on the question
        reasoning_instruction = (
            f"Based on the following extracted information: {extracted_info}\n"
            "Analyze the question and perform the required reasoning. "
            "If the question involves arithmetic operations, calculate the result explicitly. "
            "If there are multiple possible answers, list them all with explanations."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Refine the reasoning output
        refinement_instruction = (
            "Critique the following reasoning output for accuracy and completeness. "
            "Ensure all steps are logically sound and address the question fully. "
            "Correct any errors or omissions."
        )
        refined_result = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 4: Handle ambiguities with Ensemble (if needed)
        ensemble_instruction = (
            "Evaluate the following candidate solutions. "
            "Select the most accurate and complete answer, or synthesize a new one if necessary."
        )
        # Parallel generation of alternative approaches
        alternative_approach_1 = await self.generate(
            instruction="Approach the problem differently by focusing on implicit information.",
            context=self.problem_text
        )
        alternative_approach_2 = await self.generate(
            instruction="Approach the problem differently by re-examining entity associations.",
            context=self.problem_text
        )
        ensemble_result = await self.ensemble(
            instruction=ensemble_instruction,
            contexts=[refined_result, alternative_approach_1, alternative_approach_2]
        )

        # Step 5: Summarize the final answer
        summary_instruction = (
            "Condense the following information into a concise and clear answer. "
            "Ensure the response directly addresses the question."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=ensemble_result)

        return final_answer