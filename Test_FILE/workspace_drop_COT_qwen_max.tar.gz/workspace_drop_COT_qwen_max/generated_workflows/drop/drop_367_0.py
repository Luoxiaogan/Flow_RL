# Workflow ID: drop_367_0
# Benchmark: drop
# Data Indices: [441, 85]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information from the passage
        extraction_instruction = (
            "Identify all entities, numbers, and events mentioned in the passage that could be relevant "
            "to answering the question. Include explicit and implicit information, ensuring no detail is missed."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Refine the extracted information to align with the question's intent
        refinement_instruction = (
            f"Refine the following extracted information to ensure it is relevant to the question: {extracted_info}. "
            "Remove any irrelevant details and clarify ambiguous references."
        )
        refined_info = await self.revise(instruction=refinement_instruction, context=extracted_info)

        # Step 3: Perform reasoning based on the question type
        reasoning_instruction = (
            f"Based on the refined information: {refined_info}, analyze the question and determine the answer. "
            "If the question involves arithmetic, perform the necessary calculations. If it involves counting, "
            "count the relevant occurrences. For comparisons, compare the relevant entities. For span extraction, "
            "identify the exact text span that answers the question."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Summarize or Ensemble the final result
        summary_instruction = (
            f"Condense the reasoning result: {reasoning_result} into a concise answer that directly addresses the question."
        )
        summarized_answer = await self.summarize(instruction=summary_instruction, context=reasoning_result)

        ensemble_instruction = (
            f"Evaluate the following candidate answers: {reasoning_result}, {summarized_answer}. "
            "Select the most accurate and complete answer based on the question and passage."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[reasoning_result, summarized_answer])

        return final_answer