# Workflow ID: drop_267_0
# Benchmark: drop
# Data Indices: [424, 604]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all relevant entities, numbers, and relationships
        extraction_instruction = (
            "Extract all entities, numerical values, dates, and their relationships from the passage and question. "
            "Organize the information into structured format such as key-value pairs or lists. "
            "Ensure no relevant information is missed."
        )
        extracted_data = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Understand the question type and intent
        question_summary_instruction = (
            "Analyze the question to determine its type (arithmetic, counting, comparison, selection, span extraction) "
            "and intent. Summarize the question into a concise representation of what is being asked."
        )
        question_summary = await self.summarize(instruction=question_summary_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or calculation based on extracted data
        reasoning_instruction = (
            f"Based on the following extracted information: {extracted_data} "
            f"and the summarized question: {question_summary}, "
            "perform the required reasoning or calculation step by step. "
            "Ensure the reasoning process is clear and logical."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine the answer
        refinement_instruction = (
            "Critique and refine the following reasoning result to ensure it is precise, well-formatted, "
            "and directly addresses the question. Correct any errors or ambiguities."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Optional Step 5: Handle ambiguity with ensemble if needed
        # Generate multiple candidate solutions and select the best one
        async def generate_candidate(approach_instruction):
            return await self.generate(instruction=approach_instruction, context=self.problem_text)

        candidate_instructions = [
            "Approach the problem using arithmetic reasoning.",
            "Approach the problem using entity tracking and span extraction.",
            "Approach the problem using comparative analysis."
        ]
        candidates = await asyncio.gather(
            *[generate_candidate(instr) for instr in candidate_instructions]
        )
        ensemble_instruction = (
            "Evaluate the following candidate solutions and select the best one. "
            "If multiple solutions are valid, synthesize them into a single coherent answer."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=candidates)

        return final_answer