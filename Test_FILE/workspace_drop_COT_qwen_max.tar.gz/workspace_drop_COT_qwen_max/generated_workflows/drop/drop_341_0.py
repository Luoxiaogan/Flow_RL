# Workflow ID: drop_341_0
# Benchmark: drop
# Data Indices: [682, 15]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Analyze the question intent and classify the question type
        question_intent_instruction = """
        Analyze the question and classify its type. Determine whether the question requires:
        - Arithmetic operations (e.g., addition, subtraction, multiplication, division)
        - Counting (e.g., how many times something occurs)
        - Comparison (e.g., which is greater, longer, more)
        - Selection (e.g., which team won, what happened first/last)
        - Span extraction (e.g., who did something, what was the name of something)
        Provide a clear classification and any relevant keywords or patterns in the question.
        """
        question_intent = await self.generate(instruction=question_intent_instruction, context=self.problem_text)

        # Step 2: Extract relevant information from the passage
        extraction_instruction = f"""
        Based on the following question intent analysis:
        {question_intent}
        Extract all relevant information from the passage, including:
        - Numerical values and their associated entities
        - Key entities and their relationships
        - Any implicit or explicit information needed to answer the question
        Organize the extracted information clearly and label it appropriately.
        """
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or calculation based on the question type
        reasoning_instruction = f"""
        Using the following extracted information:
        {extraction}
        Perform the necessary reasoning or calculation to answer the question. Follow these guidelines:
        - For arithmetic operations, compute the result step by step.
        - For counting, tally occurrences of the specified entity or event.
        - For comparisons, evaluate the relationship between entities or values.
        - For selection, identify the correct entity or event based on the criteria.
        - For span extraction, locate and extract the exact text span that answers the question.
        Provide a detailed reasoning process and the final answer.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the answer
        refinement_instruction = f"""
        Review the following reasoning and answer:
        {reasoning_result}
        Ensure that:
        - The reasoning process is sound and aligns with the question intent.
        - The answer is accurate and in the correct format.
        - Any ambiguities or errors are corrected.
        Provide the refined answer and a summary of improvements made.
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Summarize the final output
        summary_instruction = f"""
        Summarize the final answer and the reasoning process in a concise format. Ensure clarity and completeness.
        Final Answer: {refined_answer}
        """
        final_output = await self.summarize(instruction=summary_instruction, context=refined_answer)

        return final_output