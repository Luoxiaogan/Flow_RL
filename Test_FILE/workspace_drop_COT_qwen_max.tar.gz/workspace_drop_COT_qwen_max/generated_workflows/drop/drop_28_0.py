# Workflow ID: drop_28_0
# Benchmark: drop
# Data Indices: [398, 437]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant entities, numbers, and relationships
        extraction_instruction = (
            "Thoroughly analyze the provided passage. Extract ALL entities, numerical values, dates, "
            "and relationships between them. Ensure no information is missed, as it may be critical "
            "for answering the question. Organize the extracted information clearly."
        )
        extracted_data = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_analysis_instruction = (
            "Carefully analyze the question. Determine what type of reasoning is required: "
            "arithmetic operation, counting, comparison, selection, or span extraction. "
            "Identify key terms and phrases that indicate the expected answer format."
        )
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or calculation based on the question type
        reasoning_instruction = (
            f"Using the extracted data: {extracted_data}\n"
            f"and the question analysis: {question_analysis}\n"
            "Perform the necessary reasoning or calculation to answer the question. "
            "If it involves arithmetic, show the calculation steps. If it involves counting, "
            "list the items being counted. If it involves comparison, clearly state the basis of comparison. "
            "Ensure the reasoning is precise and aligns with the question intent."
        )
        reasoning_output = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the reasoning output
        refinement_instruction = (
            "Critique the reasoning output. Check for accuracy, completeness, and alignment with the question. "
            "Address any ambiguities or potential errors. Refine the output to ensure it is correct and clear."
        )
        refined_output = await self.revise(instruction=refinement_instruction, context=reasoning_output)

        # Step 5: Summarize the final answer
        summarization_instruction = (
            "Condense the refined reasoning output into a concise answer. Ensure the answer directly "
            "addresses the question and is presented in the expected format (number, date, text span, etc.)."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_output)

        return final_answer