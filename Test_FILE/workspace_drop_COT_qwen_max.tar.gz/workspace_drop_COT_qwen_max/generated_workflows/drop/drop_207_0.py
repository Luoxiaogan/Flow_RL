# Workflow ID: drop_207_0
# Benchmark: drop
# Data Indices: [183, 471]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Initial Analysis - Understand the question type
        initial_analysis = await self.generate(
            instruction="Analyze the question to determine the type of reasoning required. "
                        "Identify whether the question involves counting, arithmetic operations, comparisons, "
                        "span extraction, or other forms of reasoning. Provide a detailed breakdown of the "
                        "question's intent and requirements.",
            context=self.problem_text
        )

        # Step 2: Extract Entities and Numbers
        extraction = await self.generate(
            instruction="Extract all entities (e.g., players, teams, events) and numerical values from the passage. "
                        "Provide them in a structured format, associating each number with its corresponding entity "
                        "or event. Ensure no relevant information is missed.",
            context=self.problem_text
        )

        # Step 3: Question-Specific Reasoning
        reasoning = await self.generate(
            instruction=f"Based on the initial analysis: {initial_analysis} and the extracted information: {extraction}, "
                        "perform the required reasoning to answer the question. Follow these guidelines: "
                        "- For counting questions, count occurrences of specific entities or events. "
                        "- For arithmetic questions, perform the necessary calculations using the extracted numbers. "
                        "- For span extraction questions, identify the exact text span that answers the question. "
                        "Provide a detailed step-by-step reasoning process.",
            context=self.problem_text
        )

        # Step 4: Validation and Refinement
        refined_answer = await self.revise(
            instruction="Review the reasoning process and the generated answer. Identify and correct any errors "
                        "or ambiguities. Ensure the answer is accurate, complete, and directly addresses the question.",
            context=reasoning
        )

        # Step 5: Final Answer Synthesis
        final_answer = await self.summarize(
            instruction="Condense the reasoning and validation results into a concise, final answer. "
                        "Ensure the answer is clear, precise, and directly responsive to the question.",
            context=refined_answer
        )

        return final_answer