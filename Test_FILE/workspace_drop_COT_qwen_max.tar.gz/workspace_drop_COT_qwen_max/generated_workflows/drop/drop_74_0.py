# Workflow ID: drop_74_0
# Benchmark: drop
# Data Indices: [411, 492]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract all relevant entities, numerical values, and relationships
        extraction_instruction = """
        Extract all entities, numerical values, and their relationships from the passage. 
        Pay special attention to:
        - Explicit mentions of numbers and their associated entities.
        - Implicit relationships that require inference from context.
        - Ambiguous references (e.g., pronouns) and resolve them using coreference resolution.
        - Multiple similar entities and ensure correct association of numbers with their respective entities.
        Format the output as a structured list for clarity.
        """
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_analysis_instruction = f"""
        Analyze the question and determine its intent based on the following categories:
        - Arithmetic Operations: Identify if the question requires addition, subtraction, multiplication, or division.
        - Counting: Check if the question asks for a count of occurrences or instances.
        - Comparison: Determine if the question involves comparing two or more entities.
        - Span Extraction: Identify if the question requires extracting a specific text span from the passage.
        Use the extracted information: {extraction} to guide your analysis.
        Provide a clear breakdown of the question's components and specify the required reasoning steps.
        """
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform parallel reasoning based on the question type
        reasoning_tasks = []
        if "Arithmetic Operations" in question_analysis:
            arithmetic_instruction = f"""
            Perform the required arithmetic operation using the extracted numerical values: {extraction}.
            Clearly show the calculation steps and provide the final result.
            """
            reasoning_tasks.append(self.generate(instruction=arithmetic_instruction, context=self.problem_text))

        if "Comparison" in question_analysis:
            comparison_instruction = f"""
            Compare the relevant entities and their associated values from the extracted information: {extraction}.
            Determine which entity is greater, longer, or more based on the question's requirements.
            Provide a clear justification for your conclusion.
            """
            reasoning_tasks.append(self.generate(instruction=comparison_instruction, context=self.problem_text))

        if "Span Extraction" in question_analysis:
            span_extraction_instruction = f"""
            Extract the exact text span from the passage that answers the question. 
            Use the extracted information: {extraction} to ensure accuracy.
            """
            reasoning_tasks.append(self.generate(instruction=span_extraction_instruction, context=self.problem_text))

        # Execute reasoning tasks in parallel
        reasoning_results = await asyncio.gather(*reasoning_tasks)

        # Step 4: Validate and refine the results
        refinement_tasks = [
            self.revise(
                instruction=f"Validate and refine the following result: {result}. Ensure it aligns with the original problem and instructions.",
                context=self.problem_text
            )
            for result in reasoning_results
        ]
        refined_results = await asyncio.gather(*refinement_tasks)

        # Step 5: Synthesize the final answer
        synthesis_instruction = """
        Evaluate the refined results and synthesize them into a single coherent answer. 
        If multiple candidates exist, select the most appropriate one based on the question's requirements.
        Ensure the final answer is clear, concise, and directly addresses the question.
        """
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=refined_results)

        return final_answer