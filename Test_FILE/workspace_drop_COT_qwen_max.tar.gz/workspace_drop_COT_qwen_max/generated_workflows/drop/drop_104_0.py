# Workflow ID: drop_104_0
# Benchmark: drop
# Data Indices: [636, 568]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all numerical values, entities, and their relationships
        extraction_instruction = (
            "Extract all numerical values, entities, and their relationships from the passage. "
            "Ensure you capture all mentions of scores, counts, dates, and other quantifiable data. "
            "For each number, associate it with the relevant entity or event described in the text."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine the reasoning pattern
        question_analysis_instruction = (
            f"Given the extracted information: {extracted_info}, analyze the question to determine the reasoning pattern required. "
            "Identify whether the question requires arithmetic operations (e.g., sum, difference), counting, comparison, or span extraction. "
            "Provide a clear directive for how to proceed with solving the question."
        )
        reasoning_directive = await self.revise(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Parallel reasoning paths
        arithmetic_instruction = (
            f"Perform arithmetic operations based on the extracted information: {extracted_info}. "
            "Calculate sums, differences, or other numerical results as implied by the question."
        )
        span_extraction_instruction = (
            f"Extract the relevant text span from the passage based on the extracted information: {extracted_info}. "
            "Focus on identifying the exact phrase or entity that answers the question."
        )
        comparison_instruction = (
            f"Compare numerical values or entities based on the extracted information: {extracted_info}. "
            "Determine which value is greater, lesser, or otherwise satisfies the question's criteria."
        )

        arithmetic_result, span_result, comparison_result = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=span_extraction_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text)
        )

        # Step 4: Ensemble decision
        ensemble_instruction = (
            "Evaluate the following candidate solutions and select the one that best answers the question. "
            "Ensure the selected solution aligns with the reasoning directive and provides the most accurate and complete answer."
        )
        final_answer = await self.ensemble(
            instruction=ensemble_instruction,
            contexts=[arithmetic_result, span_result, comparison_result]
        )

        # Step 5: Final refinement
        refinement_instruction = (
            f"Refine the final answer: {final_answer} to ensure it is concise, accurate, and properly formatted. "
            "Remove any unnecessary details while preserving the core information required to answer the question."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=self.problem_text)

        return refined_answer