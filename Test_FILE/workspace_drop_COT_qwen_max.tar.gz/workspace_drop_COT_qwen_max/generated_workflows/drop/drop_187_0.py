# Workflow ID: drop_187_0
# Benchmark: drop
# Data Indices: [528, 638]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the passage and question
        extraction_instruction = (
            "Thoroughly analyze the passage and question. "
            "Extract all entities, numbers, dates, and their relationships. "
            "Include any implicit information that can be inferred. "
            "Format your response as a structured list for clarity."
        )
        question_intent_instruction = (
            "Analyze the question to determine its intent. "
            "Classify the question type as one of the following: "
            "arithmetic (addition, subtraction, etc.), counting, comparison, selection, or span extraction. "
            "Provide reasoning for your classification."
        )

        # Parallel execution for extraction and question intent analysis
        extraction_task = self.generate(instruction=extraction_instruction, context=self.problem_text)
        question_intent_task = self.generate(instruction=question_intent_instruction, context=self.problem_text)
        extracted_info, question_intent = await asyncio.gather(extraction_task, question_intent_task)

        # Step 2: Perform reasoning/calculation based on question type
        reasoning_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            f"The question intent is: {question_intent}\n"
            "Perform the necessary reasoning or calculation to answer the question. "
            "If the question involves arithmetic, show your work step by step. "
            "If it involves counting, list all relevant occurrences. "
            "If it involves comparison, clearly state the values being compared. "
            "If it involves span extraction, provide the exact text span from the passage."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Validate and refine the answer
        refinement_instruction = (
            f"Review the reasoning result: {reasoning_result}\n"
            "Critique and refine the answer to ensure it is accurate and consistent with the passage. "
            "Correct any errors or inconsistencies."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 4: Summarize the final answer
        summary_instruction = (
            f"Condense the refined answer: {refined_answer}\n"
            "Provide a concise and clear final answer suitable for submission."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_answer)

        return final_answer