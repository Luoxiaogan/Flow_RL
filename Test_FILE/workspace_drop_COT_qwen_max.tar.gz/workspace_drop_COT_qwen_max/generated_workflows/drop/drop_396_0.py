# Workflow ID: drop_396_0
# Benchmark: drop
# Data Indices: [138, 757]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information (parallelizable with question interpretation)
        extract_instruction = (
            "Extract ALL numerical values, entities, and their relationships from the passage. "
            "Include implicit information that can be inferred from the context. "
            "Format the output as a structured list of key-value pairs, where keys are entities or events, "
            "and values are associated numerical data or descriptions."
        )
        extract_task = self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Interpret the question to determine reasoning requirements
        interpret_instruction = (
            "Analyze the question to determine what type of reasoning is required. "
            "Identify whether the task involves arithmetic operations (e.g., summing, subtracting), "
            "counting occurrences, comparing entities, selecting spans, or other types of reasoning. "
            "Provide a clear explanation of the reasoning steps needed to answer the question."
        )
        interpret_task = self.generate(instruction=interpret_instruction, context=self.problem_text)

        # Run extraction and interpretation in parallel
        extracted_info, question_analysis = await asyncio.gather(extract_task, interpret_task)

        # Step 3: Perform reasoning based on extracted information and question analysis
        reasoning_instruction = (
            f"Using the extracted information: {extracted_info}, and the question analysis: {question_analysis}, "
            "perform the necessary reasoning steps to answer the question. "
            "If the task involves arithmetic operations, calculate the result step by step. "
            "If the task involves counting, identify and count all relevant instances. "
            "If the task involves span extraction, select the correct entity or phrase. "
            "Ensure the reasoning process is explicit and verifiable."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the result
        refine_instruction = (
            "Critique and refine the provided reasoning result. "
            "Check for missed values, verify calculations, resolve ambiguities, and ensure completeness. "
            "Provide a revised result that is accurate and well-supported by the passage."
        )
        refined_result = await self.revise(instruction=refine_instruction, context=reasoning_result)

        # Step 5: Summarize the final answer
        summarize_instruction = (
            "Condense the refined result into a concise answer that directly addresses the question. "
            "Ensure the answer is in the required format (e.g., number, date, text span)."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_result)

        return final_answer