# Workflow ID: drop_271_0
# Benchmark: drop
# Data Indices: [130, 519]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (entities, numbers, relationships)
        extract_instruction = (
            "Extract all numerical values, entities, and relationships from the passage and question. "
            "Focus on identifying numbers, dates, names, and any associations between them. "
            "Organize the extracted information clearly."
        )
        extract_task = self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its type
        analyze_instruction = (
            "Analyze the question to determine its type. Identify whether the question requires "
            "arithmetic operations (e.g., addition, subtraction), comparison (e.g., greater than, less than), "
            "counting, or span extraction. Provide a clear explanation of the reasoning behind your analysis."
        )
        analyze_task = self.generate(instruction=analyze_instruction, context=self.problem_text)

        # Run extraction and analysis in parallel
        extracted_info, question_analysis = await asyncio.gather(extract_task, analyze_task)

        # Step 3: Perform reasoning based on the question type
        reasoning_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            f"And the question analysis: {question_analysis}\n"
            "Perform the necessary reasoning steps to answer the question. If the question involves arithmetic, "
            "perform the required calculations. If it involves comparison, compare the relevant values. "
            "If it requires span extraction, identify and return the relevant text span. "
            "Provide a detailed explanation of your reasoning process."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine the reasoning result into a final answer
        refine_instruction = (
            f"Refine the following reasoning result into a concise, accurate final answer: {reasoning_result}\n"
            "Ensure the answer adheres to the expected format (e.g., number, date, text span). "
            "Polish the language to make it clear and professional."
        )
        final_answer = await self.revise(instruction=refine_instruction, context=reasoning_result)

        return final_answer