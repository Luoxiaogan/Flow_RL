# Workflow ID: drop_1_0
# Benchmark: drop
# Data Indices: [303, 726]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract Relevant Information
        extraction_instruction = (
            "Carefully analyze the passage and the question. "
            "Extract all numerical values, entities, and their relationships mentioned in the passage. "
            "Pay special attention to how these numbers and entities relate to the question being asked."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Refine Extracted Information
        refinement_instruction = (
            f"Review the following extracted information: {extracted_info}. "
            "Ensure that all relevant data is captured and correctly associated with entities. "
            "Identify any missing or ambiguous information and clarify it."
        )
        refined_info = await self.revise(instruction=refinement_instruction, context=extracted_info)

        # Step 3: Summarize Key Information
        summary_instruction = (
            f"Condense the following refined information: {refined_info}. "
            "Focus on summarizing the key relationships between entities and numbers in a structured format."
        )
        summarized_info = await self.summarize(instruction=summary_instruction, context=refined_info)

        # Step 4: Generate Candidate Answers
        candidate_instructions = [
            f"Based on the summarized information: {summarized_info}, calculate the answer by performing addition.",
            f"Based on the summarized information: {summarized_info}, calculate the answer by performing subtraction.",
            f"Based on the summarized information: {summarized_info}, calculate the answer by performing comparison.",
            f"Based on the summarized information: {summarized_info}, extract the relevant span as the answer."
        ]
        candidate_answers = await asyncio.gather(
            *[self.generate(instruction=instr, context=summarized_info) for instr in candidate_instructions]
        )

        # Step 5: Ensemble Final Answer
        ensemble_instruction = (
            "Evaluate the following candidate answers and select the most accurate and complete response. "
            "Consider the context of the question and the relationships between entities and numbers."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=candidate_answers)

        return final_answer