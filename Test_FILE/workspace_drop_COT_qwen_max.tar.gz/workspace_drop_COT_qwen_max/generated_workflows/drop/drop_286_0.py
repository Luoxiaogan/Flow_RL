# Workflow ID: drop_286_0
# Benchmark: drop
# Data Indices: [417, 386]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all numerical values and their associated contexts
        extraction_instruction = (
            "Extract all numerical values from the passage along with their associated entities or contexts. "
            "For example, if the passage mentions 'a 25-yard TD pass', include '25-yard' and its context ('TD pass'). "
            "Format the output as a list of key-value pairs where the key is the numerical value and the value is its context."
        )
        extraction_task = self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_analysis_instruction = (
            "Analyze the question to determine what type of answer is required. "
            "Identify whether the question asks for a maximum, minimum, sum, difference, or specific entity. "
            "Provide a clear description of the question's intent."
        )
        question_analysis_task = self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Execute extraction and question analysis in parallel
        extraction_result, question_analysis_result = await asyncio.gather(extraction_task, question_analysis_task)

        # Step 3: Filter and compare based on the question intent
        filtering_instruction = (
            f"Given the extracted numerical values and contexts: {extraction_result}\n"
            f"And the question's intent: {question_analysis_result}\n"
            "Filter the extracted values to focus only on those relevant to the question. "
            "For example, if the question asks for the 'longest field goal', filter out all non-field-goal-related numbers. "
            "Then, compare the remaining values to determine the correct answer. "
            "Format the output as the final numerical value or entity that answers the question."
        )
        filtering_result = await self.generate(instruction=filtering_instruction, context=self.problem_text)

        # Step 4: Generate the final answer
        final_answer_instruction = (
            f"Based on the filtered and compared results: {filtering_result}\n"
            "Generate the final answer in a concise format that directly addresses the question. "
            "Ensure the response is clear and unambiguous."
        )
        final_answer = await self.generate(instruction=final_answer_instruction, context=self.problem_text)

        return final_answer