# Workflow ID: drop_349_0
# Benchmark: drop
# Data Indices: [419, 31]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Understand the problem context
        problem_analysis = await self.generate(
            instruction="Carefully analyze the passage and question. "
                        "Identify the key entities, numerical values, and relationships. "
                        "Determine the type of reasoning required (e.g., arithmetic, counting, comparison).",
            context=self.problem_text
        )

        # Step 2: Extract relevant information
        extraction_instruction = (
            f"Based on the analysis: {problem_analysis}, "
            "extract all relevant numerical values, entities, and events from the passage. "
            "Ensure the extraction aligns with the question's requirements."
        )
        extracted_info = await self.generate(
            instruction=extraction_instruction,
            context=self.problem_text
        )

        # Step 3: Perform reasoning or calculation
        reasoning_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "perform the necessary reasoning or calculations to answer the question. "
            "For arithmetic questions, compute sums, differences, or comparisons. "
            "For counting questions, tally occurrences. For comparison questions, evaluate magnitudes."
        )
        reasoning_result = await self.generate(
            instruction=reasoning_instruction,
            context=self.problem_text
        )

        # Step 4: Refine the answer
        refined_answer = await self.revise(
            instruction="Critique and refine the reasoning result. "
                        "Ensure the answer is accurate, complete, and directly addresses the question.",
            context=reasoning_result
        )

        # Step 5: Summarize the output
        final_answer = await self.summarize(
            instruction="Condense the refined answer into a clear, concise format. "
                        "Include only the final result and any essential supporting details.",
            context=refined_answer
        )

        return final_answer