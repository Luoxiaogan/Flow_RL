# Workflow ID: drop_226_0
# Benchmark: drop
# Data Indices: [728, 371]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract entities, values, and analyze the question
        extraction_instruction = (
            "Extract all entities, numerical values, and their relationships from the passage. "
            "Analyze the question to determine its type (e.g., arithmetic, counting, comparison, selection, span extraction)."
        )
        extraction_result = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Associate entities with their values
        association_instruction = (
            f"Using the extracted information: {extraction_result}, "
            "associate each numerical value with its corresponding entity or context."
        )
        association_result = await self.generate(instruction=association_instruction, context=self.problem_text)

        # Step 3: Execute parallel reasoning paths based on question type
        arithmetic_instruction = (
            f"Perform any required arithmetic operations using the extracted values: {association_result}. "
            "Ensure calculations are accurate and relevant to the question."
        )
        counting_instruction = (
            f"Count occurrences of the specified entity or condition based on: {association_result}. "
            "Ensure all relevant instances are included."
        )
        comparison_instruction = (
            f"Compare entities or values as per the question's requirements: {association_result}. "
            "Clearly state which is greater, lesser, or equal."
        )
        selection_instruction = (
            f"Identify the correct entity or event based on the question's criteria: {association_result}. "
            "Ensure the selection aligns with the question's intent."
        )
        span_extraction_instruction = (
            f"Locate and return the exact text span that answers the question: {association_result}. "
            "Ensure the span is precise and directly addresses the query."
        )

        results = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=counting_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text),
            self.generate(instruction=selection_instruction, context=self.problem_text),
            self.generate(instruction=span_extraction_instruction, context=self.problem_text)
        )

        # Step 4: Synthesize results using Ensemble
        synthesis_instruction = (
            "Evaluate the provided reasoning paths and select the most appropriate answer. "
            "Ensure the final answer aligns with the question's intent and is supported by the passage."
        )
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=results)

        # Step 5: Validate and refine the final answer
        validation_instruction = (
            f"Validate the final answer: {final_answer} against the original passage. "
            "Refine it if necessary to ensure accuracy and completeness."
        )
        refined_answer = await self.revise(instruction=validation_instruction, context=self.problem_text)

        return refined_answer