# Workflow ID: drop_246_0
# Benchmark: drop
# Data Indices: [469, 59]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (entities, numbers, dates, spans)
        extract_instruction = (
            "Thoroughly analyze the provided passage and question. "
            "Extract all relevant entities, numerical values, dates, and spans. "
            "Ensure no detail is missed and categorize each piece of information clearly."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Interpret the question's intent
        interpret_instruction = (
            "Based on the extracted information, determine the intent of the question. "
            "Identify whether the question requires arithmetic operations (e.g., sum, difference), "
            "counting, comparison, span extraction, or another type of reasoning. "
            "Provide a clear explanation of the reasoning process."
        )
        intent_analysis = await self.generate(instruction=interpret_instruction, context=extracted_info)

        # Step 3: Perform reasoning/calculation
        reasoning_instruction = (
            f"Using the extracted information and the interpreted question intent ({intent_analysis}), "
            "perform the necessary reasoning or calculation. "
            "If the question involves arithmetic, compute the result. "
            "If it's a comparison, determine which entity satisfies the condition. "
            "If it's a span extraction, identify the correct span. "
            "Provide a detailed step-by-step solution."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the answer
        validate_instruction = (
            "Review the reasoning result and validate it against the original problem text. "
            "Check for any inconsistencies, ambiguities, or missing details. "
            "Refine the answer if necessary to ensure accuracy and completeness."
        )
        refined_answer = await self.revise(instruction=validate_instruction, context=reasoning_result)

        # Return the final answer
        return refined_answer