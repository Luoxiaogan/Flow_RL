# Workflow ID: drop_103_0
# Benchmark: drop
# Data Indices: [379, 372]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract Key Information
        extraction_instruction = (
            "Carefully analyze the passage and question to extract all relevant entities, numerical values, dates, "
            "and relationships. Pay special attention to ambiguous references, implicit information, and similar entities. "
            "Ensure all extracted information is clearly labeled and organized."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Perform Reasoning
        reasoning_instruction = (
            f"Based on the following extracted information: {extracted_info}\n"
            "Determine the intent of the question and perform the necessary reasoning. "
            "This may involve arithmetic operations, comparisons, counting, or span extraction. "
            "Clearly explain your reasoning process and ensure all steps are justified."
        )
        reasoning_output = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Validate and Refine
        refinement_instruction = (
            "Critique the following reasoning output and suggest improvements if necessary. "
            "Ensure the logic is sound, resolve any ambiguities, and correct inconsistencies. "
            "Provide a revised version that is accurate and complete."
        )
        refined_output = await self.revise(instruction=refinement_instruction, context=reasoning_output)

        # Step 4: Summarize the Answer
        summary_instruction = (
            "Condense the following refined reasoning into a concise answer that directly addresses the question. "
            "Ensure the summary retains all critical information while being succinct and clear."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_output)

        return final_answer