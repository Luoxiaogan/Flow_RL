# Workflow ID: drop_38_0
# Benchmark: drop
# Data Indices: [19, 510]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the question and passage
        extract_instruction = (
            "Extract all entities, numerical values, and relationships mentioned in the question. "
            "Identify what the question is asking for (e.g., count, comparison, arithmetic operation). "
            "Map these elements to relevant parts of the passage."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Generate multiple reasoning paths
        reasoning_instructions = [
            f"Based on the extracted information: {extracted_info}. Solve the problem using direct extraction from the passage.",
            f"Based on the extracted information: {extracted_info}. Solve the problem using inferred or calculated reasoning.",
            f"Based on the extracted information: {extracted_info}. Solve the problem by resolving any ambiguities or implicit references in the passage."
        ]
        reasoning_results = await asyncio.gather(
            *(self.generate(instruction=instr, context=self.problem_text) for instr in reasoning_instructions)
        )

        # Step 3: Revise ambiguous or incomplete answers
        revise_instruction = (
            "Review the provided reasoning. If there are ambiguities, implicit references, or missing details, refine the answer. "
            "Ensure the revised answer aligns with the question's intent and the passage's context."
        )
        revised_results = await asyncio.gather(
            *(self.revise(instruction=revise_instruction, context=result) for result in reasoning_results)
        )

        # Step 4: Ensemble to select or synthesize the best result
        ensemble_instruction = (
            "Evaluate the provided reasoning paths. Select the most accurate and complete answer, or synthesize a new one "
            "that combines the strengths of the individual paths."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=revised_results)

        # Step 5: Summarize the final result
        summarize_instruction = (
            "Condense the final answer into a concise response. Ensure it directly addresses the question and includes "
            "only the most relevant information."
        )
        summarized_answer = await self.summarize(instruction=summarize_instruction, context=final_answer)

        return summarized_answer