# Workflow ID: drop_365_0
# Benchmark: drop
# Data Indices: [563, 641]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Initial Analysis and Question Understanding
        analysis_instruction = """
        Analyze the question and passage thoroughly. Identify:
        - What the question is asking for (e.g., arithmetic operation, comparison, counting, selection).
        - Relevant entities, numbers, and their associations in the passage.
        - Any implicit relationships or coreference resolutions needed.
        Provide a structured summary of your findings.
        """
        analysis = await self.generate(instruction=analysis_instruction, context=self.problem_text)

        # Step 2: Parallel Reasoning Paths
        arithmetic_instruction = f"""
        Based on the analysis: {analysis}
        Extract all relevant numbers and their associated entities. Perform any required arithmetic operations (addition, subtraction, etc.) as indicated by the question.
        """
        counting_instruction = f"""
        Based on the analysis: {analysis}
        Identify and count occurrences of specific entities or events mentioned in the question.
        """
        comparison_instruction = f"""
        Based on the analysis: {analysis}
        Compare numerical values or spans as specified by the question. Determine which is greater, longer, more, etc.
        """
        selection_instruction = f"""
        Based on the analysis: {analysis}
        Extract spans or entities that satisfy the selection criteria in the question.
        """

        # Execute reasoning paths in parallel
        results = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=counting_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text),
            self.generate(instruction=selection_instruction, context=self.problem_text)
        )

        # Step 3: Synthesis and Validation
        synthesis_instruction = """
        Evaluate the results from the parallel reasoning paths. Select the most appropriate result based on the question's intent. If there are discrepancies, provide reasoning for the final choice.
        """
        synthesized_result = await self.ensemble(instruction=synthesis_instruction, contexts=results)

        # Step 4: Final Output Construction
        final_instruction = """
        Condense the reasoning process into a concise answer. Ensure the output is in the correct format (number, date, span, etc.) as required by the question.
        """
        final_answer = await self.summarize(instruction=final_instruction, context=synthesized_result)

        return final_answer