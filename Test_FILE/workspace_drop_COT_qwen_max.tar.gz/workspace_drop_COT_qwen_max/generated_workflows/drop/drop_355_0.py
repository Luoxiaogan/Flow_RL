# Workflow ID: drop_355_0
# Benchmark: drop
# Data Indices: [472, 512]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant entities, numbers, and relationships
        extract_instruction = """
        Extract all relevant entities, numerical values, and relationships from the passage and question. 
        Identify:
        - Entities (e.g., teams, players, events)
        - Numerical values (e.g., scores, counts, measurements)
        - Relationships between entities and numbers
        - Contextual clues for ambiguous references
        Format the output as a structured list or table for clarity.
        """
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Analyze question intent and classify question type
        analyze_instruction = f"""
        Analyze the question and classify it into one of the following types:
        - Arithmetic (e.g., addition, subtraction, difference)
        - Counting (e.g., how many times, how many different)
        - Comparison (e.g., greater, longer, more)
        - Selection (e.g., who won, what happened first/last)
        - Span Extraction (e.g., who did, what was the name of)
        Based on the extracted information below, outline the reasoning steps needed to answer the question.
        Extracted Information: {extracted_info}
        """
        analysis = await self.generate(instruction=analyze_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on question type
        reasoning_instruction = f"""
        Based on the analysis below, perform the necessary reasoning steps to answer the question.
        Use the extracted information to guide your calculations, comparisons, or selections.
        Analysis: {analysis}
        Extracted Information: {extracted_info}
        Ensure the reasoning process is clear and step-by-step.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the reasoning process
        validate_instruction = f"""
        Critique and refine the reasoning process below. Ensure:
        - All relevant information is considered
        - Calculations and comparisons are accurate
        - The answer aligns with the question intent
        Reasoning Process: {reasoning_result}
        """
        refined_reasoning = await self.revise(instruction=validate_instruction, context=reasoning_result)

        # Step 5: Summarize the final answer
        summarize_instruction = f"""
        Summarize the final answer based on the refined reasoning process below.
        Ensure the answer is concise, accurate, and formatted appropriately.
        Refined Reasoning: {refined_reasoning}
        """
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_reasoning)

        return final_answer