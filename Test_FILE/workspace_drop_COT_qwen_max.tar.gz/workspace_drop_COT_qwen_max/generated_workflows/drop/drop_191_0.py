# Workflow ID: drop_191_0
# Benchmark: drop
# Data Indices: [357, 319]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (entities, numbers, dates, spans)
        extraction_instruction = """
        Extract all entities, numerical values, dates, and relevant text spans from the passage and question. 
        Organize the extracted information into categories: entities, numbers, dates, and spans. 
        Ensure no information is missed and provide clear labels for each category.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Classify the question intent
        intent_instruction = f"""
        Analyze the question to determine its type. Possible types include:
        - Arithmetic (e.g., addition, subtraction, multiplication, division)
        - Counting (e.g., how many times, how many different)
        - Comparison (e.g., greater than, less than, equal to)
        - Selection (e.g., which one, who did)
        - Span Extraction (e.g., what is the name, what happened)
        Based on the extracted information: {extracted_info}, classify the question type and explain your reasoning.
        """
        question_intent = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question type
        reasoning_instruction = f"""
        Based on the question intent: {question_intent} and the extracted information: {extracted_info},
        perform the appropriate reasoning:
        - For arithmetic questions, extract relevant numbers and perform the required calculation.
        - For counting questions, count the occurrences of the specified entities or events.
        - For comparison questions, compare the relevant values or spans.
        - For selection questions, identify the correct entity or event.
        - For span extraction questions, directly extract the relevant text span.
        Provide the final answer with clear justification.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the result
        validation_instruction = f"""
        Review the reasoning result: {reasoning_result} against the original passage and question.
        Ensure the answer is accurate, complete, and directly addresses the question.
        If necessary, refine the answer to improve clarity and correctness.
        """
        refined_answer = await self.revise(instruction=validation_instruction, context=reasoning_result)

        return refined_answer