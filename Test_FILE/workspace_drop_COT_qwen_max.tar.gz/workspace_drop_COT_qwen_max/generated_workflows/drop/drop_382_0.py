# Workflow ID: drop_382_0
# Benchmark: drop
# Data Indices: [645, 123]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract Relevant Information
        extraction_instruction = """
        Extract all entities, numerical values, dates, and their relationships from the passage and question.
        Identify which numbers or entities are associated with specific actions or events.
        Organize the extracted information into a structured format for further analysis.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the Question
        question_analysis_instruction = f"""
        Analyze the question to determine its type (e.g., arithmetic, counting, comparison, selection, span extraction).
        Based on the extracted information: {extracted_info}, identify the specific task required to answer the question.
        Provide clear instructions for solving the question, including any necessary calculations or comparisons.
        """
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform Reasoning and Calculation
        reasoning_instruction = f"""
        Using the extracted information: {extracted_info} and the question analysis: {question_analysis},
        perform the required reasoning or calculation to answer the question.
        If the question involves arithmetic operations, execute them step by step.
        If the question involves comparisons, evaluate the options and select the correct one.
        If the question requires span extraction, identify the exact text span that answers the question.
        """
        reasoning_tasks = [
            self.generate(instruction=reasoning_instruction, context=self.problem_text),
            self.generate(instruction=reasoning_instruction, context=self.problem_text)  # Parallel reasoning path
        ]
        reasoning_results = await asyncio.gather(*reasoning_tasks)

        # Step 4: Combine Results (if necessary)
        ensemble_instruction = f"""
        Evaluate the reasoning results: {reasoning_results}.
        If there are discrepancies, resolve them by selecting the most accurate answer.
        If the results are consistent, confirm the final answer.
        """
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=reasoning_results)

        # Step 5: Validate and Refine the Answer
        refinement_instruction = f"""
        Validate the final answer: {final_answer} against the extracted information: {extracted_info}.
        If inconsistencies are detected, refine the answer to ensure accuracy.
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        # Step 6: Summarize the Final Output
        summary_instruction = f"""
        Summarize the final answer: {refined_answer} in a concise and clear format.
        Ensure the output directly addresses the question without unnecessary details.
        """
        final_output = await self.summarize(instruction=summary_instruction, context=refined_answer)

        return final_output