# Workflow ID: drop_351_0
# Benchmark: drop
# Data Indices: [397, 479]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract relevant entities, numbers, and relationships
        extraction_instruction = """
        Extract all entities, numerical values, and their relationships from the passage. 
        Identify any mentions of people, teams, events, dates, or other key information. 
        Organize the extracted information in a structured format for further analysis.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_analysis_instruction = f"""
        Analyze the question and determine its intent based on the following categories:
        - Arithmetic operations (e.g., sum, difference)
        - Counting (e.g., how many times, how many different)
        - Comparison (e.g., greater, longer, more)
        - Selection (e.g., which team, what happened first/last)
        - Span extraction (e.g., who did, what was the name of)
        Use the extracted information below to guide your analysis:
        {extracted_info}
        """
        question_intent = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform parallel reasoning based on the question intent
        arithmetic_instruction = f"""
        If the question involves arithmetic operations, compute the required value (e.g., sum, difference) 
        using the extracted numerical values and their relationships:
        {extracted_info}
        """
        counting_instruction = f"""
        If the question involves counting, count the occurrences of the specified entities or events 
        using the extracted information:
        {extracted_info}
        """
        span_extraction_instruction = f"""
        If the question involves span extraction, identify the exact text span from the passage 
        that answers the question:
        {extracted_info}
        """

        # Execute reasoning paths in parallel
        reasoning_results = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=counting_instruction, context=self.problem_text),
            self.generate(instruction=span_extraction_instruction, context=self.problem_text)
        )

        # Step 4: Validate and refine the results
        refinement_instruction = f"""
        Review the following reasoning results and refine them for accuracy and consistency:
        {reasoning_results}
        Ensure the answers align with the passage and the question intent:
        {question_intent}
        """
        refined_results = await self.revise(instruction=refinement_instruction, context="\n".join(reasoning_results))

        # Step 5: Synthesize or select the best answer
        ensemble_instruction = f"""
        Evaluate the refined results and select the best answer that satisfies the question intent:
        {refined_results}
        Provide the final answer in the required format (number, date, text span, etc.).
        """
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=refined_results.split("\n"))

        return final_answer