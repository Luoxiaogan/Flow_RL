# Workflow ID: drop_375_0
# Benchmark: drop
# Data Indices: [285, 448]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract Relevant Information
        extract_instruction = """
        Extract ALL numerical values, entities, and their relationships from the passage. 
        Include counts, measurements, dates, names, and any other relevant details. 
        Ensure no information is missed and organize the output clearly.
        """
        extraction = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Understand the Question
        question_analysis_instruction = f"""
        Analyze the question and determine what type of reasoning is required (e.g., arithmetic, counting, comparison). 
        Use the following extracted information to guide your analysis:
        {extraction}
        Clearly specify the reasoning steps needed to answer the question.
        """
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform Reasoning/Calculation
        reasoning_instruction = f"""
        Based on the question analysis and the extracted information, perform the necessary calculations or comparisons. 
        Follow these reasoning steps:
        {question_analysis}
        Ensure all steps are clearly documented and the final result is accurate.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine the Answer
        refine_instruction = f"""
        Critique and refine the following answer to ensure accuracy and completeness:
        {reasoning_result}
        Verify that all calculations are correct, all entities are properly associated with their values, 
        and the answer aligns with the passage context.
        """
        refined_answer = await self.revise(instruction=refine_instruction, context=reasoning_result)

        # Step 5: Summarize the Final Answer
        summarize_instruction = f"""
        Condense the following refined answer into a concise, final response:
        {refined_answer}
        Ensure the final answer is clear, precise, and directly addresses the question.
        """
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_answer)

        return final_answer