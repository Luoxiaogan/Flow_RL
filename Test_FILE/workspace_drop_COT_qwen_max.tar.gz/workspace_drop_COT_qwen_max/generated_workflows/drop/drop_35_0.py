# Workflow ID: drop_35_0
# Benchmark: drop
# Data Indices: [298, 522]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract relevant information from the passage based on the question
        extraction_instruction = """
        Analyze the question and identify what it is asking for. Then, extract ALL relevant information from the passage 
        that could help answer the question. Pay special attention to numerical values, entities, and relationships. 
        Handle ambiguous references and ensure you capture all occurrences of similar entities.
        """
        extracted_data = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Perform reasoning or calculation based on the extracted data
        reasoning_instruction = f"""
        Using the extracted information: {extracted_data}, determine the type of reasoning required to answer the question. 
        If it involves arithmetic operations, perform the necessary calculations. If it requires counting, comparison, or span extraction, 
        follow the appropriate steps. Ensure that entities are correctly associated with their respective numbers or attributes. 
        Provide a detailed explanation of your reasoning process.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Validate and refine the reasoning result
        refinement_instruction = f"""
        Critique the following reasoning result: {reasoning_result}. Check for errors in calculation, entity association, or logical inference. 
        Refine the result to ensure accuracy and completeness. If any part of the reasoning is unclear or incomplete, improve it accordingly.
        """
        refined_result = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 4: Summarize the final answer
        summarization_instruction = f"""
        Condense the refined result: {refined_result} into a concise, final answer. Ensure the format matches the expected answer type 
        (number, date, text span, etc.). If the question asks for a specific format, adhere to it strictly.
        """
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_result)

        return final_answer