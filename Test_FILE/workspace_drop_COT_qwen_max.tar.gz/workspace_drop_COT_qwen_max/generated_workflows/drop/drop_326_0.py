# Workflow ID: drop_326_0
# Benchmark: drop
# Data Indices: [81, 399]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the passage
        extraction_instruction = (
            "Extract all entities, numerical values, dates, and relationships mentioned in the passage. "
            "Organize them into categories such as people, places, events, quantities, and time-related data. "
            "Ensure no information is missed, even if it seems trivial."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_intent_instruction = (
            "Analyze the question to determine what type of reasoning or operation is required. "
            "Identify whether the task involves arithmetic operations (e.g., sum, difference), counting, "
            "comparison, span extraction, or other forms of inference. "
            "Map the question to the extracted information from the passage."
        )
        question_analysis = await self.generate(instruction=question_intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning/calculations based on the question intent
        reasoning_instruction = (
            f"Using the extracted information ({extracted_info}) and the question analysis ({question_analysis}), "
            "perform the necessary reasoning or calculations to answer the question. "
            "If the question involves arithmetic, explicitly show the calculation steps. "
            "If it involves comparison, clearly state the basis of comparison. "
            "If it requires span extraction, provide the exact text span from the passage."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine and validate the result
        refinement_instruction = (
            "Critique the reasoning result for accuracy and completeness. "
            "Ensure that all relevant information from the passage has been considered. "
            "Check for logical consistency and correct any errors in interpretation or calculation."
        )
        refined_result = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Handle multiple candidate solutions (if necessary)
        final_instruction = (
            "If there are multiple possible answers, evaluate each candidate based on coherence, "
            "relevance, and correctness. Select the most appropriate answer that fully addresses the question."
        )
        candidates = [reasoning_result, refined_result]  # Example candidates
        final_answer = await self.ensemble(instruction=final_instruction, contexts=candidates)

        return final_answer