# Workflow ID: drop_364_0
# Benchmark: drop
# Data Indices: [455, 619]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract all relevant entities, numbers, and relationships
        extraction_instruction = """
        Extract all relevant entities, numbers, dates, and relationships from the passage and question. 
        Ensure each number is associated with its corresponding entity or event. 
        Identify any implicit relationships or contextual clues that might be important for reasoning.
        """
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its type and intent
        analysis_instruction = f"""
        Analyze the question to determine its type (e.g., arithmetic, counting, comparison, selection, span extraction) and intent. 
        Use the following extracted information as context: {extraction}.
        Provide a clear description of the reasoning strategy required to answer the question.
        """
        question_analysis = await self.generate(instruction=analysis_instruction, context=self.problem_text)

        # Step 3: Execute the reasoning strategy based on the question type
        reasoning_instruction = f"""
        Based on the question analysis: {question_analysis}, execute the appropriate reasoning strategy. 
        Use the extracted information: {extraction} to perform the required calculations, counts, comparisons, selections, or span extractions.
        Ensure the reasoning process is clear, logical, and aligned with the question's intent.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine the reasoning output for clarity and correctness
        refinement_instruction = f"""
        Critique and refine the following reasoning output: {reasoning_result}. 
        Ensure the final answer is clear, concise, and directly addresses the question. 
        Correct any errors or ambiguities in the reasoning process.
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Handle multiple reasoning paths if necessary
        # If there are multiple interpretations or reasoning paths, use Ensemble to select the best answer
        ensemble_instruction = f"""
        Evaluate the following candidate answers: {refined_answer}. 
        Select the most accurate and well-supported answer based on the passage and question. 
        If necessary, synthesize a final response that combines the strengths of multiple candidates.
        """
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[refined_answer])

        return final_answer