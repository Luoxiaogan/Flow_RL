# Workflow ID: drop_196_0
# Benchmark: drop
# Data Indices: [783, 735]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract relevant information from the passage and question
        extraction_instruction = (
            "Extract all numerical values, entities, and their relationships from the passage and question. "
            "Categorize the extracted information into numbers, dates, entities, and descriptive phrases. "
            "Ensure no critical information is missed."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Understand the question intent and classify the reasoning type
        intent_instruction = (
            f"Analyze the question and classify its type based on the following categories: "
            f"arithmetic operations (e.g., addition, subtraction), counting, comparison, selection, or span extraction. "
            f"Outline the specific steps needed to answer the question based on the extracted information: {extracted_info}."
        )
        question_intent = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question type
        reasoning_instruction = (
            f"Based on the question type identified ({question_intent}), perform the necessary reasoning steps. "
            f"For arithmetic operations, calculate the result using the extracted numbers. "
            f"For comparisons, evaluate which entity satisfies the condition. "
            f"For span extraction, identify the exact text span that answers the question. "
            f"Use the following extracted information: {extracted_info}."
        )
        reasoning_results = await asyncio.gather(
            self.generate(instruction=reasoning_instruction, context=self.problem_text),
            self.generate(instruction=reasoning_instruction, context=self.problem_text)  # Parallel reasoning paths
        )

        # Step 4: Validate and refine the reasoning process
        refinement_instruction = (
            f"Review the reasoning process and results: {reasoning_results}. "
            f"Refine the answer if needed to ensure accuracy and alignment with the question intent."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=self.problem_text)

        # Step 5: Synthesize the final answer using Ensemble
        synthesis_instruction = (
            f"Evaluate and synthesize the following reasoning results into a single coherent answer: {reasoning_results}. "
            f"Resolve any conflicts or ambiguities to produce a final, reliable answer."
        )
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=reasoning_results)

        return final_answer