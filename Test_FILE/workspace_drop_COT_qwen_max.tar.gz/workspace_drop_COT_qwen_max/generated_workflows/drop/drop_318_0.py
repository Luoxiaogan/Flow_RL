# Workflow ID: drop_318_0
# Benchmark: drop
# Data Indices: [176, 493]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant entities, numbers, and temporal markers
        extraction_instruction = """
        Extract all relevant entities, numerical values, and temporal markers (dates/times) from the passage and question.
        Include:
        - Names of people, teams, organizations, locations, etc.
        - Numerical values with their associated context (e.g., scores, counts, measurements)
        - Dates, times, or other temporal indicators
        Ensure completeness and accuracy.
        """
        entity_extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its type
        question_analysis_instruction = f"""
        Analyze the question and classify it into one of the following categories:
        - Arithmetic: Requires addition, subtraction, multiplication, or division.
        - Counting: Requires counting occurrences of entities or events.
        - Comparison: Requires comparing two or more values or spans.
        - Selection: Requires selecting an entity, event, or span as the answer.
        - Span Extraction: Requires identifying a specific text span from the passage.
        Use the extracted information: {entity_extraction} to guide your analysis.
        """
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question type
        reasoning_instruction = f"""
        Based on the question analysis: {question_analysis}, perform the required reasoning:
        - For arithmetic questions, calculate the result using the extracted numbers.
        - For counting questions, count the occurrences of the specified entities or events.
        - For comparison questions, compare the specified values or spans.
        - For selection questions, select the correct entity, event, or span.
        - For span extraction questions, identify the exact text span that answers the question.
        Use the extracted information: {entity_extraction} to ensure accuracy.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the reasoning result
        validation_instruction = f"""
        Critique the reasoning result: {reasoning_result}.
        Check for:
        - Accuracy of calculations or counts
        - Correctness of comparisons or selections
        - Appropriateness of the extracted span
        Refine the result if necessary.
        """
        refined_result = await self.revise(instruction=validation_instruction, context=reasoning_result)

        # Step 5: Summarize the final answer
        summarization_instruction = """
        Produce a concise, final answer based on the refined reasoning result.
        Ensure clarity and correctness.
        """
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_result)

        return final_answer