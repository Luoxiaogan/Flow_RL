# Workflow ID: drop_279_0
# Benchmark: drop
# Data Indices: [370, 454]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio
        
        # Step 1: Extract all relevant entities and numerical values
        extraction_instruction = (
            "Extract all entities (e.g., players, teams, events) and numerical values (e.g., scores, years, counts) "
            "from the passage. Ensure the extraction is exhaustive and includes all potentially relevant information."
        )
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)
        
        # Step 2: Analyze the question to determine the type of reasoning required
        question_analysis_instruction = (
            "Analyze the question to determine the type of reasoning required (e.g., arithmetic, comparison, selection, span extraction). "
            "Identify specific entities or values mentioned in the question that need to be tracked."
        )
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)
        
        # Step 3: Perform the necessary reasoning based on the question analysis
        reasoning_instruction = (
            f"Given the extracted information: {extraction}\n"
            f"And the question analysis: {question_analysis}\n"
            "Perform the necessary reasoning to answer the question. This may involve arithmetic operations, comparisons, "
            "or locating specific text spans. Ensure the reasoning is precise and well-supported by the passage."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)
        
        # Step 4: Validate and refine the result
        validation_instruction = (
            f"Validate the reasoning result: {reasoning_result}\n"
            "Cross-check it against the original passage and refine it if necessary. Correct any inconsistencies or errors."
        )
        refined_result = await self.revise(instruction=validation_instruction, context=reasoning_result)
        
        # Step 5: Summarize the final answer
        summary_instruction = (
            f"Condense the refined result: {refined_result}\n"
            "into a concise final answer that directly addresses the question."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_result)
        
        return final_answer