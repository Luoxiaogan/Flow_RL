# Workflow ID: drop_59_0
# Benchmark: drop
# Data Indices: [294, 791]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant entities, numbers, and relationships
        extraction_instruction = """
        Extract all entities, numerical values, and their relationships from the passage. 
        Ensure you capture:
        - All named entities (people, teams, locations, etc.)
        - All numerical values and their associated context
        - Relationships between entities and numbers
        Format your response as a structured list for clarity.
        """
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Interpret the question and identify reasoning type
        question_interpretation_instruction = f"""
        Analyze the question and determine the type of reasoning required. 
        Consider the following categories:
        - Arithmetic (addition, subtraction, etc.)
        - Counting (how many times, how many different, etc.)
        - Comparison (greater than, less than, etc.)
        - Selection (which team, what happened first, etc.)
        - Span Extraction (who did, what was the name of, etc.)
        Map the question to one or more of these categories and link it to the extracted information:
        {extraction}
        Provide a clear explanation of the reasoning type and its connection to the passage.
        """
        interpretation = await self.generate(instruction=question_interpretation_instruction, context=self.problem_text)

        # Step 3: Parallel reasoning paths
        arithmetic_instruction = f"""
        Perform any required arithmetic operations based on the extracted information:
        {extraction}
        Focus on addition, subtraction, multiplication, or division as needed.
        """
        counting_instruction = f"""
        Count occurrences of specific entities or events mentioned in the passage:
        {extraction}
        Ensure you count all relevant instances accurately.
        """
        comparison_instruction = f"""
        Compare values or entities based on the extracted information:
        {extraction}
        Determine which is greater, lesser, or equal as required.
        """
        selection_instruction = f"""
        Select the correct entity or span based on the question's constraints:
        {extraction}
        Ensure your selection matches the question's requirements.
        """

        # Execute reasoning paths in parallel
        reasoning_results = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=counting_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text),
            self.generate(instruction=selection_instruction, context=self.problem_text)
        )

        # Step 4: Synthesize results using Ensemble
        synthesis_instruction = f"""
        Evaluate the following candidate answers and select the most accurate one:
        {reasoning_results}
        Ensure the chosen answer aligns with the question's requirements and the passage's context.
        """
        synthesized_answer = await self.ensemble(instruction=synthesis_instruction, contexts=reasoning_results)

        # Step 5: Refine the final answer
        refinement_instruction = """
        Refine the provided answer to ensure it is concise, accurate, and properly formatted. 
        Address any ambiguities or inconsistencies.
        """
        final_answer = await self.revise(instruction=refinement_instruction, context=synthesized_answer)

        return final_answer