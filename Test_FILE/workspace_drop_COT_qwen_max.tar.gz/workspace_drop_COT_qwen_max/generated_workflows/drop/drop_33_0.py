# Workflow ID: drop_33_0
# Benchmark: drop
# Data Indices: [148, 644]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all relevant information from the passage
        extraction_instruction = (
            "Thoroughly analyze the provided passage and extract ALL relevant information, including "
            "numerical values, entities, relationships, and contextual details. Ensure that no critical "
            "information is missed, as this will form the basis for answering the question."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Understand the question and formulate a solution strategy
        strategy_instruction = (
            f"Given the following extracted information: {extracted_info}\n"
            "Carefully analyze the question and determine its intent (e.g., arithmetic operation, counting, "
            "comparison, span extraction). Formulate a clear strategy for answering the question based on "
            "the extracted information and the question's requirements."
        )
        strategy = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Generate multiple candidate solutions in parallel
        arithmetic_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Perform any necessary arithmetic operations (addition, subtraction, etc.) to compute potential answers."
        )
        comparison_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Evaluate which entity or value satisfies the comparison criteria specified in the question."
        )
        span_extraction_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Identify the specific text span or entity that directly answers the question."
        )

        candidates = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text),
            self.generate(instruction=span_extraction_instruction, context=self.problem_text)
        )

        # Step 4: Ensemble decision-making to select the best answer
        ensemble_instruction = (
            "Compare the following candidate solutions and select the most accurate and relevant answer. "
            "Ensure that the chosen answer aligns with the question's intent and the extracted information."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=candidates)

        # Step 5: Refine the final answer for clarity and correctness
        refinement_instruction = (
            "Review and refine the following answer to ensure clarity, correctness, and alignment with "
            "the question's requirements. Correct any errors or ambiguities."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        return refined_answer