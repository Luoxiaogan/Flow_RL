# Workflow ID: drop_308_0
# Benchmark: drop
# Data Indices: [711, 553]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information (entities, numbers, dates, etc.)
        extraction_instruction = """
        Identify and extract all relevant entities, numerical values, dates, and relationships mentioned in the passage and question. 
        Organize the extracted information clearly, associating each number or date with its corresponding entity or event.
        """
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Determine the reasoning strategy based on the question type
        reasoning_instruction = f"""
        Analyze the question to determine the type of reasoning required. 
        Possible reasoning types include arithmetic operations (addition, subtraction, etc.), counting occurrences, comparing values, selecting specific entities, or extracting text spans.
        Based on the extracted information: {extraction}, identify the reasoning strategy and outline the steps needed to solve the problem.
        """
        reasoning_strategy = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Execute the reasoning strategy
        execution_instruction = f"""
        Using the reasoning strategy outlined here: {reasoning_strategy}, and the extracted information: {extraction}, 
        perform the necessary calculations, comparisons, or extractions to arrive at the answer. 
        Ensure the result is accurate and directly addresses the question.
        """
        candidate_answers = await asyncio.gather(
            self.generate(instruction=execution_instruction, context=self.problem_text),
            self.generate(instruction=execution_instruction, context=self.problem_text)  # Parallel execution for redundancy
        )

        # Step 4: Validate and refine the result
        refinement_instruction = f"""
        Review the candidate answers: {candidate_answers}. 
        Identify any inconsistencies or errors and refine the result to ensure accuracy. 
        If necessary, revise the reasoning process or incorporate additional context from the passage.
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context="\n".join(candidate_answers))

        # Step 5: Summarize the final answer
        summarization_instruction = f"""
        Condense the refined answer: {refined_answer} into a concise and clear response that directly answers the question. 
        Ensure the final output is well-formatted and free of unnecessary details.
        """
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_answer)

        return final_answer