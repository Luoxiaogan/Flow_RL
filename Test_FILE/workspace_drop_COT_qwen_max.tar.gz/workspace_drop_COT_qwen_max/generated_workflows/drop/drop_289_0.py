# Workflow ID: drop_289_0
# Benchmark: drop
# Data Indices: [621, 49]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the passage
        extraction_instruction = (
            "Thoroughly analyze the provided passage and extract all numerical values, "
            "entities, and their relationships. Pay special attention to: "
            "- Numbers and their associated entities (e.g., '30 victims', '$2,538,000 settlement'). "
            "- Entities mentioned in the question (if available). "
            "- Any implicit or explicit comparisons, counts, or arithmetic relationships. "
            "Format the output as a structured list of findings."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question and determine its intent
        question_analysis_instruction = (
            f"Given the extracted information: {extracted_info}, analyze the question and determine its intent. "
            "Identify whether the question requires: "
            "- Arithmetic operations (e.g., addition, subtraction). "
            "- Counting specific occurrences. "
            "- Comparison between entities or values. "
            "- Span extraction (e.g., names, phrases). "
            "Provide a clear explanation of the reasoning process and the expected output format."
        )
        question_intent = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question intent
        reasoning_instruction = (
            f"Using the extracted information: {extracted_info} and the question analysis: {question_intent}, "
            "perform the necessary reasoning to answer the question. Follow these steps: "
            "- If the question involves arithmetic, perform the required calculations step by step. "
            "- If the question involves counting, ensure all relevant occurrences are considered. "
            "- If the question involves comparison, clearly state the basis of comparison and the result. "
            "- If the question involves span extraction, identify the exact text span that answers the question. "
            "Provide the final answer in a clear and concise format."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine the reasoning output
        refinement_instruction = (
            f"Review the reasoning result: {reasoning_result} and refine it for accuracy and clarity. "
            "Ensure that: "
            "- All calculations are correct. "
            "- All relevant occurrences are accounted for. "
            "- Comparisons are logical and well-supported. "
            "- Extracted spans are precise and directly answer the question. "
            "Provide the refined output."
        )
        refined_output = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Summarize the final answer
        summarization_instruction = (
            f"Condense the refined output: {refined_output} into a concise final answer. "
            "Ensure the answer is direct, unambiguous, and fully addresses the question."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_output)

        return final_answer