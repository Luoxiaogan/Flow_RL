# Workflow ID: drop_140_0
# Benchmark: drop
# Data Indices: [43, 513]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information (numerical values, entities, relationships)
        extract_instruction = """
        Identify and extract all relevant numerical values, entities, and relationships from the passage and question.
        Ensure that each extracted item is clearly associated with its corresponding entity or context.
        Organize the extracted information in a structured format for further analysis.
        """
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Analyze and solve the problem
        solve_instruction = f"""
        Using the extracted information: {extracted_info}
        Analyze the question and determine the required reasoning steps to arrive at the answer.
        Perform any necessary calculations, comparisons, or selections based on the question type.
        Clearly explain the reasoning process and provide the final result.
        """
        solution = await self.generate(instruction=solve_instruction, context=self.problem_text)

        # Step 3: Refine the solution
        refine_instruction = f"""
        Critique the following solution: {solution}
        Identify any errors, ambiguities, or areas for improvement.
        Provide a revised version of the solution that addresses these issues.
        """
        refined_solution = await self.revise(instruction=refine_instruction, context=self.problem_text)

        # Step 4: Handle ambiguities with ensemble (if necessary)
        # Check if the refined solution contains multiple possible answers
        ambiguity_check = "Are there multiple possible answers or interpretations in the following solution?"
        ambiguity = await self.generate(instruction=ambiguity_check, context=refined_solution)

        if "yes" in ambiguity.lower():
            # Generate alternative solutions
            alternatives = await asyncio.gather(
                self.generate(instruction="Provide an alternative interpretation or solution.", context=refined_solution),
                self.generate(instruction="Provide another alternative interpretation or solution.", context=refined_solution)
            )
            # Use ensemble to select the best solution
            ensemble_instruction = """
            Evaluate the following candidate solutions and select the most accurate and complete one.
            Consider the context of the original problem and ensure the chosen solution directly addresses the question.
            """
            final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=[refined_solution] + alternatives)
        else:
            final_solution = refined_solution

        # Step 5: Summarize the final answer
        summarize_instruction = f"""
        Condense the following solution into a concise and clear format: {final_solution}
        Ensure the final answer directly addresses the question and is easy to understand.
        """
        final_answer = await self.summarize(instruction=summarize_instruction, context=self.problem_text)

        return final_answer