# Workflow ID: drop_291_0
# Benchmark: drop
# Data Indices: [616, 333]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Analyze the problem and extract key components
        analysis_instruction = (
            "Analyze the given passage and question thoroughly. "
            "Identify the type of question (e.g., arithmetic, counting, comparison, selection, span extraction). "
            "Extract all relevant entities, numbers, and spans from the passage that could help answer the question. "
            "Ensure no information is missed."
        )
        analysis_result = await self.generate(instruction=analysis_instruction, context=self.problem_text)

        # Step 2: Generate a solution based on the question type
        solution_instruction = (
            f"Based on the following analysis: {analysis_result}\n"
            "Solve the problem step by step. If the question involves arithmetic operations, perform the required calculations. "
            "If it involves counting, count the occurrences accurately. "
            "For comparisons, compare the relevant values. For selections, select the appropriate entity or span. "
            "Ensure all steps are logically sound and justified."
        )
        solution_result = await self.generate(instruction=solution_instruction, context=self.problem_text)

        # Step 3: Revise and refine the solution
        revision_instruction = (
            f"Review the following solution: {solution_result}\n"
            "Critique it for correctness, completeness, and clarity. "
            "Ensure entity-number associations are accurate, implicit information is correctly inferred, and numerical calculations are precise. "
            "Refine the solution if necessary."
        )
        refined_solution = await self.revise(instruction=revision_instruction, context=solution_result)

        # Step 4: Ensemble for final decision (if needed)
        ensemble_instruction = (
            f"Evaluate the following solutions: {solution_result} and {refined_solution}\n"
            "Select the most accurate and complete solution. If both are similar, choose one. "
            "If there are discrepancies, synthesize a final answer that resolves them."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[solution_result, refined_solution])

        return final_answer