# Workflow ID: drop_228_0
# Benchmark: drop
# Data Indices: [111, 346]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract entities, numerical values, and relationships
        extraction_instruction = """
        Extract all entities (e.g., names, teams, players), numerical values, and their relationships from the passage. 
        Include details about what each number represents (e.g., field goal distance, touchdown length). 
        Organize the information clearly and associate each number with its corresponding entity or event.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine reasoning type
        analysis_instruction = f"""
        Analyze the question to determine the type of reasoning required. 
        Classify the question into one of the following categories: 
        - Arithmetic (e.g., addition, subtraction, difference)
        - Counting (e.g., how many times, how many different)
        - Comparison (e.g., greater than, longer than, more than)
        - Span Extraction (e.g., who did, what was the name of)
        Also, identify the specific entities, numbers, or spans involved in the question. 
        Use the extracted information: {extracted_info}.
        """
        question_analysis = await self.generate(instruction=analysis_instruction, context=self.problem_text)

        # Step 3: Execute reasoning based on question type
        reasoning_instruction = f"""
        Based on the question analysis: {question_analysis}, perform the required reasoning. 
        Follow these guidelines:
        - For arithmetic operations: Extract relevant numbers and perform the calculation.
        - For counting: Identify and count occurrences of the specified entity or event.
        - For comparisons: Compare numerical values or spans as requested.
        - For span extraction: Return the exact text span that answers the question.
        Ensure the reasoning process is clear and step-by-step.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine the result
        refinement_instruction = f"""
        Review the reasoning result: {reasoning_result}. 
        Ensure it is accurate, concise, and directly answers the question. 
        Correct any errors or ambiguities in the result.
        """
        refined_result = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Final answer synthesis (if needed)
        final_instruction = f"""
        Synthesize the final answer from the refined result: {refined_result}. 
        Ensure it is presented in the required format (number, date, text span, etc.) and directly addresses the question.
        """
        final_answer = await self.generate(instruction=final_instruction, context=refined_result)

        return final_answer