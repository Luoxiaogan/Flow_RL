# Workflow ID: drop_366_0
# Benchmark: drop
# Data Indices: [539, 581]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all relevant information (entities, numbers, dates, etc.)
        extraction_instruction = (
            "Extract all entities, numerical values, temporal references, and their relationships "
            "from the given text. Organize the information clearly and label each extracted item. "
            "Pay special attention to potential ambiguities such as pronouns or partial names."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Resolve ambiguities and refine extracted information
        refinement_instruction = (
            "Review the extracted information and resolve any ambiguities. "
            "Ensure that all pronouns or partial names are correctly associated with their referents. "
            "Verify that numerical values are accurately linked to their corresponding entities. "
            "Provide a revised version of the extracted information."
        )
        refined_info = await self.revise(instruction=refinement_instruction, context=extracted_info)

        # Step 3: Perform reasoning based on the question type
        reasoning_instruction = (
            f"Based on the refined information: {refined_info}, analyze the question and determine "
            "the required reasoning steps. Identify whether the question involves arithmetic operations, "
            "counting, comparison, selection, or span extraction. Provide a detailed reasoning process "
            "and calculate or infer the answer accordingly."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Synthesize results if multiple interpretations exist
        synthesis_instruction = (
            "Evaluate the reasoning result and determine if there are alternative interpretations "
            "or conflicting conclusions. If so, synthesize the best possible answer based on the evidence. "
            "If no conflicts exist, confirm the reasoning result as the final answer."
        )
        final_answer_candidates = await asyncio.gather(
            self.generate(instruction=synthesis_instruction, context=reasoning_result),
            self.revise(instruction=synthesis_instruction, context=reasoning_result)
        )
        final_answer = await self.ensemble(
            instruction="Select the most accurate and complete answer from the provided candidates.",
            contexts=final_answer_candidates
        )

        # Step 5: Summarize the final answer
        summarization_instruction = (
            "Condense the final answer into a concise response. Ensure that the output is clear, "
            "precise, and directly addresses the question. Remove any unnecessary details while "
            "retaining the essential information."
        )
        summarized_answer = await self.summarize(instruction=summarization_instruction, context=final_answer)

        return summarized_answer