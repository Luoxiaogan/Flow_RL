# Workflow ID: drop_287_0
# Benchmark: drop
# Data Indices: [629, 485]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information from the passage and question
        extract_instruction = (
            "Thoroughly analyze the provided passage and question. "
            "Identify and list all numerical values, entities, and key phrases. "
            "Include their relationships and context within the passage. "
            "Ensure no relevant information is missed."
        )
        relevant_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine the reasoning type
        analyze_instruction = (
            f"Given the extracted information: {relevant_info}\n"
            "Analyze the question to determine the type of reasoning required. "
            "Classify the question as one of the following: arithmetic operation, counting, comparison, or span extraction. "
            "Outline the specific steps needed to solve the question based on its type."
        )
        reasoning_plan = await self.generate(instruction=analyze_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question type
        reasoning_tasks = []
        if "arithmetic operation" in reasoning_plan:
            arithmetic_instruction = (
                f"Using the extracted numerical values: {relevant_info}\n"
                "Perform the required arithmetic operation (e.g., addition, subtraction). "
                "Provide the final calculated result."
            )
            reasoning_tasks.append(self.generate(instruction=arithmetic_instruction, context=self.problem_text))
        if "counting" in reasoning_plan:
            count_instruction = (
                f"Using the extracted entities and events: {relevant_info}\n"
                "Count the occurrences of the specified entity or event. "
                "Provide the total count as the result."
            )
            reasoning_tasks.append(self.generate(instruction=count_instruction, context=self.problem_text))
        if "comparison" in reasoning_plan:
            compare_instruction = (
                f"Using the extracted values or spans: {relevant_info}\n"
                "Compare the specified values or spans. "
                "Determine which is greater, longer, or more, and provide the result."
            )
            reasoning_tasks.append(self.generate(instruction=compare_instruction, context=self.problem_text))
        if "span extraction" in reasoning_plan:
            span_instruction = (
                f"Using the extracted entities and phrases: {relevant_info}\n"
                "Identify the exact span or phrase that answers the question. "
                "Provide the span as the result."
            )
            reasoning_tasks.append(self.generate(instruction=span_instruction, context=self.problem_text))

        # Execute reasoning tasks in parallel
        reasoning_results = await asyncio.gather(*reasoning_tasks)

        # Step 4: Synthesize the final answer
        synthesize_instruction = (
            "Given the following candidate answers:\n"
            f"{reasoning_results}\n"
            "Select the most appropriate answer that fully addresses the question. "
            "If multiple answers are valid, synthesize them into a single coherent response."
        )
        final_answer = await self.ensemble(instruction=synthesize_instruction, contexts=reasoning_results)

        # Optional Step 5: Refine the final answer
        refine_instruction = (
            f"Review the following answer: {final_answer}\n"
            "Improve clarity, correctness, and formatting if necessary. "
            "Ensure the answer is concise and directly addresses the question."
        )
        refined_answer = await self.revise(instruction=refine_instruction, context=final_answer)

        return refined_answer