# Workflow ID: drop_213_0
# Benchmark: drop
# Data Indices: [254, 745]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information (entities, numbers, relationships)
        extraction_instruction = """
        Analyze the passage and extract all numerical values, entities, and their relationships.
        Include counts, measurements, dates, and any other quantitative or qualitative information.
        Ensure that each number is associated with its corresponding entity or context.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Understand the question intent
        question_intent_instruction = f"""
        Analyze the question and determine its intent. Identify whether the question requires:
        - Arithmetic operations (addition, subtraction, etc.)
        - Counting specific occurrences
        - Comparing entities or values
        - Extracting a specific text span
        - Other forms of reasoning
        Use the following extracted information as context: {extracted_info}
        """
        question_intent = await self.generate(instruction=question_intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or calculation based on the question intent
        reasoning_instruction = f"""
        Based on the question intent ({question_intent}), perform the necessary reasoning or calculation.
        Use the extracted information ({extracted_info}) to derive the answer.
        Ensure that the answer is accurate, complete, and directly addresses the question.
        """
        raw_answer = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine the answer
        refinement_instruction = f"""
        Critique and refine the following answer: {raw_answer}.
        Ensure that it is precise, well-formatted, and fully addresses the question.
        Correct any errors or ambiguities.
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=raw_answer)

        # Step 5: Resolve ambiguities if necessary
        ambiguity_check_instruction = f"""
        Determine if the question involves ambiguous references or multiple similar entities.
        If so, generate multiple candidate answers for evaluation.
        """
        ambiguity_check = await self.generate(instruction=ambiguity_check_instruction, context=self.problem_text)

        if "ambiguous" in ambiguity_check.lower():
            # Generate multiple candidate answers in parallel
            candidate_instructions = [
                f"Assume the reference pertains to Entity A and answer the question: {self.problem_text}",
                f"Assume the reference pertains to Entity B and answer the question: {self.problem_text}"
            ]
            candidate_answers = await asyncio.gather(
                *[self.generate(instruction=instr, context=self.problem_text) for instr in candidate_instructions]
            )
            # Select the best answer using Ensemble
            ensemble_instruction = """
            Evaluate the candidate answers and select the one that best fits the context of the question and passage.
            """
            final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=candidate_answers)
        else:
            final_answer = refined_answer

        return final_answer