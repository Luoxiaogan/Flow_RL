# Workflow ID: drop_224_0
# Benchmark: drop
# Data Indices: [564, 42]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information from the passage
        extract_instruction = """
        Identify and list all entities, numerical values, and their relationships mentioned in the passage.
        Include any actions, events, or descriptions associated with these entities.
        Ensure no relevant detail is missed, as this information will be used for reasoning.
        Organize the output in a structured format for easy reference.
        """
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Understand the question's intent
        question_intent_instruction = f"""
        Analyze the question to determine what type of reasoning is required.
        Consider whether the question involves arithmetic operations, counting, comparison, or span extraction.
        Map the question's intent to the relevant information extracted earlier: {extracted_info}.
        Provide a clear explanation of how the question should be answered based on the extracted information.
        """
        question_intent = await self.generate(instruction=question_intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning (parallel execution for efficiency)
        reasoning_instruction_1 = f"""
        Based on the extracted information: {extracted_info} and the question's intent: {question_intent},
        perform the necessary reasoning to derive the answer. Focus on arithmetic operations and numerical calculations.
        """
        reasoning_instruction_2 = f"""
        Based on the extracted information: {extracted_info} and the question's intent: {question_intent},
        perform the necessary reasoning to derive the answer. Focus on entity tracking and span extraction.
        """
        reasoning_results = await asyncio.gather(
            self.generate(instruction=reasoning_instruction_1, context=self.problem_text),
            self.generate(instruction=reasoning_instruction_2, context=self.problem_text)
        )

        # Step 4: Synthesize the answer using Ensemble
        ensemble_instruction = f"""
        Evaluate the following reasoning results and select the most accurate and complete answer:
        Result 1: {reasoning_results[0]}
        Result 2: {reasoning_results[1]}
        Ensure the selected answer directly addresses the question and is supported by the extracted information.
        """
        synthesized_answer = await self.ensemble(instruction=ensemble_instruction, contexts=reasoning_results)

        # Step 5: Refine the output
        refine_instruction = f"""
        Review the synthesized answer: {synthesized_answer} and ensure it is concise, clear, and directly answers the question.
        Correct any errors or ambiguities to produce a polished final output.
        """
        final_answer = await self.revise(instruction=refine_instruction, context=synthesized_answer)

        return final_answer