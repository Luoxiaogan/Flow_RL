# Workflow ID: drop_394_0
# Benchmark: drop
# Data Indices: [709, 8]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract relevant information from the passage and question
        extraction_instruction = (
            "Extract all relevant entities, numbers, dates, and relationships from the passage and question. "
            "Focus on identifying numerical values, their associated entities, and any contextual clues that "
            "might indicate arithmetic operations, comparisons, or span extraction."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Determine the intent of the question
        intent_instruction = (
            "Analyze the question to determine its intent. Identify whether the question requires arithmetic "
            "(e.g., addition, subtraction), counting, comparison, or span extraction. Provide a clear description "
            "of the reasoning steps needed to answer the question based on the extracted information."
        )
        question_intent = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the extracted information and question intent
        reasoning_instruction = f"""
        Using the extracted information: {extracted_info}
        And the determined question intent: {question_intent}
        Perform the necessary reasoning steps to compute the answer. If the question involves arithmetic, 
        calculate the result explicitly. If it involves span extraction, identify the exact text span. Ensure 
        all steps are clearly documented and justified.
        """
        reasoning_output = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the reasoning output
        refine_instruction = (
            "Critique the reasoning output to ensure accuracy. Check for calculation errors, incorrect entity-number "
            "associations, or ambiguous span extractions. Refine the output to address any identified issues."
        )
        refined_output = await self.revise(instruction=refine_instruction, context=reasoning_output)

        # Step 5: Summarize the final answer
        summarize_instruction = (
            "Condense the refined reasoning output into a concise answer that directly addresses the question. "
            "Ensure the answer is clear, accurate, and formatted appropriately."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_output)

        return final_answer