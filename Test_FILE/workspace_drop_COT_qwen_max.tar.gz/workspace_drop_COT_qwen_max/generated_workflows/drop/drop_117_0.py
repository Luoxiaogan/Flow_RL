# Workflow ID: drop_117_0
# Benchmark: drop
# Data Indices: [104, 483]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information
        extraction_instruction = """
        Extract all relevant entities, numerical values, and relationships from the passage and question.
        Identify any implicit information or inferred relationships not directly stated in the text.
        Organize the extracted information in a structured format for easy reference.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze question intent
        intent_instruction = f"""
        Analyze the question to determine the type of reasoning required.
        Based on the extracted information: {extracted_info}
        Map the question to one of the following reasoning types: arithmetic, counting, comparison, span extraction.
        Provide a detailed explanation of the reasoning type and the specific task to be performed.
        """
        question_intent = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning (parallel execution for independent tasks)
        arithmetic_instruction = f"""
        If the question requires arithmetic operations, perform the necessary calculations using the extracted information: {extracted_info}.
        Specify the operation (addition, subtraction, etc.) and the operands clearly.
        """
        counting_instruction = f"""
        If the question requires counting, count all relevant occurrences and associate them with their respective entities.
        Ensure no occurrences are missed and provide a detailed breakdown of the counts.
        """
        comparison_instruction = f"""
        If the question requires comparison, evaluate the options and determine the correct answer.
        Provide a detailed explanation of the comparison process.
        """
        span_extraction_instruction = f"""
        If the question requires span extraction, extract the exact text span that answers the question.
        Ensure the span is precise and directly addresses the question.
        """

        reasoning_tasks = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=counting_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text),
            self.generate(instruction=span_extraction_instruction, context=self.problem_text)
        )

        # Step 4: Refine and validate
        refinement_instruction = f"""
        Critique and refine the reasoning process based on the following results: {reasoning_tasks}.
        Ensure the reasoning is accurate, complete, and addresses the question intent: {question_intent}.
        """
        refined_reasoning = await self.revise(instruction=refinement_instruction, context=self.problem_text)

        # Step 5: Final answer
        final_instruction = f"""
        Synthesize the results of all reasoning steps into a final answer.
        Ensure the answer is robust, concise, and directly addresses the question.
        Consider the refined reasoning: {refined_reasoning}.
        """
        final_answer = await self.ensemble(instruction=final_instruction, contexts=reasoning_tasks)

        return final_answer