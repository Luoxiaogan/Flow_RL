# Workflow ID: drop_307_0
# Benchmark: drop
# Data Indices: [154, 385]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information from the passage
        extraction_instruction = """
        Extract all numerical values, entities, and relationships mentioned in the passage.
        Ensure you associate each number with its corresponding entity or event.
        Include explicit mentions as well as any implicit information that can be inferred.
        Format your output as a structured list of key-value pairs.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Interpret the question's intent
        intent_instruction = f"""
        Analyze the question to determine what type of reasoning is required.
        Consider whether the question involves arithmetic operations (addition, subtraction, etc.), counting, comparison, or span extraction.
        Use the following extracted information from the passage to guide your analysis:
        {extracted_info}
        Clearly state the reasoning steps needed to answer the question.
        """
        question_intent = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Perform the required reasoning or calculation
        reasoning_instruction = f"""
        Based on the interpreted intent and the extracted information, perform the necessary reasoning or calculations.
        Follow these steps:
        1. Identify the specific numbers or entities involved.
        2. Apply the appropriate operation (e.g., addition, subtraction, comparison).
        3. Ensure the result answers the question accurately.
        Extracted Information:
        {extracted_info}
        Question Intent:
        {question_intent}
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the answer
        refinement_instruction = f"""
        Critique the following reasoning result to ensure accuracy and alignment with the question's requirements:
        {reasoning_result}
        Resolve any ambiguities, such as pronoun references or implicit information.
        Provide a refined version of the answer if necessary.
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Summarize the final answer
        summary_instruction = f"""
        Condense the following refined answer into a concise, final response:
        {refined_answer}
        Ensure the summary directly answers the question and is easy to understand.
        """
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_answer)

        return final_answer