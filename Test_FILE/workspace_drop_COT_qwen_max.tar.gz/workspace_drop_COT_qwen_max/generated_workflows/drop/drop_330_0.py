# Workflow ID: drop_330_0
# Benchmark: drop
# Data Indices: [139, 525]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all numerical values and their context
        extraction_instruction = """
        Extract ALL numerical values from the passage along with their associated entities and context. 
        Include details such as what the number represents (e.g., field goal distance, score, time), 
        the entity it is associated with (e.g., team, player), and any other relevant information. 
        Format the output as a list of entries, where each entry contains the number, its description, 
        and the associated entity.
        """
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Identify the constraints from the question
        constraint_instruction = """
        Analyze the question to identify any constraints or conditions that must be applied to the 
        extracted numerical values. For example, the question might specify a range (e.g., "between 20 and 50") 
        or a specific type of value (e.g., "field goals"). Output the constraints in a structured format, 
        such as a dictionary with keys like 'min', 'max', 'type', etc.
        """
        constraints = await self.generate(instruction=constraint_instruction, context=self.problem_text)

        # Step 3: Filter the extracted values based on the constraints
        filter_instruction = f"""
        Using the extracted values ({extraction}) and the identified constraints ({constraints}), 
        filter the values to include only those that satisfy the constraints. For example, if the 
        constraint specifies a range, include only numbers within that range. If the constraint 
        specifies a type (e.g., "field goals"), include only values associated with that type. 
        Output the filtered values as a list.
        """
        filtered_values = await self.generate(instruction=filter_instruction, context=self.problem_text)

        # Step 4: Count or calculate the result based on the question
        calculation_instruction = f"""
        Based on the filtered values ({filtered_values}) and the question, determine whether to count 
        the values, sum them, or perform another operation. For example, if the question asks "How many...", 
        count the values. If it asks "What is the total...", sum the values. Output the final result.
        """
        result = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 5: Validate the result using Revise
        validation_instruction = f"""
        Review the final result ({result}) against the original problem text to ensure accuracy. 
        Check that the correct values were used, the constraints were applied properly, and the 
        calculation matches the question's intent. If there are any issues, suggest corrections.
        """
        validated_result = await self.revise(instruction=validation_instruction, context=result)

        return validated_result