# Workflow ID: drop_316_0
# Benchmark: drop
# Data Indices: [182, 435]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant entities, numerical values, and relationships
        extraction_instruction = (
            "Extract ALL relevant entities, numerical values, and relationships mentioned in the passage. "
            "Include explicit and implicit information. Ensure no detail is missed."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question type and intent
        question_analysis_instruction = (
            "Analyze the question type and intent. Determine whether the question requires arithmetic operations, "
            "counting, comparison, selection, or span extraction. Identify key phrases that indicate the reasoning process."
        )
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Generate an initial answer
        answer_generation_instruction = (
            f"Based on the extracted information: {extracted_info} and the question analysis: {question_analysis}, "
            "generate an initial answer. Apply the reasoning required for the specific question type. "
            "Ensure the response is clear and directly addresses the question."
        )
        initial_answer = await self.generate(instruction=answer_generation_instruction, context=self.problem_text)

        # Step 4: Refine the initial answer
        refinement_instruction = (
            f"Review the initial answer: {initial_answer}. Critique and refine it to ensure accuracy, completeness, "
            "and alignment with the question intent. Address any ambiguities or missing details."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=initial_answer)

        # Step 5: Final decision (if needed)
        # If there are multiple plausible answers, use Ensemble to decide between them
        # Otherwise, return the refined answer
        ensemble_instruction = (
            "Evaluate the refined answer and any alternative interpretations. Select the best solution "
            "or synthesize a new one if necessary."
        )
        final_answer = await self.ensemble(
            instruction=ensemble_instruction,
            contexts=[refined_answer, initial_answer]  # Include initial answer as a fallback
        )

        return final_answer