# Workflow ID: drop_362_0
# Benchmark: drop
# Data Indices: [98, 570]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the passage
        extract_instruction = """
        Extract all numerical values, entities, dates, and relevant spans from the passage. 
        Organize them into categories: numbers, entities, events, and spans. 
        Ensure no information is missed, as it may be critical for answering the question.
        """
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        analyze_instruction = f"""
        Analyze the question and determine its intent. Classify the question into one of the following categories:
        - Arithmetic (e.g., addition, subtraction, counting)
        - Comparison (e.g., greater than, less than)
        - Selection (e.g., choosing an entity or span)
        - Span Extraction (e.g., identifying a specific phrase or name)
        Use the following extracted information as context: {extracted_info}.
        """
        question_intent = await self.generate(instruction=analyze_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question intent
        reasoning_instruction = f"""
        Based on the question intent ({question_intent}), perform the necessary reasoning using the extracted information ({extracted_info}).
        - For arithmetic operations, calculate the result using the relevant numbers.
        - For comparisons, compare the specified values or entities.
        - For selection, identify the correct entity or span based on the question constraints.
        - For span extraction, directly extract the relevant phrase or name.
        Provide a detailed explanation of the reasoning process.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine and validate the reasoning result
        refine_instruction = f"""
        Critique and refine the reasoning result ({reasoning_result}). 
        Ensure the result is accurate, addresses the question intent ({question_intent}), and uses the extracted information ({extracted_info}) correctly.
        """
        refined_result = await self.revise(instruction=refine_instruction, context=reasoning_result)

        # Step 5: Summarize the final answer
        summarize_instruction = f"""
        Condense the refined result ({refined_result}) into a concise answer that directly addresses the question. 
        Ensure the answer is clear, precise, and formatted appropriately (e.g., number, date, text span).
        """
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_result)

        return final_answer