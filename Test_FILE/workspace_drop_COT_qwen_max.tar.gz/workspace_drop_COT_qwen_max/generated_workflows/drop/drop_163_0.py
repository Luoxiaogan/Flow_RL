# Workflow ID: drop_163_0
# Benchmark: drop
# Data Indices: [582, 577]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all relevant information from the passage and question
        extraction_instruction = """
        Extract all numerical values, entities, and relationships mentioned in the passage and question. 
        Include any implicit information that might be relevant for answering the question. 
        Format the output as a structured list of key-value pairs.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Identify the type of reasoning required
        intent_instruction = f"""
        Analyze the question and determine the type of reasoning required. 
        Possible types include arithmetic operations (addition, subtraction, etc.), counting, comparison, or span extraction. 
        Provide a clear classification based on the following extracted information: {extracted_info}.
        """
        reasoning_type = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the identified type
        arithmetic_instruction = f"""
        Perform any necessary arithmetic operations using the extracted numerical values from: {extracted_info}. 
        Ensure you associate numbers with their corresponding entities and provide intermediate steps.
        """
        counting_instruction = f"""
        Count the occurrences of relevant entities or events mentioned in the passage and question. 
        Use the extracted information from: {extracted_info}.
        """
        comparison_instruction = f"""
        Compare numerical values or spans based on the extracted information from: {extracted_info}. 
        Clearly state which is greater, lesser, or if they are equal.
        """
        span_extraction_instruction = f"""
        Extract the relevant text span from the passage that answers the question. 
        Use the extracted information from: {extracted_info}.
        """

        # Execute reasoning steps in parallel
        reasoning_results = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=counting_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text),
            self.generate(instruction=span_extraction_instruction, context=self.problem_text)
        )

        # Step 4: Synthesize results using Ensemble
        synthesis_instruction = f"""
        Evaluate the following candidate solutions and select the most appropriate answer based on the question's intent ({reasoning_type}): 
        {reasoning_results}.
        Ensure the selected answer is accurate, relevant, and formatted correctly.
        """
        synthesized_answer = await self.ensemble(instruction=synthesis_instruction, contexts=reasoning_results)

        # Step 5: Refine the final output
        refinement_instruction = """
        Revise the following answer to ensure it is concise, accurate, and formatted correctly. 
        Remove any unnecessary details while preserving the key information.
        """
        final_answer = await self.revise(instruction=refinement_instruction, context=synthesized_answer)

        return final_answer