# Workflow ID: drop_15_0
# Benchmark: drop
# Data Indices: [387, 625]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract entities, numbers, and key facts from the passage
        extract_instruction = (
            "Extract all entities, numerical values, dates, and key facts from the passage. "
            "Organize them in a structured format (e.g., entity: value pairs)."
        )
        entities_extraction = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its type and requirements
        question_analysis_instruction = (
            "Analyze the question to determine its type (e.g., arithmetic, counting, comparison, span extraction). "
            "Identify the specific entities, values, or spans involved in the question. "
            "Provide a clear interpretation of what the question is asking."
        )
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or computation based on the question type
        reasoning_instruction_template = (
            "Based on the following extracted information:\n{entities}\n"
            "And the following question analysis:\n{analysis}\n"
            "Perform the necessary reasoning or computation to answer the question. "
            "If there are multiple possible interpretations, generate all plausible answers."
        )
        reasoning_instruction = reasoning_instruction_template.format(
            entities=entities_extraction, analysis=question_analysis
        )
        reasoning_results = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Handle ambiguities by selecting the best solution using the ensemble operator
        ensemble_instruction = (
            "Evaluate the following candidate solutions and select the best one. "
            "Consider the question's intent, the extracted information, and logical consistency."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[reasoning_results])

        # Step 5: Refine the final answer for clarity and correctness
        refine_instruction = (
            "Critique and refine the following answer to ensure clarity, correctness, and alignment with the question's intent."
        )
        refined_answer = await self.revise(instruction=refine_instruction, context=final_answer)

        return refined_answer