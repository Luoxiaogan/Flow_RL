# Workflow ID: drop_32_0
# Benchmark: drop
# Data Indices: [191, 323]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio
        
        # Step 1: Extract key information from the passage and question
        extraction_instruction = (
            "Thoroughly analyze the passage and question to extract all relevant entities, numerical values, "
            "and their relationships. Ensure no information is missed, and organize the extracted data clearly."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)
        
        # Step 2: Analyze the question to determine its intent
        question_intent_instruction = (
            f"Given the extracted information: {extracted_info}, analyze the question to determine its intent. "
            "Identify whether it requires arithmetic operations, comparisons, counting, span extraction, or other reasoning. "
            "Provide a clear explanation of the reasoning approach needed."
        )
        question_intent = await self.generate(instruction=question_intent_instruction, context=self.problem_text)
        
        # Step 3: Perform reasoning/computation based on the question intent
        reasoning_instruction = (
            f"Based on the extracted information: {extracted_info} and the question intent: {question_intent}, "
            "perform the necessary reasoning or computation. Follow these steps:\n"
            "1. Identify the entities and numbers involved.\n"
            "2. Perform any required arithmetic operations (e.g., addition, subtraction, comparison).\n"
            "3. Track entities and their associated values carefully.\n"
            "4. Handle implicit information and multi-hop inference if needed.\n"
            "Provide a detailed breakdown of the reasoning process and the intermediate results."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)
        
        # Step 4: Validate and refine the results
        refinement_instruction = (
            f"Review the reasoning result: {reasoning_result} for accuracy and completeness. "
            "Check for any errors in entity-number association, arithmetic calculations, or logical inferences. "
            "Refine the result to ensure it fully addresses the question intent and is free of ambiguity."
        )
        refined_result = await self.revise(instruction=refinement_instruction, context=reasoning_result)
        
        # Step 5: Synthesize the final answer
        synthesis_instruction = (
            f"Given the refined result: {refined_result}, synthesize a concise and accurate final answer. "
            "Ensure the answer directly addresses the question and is formatted appropriately."
        )
        final_answer = await self.summarize(instruction=synthesis_instruction, context=refined_result)
        
        return final_answer