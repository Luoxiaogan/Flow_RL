# Workflow ID: drop_184_0
# Benchmark: drop
# Data Indices: [554, 693]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the passage and question
        extraction = await self.generate(
            instruction="Extract all entities, numerical values, and their relationships from the passage and question. "
                        "Include any implicit information that can be inferred from context. "
                        "Format the output as a structured list of entities and their associated data.",
            context=self.problem_text
        )

        # Step 2: Understand the question intent and classify its type
        question_analysis = await self.generate(
            instruction=f"Analyze the question to determine its type (arithmetic, counting, comparison, selection, or span extraction). "
                        f"Based on the extracted information: {extraction}, outline the reasoning steps required to answer the question. "
                        f"Provide a detailed plan for solving the problem.",
            context=self.problem_text
        )

        # Step 3: Perform reasoning based on the question type
        reasoning_tasks = []
        if "arithmetic" in question_analysis.lower():
            reasoning_tasks.append(
                self.generate(
                    instruction=f"Perform arithmetic operations using the extracted numerical values: {extraction}. "
                                f"Follow the outlined reasoning steps: {question_analysis}.",
                    context=self.problem_text
                )
            )
        elif "counting" in question_analysis.lower():
            reasoning_tasks.append(
                self.generate(
                    instruction=f"Count the occurrences of relevant entities based on the extracted information: {extraction}. "
                                f"Follow the outlined reasoning steps: {question_analysis}.",
                    context=self.problem_text
                )
            )
        elif "comparison" in question_analysis.lower():
            reasoning_tasks.append(
                self.generate(
                    instruction=f"Compare the relevant entities or values based on the extracted information: {extraction}. "
                                f"Follow the outlined reasoning steps: {question_analysis}.",
                    context=self.problem_text
                )
            )
        elif "selection" in question_analysis.lower():
            reasoning_tasks.append(
                self.generate(
                    instruction=f"Select the correct entity or span based on the extracted information: {extraction}. "
                                f"Follow the outlined reasoning steps: {question_analysis}.",
                    context=self.problem_text
                )
            )
        else:  # Span extraction
            reasoning_tasks.append(
                self.generate(
                    instruction=f"Extract the relevant text span from the passage based on the extracted information: {extraction}. "
                                f"Follow the outlined reasoning steps: {question_analysis}.",
                    context=self.problem_text
                )
            )

        # Execute reasoning tasks in parallel
        reasoning_results = await asyncio.gather(*reasoning_tasks)

        # Step 4: Refine and validate the reasoning output
        refined_results = await asyncio.gather(
            *(self.revise(
                instruction=f"Critique and refine the following reasoning output: {result}. "
                            f"Ensure accuracy and alignment with the question intent: {question_analysis}.",
                context=self.problem_text
            ) for result in reasoning_results)
        )

        # Step 5: Resolve conflicts and synthesize final answer
        final_answer = await self.ensemble(
            instruction=f"Evaluate and synthesize the refined reasoning outputs: {refined_results}. "
                        f"Select the most accurate and complete answer based on the question intent: {question_analysis}.",
            contexts=refined_results
        )

        # Step 6: Summarize the final output
        summary = await self.summarize(
            instruction=f"Condense the final answer into a concise and clear response. "
                        f"Ensure it directly addresses the question: {final_answer}.",
            context=self.problem_text
        )

        return summary