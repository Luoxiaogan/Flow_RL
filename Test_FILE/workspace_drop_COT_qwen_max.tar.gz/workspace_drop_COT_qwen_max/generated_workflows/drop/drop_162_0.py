# Workflow ID: drop_162_0
# Benchmark: drop
# Data Indices: [95, 165]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all relevant entities, numbers, and relationships
        extraction_instruction = (
            "Extract all entities, numerical values, and their relationships from the passage. "
            "Include context for each extracted item to clarify its meaning and relevance to the question. "
            "Ensure no critical information is missed."
        )
        extraction_result = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question type and intent
        question_analysis_instruction = (
            "Analyze the question to determine its type and reasoning requirements. "
            "Identify if it involves arithmetic operations, counting, comparison, span extraction, or other reasoning patterns. "
            "Provide a clear breakdown of the expected reasoning steps."
        )
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Parallel reasoning paths based on question type
        reasoning_paths = []
        reasoning_instructions = {
            "arithmetic": (
                f"Perform arithmetic operations as required by the question. "
                f"Use the extracted data: {extraction_result}. "
                f"Ensure calculations are accurate and contextually appropriate."
            ),
            "counting": (
                f"Count the occurrences of relevant entities or events as specified in the question. "
                f"Use the extracted data: {extraction_result}. "
                f"Ensure all instances are considered."
            ),
            "comparison": (
                f"Compare the relevant entities or values as specified in the question. "
                f"Use the extracted data: {extraction_result}. "
                f"Clearly state which is greater, longer, or more significant."
            ),
            "span_extraction": (
                f"Extract the exact text span that answers the question. "
                f"Use the extracted data: {extraction_result}. "
                f"Ensure the span is precise and directly addresses the question."
            )
        }

        # Dynamically construct reasoning tasks based on detected question type
        for reasoning_type, instruction in reasoning_instructions.items():
            reasoning_paths.append(
                self.generate(instruction=instruction, context=self.problem_text)
            )

        # Execute reasoning paths in parallel
        reasoning_results = await asyncio.gather(*reasoning_paths)

        # Step 4: Validate and refine results
        refinement_tasks = []
        for result in reasoning_results:
            refinement_instruction = (
                f"Validate and refine the following result: {result}. "
                f"Cross-check with the original passage and question to ensure accuracy. "
                f"Resolve any ambiguities or inconsistencies."
            )
            refinement_tasks.append(self.revise(instruction=refinement_instruction, context=result))

        refined_results = await asyncio.gather(*refinement_tasks)

        # Step 5: Synthesize final answer
        synthesis_instruction = (
            "Evaluate the refined results and synthesize a single, coherent answer. "
            "Select the most relevant and accurate result based on the question and passage. "
            "Ensure the final answer is clear and unambiguous."
        )
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=refined_results)

        return final_answer