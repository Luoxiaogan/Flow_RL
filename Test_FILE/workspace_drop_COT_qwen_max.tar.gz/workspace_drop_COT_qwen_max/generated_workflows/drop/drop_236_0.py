# Workflow ID: drop_236_0
# Benchmark: drop
# Data Indices: [369, 155]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (parallel execution)
        extract_instruction = (
            "Extract all numerical values, entities, and relationships mentioned in the passage and question. "
            "Focus on identifying counts, measurements, and associations between entities. "
            "Ensure no relevant information is missed."
        )
        analyze_instruction = (
            "Analyze the question to determine its intent. Identify whether it is asking for a sum, count, "
            "comparison, specific entity, or text span. Provide clear reasoning for your conclusion."
        )

        extract_task = self.generate(instruction=extract_instruction, context=self.problem_text)
        analyze_task = self.generate(instruction=analyze_instruction, context=self.problem_text)
        extracted_data, question_intent = await asyncio.gather(extract_task, analyze_task)

        # Step 2: Perform reasoning/calculation based on question intent
        reasoning_instruction = (
            f"Using the extracted data: {extracted_data}, and the question intent: {question_intent}, "
            "perform the necessary reasoning or calculation. If the question involves arithmetic operations, "
            "compute the result explicitly. If it involves comparison, prepare multiple candidate answers."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Refine the result
        refine_instruction = (
            f"Review the reasoning result: {reasoning_result}. Critique its accuracy and alignment with the "
            "question intent. Make corrections if necessary and provide a refined answer."
        )
        refined_answer = await self.revise(instruction=refine_instruction, context=reasoning_result)

        # Step 4: Finalize the answer
        finalize_instruction = (
            f"Condense the refined answer: {refined_answer} into a concise and clear format suitable for the "
            "question type. Ensure the final output is easy to understand and directly addresses the question."
        )
        final_answer = await self.summarize(instruction=finalize_instruction, context=refined_answer)

        return final_answer