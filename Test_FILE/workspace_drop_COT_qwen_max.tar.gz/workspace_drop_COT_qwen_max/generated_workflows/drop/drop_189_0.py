# Workflow ID: drop_189_0
# Benchmark: drop
# Data Indices: [646, 21]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant entities, numerical values, and relationships
        extraction_instruction = """
        Extract all entities, numerical values, and their relationships from the passage. 
        Include any mentions of people, teams, scores, distances, times, or other measurable quantities. 
        Organize the extracted information into clear categories (e.g., entities, numbers, relationships).
        """
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_analysis_instruction = f"""
        Analyze the question to determine its intent. Identify whether the question requires:
        - Arithmetic operations (e.g., addition, subtraction, multiplication, division)
        - Counting instances of something
        - Comparisons between entities or values
        - Selection of a specific entity or value
        - Span extraction (e.g., names, phrases)
        Use the following extracted information as context: {extraction}
        """
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Execute parallel reasoning paths
        arithmetic_instruction = f"""
        Perform any required arithmetic operations based on the extracted information and question intent.
        Ensure you correctly associate numbers with their respective entities and perform the correct operation.
        Context: {extraction}
        Question Intent: {question_analysis}
        """
        counting_instruction = f"""
        Count the occurrences or instances requested by the question.
        Ensure you do not miss any relevant occurrences and correctly associate counts with their entities.
        Context: {extraction}
        Question Intent: {question_analysis}
        """
        comparison_instruction = f"""
        Compare entities or values as requested by the question.
        Ensure you clearly state which entity or value is greater, lesser, or equal.
        Context: {extraction}
        Question Intent: {question_analysis}
        """
        span_extraction_instruction = f"""
        Extract the exact text span requested by the question.
        Ensure the span is coherent and directly answers the question.
        Context: {extraction}
        Question Intent: {question_analysis}
        """

        # Run parallel reasoning paths
        results = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=counting_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text),
            self.generate(instruction=span_extraction_instruction, context=self.problem_text)
        )

        # Step 4: Synthesize results using Ensemble
        ensemble_instruction = f"""
        Evaluate the following candidate solutions and select the most appropriate one:
        - Arithmetic Operations: {results[0]}
        - Counting Instances: {results[1]}
        - Comparisons: {results[2]}
        - Span Extraction: {results[3]}
        Choose the solution that best aligns with the question intent and extracted information.
        """
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 5: Final refinement
        refinement_instruction = f"""
        Revise the following answer to ensure it is clear, concise, and fully addresses the question:
        {final_answer}
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        return refined_answer