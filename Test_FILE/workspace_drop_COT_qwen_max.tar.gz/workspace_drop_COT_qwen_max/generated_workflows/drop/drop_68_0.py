# Workflow ID: drop_68_0
# Benchmark: drop
# Data Indices: [300, 57]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract Key Information
        extraction_instruction = (
            "Extract all numerical values, entities, and relationships from the passage and question. "
            "Include any implicit information that can be inferred from the context. "
            "Format the output as a structured list for easy reference."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Understand Question Intent
        intent_instruction = (
            f"Based on the extracted information: {extracted_info}, analyze the question to determine its intent. "
            "Identify whether the question requires arithmetic operations, counting, comparison, span extraction, or multi-hop inference. "
            "Provide a clear explanation of the reasoning process required to answer the question."
        )
        question_intent = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Perform Reasoning
        reasoning_instruction = (
            f"Using the extracted information: {extracted_info} and the question intent: {question_intent}, "
            "perform the necessary reasoning steps to arrive at the answer. "
            "If the question involves arithmetic, show the calculations step-by-step. "
            "If it involves span extraction, identify the exact text span. "
            "Ensure the reasoning process is thorough and leaves no ambiguity."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine Answer
        refine_instruction = (
            f"Review the reasoning result: {reasoning_result}. "
            "Ensure the answer is accurate, concise, and directly addresses the question. "
            "Eliminate any unnecessary details or ambiguities."
        )
        refined_answer = await self.revise(instruction=refine_instruction, context=reasoning_result)

        # Step 5: Final Output
        summarize_instruction = (
            f"Condense the refined answer: {refined_answer} into a final, polished response. "
            "Ensure the output is clear, concise, and formatted appropriately."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_answer)

        return final_answer