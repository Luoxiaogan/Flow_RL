# Workflow ID: drop_34_0
# Benchmark: drop
# Data Indices: [384, 103]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant numerical values, entities, and relationships
        extraction_instruction = """
        Extract all numerical values, entities, and their relationships from the passage. 
        Include details such as who performed an action, what the action was, and any associated quantities or measurements. 
        Ensure no relevant information is missed.
        """
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Interpret the question and determine the reasoning type
        question_interpretation_instruction = f"""
        Analyze the question and determine what type of reasoning is required. 
        Possible reasoning types include arithmetic operations, counting, comparison, and span extraction. 
        Use the following extracted information for context: {extraction}.
        """
        reasoning_type = await self.generate(instruction=question_interpretation_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or calculation based on the identified type
        reasoning_instruction = f"""
        Based on the reasoning type identified ({reasoning_type}), perform the necessary reasoning or calculation. 
        Use the extracted information: {extraction}. 
        Ensure the result is accurate and directly addresses the question.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the result
        refinement_instruction = f"""
        Critique and refine the following reasoning result: {reasoning_result}. 
        Check for accuracy, logical consistency, and completeness. 
        Address any ambiguities or errors in the reasoning process.
        """
        refined_result = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Summarize the final answer
        summary_instruction = f"""
        Condense the refined result ({refined_result}) into a concise answer that directly addresses the question. 
        Ensure clarity and relevance.
        """
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_result)

        return final_answer