# Workflow ID: drop_21_0
# Benchmark: drop
# Data Indices: [673, 543]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all numerical values, entities, and key phrases
        extraction_instruction = (
            "Carefully analyze the passage and question. "
            "Extract all numerical values, entities, and key phrases. "
            "Ensure you capture relationships between entities and numbers. "
            "Format the output as a structured list."
        )
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question intent
        intent_instruction = (
            f"Given the extracted information: {extraction}, "
            "determine the intent of the question. "
            "Identify if the question requires arithmetic operations, counting, comparison, selection, or span extraction. "
            "Provide a clear explanation of the reasoning process."
        )
        intent_analysis = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question intent
        reasoning_instruction = (
            f"Based on the extracted information: {extraction} and the intent analysis: {intent_analysis}, "
            "perform the required reasoning to answer the question. "
            "If the question involves arithmetic, show the calculation steps. "
            "If it involves counting, ensure all relevant instances are included. "
            "If it involves comparison, clearly state the basis of comparison. "
            "If it involves span extraction, provide the exact text span. "
            "Format the answer clearly and concisely."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine and validate the answer
        refinement_instruction = (
            f"Review the reasoning result: {reasoning_result}. "
            "Critique and refine the answer to ensure it aligns with the passage and question. "
            "Resolve any ambiguities or inconsistencies. "
            "Provide the final refined answer."
        )
        final_answer = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        return final_answer