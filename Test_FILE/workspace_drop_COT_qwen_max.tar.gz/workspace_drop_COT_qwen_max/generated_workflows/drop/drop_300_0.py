# Workflow ID: drop_300_0
# Benchmark: drop
# Data Indices: [405, 153]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio
        
        # Step 1: Extract all relevant entities, numerical values, and relationships
        extraction_instruction = (
            "Extract all entities, numerical values, and their relationships from the passage. "
            "Ensure you capture every detail that could be relevant to answering the question. "
            "Format your output as a structured list or table for clarity."
        )
        extracted_data = await self.generate(instruction=extraction_instruction, context=self.problem_text)
        
        # Step 2: Analyze the question to determine its intent
        question_analysis_instruction = (
            "Analyze the question to determine its intent. Classify the question type "
            "(e.g., arithmetic operation, counting, comparison, selection, span extraction). "
            "Identify the specific information required from the extracted data to answer the question. "
            f"Use the following extracted data as reference: {extracted_data}."
        )
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)
        
        # Step 3: Perform reasoning or calculation based on the question type
        reasoning_instruction = (
            "Based on the question analysis, perform the necessary reasoning or calculation. "
            "If the question involves arithmetic operations, compute the result step by step. "
            "If it involves comparison or selection, evaluate the candidates and determine the best answer. "
            f"Use the extracted data and question analysis as follows: {extracted_data}, {question_analysis}."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)
        
        # Step 4: Handle ambiguity in comparisons or selections using Ensemble
        if "compare" in question_analysis.lower() or "select" in question_analysis.lower():
            candidates = await self.generate(
                instruction="Generate multiple candidate answers based on the reasoning result.",
                context=reasoning_result
            )
            candidates_list = candidates.split("\n")  # Split candidates into a list
            ensemble_instruction = (
                "Evaluate the candidate answers and select the best one based on the question requirements. "
                "Provide a clear justification for your choice."
            )
            final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=candidates_list)
        else:
            final_answer = reasoning_result
        
        # Step 5: Refine the final answer for clarity and correctness
        refinement_instruction = (
            "Refine the final answer to ensure it is clear, correct, and fully aligned with the question intent. "
            "Polish the wording and format as needed."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)
        
        return refined_answer