# Workflow ID: drop_78_0
# Benchmark: drop
# Data Indices: [658, 22]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Understand the question and identify its type
        question_analysis = await self.generate(
            instruction="""Analyze the question and determine its type. 
            Identify whether it requires arithmetic operations, counting, comparison, span extraction, or other reasoning. 
            Extract relevant entities, numbers, or spans from the passage that are pertinent to answering the question. 
            Provide a structured output indicating the question type and the extracted information.""",
            context=self.problem_text
        )

        # Step 2: Associate entities with numbers or spans
        entity_association = await self.generate(
            instruction=f"""Using the extracted information from the previous step: {question_analysis}
            Associate each number or span with its corresponding entity in the passage. 
            Ensure that all relevant occurrences are captured and correctly linked to their entities.""",
            context=self.problem_text
        )

        # Step 3: Perform reasoning or calculation
        reasoning_tasks = []
        for reasoning_type in ["arithmetic", "counting", "comparison", "span_extraction"]:
            reasoning_tasks.append(
                self.generate(
                    instruction=f"""Based on the question analysis: {question_analysis} and the entity associations: {entity_association}
                    Solve the problem using {reasoning_type} reasoning. If the question does not require this type of reasoning, return 'N/A'.
                    Otherwise, provide a detailed step-by-step solution leading to the final answer.""",
                    context=self.problem_text
                )
            )
        reasoning_results = await asyncio.gather(*reasoning_tasks)

        # Step 4: Select the best reasoning path
        final_reasoning = await self.ensemble(
            instruction="""Evaluate the reasoning results provided below. 
            Select the most appropriate reasoning path that directly answers the question. 
            If multiple paths are valid, synthesize them into a single coherent answer.""",
            contexts=reasoning_results
        )

        # Step 5: Validate and refine the answer
        refined_answer = await self.revise(
            instruction=f"""Review the final reasoning: {final_reasoning}
            Ensure that the answer is accurate, complete, and directly addresses the question. 
            Refine the answer if necessary, providing corrections or additional clarifications.""",
            context=self.problem_text
        )

        # Step 6: Summarize the final answer
        final_answer = await self.summarize(
            instruction="""Condense the refined answer into a concise format suitable for submission. 
            Ensure that the output matches the expected answer type (number, date, text span, etc.).""",
            context=refined_answer
        )

        return final_answer