# Workflow ID: drop_350_0
# Benchmark: drop
# Data Indices: [628, 753]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all relevant information from the passage
        extraction_instruction = (
            "Extract all entities, numerical values, events, and their relationships from the passage. "
            "Focus on information that could potentially answer the question. "
            "Provide the extracted information in a structured format."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its type
        question_analysis_instruction = (
            "Analyze the question to determine its type. Identify whether the question requires "
            "arithmetic operations, counting, comparison, selection, or span extraction. "
            "Provide a structured representation of what the question is asking for."
        )
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Generate candidate solutions in parallel
        arithmetic_instruction = (
            f"Based on the extracted information: {extracted_info} and the question analysis: {question_analysis}, "
            "perform any required arithmetic operations (addition, subtraction, etc.) to calculate the answer."
        )
        counting_instruction = (
            f"Based on the extracted information: {extracted_info} and the question analysis: {question_analysis}, "
            "count the occurrences of specific entities or events mentioned in the question."
        )
        comparison_instruction = (
            f"Based on the extracted information: {extracted_info} and the question analysis: {question_analysis}, "
            "compare numerical values or qualitative attributes to determine which is greater, longer, or more."
        )
        selection_instruction = (
            f"Based on the extracted information: {extracted_info} and the question analysis: {question_analysis}, "
            "identify the correct entity or event based on the constraints provided in the question."
        )
        span_extraction_instruction = (
            f"Based on the extracted information: {extracted_info} and the question analysis: {question_analysis}, "
            "extract the exact text span from the passage that answers the question."
        )

        candidates = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=counting_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text),
            self.generate(instruction=selection_instruction, context=self.problem_text),
            self.generate(instruction=span_extraction_instruction, context=self.problem_text)
        )

        # Step 4: Ensemble decision-making to select the best solution
        ensemble_instruction = (
            "Evaluate the candidate solutions and select the most accurate and complete answer. "
            "Consider correctness, consistency, and relevance to the question."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=candidates)

        # Step 5: Refine the selected solution if necessary
        refinement_instruction = (
            "Review the selected solution for clarity, accuracy, and completeness. "
            "Make any necessary refinements to ensure the answer is fully correct."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        return refined_answer