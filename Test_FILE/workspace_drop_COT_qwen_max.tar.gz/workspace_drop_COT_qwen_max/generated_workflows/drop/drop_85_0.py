# Workflow ID: drop_85_0
# Benchmark: drop
# Data Indices: [189, 213]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information (numbers, entities, relationships)
        extraction = await self.generate(
            instruction="Extract all numerical values, entities, and relationships from the passage and question. "
                        "Organize them clearly, associating each number with its corresponding entity or context.",
            context=self.problem_text
        )

        # Step 2: Analyze question intent
        analysis = await self.generate(
            instruction=f"Based on the extracted information:\n{extraction}\n"
                        "Determine the type of reasoning required to answer the question. "
                        "Identify whether the task involves arithmetic operations, counting, comparison, span extraction, or another reasoning type.",
            context=self.problem_text
        )

        # Step 3: Perform reasoning (parallel execution for different reasoning types)
        arithmetic_result = self.generate(
            instruction=f"Given the extracted information:\n{extraction}\n"
                        "Perform any arithmetic operations (addition, subtraction, etc.) required to answer the question. "
                        "If no arithmetic is needed, return 'Not applicable'.",
            context=self.problem_text
        )
        counting_result = self.generate(
            instruction=f"Given the extracted information:\n{extraction}\n"
                        "Count the occurrences of relevant entities or events as required by the question. "
                        "If no counting is needed, return 'Not applicable'.",
            context=self.problem_text
        )
        comparison_result = self.generate(
            instruction=f"Given the extracted information:\n{extraction}\n"
                        "Compare values or spans as required by the question. "
                        "If no comparison is needed, return 'Not applicable'.",
            context=self.problem_text
        )
        span_extraction_result = self.generate(
            instruction=f"Given the extracted information:\n{extraction}\n"
                        "Extract relevant text spans (entity names, phrases) as required by the question. "
                        "If no span extraction is needed, return 'Not applicable'.",
            context=self.problem_text
        )

        # Execute reasoning steps in parallel
        reasoning_results = await asyncio.gather(arithmetic_result, counting_result, comparison_result, span_extraction_result)

        # Step 4: Refine results
        refined_results = await asyncio.gather(
            self.revise(
                instruction="Critique and refine the arithmetic result. Ensure it aligns with the question's intent and context.",
                context=reasoning_results[0]
            ),
            self.revise(
                instruction="Critique and refine the counting result. Ensure it aligns with the question's intent and context.",
                context=reasoning_results[1]
            ),
            self.revise(
                instruction="Critique and refine the comparison result. Ensure it aligns with the question's intent and context.",
                context=reasoning_results[2]
            ),
            self.revise(
                instruction="Critique and refine the span extraction result. Ensure it aligns with the question's intent and context.",
                context=reasoning_results[3]
            )
        )

        # Step 5: Synthesize final answer
        final_answer = await self.ensemble(
            instruction="Evaluate the refined results and synthesize the best answer. "
                        "Ensure the final answer is clear, accurate, and directly addresses the question.",
            contexts=refined_results
        )

        return final_answer