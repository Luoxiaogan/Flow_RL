# Workflow ID: drop_333_0
# Benchmark: drop
# Data Indices: [35, 17]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information from the passage
        extraction_instruction = """
        Extract ALL relevant information from the passage that could potentially answer the question. 
        Include numerical values, entities, relationships, and any implicit or explicit facts. 
        Ensure that you capture all occurrences of similar entities and associate numbers correctly with their respective entities.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_analysis_instruction = f"""
        Analyze the question to determine its intent. Identify whether the question requires:
        - Arithmetic operations (addition, subtraction, etc.)
        - Comparison between entities or numbers
        - Selection of a specific entity or event
        - Extraction of a text span (entity name, phrase, etc.)
        Use the following extracted information as context: {extracted_info}
        """
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Parallel reasoning paths
        arithmetic_instruction = f"""
        If the question involves arithmetic operations, calculate the required value using the extracted numbers and their associations.
        Use the following extracted information as context: {extracted_info}
        """
        comparison_instruction = f"""
        If the question involves comparison, compare the relevant entities or numbers.
        Use the following extracted information as context: {extracted_info}
        """
        selection_instruction = f"""
        If the question asks for a specific entity or event, identify the correct answer from the extracted information.
        Use the following extracted information as context: {extracted_info}
        """
        span_extraction_instruction = f"""
        If the question requires extracting a text span, locate the exact phrase or sentence that answers the question.
        Use the following extracted information as context: {extracted_info}
        """

        results = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text),
            self.generate(instruction=selection_instruction, context=self.problem_text),
            self.generate(instruction=span_extraction_instruction, context=self.problem_text)
        )

        # Step 4: Ensemble decision
        ensemble_instruction = f"""
        Evaluate the following candidate answers and select the most accurate and relevant one:
        - Arithmetic Path: {results[0]}
        - Comparison Path: {results[1]}
        - Selection Path: {results[2]}
        - Span Extraction Path: {results[3]}
        Ensure the final answer aligns with the question's intent and the extracted information.
        """
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 5: Final answer refinement
        refinement_instruction = f"""
        Refine the following answer to ensure it is clear, concise, and directly addresses the question:
        {final_answer}
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        return refined_answer