# Workflow ID: drop_125_0
# Benchmark: drop
# Data Indices: [657, 9]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all relevant entities, numerical values, and relationships
        extraction_instruction = """
        Analyze the passage and extract all key entities, numerical values, and relationships.
        Focus on information that could be relevant to answering the question.
        Organize the extracted data in a structured format for easy reference.
        """
        extraction_task = self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Understand the question intent
        question_analysis_instruction = """
        Analyze the question to determine its intent. Classify the question into one of the following categories:
        - Arithmetic operation (e.g., sum, difference, count)
        - Comparison (e.g., greater than, less than)
        - Selection (e.g., who, what, which)
        - Span extraction (e.g., entity name, phrase)
        Provide a detailed explanation of the reasoning behind your classification.
        """
        question_analysis_task = self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Execute extraction and question analysis in parallel
        extraction, question_analysis = await asyncio.gather(extraction_task, question_analysis_task)

        # Step 3: Perform reasoning based on the question type
        reasoning_instruction = f"""
        Based on the extracted information: {extraction}
        And the question analysis: {question_analysis}
        Perform the necessary reasoning to answer the question. Follow these guidelines:
        - For arithmetic operations, calculate the required value step by step.
        - For comparisons, compare the relevant entities and provide a clear conclusion.
        - For selection questions, identify the correct entity or event.
        - For span extraction, extract the exact text span that answers the question.
        Ensure all reasoning steps are clearly explained and justified.
        """
        reasoning = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the reasoning output
        refinement_instruction = f"""
        Critique and refine the following reasoning output: {reasoning}
        Check for accuracy, logical consistency, and alignment with the passage and question.
        Correct any errors and improve clarity where needed.
        """
        refined_reasoning = await self.revise(instruction=refinement_instruction, context=reasoning)

        # Step 5: Summarize the refined reasoning into a concise answer
        summary_instruction = f"""
        Condense the refined reasoning: {refined_reasoning}
        Into a concise and clear answer that directly addresses the question.
        Ensure the answer is in the expected format (number, date, text span, etc.).
        """
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_reasoning)

        return final_answer