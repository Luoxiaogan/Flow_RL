# Workflow ID: drop_315_0
# Benchmark: drop
# Data Indices: [403, 184]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Classify the question type
        question_type = await self.generate(
            instruction="Analyze the question and classify it into one of the following categories: "
                        "arithmetic operation, counting, comparison, selection, or span extraction. "
                        "Provide a clear explanation for your classification.",
            context=self.problem_text
        )

        # Step 2: Extract relevant information from the passage
        extraction = await self.generate(
            instruction=f"Based on the question type ({question_type}), extract all relevant information "
                        f"from the passage that is needed to answer the question. Include entities, numbers, "
                        f"and any contextual details required for reasoning.",
            context=self.problem_text
        )

        # Step 3: Perform reasoning or calculation
        reasoning_tasks = []
        if "arithmetic" in question_type.lower():
            reasoning_tasks.append(
                self.generate(
                    instruction=f"Perform the necessary arithmetic operations using the extracted data: {extraction}. "
                                f"Show step-by-step calculations and explain how you arrived at the result.",
                    context=self.problem_text
                )
            )
        elif "comparison" in question_type.lower():
            reasoning_tasks.append(
                self.generate(
                    instruction=f"Compare the relevant entities or values from the extracted data: {extraction}. "
                                f"Determine which is greater/smaller or if they are equal, and explain your reasoning.",
                    context=self.problem_text
                )
            )
        elif "counting" in question_type.lower():
            reasoning_tasks.append(
                self.generate(
                    instruction=f"Count the occurrences of the relevant entities or events from the extracted data: {extraction}. "
                                f"Ensure no instances are missed and explain your process.",
                    context=self.problem_text
                )
            )
        elif "selection" in question_type.lower():
            reasoning_tasks.append(
                self.generate(
                    instruction=f"Select the correct entity, event, or value from the extracted data: {extraction}. "
                                f"Justify why this is the correct choice based on the question.",
                    context=self.problem_text
                )
            )
        elif "span extraction" in question_type.lower():
            reasoning_tasks.append(
                self.generate(
                    instruction=f"Identify the exact text span from the passage that answers the question. "
                                f"Ensure the span is complete and directly addresses the query.",
                    context=self.problem_text
                )
            )

        # Execute reasoning tasks in parallel
        reasoning_results = await asyncio.gather(*reasoning_tasks)

        # Step 4: Synthesize the final answer
        final_answer = await self.ensemble(
            instruction="Evaluate the reasoning results and synthesize the final answer. "
                        "Ensure the answer is concise, accurate, and formatted appropriately "
                        "(e.g., number, date, text span).",
            contexts=reasoning_results
        )

        return final_answer