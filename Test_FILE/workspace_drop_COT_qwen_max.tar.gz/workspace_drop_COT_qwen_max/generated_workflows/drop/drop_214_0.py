# Workflow ID: drop_214_0
# Benchmark: drop
# Data Indices: [193, 747]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract relevant information from the passage and question
        extraction_instruction = (
            "Carefully analyze the passage and question to identify the reasoning task required. "
            "Extract all relevant entities, numbers, dates, and relationships. "
            "Classify the question type (e.g., arithmetic, comparison, span extraction). "
            "Provide a structured summary of the extracted information."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Perform reasoning based on the extracted information
        reasoning_instruction = (
            f"Based on the following extracted information: {extracted_info} "
            "Determine the specific reasoning task required to answer the question. "
            "Perform the necessary calculations, comparisons, or span extractions. "
            "Ensure the reasoning process is clear and logical."
        )
        reasoning_output = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Validate and refine the reasoning output
        refinement_instruction = (
            f"Review the following reasoning output: {reasoning_output} "
            "Critique it for accuracy, completeness, and alignment with the question's intent. "
            "Refine the output if necessary, correcting any errors or ambiguities."
        )
        refined_output = await self.revise(instruction=refinement_instruction, context=reasoning_output)

        # Step 4: Summarize the refined output into a concise answer
        summarization_instruction = (
            f"Condense the following refined output: {refined_output} "
            "into a concise answer that directly addresses the question. "
            "Ensure the answer is in the correct format (number, date, text span, etc.)."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_output)

        return final_answer