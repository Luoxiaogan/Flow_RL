# Workflow ID: drop_6_0
# Benchmark: drop
# Data Indices: [167, 416]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract relevant information from the passage
        extraction_instruction = """
        Extract all entities, numerical values, and their relationships from the passage. 
        Include any contextual information that links numbers to specific entities, events, or timeframes. 
        Ensure completeness by capturing ALL relevant occurrences, even if they seem redundant. 
        Format the output as a structured list of key-value pairs or sentences.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_intent_instruction = f"""
        Analyze the question to determine its intent. 
        Identify whether the question requires an arithmetic operation (e.g., addition, subtraction), counting, comparison, selection, or span extraction. 
        Provide a clear explanation of the reasoning behind your determination. 
        Use the following extracted information for context: {extracted_info}.
        """
        question_intent = await self.generate(instruction=question_intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question intent
        reasoning_instruction = f"""
        Based on the determined question intent ({question_intent}), perform the required reasoning. 
        Use the extracted information ({extracted_info}) to calculate, compare, count, or extract the requested value. 
        Provide a detailed step-by-step explanation of the reasoning process. 
        Ensure all numerical values are correctly associated with their respective entities or events.
        """
        reasoning_output = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the reasoning output
        refinement_instruction = f"""
        Critique and refine the reasoning output ({reasoning_output}). 
        Address any potential ambiguities, incorrect associations, or missing information. 
        Ensure the output is accurate, complete, and directly answers the question. 
        Provide a revised version of the reasoning output.
        """
        refined_output = await self.revise(instruction=refinement_instruction, context=reasoning_output)

        # Step 5: Summarize the final answer
        summarization_instruction = f"""
        Condense the refined reasoning output ({refined_output}) into a concise, final answer. 
        Ensure the answer is clear, accurate, and formatted appropriately (e.g., number, date, text span). 
        If the question involves multiple parts, summarize each part clearly.
        """
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_output)

        return final_answer