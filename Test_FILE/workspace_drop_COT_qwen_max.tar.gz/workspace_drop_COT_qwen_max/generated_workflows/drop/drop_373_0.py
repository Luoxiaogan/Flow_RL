# Workflow ID: drop_373_0
# Benchmark: drop
# Data Indices: [721, 336]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract the question intent and identify key components
        question_intent_instruction = """
        Analyze the question to determine its type and intent. Identify whether it requires:
        - Arithmetic operations (addition, subtraction, multiplication, division)
        - Counting instances of specific events or entities
        - Comparison between entities or values
        - Selection of a specific entity or span from the passage
        - Other types of reasoning or extraction
        
        Provide a clear breakdown of what the question is asking for and any specific entities or numbers mentioned.
        """
        question_intent = await self.generate(instruction=question_intent_instruction, context=self.problem_text)

        # Step 2: Extract all relevant numerical values and entities from the passage
        extraction_instruction = f"""
        Given the following analysis of the question: {question_intent}
        
        Extract ALL relevant numerical values, entities, and spans from the passage. Ensure that:
        - Each number is associated with its corresponding entity or event
        - Ambiguous references are resolved using coreference resolution
        - Multiple similar entities are clearly distinguished
        
        Format the output as a structured list or table for easy reference in subsequent steps.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or calculation based on the question type
        reasoning_instruction = f"""
        Using the extracted information: {extracted_info}
        
        Perform the necessary reasoning or calculation based on the question type identified earlier. Follow these guidelines:
        - For arithmetic operations, clearly show the calculation steps and associate numbers with their entities
        - For counting, ensure all relevant instances are included and explain the counting process
        - For comparisons, evaluate the entities based on the extracted data and provide a clear justification
        - For selection, identify the correct entity or span and explain why it matches the question criteria
        
        Provide the intermediate result and reasoning steps.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Formulate the final answer
        answer_instruction = f"""
        Based on the reasoning and calculation: {reasoning_result}
        
        Formulate the final answer in the required format (number, text span, comparative statement, etc.). Ensure that:
        - The answer directly addresses the question
        - Any calculations or reasoning steps are summarized concisely
        - The format matches the expected answer type
        
        Provide the final answer.
        """
        initial_answer = await self.generate(instruction=answer_instruction, context=self.problem_text)

        # Step 5: Revise and validate the answer
        revision_instruction = f"""
        Review the following answer: {initial_answer}
        
        Check for accuracy, clarity, and alignment with the question and passage. Make any necessary revisions to:
        - Correct calculation errors
        - Clarify ambiguous statements
        - Ensure completeness and correctness
        
        Provide the revised answer.
        """
        final_answer = await self.revise(instruction=revision_instruction, context=initial_answer)

        return final_answer