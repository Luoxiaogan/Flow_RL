# Workflow ID: drop_8_0
# Benchmark: drop
# Data Indices: [350, 450]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Initial Information Extraction
        extraction_instruction = """
        Extract all entities, numerical values, and their relationships from the passage and question. 
        Ensure you capture all potential candidates for reasoning, including ambiguous references and implicit information.
        Format your output as a structured list of entities and their associated values.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Question Analysis
        question_analysis_instruction = f"""
        Analyze the question to determine its intent. Classify the question type as one of the following:
        - Arithmetic (e.g., addition, subtraction, counting)
        - Comparison (e.g., greater than, less than)
        - Selection (e.g., which team won, what happened first)
        - Span Extraction (e.g., who did, what was the name of)
        Provide a detailed reasoning plan based on the identified question type.
        Relevant extracted information: {extracted_info}
        """
        question_plan = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Parallel Reasoning Paths
        arithmetic_instruction = f"""
        Perform arithmetic operations if required by the question. Extract relevant numbers and calculate the result.
        Relevant extracted information: {extracted_info}
        Question analysis: {question_plan}
        """
        comparison_instruction = f"""
        Perform comparisons if required by the question. Extract relevant entities and their associated values, then compare them.
        Relevant extracted information: {extracted_info}
        Question analysis: {question_plan}
        """
        span_extraction_instruction = f"""
        Extract the exact text span that answers the question if it requires span extraction.
        Relevant extracted information: {extracted_info}
        Question analysis: {question_plan}
        """

        results = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text),
            self.generate(instruction=span_extraction_instruction, context=self.problem_text)
        )

        # Step 4: Validation and Refinement
        refined_results = await asyncio.gather(
            self.revise(instruction="Validate and refine this arithmetic result.", context=results[0]),
            self.revise(instruction="Validate and refine this comparison result.", context=results[1]),
            self.revise(instruction="Validate and refine this span extraction result.", context=results[2])
        )

        # Step 5: Final Answer Construction
        final_answer_instruction = """
        Combine the validated results into a concise final answer. Ensure the answer is clear, accurate, and directly addresses the question.
        """
        final_answer = await self.ensemble(instruction=final_answer_instruction, contexts=refined_results)

        return final_answer