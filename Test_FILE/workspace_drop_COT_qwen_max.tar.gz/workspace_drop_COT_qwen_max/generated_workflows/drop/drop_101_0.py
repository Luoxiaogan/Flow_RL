# Workflow ID: drop_101_0
# Benchmark: drop
# Data Indices: [705, 6]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant entities, numerical values, and relationships
        extraction_instruction = """
        Thoroughly analyze the provided passage and extract ALL relevant information, including:
        - Entities (e.g., teams, players, events)
        - Numerical values (e.g., scores, distances, times) and their associated entities
        - Relationships between entities and numerical values
        Ensure no information is missed and organize the output clearly.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_analysis_instruction = f"""
        Analyze the question in detail to determine its intent. Specifically:
        - Identify whether the question requires an arithmetic operation (e.g., sum, difference), counting, comparison, or span extraction.
        - Highlight any ambiguous references or implicit information that needs clarification.
        Use the following extracted information as context: {extracted_info}
        """
        question_intent = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform reasoning and calculations in parallel
        reasoning_instruction = f"""
        Based on the extracted information and the question's intent, perform the necessary reasoning or calculations:
        - If the question involves arithmetic, compute the required sum, difference, or other operation.
        - If the question involves counting, count the relevant occurrences accurately.
        - If the question involves comparison, compare the relevant entities or values.
        - If the question involves span extraction, identify the exact text span that answers the question.
        Use the following context: {extracted_info} and {question_intent}.
        """
        span_extraction_instruction = f"""
        If the question requires span extraction, identify the exact text span from the passage that answers the question.
        Ensure the span is precise and directly addresses the question.
        Use the following context: {extracted_info} and {question_intent}.
        """

        # Perform reasoning and span extraction in parallel
        reasoning_result, span_result = await asyncio.gather(
            self.generate(instruction=reasoning_instruction, context=self.problem_text),
            self.generate(instruction=span_extraction_instruction, context=self.problem_text)
        )

        # Step 4: Refine results if necessary
        refinement_instruction = f"""
        Review the following results and refine them for accuracy:
        - Reasoning result: {reasoning_result}
        - Span extraction result: {span_result}
        Correct any errors, clarify ambiguities, and ensure the results align with the question's intent.
        """
        refined_results = await self.revise(instruction=refinement_instruction, context=self.problem_text)

        # Step 5: Synthesize the final answer
        synthesis_instruction = f"""
        Combine the refined results to produce the final answer:
        - Reasoning result: {reasoning_result}
        - Span extraction result: {span_result}
        Ensure the final answer is clear, concise, and directly addresses the question.
        """
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=[reasoning_result, span_result])

        return final_answer