# Workflow ID: drop_133_0
# Benchmark: drop
# Data Indices: [44, 683]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract entities, numerical values, and analyze the question
        extraction_task = self.generate(
            instruction="Extract all entities, numerical values, and their relationships from the passage. "
                        "Ensure to capture implicit information and resolve any ambiguous references.",
            context=self.problem_text
        )
        question_analysis_task = self.generate(
            instruction="Analyze the question to determine its intent. "
                        "Identify if it requires arithmetic operations, counting, comparison, span extraction, or other reasoning.",
            context=self.problem_text
        )

        # Execute extraction and question analysis in parallel
        extraction, question_analysis = await asyncio.gather(extraction_task, question_analysis_task)

        # Step 2: Refine entity-value associations
        refined_associations = await self.revise(
            instruction=f"Refine the associations between entities and numerical values based on the following extracted information: {extraction}. "
                        "Resolve any ambiguities and ensure correct pairing of entities with their corresponding values.",
            context=self.problem_text
        )

        # Step 3: Parallel reasoning paths based on question intent
        reasoning_tasks = []

        if "arithmetic" in question_analysis.lower():
            reasoning_tasks.append(
                self.generate(
                    instruction=f"Perform the required arithmetic operations using the refined associations: {refined_associations}. "
                                "Ensure calculations are accurate and aligned with the question intent.",
                    context=self.problem_text
                )
            )
        if "count" in question_analysis.lower():
            reasoning_tasks.append(
                self.generate(
                    instruction=f"Count the occurrences of the specified entities or events based on the refined associations: {refined_associations}.",
                    context=self.problem_text
                )
            )
        if "compare" in question_analysis.lower():
            reasoning_tasks.append(
                self.generate(
                    instruction=f"Compare the specified entities or values based on the refined associations: {refined_associations}. "
                                "Determine which is greater, longer, or more as per the question intent.",
                    context=self.problem_text
                )
            )
        if "span" in question_analysis.lower():
            reasoning_tasks.append(
                self.generate(
                    instruction=f"Extract the exact text span that answers the question based on the refined associations: {refined_associations}.",
                    context=self.problem_text
                )
            )

        # Execute reasoning tasks in parallel
        reasoning_results = await asyncio.gather(*reasoning_tasks)

        # Step 4: Synthesize and validate the final answer
        final_answer = await self.ensemble(
            instruction=f"Evaluate and synthesize the following reasoning results: {reasoning_results}. "
                        "Select the most appropriate answer that aligns with the question intent and passage context.",
            contexts=reasoning_results
        )

        return final_answer