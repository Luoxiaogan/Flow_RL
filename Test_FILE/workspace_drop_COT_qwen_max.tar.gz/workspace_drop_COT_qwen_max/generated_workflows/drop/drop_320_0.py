# Workflow ID: drop_320_0
# Benchmark: drop
# Data Indices: [217, 404]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information from the passage
        extraction_instruction = (
            "Extract all numerical values, dates, entities, and their relationships from the passage. "
            "Provide a structured list of these elements, including their context and associations. "
            "Ensure no relevant information is missed."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Interpret the question and determine reasoning requirements
        question_instruction = (
            f"Given the extracted information: {extracted_info}, analyze the question to determine: "
            "1. The type of reasoning required (e.g., arithmetic, comparison, span extraction). "
            "2. The specific entities or values involved. "
            "3. Any constraints or additional context needed for answering the question."
        )
        reasoning_requirements = await self.generate(instruction=question_instruction, context=self.problem_text)

        # Step 3: Execute parallel reasoning paths
        arithmetic_instruction = (
            f"Based on the reasoning requirements: {reasoning_requirements}, perform any necessary arithmetic operations. "
            "Include step-by-step calculations and intermediate results."
        )
        comparison_instruction = (
            f"Based on the reasoning requirements: {reasoning_requirements}, compare entities or values as needed. "
            "Clearly state the basis of comparison and the result."
        )
        span_extraction_instruction = (
            f"Based on the reasoning requirements: {reasoning_requirements}, extract the relevant text span(s). "
            "Ensure the span directly answers the question."
        )

        arithmetic_result, comparison_result, span_extraction_result = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text),
            self.generate(instruction=span_extraction_instruction, context=self.problem_text)
        )

        # Step 4: Ensemble decision to select the best answer
        ensemble_instruction = (
            "Evaluate the following candidate solutions and select the most appropriate one: "
            f"1. Arithmetic Result: {arithmetic_result}. "
            f"2. Comparison Result: {comparison_result}. "
            f"3. Span Extraction Result: {span_extraction_result}. "
            "Consider the question intent and ensure the selected answer is accurate and complete."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[arithmetic_result, comparison_result, span_extraction_result])

        # Step 5: Refine the final answer
        refine_instruction = (
            f"Refine the following answer: {final_answer}. Ensure it is clear, concise, and fully addresses the question. "
            "Correct any formatting issues or ambiguities."
        )
        refined_answer = await self.revise(instruction=refine_instruction, context=final_answer)

        return refined_answer