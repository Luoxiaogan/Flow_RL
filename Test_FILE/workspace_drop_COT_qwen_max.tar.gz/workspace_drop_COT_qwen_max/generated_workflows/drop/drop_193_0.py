# Workflow ID: drop_193_0
# Benchmark: drop
# Data Indices: [774, 696]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the passage and question
        extract_instruction = (
            "Thoroughly analyze the provided passage and question. Identify all entities, numerical values, "
            "temporal references, and relationships between them. Infer any implicit information that may be "
            "relevant to answering the question. Organize your findings into categories: entities, numbers, "
            "dates, and relationships."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Classify the question type
        classify_instruction = (
            "Based on the question, determine the type of reasoning required. Possible types include: "
            "arithmetic operations (addition, subtraction, etc.), counting, comparison, selection, and span extraction. "
            "Use keywords and linguistic structure to classify the question. Provide a clear explanation of your reasoning."
        )
        question_type = await self.generate(instruction=classify_instruction, context=self.problem_text)

        # Step 3: Solve the problem based on the question type
        solve_instruction_template = (
            "Given the extracted information: {info}, and the identified question type: {type}, "
            "solve the problem step by step. For arithmetic operations, perform the necessary calculations. "
            "For counting, tally the relevant occurrences. For comparisons, evaluate the options. "
            "For span extraction, isolate the correct text span. Ensure your solution is consistent with the passage."
        )
        solve_instruction = solve_instruction_template.format(info=extracted_info, type=question_type)

        # Parallelize independent operations where possible
        solution_candidates = await asyncio.gather(
            self.generate(instruction=solve_instruction, context=self.problem_text),
            self.generate(instruction=solve_instruction, context=self.problem_text)  # Redundant for demonstration
        )

        # Step 4: Select the best solution candidate
        ensemble_instruction = (
            "Evaluate the provided solution candidates. Select the one that is most accurate, complete, "
            "and consistent with the passage and question. If necessary, synthesize elements from multiple candidates."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=solution_candidates)

        # Step 5: Validate and refine the solution
        revise_instruction = (
            "Critique the provided solution. Check for accuracy, logical correctness, and completeness. "
            "Refine the solution if necessary, ensuring it directly answers the question and aligns with the passage."
        )
        refined_solution = await self.revise(instruction=revise_instruction, context=final_solution)

        return refined_solution