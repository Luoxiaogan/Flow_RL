# Workflow ID: drop_45_0
# Benchmark: drop
# Data Indices: [552, 440]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Initial Analysis - Extract entities, values, and relationships
        initial_analysis = await self.generate(
            instruction="Extract all entities, numerical values, and their relationships from the passage. "
                        "Identify the type of question being asked (e.g., arithmetic, comparison, span extraction). "
                        "Determine what specific information is required to answer the question.",
            context=self.problem_text
        )

        # Step 2: Entity-Value Association - Map values to entities
        entity_value_association = await self.generate(
            instruction=f"Given the extracted information: {initial_analysis}, "
                        "associate each numerical value or span with its corresponding entity. "
                        "Ensure that the mapping is accurate and unambiguous.",
            context=self.problem_text
        )

        # Step 3: Answer Construction - Generate the answer based on the question type
        answer_construction = await self.generate(
            instruction=f"Using the entity-value associations: {entity_value_association}, "
                        "construct the final answer to the question. "
                        "If the question involves arithmetic, perform the necessary calculations. "
                        "If it involves comparison, compare the relevant values. "
                        "If it involves span extraction, extract the relevant phrase.",
            context=self.problem_text
        )

        # Step 4: Validation and Refinement - Critique and refine the answer
        refined_answer = await self.revise(
            instruction="Critique the generated answer to ensure it aligns with the question intent and passage context. "
                        "Refine the answer if necessary to improve accuracy and clarity.",
            context=answer_construction
        )

        # Step 5: Final Output - Summarize the reasoning process
        final_output = await self.summarize(
            instruction="Condense the reasoning process into a concise final answer. "
                        "Ensure the answer is clear, accurate, and directly addresses the question.",
            context=refined_answer
        )

        return final_output