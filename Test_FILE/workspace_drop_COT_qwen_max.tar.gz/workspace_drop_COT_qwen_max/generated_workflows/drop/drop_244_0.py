# Workflow ID: drop_244_0
# Benchmark: drop
# Data Indices: [377, 233]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract Key Information
        extract_entities_task = self.generate(
            instruction="Identify all entities, numerical values, and their relationships in the passage. "
                        "Include any relevant context that connects these elements.",
            context=self.problem_text
        )
        extract_question_intent_task = self.generate(
            instruction="Analyze the question to determine its type (e.g., arithmetic, comparison, span extraction). "
                        "Outline the reasoning steps needed to answer the question.",
            context=self.problem_text
        )

        # Run extraction tasks in parallel
        extracted_info, question_intent = await asyncio.gather(extract_entities_task, extract_question_intent_task)

        # Step 2: Perform Reasoning or Calculation
        reasoning_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            f"And the question intent: {question_intent}\n"
            "Perform the necessary reasoning or calculation to answer the question. "
            "Ensure all steps are clearly explained."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Validate and Refine
        refinement_instruction = (
            "Review the reasoning process and result. Identify any errors or ambiguities. "
            "Refine the reasoning or calculation to ensure correctness."
        )
        refined_result = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 4: Finalize Answer
        finalize_instruction = (
            "Condense the reasoning into a concise final answer that directly addresses the question. "
            "Ensure the answer is clear and unambiguous."
        )
        final_answer = await self.summarize(instruction=finalize_instruction, context=refined_result)

        return final_answer