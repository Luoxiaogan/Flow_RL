# Workflow ID: drop_343_0
# Benchmark: drop
# Data Indices: [534, 197]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant entities, numerical values, and relationships
        extraction_instruction = (
            "Extract all entities, numerical values, and their relationships from the passage. "
            "Include explicit and implicit information. Format the output as a structured list."
        )
        extracted_data = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_analysis_instruction = (
            "Analyze the question to determine its intent. Classify it into one of the following categories: "
            "arithmetic operation, counting, comparison, selection, or span extraction. "
            "Provide a detailed explanation of the classification."
        )
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Construct a detailed instruction for solving the problem
        solve_instruction = (
            f"Based on the extracted data: {extracted_data} and the question analysis: {question_analysis}, "
            "construct a detailed plan to solve the problem. Include steps for entity-number association, "
            "arithmetic operations (if applicable), and reasoning strategies. Ensure the output is clear and precise."
        )
        solution_plan = await self.generate(instruction=solve_instruction, context=self.problem_text)

        # Step 4: Generate multiple reasoning paths in parallel
        reasoning_path_1 = self.generate(
            instruction=f"Solve the problem using the following plan: {solution_plan}. Focus on accuracy.",
            context=self.problem_text
        )
        reasoning_path_2 = self.generate(
            instruction=f"Solve the problem using the following plan: {solution_plan}. Focus on completeness.",
            context=self.problem_text
        )
        reasoning_path_3 = self.generate(
            instruction=f"Solve the problem using the following plan: {solution_plan}. Focus on clarity.",
            context=self.problem_text
        )

        # Execute reasoning paths in parallel
        results = await asyncio.gather(reasoning_path_1, reasoning_path_2, reasoning_path_3)

        # Step 5: Ensemble to select the best result
        ensemble_instruction = (
            "Evaluate the following solutions and select the best one. "
            "Consider accuracy, completeness, and clarity. Provide the final answer."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 6: Refine the final answer if necessary
        refinement_instruction = (
            "Review the final answer for any errors or omissions. "
            "Improve clarity and ensure it directly answers the question."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        return refined_answer