# Workflow ID: drop_208_0
# Benchmark: drop
# Data Indices: [267, 11]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information from the passage
        extract_instruction = """
        Extract all numerical values, entities, and their relationships from the passage. 
        Include explicit mentions (e.g., scores, distances) and implicit associations (e.g., who scored what). 
        Format the output as a structured list or table for clarity.
        """
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Analyze the question intent
        analyze_instruction = f"""
        Analyze the question to determine the type of reasoning required. 
        Consider the following categories: arithmetic operations (e.g., sum, difference), counting, comparison, selection, or span extraction. 
        Based on the extracted information: {extracted_info}, specify the exact task and reasoning steps needed to answer the question.
        """
        question_analysis = await self.generate(instruction=analyze_instruction, context=self.problem_text)

        # Step 3: Perform reasoning to compute or extract the answer
        reasoning_instruction = f"""
        Using the extracted information: {extracted_info} and the question analysis: {question_analysis}, 
        compute or extract the answer. Follow these guidelines:
        - For arithmetic operations, perform the calculation step-by-step.
        - For counting, ensure all relevant instances are included.
        - For comparisons, clearly state the basis of comparison.
        - For span extraction, provide the exact text span with context.
        Format the output as a clear, concise answer.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine the reasoning process or final answer
        refine_instruction = f"""
        Critique and refine the reasoning process or the final answer: {reasoning_result}. 
        Ensure the answer is accurate, complete, and directly addresses the question intent. 
        If necessary, suggest corrections or improvements.
        """
        refined_answer = await self.revise(instruction=refine_instruction, context=reasoning_result)

        # Step 5: Handle multiple plausible answers (if applicable)
        # Use Ensemble to evaluate and select the best option
        ensemble_instruction = f"""
        Evaluate the reasoning result: {reasoning_result} and the refined answer: {refined_answer}. 
        If there are multiple plausible answers, select the best one based on the question intent and passage context.
        """
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[reasoning_result, refined_answer])

        return final_answer