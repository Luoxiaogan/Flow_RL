# Workflow ID: drop_84_0
# Benchmark: drop
# Data Indices: [443, 277]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant numerical values, entities, and relationships
        extraction_instruction = """
        Extract all numerical values, entities, and their relationships from the passage. 
        Focus on identifying dates, counts, measurements, and any other quantitative information. 
        Also, note any comparisons, sequences, or hierarchical relationships between entities. 
        Ensure the extraction is exhaustive and includes ALL relevant information.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Interpret the question's intent and identify relevant information
        question_intent_instruction = f"""
        Analyze the question and determine its intent. Classify the type of reasoning required:
        - Arithmetic operations (e.g., addition, subtraction, multiplication, division)
        - Counting (e.g., how many times something occurs)
        - Comparison (e.g., greater than, less than, equal to)
        - Span extraction (e.g., identifying a specific entity or phrase)
        - Other (specify if none of the above apply)
        
        Use the following extracted information to guide your analysis:
        {extracted_info}
        
        Identify which pieces of extracted information are relevant to answering the question.
        """
        question_analysis = await self.generate(instruction=question_intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or calculation based on the question's intent
        reasoning_instruction = f"""
        Based on the question's intent and the relevant extracted information, perform the necessary reasoning or calculation.
        If the question requires arithmetic, compute the result using the appropriate numbers.
        If the question requires counting, count the relevant occurrences.
        If the question requires comparison, compare the relevant entities or values.
        If the question requires span extraction, identify the exact text span that answers the question.
        
        Relevant extracted information:
        {extracted_info}
        
        Question analysis:
        {question_analysis}
        
        Provide the answer in a clear and concise format.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine the answer for clarity and accuracy
        refinement_instruction = f"""
        Review the following reasoning result and ensure it is clear, concise, and directly addresses the question.
        Correct any ambiguities, errors, or inconsistencies. Format the answer appropriately based on its type:
        - Numerical answers should be presented as numbers.
        - Text spans should be enclosed in quotation marks.
        - Comparative answers should explicitly state the relationship (e.g., "greater than", "less than").
        
        Reasoning result:
        {reasoning_result}
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Return the final answer
        return refined_answer