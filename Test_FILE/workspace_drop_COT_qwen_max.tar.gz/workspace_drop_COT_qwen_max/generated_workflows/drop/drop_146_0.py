# Workflow ID: drop_146_0
# Benchmark: drop
# Data Indices: [610, 423]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract Relevant Information
        extraction_instruction = (
            "Extract all entities, numerical values, and their relationships from the passage. "
            "Ensure that no critical information is missed. Organize the extracted data in a structured format."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Parse the Question
        question_parsing_instruction = (
            "Analyze the question and determine its type (e.g., arithmetic operation, counting, comparison, span extraction). "
            "Identify the specific reasoning or calculation required to answer the question."
        )
        question_analysis = await self.generate(instruction=question_parsing_instruction, context=self.problem_text)

        # Step 3: Perform Reasoning/Calculation
        reasoning_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            f"And the question analysis: {question_analysis}\n"
            "Perform the necessary reasoning or calculation to answer the question. "
            "For arithmetic operations, extract numbers and compute the result. "
            "For counting, identify and count occurrences. "
            "For comparisons, compare values and determine the relationship. "
            "For span extraction, select the correct text span."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and Refine
        validation_instruction = (
            "Critique and refine the reasoning result. Ensure that the answer is accurate, coherent, "
            "and directly addresses the question. Handle any ambiguities or inconsistencies."
        )
        refined_result = await self.revise(instruction=validation_instruction, context=reasoning_result)

        # Step 5: Synthesize Final Answer
        synthesis_instruction = (
            "Combine the refined reasoning result into a final answer. Ensure that the answer is clear, "
            "concise, and directly addresses the question."
        )
        final_answer = await self.ensemble(
            instruction=synthesis_instruction,
            contexts=[refined_result, self.problem_text]
        )

        return final_answer