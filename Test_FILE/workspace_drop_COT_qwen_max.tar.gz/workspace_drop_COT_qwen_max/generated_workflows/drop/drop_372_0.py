# Workflow ID: drop_372_0
# Benchmark: drop
# Data Indices: [391, 714]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (entities, numbers, relationships)
        extraction_instruction = """
        Extract all relevant entities, numbers, and their relationships from the passage and question. 
        Include:
        - Names of people, teams, or objects
        - Numerical values and their associated entities
        - Actions or events described in the passage
        - Any implicit or explicit relationships between entities and numbers
        Format the output as a structured list or table for clarity.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze question intent (arithmetic, counting, comparison, span extraction)
        intent_instruction = f"""
        Analyze the question to determine the type of reasoning required. Specifically:
        - Identify if the question involves arithmetic operations (e.g., addition, subtraction).
        - Check if the question asks for counting occurrences of specific entities or actions.
        - Determine if the question involves comparison (e.g., greater than, less than).
        - Identify if the question requires extracting a text span (e.g., a name or phrase).
        Use the following extracted information for context: {extracted_info}
        Output the reasoning type and a brief explanation of how to proceed.
        """
        question_intent = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the identified intent
        reasoning_instruction = f"""
        Based on the identified reasoning type ({question_intent}), perform the necessary operation:
        - For arithmetic, compute the required value using the extracted numbers and relationships.
        - For counting, count the occurrences of the specified entities or actions.
        - For comparison, compare the relevant values and determine the correct answer.
        - For span extraction, identify and extract the requested text span.
        Use the following extracted information for context: {extracted_info}
        Provide the final result along with a justification.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the result
        validation_instruction = f"""
        Validate the reasoning result ({reasoning_result}) against the passage and question.
        - Ensure the answer aligns with the question intent.
        - Cross-check the result with the extracted information.
        - If ambiguities exist, refine the answer to resolve them.
        Provide the final validated answer.
        """
        final_answer = await self.revise(instruction=validation_instruction, context=reasoning_result)

        return final_answer