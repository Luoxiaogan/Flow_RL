# Workflow ID: drop_337_0
# Benchmark: drop
# Data Indices: [501, 661]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract relevant information (numbers, entities, key phrases)
        extraction_instruction = (
            "Extract all numerical values, entities, and key phrases from the passage that could potentially answer the question. "
            "Ensure you capture all relevant data points, including dates, names, and quantities."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine reasoning type
        question_analysis_instruction = (
            "Analyze the question to determine the type of reasoning required. "
            "Identify whether the question asks for addition, subtraction, counting, comparison, or span extraction. "
            "Provide a clear explanation of the reasoning type and how it should be applied to the extracted information."
        )
        reasoning_type = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the identified type
        reasoning_instruction = (
            f"Based on the identified reasoning type ({reasoning_type}), perform the necessary calculations or extractions. "
            "Use the extracted information to compute the answer. Ensure all steps are clearly explained."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=extracted_info)

        # Step 4: Validate and refine the result
        validation_instruction = (
            "Review the reasoning result and validate its accuracy against the original problem text. "
            "Ensure the answer aligns with the question intent and the extracted information. "
            "Make any necessary corrections or refinements."
        )
        refined_result = await self.revise(instruction=validation_instruction, context=reasoning_result)

        # Step 5: Summarize the final answer
        summary_instruction = (
            "Condense the refined result into a concise and clear answer. "
            "Ensure the final output directly addresses the question and is easy to understand."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_result)

        return final_answer