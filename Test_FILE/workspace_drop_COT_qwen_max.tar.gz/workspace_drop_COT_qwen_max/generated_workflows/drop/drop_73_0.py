# Workflow ID: drop_73_0
# Benchmark: drop
# Data Indices: [408, 344]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Initial Analysis - Extract relevant information
        initial_analysis = await self.generate(
            instruction="Analyze the passage and question thoroughly. Identify all entities, numerical values, dates, and relationships. Determine the type of reasoning required (e.g., arithmetic, counting, comparison).",
            context=self.problem_text
        )

        # Step 2: Entity-Value Association - Refine extracted information
        refined_data = await self.revise(
            instruction=f"Refine the following extracted information: {initial_analysis}. Ensure correct association between entities and their values or spans. Resolve ambiguities (e.g., pronouns, partial names) and handle similar entities carefully.",
            context=self.problem_text
        )

        # Step 3: Reasoning and Calculation - Perform required reasoning
        reasoning_result = await self.generate(
            instruction=f"Based on the refined data: {refined_data}, perform the necessary reasoning or calculation. Follow these guidelines:\n"
                        "- For arithmetic questions, compute sums, differences, or other operations.\n"
                        "- For counting questions, tally occurrences of specific events or entities.\n"
                        "- For comparison questions, evaluate which entity satisfies the condition.\n"
                        "- For span extraction, identify the exact text span that answers the question.",
            context=self.problem_text
        )

        # Step 4: Validation and Finalization - Validate the result
        final_answer = await self.revise(
            instruction=f"Validate the following result: {reasoning_result}. Ensure it is accurate, complete, and formatted appropriately. Check against the original passage and question to confirm correctness.",
            context=self.problem_text
        )

        return final_answer