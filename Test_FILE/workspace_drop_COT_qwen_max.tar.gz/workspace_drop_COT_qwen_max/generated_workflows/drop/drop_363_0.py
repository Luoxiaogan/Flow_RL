# Workflow ID: drop_363_0
# Benchmark: drop
# Data Indices: [175, 620]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all numerical values and entities from the passage
        extract_instruction = (
            "Extract ALL numerical values, entities, and their relationships from the passage. "
            "Provide the output in a structured format, associating each number with its corresponding entity. "
            "Include any implicit information that can be inferred from the context."
        )
        extracted_data = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its type and intent
        question_analysis_instruction = (
            "Analyze the question to determine its type (e.g., arithmetic, counting, comparison, selection, span extraction). "
            "Identify the specific entities and numerical values relevant to answering the question. "
            "Clarify whether the question requires addition, subtraction, counting, comparison, or direct extraction."
        )
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform numerical reasoning or entity tracking based on the question type
        reasoning_instruction = (
            f"Based on the extracted data: {extracted_data} and the question analysis: {question_analysis}, "
            "perform the necessary reasoning steps to answer the question. If the question involves arithmetic operations, "
            "identify the relevant numbers and calculate the result. If it involves counting or comparison, "
            "ensure accurate association of numbers with their entities. Provide a detailed explanation of your reasoning."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Revise the reasoning result for accuracy and clarity
        revise_instruction = (
            "Critique and refine the reasoning result to ensure accuracy and clarity. "
            "Check for correct entity-number associations, logical consistency, and adherence to the question intent. "
            "Provide a revised version of the reasoning result."
        )
        revised_result = await self.revise(instruction=revise_instruction, context=reasoning_result)

        # Step 5: Generate alternative reasoning paths for robustness
        alternative_reasoning_instruction = (
            "Generate an alternative reasoning path to solve the question. "
            "Consider different interpretations or approaches that could lead to the same answer. "
            "Provide a detailed explanation of this alternative reasoning."
        )
        alternative_reasoning = await self.generate(instruction=alternative_reasoning_instruction, context=self.problem_text)

        # Step 6: Ensembling to select the best answer
        ensemble_instruction = (
            "Compare the revised reasoning result and the alternative reasoning path. "
            "Select the most accurate and contextually appropriate answer. "
            "Ensure the final output adheres to the expected format (number, date, text span, etc.)."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[revised_result, alternative_reasoning])

        return final_answer