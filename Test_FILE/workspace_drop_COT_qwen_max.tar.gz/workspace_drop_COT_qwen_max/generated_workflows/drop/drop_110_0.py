# Workflow ID: drop_110_0
# Benchmark: drop
# Data Indices: [698, 306]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the passage
        extraction_instruction = (
            "Extract all numerical values, entities, and relationships mentioned in the passage. "
            "Ensure that each number is associated with its corresponding entity or event. "
            "Include any implicit information that can be inferred from the context."
        )
        extraction_task = self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine reasoning intent
        question_analysis_instruction = (
            "Analyze the question and determine the type of reasoning required. "
            "Identify whether the question involves arithmetic operations (e.g., sum, difference), "
            "counting occurrences, comparison, or span extraction. "
            "Provide a clear description of the reasoning steps needed to answer the question."
        )
        question_analysis_task = self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Execute extraction and question analysis in parallel
        extraction, question_analysis = await asyncio.gather(extraction_task, question_analysis_task)

        # Step 3: Perform reasoning based on the question intent
        reasoning_instruction = (
            f"Given the extracted information: {extraction}\n"
            f"And the question analysis: {question_analysis}\n"
            "Perform the necessary reasoning steps to answer the question. "
            "If the question involves arithmetic, calculate the result step by step. "
            "If it involves counting, tally the occurrences accurately. "
            "If it involves comparison, compare the relevant entities or values. "
            "Ensure that the reasoning process is clear and logical."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the reasoning process
        refinement_instruction = (
            f"Review the reasoning process: {reasoning_result}\n"
            "Critique and refine the solution to ensure accuracy and alignment with the question intent. "
            "Correct any errors or ambiguities in the reasoning steps. "
            "Provide a revised version of the reasoning process."
        )
        refined_reasoning = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Summarize the final answer
        summarization_instruction = (
            f"Condense the refined reasoning: {refined_reasoning}\n"
            "Summarize the final answer in a concise format that directly addresses the question. "
            "Ensure that the answer is clear, accurate, and complete."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_reasoning)

        return final_answer