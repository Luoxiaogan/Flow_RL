# Workflow ID: drop_323_0
# Benchmark: drop
# Data Indices: [438, 526]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract relevant information from the passage
        extraction_instruction = (
            "Thoroughly analyze the provided passage and extract all numerical values, entities, "
            "and their relationships. List them clearly with explanations of their context."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Understand the question intent
        question_intent_instruction = (
            f"Given the extracted information: {extracted_info}, analyze the question to determine its intent. "
            "Classify the type of reasoning required (e.g., arithmetic, counting, comparison, span extraction). "
            "Provide a detailed explanation of the reasoning steps needed to answer the question."
        )
        question_analysis = await self.generate(instruction=question_intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question intent
        reasoning_instruction_template = (
            "Using the extracted information and the analysis of the question intent, perform the following reasoning step: {step}. "
            "Ensure your reasoning is precise and includes all relevant calculations or comparisons."
        )

        # Define reasoning steps dynamically based on the question intent
        reasoning_steps = [
            "Identify and calculate the required arithmetic operation.",
            "Compare relevant values to determine which is greater or lesser.",
            "Extract the correct text span that answers the question.",
        ]

        # Execute reasoning steps in parallel
        reasoning_tasks = [
            self.generate(instruction=reasoning_instruction_template.format(step=step), context=self.problem_text)
            for step in reasoning_steps
        ]
        reasoning_results = await asyncio.gather(*reasoning_tasks)

        # Step 4: Synthesize and validate results
        synthesis_instruction = (
            "Evaluate the following reasoning results and synthesize the most accurate answer: {results}. "
            "Ensure the final answer directly addresses the question and aligns with the extracted information."
        )
        final_answer = await self.ensemble(
            instruction=synthesis_instruction.format(results=reasoning_results),
            contexts=reasoning_results
        )

        # Step 5: Return the final answer
        return final_answer