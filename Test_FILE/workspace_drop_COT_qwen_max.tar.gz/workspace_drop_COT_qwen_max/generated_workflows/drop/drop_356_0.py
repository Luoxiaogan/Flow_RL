# Workflow ID: drop_356_0
# Benchmark: drop
# Data Indices: [738, 449]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information from the passage
        extraction_instruction = (
            "Extract all numerical values, entities, and relationships mentioned in the passage. "
            "Include explicit and implicit numerical information, such as counts, scores, dates, and comparisons. "
            "Ensure each number is associated with its corresponding entity or event."
        )
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_analysis_instruction = (
            "Analyze the question to determine its intent. Identify whether the question requires arithmetic operations (e.g., addition, subtraction), "
            "counting, comparison, span extraction, or another type of reasoning. Provide a clear description of the required reasoning process."
        )
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Refine the extracted data by associating numbers with entities
        refinement_instruction = (
            f"Refine the extracted data by ensuring each number is correctly associated with its respective entity or event. "
            f"Use the following extracted information as input: {extraction}. Ensure no associations are ambiguous."
        )
        refined_data = await self.revise(instruction=refinement_instruction, context=extraction)

        # Step 4: Perform the required reasoning or calculation
        reasoning_instruction = (
            f"Based on the question's intent ({question_analysis}) and the refined data ({refined_data}), "
            f"perform the necessary reasoning or calculation to answer the question. If the question involves arithmetic, "
            f"show the step-by-step calculation. If it involves span extraction, provide the exact text span from the passage."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 5: Validate the result using ensemble to ensure correctness
        validation_instruction = (
            f"Compare the reasoning result ({reasoning_result}) with the extracted data ({refined_data}). "
            f"Ensure the answer is consistent with the passage and addresses the question's intent. If discrepancies exist, resolve them."
        )
        final_answer = await self.ensemble(instruction=validation_instruction, contexts=[reasoning_result, refined_data])

        return final_answer