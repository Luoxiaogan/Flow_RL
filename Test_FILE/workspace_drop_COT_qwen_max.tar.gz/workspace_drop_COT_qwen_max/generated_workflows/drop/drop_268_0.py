# Workflow ID: drop_268_0
# Benchmark: drop
# Data Indices: [96, 77]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information from the passage and question
        extraction_instruction = (
            "Carefully analyze the passage and question. "
            "Extract all numerical values, entities, and relationships mentioned in the question. "
            "Ensure you capture ALL relevant information, including implicit references. "
            "Format the output as a structured list for clarity."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Understand the question's intent
        intent_instruction = (
            f"Based on the extracted information: {extracted_info}, "
            "determine the type of reasoning required to answer the question. "
            "Classify the question into one of the following categories: "
            "1. Arithmetic (addition, subtraction, etc.), "
            "2. Counting (how many times, how many different), "
            "3. Comparison (greater than, less than, equal to), "
            "4. Selection (which one, who did), "
            "5. Span Extraction (what is the name, what happened). "
            "Provide a clear classification and reasoning."
        )
        question_intent = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question's intent
        reasoning_instruction_template = (
            f"Given the extracted information: {extracted_info}, "
            "and the question's intent: {question_intent}, "
            "solve the problem step by step. "
            "If the question involves arithmetic, perform the calculation explicitly. "
            "If it involves comparison, clearly state the values being compared. "
            "If it requires span extraction, identify the exact text span. "
            "Ensure your reasoning is thorough and leaves no ambiguity."
        )
        reasoning_instruction = reasoning_instruction_template.format(
            extracted_info=extracted_info, question_intent=question_intent
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the answer
        refinement_instruction = (
            f"Review the reasoning result: {reasoning_result}. "
            "Check for logical consistency, correctness, and alignment with the question. "
            "Refine the answer if necessary, ensuring it is accurate and concise."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Handle ambiguities and edge cases (if needed)
        # Use Ensemble to compare multiple reasoning paths if there's ambiguity
        ensemble_instruction = (
            f"Compare the following results and select the most accurate answer: "
            f"1. Original reasoning: {reasoning_result}, "
            f"2. Refined answer: {refined_answer}. "
            "Synthesize the best solution based on clarity, correctness, and completeness."
        )
        final_answer = await self.ensemble(
            instruction=ensemble_instruction, contexts=[reasoning_result, refined_answer]
        )

        # Step 6: Summarize the final answer
        summary_instruction = (
            f"Summarize the final answer: {final_answer} into a concise format suitable for submission. "
            "Ensure the output is clear and directly answers the question."
        )
        final_output = await self.summarize(instruction=summary_instruction, context=final_answer)

        return final_output