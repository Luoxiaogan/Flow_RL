# Workflow ID: drop_240_0
# Benchmark: drop
# Data Indices: [388, 317]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio
        
        # Step 1: Extract relevant information from the passage and question
        extraction_instruction = (
            "Thoroughly analyze the provided passage and question. "
            "Extract all numerical values, entities, and their relationships. "
            "Identify any implicit information or contextual clues that might be relevant. "
            "Format the output as a structured list of key-value pairs."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)
        
        # Step 2: Interpret the question's intent
        intent_instruction = (
            f"Given the extracted information: {extracted_info}, determine the intent of the question. "
            "Classify the question type (e.g., arithmetic operation, comparison, counting, span extraction). "
            "Provide a clear explanation of what needs to be done to arrive at the answer."
        )
        question_intent = await self.generate(instruction=intent_instruction, context=self.problem_text)
        
        # Step 3: Perform reasoning or calculation based on the question's intent
        reasoning_instruction = (
            f"Using the extracted information: {extracted_info} and the question intent: {question_intent}, "
            "perform the necessary reasoning or calculation. If the question involves arithmetic, show the steps. "
            "If it involves counting or comparison, clearly explain the process. Format the final answer neatly."
        )
        raw_answer = await self.generate(instruction=reasoning_instruction, context=self.problem_text)
        
        # Step 4: Validate and refine the answer
        refinement_instruction = (
            f"Review the following answer: {raw_answer}. Cross-check it against the original problem text "
            "to ensure accuracy. Correct any errors or inconsistencies. Provide a refined version of the answer."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=raw_answer)
        
        # Step 5: Handle ambiguities or multiple candidates (if applicable)
        ambiguity_check_instruction = (
            f"Check if there are multiple valid interpretations or candidate answers for the question. "
            "If so, list them and provide a rationale for each. Otherwise, confirm the single best answer."
        )
        candidates = await self.generate(instruction=ambiguity_check_instruction, context=self.problem_text)
        
        if "multiple" in candidates.lower():
            ensemble_instruction = (
                f"Evaluate the following candidate answers: {candidates}. "
                "Select the most accurate and contextually appropriate answer based on the original problem text."
            )
            final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[refined_answer, candidates])
        else:
            final_answer = refined_answer
        
        return final_answer