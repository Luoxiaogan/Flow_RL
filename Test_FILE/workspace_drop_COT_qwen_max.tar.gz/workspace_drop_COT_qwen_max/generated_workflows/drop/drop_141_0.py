# Workflow ID: drop_141_0
# Benchmark: drop
# Data Indices: [373, 475]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant entities, numbers, and relationships from the passage
        extract_instruction = """
        Extract ALL entities, numerical values, and their relationships from the passage. 
        Include explicit mentions as well as implied relationships (e.g., pronouns, partial names). 
        Format the output as a structured list of key-value pairs where the key is the entity or number and the value describes its role or relationship in the passage.
        """
        extraction = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent and required reasoning type
        question_analysis_instruction = f"""
        Analyze the question to determine its intent and the type of reasoning required. 
        Classify the question into one of the following categories: arithmetic operation, counting, comparison, selection, or span extraction. 
        Identify the specific entities or numbers involved in the question based on the following extracted information: {extraction}.
        Provide a detailed breakdown of the reasoning steps needed to answer the question.
        """
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform the necessary reasoning or calculation
        reasoning_instruction = f"""
        Based on the question analysis: {question_analysis}, perform the required reasoning or calculation. 
        If the question involves arithmetic operations, calculate the result step by step. 
        If it involves span extraction, identify the exact text span that answers the question. 
        Ensure that all entities and numbers are correctly associated with their roles in the passage.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Revise the reasoning result to ensure accuracy
        revision_instruction = f"""
        Review the reasoning result: {reasoning_result} for accuracy. 
        Check that all calculations are correct, all entities are properly associated with their roles, and the answer aligns with the question intent. 
        Suggest improvements if necessary.
        """
        revised_result = await self.revise(instruction=revision_instruction, context=reasoning_result)

        # Step 5: Synthesize the final answer
        synthesis_instruction = f"""
        Combine the revised reasoning result: {revised_result} into a coherent final answer. 
        Ensure the answer is formatted correctly based on the question type (number, date, text span, etc.). 
        If there are multiple possible answers, evaluate them and select the most appropriate one.
        """
        final_answer = await self.generate(instruction=synthesis_instruction, context=revised_result)

        return final_answer