# Workflow ID: drop_112_0
# Benchmark: drop
# Data Indices: [374, 230]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract Relevant Information
        extraction_instruction = (
            "Identify and extract all entities, numerical values, and relationships from the passage "
            "that are relevant to the question. Include any mentions of people, places, events, and their associated "
            "numerical data. Organize the extracted information in a structured format."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze Question Intent
        intent_instruction = (
            f"Based on the extracted information: {extracted_info}, analyze the question to determine its intent. "
            "Classify the question as one of the following types: arithmetic operation, counting, comparison, "
            "span extraction, or other. Provide reasoning for your classification."
        )
        question_intent = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Perform Reasoning or Calculation
        reasoning_instruction = (
            f"Given the extracted information: {extracted_info} and the question intent: {question_intent}, "
            "perform the necessary reasoning or calculation to answer the question. If the question involves "
            "arithmetic, perform the calculation explicitly. If it involves counting, count the occurrences of "
            "relevant entities or events. If it involves span extraction, identify the exact text span that answers "
            "the question. Provide a clear and concise answer."
        )
        raw_answer = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine and Validate the Answer
        refine_instruction = (
            f"Critique and refine the following answer: {raw_answer}. Ensure it aligns with the question intent "
            "and is consistent with the extracted information. Check for logical consistency, numerical accuracy, "
            "and textual correctness. Revise the answer if necessary."
        )
        refined_answer = await self.revise(instruction=refine_instruction, context=raw_answer)

        # Step 5: Handle Ambiguities or Multiple Options (if applicable)
        ambiguity_check_instruction = (
            f"Evaluate whether the refined answer: {refined_answer} has any ambiguities or alternative interpretations. "
            "If multiple plausible answers exist, list them and provide reasoning for each."
        )
        ambiguity_check = await self.generate(instruction=ambiguity_check_instruction, context=self.problem_text)

        if "multiple" in ambiguity_check.lower():
            ensemble_instruction = (
                f"Given the following candidate answers: {ambiguity_check}, evaluate and select the best answer. "
                "Base your decision on relevance, accuracy, and alignment with the question intent and extracted information."
            )
            final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[refined_answer, ambiguity_check])
        else:
            final_answer = refined_answer

        return final_answer