# Workflow ID: drop_257_0
# Benchmark: drop
# Data Indices: [782, 477]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio
        
        # Step 1: Extract relevant information from the passage
        extraction_instruction = """
        Extract all numerical values, entities, and spans from the passage that could be relevant to answering the question. 
        Pay special attention to:
        - Numbers and their associated entities (e.g., scores, yardages, players).
        - Relationships between entities (e.g., who scored what, when events occurred).
        - Any implicit information that can be inferred from context.
        Organize the extracted information clearly for further analysis.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)
        
        # Step 2: Analyze the question intent
        intent_instruction = f"""
        Analyze the question to determine the type of reasoning required. Based on the extracted information: {extracted_info}
        Identify whether the task involves:
        - Arithmetic operations (e.g., summing, subtracting, averaging).
        - Comparison (e.g., identifying greater/lesser values or spans).
        - Selection (e.g., choosing specific entities or spans).
        - Span extraction (e.g., identifying specific phrases or entities).
        Provide a clear directive on how to proceed with the reasoning process.
        """
        question_intent = await self.generate(instruction=intent_instruction, context=self.problem_text)
        
        # Step 3: Perform reasoning based on the question intent
        reasoning_instruction = f"""
        Using the extracted information: {extracted_info} and the identified question intent: {question_intent}
        Perform the necessary reasoning to answer the question. Follow these guidelines:
        - For arithmetic operations, calculate totals, differences, or averages as needed.
        - For comparisons, evaluate which entity satisfies the condition specified in the question.
        - For span extraction, select the appropriate text span from the passage.
        Ensure all steps are clearly documented for validation.
        """
        reasoning_output = await self.generate(instruction=reasoning_instruction, context=self.problem_text)
        
        # Step 4: Refine and validate the reasoning output
        refinement_instruction = f"""
        Critique and refine the reasoning output: {reasoning_output}
        Cross-reference it with the original passage and question to ensure accuracy. Look for:
        - Misinterpretations of the question or passage.
        - Errors in arithmetic calculations or logical reasoning.
        - Ambiguities in span selection or entity identification.
        Provide a revised version of the reasoning output if necessary.
        """
        refined_output = await self.revise(instruction=refinement_instruction, context=reasoning_output)
        
        # Step 5: Summarize the final answer
        summary_instruction = f"""
        Condense the refined reasoning output: {refined_output} into a concise final answer.
        Ensure the answer directly addresses the question and is presented in a clear, unambiguous format.
        """
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_output)
        
        return final_answer