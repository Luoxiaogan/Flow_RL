# Workflow ID: drop_31_0
# Benchmark: drop
# Data Indices: [427, 727]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all numerical values, entities, and key phrases
        extraction_instruction = """
        Extract all numerical values, entities, and key phrases from the passage and question.
        Organize them into categories: numbers, entities, and relationships.
        Ensure no information is missed.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question intent
        intent_instruction = f"""
        Based on the extracted information: {extracted_info}
        Determine the intent of the question. Is it asking for an arithmetic operation (addition, subtraction, etc.), 
        a count, a comparison, or a span extraction? Provide a clear analysis of what needs to be done.
        """
        question_intent = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question intent
        reasoning_instruction = f"""
        Using the extracted information: {extracted_info} and the question intent: {question_intent}
        Perform the necessary reasoning steps to arrive at the answer. This may involve arithmetic calculations,
        counting occurrences, comparing values, or extracting specific spans. Ensure the reasoning is clear and logical.
        """
        reasoning_output = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the reasoning output
        refinement_instruction = f"""
        Critique the reasoning output: {reasoning_output}
        Identify any errors or ambiguities and refine it to ensure accuracy and alignment with the question intent.
        """
        refined_output = await self.revise(instruction=refinement_instruction, context=reasoning_output)

        # Step 5: Finalize the answer
        summarization_instruction = f"""
        Condense the refined reasoning output: {refined_output} into a concise final answer.
        Ensure the answer directly addresses the question and is presented in the required format.
        """
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_output)

        return final_answer