# Workflow ID: drop_24_0
# Benchmark: drop
# Data Indices: [654, 12]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant numerical values, entities, and relationships
        extraction = await self.generate(
            instruction="Identify and extract all numerical values, entities, and their relationships from the passage and question. "
                        "Focus on information that could be relevant to answering the question. "
                        "Format the output as a structured list.",
            context=self.problem_text
        )

        # Step 2: Analyze the question to determine its intent (e.g., arithmetic, counting, comparison, span extraction)
        question_intent = await self.generate(
            instruction=f"Analyze the question and classify its type into one of the following categories: "
                        f"arithmetic (e.g., addition, subtraction), counting, comparison, or span extraction. "
                        f"Provide reasoning for your classification. Extracted information: {extraction}",
            context=self.problem_text
        )

        # Step 3: Perform reasoning based on the identified intent
        if "arithmetic" in question_intent.lower():
            # Perform arithmetic operations
            calculation = await self.generate(
                instruction=f"Based on the extracted information: {extraction}, "
                            f"perform the required arithmetic operation to answer the question. "
                            f"Show step-by-step reasoning and provide the final result.",
                context=self.problem_text
            )
            result = calculation
        elif "counting" in question_intent.lower():
            # Count occurrences or entities
            count_result = await self.generate(
                instruction=f"Based on the extracted information: {extraction}, "
                            f"count the number of relevant occurrences or entities as specified in the question. "
                            f"Provide a clear breakdown of the count.",
                context=self.problem_text
            )
            result = count_result
        elif "comparison" in question_intent.lower():
            # Compare values or entities
            comparison = await self.generate(
                instruction=f"Based on the extracted information: {extraction}, "
                            f"compare the relevant values or entities as specified in the question. "
                            f"Provide a clear conclusion.",
                context=self.problem_text
            )
            result = comparison
        elif "span extraction" in question_intent.lower():
            # Extract relevant spans or phrases
            candidates = await asyncio.gather(
                self.generate(
                    instruction=f"Extract potential answer spans from the passage that match the question. "
                                f"Focus on spans that directly answer the question. Extracted information: {extraction}",
                    context=self.problem_text
                ),
                self.generate(
                    instruction=f"Extract alternative answer spans from the passage that could also answer the question. "
                                f"Consider synonyms or paraphrases. Extracted information: {extraction}",
                    context=self.problem_text
                )
            )
            result = await self.ensemble(
                instruction="Select the most appropriate answer span from the provided candidates. "
                            "Ensure the selected span directly answers the question.",
                contexts=candidates
            )
        else:
            # Default fallback
            result = await self.generate(
                instruction=f"Based on the extracted information: {extraction}, "
                            f"provide the best possible answer to the question.",
                context=self.problem_text
            )

        # Step 4: Refine and validate the result
        refined_result = await self.revise(
            instruction=f"Critique and refine the following result for accuracy and clarity: {result}. "
                        f"Ensure the final output aligns with the question's requirements.",
            context=self.problem_text
        )

        return refined_result