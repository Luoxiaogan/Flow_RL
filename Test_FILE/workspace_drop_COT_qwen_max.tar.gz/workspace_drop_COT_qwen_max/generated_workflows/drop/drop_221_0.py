# Workflow ID: drop_221_0
# Benchmark: drop
# Data Indices: [275, 160]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract relevant entities, numerical values, and relationships
        extraction_task = await self.generate(
            instruction="Thoroughly analyze the passage and question. "
                        "Extract all entities, numerical values, and their relationships. "
                        "Identify the type of question (comparison, counting, span extraction, etc.) "
                        "and any implicit or explicit constraints.",
            context=self.problem_text
        )

        # Step 2: Associate entities with numerical values
        association_task = await self.generate(
            instruction=f"Based on the extracted information:\n{extraction_task}\n"
                        "Associate each numerical value with its corresponding entity. "
                        "Ensure that all numbers are correctly linked to their context.",
            context=self.problem_text
        )

        # Step 3: Perform reasoning or span extraction
        reasoning_task = await self.generate(
            instruction=f"Given the associated entities and values:\n{association_task}\n"
                        "Perform the required reasoning or span extraction based on the question. "
                        "If the question involves a comparison, clearly state which entity satisfies the condition. "
                        "If it requires a span extraction, provide the exact text span from the passage.",
            context=self.problem_text
        )

        # Step 4: Validate and refine intermediate results
        refinement_task = await self.revise(
            instruction=f"Review the following reasoning step:\n{reasoning_task}\n"
                        "Check for accuracy, coherence, and alignment with the original passage. "
                        "Refine any ambiguous or incorrect parts.",
            context=self.problem_text
        )

        # Step 5: Synthesize final answer
        final_answer = await self.ensemble(
            instruction="Evaluate the refined reasoning step and synthesize the final answer. "
                        "Ensure the response directly addresses the question and is supported by the passage.",
            contexts=[refinement_task, self.problem_text]
        )

        return final_answer