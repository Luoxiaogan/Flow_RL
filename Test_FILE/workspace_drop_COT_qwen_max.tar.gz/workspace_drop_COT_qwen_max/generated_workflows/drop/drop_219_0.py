# Workflow ID: drop_219_0
# Benchmark: drop
# Data Indices: [716, 741]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Initial Extraction
        extraction_instruction = """
        Carefully analyze the provided passage and question. Extract ALL relevant information, including:
        - Numerical values and their associated entities or contexts
        - Key entities, events, and relationships
        - Any implicit or explicit clues that might help answer the question
        Format your output as a structured summary, clearly labeling each piece of information.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Identify Question Intent
        intent_instruction = f"""
        Based on the extracted information: {extracted_info}
        Analyze the question to determine the type of reasoning required. Classify it into one of the following categories:
        - Arithmetic Operations (e.g., addition, subtraction, multiplication, division)
        - Counting (e.g., how many times, how many different)
        - Comparison (e.g., greater than, less than, earliest, latest)
        - Selection (e.g., which team, who did)
        - Span Extraction (e.g., what was the name, who scored)
        Provide a clear classification and justification for your choice.
        """
        question_intent = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Execute Reasoning Based on Intent
        reasoning_instruction_template = f"""
        Given the extracted information: {extracted_info}
        And the identified question intent: {question_intent}
        Perform the necessary reasoning steps to arrive at the answer. Follow these guidelines:
        - For Arithmetic Operations: Perform the required calculations step-by-step.
        - For Counting: Count the occurrences or entities explicitly and implicitly mentioned.
        - For Comparison: Compare the values or spans as specified in the question.
        - For Selection: Identify and select the correct entity, event, or span.
        - For Span Extraction: Extract the exact text span that answers the question.
        Ensure your reasoning is thorough and includes all relevant steps.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction_template, context=self.problem_text)

        # Step 4: Refine Intermediate Results
        refinement_instruction = f"""
        Review the reasoning result: {reasoning_result}
        Identify any errors, ambiguities, or areas for improvement. Refine the result to ensure accuracy and completeness.
        """
        refined_result = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Final Synthesis (Optional Parallel Paths)
        # Optional: Generate alternative reasoning paths for complex questions
        alternative_reasoning_instruction = f"""
        Using a different approach, solve the problem again based on the extracted information: {extracted_info}
        Ensure your method complements the primary reasoning path.
        """
        alternative_result = await self.generate(instruction=alternative_reasoning_instruction, context=self.problem_text)

        # Use Ensemble to select or synthesize the best answer
        ensemble_instruction = f"""
        Evaluate the two reasoning paths:
        - Primary Result: {refined_result}
        - Alternative Result: {alternative_result}
        Select the most accurate and complete answer, or synthesize a new one if necessary.
        """
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[refined_result, alternative_result])

        return final_answer