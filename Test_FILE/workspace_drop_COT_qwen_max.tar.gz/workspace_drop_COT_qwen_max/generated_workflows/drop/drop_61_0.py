# Workflow ID: drop_61_0
# Benchmark: drop
# Data Indices: [536, 282]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio
        
        # Step 1: Extract all relevant entities, numbers, and relationships
        extraction_instruction = (
            "Extract all entities, numerical values, and their relationships from the passage and question. "
            "Focus on identifying key events, participants, and any quantitative data. Format the output as a list of findings."
        )
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)
        
        # Step 2: Analyze the question to determine its intent
        question_analysis_instruction = (
            "Analyze the question to determine its intent. Classify the question type into one of the following categories: "
            "arithmetic operation, counting, comparison, span extraction, or other. Provide reasoning for the classification."
        )
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)
        
        # Step 3: Execute reasoning steps based on question type
        reasoning_instruction_template = (
            "Given the extracted information: {extraction}, and the question analysis: {question_analysis}, "
            "perform the necessary reasoning steps to answer the question. Follow these guidelines:\n"
            "- For arithmetic operations, perform the required calculations.\n"
            "- For counting, tally the occurrences of the specified entity or event.\n"
            "- For comparisons, evaluate the options and select the correct one.\n"
            "- For span extraction, identify the exact text span that answers the question.\n"
            "Provide a detailed explanation of your reasoning process."
        )
        reasoning_instruction = reasoning_instruction_template.format(
            extraction=extraction, question_analysis=question_analysis
        )
        reasoning = await self.generate(instruction=reasoning_instruction, context=self.problem_text)
        
        # Step 4: Validate and refine intermediate results
        refinement_instruction = (
            "Review the reasoning process and results. Identify any errors or ambiguities and refine the output. "
            "Ensure the final result aligns with the question intent and is supported by the passage."
        )
        refined_reasoning = await self.revise(instruction=refinement_instruction, context=reasoning)
        
        # Step 5: Synthesize the final answer
        synthesis_instruction = (
            "Condense the reasoning process into a concise answer. Ensure the output is clear, accurate, and matches the expected answer type."
        )
        final_answer = await self.summarize(instruction=synthesis_instruction, context=refined_reasoning)
        
        return final_answer