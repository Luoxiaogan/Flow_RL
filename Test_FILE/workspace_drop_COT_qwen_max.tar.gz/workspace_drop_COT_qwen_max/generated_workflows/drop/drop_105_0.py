# Workflow ID: drop_105_0
# Benchmark: drop
# Data Indices: [118, 420]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information from the passage
        extraction_instruction = (
            "Extract all entities, numerical values, and their relationships from the passage. "
            "Include explicit and implicit information. Format the output as a structured list."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Interpret the question type and requirements
        question_instruction = (
            "Analyze the question to determine its type (e.g., arithmetic, comparison, span extraction). "
            "Identify what is being asked and the specific reasoning required. "
            "Output the question type and reasoning strategy."
        )
        question_analysis = await self.generate(instruction=question_instruction, context=self.problem_text)

        # Step 3: Execute parallel reasoning paths based on question type
        arithmetic_instruction = (
            f"Based on the extracted information: {extracted_info}, perform any required arithmetic operations. "
            "Ensure all calculations are accurate and relevant to the question."
        )
        comparison_instruction = (
            f"Based on the extracted information: {extracted_info}, compare entities or values as needed. "
            "Identify the correct answer based on the comparison."
        )
        span_extraction_instruction = (
            f"Based on the extracted information: {extracted_info}, identify the exact text span that answers the question. "
            "Ensure the span is precise and directly addresses the question."
        )

        # Execute reasoning paths in parallel
        results = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text),
            self.generate(instruction=span_extraction_instruction, context=self.problem_text)
        )

        # Step 4: Validate and refine outputs
        refinement_instruction = (
            "Critique and refine the provided output to ensure accuracy and alignment with the question intent. "
            "Correct any errors or ambiguities."
        )
        refined_results = await asyncio.gather(
            self.revise(instruction=refinement_instruction, context=results[0]),
            self.revise(instruction=refinement_instruction, context=results[1]),
            self.revise(instruction=refinement_instruction, context=results[2])
        )

        # Step 5: Select the best answer using Ensemble
        ensemble_instruction = (
            "Evaluate the provided options and select the best answer. "
            "Consider accuracy, relevance, and alignment with the question intent."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=refined_results)

        return final_answer