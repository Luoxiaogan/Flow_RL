# Workflow ID: drop_129_0
# Benchmark: drop
# Data Indices: [542, 406]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information from the passage
        extraction_instruction = """
        Extract ALL numerical values, entities, and relationships from the passage. 
        Associate each number with its corresponding entity or event explicitly. 
        Format your output as a structured list or table for clarity.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Understand the question and determine what is being asked
        question_understanding_instruction = f"""
        Analyze the question and determine its intent. Possible intents include:
        - Arithmetic operations (addition, subtraction, etc.)
        - Counting occurrences of specific entities or events
        - Comparisons between entities or events
        - Selection of specific spans or entities
        Based on the extracted information: {extracted_info}, identify the specific data needed to answer the question.
        """
        question_analysis = await self.generate(instruction=question_understanding_instruction, context=self.problem_text)

        # Step 3: Perform reasoning and calculations
        reasoning_instruction = f"""
        Using the extracted information: {extracted_info} and the question analysis: {question_analysis}, 
        perform the necessary reasoning steps to answer the question. Follow these guidelines:
        - For arithmetic operations, compute the result explicitly.
        - For counting, ensure all relevant instances are included.
        - For comparisons, evaluate which entity satisfies the condition.
        - For selections, extract the exact span or entity requested.
        Provide a clear and concise final answer.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the reasoning result
        refinement_instruction = f"""
        Critique the reasoning result: {reasoning_result}. Ensure it aligns with the question intent and is consistent with the passage. 
        Correct any errors or ambiguities in the reasoning process.
        """
        refined_result = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Ensemble to synthesize or select the best result
        ensemble_instruction = f"""
        Evaluate the refined result: {refined_result} against the original question and passage. 
        If there are multiple interpretations or reasoning paths, select the most coherent, relevant, and accurate answer.
        """
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[refined_result, self.problem_text])

        return final_answer