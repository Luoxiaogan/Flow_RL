# Workflow ID: drop_69_0
# Benchmark: drop
# Data Indices: [326, 701]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (numbers, entities, relationships)
        extract_instruction = """
        Extract ALL numerical values, entities, and their relationships from the passage. 
        Ensure you capture:
        - Numbers and their associated entities (e.g., "100 yards" -> "kickoff return")
        - Entities and their attributes (e.g., "Derek Anderson" -> "QB")
        - Relationships between entities (e.g., "completed a pass to")
        Format the output as a structured list for easy reference.
        """
        extract_context = self.problem_text
        extracted_info = await self.generate(instruction=extract_instruction, context=extract_context)

        # Step 2: Analyze the question intent
        question_intent_instruction = """
        Analyze the question to determine its intent. Specifically:
        - Identify if the question requires arithmetic (e.g., sum, difference), counting, comparison, or selection.
        - Determine the specific entities or values involved in the question.
        - Provide a clear explanation of what the question is asking for.
        """
        question_intent_context = self.problem_text
        question_intent = await self.generate(instruction=question_intent_instruction, context=question_intent_context)

        # Step 3: Perform reasoning based on the question intent
        reasoning_instruction = f"""
        Using the extracted information: {extracted_info}
        And the question intent: {question_intent}
        Perform the required reasoning to answer the question. Follow these steps:
        - If the question involves arithmetic, compute the result using the relevant numbers.
        - If it involves counting, count the relevant occurrences.
        - If it involves comparison, compare the relevant entities or values.
        - Ensure the reasoning process is clear and justified.
        """
        reasoning_context = self.problem_text
        reasoning_output = await self.generate(instruction=reasoning_instruction, context=reasoning_context)

        # Step 4: Validate and refine the reasoning output
        refine_instruction = """
        Critique and refine the reasoning output to ensure accuracy and alignment with the question requirements. 
        Specifically:
        - Check for calculation errors or logical inconsistencies.
        - Ensure the reasoning process is complete and justified.
        - Suggest improvements if necessary.
        """
        refined_output = await self.revise(instruction=refine_instruction, context=reasoning_output)

        # Step 5: Summarize the final answer
        summarize_instruction = """
        Condense the refined reasoning output into a concise answer that directly addresses the question. 
        Ensure the answer is clear, accurate, and formatted appropriately.
        """
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_output)

        return final_answer