# Workflow ID: drop_198_0
# Benchmark: drop
# Data Indices: [157, 266]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all entities and numerical values
        extraction_instruction = (
            "Extract all named entities (e.g., people, teams, players) and numerical values "
            "(e.g., scores, distances, counts) from the passage. Ensure no information is missed. "
            "Format the output as a structured list where each item includes the entity name, "
            "its description, and any associated numerical values."
        )
        entities_and_numbers = await self.generate(
            instruction=extraction_instruction,
            context=self.problem_text
        )

        # Step 2: Analyze the question to determine reasoning type
        question_analysis_instruction = (
            f"Given the extracted entities and numbers: {entities_and_numbers}, "
            "analyze the question to determine what type of reasoning is required. "
            "Identify whether the question involves arithmetic operations (e.g., sum, difference), "
            "comparison (e.g., greater than, less than), counting, span extraction, or other types of reasoning. "
            "Provide a clear breakdown of the reasoning steps needed to answer the question."
        )
        reasoning_plan = await self.generate(
            instruction=question_analysis_instruction,
            context=self.problem_text
        )

        # Step 3: Execute reasoning steps
        reasoning_execution_instruction = (
            f"Based on the reasoning plan: {reasoning_plan}, execute the necessary steps to derive the answer. "
            "If arithmetic is required, perform the calculations using the extracted numbers. "
            "If comparison is required, compare the relevant entities' associated values. "
            "If span extraction is required, identify the correct entity or phrase from the passage. "
            "Ensure the output is precise and directly answers the question."
        )
        raw_answer = await self.generate(
            instruction=reasoning_execution_instruction,
            context=self.problem_text
        )

        # Step 4: Refine the answer for clarity and accuracy
        refinement_instruction = (
            f"Refine the following answer: {raw_answer}. Ensure it is clear, concise, and formatted appropriately. "
            "Resolve any ambiguities and verify that the answer aligns with the question's requirements."
        )
        refined_answer = await self.revise(
            instruction=refinement_instruction,
            context=self.problem_text
        )

        # Step 5: Handle ambiguity resolution if needed
        # If multiple interpretations exist, use Ensemble to decide the best answer
        ensemble_instruction = (
            "Evaluate the following candidate answers and select the best one. "
            "Consider the context of the passage and the question's intent. "
            "If necessary, synthesize a new answer that combines the best elements of the candidates."
        )
        final_answer = await self.ensemble(
            instruction=ensemble_instruction,
            contexts=[raw_answer, refined_answer]
        )

        return final_answer