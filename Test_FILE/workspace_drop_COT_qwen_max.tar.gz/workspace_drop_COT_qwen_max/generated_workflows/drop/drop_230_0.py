# Workflow ID: drop_230_0
# Benchmark: drop
# Data Indices: [87, 328]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract relevant information from the passage
        extraction_instruction = """
        Extract all numerical values, entities, and their relationships from the passage.
        Include:
        - Numbers and their associated context (e.g., '400,000 people died')
        - Named entities (e.g., 'William Petty', 'Cromwellian')
        - Relationships between entities and numbers (e.g., 'two-thirds of deaths were civilian')
        Organize the extracted information into a structured format for further analysis.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine reasoning type
        question_analysis_instruction = f"""
        Analyze the question to determine the type of reasoning required.
        Based on the extracted information: {extracted_info}
        Identify:
        - Whether the question involves arithmetic (e.g., sum, difference, comparison)
        - Whether it requires span extraction (e.g., finding a specific entity or phrase)
        - Any constraints or specific requirements (e.g., 'highest possible figure', 'players with field goals of 40+ yards')
        Provide a detailed breakdown of the question intent.
        """
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on question intent
        reasoning_instruction = f"""
        Using the extracted information: {extracted_info}
        And the question analysis: {question_analysis}
        Perform the necessary reasoning steps to answer the question.
        Follow these guidelines:
        - For arithmetic questions, perform the required calculations (e.g., sum, difference, maximum value).
        - For span extraction, identify the exact text spans that match the query.
        - For comparison questions, compare entities or values as specified.
        Ensure the reasoning process is clear and well-documented.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Optional: Refine the reasoning result if needed
        refinement_instruction = """
        Review the reasoning result and refine it if necessary.
        Ensure the answer is accurate, concise, and directly addresses the question.
        """
        refined_result = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 4: Synthesize the final answer
        synthesis_instruction = f"""
        Condense the refined reasoning result: {refined_result}
        Into a concise and accurate final answer.
        Ensure the answer is clear and directly addresses the question.
        """
        final_answer = await self.summarize(instruction=synthesis_instruction, context=refined_result)

        return final_answer