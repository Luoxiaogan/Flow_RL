# Workflow ID: drop_348_0
# Benchmark: drop
# Data Indices: [5, 253]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information from the passage
        extraction_instruction = (
            "Extract all entities, numbers, dates, and key phrases from the passage that could potentially "
            "answer the question. Ensure that no critical information is missed. Format the output as a bullet "
            "list for clarity."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine the required reasoning type
        question_analysis_instruction = (
            f"Given the extracted information:\n{extracted_info}\n"
            "Analyze the question to determine the type of reasoning required. Identify whether the question "
            "involves arithmetic operations (e.g., addition, subtraction), counting, comparison, selection, or "
            "span extraction. Provide a detailed explanation of the reasoning type and how to proceed."
        )
        reasoning_plan = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform the necessary reasoning or calculation
        reasoning_instruction = (
            f"Based on the reasoning plan:\n{reasoning_plan}\n"
            "Perform the required reasoning or calculation using the extracted information. If the question "
            "involves arithmetic, extract the relevant numbers and perform the operation. If it involves "
            "comparison, identify the entities being compared and determine the correct answer. If it involves "
            "span extraction, identify the exact text span that answers the question. Provide a clear and "
            "detailed explanation of the steps taken."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the answer
        refinement_instruction = (
            f"Review the reasoning result:\n{reasoning_result}\n"
            "Critique and refine the answer to ensure it aligns with the question's requirements and the "
            "passage's context. Correct any errors or ambiguities, and provide a polished version of the answer."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Finalize the output
        summarization_instruction = (
            f"Condense the refined answer:\n{refined_answer}\n"
            "into a concise, well-structured format suitable for final output. Ensure that the answer is clear, "
            "accurate, and directly addresses the question."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_answer)

        return final_answer