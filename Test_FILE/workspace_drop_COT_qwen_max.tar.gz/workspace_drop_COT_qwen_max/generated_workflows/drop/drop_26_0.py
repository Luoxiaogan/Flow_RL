# Workflow ID: drop_26_0
# Benchmark: drop
# Data Indices: [533, 400]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (entities, numbers, relationships)
        extraction_instruction = """
        Extract all relevant entities, numerical values, and their relationships from the passage and question.
        Identify who did what, when, and where, along with any associated numbers or measurements.
        Organize the information in a structured format for further analysis.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Identify the question intent
        intent_instruction = f"""
        Analyze the question and classify its type based on the following patterns:
        - Arithmetic operations: Look for keywords like "total," "combined," "more," "difference."
        - Counting: Look for phrases like "how many times," "how many different."
        - Comparison: Look for words like "greater," "longer," "more."
        - Selection: Look for questions about specific entities or events.
        - Span extraction: Identify questions asking for names, phrases, or descriptions.
        Use the extracted information: {extracted_info}.
        """
        question_intent = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or calculation
        reasoning_instruction = f"""
        Based on the question intent ({question_intent}) and the extracted information ({extracted_info}),
        perform the required reasoning or calculation. Follow these steps:
        - For arithmetic operations, sum, subtract, or compare the relevant numbers.
        - For counting, tally the occurrences of the specified entity or event.
        - For comparisons, determine which entity or value satisfies the condition.
        - For span extraction, identify the correct entity or phrase from the passage.
        Ensure all calculations and selections are logically consistent with the passage.
        """
        raw_answer = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the answer
        refinement_instruction = f"""
        Critique and refine the following answer: {raw_answer}.
        Check for logical consistency, correct entity-number associations, and adherence to the question intent.
        Correct any errors or ambiguities in the reasoning process.
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=raw_answer)

        # Step 5: Finalize the answer (optional ensemble if multiple interpretations exist)
        final_instruction = f"""
        Evaluate the refined answer ({refined_answer}) and ensure it is the best possible solution.
        If there are multiple interpretations or conflicting results, synthesize them into a single coherent answer.
        """
        final_answer = await self.ensemble(instruction=final_instruction, contexts=[refined_answer])

        return final_answer