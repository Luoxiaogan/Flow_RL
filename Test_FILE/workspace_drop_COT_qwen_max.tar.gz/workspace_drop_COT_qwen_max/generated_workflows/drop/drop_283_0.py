# Workflow ID: drop_283_0
# Benchmark: drop
# Data Indices: [201, 146]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all relevant entities, numbers, and relationships
        extraction_instruction = (
            "Carefully analyze the passage and question. "
            "Extract all relevant entities, numerical values, dates, and their relationships. "
            "Include any implicit or inferred information that might be necessary to answer the question."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Perform reasoning based on the extracted information
        reasoning_instruction = (
            f"Using the following extracted information: {extracted_info}\n"
            "Determine the intent of the question and perform the necessary reasoning steps. "
            "This may involve arithmetic operations, comparisons, counting, or identifying text spans. "
            "Ensure all calculations and inferences are explicitly stated."
        )
        reasoning_output = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Refine and validate the reasoning output
        refinement_instruction = (
            "Critique the following reasoning output for accuracy and completeness:\n"
            f"{reasoning_output}\n"
            "Identify and correct any errors, ambiguities, or missing details. "
            "Ensure the final reasoning aligns with the question intent."
        )
        refined_output = await self.revise(instruction=refinement_instruction, context=reasoning_output)

        # Step 4: Summarize the refined output into a concise answer
        summarization_instruction = (
            "Condense the following refined reasoning into a concise answer:\n"
            f"{refined_output}\n"
            "Ensure the answer is clear, accurate, and matches the expected format (number, date, text span, etc.)."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_output)

        # Return the final answer
        return final_answer