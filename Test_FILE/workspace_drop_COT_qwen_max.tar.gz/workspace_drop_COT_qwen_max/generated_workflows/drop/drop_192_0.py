# Workflow ID: drop_192_0
# Benchmark: drop
# Data Indices: [24, 770]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract all relevant information (numerical values, entities, relationships)
        extraction_instruction = """
        Carefully analyze the passage and question to extract all relevant numerical values, entities, and relationships.
        Include all numbers, their associated entities, and any contextual information that might affect their interpretation.
        Ensure no information is missed, as it may be critical for answering the question.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Classify the question and outline reasoning steps
        question_analysis_instruction = f"""
        Analyze the question to determine its type (e.g., arithmetic, counting, comparison, selection, span extraction).
        Based on the extracted information: {extracted_info}, outline the reasoning steps required to answer the question.
        Specify whether the answer involves addition, subtraction, counting, comparison, or extracting a text span.
        """
        reasoning_plan = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform reasoning and calculations (parallel execution for independent paths)
        reasoning_instruction = f"""
        Using the reasoning plan: {reasoning_plan} and the extracted information: {extracted_info},
        perform the necessary calculations or reasoning steps to answer the question.
        If there are multiple interpretations or paths, generate all possible answers.
        """
        reasoning_results = await asyncio.gather(
            self.generate(instruction=reasoning_instruction, context=self.problem_text),
            self.generate(instruction=reasoning_instruction, context=self.problem_text)
        )

        # Step 4: Resolve ambiguities or synthesize results
        ensemble_instruction = f"""
        Evaluate the reasoning results: {reasoning_results}.
        If there are multiple interpretations, decide which one is most consistent with the passage and question.
        Synthesize the results into a single coherent answer if necessary.
        """
        synthesized_result = await self.ensemble(instruction=ensemble_instruction, contexts=reasoning_results)

        # Step 5: Validate and refine the result
        refinement_instruction = f"""
        Review the synthesized result: {synthesized_result} against the extracted information: {extracted_info}.
        Identify and correct any inconsistencies or errors in the reasoning process.
        Ensure the final answer is accurate and well-supported by the passage.
        """
        refined_result = await self.revise(instruction=refinement_instruction, context=synthesized_result)

        # Step 6: Summarize the final answer
        summarization_instruction = f"""
        Condense the refined result: {refined_result} into a concise and clear final answer.
        Ensure the answer directly addresses the question and is easy to understand.
        """
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_result)

        return final_answer