# Workflow ID: drop_353_0
# Benchmark: drop
# Data Indices: [221, 624]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information from the passage
        extraction_instruction = (
            "Extract all entities, numerical values, events, and their relationships from the passage. "
            "Ensure that every piece of information that could potentially answer the question is included. "
            "Format the output as a structured list for clarity."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Understand the question and formulate a reasoning strategy
        strategy_instruction = (
            f"Given the following extracted information:\n{extracted_info}\n"
            "Analyze the question and determine the type of reasoning required to answer it. "
            "Provide a detailed plan that outlines the steps needed to arrive at the correct answer. "
            "Include whether the task involves arithmetic, counting, comparison, selection, or span extraction."
        )
        reasoning_strategy = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Execute parallel reasoning paths based on the strategy
        arithmetic_instruction = (
            f"Using the extracted information:\n{extracted_info}\n"
            "Perform any arithmetic operations required by the question. "
            "Identify the relevant numbers, associate them with their entities, and compute the result."
        )
        counting_instruction = (
            f"Using the extracted information:\n{extracted_info}\n"
            "Count the occurrences of specific events or entities mentioned in the question. "
            "Ensure that all relevant instances are included in the count."
        )
        comparison_instruction = (
            f"Using the extracted information:\n{extracted_info}\n"
            "Compare the values or entities mentioned in the question. "
            "Determine which is greater, lesser, or if they are equal."
        )
        span_extraction_instruction = (
            f"Using the extracted information:\n{extracted_info}\n"
            "Identify and extract the exact text span that answers the question. "
            "Ensure that the span is complete and accurate."
        )

        # Parallel execution of reasoning paths
        reasoning_results = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=counting_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text),
            self.generate(instruction=span_extraction_instruction, context=self.problem_text)
        )

        # Step 4: Synthesize the results using the Ensemble operator
        ensemble_instruction = (
            "Given the following candidate solutions:\n"
            f"Arithmetic Result: {reasoning_results[0]}\n"
            f"Counting Result: {reasoning_results[1]}\n"
            f"Comparison Result: {reasoning_results[2]}\n"
            f"Span Extraction Result: {reasoning_results[3]}\n"
            "Evaluate each solution, determine which one best answers the question, and synthesize the final answer. "
            "If multiple solutions are valid, merge them appropriately."
        )
        synthesized_answer = await self.ensemble(instruction=ensemble_instruction, contexts=reasoning_results)

        # Step 5: Refine the synthesized answer for accuracy and completeness
        refinement_instruction = (
            f"Review the following synthesized answer:\n{synthesized_answer}\n"
            "Ensure that it is accurate, complete, and directly addresses the question. "
            "Make any necessary corrections or improvements."
        )
        final_answer = await self.revise(instruction=refinement_instruction, context=synthesized_answer)

        return final_answer