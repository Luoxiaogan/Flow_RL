# Workflow ID: drop_227_0
# Benchmark: drop
# Data Indices: [679, 172]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Initial Understanding of the Problem
        initial_understanding = await self.generate(
            instruction="Analyze the passage and question thoroughly. "
                        "Identify key entities, numerical values, temporal references, and relationships. "
                        "Provide a structured summary of the problem context.",
            context=self.problem_text
        )

        # Step 2: Entity and Value Extraction
        extraction = await self.generate(
            instruction="Extract all relevant entities (e.g., groups, years, items) and their associated numerical values or attributes. "
                        "Focus on details that are directly or indirectly related to the question.",
            context=initial_understanding
        )

        # Step 3: Reasoning and Calculation
        reasoning_instruction = f"Based on the extracted information: {extraction}, "
        reasoning_instruction += "determine the type of reasoning required (arithmetic, comparison, counting, etc.). "
        reasoning_instruction += "Perform the necessary calculations or logical deductions to arrive at potential answers."

        arithmetic_reasoning = self.generate(
            instruction=reasoning_instruction + " Focus on arithmetic operations such as addition, subtraction, or comparisons.",
            context=self.problem_text
        )
        span_extraction = self.generate(
            instruction=reasoning_instruction + " Focus on extracting specific text spans or entities.",
            context=self.problem_text
        )

        reasoning_results = await asyncio.gather(arithmetic_reasoning, span_extraction)

        # Step 4: Validation and Refinement
        refined_results = []
        for result in reasoning_results:
            refined_result = await self.revise(
                instruction="Validate the intermediate result by cross-referencing it with the original passage and question. "
                            "Ensure accuracy and resolve any ambiguities.",
                context=result
            )
            refined_results.append(refined_result)

        # Step 5: Final Answer Selection
        final_answer = await self.ensemble(
            instruction="Evaluate the refined results and select the most accurate and relevant answer. "
                        "Ensure the final output adheres to the expected answer format (number, date, text span, etc.).",
            contexts=refined_results
        )

        return final_answer