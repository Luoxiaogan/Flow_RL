# Workflow ID: drop_119_0
# Benchmark: drop
# Data Indices: [69, 226]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract relevant information from the passage and question
        extraction_instruction = (
            "Thoroughly analyze the provided passage and question. "
            "Identify all relevant entities, numerical values, and their relationships. "
            "Clearly indicate what the question is asking for (e.g., sum, count, comparison)."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Perform reasoning or calculation based on the extracted information
        reasoning_instruction = (
            f"Using the following extracted information: {extracted_info}\n"
            "Determine the appropriate operation to answer the question (e.g., arithmetic, counting, comparison). "
            "Perform the necessary calculations or reasoning step by step. "
            "Ensure all steps are clearly explained and justified."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Validate and refine the reasoning result
        refinement_instruction = (
            "Critically evaluate the following reasoning result for accuracy and completeness. "
            "Identify any errors or ambiguities and suggest improvements. "
            "Ensure the final result aligns with the problem context and question intent."
        )
        refined_result = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 4: Summarize the refined result into a concise final answer
        summarization_instruction = (
            "Condense the following refined result into a clear and concise final answer. "
            "Ensure the answer directly addresses the question and is easy to understand."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_result)

        return final_answer