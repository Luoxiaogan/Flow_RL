# Workflow ID: drop_251_0
# Benchmark: drop
# Data Indices: [97, 601]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information
        extraction_instruction = (
            "Identify all entities, numerical values, and their relationships mentioned in the passage that are relevant to the question. "
            "Ensure that each numerical value is correctly associated with its corresponding entity. "
            "Provide the extracted information in a structured format, such as a list or table."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Refine extracted information
        refinement_instruction = (
            f"Given the following extracted information: {extracted_info}\n"
            "Carefully review and refine the associations between entities and numerical values. "
            "Resolve any ambiguities or partial references. "
            "If there are multiple similar entities, ensure that each is correctly differentiated."
        )
        refined_info = await self.revise(instruction=refinement_instruction, context=extracted_info)

        # Step 3: Perform reasoning based on question type
        reasoning_instruction = (
            f"Given the refined information: {refined_info}\n"
            "Determine the type of reasoning required to answer the question (e.g., arithmetic, comparison, span extraction). "
            "Perform the necessary calculations, comparisons, or selections to derive the answer. "
            "If the question involves arithmetic, show the step-by-step computation. "
            "If the question involves span extraction, provide the exact text span from the passage."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=refined_info)

        # Step 4: Ensemble multiple interpretations (if needed)
        ensemble_instruction = (
            f"Evaluate the following reasoning result: {reasoning_result}\n"
            "If there are multiple plausible interpretations or conflicting evidence, resolve the ambiguity by selecting the most appropriate answer. "
            "Provide a justification for your choice."
        )
        ensemble_result = await self.ensemble(instruction=ensemble_instruction, contexts=[reasoning_result, refined_info])

        # Step 5: Summarize the final answer
        summarization_instruction = (
            f"Condense the following reasoning and ensemble results into a concise final answer: {ensemble_result}\n"
            "Ensure that the final answer directly addresses the question and is presented in a clear, unambiguous format."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=ensemble_result)

        return final_answer