# Workflow ID: drop_150_0
# Benchmark: drop
# Data Indices: [301, 343]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information
        extraction_instruction = """
        Extract all relevant entities, numerical values, and relationships from the passage and question.
        Include:
        - All numerical values mentioned in the passage and question.
        - Entities associated with these numerical values (e.g., players, teams, events).
        - Relationships between entities and numbers (e.g., "Rudi Johnson scored on a 7-yard TD run").
        Ensure nothing is missed and organize the extracted information clearly.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze question intent
        intent_instruction = f"""
        Analyze the question to determine the type of reasoning required. Use the following guidelines:
        - Arithmetic: Look for keywords like "total," "combined," "difference," "more than."
        - Counting: Look for keywords like "how many times," "how many different."
        - Comparison: Look for keywords like "greater," "longer," "more."
        - Span Extraction: Look for questions asking for specific entities, phrases, or events.
        Based on the extracted information: {extracted_info}, determine the reasoning type and provide clear guidance for the next step.
        """
        question_intent = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or calculation
        reasoning_instruction = f"""
        Perform the necessary reasoning or calculation based on the question intent: {question_intent}.
        Follow these steps:
        - If arithmetic, perform the required operation (e.g., addition, subtraction).
        - If counting, count occurrences of the relevant entity or event.
        - If comparison, compare the relevant values and determine the result.
        - If span extraction, identify the exact text span that answers the question.
        Ensure the reasoning process is clear and logical.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine and validate the answer
        refinement_instruction = f"""
        Critique and refine the reasoning result: {reasoning_result}.
        Ensure the answer is accurate, complete, and directly addresses the question.
        Correct any errors or ambiguities in the reasoning process.
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Final output
        final_instruction = f"""
        Condense the refined answer: {refined_answer} into a concise final response.
        Ensure the final answer is clear, precise, and directly answers the question.
        """
        final_answer = await self.summarize(instruction=final_instruction, context=refined_answer)

        return final_answer