# Workflow ID: drop_153_0
# Benchmark: drop
# Data Indices: [541, 234]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all relevant numerical values, entities, and relationships
        extraction_instruction = """
        Extract ALL numerical values, entities, and their relationships from the passage and question. 
        Include:
        - Numbers and their associated entities (e.g., "45 yards for a touchdown").
        - Named entities (e.g., players, teams, events).
        - Relationships between entities and numbers (e.g., "Patriots scored 10 points").
        Format the output as a structured list.
        """
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question and formulate a reasoning strategy
        strategy_instruction = f"""
        Analyze the question and determine the required reasoning strategy. 
        Use the extracted information: {extraction}.
        Identify:
        - If the question requires arithmetic operations (e.g., sum, difference).
        - If it involves counting occurrences of specific entities or events.
        - If it requires comparing values or extracting a specific text span.
        Provide a clear plan for solving the problem.
        """
        strategy = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Execute parallel reasoning paths
        arithmetic_instruction = f"""
        Perform arithmetic operations (e.g., sum, difference) based on the extracted data: {extraction}.
        Follow the reasoning strategy: {strategy}.
        """
        counting_instruction = f"""
        Count occurrences of specific entities or events based on the extracted data: {extraction}.
        Follow the reasoning strategy: {strategy}.
        """
        comparison_instruction = f"""
        Compare values or spans based on the extracted data: {extraction}.
        Follow the reasoning strategy: {strategy}.
        """

        arithmetic_result, counting_result, comparison_result = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=counting_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text)
        )

        # Step 4: Ensemble decision-making
        ensemble_instruction = f"""
        Evaluate the following candidate solutions:
        - Arithmetic Result: {arithmetic_result}
        - Counting Result: {counting_result}
        - Comparison Result: {comparison_result}
        Select the most appropriate answer based on the question and extracted data: {extraction}.
        """
        final_answer = await self.ensemble(
            instruction=ensemble_instruction,
            contexts=[arithmetic_result, counting_result, comparison_result]
        )

        # Step 5: Refine the final answer
        refinement_instruction = f"""
        Refine the final answer: {final_answer}.
        Ensure it is clear, correct, and directly addresses the question.
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        return refined_answer