# Workflow ID: drop_253_0
# Benchmark: drop
# Data Indices: [780, 591]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract relevant information from the passage and question
        extraction_instruction = (
            "Thoroughly analyze the provided passage and question. "
            "Extract all numerical values, entities, temporal references, and their relationships. "
            "Ensure no relevant information is missed. Format the output clearly for further processing."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine reasoning type
        analysis_instruction = (
            f"Given the extracted information: {extracted_info}, analyze the question to determine "
            "the type of reasoning required (e.g., arithmetic, counting, comparison, span extraction). "
            "Provide a detailed breakdown of the reasoning steps needed to answer the question."
        )
        reasoning_plan = await self.generate(instruction=analysis_instruction, context=self.problem_text)

        # Step 3: Execute reasoning strategies in parallel
        arithmetic_instruction = (
            f"Based on the reasoning plan: {reasoning_plan}, perform any required arithmetic operations "
            "(e.g., addition, subtraction, multiplication). Ensure calculations are accurate and explain each step."
        )
        comparison_instruction = (
            f"Based on the reasoning plan: {reasoning_plan}, compare entities or values as needed. "
            "Clearly state which entity or value satisfies the question's criteria."
        )
        span_extraction_instruction = (
            f"Based on the reasoning plan: {reasoning_plan}, extract the specific text spans "
            "that directly answer the question. Ensure the spans are precise and complete."
        )

        # Parallel execution for independent reasoning paths
        arithmetic_result, comparison_result, span_extraction_result = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text),
            self.generate(instruction=span_extraction_instruction, context=self.problem_text)
        )

        # Step 4: Synthesize results and finalize the answer
        synthesis_instruction = (
            "Evaluate the results from the following reasoning paths: "
            f"Arithmetic: {arithmetic_result}, Comparison: {comparison_result}, Span Extraction: {span_extraction_result}. "
            "Select the most appropriate answer based on the question's requirements. "
            "Ensure the final output adheres to the expected format (number, date, text span, etc.)."
        )
        final_answer = await self.ensemble(
            instruction=synthesis_instruction,
            contexts=[arithmetic_result, comparison_result, span_extraction_result]
        )

        return final_answer