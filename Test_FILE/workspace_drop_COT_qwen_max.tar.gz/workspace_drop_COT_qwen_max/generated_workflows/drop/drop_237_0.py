# Workflow ID: drop_237_0
# Benchmark: drop
# Data Indices: [144, 105]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information from the problem text
        extraction_instruction = """
        Extract all entities, numerical values, dates, and relationships mentioned in the text.
        Include any contextual information that might affect the interpretation of numbers or entities.
        Organize the extracted information clearly by categories such as entities, numbers, and relationships.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine the reasoning type
        question_analysis_instruction = f"""
        Analyze the question to determine what type of reasoning is required.
        Consider whether the question involves arithmetic operations, counting, comparison, selection, or span extraction.
        Use the following extracted information to guide your analysis: {extracted_info}
        Provide a clear reasoning strategy based on the question type.
        """
        reasoning_strategy = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform the reasoning or calculation
        reasoning_instruction = f"""
        Based on the following reasoning strategy: {reasoning_strategy}
        And the extracted information: {extracted_info}
        Perform the necessary reasoning or calculation to answer the question.
        Ensure that all steps are clearly explained and justified.
        """
        initial_answer = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the answer
        refinement_instruction = f"""
        Critique and refine the following answer: {initial_answer}
        Check for any errors, ambiguities, or inconsistencies in the reasoning process.
        Ensure that the answer directly addresses the question and uses the correct information from the extracted data.
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=initial_answer)

        # Step 5: Summarize the final answer
        summarization_instruction = f"""
        Summarize the following refined answer into a concise form suitable for final output: {refined_answer}
        Ensure that the summary captures all essential information and is presented clearly.
        """
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_answer)

        return final_answer