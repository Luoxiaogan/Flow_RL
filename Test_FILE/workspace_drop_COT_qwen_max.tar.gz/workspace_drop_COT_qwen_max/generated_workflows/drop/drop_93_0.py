# Workflow ID: drop_93_0
# Benchmark: drop
# Data Indices: [545, 288]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant numerical values, entities, and relationships
        extraction_instruction = (
            "Thoroughly analyze the provided passage and question. Extract ALL numerical values, "
            "their associated entities, and any contextual information that might be relevant to the question. "
            "Format the output as a structured list for clarity."
        )
        extracted_data = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine the reasoning type
        question_analysis_instruction = (
            f"Given the extracted data: {extracted_data}, analyze the question to determine the type of reasoning required. "
            "Identify whether the task involves arithmetic operations, counting, comparison, span extraction, or another type of reasoning. "
            "Provide a clear explanation of the reasoning steps needed to solve the problem."
        )
        reasoning_plan = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform the reasoning or calculation
        reasoning_instruction = (
            f"Using the extracted data: {extracted_data}, and the reasoning plan: {reasoning_plan}, "
            "perform the necessary reasoning or calculations to answer the question. Ensure all steps are clearly documented."
        )
        raw_answer = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the result
        refinement_instruction = (
            f"Review the raw answer: {raw_answer}. Critique its accuracy and correctness. "
            "Refine the answer if necessary, ensuring it aligns with the extracted data and reasoning plan."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=raw_answer)

        # Step 5: Summarize the final answer
        summarization_instruction = (
            f"Condense the refined answer: {refined_answer} into a concise and clear response. "
            "Ensure the final answer directly addresses the question."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_answer)

        return final_answer