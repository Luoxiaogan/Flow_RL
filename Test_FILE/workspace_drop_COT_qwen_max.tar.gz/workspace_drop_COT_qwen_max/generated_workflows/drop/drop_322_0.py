# Workflow ID: drop_322_0
# Benchmark: drop
# Data Indices: [703, 173]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Analyze the question to determine its type and extract intent
        question_analysis_instruction = (
            "Analyze the question to determine its type (e.g., arithmetic, counting, comparison, span extraction). "
            "Identify key entities, numbers, and relationships mentioned in the question. "
            "Output the question type and any relevant keywords or constraints."
        )
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 2: Extract relevant information from the passage
        extraction_instruction = (
            f"Given the question analysis: {question_analysis}, "
            "extract all relevant numerical values, entities, and contextual clues from the passage. "
            "Ensure exhaustive extraction to avoid missing critical data points."
        )
        relevant_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or calculation based on the question type
        reasoning_instruction = (
            f"Given the question analysis: {question_analysis} and the extracted information: {relevant_info}, "
            "perform the necessary reasoning or calculation to answer the question. "
            "For arithmetic questions, calculate the result. "
            "For counting questions, tally the relevant occurrences. "
            "For comparison questions, evaluate which entity satisfies the condition. "
            "For span extraction questions, isolate the exact text span that answers the question."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the answer
        validation_instruction = (
            f"Review the reasoning result: {reasoning_result} for accuracy, completeness, and alignment with the question. "
            "Critique and refine the answer if necessary."
        )
        refined_answer = await self.revise(instruction=validation_instruction, context=reasoning_result)

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"Condense the refined answer: {refined_answer} into a concise, final response that directly addresses the question."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_answer)

        return final_answer