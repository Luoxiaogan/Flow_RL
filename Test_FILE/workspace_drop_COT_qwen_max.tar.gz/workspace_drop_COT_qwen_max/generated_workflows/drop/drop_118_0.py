# Workflow ID: drop_118_0
# Benchmark: drop
# Data Indices: [560, 321]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract key information (entities, numbers, relationships)
        extraction_instruction = """
        Extract all relevant entities, numerical values, and their relationships from the passage and the question. 
        Handle ambiguous references by resolving pronouns or partial names. 
        Identify any implicit information that may be required to answer the question. 
        Format the output as a structured list of findings.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Understand the question intent
        intent_instruction = f"""
        Analyze the question and determine its intent. Classify the question type into one of the following categories:
        - Arithmetic (addition, subtraction, etc.)
        - Counting (how many times, how many different)
        - Comparison (greater, longer, more)
        - Selection (which team won, what happened first/last)
        - Span Extraction (who did, what was the name of)
        Also, identify the specific task required (e.g., summing values, finding differences, extracting spans).
        Use the following extracted information as context: {extracted_info}.
        """
        question_intent = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or calculation
        reasoning_instruction = f"""
        Based on the extracted information and the question's intent, perform the required reasoning or calculation.
        If the task involves arithmetic operations, show the step-by-step calculation.
        If the task involves comparison, clearly state the compared entities and the result.
        If the task involves span extraction, provide the exact text span from the passage.
        Use the following context: {extracted_info} and {question_intent}.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Optional: Use ensemble for complex questions with multiple interpretations
        # Uncomment the following lines if needed:
        # alternative_results = await asyncio.gather(
        #     self.generate(instruction=f"Alternative approach 1: {reasoning_instruction}", context=self.problem_text),
        #     self.generate(instruction=f"Alternative approach 2: {reasoning_instruction}", context=self.problem_text)
        # )
        # reasoning_result = await self.ensemble(instruction="Select the most accurate and complete solution.", contexts=alternative_results)

        # Step 4: Refine and validate the answer
        refinement_instruction = f"""
        Critique and refine the following answer to ensure it is accurate, concise, and directly addresses the question.
        Highlight any potential errors or ambiguities and correct them.
        Original answer: {reasoning_result}.
        """
        final_answer = await self.revise(instruction=refinement_instruction, context=self.problem_text)

        return final_answer