# Workflow ID: drop_309_0
# Benchmark: drop
# Data Indices: [499, 180]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information from the passage
        extraction_instruction = """
        Extract ALL numerical values, entities, and their relationships from the passage. 
        Include any explicit or implicit information that could be relevant to answering the question. 
        Format your output as a structured list of key-value pairs or bullet points for clarity.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Understand the question intent
        question_intent_instruction = f"""
        Analyze the question to determine its intent. Specifically:
        - Identify whether the question requires arithmetic operations (e.g., addition, subtraction), counting, comparison, or span extraction.
        - Highlight any specific entities or values mentioned in the question.
        - Provide a clear explanation of what needs to be done to answer the question.
        Use the following extracted information as context: {extracted_info}.
        """
        question_intent = await self.generate(instruction=question_intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or calculation
        reasoning_instruction = f"""
        Based on the question intent and the extracted information, perform the necessary reasoning or calculation to answer the question.
        Ensure your reasoning process is step-by-step and clearly explained. If the question involves arithmetic, show the calculation explicitly.
        Question Intent: {question_intent}
        Extracted Information: {extracted_info}
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the answer
        refinement_instruction = f"""
        Critique and refine the following reasoning result to ensure accuracy and alignment with the question intent.
        If there are any ambiguities or errors, correct them. Provide the final polished answer.
        Reasoning Result: {reasoning_result}
        Question Intent: {question_intent}
        Extracted Information: {extracted_info}
        """
        final_answer = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        return final_answer