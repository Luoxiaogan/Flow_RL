# Workflow ID: drop_256_0
# Benchmark: drop
# Data Indices: [642, 169]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Initial Analysis - Extract key entities, numbers, and relationships
        initial_analysis = await self.generate(
            instruction="""Analyze the passage and question thoroughly. 
            Identify all entities, numerical values, dates, and their relationships. 
            Highlight any ambiguous references or implicit information. 
            Provide a structured summary of the key components required to answer the question.""",
            context=self.problem_text
        )

        # Step 2: Question Type Classification
        question_type = await self.generate(
            instruction=f"""Based on the following analysis: {initial_analysis}
            Classify the question into one of the following categories: 
            arithmetic, counting, comparison, selection, or span extraction. 
            Provide a clear justification for the classification.""",
            context=self.problem_text
        )

        # Step 3: Parallel Reasoning Paths
        arithmetic_result = await self.generate(
            instruction=f"""If the question involves arithmetic operations (e.g., addition, subtraction): 
            Extract all relevant numerical values from the passage and perform the necessary calculations. 
            Ensure proper association of numbers with their respective entities.""",
            context=initial_analysis
        )
        comparison_result = await self.generate(
            instruction=f"""If the question involves comparison: 
            Identify the entities or values being compared and determine their relationship (greater, lesser, equal). 
            Provide a clear explanation of the comparison process.""",
            context=initial_analysis
        )
        selection_result = await self.generate(
            instruction=f"""If the question involves selection: 
            Determine which entity satisfies the criteria specified in the question. 
            Justify why this entity is the correct choice.""",
            context=initial_analysis
        )
        span_extraction_result = await self.generate(
            instruction=f"""If the question involves span extraction: 
            Locate the exact text span from the passage that directly answers the question. 
            Ensure the span is concise and accurate.""",
            context=initial_analysis
        )

        # Gather results from parallel paths
        results = await asyncio.gather(
            arithmetic_result,
            comparison_result,
            selection_result,
            span_extraction_result
        )

        # Step 4: Validation and Refinement
        refined_results = []
        for result in results:
            refined = await self.revise(
                instruction=f"""Review the following reasoning: {result}
                Ensure it aligns with the question intent and passage context. 
                Correct any errors or ambiguities.""",
                context=initial_analysis
            )
            refined_results.append(refined)

        # Step 5: Final Answer Selection or Synthesis
        final_answer = await self.ensemble(
            instruction=f"""Given the following refined results: {refined_results}
            Select the most appropriate answer or synthesize a final response. 
            Ensure the answer is precise, accurate, and directly addresses the question.""",
            contexts=refined_results
        )

        return final_answer