# Workflow ID: drop_245_0
# Benchmark: drop
# Data Indices: [47, 256]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the passage
        extract_instruction = (
            "Extract all entities, numerical values, dates, and their relationships from the passage. "
            "Include explicit mentions and infer implicit associations. Format the output as a structured list."
        )
        extract_task = self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_analysis_instruction = (
            "Analyze the question to determine its intent. "
            "Identify if it requires arithmetic operations, comparisons, span extraction, or other reasoning. "
            "Provide a clear explanation of the reasoning required."
        )
        question_analysis_task = self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Execute Steps 1 and 2 in parallel
        extraction, question_analysis = await asyncio.gather(extract_task, question_analysis_task)

        # Step 3: Perform reasoning based on the question analysis
        reasoning_instruction = (
            f"Based on the following extracted information:\n{extraction}\n"
            f"And the analysis of the question:\n{question_analysis}\n"
            "Perform the required reasoning step-by-step. Include all calculations, comparisons, or extractions needed."
        )
        reasoning = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the reasoning output
        refine_instruction = (
            "Critique the following reasoning output for correctness and completeness. "
            "Address any ambiguities, missing details, or potential errors. Provide a refined version."
        )
        refined_reasoning = await self.revise(instruction=refine_instruction, context=reasoning)

        # Step 5: Summarize the refined reasoning into a concise answer
        summarize_instruction = (
            "Condense the following refined reasoning into a concise and clear answer. "
            "Ensure the answer directly addresses the question and is easy to understand."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_reasoning)

        return final_answer