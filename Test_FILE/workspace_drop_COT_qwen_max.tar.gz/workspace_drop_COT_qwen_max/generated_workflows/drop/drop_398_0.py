# Workflow ID: drop_398_0
# Benchmark: drop
# Data Indices: [239, 612]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all relevant numerical values, entities, and relationships
        extraction_instruction = """
        Extract ALL numerical values, entities, and their relationships from the passage.
        Include explicit and implicit information, such as counts, measurements, dates, names, and any associated context.
        Format the output as a structured list for clarity.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Interpret the question and determine the reasoning type
        interpretation_instruction = f"""
        Analyze the question and determine the type of reasoning required (e.g., arithmetic, counting, comparison, span extraction).
        Use the following extracted information to guide your analysis:
        {extracted_info}
        Provide a detailed explanation of the reasoning steps needed to answer the question.
        """
        question_interpretation = await self.generate(instruction=interpretation_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the interpreted question type
        reasoning_instruction = f"""
        Based on the interpreted reasoning type and the extracted information:
        {question_interpretation}
        Perform the necessary reasoning steps to compute or identify the answer.
        Ensure all numbers are correctly associated with their entities and that any calculations are accurate.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the answer
        refinement_instruction = f"""
        Critique and refine the following reasoning result:
        {reasoning_result}
        Ensure it is consistent with the passage and the question intent.
        Correct any errors or ambiguities and provide a polished final answer.
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Handle ambiguities and edge cases (if necessary)
        # Use Ensemble to decide between multiple candidate answers if needed
        ensemble_instruction = f"""
        Evaluate the following candidate answers and select the most consistent and relevant one:
        - Candidate 1: {refined_answer}
        Consider all extracted information and reasoning steps before making a decision.
        """
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[refined_answer])

        return final_answer