# Workflow ID: drop_108_0
# Benchmark: drop
# Data Indices: [685, 662]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the passage
        extraction_instruction = """
        Extract all numerical values, entities, and relationships mentioned in the passage. 
        Organize the information in a structured format, associating numbers with their respective entities or events.
        Ensure no relevant detail is missed, as this will form the basis for answering the question.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question intent
        intent_instruction = f"""
        Analyze the question to determine its type and intent. Possible types include:
        - Arithmetic operations (e.g., addition, subtraction, multiplication, division)
        - Counting (e.g., number of occurrences, unique entities)
        - Comparison (e.g., greater than, less than, equality)
        - Span extraction (e.g., identifying specific phrases or entities)
        - Other (e.g., inference, implicit reasoning)
        Based on the extracted information: {extracted_info}, provide a detailed breakdown of what the question is asking.
        """
        question_intent = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question intent
        reasoning_instruction = f"""
        Based on the identified question intent: {question_intent}, perform the necessary reasoning steps:
        - For arithmetic operations, calculate the required values using the extracted numerical data.
        - For counting, tally the occurrences of the specified entities or events.
        - For comparisons, evaluate which entity satisfies the condition.
        - For span extraction, identify and return the relevant text span.
        Ensure the reasoning process is detailed and accurate.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine intermediate results
        refinement_instruction = f"""
        Critique the reasoning result: {reasoning_result}. Check for:
        - Accuracy of calculations or counts
        - Correct alignment with the question intent
        - Any missing or ambiguous information
        Provide a revised version if necessary.
        """
        refined_result = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Handle ambiguity with Ensemble (if needed)
        ensemble_instruction = f"""
        If there are multiple possible interpretations or answers, evaluate and synthesize the options:
        - Compare the reasoning paths and select the most plausible answer.
        - Resolve any conflicts or ambiguities.
        """
        candidate_answers = [refined_result]  # Default single answer
        if "multiple interpretations" in refined_result.lower():
            alternative_answer = await self.generate(
                instruction="Provide an alternative interpretation or reasoning path.",
                context=self.problem_text
            )
            candidate_answers.append(alternative_answer)
            refined_result = await self.ensemble(instruction=ensemble_instruction, contexts=candidate_answers)

        # Step 6: Construct the final answer
        final_instruction = f"""
        Summarize the final reasoning and present the answer in a concise format. Ensure the response directly addresses the question.
        Final reasoning: {refined_result}
        """
        final_answer = await self.summarize(instruction=final_instruction, context=self.problem_text)

        return final_answer