# Workflow ID: drop_145_0
# Benchmark: drop
# Data Indices: [718, 656]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information from the passage
        extraction_instruction = (
            "Thoroughly analyze the passage and extract ALL numerical values, entities, and key phrases. "
            "Ensure no relevant information is missed. Organize the extracted data into categories such as "
            "numbers, named entities (e.g., teams, players), events (e.g., touchdowns, field goals), and relationships."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Understand the question and formulate a strategy
        strategy_instruction = f"""
        Analyze the question to determine its intent and requirements. Use the following extracted information:
        {extracted_info}

        Identify whether the question asks for a count, a comparison, a specific value, or another type of answer. 
        Formulate a clear strategy to compute or select the answer based on the extracted information. 
        For example, if the question involves counting, specify what needs to be counted; if it involves comparison, 
        specify the entities or values to compare.
        """
        strategy = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Perform computation or selection
        computation_instruction = f"""
        Execute the strategy formulated in the previous step. Use the extracted information:
        {extracted_info}

        Perform any required calculations, comparisons, or selections. If there are multiple plausible answers, 
        generate them all for further evaluation.
        """
        candidate_answers = await self.generate(instruction=computation_instruction, context=self.problem_text)

        # Step 4: Evaluate and synthesize the best answer (if needed)
        ensemble_instruction = f"""
        Evaluate the following candidate answers and synthesize the best response:
        {candidate_answers}

        Ensure the final answer aligns with the question's intent and is supported by the extracted information. 
        If there are ambiguities, resolve them by considering the most logical interpretation.
        """
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[candidate_answers])

        # Step 5: Refine the final answer
        refinement_instruction = f"""
        Critique and refine the following answer to ensure clarity, correctness, and alignment with the question:
        {final_answer}

        Address any ambiguities, ensure proper formatting, and verify that the answer fully satisfies the question's requirements.
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        return refined_answer