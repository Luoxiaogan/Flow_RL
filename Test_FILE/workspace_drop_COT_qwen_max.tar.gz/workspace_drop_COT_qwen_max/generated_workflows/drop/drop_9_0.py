# Workflow ID: drop_9_0
# Benchmark: drop
# Data Indices: [152, 544]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Initial Analysis
        extraction_instruction = (
            "Thoroughly analyze the passage and question. "
            "Identify all entities, numerical values, and their relationships. "
            "Determine the type of reasoning required (counting, arithmetic, comparison)."
        )
        initial_analysis = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Entity-Value Association
        revision_instruction = (
            f"Refine the following extracted information: {initial_analysis}. "
            "Ensure each numerical value is correctly associated with its corresponding entity. "
            "Distinguish between similar entities if present."
        )
        refined_analysis = await self.revise(instruction=revision_instruction, context=initial_analysis)

        # Step 3: Reasoning Execution
        reasoning_instruction = (
            f"Based on the refined analysis: {refined_analysis}, "
            "execute the necessary reasoning steps. "
            "For counting questions, count occurrences. "
            "For arithmetic questions, perform the required operations. "
            "For comparison questions, determine the correct answer."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=refined_analysis)

        # Step 4: Final Answer Synthesis
        synthesis_instruction = (
            "Combine all results from previous steps to form the final answer. "
            "Handle any ambiguities or edge cases by evaluating multiple interpretations if necessary."
        )
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=[refined_analysis, reasoning_result])

        return final_answer