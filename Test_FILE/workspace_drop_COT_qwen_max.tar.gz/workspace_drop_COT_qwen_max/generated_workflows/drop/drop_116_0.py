# Workflow ID: drop_116_0
# Benchmark: drop
# Data Indices: [34, 308]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information and analyze the question
        extraction_instruction = """
        Extract all numerical values, entities, and their associations from the passage. 
        Identify what the question is asking for and categorize it into one of the following types:
        - Arithmetic Operations (e.g., total, difference)
        - Counting (e.g., how many times)
        - Comparison (e.g., greater, longer)
        - Selection (e.g., which team won)
        - Span Extraction (e.g., who did...)

        Provide the extracted information in a structured format:
        - Numerical Values: [list of numbers]
        - Entities: [list of associated entities or contexts]
        - Question Type: [identified type]
        - Specific Request: [what is being asked specifically]
        """
        extraction_result = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Associate numbers with entities
        association_instruction = f"""
        Given the following extracted information:
        {extraction_result}

        Associate each numerical value with its corresponding entity or context from the passage.
        Ensure that each number is correctly linked to avoid ambiguity.
        Present the associations in a clear, structured format:
        - Number: [value], Entity/Context: [description]
        """
        association_result = await self.generate(instruction=association_instruction, context=self.problem_text)

        # Step 3: Determine question type and initiate parallel reasoning paths
        question_type_instruction = f"""
        Based on the analysis:
        {extraction_result}

        Identify the exact question type and prepare the necessary reasoning steps.
        For each type, outline the required actions:
        - Arithmetic Operations: Perform the specified calculation using associated numbers.
        - Counting: Count occurrences of the specified entity or event.
        - Comparison: Compare entities based on the given criteria.
        - Selection: Select the correct entity or span based on the question.
        - Span Extraction: Extract the exact text or entity name as requested.

        Prepare detailed instructions for each identified reasoning path.
        """
        reasoning_instructions = await self.generate(instruction=question_type_instruction, context=self.problem_text)

        # Parallel execution based on question type
        if "Arithmetic Operations" in reasoning_instructions:
            arithmetic_instruction = f"""
            Perform the required arithmetic operation based on the following information:
            {reasoning_instructions}

            Calculate the result step by step and provide the final answer.
            """
            arithmetic_result = await self.generate(instruction=arithmetic_instruction, context=self.problem_text)

        if "Counting" in reasoning_instructions:
            counting_instruction = f"""
            Count the occurrences of the specified entity or event based on:
            {reasoning_instructions}

            Provide the total count as the answer.
            """
            counting_result = await self.generate(instruction=counting_instruction, context=self.problem_text)

        if "Comparison" in reasoning_instructions:
            comparison_candidates = await asyncio.gather(
                self.generate(instruction=f"Analyze the first entity for comparison: {reasoning_instructions}", context=self.problem_text),
                self.generate(instruction=f"Analyze the second entity for comparison: {reasoning_instructions}", context=self.problem_text)
            )
            comparison_result = await self.ensemble(
                instruction="Compare the two entities and determine which satisfies the comparison criteria.",
                contexts=comparison_candidates
            )

        if "Selection" in reasoning_instructions:
            selection_instruction = f"""
            Select the correct entity or span based on:
            {reasoning_instructions}

            Extract the exact text or entity name as the answer.
            """
            selection_result = await self.generate(instruction=selection_instruction, context=self.problem_text)

        if "Span Extraction" in reasoning_instructions:
            span_extraction_instruction = f"""
            Extract the exact text or entity name as requested in:
            {reasoning_instructions}

            Provide the precise span that answers the question.
            """
            span_extraction_result = await self.generate(instruction=span_extraction_instruction, context=self.problem_text)

        # Gather all potential results
        potential_results = [
            arithmetic_result if "Arithmetic Operations" in reasoning_instructions else None,
            counting_result if "Counting" in reasoning_instructions else None,
            comparison_result if "Comparison" in reasoning_instructions else None,
            selection_result if "Selection" in reasoning_instructions else None,
            span_extraction_result if "Span Extraction" in reasoning_instructions else None
        ]
        potential_results = [result for result in potential_results if result]

        # Step 4: Revise and validate the results
        revision_instruction = f"""
        Review the following potential answers:
        {potential_results}

        Critique each result for accuracy and relevance to the question.
        Refine any answers that require improvement and ensure the final selection accurately addresses the question.
        """
        revised_result = await self.revise(instruction=revision_instruction, context="\n".join(potential_results))

        # Step 5: Summarize the final answer
        summary_instruction = """
        Summarize the final, refined answer in a concise and clear manner.
        Ensure that the response directly addresses the question without unnecessary details.
        """
        final_answer = await self.summarize(instruction=summary_instruction, context=revised_result)

        return final_answer