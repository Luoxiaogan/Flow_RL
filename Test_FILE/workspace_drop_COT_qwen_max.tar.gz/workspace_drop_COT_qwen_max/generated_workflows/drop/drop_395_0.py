# Workflow ID: drop_395_0
# Benchmark: drop
# Data Indices: [496, 412]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract relevant information from the passage
        extraction_instruction = """
        Extract all relevant entities, numerical values, and their relationships from the passage.
        Include:
        - Names of people, teams, organizations, or other entities.
        - Numerical values and their associated contexts (e.g., scores, counts, dates).
        - Relationships between entities and numbers (e.g., who scored what, when events occurred).
        Organize the extracted information in a structured format for easy reference.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_analysis_instruction = f"""
        Analyze the question to determine its intent based on the following categories:
        - Arithmetic operations (e.g., sum, difference, count).
        - Comparison (e.g., greater than, less than, equal to).
        - Selection (e.g., identifying a specific entity or event).
        - Span extraction (e.g., extracting a phrase or name directly from the text).
        Use the extracted information below to align the question with the relevant data:
        {extracted_info}
        Provide a clear interpretation of what the question is asking for.
        """
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform reasoning and calculations
        reasoning_instruction = f"""
        Based on the question analysis below, perform the necessary reasoning steps to solve the problem:
        {question_analysis}
        Use the extracted information to calculate, compare, or select the correct answer.
        Ensure that all steps are clearly documented and justified.
        """
        reasoning_results = await asyncio.gather(
            self.generate(instruction=reasoning_instruction, context=self.problem_text),
            self.generate(instruction=reasoning_instruction, context=self.problem_text)  # Parallel reasoning paths
        )

        # Step 4: Validate and refine intermediate results
        refinement_instruction = f"""
        Critique and refine the reasoning results below to ensure accuracy and resolve ambiguities:
        Results:
        {reasoning_results[0]}
        {reasoning_results[1]}
        Focus on:
        - Correctness of calculations or comparisons.
        - Clarity and justification of reasoning steps.
        - Resolution of conflicting interpretations.
        """
        refined_results = await asyncio.gather(
            self.revise(instruction=refinement_instruction, context=reasoning_results[0]),
            self.revise(instruction=refinement_instruction, context=reasoning_results[1])
        )

        # Step 5: Synthesize the final answer
        synthesis_instruction = f"""
        Evaluate the refined results below and synthesize a final answer:
        Refined Results:
        {refined_results[0]}
        {refined_results[1]}
        Select the most appropriate result based on:
        - Alignment with the question's intent.
        - Completeness and accuracy of reasoning.
        - Consistency with the extracted information.
        Provide the final answer in the required format (number, date, text span, etc.).
        """
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=refined_results)

        return final_answer