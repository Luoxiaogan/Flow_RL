# Workflow ID: drop_87_0
# Benchmark: drop
# Data Indices: [203, 248]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all relevant entities, numerical values, and relationships
        extraction_instruction = (
            "Carefully analyze the provided passage. "
            "Extract all entities, numerical values, and their relationships. "
            "Ensure you capture every instance where a number is associated with an entity. "
            "Organize the extracted information into a structured format for further processing."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Interpret the question's intent
        question_instruction = (
            f"Given the following extracted information: {extracted_info}\n"
            "Analyze the question to determine its intent. "
            "Identify whether the question requires arithmetic operations, counting, comparison, or span extraction. "
            "Provide a clear breakdown of the reasoning steps needed to answer the question."
        )
        question_analysis = await self.generate(instruction=question_instruction, context=self.problem_text)

        # Step 3: Parallel reasoning paths
        arithmetic_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Perform any required arithmetic operations (addition, subtraction, etc.) to compute the answer. "
            "Ensure all calculations are accurate and explain your reasoning."
        )
        counting_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Count the occurrences of specific entities or events as requested by the question. "
            "Provide a clear tally and explanation."
        )
        comparison_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Compare numerical values or entities as specified in the question. "
            "Clearly state which value or entity is greater, lesser, or equal."
        )
        span_extraction_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Extract the relevant text span (entity name, phrase, etc.) that answers the question. "
            "Ensure the span is precise and directly addresses the query."
        )

        results = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=counting_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text),
            self.generate(instruction=span_extraction_instruction, context=self.problem_text)
        )

        # Step 4: Ensemble decision
        ensemble_instruction = (
            f"Given the following reasoning paths:\n"
            f"Arithmetic: {results[0]}\n"
            f"Counting: {results[1]}\n"
            f"Comparison: {results[2]}\n"
            f"Span Extraction: {results[3]}\n"
            "Synthesize the results to produce a coherent and accurate final answer. "
            "Prioritize the path that best aligns with the question's intent. "
            "If multiple paths are relevant, combine them logically."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 5: Final refinement
        refinement_instruction = (
            f"Refine the following answer: {final_answer}\n"
            "Ensure it is clear, concise, and formatted appropriately. "
            "Correct any ambiguities or errors."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        return refined_answer