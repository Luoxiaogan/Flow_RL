# Workflow ID: drop_115_0
# Benchmark: drop
# Data Indices: [38, 378]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information from the passage and question
        extraction_instruction = (
            "Carefully analyze the passage and question to extract all relevant entities, numerical values, "
            "dates, and relationships. Organize the extracted information into categories such as 'entities', "
            "'numbers', 'dates', and 'relationships'. Ensure no critical detail is missed."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Understand the intent of the question
        intent_instruction = (
            f"Based on the extracted information: {extracted_info}, determine the type of reasoning required "
            "to answer the question. Classify the question into one of the following categories: "
            "'arithmetic operation', 'comparison', 'counting', 'span extraction', or 'other'. "
            "Provide a clear explanation of the reasoning process needed."
        )
        question_intent = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning or calculation based on the question intent
        reasoning_instruction = (
            f"Given the extracted information: {extracted_info}, and the identified question intent: {question_intent}, "
            "perform the necessary reasoning or calculation to derive the answer. If the question requires arithmetic, "
            "show the step-by-step calculation. If it involves comparison, clearly state the basis of the comparison. "
            "Ensure the reasoning is thorough and leaves no ambiguity."
        )
        preliminary_answer = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine and validate the answer
        refinement_instruction = (
            f"Review the preliminary answer: {preliminary_answer}. Critique its accuracy and alignment with the "
            "question's requirements. Address any ambiguities or errors. Provide a refined version of the answer that "
            "is concise, precise, and fully supported by the passage and reasoning process."
        )
        refined_answer = await self.revise(instruction=refinement_instruction, context=preliminary_answer)

        # Step 5: Handle ambiguity with multiple interpretations (if needed)
        ambiguity_check_instruction = (
            f"Check if the refined answer: {refined_answer} could be interpreted in multiple ways due to similar entities "
            "or ambiguous references. If so, generate alternative interpretations or solutions."
        )
        alternative_solutions = await self.generate(instruction=ambiguity_check_instruction, context=self.problem_text)

        if "alternative" in alternative_solutions.lower():
            final_instruction = (
                f"Evaluate the refined answer: {refined_answer} and alternative solutions: {alternative_solutions}. "
                "Select the most accurate and well-supported answer based on the passage and reasoning process."
            )
            final_answer = await self.ensemble(instruction=final_instruction, contexts=[refined_answer, alternative_solutions])
        else:
            final_answer = refined_answer

        return final_answer