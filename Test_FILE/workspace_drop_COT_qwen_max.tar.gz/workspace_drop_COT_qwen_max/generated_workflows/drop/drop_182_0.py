# Workflow ID: drop_182_0
# Benchmark: drop
# Data Indices: [37, 206]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Understand the question and identify its intent
        question_intent = await self.generate(
            instruction="Analyze the question and determine its intent. "
                        "Identify if the question requires arithmetic operations, counting, comparison, selection, or span extraction. "
                        "Provide a detailed breakdown of what the question is asking for.",
            context=self.problem_text
        )

        # Step 2: Extract relevant information from the passage
        info_extraction_task = await self.generate(
            instruction=f"Based on the question intent: {question_intent}, extract all relevant entities, numerical values, and their associations from the passage. "
                        "Focus on identifying key phrases, numbers, and relationships that are crucial to answering the question.",
            context=self.problem_text
        )

        # Step 3: Perform reasoning or computation
        reasoning_task = await self.generate(
            instruction=f"Using the extracted information: {info_extraction_task}, perform the necessary reasoning or computation to answer the question. "
                        "If the question involves arithmetic operations, calculate the result. "
                        "If it involves comparison, determine which entity satisfies the condition. "
                        "If it involves span extraction, identify the exact text span that answers the question.",
            context=self.problem_text
        )

        # Step 4: Validate and refine the intermediate results
        refined_result = await self.revise(
            instruction="Critique the reasoning or computation performed in the previous step. "
                        "Ensure that the result aligns with the question's intent and is logically consistent with the passage. "
                        "Refine the result if necessary.",
            context=reasoning_task
        )

        # Step 5: Synthesize the final answer
        # Optionally generate alternative reasoning paths for ensemble evaluation
        alternative_reasoning = await self.generate(
            instruction="Provide an alternative reasoning path or approach to answer the question. "
                        "This should be distinct from the primary reasoning but still valid based on the passage.",
            context=self.problem_text
        )

        final_answer = await self.ensemble(
            instruction="Evaluate the primary reasoning and the alternative reasoning. "
                        "Select the most accurate and complete answer that directly addresses the question. "
                        "Ensure the final output is concise and clear.",
            contexts=[refined_result, alternative_reasoning]
        )

        return final_answer