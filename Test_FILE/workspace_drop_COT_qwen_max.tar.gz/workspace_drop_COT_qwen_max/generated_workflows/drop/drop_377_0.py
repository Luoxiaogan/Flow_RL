# Workflow ID: drop_377_0
# Benchmark: drop
# Data Indices: [171, 596]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (entities, numbers, relationships)
        extraction_instruction = (
            "Extract all relevant entities, numerical values, and their relationships from the passage. "
            "Include counts, measurements, dates, and any comparative or descriptive information. "
            "Ensure no relevant information is missed."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Understand the question intent
        intent_instruction = (
            f"Given the extracted information: {extracted_info}\n"
            "Analyze the question to determine its intent. Classify the question into one of the following categories: "
            "arithmetic (addition, subtraction, etc.), counting, comparison, or span extraction. "
            "Provide clear reasoning for the classification."
        )
        question_intent = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the question intent
        reasoning_instruction_template = (
            f"Based on the extracted information: {extracted_info}\n"
            "and the question intent: {question_intent}\n"
            "Perform the necessary reasoning to answer the question. "
            "For arithmetic operations, calculate the result step by step. "
            "For counting, count the occurrences of the relevant entity or event. "
            "For comparisons, compare the relevant values or spans. "
            "For span extraction, identify and extract the exact text span that answers the question."
        )
        reasoning_instruction = reasoning_instruction_template.format(question_intent=question_intent)
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine and validate the reasoning result
        refinement_instruction = (
            f"Review the reasoning result: {reasoning_result}\n"
            "Critique and refine it to ensure accuracy and alignment with the question's requirements. "
            "Correct any errors or ambiguities in the reasoning process."
        )
        refined_result = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Synthesize final answer (if multiple paths exist)
        ensemble_instruction = (
            f"Given the refined result: {refined_result}\n"
            "and the original reasoning result: {reasoning_result}\n"
            "Select the best answer or synthesize results from different approaches. "
            "Ensure the final answer is clear, concise, and directly addresses the question."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[reasoning_result, refined_result])

        return final_answer