# Workflow ID: drop_209_0
# Benchmark: drop
# Data Indices: [264, 466]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information from the passage and question
        extraction_instruction = (
            "Carefully analyze the passage and question. "
            "Extract all numerical values, entities, relationships, and any implicit or explicit reasoning clues. "
            "Ensure you associate numbers with their corresponding entities or events. "
            "Provide a structured summary of the extracted information."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        analysis_instruction = (
            f"Based on the extracted information: {extracted_info}, analyze the question. "
            "Determine whether it requires arithmetic operations (e.g., addition, subtraction), comparisons, "
            "span extraction, or multi-hop inference. Provide a clear description of the reasoning path needed."
        )
        question_analysis = await self.generate(instruction=analysis_instruction, context=self.problem_text)

        # Step 3: Execute parallel reasoning paths
        arithmetic_instruction = (
            f"Using the extracted information: {extracted_info}, perform any required arithmetic operations. "
            "Ensure you clearly show your calculations and the associated entities."
        )
        comparison_instruction = (
            f"Using the extracted information: {extracted_info}, compare entities or values as specified in the question. "
            "Provide a detailed justification for your comparison."
        )
        span_extraction_instruction = (
            f"Using the extracted information: {extracted_info}, identify and extract the requested text span. "
            "Ensure the span directly answers the question."
        )

        # Run reasoning paths in parallel
        results = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text),
            self.generate(instruction=span_extraction_instruction, context=self.problem_text)
        )

        # Step 4: Validate and refine results
        refinement_instruction = (
            "Critique and refine the provided result. Ensure it aligns with the question's intent and the passage's context. "
            "Correct any errors or ambiguities."
        )
        refined_results = await asyncio.gather(
            self.revise(instruction=refinement_instruction, context=results[0]),
            self.revise(instruction=refinement_instruction, context=results[1]),
            self.revise(instruction=refinement_instruction, context=results[2])
        )

        # Step 5: Synthesize the final answer
        synthesis_instruction = (
            "Evaluate the refined results and synthesize them into a single coherent answer. "
            "Resolve any conflicts between reasoning paths and ensure the final output is robust and accurate."
        )
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=refined_results)

        return final_answer