# Workflow ID: drop_370_0
# Benchmark: drop
# Data Indices: [62, 681]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information (numbers, entities, relationships)
        extraction_instruction = (
            "Extract all numerical values, entities, and their relationships from the passage. "
            "Ensure that each number is associated with its corresponding entity or context. "
            "Pay attention to dates, counts, measurements, and any comparative statements."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine the reasoning type
        analysis_instruction = (
            f"Given the extracted information: {extracted_info}\n"
            "Analyze the question to determine the type of reasoning required (e.g., arithmetic, comparison, extraction). "
            "Identify the specific entities, numbers, or spans involved in answering the question."
        )
        reasoning_type = await self.generate(instruction=analysis_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the identified type
        reasoning_instruction = (
            f"Based on the reasoning type: {reasoning_type}\n"
            "Perform the required reasoning step by step. If arithmetic is needed, calculate the result explicitly. "
            "If comparison is needed, compare the relevant values and provide the answer. "
            "If extraction is needed, ensure the span is precise and matches the question."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine the result to ensure accuracy
        refinement_instruction = (
            f"Review the reasoning result: {reasoning_result}\n"
            "Check for any errors or ambiguities. Ensure that the answer aligns perfectly with the question's intent. "
            "If necessary, revise the result to improve clarity and correctness."
        )
        refined_result = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Optional Step 5: Use Ensemble to resolve ambiguities (if multiple interpretations exist)
        # Generate alternative interpretations in parallel
        alternative_instructions = [
            "Provide an alternative interpretation focusing on arithmetic operations.",
            "Provide an alternative interpretation focusing on entity extraction.",
            "Provide an alternative interpretation focusing on comparative analysis."
        ]
        alternative_results = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in alternative_instructions]
        )

        # Synthesize results using Ensemble
        ensemble_instruction = (
            "Evaluate the following interpretations and select the most accurate one. "
            "If there are complementary insights, synthesize them into a single coherent answer."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[refined_result] + alternative_results)

        return final_answer