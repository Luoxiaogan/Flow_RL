# Workflow ID: drop_342_0
# Benchmark: drop
# Data Indices: [667, 212]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract entities, numerical values, and relationships
        extraction_instruction = (
            "Extract all entities, numerical values, and their relationships from the passage. "
            "Ensure you capture every detail that could be relevant to answering the question."
        )
        entity_extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its type and intent
        question_analysis_instruction = (
            "Analyze the question to determine its type and intent. "
            "Classify the question as one of the following: arithmetic, counting, comparison, span extraction. "
            "Provide detailed reasoning about what the question is asking for."
        )
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Execute reasoning based on the question type
        reasoning_instruction_template = (
            "Given the extracted information: {entity_extraction}\n"
            "And the question analysis: {question_analysis}\n"
            "Solve the problem step by step. Use the following guidelines:\n"
            "- For arithmetic questions, perform the required calculations.\n"
            "- For counting questions, count the relevant occurrences.\n"
            "- For comparison questions, evaluate the relationships between entities or values.\n"
            "- For span extraction questions, extract the relevant text spans directly.\n"
            "Provide a clear and complete solution."
        )
        reasoning_instruction = reasoning_instruction_template.format(
            entity_extraction=entity_extraction, question_analysis=question_analysis
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the solution
        refinement_instruction = (
            "Review the solution and refine it for accuracy and completeness. "
            "Resolve any ambiguities or inconsistencies. Ensure the final answer directly addresses the question."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Handle multiple candidate answers if necessary
        # (Optional: Only used if parallel reasoning paths produce multiple candidates)
        ensemble_instruction = (
            "Evaluate the provided candidate solutions and select the best one. "
            "If multiple answers are valid, synthesize them into a single coherent response."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[refined_solution])

        return final_answer