# Workflow ID: drop_252_0
# Benchmark: drop
# Data Indices: [567, 259]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information from the passage and question
        extraction_instruction = (
            "Thoroughly analyze the provided passage and question. "
            "Extract all entities, numerical values, relationships, and implicit constraints. "
            "Organize the information into categories such as 'Entities', 'Numbers', 'Relationships', and 'Constraints'. "
            "Ensure completeness and clarity in your extraction."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Identify the intent of the question
        intent_instruction = (
            f"Given the following extracted information: {extracted_info}\n"
            "Determine the intent of the question. Classify the reasoning required into one of the following categories:\n"
            "- Arithmetic Operations (e.g., addition, subtraction, comparison)\n"
            "- Counting (e.g., tallying occurrences)\n"
            "- Comparison (e.g., greater than, less than)\n"
            "- Span Extraction (e.g., identifying specific phrases or entities)\n"
            "Provide a clear explanation of the reasoning required and any specific constraints."
        )
        question_intent = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on the identified intent
        reasoning_instruction = (
            f"Based on the identified intent: {question_intent}\n"
            "Perform the necessary reasoning steps to arrive at the answer. Follow these guidelines:\n"
            "- For arithmetic operations, perform calculations step by step.\n"
            "- For counting, ensure all relevant occurrences are tallied.\n"
            "- For comparisons, clearly state the basis of comparison.\n"
            "- For span extraction, isolate the exact phrase or entity.\n"
            "Provide a detailed breakdown of the reasoning process and the final result."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Optional Step 4: Refine the reasoning result if needed
        refinement_instruction = (
            f"Review the following reasoning result: {reasoning_result}\n"
            "Critique the reasoning process and identify any ambiguities, errors, or omissions. "
            "Refine the result to ensure accuracy and completeness."
        )
        refined_result = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Synthesize results if multiple paths were explored
        final_instruction = (
            f"Given the following reasoning results: {refined_result}\n"
            "Evaluate and synthesize the results to produce the final answer. "
            "Ensure the answer directly addresses the question and is presented concisely."
        )
        final_answer = await self.ensemble(instruction=final_instruction, contexts=[refined_result])

        return final_answer