# Workflow ID: drop_270_0
# Benchmark: drop
# Data Indices: [447, 271]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information
        extraction_instruction = (
            "Extract ALL relevant information from the passage and question, including numerical values, "
            "entities, relationships, and any implicit information. Organize the extracted data clearly "
            "and label each piece of information for easy reference."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Understand the question intent
        question_intent_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Determine what the question is asking for. Identify the type of reasoning required: "
            "arithmetic operation (e.g., sum, difference), counting, comparison, selection, or span extraction. "
            "Provide a clear explanation of the reasoning type and how to proceed."
        )
        question_intent = await self.generate(instruction=question_intent_instruction, context=self.problem_text)

        # Step 3: Parallel reasoning paths
        arithmetic_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "If the question requires an arithmetic operation (e.g., sum, difference), perform the calculation "
            "step by step. Show all intermediate steps and the final result."
        )
        counting_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "If the question requires counting occurrences, count the relevant entities or events carefully. "
            "Ensure no instances are missed and provide the total count."
        )
        comparison_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "If the question requires a comparison, compare the relevant entities or values. "
            "Clearly state which entity or value is greater, smaller, or equal."
        )
        selection_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "If the question requires selecting a text span or entity, extract the relevant span or name. "
            "Ensure the selection matches the question's requirements exactly."
        )

        # Execute parallel reasoning paths
        results = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=counting_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text),
            self.generate(instruction=selection_instruction, context=self.problem_text)
        )

        # Step 4: Synthesize and finalize the answer
        synthesis_instruction = (
            f"Given the following reasoning results:\n"
            f"- Arithmetic: {results[0]}\n"
            f"- Counting: {results[1]}\n"
            f"- Comparison: {results[2]}\n"
            f"- Selection: {results[3]}\n"
            "Synthesize the results and select the most appropriate answer based on the question intent. "
            "Ensure the final answer is accurate, complete, and formatted correctly."
        )
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=results)

        return final_answer