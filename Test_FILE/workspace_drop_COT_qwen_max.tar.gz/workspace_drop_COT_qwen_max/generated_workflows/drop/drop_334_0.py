# Workflow ID: drop_334_0
# Benchmark: drop
# Data Indices: [281, 137]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information (numerical values and entities)
        extraction_instruction = """
        Extract all numerical values and their associated entities from the passage. 
        Ensure you capture every instance where numbers are mentioned alongside their corresponding entities.
        For example, if the text says '50,251 people', capture '50,251' as the number and 'people' as the entity.
        Organize the extracted information in a structured format for easy reference.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Understand the question intent
        intent_instruction = f"""
        Based on the extracted information: {extracted_info}
        Determine what the question is asking for. Identify whether it requires addition, subtraction, counting, or another operation.
        Provide a clear explanation of the question's intent and specify which numbers and entities are relevant to the calculation.
        """
        question_intent = await self.generate(instruction=intent_instruction, context=self.problem_text)

        # Step 3: Perform the necessary calculation
        calculation_instruction = f"""
        Given the extracted information: {extracted_info}
        And the identified question intent: {question_intent}
        Perform the required calculation to arrive at the answer. Ensure you handle all numerical operations accurately.
        Present the calculation steps and the final result clearly.
        """
        calculation_result = await self.generate(instruction=calculation_instruction, context=self.problem_text)

        # Step 4: Revise and validate the result
        revision_instruction = f"""
        Review the following calculation result: {calculation_result}
        Critique and refine it to ensure accuracy. Verify that all steps are correct and that the final answer aligns with the question's requirements.
        """
        revised_result = await self.revise(instruction=revision_instruction, context=calculation_result)

        # Step 5: Summarize the final answer
        summary_instruction = f"""
        Summarize the following revised result: {revised_result}
        Present the final answer in a clear and concise manner, ensuring it directly addresses the question.
        """
        final_answer = await self.summarize(instruction=summary_instruction, context=revised_result)

        return final_answer