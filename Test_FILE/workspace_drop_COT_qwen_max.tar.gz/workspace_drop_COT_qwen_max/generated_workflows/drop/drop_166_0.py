# Workflow ID: drop_166_0
# Benchmark: drop
# Data Indices: [798, 796]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key entities, numbers, and relationships
        extract_instruction = """
        Analyze the passage thoroughly and extract all relevant entities, numerical values, and their relationships. 
        Ensure you capture every detail, including implicit associations between entities and numbers. 
        Format your output as a structured list or table for clarity.
        """
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Understand the question intent
        question_intent_instruction = f"""
        Analyze the question and determine its type. Possible types include:
        - Arithmetic (e.g., addition, subtraction, multiplication, division)
        - Counting (e.g., how many times, how many different)
        - Comparison (e.g., greater than, less than, earliest, latest)
        - Selection (e.g., which team, what happened first/last)
        - Span Extraction (e.g., who did, what was the name of)
        Use the following extracted information to guide your analysis:
        {extracted_info}
        Clearly state the question type and provide reasoning for your classification.
        """
        question_intent = await self.generate(instruction=question_intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on question type
        reasoning_instruction = f"""
        Based on the extracted information:
        {extracted_info}
        And the identified question type:
        {question_intent}
        Perform the necessary reasoning to answer the question. Follow these guidelines:
        - For arithmetic questions, perform calculations step by step.
        - For counting questions, tally occurrences accurately.
        - For comparison questions, evaluate magnitudes or orderings explicitly.
        - For selection questions, identify the correct entity or event.
        - For span extraction questions, extract the exact text span.
        Provide a clear and detailed explanation of your reasoning process.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Refine and validate the answer
        refine_instruction = f"""
        Review the following reasoning result for logical consistency and accuracy:
        {reasoning_result}
        Correct any errors, clarify ambiguities, and ensure the answer aligns with the question intent. 
        Provide a refined version of the answer with explanations for any changes made.
        """
        refined_answer = await self.revise(instruction=refine_instruction, context=reasoning_result)

        # Step 5: Final answer synthesis (if multiple interpretations exist)
        final_instruction = f"""
        Evaluate the following candidate answers and select the most accurate one:
        - Original Reasoning: {reasoning_result}
        - Refined Answer: {refined_answer}
        If there are discrepancies, resolve them by considering the question intent and extracted information.
        Provide the final answer with a justification for your choice.
        """
        final_answer = await self.ensemble(instruction=final_instruction, contexts=[reasoning_result, refined_answer])

        return final_answer