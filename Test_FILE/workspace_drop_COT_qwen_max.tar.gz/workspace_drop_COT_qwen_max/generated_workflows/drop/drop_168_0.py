# Workflow ID: drop_168_0
# Benchmark: drop
# Data Indices: [29, 109]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract relevant information (parallel execution)
        extract_instruction = (
            "Identify all numerical values, entities, and spans in the passage that are relevant to the question. "
            "For each numerical value, associate it with the corresponding entity or context. "
            "Include any implicit relationships or inferred information."
        )
        question_intent_instruction = (
            "Analyze the question to determine its intent. "
            "Is it asking for a sum, difference, count, comparison, or specific span? "
            "Provide a detailed breakdown of what needs to be done to answer the question."
        )
        extraction_task = self.generate(instruction=extract_instruction, context=self.problem_text)
        intent_task = self.generate(instruction=question_intent_instruction, context=self.problem_text)
        extracted_info, question_intent = await asyncio.gather(extraction_task, intent_task)

        # Step 2: Perform reasoning based on question intent
        reasoning_instruction = (
            f"Given the extracted information: {extracted_info}\n"
            f"and the question intent: {question_intent}\n"
            "Perform the required reasoning step-by-step. "
            "If the question involves arithmetic, show all calculations explicitly. "
            "If it involves comparison, clearly state which value is greater or lesser. "
            "If it involves span extraction, identify the exact text span."
        )
        reasoning_output = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 3: Validate and refine the reasoning output
        revise_instruction = (
            "Critique the reasoning output and refine it for accuracy. "
            "Address any ambiguities, incorrect associations, or calculation errors. "
            "Ensure the output fully answers the question."
        )
        refined_output = await self.revise(instruction=revise_instruction, context=reasoning_output)

        # Step 4: Summarize the final answer
        summarize_instruction = (
            "Condense the refined reasoning into a concise final answer. "
            "Ensure the response is clear, accurate, and directly addresses the question."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_output)

        return final_answer