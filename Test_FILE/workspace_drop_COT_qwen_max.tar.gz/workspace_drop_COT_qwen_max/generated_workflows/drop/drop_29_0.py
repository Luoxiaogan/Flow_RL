# Workflow ID: drop_29_0
# Benchmark: drop
# Data Indices: [131, 402]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract Relevant Information
        extraction_instruction = (
            "Carefully analyze the passage and question to identify all relevant entities, numbers, and relationships. "
            "Focus specifically on the question's intent and extract only the information needed to answer it. "
            "Ensure you capture all occurrences and associate numbers with their respective entities."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Refine Extracted Information
        refinement_instruction = (
            "Review the extracted information and ensure its accuracy. "
            "Remove any irrelevant or incorrect extractions and clarify ambiguous references. "
            "Make sure the remaining data is directly related to the question."
        )
        refined_info = await self.revise(instruction=refinement_instruction, context=extracted_info)

        # Step 3: Summarize Key Insights
        summarization_instruction = (
            "Condense the refined information into key insights. "
            "Focus on the most important data needed to answer the question. "
            "Format the summary clearly and concisely."
        )
        summary = await self.summarize(instruction=summarization_instruction, context=refined_info)

        # Step 4: Perform Reasoning and Calculation
        reasoning_instruction = (
            f"Based on the summarized insights: {summary}\n"
            "Perform the necessary reasoning or calculations to answer the question. "
            "If the question involves arithmetic operations, perform them step by step. "
            "If it involves span extraction, identify the exact text span. "
            "Ensure the reasoning process is clear and logical."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 5: Ensemble Multiple Approaches (if needed)
        ensemble_instruction = (
            "Evaluate the reasoning result and determine if multiple interpretations or approaches are possible. "
            "If so, compare and synthesize the results to select the best solution. "
            "Ensure the final answer aligns with the question's intent."
        )
        final_answer = await self.ensemble(instruction=ensemble_instruction, contexts=[reasoning_result])

        return final_answer