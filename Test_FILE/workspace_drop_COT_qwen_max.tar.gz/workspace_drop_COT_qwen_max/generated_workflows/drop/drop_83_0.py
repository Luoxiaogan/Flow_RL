# Workflow ID: drop_83_0
# Benchmark: drop
# Data Indices: [431, 605]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information from the passage and question
        extraction_instruction = (
            "Extract all relevant entities, numerical values, dates, and relationships from the passage and question. "
            "Identify which entities are associated with which numbers or dates. "
            "Include any implicit information that can be inferred from the context."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its intent
        question_analysis_instruction = (
            "Analyze the question to determine its intent. "
            "Classify the question into one of the following categories: "
            "arithmetic operation (addition, subtraction, etc.), counting, comparison, selection, or span extraction. "
            "Provide a detailed explanation of the reasoning behind the classification."
        )
        question_intent = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Perform reasoning and calculation based on the question intent
        reasoning_instruction = (
            f"Based on the extracted information: {extracted_info} and the question intent: {question_intent}, "
            "perform the necessary reasoning steps to arrive at the answer. "
            "For arithmetic operations, show the calculation steps. "
            "For comparisons, clearly state the entities being compared and the basis of comparison. "
            "For span extraction, identify the exact text span that answers the question."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the intermediate results
        refinement_instruction = (
            "Review the reasoning result for accuracy and consistency. "
            "Ensure that all numbers, entities, and relationships are correctly associated. "
            "Refine the result if necessary to eliminate errors or ambiguities."
        )
        refined_result = await self.revise(instruction=refinement_instruction, context=reasoning_result)

        # Step 5: Summarize the final answer
        summarization_instruction = (
            "Condense the reasoning and produce the final answer in the required format. "
            "If the answer is a number, provide it as a plain number. "
            "If the answer is a date, provide it in the format YYYY or YYYY-MM-DD. "
            "If the answer is a text span, provide the exact span without additional commentary."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_result)

        return final_answer