# Workflow ID: drop_386_0
# Benchmark: drop
# Data Indices: [561, 527]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract relevant information
        extraction_instruction = """
        Extract all numerical values, their associated entities, and any contextual clues from the problem text.
        Ensure you capture all potential candidates for answering the question. Format your output as follows:
        - Numerical Value: [value]
        - Associated Entity: [entity]
        - Contextual Clue: [clue]
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Understand question intent
        question_intent_instruction = f"""
        Analyze the question and determine its intent. Classify the question into one of the following types:
        - Arithmetic Operation (e.g., total, difference)
        - Comparison (e.g., greater, longer)
        - Counting (e.g., how many times)
        - Span Extraction (e.g., who did, what was)
        Use the extracted information: {extracted_info} to guide your analysis.
        """
        question_intent = await self.generate(instruction=question_intent_instruction, context=self.problem_text)

        # Step 3: Perform reasoning based on question intent
        reasoning_instruction = f"""
        Based on the question intent: {question_intent}, perform the necessary reasoning steps:
        - If the question asks for a total, sum the relevant numbers.
        - If it asks for a difference, subtract the appropriate values.
        - If it involves a comparison, compare the relevant entities or values.
        Use the extracted information: {extracted_info} to guide your calculations.
        """
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the result
        validation_instruction = f"""
        Cross-check the reasoning result: {reasoning_result} with the original problem text to ensure accuracy.
        Specifically, verify that:
        - All numerical values are correctly associated with their entities.
        - All arithmetic operations or comparisons are performed correctly.
        """
        refined_result = await self.revise(instruction=validation_instruction, context=reasoning_result)

        # Step 5: Finalize the answer
        final_instruction = f"""
        Summarize the final answer in the required format (number, text span, etc.) based on the refined result: {refined_result}.
        Ensure the answer directly addresses the question and is concise.
        """
        final_answer = await self.summarize(instruction=final_instruction, context=refined_result)

        return final_answer