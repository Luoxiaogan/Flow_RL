# Workflow ID: drop_217_0
# Benchmark: drop
# Data Indices: [465, 20]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant entities, numbers, and relationships
        extraction_instruction = """
        Extract all relevant entities, numerical values, dates, and their relationships from the passage and question.
        Ensure you capture:
        - Entities (e.g., people, teams, locations)
        - Numerical values (e.g., scores, counts, measurements)
        - Dates and time-related information
        - Relationships between entities and numbers
        Organize the extracted information clearly for further reasoning.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine its type and reasoning steps
        question_analysis_instruction = f"""
        Analyze the question to determine its type and reasoning requirements. Specifically:
        - Identify if the question involves arithmetic operations, counting, comparison, selection, or span extraction.
        - Outline the specific reasoning steps needed to answer the question.
        - Use the following extracted information as context: {extracted_info}
        Provide a clear classification of the question type and the reasoning plan.
        """
        question_analysis = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Execute parallel reasoning paths based on question type
        arithmetic_instruction = f"""
        Perform arithmetic operations if required by the question. Use the extracted information: {extracted_info}.
        Ensure calculations are accurate and relevant to the question.
        """
        comparison_instruction = f"""
        Compare entities or values as required by the question. Use the extracted information: {extracted_info}.
        Clearly state the basis of comparison and the result.
        """
        selection_instruction = f"""
        Select the correct entity or span based on the question. Use the extracted information: {extracted_info}.
        Ensure the selection aligns with the question's intent.
        """

        # Run parallel reasoning paths
        results = await asyncio.gather(
            self.generate(instruction=arithmetic_instruction, context=self.problem_text),
            self.generate(instruction=comparison_instruction, context=self.problem_text),
            self.generate(instruction=selection_instruction, context=self.problem_text)
        )

        # Step 4: Synthesize results using Ensemble
        synthesis_instruction = f"""
        Evaluate and synthesize the following candidate solutions to select the most accurate and relevant answer:
        - Arithmetic Result: {results[0]}
        - Comparison Result: {results[1]}
        - Selection Result: {results[2]}
        Use the extracted information and question analysis to guide your decision.
        """
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=results)

        # Optional Step 5: Refine the final answer
        refinement_instruction = """
        Refine the final answer to ensure clarity, correctness, and completeness. Address any ambiguities or inconsistencies.
        """
        refined_answer = await self.revise(instruction=refinement_instruction, context=final_answer)

        return refined_answer