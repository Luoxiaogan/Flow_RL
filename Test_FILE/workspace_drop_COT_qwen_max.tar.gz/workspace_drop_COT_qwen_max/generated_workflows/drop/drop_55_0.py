# Workflow ID: drop_55_0
# Benchmark: drop
# Data Indices: [251, 467]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information from the passage
        extraction_instruction = (
            "Extract all numerical values, entities, and relationships mentioned in the passage. "
            "Include units (e.g., degrees Celsius, millimeters) where applicable. "
            "Format the output as a structured list."
        )
        entities_and_numbers = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the question to determine reasoning type
        question_analysis_instruction = (
            f"Given the extracted information: {entities_and_numbers}\n"
            "Analyze the question and determine the type of reasoning required (e.g., arithmetic, comparison, span extraction). "
            "Provide a detailed breakdown of the reasoning steps needed to answer the question."
        )
        reasoning_plan = await self.generate(instruction=question_analysis_instruction, context=self.problem_text)

        # Step 3: Execute reasoning steps
        reasoning_execution_instruction = (
            f"Based on the extracted information: {entities_and_numbers}\n"
            f"And the reasoning plan: {reasoning_plan}\n"
            "Perform the necessary reasoning steps to compute the answer. "
            "Ensure all calculations and comparisons are explicitly shown."
        )
        reasoning_result = await self.generate(instruction=reasoning_execution_instruction, context=self.problem_text)

        # Step 4: Validate the computed answer
        validation_instruction = (
            f"Validate the computed result: {reasoning_result}\n"
            "Ensure it aligns with the original passage and question. "
            "If discrepancies are found, explain them and suggest corrections."
        )
        validated_answer = await self.revise(instruction=validation_instruction, context=reasoning_result)

        # Step 5: Handle multiple reasoning paths (if applicable)
        # Generate alternative reasoning paths in parallel
        alternative_reasoning_1 = await self.generate(
            instruction="Solve the problem using an alternative reasoning approach.",
            context=self.problem_text
        )
        alternative_reasoning_2 = await self.generate(
            instruction="Solve the problem using another alternative reasoning approach.",
            context=self.problem_text
        )

        # Use Ensemble to select the best answer
        ensemble_instruction = (
            "Compare the following reasoning results and select the most accurate answer:\n"
            f"1. {validated_answer}\n"
            f"2. {alternative_reasoning_1}\n"
            f"3. {alternative_reasoning_2}\n"
            "Explain your decision."
        )
        final_answer = await self.ensemble(
            instruction=ensemble_instruction,
            contexts=[validated_answer, alternative_reasoning_1, alternative_reasoning_2]
        )

        return final_answer