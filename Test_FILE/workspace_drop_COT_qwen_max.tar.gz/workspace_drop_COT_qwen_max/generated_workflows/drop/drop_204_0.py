# Workflow ID: drop_204_0
# Benchmark: drop
# Data Indices: [708, 586]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information from the passage
        extract_instruction = (
            "Extract all numerical values, entities, and relationships from the passage. "
            "Ensure you capture every instance of relevant information, including counts, measurements, "
            "and associations between entities and numbers. Format your response clearly, grouping related data."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Interpret the question to determine the required reasoning type
        interpret_instruction = (
            f"Given the following extracted information: {extracted_info}\n"
            "Interpret the question to determine what type of reasoning is required. "
            "Identify whether the task involves arithmetic operations, counting, comparison, or span extraction. "
            "Provide a clear explanation of the reasoning steps needed to answer the question."
        )
        question_intent = await self.generate(instruction=interpret_instruction, context=self.problem_text)

        # Step 3: Perform the required reasoning or calculation
        reasoning_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            f"And the interpreted question intent: {question_intent}\n"
            "Perform the necessary reasoning or calculation to answer the question. "
            "If the task involves arithmetic, ensure you associate numbers with their respective entities and perform the operation. "
            "If the task involves span extraction, identify the exact text span that answers the question. "
            "Explain your reasoning process step by step."
        )
        reasoning_result = await self.generate(instruction=reasoning_instruction, context=self.problem_text)

        # Step 4: Validate and refine the answer
        refine_instruction = (
            f"Review the following reasoning result: {reasoning_result}\n"
            "Critique and refine the answer to ensure accuracy. Address any ambiguities, implicit information, "
            "or potential errors in the reasoning process. Provide a revised and polished answer."
        )
        refined_answer = await self.revise(instruction=refine_instruction, context=reasoning_result)

        # Step 5: Summarize the final answer
        summarize_instruction = (
            f"Condense the following refined answer: {refined_answer}\n"
            "Produce a concise and clear final answer suitable for submission. Ensure the answer directly addresses the question."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_answer)

        return final_answer