# Workflow ID: high_level_math_ganluo_434_0
# Benchmark: high_level_math_ganluo
# Data Indices: [919, 239]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all key information from the problem, including variables, equations, "
            "constraints, and the desired output. Organize the information clearly."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Propose multiple solution strategies
        strategy_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Propose at least three distinct solution strategies. For each strategy, explain the reasoning, "
            "the mathematical techniques involved, and how it addresses the problem's requirements."
        )
        strategies = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Execute multiple approaches in parallel
        approaches = [
            f"Using the following strategy:\n{strategy}\nSolve the problem step by step."
            for strategy in strategies.split("\n\n")  # Assuming strategies are separated by double newlines
        ]
        results = await asyncio.gather(
            *[self.generate(instruction=approach, context=self.problem_text) for approach in approaches]
        )

        # Step 4: Select the best solution using Ensemble
        ensemble_instruction = (
            "Evaluate the following candidate solutions. Select the best one based on correctness, "
            "completeness, and adherence to the problem's constraints. If none are satisfactory, "
            "explain why and suggest improvements."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 5: Refine the selected solution
        refinement_instruction = (
            "Refine the following solution to ensure clarity, correctness, and alignment with the problem's requirements. "
            "Correct any errors, improve explanations, and format the solution professionally."
        )
        final_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        return final_solution