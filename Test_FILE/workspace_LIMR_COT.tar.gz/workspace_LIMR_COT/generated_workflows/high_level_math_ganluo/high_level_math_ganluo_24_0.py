# Workflow ID: high_level_math_ganluo_24_0
# Benchmark: high_level_math_ganluo
# Data Indices: [960, 506]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key components from the problem
        extraction_instruction = (
            "Extract all key components from the problem, including variables, constants, relationships, "
            "constraints, and any specific requirements. Organize the information clearly for subsequent steps."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        algebraic_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Solve the problem algebraically. Provide step-by-step reasoning and ensure all constraints are satisfied."
        )
        geometric_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Solve the problem geometrically. Include diagrams or visual reasoning if applicable."
        )
        combinatorial_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Solve the problem using combinatorial methods. Consider counting principles, recursive structures, or generating functions."
        )

        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and synthesize the best solution
        ensemble_instruction = (
            "Evaluate the provided candidate solutions based on correctness, clarity, and adherence to problem constraints. "
            "Select the best solution or synthesize a new one if necessary."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 4: Refine the selected solution
        refinement_instruction = (
            "Critique the solution for mathematical rigor, clarity, and completeness. Refine it to ensure it satisfies all problem constraints."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the final answer
        summary_instruction = (
            "Condense the refined solution into a concise, well-structured answer. Ensure it directly addresses the problem statement."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer