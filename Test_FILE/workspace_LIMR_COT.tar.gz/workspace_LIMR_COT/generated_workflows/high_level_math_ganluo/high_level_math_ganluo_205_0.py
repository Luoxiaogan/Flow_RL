# Workflow ID: high_level_math_ganluo_205_0
# Benchmark: high_level_math_ganluo
# Data Indices: [583, 706]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information and understand the problem
        extract_instruction = """
        Carefully analyze the problem statement. Identify:
        - What is being asked (the goal)
        - Key numerical values or constraints
        - Relevant mathematical concepts or structures
        - Any implicit assumptions or conditions
        Organize this information clearly and concisely.
        """
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Generate multiple candidate solutions in parallel
        approach_1_instruction = f"""
        Solve the problem using an algebraic approach. Consider:
        - Setting up equations or expressions based on {extracted_info}
        - Simplifying or manipulating these expressions systematically
        - Ensuring all constraints are satisfied
        Provide a detailed step-by-step solution.
        """

        approach_2_instruction = f"""
        Solve the problem using a geometric or combinatorial approach. Consider:
        - Visualizing the problem if applicable
        - Counting or arranging elements systematically
        - Leveraging symmetry or patterns to simplify calculations
        Provide a detailed step-by-step solution.
        """

        approach_3_instruction = f"""
        Solve the problem using number theory or modular arithmetic. Consider:
        - Analyzing divisibility, remainders, or cyclic patterns
        - Applying properties of primes, gcd, or lcm if relevant
        - Using modular arithmetic to simplify computations
        Provide a detailed step-by-step solution.
        """

        # Execute the three approaches in parallel
        candidate_solutions = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text),
            self.generate(instruction=approach_3_instruction, context=self.problem_text)
        )

        # Step 3: Refine each candidate solution
        refine_instruction = """
        Critically evaluate the provided solution. Check for:
        - Mathematical correctness
        - Logical consistency
        - Clarity of explanation
        - Satisfaction of all problem constraints
        Revise and improve the solution where necessary.
        """
        refined_solutions = await asyncio.gather(
            *[self.revise(instruction=refine_instruction, context=solution) for solution in candidate_solutions]
        )

        # Step 4: Synthesize the best solution
        ensemble_instruction = """
        Compare the provided solutions and select the best one. Consider:
        - Mathematical rigor and correctness
        - Simplicity and elegance of the approach
        - Clarity of explanation
        - Completeness in addressing all problem constraints
        If multiple solutions are equally valid, merge their strengths into a single coherent solution.
        """
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_solutions)

        # Step 5: Summarize the final solution for clarity
        summarize_instruction = """
        Condense the solution into a clear and concise format. Include:
        - The final answer
        - Key steps or reasoning
        - Any important observations or insights
        Ensure the summary is easy to understand and directly addresses the problem.
        """
        summarized_solution = await self.summarize(instruction=summarize_instruction, context=final_solution)

        return summarized_solution