# Workflow ID: high_level_math_ganluo_383_0
# Benchmark: high_level_math_ganluo
# Data Indices: [10, 917]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key elements of the problem
        extraction_instruction = (
            "Extract all key elements from the problem, including variables, constants, "
            "constraints, relationships, and any implicit assumptions. Organize the extracted "
            "information into categories such as 'variables', 'equations', 'constraints', and 'goals'."
        )
        key_elements = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple candidate solutions in parallel
        candidate_instructions = [
            f"Using an algebraic approach, solve the problem based on the following extracted information: {key_elements}.",
            f"Using a combinatorial or probabilistic approach, solve the problem based on the following extracted information: {key_elements}.",
            f"Using geometric reasoning, solve the problem based on the following extracted information: {key_elements}."
        ]
        candidate_solutions = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in candidate_instructions]
        )

        # Step 3: Refine each candidate solution
        refinement_instruction = (
            "Critique and refine the given solution. Ensure it satisfies all constraints, is mathematically rigorous, "
            "and is presented in a clear and logical manner. Highlight any assumptions or steps that require clarification."
        )
        refined_solutions = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction, context=sol) for sol in candidate_solutions]
        )

        # Step 4: Ensemble decision-making to select the best solution
        ensemble_instruction = (
            "Compare the provided solutions and select the one that is most rigorous, complete, and aligned with the problem's requirements. "
            "If multiple solutions are valid, synthesize them into a single coherent solution."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_solutions)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the solution into a concise and well-structured format. Include only the essential steps, results, "
            "and any necessary explanations. Ensure the final output is easy to understand and directly addresses the problem."
        )
        summarized_solution = await self.summarize(instruction=summary_instruction, context=final_solution)

        return summarized_solution