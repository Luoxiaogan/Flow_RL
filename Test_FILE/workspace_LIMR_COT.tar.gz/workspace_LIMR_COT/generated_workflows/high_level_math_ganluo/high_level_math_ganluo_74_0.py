# Workflow ID: high_level_math_ganluo_74_0
# Benchmark: high_level_math_ganluo
# Data Indices: [455, 819]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information and understand the problem
        extraction_instruction = (
            "Extract all key information from the problem statement, including variables, constants, "
            "constraints, and the type of mathematical domain (e.g., algebra, geometry, combinatorics). "
            "Provide a structured summary of the problem's requirements and goals."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        approach_instructions = [
            f"Using algebraic techniques, solve the problem step by step. Problem details: {extracted_info}",
            f"Using geometric reasoning, solve the problem step by step. Problem details: {extracted_info}",
            f"Using combinatorial analysis, solve the problem step by step. Problem details: {extracted_info}",
            f"Using number theory principles, solve the problem step by step. Problem details: {extracted_info}"
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Evaluate and select the best approach
        ensemble_instruction = (
            "Evaluate the provided solution approaches based on correctness, simplicity, and alignment "
            "with the problem constraints. Select the most promising approach and provide a justification."
        )
        best_approach = await self.ensemble(instruction=ensemble_instruction, contexts=approaches)

        # Step 4: Refine the selected approach
        refinement_instruction = (
            "Critically analyze and refine the selected solution approach. Address any gaps, ambiguities, "
            "or errors. Ensure the solution satisfies all problem constraints and edge cases."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_approach)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the refined solution into a concise and clear format. Include the final answer "
            "and a brief explanation of the reasoning process."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_summary