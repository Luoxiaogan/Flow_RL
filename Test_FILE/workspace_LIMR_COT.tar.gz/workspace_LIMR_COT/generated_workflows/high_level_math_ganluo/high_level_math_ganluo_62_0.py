# Workflow ID: high_level_math_ganluo_62_0
# Benchmark: high_level_math_ganluo
# Data Indices: [498, 927]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Problem Understanding and Decomposition
        decomposition_instruction = (
            "Analyze the problem statement carefully. Identify key components such as variables, constraints, "
            "and the type of mathematical reasoning required (e.g., algebraic, geometric, combinatorial). "
            "Break the problem into smaller, manageable sub-problems."
        )
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Solution Path Exploration
        algebraic_instruction = (
            f"Based on the following analysis: {decomposition} "
            "Solve the problem using algebraic techniques. Include all steps and intermediate results."
        )
        geometric_instruction = (
            f"Based on the following analysis: {decomposition} "
            "Solve the problem using geometric reasoning. Include all steps and intermediate results."
        )
        combinatorial_instruction = (
            f"Based on the following analysis: {decomposition} "
            "Solve the problem using combinatorial methods. Include all steps and intermediate results."
        )

        # Generate candidate solutions in parallel
        candidates = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Evaluation and Selection
        evaluation_instruction = (
            "Evaluate the following candidate solutions and select the best one. "
            "Consider correctness, completeness, and adherence to the problem constraints."
        )
        best_solution = await self.ensemble(instruction=evaluation_instruction, contexts=candidates)

        # Step 4: Refinement and Verification
        refinement_instruction = (
            "Review the selected solution carefully. Ensure it is clear, correct, and mathematically rigorous. "
            "Revise any unclear or incorrect parts."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarization
        summary_instruction = (
            "Summarize the final solution concisely. Ensure the answer is well-structured and easy to understand."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer