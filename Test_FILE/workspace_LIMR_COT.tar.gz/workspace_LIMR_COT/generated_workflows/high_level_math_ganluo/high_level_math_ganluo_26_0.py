# Workflow ID: high_level_math_ganluo_26_0
# Benchmark: high_level_math_ganluo
# Data Indices: [243, 152]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract critical information and categorize the problem
        extraction_instruction = (
            "Extract all numerical values, variables, equations, constraints, and the specific question being asked. "
            "Categorize the problem into one or more mathematical domains (e.g., algebra, geometry, combinatorics)."
        )
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        approach_instructions = [
            f"Solve the problem using algebraic manipulation. Incorporate the following extracted information: {extraction}",
            f"Solve the problem using geometric reasoning. Incorporate the following extracted information: {extraction}",
            f"Solve the problem using combinatorial analysis. Incorporate the following extracted information: {extraction}",
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Refine each candidate solution
        refinement_instructions = [
            "Critique and improve this solution. Identify logical gaps, computational errors, or overlooked constraints.",
        ] * len(approaches)
        refined_solutions = await asyncio.gather(
            *[self.revise(instruction=refinement_instructions[i], context=approaches[i]) for i in range(len(approaches))]
        )

        # Step 4: Ensemble decision-making to select the best solution
        ensemble_instruction = (
            "Compare and synthesize the following candidate solutions. Select the most elegant, efficient, and correct solution. "
            "Ensure it satisfies all problem constraints and answers the question accurately."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_solutions)

        # Step 5: Final verification of the chosen solution
        verification_instruction = (
            "Verify that this solution satisfies all constraints and answers the question correctly. "
            "Provide a step-by-step justification for why this solution is valid."
        )
        final_verification = await self.generate(instruction=verification_instruction, context=best_solution)

        return final_verification