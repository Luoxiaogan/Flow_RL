# Workflow ID: high_level_math_ganluo_186_0
# Benchmark: high_level_math_ganluo
# Data Indices: [948, 750]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract critical components from the problem
        extraction_instruction = (
            "Extract all key components from the problem, including variables, equations, constraints, "
            "and the specific question being asked. Identify any patterns, symmetries, or special structures "
            "that might be relevant to solving the problem. Format the output clearly with labeled sections."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        approach_instructions = [
            f"Using the extracted information: {extracted_info}, solve the problem using algebraic manipulation. "
            "Provide step-by-step reasoning and ensure all constraints are satisfied.",

            f"Using the extracted information: {extracted_info}, solve the problem using geometric reasoning. "
            "If applicable, convert the problem into a geometric representation and analyze it accordingly.",

            f"Using the extracted information: {extracted_info}, solve the problem using combinatorial analysis. "
            "Identify counting principles, recursive structures, or probabilistic methods that apply.",

            f"Using the extracted information: {extracted_info}, solve the problem using number theory. "
            "Focus on divisibility, modular arithmetic, or Diophantine equations as needed."
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Evaluate and select the best approach
        ensemble_instruction = (
            "Evaluate the provided solution approaches and select the most promising one. Consider clarity, "
            "mathematical rigor, and alignment with the problem's constraints. Provide a justification for your choice."
        )
        best_approach = await self.ensemble(instruction=ensemble_instruction, contexts=approaches)

        # Step 4: Refine the selected approach
        refinement_instruction = (
            "Critique and refine the selected solution approach. Address any gaps, inconsistencies, or inefficiencies. "
            "Ensure the solution is mathematically sound and satisfies all constraints."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_approach)

        # Step 5: Compute the final solution and verify it
        final_solution_instruction = (
            "Compute the final solution based on the refined approach. Verify that the solution satisfies all "
            "constraints and makes mathematical sense. Present the result in a clear and concise format."
        )
        final_solution = await self.generate(instruction=final_solution_instruction, context=refined_solution)

        # Optional: Summarize the final solution
        summary_instruction = (
            "Condense the final solution into a concise and clear format. Highlight the key steps and the result."
        )
        summarized_solution = await self.summarize(instruction=summary_instruction, context=final_solution)

        return summarized_solution