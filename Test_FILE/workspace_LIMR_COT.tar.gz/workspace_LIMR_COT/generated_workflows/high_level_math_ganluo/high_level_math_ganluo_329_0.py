# Workflow ID: high_level_math_ganluo_329_0
# Benchmark: high_level_math_ganluo
# Data Indices: [464, 894]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Problem Understanding & Decomposition
        decomposition_instruction = (
            "Carefully analyze the problem statement to identify all key components, including variables, "
            "constraints, relationships, and the goal. Provide a structured breakdown of the problem, "
            "highlighting any mathematical structures or patterns that can guide the solution process."
        )
        problem_decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Solution Exploration (Parallel Approaches)
        algebraic_instruction = (
            f"Based on the problem decomposition: {problem_decomposition}\n"
            "Solve the problem using algebraic methods. Focus on equations, inequalities, and functional relationships. "
            "Provide a step-by-step solution, ensuring all steps are mathematically rigorous."
        )
        combinatorial_instruction = (
            f"Based on the problem decomposition: {problem_decomposition}\n"
            "Solve the problem using combinatorial methods. Consider counting principles, permutations, combinations, "
            "and recursive structures. Provide a clear and logical explanation of your reasoning."
        )
        geometric_instruction = (
            f"Based on the problem decomposition: {problem_decomposition}\n"
            "Solve the problem using geometric methods. Analyze shapes, areas, volumes, and spatial relationships. "
            "Include diagrams or coordinate transformations if applicable."
        )

        # Execute parallel solution paths
        algebraic_solution, combinatorial_solution, geometric_solution = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text)
        )

        # Step 3: Evaluation & Synthesis
        evaluation_instruction = (
            "Compare the following solutions: \n"
            f"1. Algebraic Solution: {algebraic_solution}\n"
            f"2. Combinatorial Solution: {combinatorial_solution}\n"
            f"3. Geometric Solution: {geometric_solution}\n"
            "Evaluate each solution's correctness, clarity, and alignment with the problem requirements. "
            "Select the best solution or synthesize elements from multiple solutions if needed."
        )
        best_solution = await self.ensemble(
            instruction=evaluation_instruction,
            contexts=[algebraic_solution, combinatorial_solution, geometric_solution]
        )

        # Step 4: Refinement (if necessary)
        refinement_instruction = (
            f"Review the selected solution: {best_solution}\n"
            "Identify any gaps, ambiguities, or errors. Refine the solution to ensure it is complete, accurate, "
            "and well-structured. Provide the final refined solution."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Final Answer Extraction
        summarization_instruction = (
            f"Condense the refined solution: {refined_solution}\n"
            "Extract the final answer clearly and concisely, ensuring it directly addresses the problem's question."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_solution)

        return final_answer