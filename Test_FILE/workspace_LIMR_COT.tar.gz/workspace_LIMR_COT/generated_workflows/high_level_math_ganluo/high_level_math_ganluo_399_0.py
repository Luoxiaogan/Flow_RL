# Workflow ID: high_level_math_ganluo_399_0
# Benchmark: high_level_math_ganluo
# Data Indices: [745, 414]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all numerical values, variables, relationships, and constraints from the problem. "
            "Identify what the question is asking for and summarize the key elements needed to solve it."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple candidate solutions in parallel
        algebraic_instruction = (
            f"Given the extracted information: {extracted_info}, solve the problem using algebraic methods. "
            "Include all steps and justify each transformation."
        )
        geometric_instruction = (
            f"Given the extracted information: {extracted_info}, solve the problem using geometric reasoning. "
            "Include diagrams if necessary and explain all steps."
        )
        combinatorial_instruction = (
            f"Given the extracted information: {extracted_info}, solve the problem using combinatorial or probabilistic methods. "
            "Clearly state assumptions and compute all required values."
        )

        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Refine each candidate solution
        refinement_instruction = (
            "Critique and refine the given solution. Check for logical consistency, adherence to constraints, "
            "and computational accuracy. Suggest improvements if necessary."
        )
        refined_results = await asyncio.gather(
            self.revise(instruction=refinement_instruction, context=results[0]),
            self.revise(instruction=refinement_instruction, context=results[1]),
            self.revise(instruction=refinement_instruction, context=results[2])
        )

        # Step 4: Ensemble decision-making
        ensemble_instruction = (
            "Compare the following solutions and select the best one based on correctness, clarity, and alignment "
            "with the problem's requirements. If possible, combine insights from multiple solutions."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_results)

        # Step 5: Summarize the final answer
        summary_instruction = (
            "Condense the given solution into a concise, well-formatted answer that directly addresses the problem's question. "
            "Ensure the answer is clear, precise, and complete."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=final_solution)

        return final_answer