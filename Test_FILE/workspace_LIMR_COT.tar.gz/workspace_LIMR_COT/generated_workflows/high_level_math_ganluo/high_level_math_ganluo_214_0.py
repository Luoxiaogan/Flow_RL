# Workflow ID: high_level_math_ganluo_214_0
# Benchmark: high_level_math_ganluo
# Data Indices: [493, 661]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Problem Understanding and Decomposition
        decomposition_instruction = (
            "Analyze the problem statement carefully. Identify all variables, constraints, "
            "and relationships. Provide a structured breakdown of the problem, including "
            "key mathematical concepts involved (e.g., algebra, geometry, combinatorics)."
        )
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Solution Exploration (Parallel Approaches)
        approach_1_instruction = (
            f"Based on the problem decomposition: {decomposition}, develop an algebraic approach "
            "to solve the problem. Include step-by-step reasoning."
        )
        approach_2_instruction = (
            f"Based on the problem decomposition: {decomposition}, develop a combinatorial or probabilistic approach "
            "to solve the problem. Include step-by-step reasoning."
        )
        approach_3_instruction = (
            f"Based on the problem decomposition: {decomposition}, develop a geometric or number-theoretic approach "
            "to solve the problem. Include step-by-step reasoning."
        )

        approaches = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text),
            self.generate(instruction=approach_3_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and Select Best Approach
        evaluation_instruction = (
            "Compare the following solution approaches and select the most promising one. "
            "Consider clarity, correctness, and efficiency. Provide a justification for your choice."
        )
        best_approach = await self.ensemble(instruction=evaluation_instruction, contexts=approaches)

        # Step 4: Detailed Execution of Selected Approach
        execution_instruction = (
            f"Execute the selected approach: {best_approach}. Break it into smaller steps, "
            "ensuring each step logically follows from the previous one. Include intermediate results."
        )
        detailed_solution = await self.generate(instruction=execution_instruction, context=self.problem_text)

        # Step 5: Refinement and Verification
        refinement_instruction = (
            "Review the detailed solution for accuracy and completeness. Correct any errors, "
            "clarify ambiguous steps, and ensure all constraints are satisfied."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=detailed_solution)

        # Step 6: Summarize the Final Answer
        summary_instruction = (
            "Summarize the solution, highlighting the final answer and the key reasoning steps. "
            "Ensure the summary is concise but complete."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_summary