# Workflow ID: high_level_math_ganluo_122_0
# Benchmark: high_level_math_ganluo
# Data Indices: [744, 207]

```python
class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Problem Decomposition
        decomposition_instruction = (
            "Analyze the problem to identify its key components, mathematical constructs, "
            "and relationships between them. Extract all relevant information, including "
            "equations, constraints, and conditions. Organize the findings systematically."
        )
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Approach Generation
        approach_instruction_template = (
            "Based on the following decomposition: {decomposition}, "
            "generate a detailed solution approach for solving the problem. "
            "Consider multiple methods, including algebraic manipulation, geometric reasoning, "
            "combinatorial analysis, and number theory techniques. Ensure the approach is "
            "mathematically sound and addresses all constraints."
        )
        approach_instructions = [
            approach_instruction_template.format(decomposition=decomposition),
            approach_instruction_template.format(decomposition=decomposition) + " Focus on alternative methods.",
        ]
        approaches = await asyncio.gather(
            self.generate(instruction=approach_instructions[0], context=self.problem_text),
            self.generate(instruction=approach_instructions[1], context=self.problem_text),
        )

        # Step 3: Solution Refinement
        refine_instruction_template = (
            "Refine the following solution approach: {approach}. "
            "Ensure it is mathematically rigorous, satisfies all constraints, and addresses "
            "any edge cases. Provide detailed reasoning and justification for each step."
        )
        refined_approaches = await asyncio.gather(
            self.revise(instruction=refine_instruction_template.format(approach=approaches[0]), context=approaches[0]),
            self.revise(instruction=refine_instruction_template.format(approach=approaches[1]), context=approaches[1]),
        )

        # Step 4: Ensemble Decision
        ensemble_instruction = (
            "Evaluate the following refined solutions: {solution1} and {solution2}. "
            "Select the most robust and efficient solution, or combine insights from both if applicable. "
            "Provide clear criteria for your decision, including correctness, simplicity, and computational efficiency."
        )
        final_solution = await self.ensemble(
            instruction=ensemble_instruction.format(solution1=refined_approaches[0], solution2=refined_approaches[1]),
            contexts=refined_approaches,
        )

        # Step 5: Final Verification
        summarize_instruction = (
            "Summarize the final solution: {final_solution}. Ensure it is concise, complete, "
            "and directly addresses the original problem. Verify that the solution satisfies "
            "all constraints and conditions."
        )
        verified_solution = await self.summarize(
            instruction=summarize_instruction.format(final_solution=final_solution),
            context=final_solution,
        )

        return verified_solution
```