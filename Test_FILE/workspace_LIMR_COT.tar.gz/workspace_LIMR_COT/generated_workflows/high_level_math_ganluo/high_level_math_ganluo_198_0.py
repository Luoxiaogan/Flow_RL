# Workflow ID: high_level_math_ganluo_198_0
# Benchmark: high_level_math_ganluo
# Data Indices: [124, 389]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all numerical values, variables, relationships, and constraints from the problem. "
            "Identify the type of mathematical reasoning required (e.g., algebraic, combinatorial, geometric). "
            "Provide a structured summary of the problem's key components."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate initial solution approaches
        initial_solution_instruction = (
            f"Based on the extracted information: {extracted_info}, "
            "propose one or more solution approaches. Consider multiple strategies if applicable, "
            "such as algebraic manipulation, combinatorial analysis, or geometric reasoning. "
            "For each approach, provide a brief outline of the reasoning process."
        )
        initial_solutions = await self.generate(instruction=initial_solution_instruction, context=self.problem_text)

        # Step 3: Parallel exploration of multiple approaches
        approaches = initial_solutions.split("\n\n")  # Split into individual approaches
        tasks = []
        for approach in approaches:
            approach_instruction = (
                f"Develop this approach in detail: {approach}. "
                "Ensure all steps are mathematically sound and logically consistent. "
                "If calculations are involved, perform them step by step."
            )
            tasks.append(self.generate(instruction=approach_instruction, context=self.problem_text))
        
        parallel_results = await asyncio.gather(*tasks)

        # Step 4: Evaluate and select the best approach
        ensemble_instruction = (
            "Compare the following candidate solutions and select the most mathematically rigorous and efficient one. "
            "Ensure the chosen solution satisfies all constraints and conditions stated in the original problem."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=parallel_results)

        # Step 5: Refine the selected solution
        refinement_instruction = (
            "Critique and refine the following solution: {best_solution}. "
            "Check for mathematical accuracy, logical consistency, and clarity. "
            "Correct any errors and improve the explanation if needed."
        )
        refined_solution = await self.revise(instruction=refinement_instruction.format(best_solution=best_solution), context=self.problem_text)

        # Step 6: Summarize the final solution
        summary_instruction = (
            "Summarize the following solution concisely while preserving all key steps and the final answer: {refined_solution}."
        )
        final_summary = await self.summarize(instruction=summary_instruction.format(refined_solution=refined_solution), context=self.problem_text)

        return final_summary