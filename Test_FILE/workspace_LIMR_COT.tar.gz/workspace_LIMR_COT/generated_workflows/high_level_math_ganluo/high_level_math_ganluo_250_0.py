# Workflow ID: high_level_math_ganluo_250_0
# Benchmark: high_level_math_ganluo
# Data Indices: [178, 101]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio
        
        # Step 1: Extract and understand the problem components
        extraction_instruction = (
            "Extract all numerical values, variables, constraints, and relationships from the problem. "
            "Identify the type of mathematical domain (e.g., algebra, geometry, number theory) and any advanced techniques required."
        )
        problem_components = await self.generate(instruction=extraction_instruction, context=self.problem_text)
        
        # Step 2: Generate multiple solution approaches
        approach_instructions = [
            f"Develop an algebraic approach to solve the problem. Consider equations, inequalities, and functional relationships. Problem context: {problem_components}",
            f"Develop a geometric approach to solve the problem. Consider shapes, angles, areas, and coordinate transformations. Problem context: {problem_components}",
            f"Develop a combinatorial or number-theoretic approach to solve the problem. Consider counting techniques, modular arithmetic, and divisibility rules. Problem context: {problem_components}"
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )
        
        # Step 3: Evaluate and select the best approach
        ensemble_instruction = (
            "Compare the following approaches and select the most promising one based on clarity, feasibility, and alignment with the problem constraints. "
            "Provide a rationale for your choice."
        )
        best_approach = await self.ensemble(instruction=ensemble_instruction, contexts=approaches)
        
        # Step 4: Execute the selected approach step-by-step
        execution_instruction = (
            f"Execute the following approach step-by-step, performing all necessary calculations and derivations. Ensure all constraints are satisfied. Approach: {best_approach}"
        )
        solution = await self.generate(instruction=execution_instruction, context=self.problem_text)
        
        # Step 5: Validate and refine the solution
        refinement_instruction = (
            "Critique the solution for correctness, completeness, and adherence to the problem constraints. "
            "Address any gaps in reasoning or missing steps. Refine the solution if necessary."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=solution)
        
        # Step 6: Summarize the final solution
        summary_instruction = (
            "Summarize the solution in a concise and clear format. Include the final answer and key reasoning steps."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_solution)
        
        return final_summary