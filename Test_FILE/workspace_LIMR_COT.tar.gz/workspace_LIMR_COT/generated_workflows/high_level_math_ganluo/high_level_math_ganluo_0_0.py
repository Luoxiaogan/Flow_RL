# Workflow ID: high_level_math_ganluo_0_0
# Benchmark: high_level_math_ganluo
# Data Indices: [413, 211]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Carefully analyze the problem statement and extract all relevant information, "
            "including variables, constraints, and relationships. Organize this information "
            "in a structured format for further processing."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Propose multiple solution paths
        solution_paths_instruction = (
            f"Based on the extracted information: {extracted_info}, propose at least three distinct "
            "approaches to solve the problem. Each approach should include a clear explanation of the reasoning, "
            "the mathematical techniques involved, and any assumptions made."
        )
        solution_paths = await self.generate(instruction=solution_paths_instruction, context=self.problem_text)

        # Step 3: Refine each solution path
        refinement_tasks = []
        for i in range(3):  # Assuming 3 paths were generated
            refine_instruction = (
                f"Review the following solution path critically: {solution_paths}. Identify any logical gaps, "
                "errors, or areas for improvement. Suggest refinements to make the solution more rigorous and complete."
            )
            refinement_tasks.append(self.revise(instruction=refine_instruction, context=solution_paths))

        refined_solutions = await asyncio.gather(*refinement_tasks)

        # Step 4: Evaluate and select the best solution
        evaluation_instruction = (
            "Compare the following refined solution paths and determine which one is the most rigorous, "
            "efficient, and satisfies all constraints of the problem. Provide a justification for your choice."
        )
        best_solution = await self.ensemble(instruction=evaluation_instruction, contexts=refined_solutions)

        # Step 5: Summarize the final answer
        summary_instruction = (
            "Condense the selected solution into a concise and clear final answer. Ensure that the answer "
            "is presented in the required format and includes all necessary details."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=best_solution)

        return final_answer