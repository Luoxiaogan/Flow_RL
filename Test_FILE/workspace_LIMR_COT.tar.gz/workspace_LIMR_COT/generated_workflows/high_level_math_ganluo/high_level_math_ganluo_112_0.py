# Workflow ID: high_level_math_ganluo_112_0
# Benchmark: high_level_math_ganluo
# Data Indices: [312, 965]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Problem Decomposition
        decomposition_instruction = (
            "Analyze the given problem to identify its core mathematical structure, "
            "including variables, constraints, and relationships. Highlight any special "
            "conditions or edge cases that need consideration. Organize the information "
            "in a structured format."
        )
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Generate Multiple Approaches
        approach_instructions = [
            "Develop an algebraic solution strategy for the problem. Focus on equations, "
            "transformations, and simplifications that lead to the solution.",
            "Develop a geometric or visual interpretation of the problem. Consider how "
            "spatial relationships or diagrams can aid in solving it.",
            "Develop a combinatorial or probabilistic approach. Focus on counting methods, "
            "recursive structures, or expected value calculations if applicable."
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=decomposition) for instr in approach_instructions]
        )

        # Step 3: Evaluate and Select Best Approach
        evaluation_instruction = (
            "Compare the provided solution approaches. Evaluate each based on clarity, "
            "feasibility, alignment with the problem's constraints, and computational simplicity. "
            "Select the most promising approach and justify your choice."
        )
        best_approach = await self.ensemble(instruction=evaluation_instruction, contexts=approaches)

        # Step 4: Refine and Verify the Solution
        refinement_instruction = (
            "Critically analyze the selected approach. Identify any errors, ambiguities, "
            "or areas for improvement. Refine the solution to ensure correctness and completeness. "
            "Verify that all problem constraints are satisfied."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_approach)

        # Step 5: Summarize the Final Solution
        summary_instruction = (
            "Condense the refined solution into a concise and clear format. Ensure that "
            "the final answer is explicitly stated and all key steps are summarized."
        )
        final_solution = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_solution