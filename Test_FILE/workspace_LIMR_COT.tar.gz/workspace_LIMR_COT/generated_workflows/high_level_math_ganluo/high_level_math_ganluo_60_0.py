# Workflow ID: high_level_math_ganluo_60_0
# Benchmark: high_level_math_ganluo
# Data Indices: [509, 871]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Problem Understanding and Decomposition
        decomposition_instruction = (
            "Analyze the problem thoroughly. Identify all variables, constraints, "
            "and relationships. Determine the type of mathematical reasoning required "
            "(e.g., algebraic, geometric, combinatorial). Provide a structured summary."
        )
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Solution Path Exploration
        algebraic_instruction = (
            f"Based on the decomposition: {decomposition}, solve the problem using algebraic reasoning. "
            "Focus on equations, transformations, and logical deductions."
        )
        geometric_instruction = (
            f"Based on the decomposition: {decomposition}, solve the problem using geometric reasoning. "
            "Focus on shapes, spatial relationships, and visual interpretations."
        )
        combinatorial_instruction = (
            f"Based on the decomposition: {decomposition}, solve the problem using combinatorial reasoning. "
            "Focus on counting principles, arrangements, and probabilistic methods."
        )

        # Generate multiple solution paths in parallel
        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Refinement and Validation
        refine_instructions = [
            "Critique and refine this solution. Ensure it is logically consistent and satisfies all problem constraints.",
            "Critique and refine this solution. Ensure it is logically consistent and satisfies all problem constraints.",
            "Critique and refine this solution. Ensure it is logically consistent and satisfies all problem constraints."
        ]
        refined_results = await asyncio.gather(
            *[self.revise(instruction=refine_instructions[i], context=results[i]) for i in range(len(results))]
        )

        # Step 4: Synthesis and Final Decision
        ensemble_instruction = (
            "Compare and synthesize the following refined solutions. Select the most robust and complete solution, "
            "or combine insights from multiple approaches if necessary."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_results)

        # Step 5: Summarization
        summarize_instruction = (
            "Condense the final solution into a clear and concise format. Include all key steps and the final answer."
        )
        summary = await self.summarize(instruction=summarize_instruction, context=final_solution)

        return summary