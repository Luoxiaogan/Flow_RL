# Workflow ID: high_level_math_ganluo_178_0
# Benchmark: high_level_math_ganluo
# Data Indices: [47, 989]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio
        
        # Step 1: Problem Understanding and Decomposition
        problem_analysis = await self.generate(
            instruction="Analyze the problem to identify the mathematical domain (e.g., algebra, geometry, combinatorics), extract key variables, constraints, and the goal. Provide a structured breakdown of the problem.",
            context=self.problem_text
        )
        
        # Step 2: Generate Multiple Solution Paths
        algebraic_approach = self.generate(
            instruction=f"Using the following problem analysis: {problem_analysis}\nDevelop an algebraic approach to solve the problem. Include all steps and reasoning.",
            context=self.problem_text
        )
        combinatorial_approach = self.generate(
            instruction=f"Using the following problem analysis: {problem_analysis}\nDevelop a combinatorial approach to solve the problem. Include all steps and reasoning.",
            context=self.problem_text
        )
        geometric_approach = self.generate(
            instruction=f"Using the following problem analysis: {problem_analysis}\nDevelop a geometric approach to solve the problem. Include all steps and reasoning.",
            context=self.problem_text
        )
        
        # Execute in parallel
        approaches = await asyncio.gather(algebraic_approach, combinatorial_approach, geometric_approach)
        
        # Step 3: Evaluate and Select the Best Approach
        best_approach = await self.ensemble(
            instruction="Compare the provided solution approaches. Evaluate them based on correctness, simplicity, and alignment with the problem constraints. Select the best approach and provide a justification.",
            contexts=approaches
        )
        
        # Step 4: Refine the Selected Solution
        refined_solution = await self.revise(
            instruction=f"Refine the following solution: {best_approach}\nEnsure it is mathematically correct, handles edge cases, and adheres to all problem constraints. Improve clarity and structure.",
            context=self.problem_text
        )
        
        # Step 5: Summarize the Final Solution
        final_answer = await self.summarize(
            instruction=f"Condense the following refined solution into a concise, well-structured answer: {refined_solution}\nEnsure the final output is clear and directly addresses the problem.",
            context=self.problem_text
        )
        
        return final_answer