# Workflow ID: high_level_math_ganluo_206_0
# Benchmark: high_level_math_ganluo
# Data Indices: [420, 759]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Carefully analyze the problem statement and extract all relevant information, including "
            "numerical values, relationships, constraints, and any implicit assumptions. Organize the "
            "information in a structured format for further processing."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a high-level strategy for solving the problem
        strategy_instruction = (
            f"Based on the extracted information: {extracted_info}, determine the most appropriate "
            "mathematical approach to solve the problem. Consider multiple strategies (e.g., algebraic, "
            "geometric, combinatorial) and outline the steps required for each approach."
        )
        strategy = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Generate multiple candidate solutions in parallel
        algebraic_instruction = (
            f"Using an algebraic approach, solve the problem step by step. Ensure that all constraints "
            f"are satisfied and provide a clear explanation of each step. Extracted info: {extracted_info}."
        )
        geometric_instruction = (
            f"Using a geometric approach, solve the problem step by step. Ensure that all constraints "
            f"are satisfied and provide a clear explanation of each step. Extracted info: {extracted_info}."
        )

        # Parallel execution for independent solution attempts
        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text)
        )

        # Step 4: Select or synthesize the best solution
        ensemble_instruction = (
            "Compare the provided candidate solutions and select the best one. If both solutions are valid, "
            "synthesize a hybrid solution that combines their strengths. Ensure the final solution satisfies "
            "all constraints and is mathematically rigorous."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 5: Verify and refine the solution
        refinement_instruction = (
            "Critically evaluate the solution for correctness and completeness. Check that all constraints "
            "are satisfied and refine the solution if necessary. Provide a polished, final answer."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=final_solution)

        return refined_solution