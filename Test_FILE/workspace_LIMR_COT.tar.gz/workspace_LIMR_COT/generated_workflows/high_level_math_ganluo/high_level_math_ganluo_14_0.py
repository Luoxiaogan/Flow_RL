# Workflow ID: high_level_math_ganluo_14_0
# Benchmark: high_level_math_ganluo
# Data Indices: [82, 941]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information and decompose the problem
        extraction_instruction = (
            "Extract all key information, constraints, and goals from the problem. "
            "Identify numerical values, relationships, and any special conditions. "
            "Organize the information into categories such as 'knowns', 'unknowns', and 'constraints'."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        approach_instructions = [
            f"Using algebraic methods, solve the problem based on the following extracted information: {extracted_info}. "
            "Provide step-by-step reasoning and ensure the solution is mathematically rigorous.",

            f"Using geometric reasoning, solve the problem based on the following extracted information: {extracted_info}. "
            "Include visual representations if applicable and justify each step.",

            f"Using combinatorial or probabilistic methods, solve the problem based on the following extracted information: {extracted_info}. "
            "Clearly outline the counting principles or probability rules applied."
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Evaluate and synthesize the approaches
        ensemble_instruction = (
            "Compare the following candidate solutions and select the most correct, complete, and elegant one. "
            "Provide a justification for your choice. If multiple solutions are valid, synthesize them into a unified answer."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=approaches)

        # Step 4: Refine the selected solution
        refinement_instruction = (
            "Review the following solution and improve its clarity, accuracy, and formatting. "
            "Ensure it adheres to all problem constraints and is expressed in the simplest form."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the following solution into a concise, well-structured format suitable for presentation. "
            "Highlight the key steps and the final answer."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_summary