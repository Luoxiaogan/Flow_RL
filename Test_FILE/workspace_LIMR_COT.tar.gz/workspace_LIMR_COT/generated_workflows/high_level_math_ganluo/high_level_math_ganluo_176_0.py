# Workflow ID: high_level_math_ganluo_176_0
# Benchmark: high_level_math_ganluo
# Data Indices: [737, 322]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information and understand the problem
        problem_analysis = await self.generate(
            instruction="Extract all numerical values, variables, constraints, and goals from the problem. "
                        "Identify the mathematical domain (e.g., algebra, geometry, combinatorics) and suggest possible techniques to solve it.",
            context=self.problem_text
        )

        # Step 2: Generate multiple solution approaches in parallel
        approaches = await asyncio.gather(
            self.generate(
                instruction=f"Using the following analysis: {problem_analysis}\n"
                            "Solve the problem using algebraic manipulation. Provide step-by-step reasoning.",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"Using the following analysis: {problem_analysis}\n"
                            "Solve the problem using geometric reasoning. Provide step-by-step reasoning.",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"Using the following analysis: {problem_analysis}\n"
                            "Solve the problem using combinatorial or probabilistic methods. Provide step-by-step reasoning.",
                context=self.problem_text
            )
        )

        # Step 3: Refine each solution approach
        refined_approaches = await asyncio.gather(
            *[self.revise(
                instruction="Critique and improve the following solution. Ensure all steps are clear, logical, and correct.",
                context=approach
            ) for approach in approaches]
        )

        # Step 4: Select the best solution using Ensemble
        best_solution = await self.ensemble(
            instruction="Evaluate the following solutions based on clarity, correctness, and efficiency. "
                        "Select the best solution and provide justification for your choice.",
            contexts=refined_approaches
        )

        # Step 5: Summarize the final solution
        final_summary = await self.summarize(
            instruction="Condense the following solution into a concise summary. Highlight the key steps and the final result.",
            context=best_solution
        )

        return final_summary