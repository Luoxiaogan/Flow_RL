# Workflow ID: high_level_math_ganluo_87_0
# Benchmark: high_level_math_ganluo
# Data Indices: [7, 5]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract and Understand the Problem
        problem_understanding = await self.generate(
            instruction="Thoroughly analyze the problem statement. Identify all variables, constraints, and the goal. "
                        "Organize this information into clear categories such as 'Known Information', 'Constraints', and 'Goal'. "
                        "Ensure the output is structured and easy to reference.",
            context=self.problem_text
        )

        # Step 2: Generate Multiple Solution Approaches
        approaches = await asyncio.gather(
            self.generate(
                instruction="Develop an algebraic approach to solve the problem. Focus on equations, transformations, "
                            "and logical deductions. Ensure the reasoning is step-by-step and mathematically rigorous.",
                context=problem_understanding
            ),
            self.generate(
                instruction="Develop a geometric approach to solve the problem. Use diagrams, coordinate geometry, "
                            "or trigonometric relationships if applicable. Provide clear explanations for each step.",
                context=problem_understanding
            ),
            self.generate(
                instruction="Develop a combinatorial or number-theoretic approach to solve the problem. Focus on counting, "
                            "modular arithmetic, or recursive structures. Justify all assumptions and calculations.",
                context=problem_understanding
            )
        )

        # Step 3: Refine Each Approach
        refined_approaches = await asyncio.gather(
            *[self.revise(
                instruction=f"Review and refine the following solution approach. Check for mathematical correctness, "
                            f"adherence to constraints, and clarity of reasoning. Suggest improvements where necessary.",
                context=approach
            ) for approach in approaches]
        )

        # Step 4: Synthesize and Select the Best Solution
        final_solution = await self.ensemble(
            instruction="Compare the refined solution approaches. Evaluate them based on correctness, elegance, "
                        "and efficiency. Select the best solution or synthesize a new one that combines their strengths.",
            contexts=refined_approaches
        )

        # Step 5: Summarize the Final Solution
        summary = await self.summarize(
            instruction="Condense the final solution into a concise summary. Include the key steps, reasoning, "
                        "and the final answer. Ensure the summary is clear and easy to understand.",
            context=final_solution
        )

        return summary