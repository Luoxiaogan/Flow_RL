# Workflow ID: high_level_math_ganluo_201_0
# Benchmark: high_level_math_ganluo
# Data Indices: [626, 408]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Problem Decomposition
        decomposition = await self.generate(
            instruction="Extract all key components from the problem, including variables, equations, constraints, and the target objective. Identify the mathematical domain (e.g., algebra, geometry, combinatorics) and suggest possible solution strategies.",
            context=self.problem_text
        )

        # Step 2: Parallel Exploration of Solution Paths
        algebraic_approach = self.generate(
            instruction=f"Using algebraic techniques, solve the problem based on the following decomposition: {decomposition}. Provide step-by-step reasoning and ensure all constraints are satisfied.",
            context=self.problem_text
        )
        geometric_approach = self.generate(
            instruction=f"Using geometric reasoning, solve the problem based on the following decomposition: {decomposition}. Provide step-by-step reasoning and ensure all constraints are satisfied.",
            context=self.problem_text
        )
        combinatorial_approach = self.generate(
            instruction=f"Using combinatorial or probabilistic methods, solve the problem based on the following decomposition: {decomposition}. Provide step-by-step reasoning and ensure all constraints are satisfied.",
            context=self.problem_text
        )

        # Execute approaches in parallel
        results = await asyncio.gather(algebraic_approach, geometric_approach, combinatorial_approach)

        # Step 3: Critical Evaluation and Refinement
        refined_results = await asyncio.gather(
            *(self.revise(
                instruction=f"Critique and refine the following solution approach to ensure mathematical correctness, completeness, and clarity: {result}.",
                context=self.problem_text
            ) for result in results)
        )

        # Step 4: Solution Synthesis
        final_solution = await self.ensemble(
            instruction="Compare and synthesize the following refined solutions to produce the best possible answer. Ensure the final solution is rigorous, elegant, and satisfies all problem constraints.",
            contexts=refined_results
        )

        # Step 5: Final Summary
        summary = await self.summarize(
            instruction="Condense the final solution into a concise, well-structured format that includes all necessary details and explanations.",
            context=final_solution
        )

        return summary