# Workflow ID: high_level_math_ganluo_468_0
# Benchmark: high_level_math_ganluo
# Data Indices: [445, 780]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Problem Understanding and Decomposition
        decomposition_instruction = (
            "Analyze the problem thoroughly. Identify the mathematical domain (e.g., algebra, geometry, number theory), "
            "extract all numerical values, variables, and constraints. Outline possible solution strategies based on the problem type."
        )
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Parallel Exploration of Solution Paths
        algebra_instruction = f"Using algebraic methods, solve the problem step-by-step. Relevant information: {decomposition}"
        geometry_instruction = f"Using geometric reasoning, solve the problem step-by-step. Relevant information: {decomposition}"
        combinatorics_instruction = f"Using combinatorial analysis, solve the problem step-by-step. Relevant information: {decomposition}"

        results = await asyncio.gather(
            self.generate(instruction=algebra_instruction, context=self.problem_text),
            self.generate(instruction=geometry_instruction, context=self.problem_text),
            self.generate(instruction=combinatorics_instruction, context=self.problem_text)
        )

        # Step 3: Evaluation and Selection of the Best Solution
        ensemble_instruction = (
            "Evaluate the provided solutions. Select the most accurate, efficient, and complete solution. "
            "Consider whether the solution satisfies all constraints and provides a clear path to the answer."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Optional: Refinement of the Selected Solution
        refinement_instruction = (
            "Review the selected solution for clarity, correctness, and completeness. Make any necessary improvements."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 4: Final Answer Compilation
        summary_instruction = (
            "Condense the solution into a concise and well-formatted answer. Include only the essential reasoning and the final result."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer