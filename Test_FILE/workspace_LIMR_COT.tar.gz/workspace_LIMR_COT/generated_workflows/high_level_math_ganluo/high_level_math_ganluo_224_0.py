# Workflow ID: high_level_math_ganluo_224_0
# Benchmark: high_level_math_ganluo
# Data Indices: [848, 416]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Identify all numerical values, variables, and constraints in the problem. "
            "Organize them into categories such as 'given data', 'unknowns', and 'relationships'."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple candidate solutions
        algebraic_instruction = f"Using algebraic methods, solve the problem step-by-step. Given data: {extracted_info}."
        geometric_instruction = f"Using geometric reasoning, solve the problem step-by-step. Given data: {extracted_info}."
        combinatorial_instruction = f"Using combinatorial analysis, solve the problem step-by-step. Given data: {extracted_info}."

        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Revise and improve each candidate solution
        revised_results = await asyncio.gather(
            self.revise(instruction="Critique and refine this solution for correctness and clarity.", context=results[0]),
            self.revise(instruction="Critique and refine this solution for correctness and clarity.", context=results[1]),
            self.revise(instruction="Critique and refine this solution for correctness and clarity.", context=results[2])
        )

        # Step 4: Ensemble selection to choose the best solution
        ensemble_instruction = (
            "Compare the following solutions and select the most correct, efficient, and elegant one. "
            "Ensure it satisfies all problem constraints."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=revised_results)

        # Step 5: Summarize the final solution
        summary_instruction = "Condense the solution into a concise and clear format, highlighting the key steps and final answer."
        final_summary = await self.summarize(instruction=summary_instruction, context=final_solution)

        return final_summary