# Workflow ID: high_level_math_ganluo_177_0
# Benchmark: high_level_math_ganluo
# Data Indices: [881, 944]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information and problem type
        extraction_instruction = (
            "Extract all numerical values, constraints, and relationships from the problem. "
            "Identify the type of problem (e.g., combinatorics, number theory) and any hidden structures or symmetries. "
            "Provide a clear summary of what needs to be solved."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Explore multiple solution paths in parallel
        generate_instructions = [
            f"Using an algebraic approach, solve the problem based on the following extracted information: {extracted_info}. "
            "Include all steps and justify each transformation.",
            f"Using a geometric approach, solve the problem based on the following extracted information: {extracted_info}. "
            "Include all steps and justify each transformation.",
            f"Using a combinatorial approach, solve the problem based on the following extracted information: {extracted_info}. "
            "Include all steps and justify each transformation."
        ]
        results = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in generate_instructions]
        )

        # Step 3: Refine and validate the solutions
        refinement_instruction = (
            "Critique and refine the provided solution. Ensure it satisfies all constraints and is mathematically rigorous. "
            "Check for edge cases and boundary conditions. Provide a revised solution with detailed reasoning."
        )
        refined_solutions = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction, context=result) for result in results]
        )

        # Step 4: Select the best solution or synthesize insights
        ensemble_instruction = (
            "Compare the provided solutions and select the most accurate, efficient, and elegant one. "
            "If multiple solutions are valid, synthesize their insights into a single coherent solution."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_solutions)

        # Step 5: Summarize the final solution
        summarize_instruction = (
            "Condense the solution into a clear and concise format. Include only the essential steps and final answer."
        )
        summarized_solution = await self.summarize(instruction=summarize_instruction, context=final_solution)

        return summarized_solution