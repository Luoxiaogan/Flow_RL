# Workflow ID: high_level_math_ganluo_440_0
# Benchmark: high_level_math_ganluo
# Data Indices: [622, 827]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Analyze the problem thoroughly and extract key information such as variables, equations, "
            "constraints, and objectives. Identify the mathematical domain (e.g., algebra, geometry, number theory) "
            "and categorize the type of problem (e.g., equation solving, counting, optimization)."
        )
        key_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        approach_instructions = [
            f"Using the extracted information: {key_info}, solve the problem using algebraic manipulation. "
            "Focus on equations, inequalities, and functional relationships.",
            f"Using the extracted information: {key_info}, solve the problem using geometric reasoning. "
            "Consider coordinate geometry, synthetic geometry, and trigonometric relationships.",
            f"Using the extracted information: {key_info}, solve the problem using combinatorial analysis. "
            "Focus on counting principles, recursive structures, and probabilistic methods."
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Refine and validate each approach
        refine_instruction_template = (
            "Critique and refine the following solution approach. Ensure it satisfies all problem constraints, "
            "is mathematically rigorous, and is computationally feasible. Highlight any errors or gaps in reasoning."
        )
        refined_approaches = await asyncio.gather(
            *[self.revise(instruction=refine_instruction_template, context=approach) for approach in approaches]
        )

        # Step 4: Ensemble decision-making to select or synthesize the best solution
        ensemble_instruction = (
            "Evaluate the following refined solutions and select the best one. If multiple solutions are valid, "
            "synthesize them into a single coherent answer. Prioritize solutions that are mathematically rigorous, "
            "computationally efficient, and aligned with the problem's intent."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_approaches)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Prepare a concise and clear summary of the final solution. Include all required details such as "
            "numerical answers, symbolic expressions, or step-by-step reasoning. Ensure the output is easy to understand."
        )
        final_output = await self.summarize(instruction=summary_instruction, context=final_solution)

        return final_output