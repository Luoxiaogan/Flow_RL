# Workflow ID: high_level_math_ganluo_361_0
# Benchmark: high_level_math_ganluo
# Data Indices: [866, 614]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key components from the problem
        extraction_instruction = (
            "Extract all numerical values, variables, constraints, and relationships from the problem. "
            "Organize the information clearly and label each component (e.g., given values, unknowns, conditions)."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        generate_instruction_template = (
            f"Using the extracted information: {extracted_info}, "
            "develop a detailed solution approach for the problem. "
            "Consider different mathematical techniques and domains (e.g., algebraic manipulation, geometric reasoning, combinatorial analysis). "
            "Ensure the approach is systematic and addresses all constraints."
        )

        # Generate two independent approaches in parallel
        approach1 = self.generate(instruction=generate_instruction_template + " Focus on an algebraic or analytical approach.", context=self.problem_text)
        approach2 = self.generate(instruction=generate_instruction_template + " Focus on a geometric or combinatorial approach.", context=self.problem_text)
        approaches = await asyncio.gather(approach1, approach2)

        # Step 3: Refine each approach
        refine_instruction_template = (
            "Critique and refine the following solution approach. "
            "Check for logical consistency, completeness, and adherence to the problem's constraints. "
            "Fill any gaps in reasoning and improve clarity."
        )
        refined_approach1 = await self.revise(instruction=refine_instruction_template, context=approaches[0])
        refined_approach2 = await self.revise(instruction=refine_instruction_template, context=approaches[1])

        # Step 4: Ensemble selection of the best approach
        ensemble_instruction = (
            "Compare the following refined approaches and select the most robust, clear, and correct solution. "
            "If possible, synthesize insights from both approaches into a single superior solution."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=[refined_approach1, refined_approach2])

        # Step 5: Summarize the final solution
        summarize_instruction = (
            "Summarize the final solution in a concise yet complete manner. "
            "Include all key steps, reasoning, and the final answer. Ensure the summary is well-structured and easy to follow."
        )
        summary = await self.summarize(instruction=summarize_instruction, context=final_solution)

        return summary