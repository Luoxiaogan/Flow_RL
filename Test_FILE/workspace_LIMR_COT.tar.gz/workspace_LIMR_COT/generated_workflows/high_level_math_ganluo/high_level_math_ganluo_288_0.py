# Workflow ID: high_level_math_ganluo_288_0
# Benchmark: high_level_math_ganluo
# Data Indices: [360, 336]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key mathematical entities and constraints
        extraction_instruction = (
            "Thoroughly analyze the problem statement to extract all key mathematical entities, "
            "constraints, and relationships. Categorize them into numerical values, geometric descriptions, "
            "algebraic equations, or combinatorial structures. Provide a structured summary."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple candidate solutions in parallel
        strategies = [
            "Use coordinate geometry to represent the problem algebraically. Solve for the required quantities.",
            "Apply symmetry or geometric properties to simplify the problem. Derive the solution step-by-step.",
            "Employ algebraic manipulation or functional equations to solve the problem rigorously.",
            "Use combinatorial reasoning or number theory techniques to count or calculate the desired value."
        ]
        candidate_solutions = await asyncio.gather(
            *[self.generate(instruction=f"{strategy} Given the following extracted information: {extracted_info}", context=self.problem_text)
              for strategy in strategies]
        )

        # Step 3: Refine each candidate solution
        refinement_instruction = (
            "Critically evaluate the provided solution. Identify and correct any errors, ambiguities, or gaps. "
            "Ensure that all problem constraints are satisfied and the reasoning is mathematically rigorous."
        )
        refined_solutions = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction, context=solution) for solution in candidate_solutions]
        )

        # Step 4: Synthesize the best solution or combine insights
        synthesis_instruction = (
            "Compare the provided solutions. Select the most rigorous and complete one, or synthesize insights "
            "from multiple solutions if they complement each other. Ensure the final answer satisfies all problem constraints."
        )
        final_solution = await self.ensemble(instruction=synthesis_instruction, contexts=refined_solutions)

        # Step 5: Summarize the final answer
        summary_instruction = (
            "Condense the solution into a concise and clear format. Include the final answer and key reasoning steps."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=final_solution)

        return final_answer