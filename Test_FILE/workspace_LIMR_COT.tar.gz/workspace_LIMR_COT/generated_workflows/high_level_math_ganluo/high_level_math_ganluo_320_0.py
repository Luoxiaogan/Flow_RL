# Workflow ID: high_level_math_ganluo_320_0
# Benchmark: high_level_math_ganluo
# Data Indices: [631, 415]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information from the problem
        extraction_instruction = (
            "Extract all numerical values, constraints, and conditions from the problem. "
            "Include any specific requirements or restrictions mentioned in the problem statement. "
            "Format the output clearly with labels for each piece of information."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        approach_instructions = [
            f"Using the following extracted information: {extracted_info}. "
            "Solve the problem using an algebraic approach. Include all steps and reasoning.",
            f"Using the following extracted information: {extracted_info}. "
            "Solve the problem using a combinatorial approach. Include all steps and reasoning.",
            f"Using the following extracted information: {extracted_info}. "
            "Solve the problem using a geometric approach. Include all steps and reasoning."
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Refine each approach to ensure correctness
        refine_instruction = (
            "Critically evaluate the solution provided. Identify any errors, gaps, or ambiguities. "
            "Improve the solution to ensure it satisfies all constraints and conditions. "
            "Provide a revised version of the solution with clear explanations."
        )
        refined_approaches = await asyncio.gather(
            *[self.revise(instruction=refine_instruction, context=approach) for approach in approaches]
        )

        # Step 4: Summarize the refined solutions
        summary_instruction = (
            "Condense the solution into a concise summary. Include only the key steps, results, and insights. "
            "Ensure that the summary captures the essence of the solution without losing important details."
        )
        summaries = await asyncio.gather(
            *[self.summarize(instruction=summary_instruction, context=refined) for refined in refined_approaches]
        )

        # Step 5: Select the best solution using Ensemble
        ensemble_instruction = (
            "Compare the provided solutions and select the best one. Consider accuracy, completeness, "
            "and adherence to the problem constraints. Provide a justification for your choice."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=summaries)

        return final_solution