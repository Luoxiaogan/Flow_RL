# Workflow ID: high_level_math_ganluo_31_0
# Benchmark: high_level_math_ganluo
# Data Indices: [515, 850]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key components from the problem
        extraction_instruction = (
            "Carefully analyze the problem statement and extract all key components, "
            "including numerical values, constraints, relationships, and the specific question being asked. "
            "Organize this information clearly for further processing."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution strategies
        strategy_instructions = [
            f"Based on the extracted information: {extracted_info}, "
            "develop a solution strategy using algebraic manipulation and equation-solving techniques.",
            f"Based on the extracted information: {extracted_info}, "
            "develop a solution strategy using combinatorial reasoning and counting principles.",
            f"Based on the extracted information: {extracted_info}, "
            "develop a solution strategy using geometric reasoning and visualization techniques.",
        ]
        strategies = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in strategy_instructions]
        )

        # Step 3: Refine each strategy
        refinement_instruction_template = (
            "Critically evaluate the following solution strategy: {strategy}. "
            "Ensure it is mathematically sound, adheres to the problem constraints, and accounts for edge cases. "
            "Refine it if necessary and provide a clear, improved version."
        )
        refined_strategies = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction_template.format(strategy=strategy), context=strategy)
              for strategy in strategies]
        )

        # Step 4: Select the best strategy or synthesize insights
        ensemble_instruction = (
            "Compare the following refined solution strategies and select the most appropriate one: {strategies}. "
            "If multiple strategies are complementary, synthesize their insights into a unified approach."
        )
        final_strategy = await self.ensemble(
            instruction=ensemble_instruction.format(strategies="\n".join(refined_strategies)),
            contexts=refined_strategies
        )

        # Step 5: Compile the final answer
        summarization_instruction = (
            "Summarize the final solution strategy: {final_strategy}. "
            "Provide a concise, well-structured answer that directly addresses the problem's question. "
            "Ensure the answer is expressed in the required format (e.g., common fraction, numerical value)."
        )
        final_answer = await self.summarize(
            instruction=summarization_instruction.format(final_strategy=final_strategy),
            context=final_strategy
        )

        return final_answer