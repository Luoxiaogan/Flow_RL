# Workflow ID: high_level_math_ganluo_313_0
# Benchmark: high_level_math_ganluo
# Data Indices: [286, 533]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = ("Extract all numerical values, variables, constraints, and objectives "
                                  "from the problem text. Organize them clearly for subsequent analysis.")
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Explore multiple solution approaches in parallel
        algebraic_instruction = f"Solve the problem algebraically using the following information: {extracted_info}."
        geometric_instruction = f"Solve the problem geometrically using the following information: {extracted_info}."
        combinatorial_instruction = f"Solve the problem combinatorially using the following information: {extracted_info}."

        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and synthesize the best solution
        ensemble_instruction = ("Compare the following candidate solutions and select the most promising one. "
                                 "Ensure it satisfies all constraints and is mathematically rigorous.")
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 4: Refine the chosen solution
        refinement_instruction = ("Critically review the following solution. Check for errors, "
                                  "ensure all constraints are satisfied, and refine as needed.")
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the final solution
        summary_instruction = ("Condense the following solution into a concise, clear format. "
                               "Include only the essential steps and the final answer.")
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_summary