# Workflow ID: high_level_math_ganluo_324_0
# Benchmark: high_level_math_ganluo
# Data Indices: [54, 268]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information and rephrase the problem
        problem_understanding = await self.generate(
            instruction="Extract all key mathematical elements, constraints, and variables from the problem. "
                        "Rephrase the problem in a structured format that highlights the relationships between these elements.",
            context=self.problem_text
        )

        # Step 2: Generate multiple candidate solutions in parallel
        algebraic_solution = self.generate(
            instruction=f"Using algebraic methods, solve the problem step by step. Ensure all constraints are satisfied. "
                        f"Provide intermediate results and reasoning. Problem understanding: {problem_understanding}",
            context=self.problem_text
        )
        geometric_solution = self.generate(
            instruction=f"Using geometric or visual reasoning, solve the problem step by step. Ensure all constraints are satisfied. "
                        f"Provide intermediate results and reasoning. Problem understanding: {problem_understanding}",
            context=self.problem_text
        )
        combinatorial_solution = self.generate(
            instruction=f"Using combinatorial or probabilistic reasoning, solve the problem step by step. Ensure all constraints are satisfied. "
                        f"Provide intermediate results and reasoning. Problem understanding: {problem_understanding}",
            context=self.problem_text
        )

        # Execute in parallel
        candidate_solutions = await asyncio.gather(algebraic_solution, geometric_solution, combinatorial_solution)

        # Step 3: Refine each candidate solution
        refined_solutions = []
        for solution in candidate_solutions:
            refined = await self.revise(
                instruction=f"Review and refine the following solution. Check for mathematical correctness, "
                            f"address any missing steps, and ensure all constraints are satisfied. "
                            f"Problem understanding: {problem_understanding}",
                context=solution
            )
            refined_solutions.append(refined)

        # Step 4: Synthesize the best solution
        final_solution = await self.ensemble(
            instruction=f"Compare the following solutions and select the most correct, elegant, and complete one. "
                        f"Ensure the chosen solution satisfies all constraints and handles edge cases. "
                        f"Problem understanding: {problem_understanding}",
            contexts=refined_solutions
        )

        # Step 5: Verify the final solution
        verification = await self.generate(
            instruction=f"Verify the correctness of the following solution. Check if it satisfies all constraints, "
                        f"performs boundary testing, and handles edge cases. Problem understanding: {problem_understanding}",
            context=final_solution
        )

        return verification