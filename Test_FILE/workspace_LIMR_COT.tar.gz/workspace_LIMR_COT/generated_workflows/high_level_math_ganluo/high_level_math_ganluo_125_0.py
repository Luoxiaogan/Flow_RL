# Workflow ID: high_level_math_ganluo_125_0
# Benchmark: high_level_math_ganluo
# Data Indices: [185, 138]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract key information and understand the problem
        problem_analysis = await self.generate(
            instruction="Extract all key information from the problem, including variables, constraints, and the desired output. Provide a structured breakdown of the problem.",
            context=self.problem_text
        )

        # Step 2: Generate multiple solution approaches in parallel
        algebraic_solution = self.generate(
            instruction=f"Using the following problem analysis: {problem_analysis}\nSolve the problem using algebraic techniques. Include all steps and reasoning.",
            context=self.problem_text
        )
        combinatorial_solution = self.generate(
            instruction=f"Using the following problem analysis: {problem_analysis}\nSolve the problem using combinatorial reasoning. Include all steps and reasoning.",
            context=self.problem_text
        )
        geometric_solution = self.generate(
            instruction=f"Using the following problem analysis: {problem_analysis}\nSolve the problem using geometric techniques. Include all steps and reasoning.",
            context=self.problem_text
        )
        number_theory_solution = self.generate(
            instruction=f"Using the following problem analysis: {problem_analysis}\nSolve the problem using number-theoretic techniques. Include all steps and reasoning.",
            context=self.problem_text
        )

        # Execute all solution approaches in parallel
        solutions = await asyncio.gather(algebraic_solution, combinatorial_solution, geometric_solution, number_theory_solution)

        # Step 3: Refine and validate each solution
        refined_solutions = await asyncio.gather(
            *[self.revise(
                instruction="Critique and refine the provided solution. Ensure it is mathematically sound, adheres to the problem's constraints, and includes all necessary steps.",
                context=solution
            ) for solution in solutions]
        )

        # Step 4: Ensemble decision-making
        final_solution = await self.ensemble(
            instruction="Compare and synthesize the refined solutions. Select the most appropriate solution or combine insights from multiple approaches. Ensure the final solution is correct, elegant, and satisfies all constraints.",
            contexts=refined_solutions
        )

        # Step 5: Summarize the final solution
        summarized_solution = await self.summarize(
            instruction="Condense the final solution into a concise and well-structured format. Ensure it explicitly answers the problem's question and satisfies all constraints.",
            context=final_solution
        )

        return summarized_solution