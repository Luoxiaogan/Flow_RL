# Workflow ID: high_level_math_ganluo_384_0
# Benchmark: high_level_math_ganluo
# Data Indices: [704, 38]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Understand and decompose the problem
        decomposition = await self.generate(
            instruction="Carefully analyze the problem statement. Identify all variables, constants, constraints, and relationships. "
                        "Break the problem into smaller sub-problems if necessary. Provide a structured summary of the problem's key components.",
            context=self.problem_text
        )

        # Step 2: Formulate solution strategies
        strategies = await self.generate(
            instruction=f"Based on the following decomposition:\n{decomposition}\n"
                        "Propose multiple solution strategies. Consider different mathematical techniques such as algebraic manipulation, "
                        "geometric reasoning, combinatorial analysis, or number theory. For each strategy, provide a brief rationale.",
            context=self.problem_text
        )

        # Step 3: Explore solution paths in parallel
        # Extract individual strategies dynamically
        strategy_list = strategies.split("\n\n")  # Assuming strategies are separated by double newlines
        parallel_tasks = [
            self.generate(
                instruction=f"Using the following strategy:\n{strategy}\n"
                            "Solve the problem step by step. Ensure all calculations are accurate and all constraints are satisfied.",
                context=self.problem_text
            )
            for strategy in strategy_list
        ]
        candidate_solutions = await asyncio.gather(*parallel_tasks)

        # Step 4: Evaluate and select the best solution
        best_solution = await self.ensemble(
            instruction="Compare the following candidate solutions. Evaluate each based on correctness, clarity, and adherence to the problem's constraints. "
                        "Select the most robust and elegant solution.",
            contexts=candidate_solutions
        )

        # Step 5: Refine the selected solution
        refined_solution = await self.revise(
            instruction="Improve the clarity and presentation of the solution. Address any gaps in reasoning, simplify complex expressions, "
                        "and ensure all steps are logically connected.",
            context=best_solution
        )

        # Step 6: Summarize the final solution
        final_solution = await self.summarize(
            instruction="Condense the solution into a concise and polished form. Include only the essential steps and results.",
            context=refined_solution
        )

        return final_solution