# Workflow ID: high_level_math_ganluo_53_0
# Benchmark: high_level_math_ganluo
# Data Indices: [287, 729]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Carefully analyze the problem statement and extract all numerical values, "
            "variables, equations, constraints, and relationships. Organize the information "
            "in a structured format suitable for further analysis."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        approach_1_instruction = (
            f"Based on the extracted information: {extracted_info}, develop a solution "
            "using algebraic methods. Ensure all steps are clearly explained and justified."
        )
        approach_2_instruction = (
            f"Based on the extracted information: {extracted_info}, develop a solution "
            "using geometric reasoning. Ensure all steps are clearly explained and justified."
        )
        approaches = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text)
        )

        # Step 3: Critique and refine the solutions
        refine_instruction = (
            "Critique the following solution for mathematical correctness, clarity, and completeness. "
            "Refine any ambiguous or incorrect steps, and ensure the solution adheres to the problem constraints."
        )
        refined_approaches = await asyncio.gather(
            self.revise(instruction=refine_instruction, context=approaches[0]),
            self.revise(instruction=refine_instruction, context=approaches[1])
        )

        # Step 4: Summarize key insights from each refined solution
        summarize_instruction = (
            "Summarize the key insights and results from the following solution. Focus on the main steps "
            "and the final answer, ensuring clarity and conciseness."
        )
        summaries = await asyncio.gather(
            self.summarize(instruction=summarize_instruction, context=refined_approaches[0]),
            self.summarize(instruction=summarize_instruction, context=refined_approaches[1])
        )

        # Step 5: Select the best solution using ensemble decision-making
        ensemble_instruction = (
            "Compare the following summaries and select the most appropriate solution based on "
            "correctness, simplicity, and elegance. Provide a justification for your choice."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=summaries)

        return final_solution