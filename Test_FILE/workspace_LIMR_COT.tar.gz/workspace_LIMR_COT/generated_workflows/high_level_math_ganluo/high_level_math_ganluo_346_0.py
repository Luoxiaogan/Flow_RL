# Workflow ID: high_level_math_ganluo_346_0
# Benchmark: high_level_math_ganluo
# Data Indices: [186, 107]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Decompose the problem into its essential components
        decomposition_instruction = (
            "Carefully analyze the problem statement and identify all key components, including:"
            "- Known values and their relationships"
            "- Constraints and conditions"
            "- What is being asked for"
            "Provide a structured breakdown of the problem."
        )
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Generate multiple candidate solutions in parallel
        candidate_instructions = [
            "Solve the problem using an algebraic approach. Focus on equations, variables, and logical deductions.",
            "Solve the problem using a geometric approach. Consider shapes, areas, volumes, and spatial relationships.",
            "Solve the problem using a combinatorial or probabilistic approach. Count possibilities, calculate probabilities, and use symmetry where applicable."
        ]
        candidates = await asyncio.gather(
            *[self.generate(instruction=instr, context=decomposition) for instr in candidate_instructions]
        )

        # Step 3: Refine each candidate solution
        refine_instruction_template = (
            "Review the following solution carefully. Ensure it is mathematically correct, adheres to all problem constraints, "
            "and is clearly explained. Identify and fix any errors or ambiguities."
        )
        refined_candidates = await asyncio.gather(
            *[self.revise(instruction=refine_instruction_template, context=candidate) for candidate in candidates]
        )

        # Step 4: Synthesize the best solution or combine insights
        ensemble_instruction = (
            "Evaluate the following candidate solutions. Select the most robust and accurate solution, or synthesize insights "
            "from multiple solutions if necessary. Ensure the final result satisfies all problem constraints."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_candidates)

        # Step 5: Format the final answer
        summarize_instruction = (
            "Condense the solution into a concise, well-structured answer. Ensure the format matches the problem's requirements, "
            "such as expressing the answer as a fraction, decimal, or symbolic expression."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=final_solution)

        return final_answer