# Workflow ID: high_level_math_ganluo_193_0
# Benchmark: high_level_math_ganluo
# Data Indices: [367, 641]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all key information from the problem, including variables, constraints, "
            "and the specific question being asked. Organize this information clearly."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        algebra_instruction = (
            f"Using the extracted information: {extracted_info}, develop an algebraic approach to solve the problem. "
            "Include step-by-step reasoning and any necessary formulas."
        )
        geometry_instruction = (
            f"Using the extracted information: {extracted_info}, develop a geometric approach to solve the problem. "
            "Include step-by-step reasoning and any necessary diagrams or constructions."
        )
        combinatorics_instruction = (
            f"Using the extracted information: {extracted_info}, develop a combinatorial approach to solve the problem. "
            "Include step-by-step reasoning and any necessary counting principles."
        )

        approaches = await asyncio.gather(
            self.generate(instruction=algebra_instruction, context=self.problem_text),
            self.generate(instruction=geometry_instruction, context=self.problem_text),
            self.generate(instruction=combinatorics_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and select the best approach
        ensemble_instruction = (
            "Evaluate the provided solution approaches based on correctness, elegance, and computational feasibility. "
            "Select the most promising approach and justify your choice."
        )
        selected_approach = await self.ensemble(instruction=ensemble_instruction, contexts=approaches)

        # Step 4: Refine the selected approach
        refine_instruction = (
            f"Refine the selected approach: {selected_approach}. Ensure the solution is mathematically rigorous, "
            "addresses all constraints, and is presented in a clear and logical manner."
        )
        refined_solution = await self.revise(instruction=refine_instruction, context=selected_approach)

        # Step 5: Final verification and summarization
        summarize_instruction = (
            "Summarize the refined solution, ensuring it is concise and verifiable. Check for edge cases "
            "and confirm that the solution satisfies all problem constraints."
        )
        final_solution = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_solution