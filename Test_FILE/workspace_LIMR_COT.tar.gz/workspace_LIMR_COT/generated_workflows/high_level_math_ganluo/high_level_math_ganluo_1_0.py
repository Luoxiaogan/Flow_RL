# Workflow ID: high_level_math_ganluo_1_0
# Benchmark: high_level_math_ganluo
# Data Indices: [765, 735]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all key information from the problem statement, including variables, "
            "constraints, relationships, and the specific question being asked. Organize this "
            "information into structured categories for further analysis."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate two independent solution approaches in parallel
        approach_1_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Develop a step-by-step solution strategy using algebraic or analytical methods. "
            "Ensure all constraints are satisfied and explain the reasoning behind each step."
        )
        approach_2_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Develop a step-by-step solution strategy using combinatorial, geometric, or number-theoretic methods. "
            "Ensure all constraints are satisfied and explain the reasoning behind each step."
        )
        results = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text)
        )
        solution_1, solution_2 = results

        # Step 3: Validate and refine the solutions
        refine_instruction_1 = (
            "Critique the following solution and refine it if necessary. Ensure all steps are mathematically "
            "correct, address any gaps in reasoning, and verify that all problem constraints are satisfied."
        )
        refine_instruction_2 = refine_instruction_1  # Same instruction for both solutions
        refined_results = await asyncio.gather(
            self.revise(instruction=refine_instruction_1, context=solution_1),
            self.revise(instruction=refine_instruction_2, context=solution_2)
        )
        refined_solution_1, refined_solution_2 = refined_results

        # Step 4: Synthesize the final answer
        ensemble_instruction = (
            "Compare the following two solutions and determine which one is correct and most efficient. "
            "If both are valid, synthesize a combined solution. Ensure the final answer satisfies all "
            "problem constraints and is presented clearly."
        )
        final_solution = await self.ensemble(
            instruction=ensemble_instruction,
            contexts=[refined_solution_1, refined_solution_2]
        )

        # Step 5: Summarize the final result
        summary_instruction = (
            "Summarize the final solution in a concise and clear manner, highlighting the key steps and "
            "the final answer. Ensure the summary is easy to understand and directly addresses the problem."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=final_solution)

        return final_summary