# Workflow ID: high_level_math_ganluo_349_0
# Benchmark: high_level_math_ganluo
# Data Indices: [907, 772]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Problem Understanding and Decomposition
        extraction_instruction = (
            "Extract all key information from the problem, including variables, constraints, "
            "relationships, and any specific mathematical structures. Organize the information "
            "in a structured format for further analysis."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Parallel Exploration of Solution Paths
        algebraic_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem algebraically. "
            "Provide a step-by-step solution, ensuring all constraints are satisfied."
        )
        geometric_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem geometrically. "
            "Provide a step-by-step solution, ensuring all constraints are satisfied."
        )
        combinatorial_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem combinatorially. "
            "Provide a step-by-step solution, ensuring all constraints are satisfied."
        )

        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Refinement and Verification
        refinement_instruction = (
            "Critique the provided solution, checking for mathematical correctness, logical consistency, "
            "and adherence to problem constraints. Suggest improvements if necessary."
        )
        refined_solutions = await asyncio.gather(
            self.revise(instruction=refinement_instruction, context=results[0]),
            self.revise(instruction=refinement_instruction, context=results[1]),
            self.revise(instruction=refinement_instruction, context=results[2])
        )

        # Step 4: Synthesis and Final Selection
        ensemble_instruction = (
            "Compare the provided solutions and select the most elegant, efficient, and correct one. "
            "Ensure the chosen solution satisfies all problem constraints and is mathematically rigorous."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_solutions)

        # Step 5: Output Preparation
        summary_instruction = (
            "Condense the final solution into a concise and well-structured format. Include all key steps "
            "and ensure clarity for presentation."
        )
        final_output = await self.summarize(instruction=summary_instruction, context=final_solution)

        return final_output