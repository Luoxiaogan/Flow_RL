# Workflow ID: high_level_math_ganluo_86_0
# Benchmark: high_level_math_ganluo
# Data Indices: [547, 958]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information and decompose the problem
        extraction_instruction = (
            "Extract all key information, constraints, and mathematical structures from the problem. "
            "Identify the domain (e.g., algebra, geometry, combinatorics) and the type of reasoning required."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        algebraic_approach = self.generate(
            instruction=f"Based on the extracted information: {extracted_info}, "
                        "develop an algebraic solution approach. Include step-by-step reasoning.",
            context=self.problem_text
        )
        geometric_approach = self.generate(
            instruction=f"Based on the extracted information: {extracted_info}, "
                        "develop a geometric solution approach. Include step-by-step reasoning.",
            context=self.problem_text
        )
        combinatorial_approach = self.generate(
            instruction=f"Based on the extracted information: {extracted_info}, "
                        "develop a combinatorial or recursive solution approach. Include step-by-step reasoning.",
            context=self.problem_text
        )

        # Execute approaches in parallel
        approaches = await asyncio.gather(algebraic_approach, geometric_approach, combinatorial_approach)

        # Step 3: Evaluate and select the best approach
        selection_instruction = (
            "Evaluate the following solution approaches and select the most promising one. "
            "Consider clarity, feasibility, and alignment with the problem's constraints."
        )
        best_approach = await self.ensemble(instruction=selection_instruction, contexts=approaches)

        # Step 4: Refine the chosen approach
        refinement_instruction = (
            f"Refine the following solution approach: {best_approach}. "
            "Address any gaps, ambiguities, or inefficiencies. Ensure all steps are clear and correct."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_approach)

        # Step 5: Execute detailed reasoning and calculations
        execution_instruction = (
            f"Execute the refined solution step-by-step: {refined_solution}. "
            "Perform all necessary calculations and verify intermediate results."
        )
        executed_solution = await self.generate(instruction=execution_instruction, context=self.problem_text)

        # Step 6: Verify and finalize the solution
        verification_instruction = (
            f"Verify that the following solution satisfies all constraints and conditions: {executed_solution}. "
            "Ensure the solution is complete and correct."
        )
        verified_solution = await self.generate(instruction=verification_instruction, context=self.problem_text)

        # Step 7: Summarize the final answer
        summarization_instruction = (
            "Condense the solution into a concise, well-structured format. "
            "Include only the final answer and any required formatting (e.g., solutions separated by commas)."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=verified_solution)

        return final_answer