# Workflow ID: high_level_math_ganluo_172_0
# Benchmark: high_level_math_ganluo
# Data Indices: [571, 70]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key components of the problem
        extraction_instruction = (
            "Extract all key components of the problem, including numerical values, variables, constraints, "
            "relationships, and any specific requirements. Organize the information clearly."
        )
        problem_extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Explore multiple solution approaches in parallel
        approach_instructions = [
            f"Using an algebraic approach, solve the problem step by step. Key details: {problem_extraction}",
            f"Using a geometric approach, solve the problem step by step. Key details: {problem_extraction}",
            f"Using a combinatorial or number-theoretic approach, solve the problem step by step. Key details: {problem_extraction}"
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Evaluate and select the best approach
        ensemble_instruction = (
            "Compare the following solution approaches and select the most rigorous, correct, and complete one. "
            "Ensure the chosen solution satisfies all constraints and requirements of the problem."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=approaches)

        # Step 4: Refine and verify the selected solution
        refinement_instruction = (
            "Critique and refine the following solution. Ensure it is mathematically rigorous, adheres to all "
            "problem constraints, and is presented in the required format."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        return refined_solution