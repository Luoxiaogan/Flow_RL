# Workflow ID: high_level_math_ganluo_386_0
# Benchmark: high_level_math_ganluo
# Data Indices: [295, 738]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract critical information from the problem text
        extraction_instruction = (
            "Extract all numerical values, variables, constraints, and relationships from the problem. "
            "Organize them into a structured format for further analysis."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        approach_instructions = [
            f"Using algebraic methods, solve the problem based on the following extracted information: {extracted_info}.",
            f"Using geometric reasoning, analyze the problem based on the following extracted information: {extracted_info}.",
            f"Using combinatorial or number-theoretic techniques, solve the problem based on the following extracted information: {extracted_info}."
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Revise and refine each solution approach
        refinement_instruction_template = (
            "Critique and refine the following solution approach. Ensure all steps are mathematically rigorous, "
            "address any gaps in reasoning, and verify that the solution satisfies all constraints."
        )
        refined_approaches = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction_template, context=approach) for approach in approaches]
        )

        # Step 4: Ensemble to select the best solution
        ensemble_instruction = (
            "Compare the following refined solutions and select the most accurate, complete, and elegant one. "
            "Provide justification for your choice."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_approaches)

        # Step 5: Summarize the final answer
        summary_instruction = (
            "Summarize the final solution in a concise and clear manner. Highlight the key result and ensure "
            "it directly answers the original problem."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=best_solution)

        return final_answer