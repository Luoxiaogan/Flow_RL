# Workflow ID: high_level_math_ganluo_423_0
# Benchmark: high_level_math_ganluo
# Data Indices: [664, 431]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information and decompose the problem
        decomposition_instruction = (
            "Analyze the problem thoroughly and extract all key information, including numerical values, "
            "constraints, and the type of mathematical reasoning required (e.g., algebraic, combinatorial, geometric). "
            "Identify potential solution paths and outline the main steps needed to solve the problem."
        )
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Generate multiple candidate solutions in parallel
        candidate_instructions = [
            f"Using the extracted information: {decomposition}, solve the problem using an algebraic approach.",
            f"Using the extracted information: {decomposition}, solve the problem using a combinatorial approach.",
            f"Using the extracted information: {decomposition}, solve the problem using a geometric approach."
        ]
        candidates = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in candidate_instructions]
        )

        # Step 3: Refine each candidate solution
        refinement_instruction_template = (
            "Critique the following solution and refine it to ensure correctness, clarity, and adherence to the problem's constraints. "
            "Provide detailed improvements where necessary."
        )
        refined_candidates = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction_template, context=candidate) for candidate in candidates]
        )

        # Step 4: Synthesize the best solution
        synthesis_instruction = (
            "Compare the following refined solutions and select the most robust, elegant, and correct one. "
            "Provide a justification for your choice."
        )
        best_solution = await self.ensemble(instruction=synthesis_instruction, contexts=refined_candidates)

        # Step 5: Final verification and presentation
        final_instruction = (
            "Verify that the following solution satisfies all constraints and present it in a clear, concise format. "
            "Include key insights and ensure the solution is easy to follow."
        )
        final_solution = await self.summarize(instruction=final_instruction, context=best_solution)

        return final_solution