# Workflow ID: high_level_math_ganluo_230_0
# Benchmark: high_level_math_ganluo
# Data Indices: [277, 257]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key components and analyze the problem
        analysis_instruction = (
            "Analyze the problem to identify its type (e.g., algebraic, combinatorial, geometric), "
            "key components (e.g., numerical values, constraints, relationships), and any hidden patterns or structures. "
            "Provide a detailed breakdown of the problem's requirements and potential solution strategies."
        )
        problem_analysis = await self.generate(instruction=analysis_instruction, context=self.problem_text)

        # Step 2: Explore multiple solution paths in parallel
        algebraic_instruction = (
            f"Based on the analysis: {problem_analysis}, solve the problem using algebraic techniques. "
            "Include step-by-step reasoning and verify intermediate results."
        )
        combinatorial_instruction = (
            f"Based on the analysis: {problem_analysis}, solve the problem using combinatorial or probabilistic methods. "
            "Include step-by-step reasoning and verify intermediate results."
        )
        geometric_instruction = (
            f"Based on the analysis: {problem_analysis}, solve the problem using geometric or coordinate-based methods. "
            "Include step-by-step reasoning and verify intermediate results."
        )

        # Execute approaches in parallel
        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and synthesize results
        ensemble_instruction = (
            "Compare the provided solutions and select the most rigorous, complete, and accurate one. "
            "If multiple solutions are valid, synthesize them into a unified answer."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 4: Refine the selected solution
        refinement_instruction = (
            "Critically review the solution for correctness, rigor, and clarity. "
            "Address any gaps, inconsistencies, or potential errors. Ensure the solution satisfies all problem constraints."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the solution into a clear, concise, and well-structured format. "
            "Include the final answer and a brief explanation of how it was derived."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer