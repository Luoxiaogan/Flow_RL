# Workflow ID: high_level_math_ganluo_454_0
# Benchmark: high_level_math_ganluo
# Data Indices: [608, 439]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Understand the problem and extract key information
        problem_analysis = await self.generate(
            instruction="""Analyze the problem thoroughly. Identify:
            - Known variables and constants
            - Relationships and constraints
            - Mathematical domains involved (e.g., algebra, geometry, combinatorics)
            - Any special properties or symmetries that can simplify the problem
            Provide this information in a structured format.""",
            context=self.problem_text
        )

        # Step 2: Generate multiple solution approaches in parallel
        algebraic_solution = self.generate(
            instruction=f"""Using algebraic methods, solve the problem based on the following analysis:
            {problem_analysis}
            Include all steps and intermediate results.""",
            context=self.problem_text
        )
        geometric_solution = self.generate(
            instruction=f"""Using geometric methods, solve the problem based on the following analysis:
            {problem_analysis}
            Include all steps and intermediate results.""",
            context=self.problem_text
        )
        combinatorial_solution = self.generate(
            instruction=f"""Using combinatorial or probabilistic methods, solve the problem based on the following analysis:
            {problem_analysis}
            Include all steps and intermediate results.""",
            context=self.problem_text
        )

        # Execute all solution approaches in parallel
        results = await asyncio.gather(algebraic_solution, geometric_solution, combinatorial_solution)

        # Step 3: Evaluate and select the best solution
        best_solution = await self.ensemble(
            instruction="""Compare the provided solutions based on:
            - Correctness and completeness
            - Clarity and logical flow
            - Computational feasibility
            Select the best solution and provide a justification for your choice.""",
            contexts=results
        )

        # Step 4: Refine the selected solution
        refined_solution = await self.revise(
            instruction="""Critique and improve the following solution:
            Ensure all steps are rigorous, logical, and clearly explained.
            Address any ambiguities or gaps in reasoning.""",
            context=best_solution
        )

        # Step 5: Summarize the final solution
        final_answer = await self.summarize(
            instruction="""Condense the following solution into a concise, well-structured answer:
            Include only the essential steps and the final result.""",
            context=refined_solution
        )

        return final_answer