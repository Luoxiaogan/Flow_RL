# Workflow ID: high_level_math_ganluo_29_0
# Benchmark: high_level_math_ganluo
# Data Indices: [149, 378]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = """
        Analyze the problem thoroughly and extract all key information, including:
        - Variables and their relationships
        - Constraints or conditions
        - Desired output or goal
        - Any implicit assumptions or symmetries
        Provide the extracted information in a structured format for further processing.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Explore multiple solution approaches in parallel
        algebraic_instruction = f"""
        Solve the problem using an algebraic approach. Consider the following:
        - {extracted_info}
        - Use equations, inequalities, or functional relationships as needed
        - Ensure all constraints are satisfied
        Provide a detailed step-by-step solution.
        """
        geometric_instruction = f"""
        Solve the problem using a geometric approach. Consider the following:
        - {extracted_info}
        - Use coordinate geometry, synthetic geometry, or trigonometry as needed
        - Visualize the problem if possible
        Provide a detailed step-by-step solution.
        """
        combinatorial_instruction = f"""
        Solve the problem using a combinatorial approach. Consider the following:
        - {extracted_info}
        - Use counting principles, recursive formulas, or generating functions as needed
        - Ensure all cases are considered
        Provide a detailed step-by-step solution.
        """

        # Execute approaches in parallel
        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and synthesize the results
        ensemble_instruction = """
        Compare the provided solutions and select the best one based on the following criteria:
        - Correctness: Does the solution satisfy all problem constraints?
        - Simplicity: Is the solution straightforward and easy to follow?
        - Completeness: Does the solution address all aspects of the problem?
        If multiple solutions are valid, synthesize them into a single cohesive answer.
        """
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 4: Refine and verify the selected solution
        refinement_instruction = """
        Critique and improve the provided solution. Ensure the following:
        - All steps are logically sound and mathematically rigorous
        - Any edge cases or special scenarios are addressed
        - The solution is presented clearly and concisely
        Provide the refined solution.
        """
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the final solution
        summary_instruction = """
        Condense the solution into a concise and clear final answer. Include:
        - The main result or conclusion
        - Key steps or reasoning (briefly)
        - Any important caveats or notes
        Ensure the summary is easy to understand and directly addresses the problem.
        """
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer