# Workflow ID: high_level_math_ganluo_55_0
# Benchmark: high_level_math_ganluo
# Data Indices: [677, 503]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem text
        extraction_instruction = (
            "Extract all key information from the problem, including variables, constraints, "
            "and the mathematical domain (e.g., combinatorics, number theory, geometry). "
            "Identify what the question is asking for and highlight any special conditions."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        approach_instructions = [
            f"Using algebraic methods, solve the problem step by step. Key information: {extracted_info}",
            f"Using combinatorial reasoning, analyze the problem and count possibilities. Key information: {extracted_info}",
            f"Exploit symmetry or modular arithmetic if applicable. Key information: {extracted_info}",
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Evaluate and synthesize the best solution
        ensemble_instruction = (
            "Compare the following candidate solutions and select the most complete, correct, and elegant one. "
            "Ensure the chosen solution satisfies all constraints and is mathematically sound."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=approaches)

        # Step 4: Refine the solution if necessary
        refine_instruction = (
            "Critique and improve the following solution. Ensure it is clear, concise, and free of errors. "
            "Verify that it fully addresses the problem requirements."
        )
        refined_solution = await self.revise(instruction=refine_instruction, context=best_solution)

        # Step 5: Summarize the final solution
        summarize_instruction = (
            "Condense the solution into a concise format. Highlight the final answer and ensure it directly "
            "addresses the problem's question."
        )
        final_summary = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_summary