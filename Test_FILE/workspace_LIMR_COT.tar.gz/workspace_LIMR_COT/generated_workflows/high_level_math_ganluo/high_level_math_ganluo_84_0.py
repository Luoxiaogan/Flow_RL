# Workflow ID: high_level_math_ganluo_84_0
# Benchmark: high_level_math_ganluo
# Data Indices: [153, 739]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio
        
        # Step 1: Analyze the problem to extract key information
        analysis_instruction = (
            "Analyze the problem statement to identify key variables, constraints, "
            "and the mathematical domain (e.g., algebra, geometry, combinatorics). "
            "Provide a structured breakdown of the problem components."
        )
        problem_analysis = await self.generate(instruction=analysis_instruction, context=self.problem_text)
        
        # Step 2: Generate multiple solution approaches
        generate_instruction_template = (
            f"Based on the following problem analysis:\n{problem_analysis}\n"
            "Develop a detailed solution approach using {method}. "
            "Ensure all constraints are addressed and provide step-by-step reasoning."
        )
        
        # Define methods to explore
        methods = ["algebraic manipulation", "geometric reasoning", "combinatorial analysis"]
        generate_tasks = [
            self.generate(instruction=generate_instruction_template.format(method=method), context=self.problem_text)
            for method in methods
        ]
        solution_approaches = await asyncio.gather(*generate_tasks)
        
        # Step 3: Refine and validate each solution approach
        refine_instruction_template = (
            "Critique and improve the following solution approach:\n{approach}\n"
            "Ensure mathematical correctness, address all constraints, and consider edge cases."
        )
        refine_tasks = [
            self.revise(instruction=refine_instruction_template.format(approach=approach), context=self.problem_text)
            for approach in solution_approaches
        ]
        refined_solutions = await asyncio.gather(*refine_tasks)
        
        # Step 4: Synthesize the best solution
        ensemble_instruction = (
            "Evaluate the following refined solutions and select the most robust and accurate one:\n"
            "{solutions}\n"
            "Provide a justification for your choice and ensure it satisfies all problem constraints."
        )
        best_solution = await self.ensemble(
            instruction=ensemble_instruction.format(solutions="\n".join(refined_solutions)),
            contexts=refined_solutions
        )
        
        # Step 5: Summarize the final result
        summarize_instruction = (
            "Condense the following solution into a clear and concise summary:\n{solution}\n"
            "Include the final answer and key reasoning steps."
        )
        final_summary = await self.summarize(
            instruction=summarize_instruction.format(solution=best_solution),
            context=self.problem_text
        )
        
        return final_summary