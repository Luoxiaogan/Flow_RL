# Workflow ID: high_level_math_ganluo_460_0
# Benchmark: high_level_math_ganluo
# Data Indices: [585, 767]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract critical information from the problem
        extraction_instruction = (
            "Extract all variables, constants, equations, inequalities, and constraints from the problem. "
            "Identify the type of problem (e.g., algebra, geometry, combinatorics). "
            "Summarize the goal of the problem in clear terms."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        approach_instructions = [
            f"Using algebraic methods, solve the problem based on the following extracted information: {extracted_info}",
            f"Using combinatorial or probabilistic methods, analyze the problem based on the following extracted information: {extracted_info}",
            f"Using geometric reasoning, interpret and solve the problem based on the following extracted information: {extracted_info}",
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Refine each solution approach
        refine_instruction_template = (
            "Critique and improve the following solution approach. Ensure all constraints are satisfied, "
            "intermediate steps are valid, and the reasoning is clear. Identify and address any gaps or errors."
        )
        refined_approaches = await asyncio.gather(
            *[self.revise(instruction=refine_instruction_template, context=approach) for approach in approaches]
        )

        # Step 4: Ensemble decision-making to select or synthesize the best solution
        ensemble_instruction = (
            "Evaluate the following candidate solutions. Select the most rigorous and complete solution, "
            "or synthesize a new solution that combines the strengths of the candidates. "
            "Ensure the final solution satisfies all constraints and is mathematically sound."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_approaches)

        # Step 5: Summarize the final solution for clarity and conciseness
        summary_instruction = (
            "Condense the following solution into a concise and clear format. Highlight the key result and reasoning."
        )
        summarized_solution = await self.summarize(instruction=summary_instruction, context=final_solution)

        return summarized_solution