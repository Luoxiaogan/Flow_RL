# Workflow ID: high_level_math_ganluo_321_0
# Benchmark: high_level_math_ganluo
# Data Indices: [195, 288]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all relevant information from the problem, including variables, constraints, "
            "and relationships. Identify the type of mathematical problem (e.g., algebraic, geometric, "
            "combinatorial) and any specific techniques that might be applicable."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple candidate solutions
        candidate_instructions = [
            f"Using algebraic techniques, solve the problem step by step. Relevant information: {extracted_info}",
            f"Using geometric reasoning, approach the problem. Relevant information: {extracted_info}",
            f"Using combinatorial methods, analyze the problem. Relevant information: {extracted_info}"
        ]
        candidate_solutions = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in candidate_instructions]
        )

        # Step 3: Refine candidate solutions
        refinement_instruction = (
            "Critique and improve the given solution. Ensure that all steps are mathematically sound, "
            "adhere to the problem's constraints, and address any edge cases."
        )
        refined_solutions = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction, context=sol) for sol in candidate_solutions]
        )

        # Step 4: Synthesize the best solution
        ensemble_instruction = (
            "Compare the provided solutions and select the most correct, elegant, and efficient one. "
            "If there are discrepancies, resolve them and provide a final answer."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_solutions)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the solution into a concise and clear format. Include only the essential steps "
            "and the final answer."
        )
        summarized_solution = await self.summarize(instruction=summary_instruction, context=final_solution)

        return summarized_solution