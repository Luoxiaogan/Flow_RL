# Workflow ID: high_level_math_ganluo_111_0
# Benchmark: high_level_math_ganluo
# Data Indices: [255, 470]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all numerical values, variables, constraints, and the specific question being asked. "
            "Organize the information into a structured format for further processing."
        )
        key_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        approach_instructions = [
            f"Using an algebraic approach, solve the problem based on the following extracted information: {key_info}. "
            "Provide a step-by-step solution.",
            
            f"Using a geometric approach, solve the problem based on the following extracted information: {key_info}. "
            "Provide a step-by-step solution.",
            
            f"Using a combinatorial or number-theoretic approach, solve the problem based on the following extracted information: {key_info}. "
            "Provide a step-by-step solution."
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Evaluate and select the best solution
        ensemble_instruction = (
            "Evaluate the provided solutions and select the most mathematically rigorous, logically consistent, and efficient one. "
            "If multiple approaches are valid, synthesize their insights into a unified solution."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=approaches)

        # Step 4: Refine the selected solution
        refinement_instruction = (
            "Critique and refine the provided solution to ensure clarity, correctness, and adherence to mathematical rigor. "
            "Correct any errors, fill gaps in reasoning, and improve the overall presentation."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Summarize the solution in a concise and structured format. Include the final answer and key steps used to derive it."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_summary