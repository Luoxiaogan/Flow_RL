# Workflow ID: high_level_math_ganluo_132_0
# Benchmark: high_level_math_ganluo
# Data Indices: [586, 828]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information and decompose the problem
        problem_analysis = await self.generate(
            instruction="Extract all numerical values, constraints, and the specific question being asked. "
                        "Break the problem into smaller, solvable components. "
                        "Provide a structured summary of the problem.",
            context=self.problem_text
        )

        # Step 2: Generate multiple solution approaches in parallel
        algebraic_approach = self.generate(
            instruction=f"Using algebraic techniques, solve the problem. Consider all constraints and conditions. "
                        f"Provide a step-by-step solution. Key information: {problem_analysis}",
            context=self.problem_text
        )
        geometric_approach = self.generate(
            instruction=f"Using geometric reasoning, solve the problem. Consider all constraints and conditions. "
                        f"Provide a step-by-step solution. Key information: {problem_analysis}",
            context=self.problem_text
        )
        combinatorial_approach = self.generate(
            instruction=f"Using combinatorial or probabilistic methods, solve the problem. "
                        f"Consider all constraints and conditions. Provide a step-by-step solution. "
                        f"Key information: {problem_analysis}",
            context=self.problem_text
        )

        # Execute approaches in parallel
        approaches = await asyncio.gather(algebraic_approach, geometric_approach, combinatorial_approach)

        # Step 3: Refine each approach
        refined_approaches = await asyncio.gather(
            self.revise(instruction="Critique and refine this solution. Ensure accuracy, simplify expressions, "
                                    "and verify adherence to constraints.", context=approaches[0]),
            self.revise(instruction="Critique and refine this solution. Ensure accuracy, simplify expressions, "
                                    "and verify adherence to constraints.", context=approaches[1]),
            self.revise(instruction="Critique and refine this solution. Ensure accuracy, simplify expressions, "
                                    "and verify adherence to constraints.", context=approaches[2])
        )

        # Step 4: Synthesize and decide on the best solution
        final_solution = await self.ensemble(
            instruction="Compare these solutions and select the most robust, accurate, and clear approach. "
                        "Ensure the chosen solution satisfies all constraints and is mathematically sound.",
            contexts=refined_approaches
        )

        # Step 5: Summarize the final solution
        final_summary = await self.summarize(
            instruction="Condense the final solution into a concise, verifiable form. "
                        "Ensure the answer satisfies all constraints and is presented in the required format.",
            context=final_solution
        )

        return final_summary