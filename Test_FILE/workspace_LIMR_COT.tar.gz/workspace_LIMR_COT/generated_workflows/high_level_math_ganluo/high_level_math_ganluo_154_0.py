# Workflow ID: high_level_math_ganluo_154_0
# Benchmark: high_level_math_ganluo
# Data Indices: [645, 232]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = """
        Analyze the problem statement and extract all essential information, including:
        - Variables involved
        - Equations or relationships provided
        - Constraints or conditions
        - The specific question or goal to be solved
        Organize the extracted information in a structured format for further processing.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a solution strategy
        strategy_instruction = f"""
        Based on the following extracted information:
        {extracted_info}
        Devise a comprehensive solution strategy. Include:
        - Identification of the mathematical domain(s) (e.g., algebra, geometry, combinatorics)
        - Suggested methods or techniques (e.g., substitution, coordinate geometry, recursion)
        - A step-by-step outline of how to approach the problem
        Ensure the strategy is general enough to adapt to variations of the problem.
        """
        strategy = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Explore multiple solution approaches in parallel
        algebraic_instruction = f"""
        Solve the problem using algebraic methods. Follow the strategy outlined below:
        {strategy}
        Focus on manipulating equations, solving systems, and simplifying expressions.
        """
        geometric_instruction = f"""
        Solve the problem using geometric reasoning. Follow the strategy outlined below:
        {strategy}
        Focus on interpreting the problem geometrically, calculating areas/volumes, and applying theorems.
        """
        combinatorial_instruction = f"""
        Solve the problem using combinatorial or probabilistic reasoning. Follow the strategy outlined below:
        {strategy}
        Focus on counting principles, recursive structures, and expected values.
        """
        algebraic_solution, geometric_solution, combinatorial_solution = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 4: Refine the solutions
        refinement_instruction = """
        Critique and refine the provided solution. Address any errors, ambiguities, or inefficiencies.
        Ensure the solution is mathematically rigorous and adheres to the problem's constraints.
        """
        refined_algebraic = await self.revise(instruction=refinement_instruction, context=algebraic_solution)
        refined_geometric = await self.revise(instruction=refinement_instruction, context=geometric_solution)
        refined_combinatorial = await self.revise(instruction=refinement_instruction, context=combinatorial_solution)

        # Step 5: Select the best solution
        selection_instruction = """
        Compare the following solutions and select the most robust, elegant, and correct one:
        - Algebraic Solution
        - Geometric Solution
        - Combinatorial Solution
        Ensure the chosen solution satisfies all constraints and conditions of the problem.
        """
        final_solution = await self.ensemble(
            instruction=selection_instruction,
            contexts=[refined_algebraic, refined_geometric, refined_combinatorial]
        )

        # Step 6: Summarize the final solution
        summary_instruction = """
        Summarize the final solution in a concise and clear format. Include:
        - The key steps taken to solve the problem
        - The final answer
        - Any additional insights or verifications
        """
        final_summary = await self.summarize(instruction=summary_instruction, context=final_solution)

        return final_summary