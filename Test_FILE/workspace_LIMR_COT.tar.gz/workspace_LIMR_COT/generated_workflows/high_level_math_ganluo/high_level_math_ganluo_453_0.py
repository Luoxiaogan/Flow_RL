# Workflow ID: high_level_math_ganluo_453_0
# Benchmark: high_level_math_ganluo
# Data Indices: [951, 629]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Understand and decompose the problem
        decomposition_instruction = (
            "Carefully analyze the given problem. "
            "Identify all variables, constants, constraints, and relationships. "
            "Break the problem into smaller sub-problems or steps. "
            "Provide a structured breakdown that can guide further reasoning."
        )
        problem_decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution paths in parallel
        algebraic_instruction = (
            f"Using the following problem decomposition: {problem_decomposition} "
            "Solve the problem using algebraic techniques. "
            "Ensure all steps are clearly explained and justified. "
            "If assumptions are made, state them explicitly."
        )
        geometric_instruction = (
            f"Using the following problem decomposition: {problem_decomposition} "
            "Solve the problem using geometric reasoning or coordinate geometry. "
            "Include diagrams or visual representations if helpful. "
            "Ensure all steps are clearly explained and justified."
        )
        combinatorial_instruction = (
            f"Using the following problem decomposition: {problem_decomposition} "
            "Solve the problem using combinatorial or probabilistic methods. "
            "Consider counting principles, recursive structures, or generating functions. "
            "Ensure all steps are clearly explained and justified."
        )

        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and select the best solution path
        ensemble_instruction = (
            "Compare the following candidate solutions and select the most rigorous, complete, and correct one. "
            "Ensure the chosen solution adheres to all problem constraints and provides a clear explanation. "
            "If refinements are needed, suggest specific improvements."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 4: Refine the selected solution if necessary
        refinement_instruction = (
            "Critically review the following solution. "
            "Ensure all steps are mathematically sound, all constraints are satisfied, and the reasoning is clear. "
            "Make improvements where necessary to enhance rigor and clarity."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the following solution into a concise summary. "
            "Include only the key steps, final answer, and any critical insights. "
            "Ensure the summary is easy to understand and verify."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_summary