# Workflow ID: high_level_math_ganluo_356_0
# Benchmark: high_level_math_ganluo
# Data Indices: [14, 205]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract and organize key information from the problem
        extraction_instruction = (
            "Carefully analyze the problem statement and extract all relevant information, "
            "including variables, constants, constraints, and relationships. "
            "Organize this information clearly for further reasoning."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Explore multiple solution paths in parallel
        approach_1_instruction = (
            f"Based on the extracted information: {extracted_info}, "
            "solve the problem using an algebraic or analytical approach. "
            "Provide detailed reasoning and calculations."
        )
        approach_2_instruction = (
            f"Based on the extracted information: {extracted_info}, "
            "solve the problem using a geometric or combinatorial approach. "
            "Provide detailed reasoning and calculations."
        )
        results = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text)
        )

        # Step 3: Validate and refine the solutions
        refinement_instruction = (
            "Critically evaluate the provided solution. Check for logical consistency, "
            "mathematical correctness, and adherence to the problem constraints. "
            "Refine the solution if necessary."
        )
        refined_results = await asyncio.gather(
            self.revise(instruction=refinement_instruction, context=results[0]),
            self.revise(instruction=refinement_instruction, context=results[1])
        )

        # Step 4: Select the best solution using ensemble
        ensemble_instruction = (
            "Compare the two refined solutions and select the most accurate, complete, "
            "and mathematically sound one. If both are valid, synthesize them into a single answer."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_results)

        # Step 5: Summarize the final result
        summary_instruction = (
            "Condense the final solution into a concise and clear format. "
            "Ensure all key steps and the final answer are included."
        )
        summarized_result = await self.summarize(instruction=summary_instruction, context=final_solution)

        return summarized_result