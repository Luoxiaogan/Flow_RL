# Workflow ID: high_level_math_ganluo_451_0
# Benchmark: high_level_math_ganluo
# Data Indices: [285, 344]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Identify and extract all key variables, constraints, and the specific question being asked. "
            "Include numerical values, relationships, and any implicit assumptions."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        approaches = [
            "Algebraic approach: Solve using equations, substitutions, and simplifications.",
            "Geometric approach: Interpret the problem geometrically and use spatial reasoning.",
            "Combinatorial approach: Count possibilities, use recursion, or apply combinatorial identities.",
            "Number-theoretic approach: Analyze divisibility, modular arithmetic, or prime factorizations."
        ]
        approach_instructions = [
            f"Using the following extracted information:\n{extracted_info}\n"
            f"Solve the problem using the {approach} Provide detailed reasoning and calculations."
            for approach in approaches
        ]
        approach_results = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Evaluate and select the best solution
        ensemble_instruction = (
            "Compare the provided solutions based on correctness, mathematical rigor, and alignment with the problem constraints. "
            "Select the most accurate and efficient solution. If multiple solutions are valid, synthesize them into a single coherent answer."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=approach_results)

        # Step 4: Verify and refine the final solution
        revise_instruction = (
            "Critique the solution for correctness and completeness. Ensure it satisfies all constraints and accounts for edge cases. "
            "Refine the reasoning if necessary."
        )
        refined_solution = await self.revise(instruction=revise_instruction, context=best_solution)

        # Step 5: Summarize the final result
        summarize_instruction = (
            "Condense the reasoning and results into a concise, readable format. Include the final answer and key insights."
        )
        final_summary = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_summary