# Workflow ID: high_level_math_ganluo_141_0
# Benchmark: high_level_math_ganluo
# Data Indices: [630, 220]

```python
class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio
        
        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Carefully analyze the problem statement and extract all relevant information, "
            "including variables, constraints, objectives, and any implicit conditions. "
            "Organize the extracted information in a structured format."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)
        
        # Step 2: Generate multiple solution approaches in parallel
        algebraic_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "develop an algebraic approach to solve the problem. Include detailed steps, "
            "equations, and reasoning. Ensure the solution aligns with the problem constraints."
        )
        geometric_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "develop a geometric approach to solve the problem. Include diagrams (if applicable), "
            "key theorems, and reasoning. Ensure the solution aligns with the problem constraints."
        )
        combinatorial_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "develop a combinatorial approach to solve the problem. Include counting principles, "
            "recursive formulas, or generating functions if applicable. Ensure the solution "
            "aligns with the problem constraints."
        )
        
        approaches = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )
        
        # Step 3: Evaluate and synthesize the best solution
        ensemble_instruction = (
            "Compare the following solution approaches and determine the most effective one. "
            "Consider factors such as correctness, simplicity, alignment with constraints, and "
            "mathematical rigor. If multiple approaches are valid, synthesize them into a unified solution."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=approaches)
        
        # Step 4: Refine the selected solution
        refinement_instruction = (
            "Critique the following solution and refine it to ensure correctness, clarity, "
            "and completeness. Address any gaps in reasoning, simplify complex expressions, "
            "and verify that all constraints are satisfied."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)
        
        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the following solution into a concise, well-structured format suitable "
            "for presentation. Highlight key steps, final answers, and any important insights."
        )
        final_output = await self.summarize(instruction=summary_instruction, context=refined_solution)
        
        return final_output
```