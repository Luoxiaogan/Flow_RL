# Workflow ID: high_level_math_ganluo_427_0
# Benchmark: high_level_math_ganluo
# Data Indices: [551, 486]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key components of the problem
        extraction_instruction = (
            "Extract all variables, constants, equations, constraints, and relationships "
            "from the problem statement. Organize them into a structured format."
        )
        extracted_components = await self.generate(instruction=extraction_instruction, context=self.problem_text)
        
        # Step 2: Generate multiple solution approaches
        approach_instructions = [
            f"Using algebraic manipulation, solve the problem based on the following extracted components: {extracted_components}",
            f"Using geometric reasoning, solve the problem based on the following extracted components: {extracted_components}",
            f"Using combinatorial analysis, solve the problem based on the following extracted components: {extracted_components}",
            f"Using number theory techniques, solve the problem based on the following extracted components: {extracted_components}"
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )
        
        # Step 3: Evaluate and select the best approach
        ensemble_instruction = (
            "Compare the following solution approaches and select the most mathematically rigorous and efficient one. "
            "Provide justification for your selection."
        )
        best_approach = await self.ensemble(instruction=ensemble_instruction, contexts=approaches)
        
        # Step 4: Refine the selected approach
        refinement_instruction = (
            f"Refine the following solution approach to ensure it is complete, rigorous, and free of errors: {best_approach}. "
            "Address any ambiguities or computational complexities."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_approach)
        
        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the following refined solution into a concise, well-structured format. "
            "Ensure all constraints and requirements of the problem are satisfied."
        )
        final_solution = await self.summarize(instruction=summary_instruction, context=refined_solution)
        
        return final_solution