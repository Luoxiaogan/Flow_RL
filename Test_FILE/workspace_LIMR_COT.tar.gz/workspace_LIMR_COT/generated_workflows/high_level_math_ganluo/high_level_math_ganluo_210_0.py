# Workflow ID: high_level_math_ganluo_210_0
# Benchmark: high_level_math_ganluo
# Data Indices: [523, 869]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information and constraints from the problem
        extraction_instruction = (
            "Extract all key variables, constraints, and relationships from the problem. "
            "Organize them into categories such as equations, inequalities, sequences, or geometric properties. "
            "Ensure that all numerical values and conditions are clearly identified."
        )
        key_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        approach_instructions = [
            f"Using an algebraic approach, solve the problem step by step. Key information: {key_info}",
            f"Using a geometric approach, interpret the problem visually and derive a solution. Key information: {key_info}",
            f"Using combinatorial reasoning, count or analyze possible outcomes. Key information: {key_info}",
            f"Using number theory techniques, explore divisibility, modular arithmetic, or prime factorization. Key information: {key_info}"
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Evaluate and synthesize the best approach
        ensemble_instruction = (
            "Evaluate the following candidate solutions for correctness, elegance, and feasibility. "
            "Select the best approach or synthesize insights from multiple solutions. "
            "Ensure that the final solution satisfies all constraints and conditions."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=approaches)

        # Step 4: Refine the selected solution
        refinement_instruction = (
            "Critique and refine the provided solution to ensure clarity, correctness, and completeness. "
            "Verify that all problem constraints are satisfied and that the reasoning is mathematically sound."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the solution into a concise yet complete form. "
            "Include the final answer and any key steps or insights that led to it."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_summary