# Workflow ID: high_level_math_ganluo_50_0
# Benchmark: high_level_math_ganluo
# Data Indices: [440, 39]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract critical information from the problem
        extraction_instruction = (
            "Extract all key information from the problem, including equations, constraints, "
            "variables, and what is being asked. Organize the information clearly."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        approach_instruction = (
            f"Based on the extracted information:\n{extracted_info}\n"
            "Propose multiple solution approaches. Consider different mathematical domains (e.g., algebra, geometry, combinatorics) "
            "and techniques (e.g., casework, symmetry, recursion). Provide detailed reasoning for each approach."
        )
        approaches = await asyncio.gather(
            self.generate(instruction=approach_instruction, context=self.problem_text),
            self.generate(instruction=approach_instruction, context=self.problem_text)
        )

        # Step 3: Refine each approach
        refine_instruction_template = (
            "Critique and refine the following solution approach. Ensure the reasoning is rigorous, "
            "and correct any errors or gaps in logic. Provide an improved version of the approach."
        )
        refined_approaches = await asyncio.gather(
            self.revise(instruction=refine_instruction_template, context=approaches[0]),
            self.revise(instruction=refine_instruction_template, context=approaches[1])
        )

        # Step 4: Ensemble decision-making
        ensemble_instruction = (
            "Compare and synthesize the following refined approaches. Select the most robust and elegant solution, "
            "or combine insights from multiple approaches if beneficial. Justify your decision."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_approaches)

        # Step 5: Summarize the final answer
        summarize_instruction = (
            "Condense the final solution into a concise, well-structured answer that directly addresses the problem's requirements. "
            "Ensure clarity and correctness."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=final_solution)

        return final_answer