# Workflow ID: high_level_math_ganluo_58_0
# Benchmark: high_level_math_ganluo
# Data Indices: [954, 438]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Initial Analysis - Extract key components
        extraction_instruction = (
            "Extract all variables, equations, constraints, and the specific question being asked from the problem. "
            "Format the output as a structured summary."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Strategic Decomposition - Break into sub-problems
        decomposition_instruction = (
            f"Based on the following extracted information: {extracted_info}\n"
            "Decompose the problem into logical steps or sub-problems. "
            "Identify potential solution paths (e.g., algebraic, geometric, combinatorial)."
        )
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 3: Parallel Exploration - Explore multiple approaches
        algebra_instruction = (
            f"Solve the problem using algebraic methods. Consider the following decomposition: {decomposition}"
        )
        geometry_instruction = (
            f"Solve the problem using geometric reasoning. Consider the following decomposition: {decomposition}"
        )
        combinatorics_instruction = (
            f"Solve the problem using combinatorial analysis. Consider the following decomposition: {decomposition}"
        )

        algebra_result, geometry_result, combinatorics_result = await asyncio.gather(
            self.generate(instruction=algebra_instruction, context=self.problem_text),
            self.generate(instruction=geometry_instruction, context=self.problem_text),
            self.generate(instruction=combinatorics_instruction, context=self.problem_text)
        )

        # Step 4: Evaluation and Synthesis - Select or synthesize best approach
        ensemble_instruction = (
            "Evaluate the following candidate solutions and select the most promising one. "
            "If multiple solutions are complementary, synthesize them into a unified answer. "
            "Ensure the solution satisfies all constraints and is mathematically rigorous."
        )
        best_solution = await self.ensemble(
            instruction=ensemble_instruction,
            contexts=[algebra_result, geometry_result, combinatorics_result]
        )

        # Step 5: Refinement - Critique and refine the solution
        refinement_instruction = (
            "Critique the following solution for correctness, completeness, and clarity. "
            "Refine it to ensure all constraints are satisfied and edge cases are considered."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 6: Final Output - Summarize the refined solution
        summary_instruction = (
            "Condense the following refined solution into a concise, well-structured final answer. "
            "Include all key steps and the final result."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer