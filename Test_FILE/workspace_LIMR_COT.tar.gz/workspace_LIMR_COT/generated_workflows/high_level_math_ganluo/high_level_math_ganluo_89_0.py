# Workflow ID: high_level_math_ganluo_89_0
# Benchmark: high_level_math_ganluo
# Data Indices: [711, 459]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Problem Decomposition
        extraction = await self.generate(
            instruction="Extract all key components of the problem, including numerical values, variables, constraints, and what is being asked.",
            context=self.problem_text
        )

        # Step 2: Explore Multiple Solution Paths in Parallel
        algebraic_solution = self.generate(
            instruction=f"Using algebraic methods, solve the problem step by step. Key components: {extraction}",
            context=self.problem_text
        )
        geometric_solution = self.generate(
            instruction=f"Using geometric reasoning, solve the problem step by step. Key components: {extraction}",
            context=self.problem_text
        )
        combinatorial_solution = self.generate(
            instruction=f"Using combinatorial or probabilistic methods, solve the problem step by step. Key components: {extraction}",
            context=self.problem_text
        )
        results = await asyncio.gather(algebraic_solution, geometric_solution, combinatorial_solution)

        # Step 3: Refine Each Solution Path
        refined_results = await asyncio.gather(
            self.revise(
                instruction="Critique and refine this solution. Ensure all constraints are satisfied and calculations are accurate.",
                context=results[0]
            ),
            self.revise(
                instruction="Critique and refine this solution. Ensure all constraints are satisfied and calculations are accurate.",
                context=results[1]
            ),
            self.revise(
                instruction="Critique and refine this solution. Ensure all constraints are satisfied and calculations are accurate.",
                context=results[2]
            )
        )

        # Step 4: Synthesize Results
        final_solution = await self.ensemble(
            instruction="Compare these solutions and select the most accurate and complete one. Ensure it satisfies all problem constraints.",
            contexts=refined_results
        )

        # Step 5: Prepare Final Output
        summary = await self.summarize(
            instruction="Condense the final solution into a concise, clear format. Include only the essential steps and the final answer.",
            context=final_solution
        )

        return summary