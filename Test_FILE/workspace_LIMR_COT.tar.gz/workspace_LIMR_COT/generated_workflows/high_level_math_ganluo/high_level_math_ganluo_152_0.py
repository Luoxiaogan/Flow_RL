# Workflow ID: high_level_math_ganluo_152_0
# Benchmark: high_level_math_ganluo
# Data Indices: [560, 95]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all key information from the problem, including variables, constraints, "
            "and the objective. Organize this information into categories such as 'Given Data', "
            "'Constraints', and 'Objective'. Ensure that the extraction is complete and precise."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        approach_instructions = [
            f"Using algebraic manipulation, derive a step-by-step solution based on the following extracted information: {extracted_info}.",
            f"Using geometric reasoning, interpret the problem visually and derive a step-by-step solution based on the following extracted information: {extracted_info}.",
            f"Using casework analysis, consider different scenarios and derive a step-by-step solution based on the following extracted information: {extracted_info}."
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Evaluate and select the best approach
        ensemble_instruction = (
            "Evaluate the provided solution approaches based on clarity, feasibility, and alignment with the problem's constraints. "
            "Select the most promising approach and provide a justification for your choice."
        )
        best_approach = await self.ensemble(instruction=ensemble_instruction, contexts=approaches)

        # Step 4: Refine the selected approach
        refine_instruction = (
            f"Critique and improve the following solution approach: {best_approach}. "
            "Ensure that it adheres to all constraints, is mathematically rigorous, and addresses any edge cases."
        )
        refined_solution = await self.revise(instruction=refine_instruction, context=best_approach)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the following solution into a concise, verifiable format. "
            "Ensure that it clearly states the final answer and satisfies all problem requirements."
        )
        final_solution = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_solution