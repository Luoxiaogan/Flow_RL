# Workflow ID: high_level_math_ganluo_110_0
# Benchmark: high_level_math_ganluo
# Data Indices: [4, 102]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information and understand the problem
        problem_understanding = await self.generate(
            instruction="Extract all key variables, constraints, and the goal from the problem. "
                        "Identify the mathematical domain (e.g., algebra, geometry, number theory) and any special techniques required. "
                        "Provide a structured summary of the problem.",
            context=self.problem_text
        )

        # Step 2: Generate multiple independent approaches in parallel
        approaches = await asyncio.gather(
            self.generate(
                instruction="Solve the problem using an algebraic approach. Focus on equations, substitutions, and simplifications.",
                context=problem_understanding
            ),
            self.generate(
                instruction="Solve the problem using a geometric or visual approach. Consider diagrams, coordinate geometry, or trigonometric relationships.",
                context=problem_understanding
            ),
            self.generate(
                instruction="Solve the problem using combinatorial or number-theoretic techniques. Look for patterns, modular arithmetic, or recursive structures.",
                context=problem_understanding
            )
        )

        # Step 3: Refine each approach to ensure correctness and clarity
        refined_approaches = await asyncio.gather(
            *[self.revise(
                instruction=f"Review and refine the following solution. Ensure all steps are mathematically valid, "
                            f"eliminate errors, and clarify reasoning. Verify that all constraints from the original problem are satisfied.",
                context=approach
            ) for approach in approaches]
        )

        # Step 4: Synthesize the best solution using Ensemble
        final_solution = await self.ensemble(
            instruction="Compare and evaluate the refined solutions. Select the most robust, accurate, and complete solution. "
                        "If multiple solutions are equally valid, combine their strengths into a single coherent answer.",
            contexts=refined_approaches
        )

        # Step 5: Summarize the final solution for clarity and conciseness
        summarized_solution = await self.summarize(
            instruction="Condense the final solution into a concise and clear format. "
                        "Ensure it directly answers the original problem and includes all critical steps and results.",
            context=final_solution
        )

        return summarized_solution