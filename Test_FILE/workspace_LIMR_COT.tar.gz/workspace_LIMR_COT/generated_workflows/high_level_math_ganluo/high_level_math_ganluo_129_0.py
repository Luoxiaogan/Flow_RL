# Workflow ID: high_level_math_ganluo_129_0
# Benchmark: high_level_math_ganluo
# Data Indices: [771, 157]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Understand and decompose the problem
        problem_understanding = await self.generate(
            instruction="Extract all given information, constraints, and identify what is being asked in the problem. "
                        "Include any relevant mathematical domains or techniques that might be applicable.",
            context=self.problem_text
        )

        # Step 2: Generate multiple solution approaches
        approaches = await asyncio.gather(
            self.generate(
                instruction=f"Based on the problem understanding: {problem_understanding}, "
                            "develop an algebraic approach to solve the problem. Include step-by-step reasoning.",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"Based on the problem understanding: {problem_understanding}, "
                            "develop a geometric approach to solve the problem. Include step-by-step reasoning.",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"Based on the problem understanding: {problem_understanding}, "
                            "develop a combinatorial or probabilistic approach to solve the problem. Include step-by-step reasoning.",
                context=self.problem_text
            )
        )

        # Step 3: Evaluate and synthesize the best solution
        best_solution = await self.ensemble(
            instruction="Evaluate the following approaches based on correctness, simplicity, and adherence to problem constraints. "
                        "Select the best solution or synthesize a combined solution if necessary.",
            contexts=approaches
        )

        # Step 4: Refine the selected solution
        refined_solution = await self.revise(
            instruction="Critique and refine the following solution to ensure it is mathematically sound, "
                        "satisfies all constraints, and is presented clearly.",
            context=best_solution
        )

        # Step 5: Summarize the final solution
        final_solution = await self.summarize(
            instruction="Condense the following solution into a concise yet comprehensive answer.",
            context=refined_solution
        )

        return final_solution