# Workflow ID: high_level_math_ganluo_331_0
# Benchmark: high_level_math_ganluo
# Data Indices: [994, 985]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Analyze the problem and extract key information
        problem_analysis = await self.generate(
            instruction="Analyze the problem thoroughly. Identify all variables, constants, relationships, and constraints. "
                        "If applicable, categorize the problem into one of the following domains: "
                        "algebra, geometry, combinatorics, number theory, or probability. "
                        "Provide a structured breakdown of the problem.",
            context=self.problem_text
        )

        # Step 2: Generate multiple solution paths in parallel
        algebraic_solution = self.generate(
            instruction=f"Using algebraic methods, solve the problem step by step. "
                        f"Ensure all steps are justified mathematically. Problem analysis: {problem_analysis}",
            context=self.problem_text
        )
        geometric_solution = self.generate(
            instruction=f"Using geometric reasoning, solve the problem step by step. "
                        f"Include diagrams or visual representations if helpful. Problem analysis: {problem_analysis}",
            context=self.problem_text
        )
        combinatorial_solution = self.generate(
            instruction=f"Using combinatorial methods, solve the problem step by step. "
                        f"Consider counting principles, recursive formulas, or generating functions. "
                        f"Problem analysis: {problem_analysis}",
            context=self.problem_text
        )

        # Execute the solution paths in parallel
        solutions = await asyncio.gather(algebraic_solution, geometric_solution, combinatorial_solution)

        # Step 3: Evaluate and synthesize the best solution
        best_solution = await self.ensemble(
            instruction="Compare the provided solutions and select the most accurate, complete, and elegant one. "
                        "Ensure the chosen solution satisfies all constraints and is mathematically rigorous.",
            contexts=solutions
        )

        # Step 4: Refine the chosen solution
        refined_solution = await self.revise(
            instruction="Critique and refine the solution. Check for logical consistency, mathematical accuracy, "
                        "and clarity. Ensure the solution is presented in a clear and professional manner.",
            context=best_solution
        )

        # Step 5: Summarize the final solution
        final_solution = await self.summarize(
            instruction="Condense the solution into a concise, well-structured format. "
                        "Include only the essential steps and the final answer.",
            context=refined_solution
        )

        return final_solution