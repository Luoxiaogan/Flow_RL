# Workflow ID: high_level_math_ganluo_223_0
# Benchmark: high_level_math_ganluo
# Data Indices: [650, 812]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction = await self.generate(
            instruction="Extract all key mathematical entities, relationships, and constraints from the problem. "
                        "Include variables, equations, inequalities, and any other relevant details. "
                        "Organize the information clearly for use in subsequent steps.",
            context=self.problem_text
        )

        # Step 2: Explore two distinct solution approaches in parallel
        approach_1 = self.generate(
            instruction=f"Using the extracted information: {extraction}, "
                        "solve the problem using an algebraic or analytical approach. "
                        "Provide a step-by-step reasoning process, ensuring all constraints are satisfied.",
            context=self.problem_text
        )
        approach_2 = self.generate(
            instruction=f"Using the extracted information: {extraction}, "
                        "solve the problem using a geometric or combinatorial approach if applicable. "
                        "Provide a step-by-step reasoning process, ensuring all constraints are satisfied.",
            context=self.problem_text
        )
        results = await asyncio.gather(approach_1, approach_2)
        solution_1, solution_2 = results

        # Step 3: Validate and refine both solutions in parallel
        refinement_1 = self.revise(
            instruction="Critique and improve this solution. "
                        "Check for logical consistency, adherence to constraints, and computational accuracy. "
                        "Suggest corrections if needed.",
            context=solution_1
        )
        refinement_2 = self.revise(
            instruction="Critique and improve this solution. "
                        "Check for logical consistency, adherence to constraints, and computational accuracy. "
                        "Suggest corrections if needed.",
            context=solution_2
        )
        refined_results = await asyncio.gather(refinement_1, refinement_2)
        refined_solution_1, refined_solution_2 = refined_results

        # Step 4: Compare and select the best solution
        final_solution = await self.ensemble(
            instruction="Compare the two solutions and select the most robust, elegant, and accurate one. "
                        "Consider simplicity, clarity, and adherence to problem constraints. "
                        "If both solutions are valid, choose the one with fewer assumptions or computations.",
            contexts=[refined_solution_1, refined_solution_2]
        )

        # Step 5: Summarize the final answer
        final_answer = await self.summarize(
            instruction="Condense the selected solution into a concise final answer. "
                        "Focus on the requested output format and ensure clarity.",
            context=final_solution
        )

        return final_answer