# Workflow ID: high_level_math_ganluo_15_0
# Benchmark: high_level_math_ganluo
# Data Indices: [719, 384]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Analyze and decompose the problem
        analysis_instruction = (
            "Analyze the problem thoroughly. Identify all variables, equations, constraints, "
            "and objectives. Determine potential solution paths and required techniques."
        )
        problem_analysis = await self.generate(instruction=analysis_instruction, context=self.problem_text)

        # Step 2: Generate candidate solutions using parallel exploration
        algebraic_instruction = (
            f"Using algebraic methods, solve the problem based on the following analysis: {problem_analysis}. "
            "Provide step-by-step reasoning and ensure all constraints are satisfied."
        )
        combinatorial_instruction = (
            f"Using combinatorial or probabilistic methods, solve the problem based on the following analysis: {problem_analysis}. "
            "Provide step-by-step reasoning and ensure all constraints are satisfied."
        )
        geometric_instruction = (
            f"Using geometric or trigonometric methods, solve the problem based on the following analysis: {problem_analysis}. "
            "Provide step-by-step reasoning and ensure all constraints are satisfied."
        )

        # Run parallel solution paths
        candidate_solutions = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text)
        )

        # Step 3: Revise and validate each candidate solution
        revised_solutions = []
        for solution in candidate_solutions:
            revision_instruction = (
                f"Critique and refine the following solution: {solution}. Ensure it is mathematically correct, "
                "satisfies all constraints, and is presented in a clear and logical manner."
            )
            revised_solution = await self.revise(instruction=revision_instruction, context=solution)
            revised_solutions.append(revised_solution)

        # Step 4: Ensemble decision-making
        ensemble_instruction = (
            "Compare the following candidate solutions and select the most robust, accurate, and elegant one. "
            "Provide justification for your choice."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=revised_solutions)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the following solution into a concise and clear format. Ensure it directly answers the problem "
            "and includes all necessary steps and reasoning."
        )
        final_output = await self.summarize(instruction=summary_instruction, context=final_solution)

        return final_output