# Workflow ID: high_level_math_ganluo_238_0
# Benchmark: high_level_math_ganluo
# Data Indices: [746, 90]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key components and understand the problem
        extraction_instruction = (
            "Carefully analyze the given problem and extract all relevant mathematical entities, "
            "constraints, and relationships. Organize this information clearly and concisely."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution strategies
        strategy_instruction = (
            f"Based on the extracted information: {extracted_info}, formulate multiple solution strategies. "
            "Consider different mathematical techniques such as algebraic manipulation, combinatorial reasoning, "
            "geometric analysis, or number theory. Provide detailed reasoning for each strategy."
        )
        strategies = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Explore strategies in parallel
        strategy_list = strategies.split("\n\n")  # Split strategies into individual approaches
        parallel_tasks = [
            self.generate(
                instruction=f"Develop a complete solution using the following strategy: {strategy}",
                context=self.problem_text
            )
            for strategy in strategy_list
        ]
        solutions = await asyncio.gather(*parallel_tasks)

        # Step 4: Evaluate and select the best solution
        evaluation_instruction = (
            "Evaluate the provided solutions and select the best one based on correctness, simplicity, "
            "and adherence to the problem constraints. Provide a justification for your choice."
        )
        best_solution = await self.ensemble(instruction=evaluation_instruction, contexts=solutions)

        # Step 5: Refine and verify the selected solution
        refinement_instruction = (
            "Critically review the selected solution for correctness, edge cases, and clarity. "
            "Simplify expressions if possible and ensure the solution satisfies all problem constraints."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 6: Summarize the final answer
        summary_instruction = (
            "Summarize the refined solution into a concise and clear final answer. "
            "Include only the essential steps and the final result."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer