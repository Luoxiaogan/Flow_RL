# Workflow ID: high_level_math_ganluo_16_0
# Benchmark: high_level_math_ganluo
# Data Indices: [950, 55]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information and decompose the problem
        extract_instruction = (
            "Carefully analyze the problem and extract all key numerical values, variables, "
            "constraints, and relationships. Organize this information in a structured format."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Formulate multiple solution strategies
        strategy_instruction_template = (
            f"Based on the extracted information: {extracted_info}, "
            "formulate a detailed solution strategy for the following approach: {{approach}}. "
            "Ensure the strategy includes all necessary steps and reasoning."
        )
        strategies = [
            "Algebraic manipulation",
            "Geometric reasoning",
            "Combinatorial analysis",
            "Number theory techniques"
        ]
        strategy_instructions = [strategy_instruction_template.format(approach=approach) for approach in strategies]

        # Step 3: Execute solution strategies in parallel
        strategy_results = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in strategy_instructions]
        )

        # Step 4: Evaluate and select the best solution
        ensemble_instruction = (
            "Evaluate the provided solution strategies and select the most appropriate one. "
            "Consider factors such as correctness, simplicity, and computational feasibility. "
            "Provide a justification for your selection."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=strategy_results)

        # Step 5: Refine the selected solution
        refine_instruction = (
            "Critique and improve the given solution. Ensure it is mathematically rigorous, "
            "clearly explained, and satisfies all problem constraints."
        )
        refined_solution = await self.revise(instruction=refine_instruction, context=best_solution)

        # Step 6: Summarize the final solution
        summarize_instruction = (
            "Condense the solution into a concise and well-structured format. "
            "Include the final answer and ensure it is expressed in the required form."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_answer