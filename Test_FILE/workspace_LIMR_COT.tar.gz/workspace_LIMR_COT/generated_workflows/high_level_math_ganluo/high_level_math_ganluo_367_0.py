# Workflow ID: high_level_math_ganluo_367_0
# Benchmark: high_level_math_ganluo
# Data Indices: [41, 778]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Problem Decomposition
        decomposition_instruction = (
            "Analyze the problem statement to identify key variables, constraints, and relationships. "
            "Determine the mathematical domain (e.g., algebra, geometry) and the type of problem (e.g., optimization, equation solving). "
            "Provide a structured breakdown of the problem."
        )
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Solution Path Exploration
        approach_1_instruction = (
            f"Based on the following problem decomposition: {decomposition} "
            "Solve the problem using algebraic manipulation. Include step-by-step reasoning and intermediate results."
        )
        approach_2_instruction = (
            f"Based on the following problem decomposition: {decomposition} "
            "Solve the problem using geometric reasoning. Include step-by-step reasoning and intermediate results."
        )
        approach_3_instruction = (
            f"Based on the following problem decomposition: {decomposition} "
            "Solve the problem using combinatorial or probabilistic methods. Include step-by-step reasoning and intermediate results."
        )

        # Explore multiple approaches in parallel
        results = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text),
            self.generate(instruction=approach_3_instruction, context=self.problem_text)
        )

        # Step 3: Synthesis and Decision-Making
        ensemble_instruction = (
            "Compare the following solution approaches and select the most appropriate one. "
            "Ensure the chosen solution satisfies all constraints and is mathematically sound. "
            "If multiple approaches are valid, synthesize them into a unified result."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 4: Verification and Refinement
        revise_instruction = (
            "Critique the following solution for correctness, clarity, and completeness. "
            "Ensure all constraints are satisfied and the reasoning is rigorous. "
            "Refine the solution if necessary."
        )
        refined_solution = await self.revise(instruction=revise_instruction, context=final_solution)

        # Step 5: Summarization (Optional)
        summarize_instruction = (
            "Condense the following solution into a concise and clear format. "
            "Include only the essential steps and the final answer."
        )
        summary = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return summary