# Workflow ID: high_level_math_ganluo_150_0
# Benchmark: high_level_math_ganluo
# Data Indices: [600, 240]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key components from the problem
        extraction_instruction = (
            "Extract all numerical values, constraints, entities, and relationships from the problem. "
            "Format the output as a structured summary, including labels such as 'Numerical Values:', "
            "'Constraints:', and 'Entities:' for clarity."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple candidate solutions in parallel
        candidate_instructions = [
            f"Using a combinatorial approach, solve the problem based on the following extracted information: {extracted_info}. "
            "Ensure all constraints are satisfied and provide a step-by-step solution.",

            f"Using an algebraic approach, solve the problem based on the following extracted information: {extracted_info}. "
            "Ensure all constraints are satisfied and provide a step-by-step solution.",

            f"Using a geometric or visual approach, solve the problem based on the following extracted information: {extracted_info}. "
            "Ensure all constraints are satisfied and provide a step-by-step solution."
        ]
        candidate_solutions = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in candidate_instructions]
        )

        # Step 3: Refine each candidate solution
        refinement_instruction = (
            "Critically review the provided solution. Check for logical consistency, adherence to constraints, "
            "and mathematical correctness. Revise the solution if necessary, providing a detailed explanation of changes."
        )
        refined_solutions = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction, context=sol) for sol in candidate_solutions]
        )

        # Step 4: Ensemble decision-making to select the best solution
        ensemble_instruction = (
            "Evaluate the provided solutions. Compare their correctness, clarity, and adherence to the problem constraints. "
            "Select the most robust and correct solution, or synthesize a new solution combining the best aspects of each."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_solutions)

        # Step 5: Summarize the final solution
        summarization_instruction = (
            "Condense the provided solution into a concise, well-structured final answer. Ensure all steps are clear, "
            "and the answer satisfies all problem constraints."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=final_solution)

        return final_answer