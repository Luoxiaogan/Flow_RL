# Workflow ID: high_level_math_ganluo_456_0
# Benchmark: high_level_math_ganluo
# Data Indices: [924, 106]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information and analyze the problem
        analysis_instruction = """
        Analyze the problem thoroughly. Identify the mathematical domain (e.g., algebra, geometry, combinatorics),
        key variables, equations, constraints, and any implicit or explicit conditions. Provide a structured summary
        of the problem's requirements and known information.
        """
        problem_analysis = await self.generate(instruction=analysis_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution paths in parallel
        algebra_instruction = f"""
        Solve the problem using algebraic techniques. Focus on manipulating equations, simplifying expressions,
        and identifying patterns. Ensure that all constraints from the problem analysis are satisfied.
        Problem analysis: {problem_analysis}
        """
        geometry_instruction = f"""
        Solve the problem using geometric reasoning. Translate the problem into geometric terms if possible,
        and use properties of shapes, areas, or trigonometry to find a solution. Ensure that all constraints
        from the problem analysis are satisfied.
        Problem analysis: {problem_analysis}
        """
        combinatorics_instruction = f"""
        Solve the problem using combinatorial methods. Count arrangements, use recursive formulas, or apply
        generating functions as needed. Ensure that all constraints from the problem analysis are satisfied.
        Problem analysis: {problem_analysis}
        """

        # Execute these paths in parallel
        results = await asyncio.gather(
            self.generate(instruction=algebra_instruction, context=self.problem_text),
            self.generate(instruction=geometry_instruction, context=self.problem_text),
            self.generate(instruction=combinatorics_instruction, context=self.problem_text)
        )

        # Step 3: Refine each candidate solution
        refine_instruction_template = """
        Critique and refine the following solution. Check for mathematical correctness, logical consistency,
        and adherence to all constraints. Improve clarity and rigor where necessary.
        Candidate solution: {solution}
        Problem analysis: {problem_analysis}
        """
        refined_solutions = await asyncio.gather(
            self.revise(instruction=refine_instruction_template.format(solution=results[0], problem_analysis=problem_analysis), context=results[0]),
            self.revise(instruction=refine_instruction_template.format(solution=results[1], problem_analysis=problem_analysis), context=results[1]),
            self.revise(instruction=refine_instruction_template.format(solution=results[2], problem_analysis=problem_analysis), context=results[2])
        )

        # Step 4: Synthesize the best solution
        ensemble_instruction = """
        Compare the following refined solutions and select the best one. Evaluate based on mathematical correctness,
        simplicity, elegance, and alignment with the problem's requirements. Provide a justification for your choice.
        Refined solutions:
        1. Algebraic: {algebra}
        2. Geometric: {geometry}
        3. Combinatorial: {combinatorics}
        """
        final_solution = await self.ensemble(
            instruction=ensemble_instruction.format(algebra=refined_solutions[0], geometry=refined_solutions[1], combinatorics=refined_solutions[2]),
            contexts=refined_solutions
        )

        return final_solution