# Workflow ID: high_level_math_ganluo_376_0
# Benchmark: high_level_math_ganluo
# Data Indices: [204, 34]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem text
        extraction_instruction = (
            "Extract all numerical values, constraints, and relationships from the problem. "
            "Identify the mathematical domain (e.g., combinatorics, number theory, geometry) and any special conditions."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        approach_instructions = [
            f"Using {domain} techniques, solve the problem step by step. "
            f"Ensure all constraints are satisfied and provide a clear explanation of the reasoning process."
            for domain in ["algebraic", "geometric", "combinatorial", "number-theoretic"]
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=extracted_info) for instr in approach_instructions]
        )

        # Step 3: Refine each approach
        refinement_instruction = (
            "Critique and refine the solution. Ensure it adheres to all constraints, is mathematically rigorous, "
            "and is presented in a clear, logical manner."
        )
        refined_approaches = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction, context=approach) for approach in approaches]
        )

        # Step 4: Summarize refined approaches
        summarization_instruction = (
            "Condense the solution into its essential components while preserving clarity and completeness."
        )
        summarized_approaches = await asyncio.gather(
            *[self.summarize(instruction=summarization_instruction, context=approach) for approach in refined_approaches]
        )

        # Step 5: Select the best solution
        ensemble_instruction = (
            "Compare the summarized solutions and select the most efficient, elegant, and complete one. "
            "Ensure the chosen solution satisfies all problem constraints and is mathematically sound."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=summarized_approaches)

        return final_solution