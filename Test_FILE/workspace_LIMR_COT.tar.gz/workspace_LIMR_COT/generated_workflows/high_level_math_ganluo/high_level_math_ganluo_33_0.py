# Workflow ID: high_level_math_ganluo_33_0
# Benchmark: high_level_math_ganluo
# Data Indices: [241, 726]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information and understand the problem
        extraction_instruction = (
            "Carefully analyze the problem statement and extract all relevant information, "
            "including numerical values, constraints, and the specific question being asked. "
            "Identify the mathematical domain (e.g., combinatorics, number theory, geometry) "
            "and any advanced techniques required (e.g., modular arithmetic, recursive formulas)."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        approach_1_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Develop a solution using algebraic manipulation or direct computation. "
            "Ensure all constraints are satisfied and intermediate steps are clearly explained."
        )
        approach_2_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Develop a solution using geometric reasoning or combinatorial analysis. "
            "Consider symmetry, patterns, and alternative interpretations of the problem."
        )
        results = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text)
        )

        # Step 3: Refine and validate each solution
        refine_instruction = (
            "Critically evaluate the provided solution. Check for correctness, completeness, "
            "and adherence to all problem constraints. Suggest improvements if necessary."
        )
        refined_results = await asyncio.gather(
            self.revise(instruction=refine_instruction, context=results[0]),
            self.revise(instruction=refine_instruction, context=results[1])
        )

        # Step 4: Ensemble selection to determine the best solution
        ensemble_instruction = (
            "Compare the two refined solutions and select the most robust, efficient, and mathematically sound option. "
            "If the solutions are complementary, synthesize their insights into a single coherent solution."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_results)

        # Step 5: Summarize the final answer
        summarize_instruction = (
            "Condense the final solution into a concise, well-structured answer. "
            "Ensure the format matches the problem's requirements (e.g., residue modulo 508, count of bits)."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=final_solution)

        return final_answer