# Workflow ID: high_level_math_ganluo_221_0
# Benchmark: high_level_math_ganluo
# Data Indices: [284, 342]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key components of the problem
        extraction_instruction = (
            "Extract all numerical values, variables, equations, and constraints from the problem. "
            "Identify the mathematical domain (e.g., algebra, geometry, combinatorics) and any specific techniques required. "
            "Provide a structured summary of the problem components."
        )
        problem_summary = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        approach_1_instruction = (
            f"Using the problem components: {problem_summary}, "
            "develop a solution using algebraic manipulation. "
            "If applicable, use equations, inequalities, or sequences to solve the problem step by step."
        )
        approach_2_instruction = (
            f"Using the problem components: {problem_summary}, "
            "develop a solution using geometric reasoning. "
            "If applicable, use properties of shapes, areas, volumes, or trigonometric relationships to solve the problem step by step."
        )
        approach_3_instruction = (
            f"Using the problem components: {problem_summary}, "
            "develop a solution using combinatorial or probabilistic methods. "
            "If applicable, use counting principles, recursive formulas, or expected value calculations to solve the problem step by step."
        )

        # Execute approaches in parallel
        results = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text),
            self.generate(instruction=approach_3_instruction, context=self.problem_text)
        )

        # Step 3: Refine each solution
        refine_instruction = (
            "Critique and refine the provided solution. "
            "Ensure all constraints are satisfied, verify calculations, and simplify expressions where possible. "
            "Provide a polished version of the solution."
        )
        refined_results = await asyncio.gather(
            *[self.revise(instruction=refine_instruction, context=result) for result in results]
        )

        # Step 4: Synthesize the best solution
        ensemble_instruction = (
            "Evaluate the provided solutions and select the best one. "
            "Consider accuracy, simplicity, and adherence to the problem constraints. "
            "If multiple solutions are valid, combine their insights into a single cohesive answer."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_results)

        return final_solution