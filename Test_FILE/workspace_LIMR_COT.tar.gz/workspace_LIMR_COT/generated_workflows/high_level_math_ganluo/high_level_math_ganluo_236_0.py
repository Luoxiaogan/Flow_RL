# Workflow ID: high_level_math_ganluo_236_0
# Benchmark: high_level_math_ganluo
# Data Indices: [599, 296]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key features and understand the problem
        extraction_instruction = (
            "Carefully analyze the problem statement and extract all key features, "
            "including numerical values, constraints, relationships, and the specific question being asked. "
            "Organize this information in a structured format."
        )
        extracted_features = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        approach_instructions = [
            f"Develop an algebraic approach to solve the problem using the following extracted features: {extracted_features}",
            f"Develop a combinatorial or probabilistic approach to solve the problem using the following extracted features: {extracted_features}",
            f"Develop a geometric approach to solve the problem using the following extracted features: {extracted_features}",
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Refine each approach
        refinement_instruction_template = (
            "Critically evaluate and refine the following solution approach. "
            "Ensure it adheres to all problem constraints, is mathematically rigorous, and is presented clearly. "
            "Highlight any assumptions or potential ambiguities."
        )
        refined_approaches = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction_template, context=approach) for approach in approaches]
        )

        # Step 4: Ensemble decision to select or synthesize the best solution
        ensemble_instruction = (
            "Compare the following refined solution approaches and determine the best one. "
            "If possible, synthesize elements from multiple approaches to create a superior solution. "
            "Evaluate based on correctness, elegance, and computational feasibility."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_approaches)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the final solution into a concise, well-structured format. "
            "Ensure it clearly answers the problem's question and satisfies all constraints."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=final_solution)

        return final_summary