# Workflow ID: high_level_math_ganluo_39_0
# Benchmark: high_level_math_ganluo
# Data Indices: [792, 333]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Understand the Problem
        problem_understanding = await self.generate(
            instruction="Extract all key elements from the problem, including variables, constants, constraints, and the objective. "
                        "Identify the mathematical domain (e.g., algebra, geometry, combinatorics) and any special techniques required. "
                        "Organize this information into a structured format.",
            context=self.problem_text
        )

        # Step 2: Plan the Solution
        solution_strategies = await self.generate(
            instruction=f"Based on the following understanding of the problem:\n{problem_understanding}\n"
                        "Generate multiple potential solution strategies. Consider different approaches such as algebraic manipulation, "
                        "geometric reasoning, combinatorial analysis, or number theory. Include instructions for handling edge cases "
                        "and validating assumptions.",
            context=self.problem_text
        )

        # Step 3: Execute the Solution (Parallel Generate)
        strategies = solution_strategies.split("\n\n")  # Assume strategies are separated by double newlines
        parallel_tasks = [
            self.generate(
                instruction=f"Execute the following strategy step-by-step:\n{strategy}\n"
                            "Ensure all calculations and reasoning are clearly explained.",
                context=self.problem_text
            )
            for strategy in strategies
        ]
        results = await asyncio.gather(*parallel_tasks)

        # Step 4: Evaluate and Select the Best Solution (Ensemble)
        best_solution = await self.ensemble(
            instruction="Compare the following candidate solutions and select the most accurate, complete, and efficient one. "
                        "Resolve any conflicts or inconsistencies by synthesizing the best aspects of each solution.",
            contexts=results
        )

        # Step 5: Verify the Solution (Revise)
        verified_solution = await self.revise(
            instruction="Critically evaluate the following solution to ensure it satisfies all constraints and conditions. "
                        "Identify and correct any gaps or errors in reasoning.",
            context=best_solution
        )

        # Step 6: Summarize the Final Answer
        final_answer = await self.summarize(
            instruction="Condense the following solution into a concise, well-formatted final answer. "
                        "Include only the essential information and the boxed final result.",
            context=verified_solution
        )

        return final_answer