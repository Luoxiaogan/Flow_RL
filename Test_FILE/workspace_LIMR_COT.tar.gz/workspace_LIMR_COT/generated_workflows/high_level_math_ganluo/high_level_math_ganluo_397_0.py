# Workflow ID: high_level_math_ganluo_397_0
# Benchmark: high_level_math_ganluo
# Data Indices: [418, 362]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract critical components of the problem
        extraction_instruction = (
            "Extract all numerical values, constraints, relationships, and key mathematical concepts "
            "from the problem. Organize them into categories such as 'given values', 'constraints', "
            "and 'objectives'. Ensure the extraction is comprehensive and precise."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        approach_instructions = [
            f"Using the extracted information: {extracted_info}, solve the problem using algebraic methods. "
            "Focus on equations, inequalities, and functional relationships.",
            
            f"Using the extracted information: {extracted_info}, solve the problem using geometric reasoning. "
            "Consider both synthetic geometry and coordinate geometry approaches.",
            
            f"Using the extracted information: {extracted_info}, solve the problem using combinatorial analysis. "
            "Explore counting principles, recursive structures, and probabilistic methods."
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Evaluate and select the best approach
        ensemble_instruction = (
            "Compare the provided solution approaches and select the most robust, accurate, and efficient one. "
            "Ensure the chosen approach satisfies all constraints and objectives outlined in the problem. "
            "If multiple approaches are valid, synthesize them into a unified solution."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=approaches)

        # Step 4: Refine the selected solution
        refinement_instruction = (
            "Critique and improve the clarity, accuracy, and presentation of the solution. "
            "Ensure all steps are logically sound, all constraints are satisfied, and the final answer is explicit."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the solution into a concise, clear, and polished format. "
            "Include only the essential steps and the final answer."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer