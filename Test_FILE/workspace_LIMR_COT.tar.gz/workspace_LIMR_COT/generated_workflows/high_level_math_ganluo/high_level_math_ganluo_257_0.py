# Workflow ID: high_level_math_ganluo_257_0
# Benchmark: high_level_math_ganluo
# Data Indices: [399, 990]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Problem Decomposition
        decomposition_instruction = (
            "Analyze the problem thoroughly. Identify the type of problem (e.g., algebraic, combinatorial, geometric), "
            "extract key variables, constraints, and relationships, and outline potential solution strategies. "
            "Provide a structured breakdown of the problem."
        )
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Parallel Exploration of Solution Paths
        # Define multiple reasoning strategies
        algebraic_instruction = (
            f"Based on the following problem decomposition:\n{decomposition}\n"
            "Solve the problem using algebraic techniques. Show all steps clearly, including substitutions, simplifications, "
            "and any transformations applied to the equations."
        )
        calculus_instruction = (
            f"Based on the following problem decomposition:\n{decomposition}\n"
            "Solve the problem using calculus-based methods such as differentiation or integration. "
            "Explain the reasoning behind each step and justify why this approach is applicable."
        )
        combinatorial_instruction = (
            f"Based on the following problem decomposition:\n{decomposition}\n"
            "Solve the problem using combinatorial reasoning. If applicable, use counting principles, recursive formulas, "
            "or generating functions to derive the solution."
        )

        # Execute solution paths in parallel
        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=calculus_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Evaluation and Selection
        evaluation_instruction = (
            "Evaluate the following candidate solutions and select the most promising one. "
            "Consider correctness, clarity, and adherence to problem constraints. "
            "If multiple solutions are valid, synthesize their insights into a unified answer."
        )
        selected_solution = await self.ensemble(instruction=evaluation_instruction, contexts=results)

        # Step 4: Verification and Refinement
        refinement_instruction = (
            "Verify the selected solution against the problem constraints. Check for edge cases, "
            "ensure mathematical correctness, and simplify the result if possible. Provide feedback on any issues found."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=selected_solution)

        # Step 5: Final Output
        summary_instruction = (
            "Summarize the final solution in a concise and clear format. Include the key steps, "
            "the reasoning behind the chosen approach, and the final answer."
        )
        final_output = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_output