# Workflow ID: high_level_math_ganluo_182_0
# Benchmark: high_level_math_ganluo
# Data Indices: [790, 458]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all key information from the problem, including numerical values, "
            "constraints, and the mathematical domain (e.g., algebra, geometry, combinatorics). "
            "Organize the information in a structured format."
        )
        key_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        approach_instruction = (
            f"Based on the extracted information: {key_info}, generate multiple solution approaches. "
            "Each approach should focus on a different mathematical technique or reasoning path, "
            "such as algebraic manipulation, combinatorial analysis, or geometric interpretation. "
            "Provide detailed reasoning for each approach."
        )
        approaches = await asyncio.gather(
            self.generate(instruction=approach_instruction, context=self.problem_text),
            self.generate(instruction=approach_instruction, context=self.problem_text),
            self.generate(instruction=approach_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and select the best solution
        evaluation_instruction = (
            "Evaluate the provided candidate solutions. Select the best solution based on "
            "correctness, simplicity, and adherence to problem constraints. If multiple solutions "
            "are equally valid, choose the most elegant one."
        )
        best_solution = await self.ensemble(instruction=evaluation_instruction, contexts=approaches)

        # Step 4: Refine the selected solution
        refinement_instruction = (
            "Refine the selected solution to ensure it satisfies all problem constraints and is "
            "presented in the required format. Simplify expressions, verify calculations, and "
            "highlight the final answer."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the final result
        summary_instruction = (
            "Summarize the final solution, focusing on extracting the answer in the required format. "
            "Ensure the result is concise and clearly presented."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer