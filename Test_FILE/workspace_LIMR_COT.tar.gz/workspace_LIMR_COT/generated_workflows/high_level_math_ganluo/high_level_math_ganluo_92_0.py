# Workflow ID: high_level_math_ganluo_92_0
# Benchmark: high_level_math_ganluo
# Data Indices: [351, 159]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information and understand the problem
        extraction_instruction = (
            "Extract all key information from the problem, including variables, equations, constraints, "
            "and what is being asked. Organize this information clearly."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Explore multiple solution paths in parallel
        algebraic_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using algebraic methods. "
            "Focus on equations, inequalities, and functional relationships."
        )
        combinatorial_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using combinatorial reasoning. "
            "Count possibilities, analyze patterns, and consider recursive structures if applicable."
        )
        geometric_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using geometric methods. "
            "Consider coordinate geometry, synthetic geometry, and trigonometric relationships."
        )

        algebraic_solution, combinatorial_solution, geometric_solution = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text)
        )

        # Step 3: Refine and validate each solution path
        refine_instructions = (
            "Critique and refine the given solution. Ensure all constraints are satisfied, "
            "and verify the mathematical correctness. Consider edge cases and special scenarios."
        )
        refined_algebraic = await self.revise(instruction=refine_instructions, context=algebraic_solution)
        refined_combinatorial = await self.revise(instruction=refine_instructions, context=combinatorial_solution)
        refined_geometric = await self.revise(instruction=refine_instructions, context=geometric_solution)

        # Step 4: Synthesize results using Ensemble
        synthesis_instruction = (
            "Compare and synthesize the refined solutions. Select the most appropriate solution or combine insights "
            "from multiple approaches. Resolve any conflicts or ambiguities."
        )
        final_solution = await self.ensemble(
            instruction=synthesis_instruction,
            contexts=[refined_algebraic, refined_combinatorial, refined_geometric]
        )

        # Step 5: Summarize the final result
        summary_instruction = (
            "Condense the final solution into a concise and structured format. Ensure the output directly "
            "addresses the problem and includes all necessary details."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=final_solution)

        return final_answer