# Workflow ID: high_level_math_ganluo_312_0
# Benchmark: high_level_math_ganluo
# Data Indices: [541, 991]

```python
class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract problem details and constraints
        extraction_instruction = (
            "Extract all key information from the problem statement, including the mathematical domain, "
            "specific constraints, and what the question is asking for. Organize the information clearly."
        )
        problem_details = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate solution strategy
        strategy_instruction = (
            f"Based on the following extracted information:\n{problem_details}\n"
            "Formulate a detailed solution strategy. Identify possible approaches, techniques, and formulas "
            "that can be used to solve the problem. Provide reasoning for each approach."
        )
        solution_strategy = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Generate multiple candidate solutions in parallel
        approach_1_instruction = (
            f"Using the following strategy:\n{solution_strategy}\n"
            "Implement the first approach to solve the problem step by step. Show all calculations and reasoning."
        )
        approach_2_instruction = (
            f"Using the following strategy:\n{solution_strategy}\n"
            "Implement an alternative approach to solve the problem step by step. Show all calculations and reasoning."
        )

        results = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text)
        )

        # Step 4: Evaluate and select the best solution
        ensemble_instruction = (
            "Compare the following candidate solutions and select the best one based on correctness, "
            "simplicity, and adherence to the problem constraints. If both are correct, choose the simpler one."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 5: Refine the selected solution if necessary
        refinement_instruction = (
            "Review the following solution and refine it if needed. Ensure all steps are clear, "
            "all calculations are correct, and the solution satisfies all problem constraints."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 6: Extract the final answer
        summarization_instruction = (
            "Summarize the following solution to extract the final answer. Present the answer in a clear, "
            "concise format, explicitly stating what the answer is."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_solution)

        return final_answer
```