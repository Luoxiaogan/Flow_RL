# Workflow ID: high_level_math_ganluo_310_0
# Benchmark: high_level_math_ganluo
# Data Indices: [275, 544]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key components from the problem
        extraction_instruction = (
            "Extract all key components from the problem, including variables, constants, constraints, "
            "relationships, and any mathematical structures. Format the output as a structured summary."
        )
        key_components = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        generate_instructions = [
            f"Using the following key components:\n{key_components}\n"
            "Propose a solution approach based on algebraic manipulation and equations.",
            f"Using the following key components:\n{key_components}\n"
            "Propose a solution approach based on geometric reasoning and visualization.",
            f"Using the following key components:\n{key_components}\n"
            "Propose a solution approach based on combinatorial analysis or recursive structures.",
            f"Using the following key components:\n{key_components}\n"
            "Propose a solution approach based on number theory or modular arithmetic."
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in generate_instructions]
        )

        # Step 3: Revise and improve each approach
        revise_instructions = [
            f"Critique and refine the following solution approach for mathematical rigor and completeness:\n{approach}"
            for approach in approaches
        ]
        refined_approaches = await asyncio.gather(
            *[self.revise(instruction=instr, context=approach) for instr, approach in zip(revise_instructions, approaches)]
        )

        # Step 4: Ensemble decision-making to select or synthesize the best solution
        ensemble_instruction = (
            "Compare the following refined solution approaches and select the most robust and efficient one. "
            "If multiple approaches provide complementary insights, synthesize them into a unified solution."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_approaches)

        # Step 5: Summarize the final solution
        summarize_instruction = (
            "Condense the following solution into a clear, concise, and well-structured final answer. "
            "Ensure all constraints and requirements from the original problem are satisfied."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=final_solution)

        return final_answer