# Workflow ID: high_level_math_ganluo_140_0
# Benchmark: high_level_math_ganluo
# Data Indices: [46, 497]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract Key Information
        extraction_instruction = (
            "Thoroughly analyze the problem statement and extract all critical information. "
            "Identify variables, constraints, relationships, and the desired output. "
            "Format your response as a structured summary."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate Multiple Solution Approaches
        algebra_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "solve the problem using algebraic techniques. Focus on equations, expressions, and transformations."
        )
        geometry_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "solve the problem using geometric reasoning. Consider shapes, angles, areas, and spatial relationships."
        )
        combinatorics_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "solve the problem using combinatorial methods. Count arrangements, apply probability, or use recursive formulas."
        )

        approaches = await asyncio.gather(
            self.generate(instruction=algebra_instruction, context=self.problem_text),
            self.generate(instruction=geometry_instruction, context=self.problem_text),
            self.generate(instruction=combinatorics_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and Select the Best Approach
        ensemble_instruction = (
            "Compare the provided solution approaches critically. "
            "Select the most accurate, efficient, and elegant solution that satisfies all problem constraints."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=approaches)

        # Step 4: Refine the Selected Solution
        refine_instruction = (
            "Review the selected solution carefully. "
            "Improve clarity, ensure correctness, and verify adherence to all constraints. "
            "Highlight any assumptions or edge cases."
        )
        refined_solution = await self.revise(instruction=refine_instruction, context=best_solution)

        # Step 5: Summarize the Final Answer
        summarize_instruction = (
            "Condense the refined solution into a concise summary. "
            "Include the final answer, key steps, and any important insights."
        )
        final_summary = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_summary