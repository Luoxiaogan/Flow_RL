# Workflow ID: high_level_math_ganluo_218_0
# Benchmark: high_level_math_ganluo
# Data Indices: [856, 25]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract all relevant information from the problem text
        extraction_instruction = (
            "Extract all numerical values, constraints, and the specific question being asked. "
            "Organize this information clearly, ensuring nothing is omitted."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Explore multiple solution paths in parallel
        algebraic_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Solve the problem using an algebraic approach. Include all steps, justify assumptions, "
            "and verify intermediate results. Ensure the solution satisfies all constraints."
        )
        combinatorial_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Solve the problem using a combinatorial or probabilistic approach. Include all steps, "
            "justify assumptions, and verify intermediate results. Ensure the solution satisfies all constraints."
        )
        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )
        algebraic_solution, combinatorial_solution = results

        # Step 3: Refine and validate the solutions
        refinement_instruction = (
            "Critically review the provided solution. Identify and correct any errors, "
            "fill gaps in reasoning, and ensure all constraints are satisfied. "
            "Provide a revised version of the solution with improved clarity and correctness."
        )
        refined_algebraic = await self.revise(instruction=refinement_instruction, context=algebraic_solution)
        refined_combinatorial = await self.revise(instruction=refinement_instruction, context=combinatorial_solution)

        # Step 4: Ensemble decision-making to select the best solution
        ensemble_instruction = (
            "Compare the two refined solutions. Evaluate their correctness, completeness, "
            "and adherence to the problem constraints. Select the best solution or synthesize "
            "a new one that combines the strengths of both."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=[refined_algebraic, refined_combinatorial])

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the final solution into a clear, concise format. Highlight the key steps, "
            "reasoning, and final answer. Ensure the summary is easy to understand and mathematically accurate."
        )
        summarized_solution = await self.summarize(instruction=summary_instruction, context=final_solution)

        return summarized_solution