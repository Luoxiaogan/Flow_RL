# Workflow ID: high_level_math_ganluo_402_0
# Benchmark: high_level_math_ganluo
# Data Indices: [582, 532]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract problem components and identify solution strategies
        extraction_instruction = (
            "Analyze the problem thoroughly. Identify what is being asked, "
            "list all given data, constraints, and conditions. Suggest multiple "
            "potential solution strategies (e.g., algebraic manipulation, geometric reasoning, casework)."
        )
        problem_analysis = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple candidate solutions in parallel
        candidate_instructions = [
            f"Using an algebraic approach, solve the problem step by step. Problem analysis: {problem_analysis}",
            f"Using a geometric or visual reasoning approach, solve the problem step by step. Problem analysis: {problem_analysis}",
            f"Using combinatorial or number-theoretic reasoning, solve the problem step by step. Problem analysis: {problem_analysis}"
        ]
        candidate_solutions = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in candidate_instructions]
        )

        # Step 3: Evaluate and select the best solution
        evaluation_instruction = (
            "Compare the following candidate solutions. Evaluate them based on correctness, "
            "completeness, and efficiency. Select the best solution and provide reasoning for your choice."
        )
        best_solution = await self.ensemble(instruction=evaluation_instruction, contexts=candidate_solutions)

        # Step 4: Refine the selected solution
        refinement_instruction = (
            "Critique and improve the following solution. Ensure all constraints are satisfied, "
            "and the reasoning is rigorous and clear."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the final solution
        summarization_instruction = (
            "Condense the solution into a concise and clear format. Include only the essential steps "
            "and the final answer."
        )
        final_solution = await self.summarize(instruction=summarization_instruction, context=refined_solution)

        return final_solution