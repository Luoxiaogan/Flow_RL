# Workflow ID: high_level_math_ganluo_73_0
# Benchmark: high_level_math_ganluo
# Data Indices: [357, 700]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extracted_info = await self.generate(
            instruction="Extract all key information from the problem, including what is being asked, "
                        "any constraints, numerical values, geometric relationships, or other relevant details. "
                        "Organize this information into a structured format.",
            context=self.problem_text
        )

        # Step 2: Generate multiple solution strategies in parallel
        algebraic_solution = self.generate(
            instruction=f"Using the extracted information: {extracted_info}, "
                        "solve the problem using algebraic methods. Provide step-by-step reasoning.",
            context=self.problem_text
        )
        geometric_solution = self.generate(
            instruction=f"Using the extracted information: {extracted_info}, "
                        "solve the problem using geometric methods. Provide step-by-step reasoning.",
            context=self.problem_text
        )
        combinatorial_solution = self.generate(
            instruction=f"Using the extracted information: {extracted_info}, "
                        "solve the problem using combinatorial methods. Provide step-by-step reasoning.",
            context=self.problem_text
        )

        # Execute the strategies in parallel
        results = await asyncio.gather(algebraic_solution, geometric_solution, combinatorial_solution)

        # Step 3: Revise each solution to address potential errors or gaps
        revised_solutions = await asyncio.gather(
            self.revise(
                instruction="Critique and refine this algebraic solution. Ensure all steps are correct, "
                            "and address any missing details or logical gaps.",
                context=results[0]
            ),
            self.revise(
                instruction="Critique and refine this geometric solution. Ensure all steps are correct, "
                            "and address any missing details or logical gaps.",
                context=results[1]
            ),
            self.revise(
                instruction="Critique and refine this combinatorial solution. Ensure all steps are correct, "
                            "and address any missing details or logical gaps.",
                context=results[2]
            )
        )

        # Step 4: Ensemble decision-making to select the best solution
        final_solution = await self.ensemble(
            instruction="Evaluate these three refined solutions. Select the one that is most accurate, "
                        "clear, and adheres to the problem's constraints. If necessary, synthesize elements "
                        "from multiple solutions to create a comprehensive answer.",
            contexts=revised_solutions
        )

        # Step 5: Summarize the final solution for clarity and verification
        summary = await self.summarize(
            instruction="Summarize the chosen solution in a concise manner. Ensure the answer is clear, "
                        "satisfies all problem constraints, and provides the final result.",
            context=final_solution
        )

        return summary