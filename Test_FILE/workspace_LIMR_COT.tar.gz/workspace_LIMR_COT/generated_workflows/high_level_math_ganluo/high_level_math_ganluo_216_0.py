# Workflow ID: high_level_math_ganluo_216_0
# Benchmark: high_level_math_ganluo
# Data Indices: [520, 580]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information and structure from the problem
        extraction_instruction = (
            "Extract all numerical values, variables, equations, and constraints from the problem. "
            "Identify the specific question being asked and describe the problem structure. "
            "Format the output as a structured summary."
        )
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        approach_instructions = [
            f"Using the extracted information: {extraction}, solve the problem using an algebraic approach. "
            "Include step-by-step reasoning and verify all constraints.",
            f"Using the extracted information: {extraction}, solve the problem using a combinatorial approach. "
            "Include casework analysis if applicable and verify all constraints.",
            f"Using the extracted information: {extraction}, solve the problem using a geometric or visual approach. "
            "Include symmetry exploitation if applicable and verify all constraints."
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Refine each approach
        refinement_instructions = [
            "Critique and refine this solution. Check for logical consistency, computational accuracy, and adherence to constraints. "
            "Address any edge cases or missing details."
        ] * len(approaches)
        refined_approaches = await asyncio.gather(
            *[self.revise(instruction=refinement_instructions[i], context=approaches[i]) for i in range(len(approaches))]
        )

        # Step 4: Ensemble decision-making to select the best solution
        ensemble_instruction = (
            "Compare the following solutions and select the most mathematically sound, complete, and efficient one. "
            "Ensure the chosen solution satisfies all problem constraints and is presented clearly."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_approaches)

        # Step 5: Summarize the final solution
        summarization_instruction = (
            "Condense the solution into a concise, polished answer. Ensure it directly addresses the problem question "
            "and includes all necessary details for verification."
        )
        summary = await self.summarize(instruction=summarization_instruction, context=final_solution)

        return summary