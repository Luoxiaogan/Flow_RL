# Workflow ID: high_level_math_ganluo_23_0
# Benchmark: high_level_math_ganluo
# Data Indices: [226, 638]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all key mathematical components from the problem, including variables, constraints, "
            "mathematical domains (e.g., combinatorics, number theory), and the type of solution required. "
            "Provide this information in a structured format."
        )
        key_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution strategies
        strategy_instruction = (
            f"Based on the extracted information: {key_info}\n"
            "Generate at least three distinct solution strategies. Each strategy should include a detailed "
            "step-by-step plan for solving the problem, specifying the mathematical techniques and reasoning "
            "patterns to be used (e.g., casework analysis, recursive formulas, symmetry exploitation)."
        )
        strategies = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Execute solution strategies in parallel
        async def execute_strategy(strategy):
            return await self.generate(
                instruction=f"Follow this strategy step-by-step: {strategy}",
                context=self.problem_text
            )

        # Split strategies into individual tasks
        strategy_list = strategies.split("\n\n")  # Assuming each strategy is separated by double newlines
        results = await asyncio.gather(*(execute_strategy(strategy) for strategy in strategy_list))

        # Step 4: Evaluate and synthesize the best solution
        ensemble_instruction = (
            "Evaluate the provided candidate solutions and select the most mathematically sound and efficient one. "
            "If there are discrepancies, resolve them by analyzing the reasoning behind each solution. "
            "Provide the final solution along with a justification for your choice."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 5: Refine the final solution
        refinement_instruction = (
            "Critically review the provided solution. Ensure it satisfies all constraints and adheres to "
            "rigorous mathematical standards. Check for edge cases and simplify the solution if possible."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=final_solution)

        # Step 6: Summarize the final answer
        summary_instruction = (
            "Condense the solution into a concise, final answer. Format the result appropriately (e.g., as a "
            "simplified fraction, boxed numerical value, or probability). Ensure the output is clear and meets "
            "the problem's requirements."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer