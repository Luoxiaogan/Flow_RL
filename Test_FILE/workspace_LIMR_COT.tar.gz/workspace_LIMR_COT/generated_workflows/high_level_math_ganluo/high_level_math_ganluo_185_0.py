# Workflow ID: high_level_math_ganluo_185_0
# Benchmark: high_level_math_ganluo
# Data Indices: [535, 875]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all numerical values, constraints, conditions, and the specific question being asked. "
            "Organize this information into a structured format for further analysis."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        approach_1_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using an algebraic approach. "
            "Include all steps and reasoning explicitly."
        )
        approach_2_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using a geometric or visual approach. "
            "Include all steps and reasoning explicitly."
        )
        approach_3_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using combinatorial or probabilistic methods. "
            "Include all steps and reasoning explicitly."
        )

        results = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text),
            self.generate(instruction=approach_3_instruction, context=self.problem_text)
        )

        # Step 3: Refine each candidate solution
        refined_results = await asyncio.gather(
            self.revise(instruction="Critique and refine this solution for accuracy, completeness, and adherence to constraints.", context=results[0]),
            self.revise(instruction="Critique and refine this solution for accuracy, completeness, and adherence to constraints.", context=results[1]),
            self.revise(instruction="Critique and refine this solution for accuracy, completeness, and adherence to constraints.", context=results[2])
        )

        # Step 4: Select the best solution using Ensemble
        ensemble_instruction = (
            "Evaluate the following candidate solutions and select the most appropriate one based on correctness, clarity, and efficiency. "
            "Provide justification for your selection."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_results)

        # Step 5: Final verification and summarization
        verification_instruction = (
            "Condense the reasoning and verify that the solution addresses the problem comprehensively. "
            "Ensure all constraints are satisfied and the solution is mathematically sound."
        )
        verified_solution = await self.summarize(instruction=verification_instruction, context=final_solution)

        return verified_solution