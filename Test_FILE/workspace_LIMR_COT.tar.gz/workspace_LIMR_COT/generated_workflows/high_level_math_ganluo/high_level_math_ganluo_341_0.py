# Workflow ID: high_level_math_ganluo_341_0
# Benchmark: high_level_math_ganluo
# Data Indices: [446, 63]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract and understand the problem
        problem_understanding = await self.generate(
            instruction="Carefully analyze the problem statement. Identify all variables, constants, constraints, and the specific question being asked. Provide a structured summary.",
            context=self.problem_text
        )

        # Step 2: Generate multiple solution strategies
        strategy_1 = self.generate(
            instruction=f"Based on the problem understanding: {problem_understanding}, develop a solution using algebraic manipulation or direct computation. Explain each step clearly.",
            context=self.problem_text
        )
        strategy_2 = self.generate(
            instruction=f"Based on the problem understanding: {problem_understanding}, develop a solution using geometric reasoning or symmetry exploitation. Explain each step clearly.",
            context=self.problem_text
        )
        strategy_3 = self.generate(
            instruction=f"Based on the problem understanding: {problem_understanding}, develop a solution using combinatorial analysis or recursive structures. Explain each step clearly.",
            context=self.problem_text
        )

        # Execute strategies in parallel
        strategies = await asyncio.gather(strategy_1, strategy_2, strategy_3)

        # Step 3: Evaluate and refine solutions
        refined_solutions = []
        for i, strategy in enumerate(strategies):
            refined_solution = await self.revise(
                instruction=f"Critique and refine the following solution strategy: {strategy}. Ensure mathematical rigor, adherence to constraints, and computational feasibility.",
                context=self.problem_text
            )
            refined_solutions.append(refined_solution)

        # Step 4: Select the best solution
        best_solution = await self.ensemble(
            instruction="Compare the following refined solutions and select the most efficient, elegant, and mathematically rigorous one. Justify your choice.",
            contexts=refined_solutions
        )

        # Step 5: Extract the final answer
        final_answer = await self.summarize(
            instruction=f"Extract the final answer from the selected solution: {best_solution}. Format the answer clearly and concisely, adhering to the problem's requirements.",
            context=self.problem_text
        )

        return final_answer