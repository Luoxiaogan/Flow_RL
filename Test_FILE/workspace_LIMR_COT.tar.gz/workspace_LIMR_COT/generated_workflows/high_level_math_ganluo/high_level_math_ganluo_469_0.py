# Workflow ID: high_level_math_ganluo_469_0
# Benchmark: high_level_math_ganluo
# Data Indices: [249, 905]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract and decompose the problem
        problem_structure = await self.generate(
            instruction="Analyze the problem thoroughly. Identify all key components, including numerical values, variables, constraints, and relationships. Clearly outline the sub-problems that need to be solved.",
            context=self.problem_text
        )

        # Step 2: Generate multiple candidate solutions in parallel
        algebraic_solution = self.generate(
            instruction=f"Using an algebraic approach, solve the problem step by step. Ensure all calculations are precise and aligned with the following structure:\n{problem_structure}",
            context=self.problem_text
        )
        geometric_solution = self.generate(
            instruction=f"Using a geometric approach, solve the problem step by step. Leverage symmetry, coordinate geometry, or trigonometry as needed. Ensure alignment with the following structure:\n{problem_structure}",
            context=self.problem_text
        )
        combinatorial_solution = self.generate(
            instruction=f"Using a combinatorial or probabilistic approach, solve the problem step by step. Consider counting principles, recursive formulas, or expected value calculations. Ensure alignment with the following structure:\n{problem_structure}",
            context=self.problem_text
        )

        # Execute candidate solutions in parallel
        candidate_solutions = await asyncio.gather(algebraic_solution, geometric_solution, combinatorial_solution)

        # Step 3: Refine each candidate solution
        refined_solutions = await asyncio.gather(
            *(self.revise(
                instruction="Critique and refine the solution. Check for mathematical correctness, logical consistency, and alignment with the problem's constraints. Suggest improvements if necessary.",
                context=solution
            ) for solution in candidate_solutions)
        )

        # Step 4: Summarize each refined solution
        summarized_solutions = await asyncio.gather(
            *(self.summarize(
                instruction="Condense the solution into a concise summary. Preserve the key reasoning steps and final answer.",
                context=solution
            ) for solution in refined_solutions)
        )

        # Step 5: Ensemble decision-making
        final_solution = await self.ensemble(
            instruction="Evaluate the summarized solutions. Select the most mathematically rigorous and efficient approach. If multiple solutions are valid, synthesize their insights into a unified answer.",
            contexts=summarized_solutions
        )

        return final_solution