# Workflow ID: high_level_math_ganluo_283_0
# Benchmark: high_level_math_ganluo
# Data Indices: [96, 885]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information and understand the problem
        understanding_instruction = (
            "Carefully analyze the problem statement. "
            "Identify the mathematical domain (e.g., algebra, geometry, combinatorics), "
            "key variables, constraints, and what is being asked. "
            "Provide a structured summary of the problem's requirements and characteristics."
        )
        problem_understanding = await self.generate(instruction=understanding_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        generate_instructions = [
            "Using an algebraic approach, solve the problem step by step. "
            "Focus on equations, inequalities, and transformations. "
            f"Problem context: {problem_understanding}",

            "Using a geometric approach, solve the problem step by step. "
            "Focus on visual representations, area/volume calculations, and trigonometric relationships. "
            f"Problem context: {problem_understanding}",

            "Using a combinatorial approach, solve the problem step by step. "
            "Focus on counting principles, recursive formulas, and generating functions. "
            f"Problem context: {problem_understanding}",

            "Using number theory, solve the problem step by step. "
            "Focus on divisibility, modular arithmetic, and prime factorization. "
            f"Problem context: {problem_understanding}"
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in generate_instructions]
        )

        # Step 3: Revise each approach to ensure correctness and completeness
        revise_instructions = [
            "Critically evaluate this solution. Check for logical consistency, "
            "correctness, and completeness. Address any gaps, errors, or ambiguities. "
            "Ensure all constraints and edge cases are handled."
        ] * len(approaches)
        revised_approaches = await asyncio.gather(
            *[self.revise(instruction=revise_instr, context=approach) 
              for revise_instr, approach in zip(revise_instructions, approaches)]
        )

        # Step 4: Select the best solution or synthesize multiple approaches
        ensemble_instruction = (
            "Compare the following candidate solutions. "
            "Evaluate their correctness, elegance, and adherence to the problem constraints. "
            "If possible, synthesize elements from multiple solutions into a unified approach. "
            "Select the best overall solution."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=revised_approaches)

        # Step 5: Summarize the final answer
        summarize_instruction = (
            "Condense the solution into a concise, clear format. "
            "Highlight the key steps and present the final answer. "
            "Ensure the response is easy to understand and mathematically rigorous."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=final_solution)

        return final_answer