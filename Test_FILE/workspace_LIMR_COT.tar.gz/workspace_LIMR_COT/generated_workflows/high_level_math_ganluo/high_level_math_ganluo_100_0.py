# Workflow ID: high_level_math_ganluo_100_0
# Benchmark: high_level_math_ganluo
# Data Indices: [383, 58]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Understand and decompose the problem
        extraction_instruction = (
            "Extract all numerical values, variables, equations, and constraints from the problem. "
            "Identify the type of mathematical domain (e.g., algebra, geometry, combinatorics) and any special techniques that might apply."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution attempts in parallel
        algebraic_instruction = f"Using algebraic methods, solve the problem based on the following extracted information: {extracted_info}."
        geometric_instruction = f"Using geometric methods, solve the problem based on the following extracted information: {extracted_info}."
        combinatorial_instruction = f"Using combinatorial or probabilistic methods, solve the problem based on the following extracted information: {extracted_info}."

        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Refine each solution attempt
        refinement_instruction = (
            "Critically review the solution and ensure it satisfies all constraints and conditions stated in the problem. "
            "Check for edge cases, logical consistency, and mathematical correctness. Suggest improvements if necessary."
        )
        refined_results = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction, context=result) for result in results]
        )

        # Step 4: Ensemble decision-making to select the best solution
        ensemble_instruction = (
            "Compare the provided solutions and select the most correct, complete, and elegant one. "
            "If discrepancies exist, resolve them by analyzing the reasoning and mathematical validity of each approach."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_results)

        # Step 5: Summarize the final solution for clarity
        summarization_instruction = (
            "Condense the solution into a clear and concise format, highlighting the key steps and final answer. "
            "Ensure the summary is easy to understand while preserving all essential details."
        )
        summarized_solution = await self.summarize(instruction=summarization_instruction, context=final_solution)

        return summarized_solution