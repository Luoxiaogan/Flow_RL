# Workflow ID: high_level_math_ganluo_461_0
# Benchmark: high_level_math_ganluo
# Data Indices: [618, 472]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract relevant information from the problem
        extraction_instruction = (
            "Extract all relevant mathematical information from the problem, including variables, "
            "equations, constraints, and any specific structures (e.g., vectors, roots, functions). "
            "Categorize the problem type (e.g., algebraic, geometric, combinatorial)."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        approach_instructions = [
            f"Using algebraic methods, solve the problem based on the following extracted information: {extracted_info}.",
            f"Using geometric reasoning, interpret and solve the problem based on the following extracted information: {extracted_info}.",
            f"Using combinatorial or number-theoretic techniques, analyze and solve the problem based on the following extracted information: {extracted_info}."
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Evaluate and select the best approach
        ensemble_instruction = (
            "Compare the provided solution approaches and select the most promising one. "
            "Consider mathematical rigor, adherence to constraints, and computational feasibility."
        )
        best_approach = await self.ensemble(instruction=ensemble_instruction, contexts=approaches)

        # Step 4: Refine the chosen approach if necessary
        refinement_instruction = (
            "Critique and refine the selected solution approach. Address any ambiguities, "
            "ensure all constraints are satisfied, and improve clarity."
        )
        refined_approach = await self.revise(instruction=refinement_instruction, context=best_approach)

        # Step 5: Execute the solution step-by-step
        execution_instruction = (
            f"Solve the problem step-by-step based on the refined approach: {refined_approach}. "
            "Perform all necessary calculations, derivations, and verifications."
        )
        solution = await self.generate(instruction=execution_instruction, context=self.problem_text)

        # Step 6: Summarize the final answer
        summary_instruction = (
            "Condense the solution into a concise final answer. Ensure the answer satisfies all "
            "problem constraints and is presented in a clear, precise format."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=solution)

        return final_answer