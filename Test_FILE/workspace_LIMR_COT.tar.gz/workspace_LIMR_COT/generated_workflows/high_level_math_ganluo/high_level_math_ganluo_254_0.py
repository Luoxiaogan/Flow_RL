# Workflow ID: high_level_math_ganluo_254_0
# Benchmark: high_level_math_ganluo
# Data Indices: [36, 569]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Problem Decomposition
        decomposition_instruction = (
            "Analyze the problem to identify its mathematical domain (e.g., algebra, geometry, combinatorics), "
            "key variables, constraints, and relationships. Extract all numerical values, equations, and conditions. "
            "Provide a structured summary of the problem's components."
        )
        problem_structure = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Solution Exploration (Parallel Execution)
        algebra_instruction = (
            f"Using the problem structure: {problem_structure}, "
            "solve the problem using algebraic techniques such as equation solving, polynomial factorization, or inequalities. "
            "Provide a detailed step-by-step solution."
        )
        geometry_instruction = (
            f"Using the problem structure: {problem_structure}, "
            "solve the problem using geometric reasoning such as coordinate geometry, synthetic geometry, or trigonometry. "
            "Provide a detailed step-by-step solution."
        )
        combinatorics_instruction = (
            f"Using the problem structure: {problem_structure}, "
            "solve the problem using combinatorial techniques such as counting principles, recursion, or generating functions. "
            "Provide a detailed step-by-step solution."
        )

        algebra_solution, geometry_solution, combinatorics_solution = await asyncio.gather(
            self.generate(instruction=algebra_instruction, context=self.problem_text),
            self.generate(instruction=geometry_instruction, context=self.problem_text),
            self.generate(instruction=combinatorics_instruction, context=self.problem_text)
        )

        # Step 3: Intermediate Refinement
        refinement_instruction = (
            "Critique and refine the provided solution to ensure correctness and optimality. "
            "Check for logical consistency, computational accuracy, and adherence to problem constraints."
        )
        refined_algebra = await self.revise(instruction=refinement_instruction, context=algebra_solution)
        refined_geometry = await self.revise(instruction=refinement_instruction, context=geometry_solution)
        refined_combinatorics = await self.revise(instruction=refinement_instruction, context=combinatorics_solution)

        # Step 4: Ensemble Decision
        ensemble_instruction = (
            "Compare the following solutions and select the most valid and complete one. "
            "If multiple solutions are complementary, merge them into a unified answer. "
            "Ensure the final solution satisfies all problem constraints."
        )
        final_solution = await self.ensemble(
            instruction=ensemble_instruction,
            contexts=[refined_algebra, refined_geometry, refined_combinatorics]
        )

        # Step 5: Final Verification
        verification_instruction = (
            f"Verify the solution: {final_solution} against all problem constraints and conditions. "
            "Ensure it is mathematically sound and satisfies the original problem requirements."
        )
        verified_solution = await self.generate(instruction=verification_instruction, context=self.problem_text)

        # Step 6: Output Formatting
        summarization_instruction = (
            "Condense the verified solution into a concise and well-structured format. "
            "Include only the essential steps and the final answer."
        )
        final_output = await self.summarize(instruction=summarization_instruction, context=verified_solution)

        return final_output