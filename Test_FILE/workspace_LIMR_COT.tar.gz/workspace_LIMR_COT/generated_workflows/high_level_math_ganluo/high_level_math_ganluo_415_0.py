# Workflow ID: high_level_math_ganluo_415_0
# Benchmark: high_level_math_ganluo
# Data Indices: [328, 318]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract Problem Components
        problem_analysis = await self.generate(
            instruction="Extract and analyze the key components of the problem: "
                        "What is being asked? What are the given constraints? "
                        "Are there any implicit relationships or symmetries? "
                        "Provide a detailed breakdown.",
            context=self.problem_text
        )

        # Step 2: Generate Multiple Candidate Solutions
        algebraic_solution = self.generate(
            instruction=f"Using algebraic methods, solve the problem step-by-step. "
                        f"Ensure all constraints from the following analysis are satisfied: {problem_analysis}.",
            context=self.problem_text
        )
        geometric_solution = self.generate(
            instruction=f"Using geometric methods, solve the problem step-by-step. "
                        f"Ensure all constraints from the following analysis are satisfied: {problem_analysis}.",
            context=self.problem_text
        )
        combinatorial_solution = self.generate(
            instruction=f"Using combinatorial or probabilistic methods, solve the problem step-by-step. "
                        f"Ensure all constraints from the following analysis are satisfied: {problem_analysis}.",
            context=self.problem_text
        )

        # Execute candidate solution generation in parallel
        candidates = await asyncio.gather(algebraic_solution, geometric_solution, combinatorial_solution)

        # Step 3: Refine Each Candidate Solution
        refined_solutions = await asyncio.gather(
            *[self.revise(
                instruction="Critique and refine this solution. Ensure it is mathematically rigorous, "
                            "satisfies all constraints, and is presented clearly.",
                context=candidate
            ) for candidate in candidates]
        )

        # Step 4: Ensemble Decision-Making
        final_solution = await self.ensemble(
            instruction="Compare the following refined solutions. Select the most robust, elegant, "
                        "and correct one. If necessary, synthesize a hybrid solution that combines their strengths.",
            contexts=refined_solutions
        )

        # Step 5: Summarize the Final Solution
        summary = await self.summarize(
            instruction="Summarize the final solution concisely. Highlight the key steps, reasoning, "
                        "and the final answer in a clear and structured format.",
            context=final_solution
        )

        return summary