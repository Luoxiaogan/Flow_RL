# Workflow ID: high_level_math_ganluo_196_0
# Benchmark: high_level_math_ganluo
# Data Indices: [425, 507]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key components of the problem
        extraction_instruction = (
            "Extract all key components of the problem, including variables, constants, "
            "constraints, relationships, and the question being asked. Organize this information "
            "in a structured format for further analysis."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution strategies in parallel
        algebra_instruction = (
            f"Using the extracted information: {extracted_info}, develop an algebraic solution strategy. "
            "Focus on equations, inequalities, and functional relationships. Provide a step-by-step plan."
        )
        geometry_instruction = (
            f"Using the extracted information: {extracted_info}, develop a geometric solution strategy. "
            "Focus on shapes, angles, areas, and spatial relationships. Provide a step-by-step plan."
        )
        number_theory_instruction = (
            f"Using the extracted information: {extracted_info}, develop a number theory solution strategy. "
            "Focus on divisibility, modular arithmetic, and prime factorization. Provide a step-by-step plan."
        )

        results = await asyncio.gather(
            self.generate(instruction=algebra_instruction, context=self.problem_text),
            self.generate(instruction=geometry_instruction, context=self.problem_text),
            self.generate(instruction=number_theory_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and select the best solution path
        ensemble_instruction = (
            "Compare the following solution strategies and select the most promising one based on clarity, "
            "correctness, and feasibility. Provide reasoning for your choice."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 4: Refine the chosen solution if necessary
        refinement_instruction = (
            "Review the selected solution strategy and refine it if needed. Address any gaps, ambiguities, "
            "or errors. Ensure the solution is complete and ready for final answer extraction."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Extract the final answer
        answer_extraction_instruction = (
            "From the refined solution, extract the final answer. Ensure it is in the required format "
            "(e.g., simplified expression, decimal approximation)."
        )
        final_answer = await self.generate(instruction=answer_extraction_instruction, context=refined_solution)

        return final_answer