# Workflow ID: high_level_math_ganluo_68_0
# Benchmark: high_level_math_ganluo
# Data Indices: [216, 511]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract problem components
        extraction_instruction = (
            "Extract all key components from the problem, including variables, equations, constraints, "
            "and the specific question being asked. Organize them clearly for further analysis."
        )
        extracted_components = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple candidate solutions
        strategies = [
            "Solve the problem using algebraic manipulation and equation solving.",
            "Approach the problem using number theory techniques such as modular arithmetic or divisibility rules.",
            "Apply combinatorial reasoning or counting principles to solve the problem.",
            "Use geometric interpretations or coordinate geometry to analyze the problem."
        ]
        candidate_tasks = [
            self.generate(instruction=f"Using the following strategy: '{strategy}'\n\n"
                                      f"Extracted components:\n{extracted_components}\n\n"
                                      "Provide a detailed step-by-step solution.",
                           context=self.problem_text)
            for strategy in strategies
        ]
        candidate_solutions = await asyncio.gather(*candidate_tasks)

        # Step 3: Refine candidate solutions
        refinement_instruction = (
            "Critique and refine the provided solution. Ensure it adheres to all problem constraints, "
            "is mathematically rigorous, and provides a clear path to the final answer. "
            "If necessary, suggest improvements or corrections."
        )
        refined_tasks = [
            self.revise(instruction=refinement_instruction, context=solution)
            for solution in candidate_solutions
        ]
        refined_solutions = await asyncio.gather(*refined_tasks)

        # Step 4: Select the best solution
        selection_instruction = (
            "Evaluate the provided solutions. Select the one that is most accurate, complete, "
            "and adheres to the problem's constraints. Provide a justification for your choice."
        )
        best_solution = await self.ensemble(instruction=selection_instruction, contexts=refined_solutions)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the solution into a concise, well-structured format. Include all key steps, "
            "the final answer, and any important insights or observations."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=best_solution)

        return final_answer