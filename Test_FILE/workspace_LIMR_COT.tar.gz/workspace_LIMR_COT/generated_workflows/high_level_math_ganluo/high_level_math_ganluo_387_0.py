# Workflow ID: high_level_math_ganluo_387_0
# Benchmark: high_level_math_ganluo
# Data Indices: [563, 914]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information and classify the problem
        extraction = await self.generate(
            instruction="Extract all key mathematical elements from the problem, including variables, equations, constraints, and the desired output. Classify the problem into a specific mathematical domain (e.g., algebra, geometry, combinatorics).",
            context=self.problem_text
        )

        # Step 2: Formulate detailed solution strategies
        strategy_instruction = f"""
        Based on the extracted information: {extraction}
        Formulate a detailed plan to solve the problem. Consider multiple approaches, such as:
        - Algebraic manipulation (e.g., symmetric polynomials, functional equations)
        - Geometric reasoning (e.g., coordinate geometry, synthetic geometry)
        - Combinatorial analysis (e.g., counting principles, recursive structures)
        - Number theory techniques (e.g., modular arithmetic, divisibility)
        Include potential pitfalls and how to address them.
        """
        strategy = await self.generate(
            instruction=strategy_instruction,
            context=self.problem_text
        )

        # Step 3: Explore multiple solution paths in parallel
        algebraic_approach = self.generate(
            instruction=f"Using algebraic techniques, solve the problem step by step. Extracted information: {extraction}",
            context=self.problem_text
        )
        geometric_approach = self.generate(
            instruction=f"Using geometric reasoning, solve the problem step by step. Extracted information: {extraction}",
            context=self.problem_text
        )
        combinatorial_approach = self.generate(
            instruction=f"Using combinatorial analysis, solve the problem step by step. Extracted information: {extraction}",
            context=self.problem_text
        )

        # Execute approaches in parallel
        results = await asyncio.gather(algebraic_approach, geometric_approach, combinatorial_approach)

        # Step 4: Validate and refine intermediate results
        refined_results = []
        for result in results:
            refined = await self.revise(
                instruction="Critique and refine this solution. Ensure it satisfies all constraints and is mathematically rigorous.",
                context=result
            )
            refined_results.append(refined)

        # Step 5: Synthesize the best solution
        final_solution = await self.ensemble(
            instruction="Evaluate the provided solutions and select the most mathematically sound and efficient one. Ensure it satisfies all problem constraints.",
            contexts=refined_results
        )

        return final_solution