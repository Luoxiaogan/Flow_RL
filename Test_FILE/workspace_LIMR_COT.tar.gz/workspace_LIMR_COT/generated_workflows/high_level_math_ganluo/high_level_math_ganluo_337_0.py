# Workflow ID: high_level_math_ganluo_337_0
# Benchmark: high_level_math_ganluo
# Data Indices: [818, 847]

```python
class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information and decompose the problem
        decomposition_instruction = (
            "Carefully analyze the problem statement and identify all key components, "
            "including variables, constants, constraints, and relationships. "
            "Provide a structured breakdown of the problem."
        )
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution paths in parallel
        approach_1_instruction = (
            f"Using the following decomposition:\n{decomposition}\n"
            "Solve the problem using an algebraic or analytical approach. "
            "Include step-by-step reasoning and calculations."
        )
        approach_2_instruction = (
            f"Using the following decomposition:\n{decomposition}\n"
            "Solve the problem using a geometric or visual approach. "
            "Include step-by-step reasoning and calculations."
        )
        approach_3_instruction = (
            f"Using the following decomposition:\n{decomposition}\n"
            "Solve the problem using a combinatorial or recursive approach. "
            "Include step-by-step reasoning and calculations."
        )

        results = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text),
            self.generate(instruction=approach_3_instruction, context=self.problem_text)
        )

        # Step 3: Refine each solution path
        refinement_instruction = (
            "Review the provided solution and improve its clarity, correctness, and completeness. "
            "Ensure all steps are logically sound and satisfy the problem constraints."
        )
        refined_results = await asyncio.gather(
            self.revise(instruction=refinement_instruction, context=results[0]),
            self.revise(instruction=refinement_instruction, context=results[1]),
            self.revise(instruction=refinement_instruction, context=results[2])
        )

        # Step 4: Select the best solution using Ensemble
        ensemble_instruction = (
            "Compare the following solutions and select the most accurate, complete, and elegant one. "
            "Provide a justification for your choice."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_results)

        # Step 5: Summarize the final solution
        summarization_instruction = (
            "Condense the solution into a concise and clear format, highlighting the key steps and final answer."
        )
        summary = await self.summarize(instruction=summarization_instruction, context=final_solution)

        return summary
```