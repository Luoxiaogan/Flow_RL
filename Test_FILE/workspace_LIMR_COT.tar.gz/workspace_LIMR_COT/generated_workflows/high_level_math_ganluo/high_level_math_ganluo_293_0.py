# Workflow ID: high_level_math_ganluo_293_0
# Benchmark: high_level_math_ganluo
# Data Indices: [933, 29]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction = await self.generate(
            instruction="Extract all key variables, constraints, and relationships from the problem. "
                        "Format the output as a structured list of items.",
            context=self.problem_text
        )

        # Step 2: Generate multiple solution approaches
        approaches = await asyncio.gather(
            self.generate(
                instruction=f"Using the extracted information: {extraction}, "
                            "solve the problem using algebraic methods. Provide step-by-step reasoning.",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"Using the extracted information: {extraction}, "
                            "solve the problem using geometric reasoning. Provide step-by-step reasoning.",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"Using the extracted information: {extraction}, "
                            "solve the problem using combinatorial or probabilistic methods. Provide step-by-step reasoning.",
                context=self.problem_text
            )
        )

        # Step 3: Refine each approach
        refined_approaches = await asyncio.gather(
            *[self.revise(
                instruction="Critique and refine this solution approach. Ensure all constraints are satisfied, "
                            "and simplify expressions where possible.",
                context=approach
            ) for approach in approaches]
        )

        # Step 4: Ensemble decision to select or synthesize the best solution
        final_solution = await self.ensemble(
            instruction="Compare these refined approaches and select the most accurate, clear, and feasible solution. "
                        "If multiple approaches are valid, synthesize their insights into a single solution.",
            contexts=refined_approaches
        )

        # Step 5: Summarize the final solution
        summary = await self.summarize(
            instruction="Condense this solution into a concise, well-structured answer. "
                        "Ensure it satisfies all problem constraints and is easy to understand.",
            context=final_solution
        )

        return summary