# Workflow ID: high_level_math_ganluo_228_0
# Benchmark: high_level_math_ganluo
# Data Indices: [349, 556]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all variables, equations, constraints, and the desired output from the problem. "
            "Identify any patterns, symmetries, or special structures that might simplify the solution. "
            "Provide a clear summary of the problem's requirements."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Explore multiple solution paths in parallel
        algebraic_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem algebraically. "
            "Focus on manipulating equations, substituting variables, and simplifying expressions. "
            "Provide a step-by-step solution with clear justifications."
        )
        combinatorial_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using combinatorial reasoning. "
            "Consider counting principles, recursive relationships, or generating functions if applicable. "
            "Provide a step-by-step solution with clear justifications."
        )
        geometric_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using geometric reasoning. "
            "Consider coordinate geometry, synthetic geometry, or trigonometric methods if applicable. "
            "Provide a step-by-step solution with clear justifications."
        )

        # Execute solution paths in parallel
        algebraic_solution, combinatorial_solution, geometric_solution = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text)
        )

        # Step 3: Refine intermediate results
        refine_instruction = (
            "Critique the provided solution. Identify any errors, ambiguities, or areas for improvement. "
            "Ensure the solution satisfies all constraints and is mathematically rigorous. "
            "Provide a revised version of the solution with corrections and clarifications."
        )
        refined_algebraic = await self.revise(instruction=refine_instruction, context=algebraic_solution)
        refined_combinatorial = await self.revise(instruction=refine_instruction, context=combinatorial_solution)
        refined_geometric = await self.revise(instruction=refine_instruction, context=geometric_solution)

        # Step 4: Synthesize the final answer
        ensemble_instruction = (
            "Evaluate the refined solutions from different approaches (algebraic, combinatorial, geometric). "
            "Select the most robust, accurate, and elegant solution. Ensure the chosen solution satisfies "
            "all problem constraints and is presented clearly. Provide the final answer with justification."
        )
        final_answer = await self.ensemble(
            instruction=ensemble_instruction,
            contexts=[refined_algebraic, refined_combinatorial, refined_geometric]
        )

        return final_answer