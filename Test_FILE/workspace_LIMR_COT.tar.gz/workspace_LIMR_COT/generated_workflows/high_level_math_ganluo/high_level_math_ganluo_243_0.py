# Workflow ID: high_level_math_ganluo_243_0
# Benchmark: high_level_math_ganluo
# Data Indices: [279, 482]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information and understand the problem
        extraction_instruction = (
            "Extract all key information from the problem, including variables, constraints, "
            "and the objective. Identify potential solution paths (e.g., algebraic, geometric, combinatorial)."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Explore multiple solution paths in parallel
        algebraic_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using algebraic methods. "
            "Provide step-by-step reasoning and ensure all constraints are satisfied."
        )
        geometric_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using geometric methods. "
            "Provide step-by-step reasoning and ensure all constraints are satisfied."
        )
        combinatorial_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using combinatorial methods. "
            "Provide step-by-step reasoning and ensure all constraints are satisfied."
        )

        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Revise and refine each solution path
        revised_results = await asyncio.gather(
            self.revise(instruction="Critique and refine this solution for mathematical correctness and logical consistency.", context=results[0]),
            self.revise(instruction="Critique and refine this solution for mathematical correctness and logical consistency.", context=results[1]),
            self.revise(instruction="Critique and refine this solution for mathematical correctness and logical consistency.", context=results[2])
        )

        # Step 4: Synthesize and select the best solution
        synthesis_instruction = (
            "Compare the following refined solutions and select the most robust, elegant, and mathematically sound approach. "
            "Ensure the chosen solution satisfies all constraints and considers edge cases."
        )
        final_solution = await self.ensemble(instruction=synthesis_instruction, contexts=revised_results)

        # Step 5: Summarize the final solution for clarity
        summary_instruction = (
            "Condense the final solution into a concise and clear format, ensuring all key steps and reasoning are preserved."
        )
        summarized_solution = await self.summarize(instruction=summary_instruction, context=final_solution)

        return summarized_solution