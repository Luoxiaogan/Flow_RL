# Workflow ID: high_level_math_ganluo_78_0
# Benchmark: high_level_math_ganluo
# Data Indices: [800, 126]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information and identify problem type
        extraction_instruction = """
        Analyze the problem thoroughly. Identify all variables, constants, constraints, and relationships.
        Determine the mathematical domain (e.g., algebra, geometry, number theory) and any specific techniques required.
        Format the output as a structured summary with clear labels for each component.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        generate_approaches_instruction = f"""
        Based on the extracted information: {extracted_info}
        Propose at least two distinct solution strategies. Consider different mathematical techniques such as:
        - Algebraic manipulation
        - Geometric reasoning
        - Combinatorial analysis
        - Recursive formulas or generating functions
        - Symmetry exploitation or modular arithmetic
        For each strategy, outline the steps and reasoning clearly.
        """
        approaches = await self.generate(instruction=generate_approaches_instruction, context=self.problem_text)

        # Step 3: Execute and refine each approach in parallel
        execution_instruction_template = """
        Follow the outlined steps for the given solution strategy. Perform all necessary calculations and derivations.
        Ensure intermediate results are verified and edge cases are considered. Format the output as a step-by-step explanation.
        """
        approach_1, approach_2 = approaches.split("Approach 2:")  # Assuming two approaches are separated
        refined_results = await asyncio.gather(
            self.revise(instruction=execution_instruction_template, context=approach_1.strip()),
            self.revise(instruction=execution_instruction_template, context=approach_2.strip())
        )

        # Step 4: Synthesize and select the best solution
        synthesis_instruction = """
        Compare the provided solutions. Evaluate them based on:
        - Mathematical correctness
        - Efficiency and clarity
        - Handling of constraints and edge cases
        Select the best solution and provide a justification for the choice.
        """
        final_solution = await self.ensemble(instruction=synthesis_instruction, contexts=refined_results)

        # Step 5: Summarize the final result
        summary_instruction = """
        Condense the final solution into a concise format. Include:
        - The final answer
        - Key reasoning steps
        - Any assumptions or constraints satisfied
        """
        summarized_result = await self.summarize(instruction=summary_instruction, context=final_solution)

        return summarized_result