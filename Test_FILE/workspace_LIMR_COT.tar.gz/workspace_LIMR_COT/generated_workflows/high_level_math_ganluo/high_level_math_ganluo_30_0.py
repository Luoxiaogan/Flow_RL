# Workflow ID: high_level_math_ganluo_30_0
# Benchmark: high_level_math_ganluo
# Data Indices: [886, 717]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all key information from the problem, including variables, constraints, "
            "and the goal. Identify the mathematical domain (e.g., algebra, combinatorics) and "
            "any special techniques required (e.g., modular arithmetic, symmetry)."
        )
        key_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        approach_instructions = [
            f"Using algebraic manipulation, solve the problem step by step. Key information: {key_info}",
            f"Using combinatorial reasoning, solve the problem step by step. Key information: {key_info}",
            f"Using geometric interpretation, solve the problem step by step. Key information: {key_info}"
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Evaluate and select the best solution
        ensemble_instruction = (
            "Compare the provided solutions and select the best one based on correctness, "
            "simplicity, and adherence to the problem constraints. If multiple solutions are valid, "
            "choose the most elegant one."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=approaches)

        # Step 4: Refine the selected solution
        refinement_instruction = (
            "Refine the solution to ensure clarity, correctness, and completeness. Address any "
            "ambiguities or gaps in the reasoning."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Summarize the solution in a concise and clear format, highlighting the key steps "
            "and the final answer."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_summary