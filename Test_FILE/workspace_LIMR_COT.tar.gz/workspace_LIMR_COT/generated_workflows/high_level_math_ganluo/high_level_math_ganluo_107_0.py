# Workflow ID: high_level_math_ganluo_107_0
# Benchmark: high_level_math_ganluo
# Data Indices: [393, 934]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Carefully analyze the problem and extract all key information, including variables, equations, "
            "constraints, and the ultimate goal. Format the output clearly, separating numerical values, "
            "relationships, and any implicit conditions."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution strategies
        strategy_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Propose multiple solution strategies. Consider different mathematical approaches, such as algebraic, "
            "geometric, combinatorial, or number-theoretic methods. For each strategy, outline the key steps required."
        )
        strategies = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Execute solution paths in parallel
        solution_paths = []
        for i, strategy in enumerate(strategies.split("\n\n")):  # Assuming strategies are separated by double newlines
            path_instruction = (
                f"Follow this solution strategy step-by-step:\n{strategy}\n"
                "Ensure all calculations are accurate and all constraints are satisfied. Provide intermediate results."
            )
            solution_paths.append(self.generate(instruction=path_instruction, context=self.problem_text))
        raw_results = await asyncio.gather(*solution_paths)

        # Step 4: Validate and refine results
        refinement_tasks = []
        for result in raw_results:
            refine_instruction = (
                f"Review this solution critically:\n{result}\n"
                "Check for correctness, consistency with the problem's conditions, and mathematical rigor. "
                "Identify and correct any errors or gaps."
            )
            refinement_tasks.append(self.revise(instruction=refine_instruction, context=result))
        refined_results = await asyncio.gather(*refinement_tasks)

        # Step 5: Ensemble decision-making
        ensemble_instruction = (
            "Compare the following solutions and select the best one:\n"
            + "\n---\n".join(refined_results) + "\n"
            "Evaluate based on correctness, clarity, elegance, and adherence to the problem's requirements. "
            "If multiple solutions are valid, choose the most efficient or straightforward one."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_results)

        # Step 6: Summarize the final solution
        summary_instruction = (
            f"Condense the following solution into a concise, well-structured format:\n{final_solution}\n"
            "Ensure the output directly addresses the problem and is easy to understand."
        )
        final_output = await self.summarize(instruction=summary_instruction, context=final_solution)

        return final_output