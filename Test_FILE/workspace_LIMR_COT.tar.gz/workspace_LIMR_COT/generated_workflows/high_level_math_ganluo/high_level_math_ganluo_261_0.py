# Workflow ID: high_level_math_ganluo_261_0
# Benchmark: high_level_math_ganluo
# Data Indices: [568, 549]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Problem Understanding and Decomposition
        problem_analysis = await self.generate(
            instruction="Extract all variables, constants, constraints, and objectives from the problem. "
                        "Identify the mathematical domain (e.g., algebra, geometry, combinatorics). "
                        "Provide a structured breakdown of the problem's components.",
            context=self.problem_text
        )

        # Step 2: Solution Exploration (Parallel Execution)
        algebraic_solution = self.generate(
            instruction=f"Using algebraic methods, solve the problem step by step. "
                        f"Ensure all constraints are satisfied. Problem details: {problem_analysis}",
            context=self.problem_text
        )
        geometric_solution = self.generate(
            instruction=f"Using geometric reasoning, solve the problem step by step. "
                        f"Include any necessary diagrams or visualizations. Problem details: {problem_analysis}",
            context=self.problem_text
        )
        combinatorial_solution = self.generate(
            instruction=f"Using combinatorial or probabilistic methods, solve the problem step by step. "
                        f"Consider casework and recursive structures if applicable. Problem details: {problem_analysis}",
            context=self.problem_text
        )

        # Execute solution exploration in parallel
        results = await asyncio.gather(algebraic_solution, geometric_solution, combinatorial_solution)

        # Step 3: Solution Refinement
        refined_solutions = await asyncio.gather(
            self.revise(
                instruction="Critique and refine this solution. Ensure it is mathematically rigorous, "
                            "satisfies all constraints, and is presented clearly.",
                context=results[0]
            ),
            self.revise(
                instruction="Critique and refine this solution. Ensure it is mathematically rigorous, "
                            "satisfies all constraints, and is presented clearly.",
                context=results[1]
            ),
            self.revise(
                instruction="Critique and refine this solution. Ensure it is mathematically rigorous, "
                            "satisfies all constraints, and is presented clearly.",
                context=results[2]
            )
        )

        # Step 4: Final Selection and Synthesis
        final_solution = await self.ensemble(
            instruction="Compare these solutions and select the most robust, elegant, and correct one. "
                        "Synthesize insights from all solutions if necessary.",
            contexts=refined_solutions
        )

        # Step 5: Summarization
        summary = await self.summarize(
            instruction="Condense the final solution into a concise, well-structured format. "
                        "Include all key steps, intermediate results, and the final answer.",
            context=final_solution
        )

        return summary