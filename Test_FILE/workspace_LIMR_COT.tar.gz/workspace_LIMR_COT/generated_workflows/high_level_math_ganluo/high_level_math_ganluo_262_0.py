# Workflow ID: high_level_math_ganluo_262_0
# Benchmark: high_level_math_ganluo
# Data Indices: [781, 624]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract critical information from the problem
        extraction_instruction = """Extract all critical information from the problem, including:
        - Variables and their relationships
        - Numerical values and constraints
        - Equations, inequalities, or other mathematical structures
        - Any special conditions or requirements
        Provide this information in a structured format."""
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        approach_instructions = [
            f"Using algebraic manipulation, solve the problem based on the following extracted information: {extracted_info}",
            f"Using geometric reasoning, solve the problem based on the following extracted information: {extracted_info}",
            f"Using combinatorial analysis, solve the problem based on the following extracted information: {extracted_info}",
            f"Using number theory techniques, solve the problem based on the following extracted information: {extracted_info}"
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Evaluate and select the best approach
        evaluation_instruction = """Evaluate the provided solution approaches based on:
        - Feasibility and correctness
        - Alignment with the problem's constraints
        - Complexity and efficiency
        Select the most promising approach and justify your choice."""
        best_approach = await self.ensemble(instruction=evaluation_instruction, contexts=approaches)

        # Step 4: Develop a detailed solution using the selected approach
        solution_instruction = f"""Develop a detailed step-by-step solution using the following approach:
        {best_approach}
        Ensure all steps are mathematically rigorous and satisfy the problem's constraints."""
        detailed_solution = await self.generate(instruction=solution_instruction, context=self.problem_text)

        # Step 5: Refine and verify the solution
        refinement_instruction = """Refine the solution by:
        - Checking for mathematical correctness
        - Verifying that all constraints are satisfied
        - Addressing any edge cases or special conditions
        Provide a revised and verified version of the solution."""
        refined_solution = await self.revise(instruction=refinement_instruction, context=detailed_solution)

        # Step 6: Summarize the final solution
        summary_instruction = """Summarize the final solution in a concise format, highlighting:
        - Key steps and reasoning
        - Final result or answer"""
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_summary