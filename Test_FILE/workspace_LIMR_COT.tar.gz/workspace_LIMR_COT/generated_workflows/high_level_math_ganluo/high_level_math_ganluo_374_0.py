# Workflow ID: high_level_math_ganluo_374_0
# Benchmark: high_level_math_ganluo
# Data Indices: [816, 100]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Problem Decomposition
        decomposition_instruction = (
            "Analyze the problem thoroughly and break it into its key components. "
            "Identify the mathematical domain (e.g., algebra, geometry, number theory), "
            "list all given variables and constraints, and classify the problem type. "
            "Provide a structured summary of the findings."
        )
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Strategy Formulation
        strategy_instruction = f"Based on the following decomposition:\n{decomposition}\n"
        strategy_instruction += (
            "Generate multiple potential solution strategies. Consider different mathematical techniques "
            "(e.g., algebraic manipulation, combinatorial reasoning, modular arithmetic, geometric transformations) "
            "and outline each approach step-by-step. Ensure the strategies are comprehensive and distinct."
        )
        strategies = await asyncio.gather(
            self.generate(instruction=strategy_instruction, context=self.problem_text),
            self.generate(instruction=strategy_instruction, context=self.problem_text)
        )

        # Step 3: Solution Execution
        execution_instruction_template = (
            "Execute the following strategy step-by-step:\n{{strategy}}\n"
            "Ensure all calculations are accurate and provide intermediate results where necessary."
        )
        solutions = await asyncio.gather(
            self.generate(instruction=execution_instruction_template.format(strategy=strategies[0]), context=self.problem_text),
            self.generate(instruction=execution_instruction_template.format(strategy=strategies[1]), context=self.problem_text)
        )

        # Step 4: Result Aggregation
        ensemble_instruction = (
            "Compare the following candidate solutions and select the best one. "
            "Evaluate based on correctness, simplicity, and adherence to problem constraints. "
            "If there are discrepancies, resolve them by analyzing intermediate steps."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=solutions)

        # Step 5: Final Verification
        verification_instruction = (
            "Verify the following solution against the original problem statement:\n"
            "{{solution}}\nEnsure it satisfies all constraints and conditions. "
            "If any issues are found, suggest revisions to improve correctness and clarity."
        )
        verified_solution = await self.revise(
            instruction=verification_instruction.format(solution=final_solution),
            context=self.problem_text
        )

        # Step 6: Summarize the Final Answer
        summary_instruction = (
            "Summarize the final solution concisely while preserving all key details. "
            "Format the answer clearly and ensure it is ready for submission."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=verified_solution)

        return final_answer