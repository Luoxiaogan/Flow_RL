# Workflow ID: high_level_math_ganluo_373_0
# Benchmark: high_level_math_ganluo
# Data Indices: [690, 320]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract and Understand the Problem
        extraction_instruction = (
            "Thoroughly analyze the problem statement. "
            "Extract all numerical values, variables, constraints, and relationships. "
            "Identify the mathematical domain (e.g., algebra, geometry, combinatorics) "
            "and any specific techniques that might be applicable. "
            "Provide a structured summary of the problem's key components."
        )
        problem_analysis = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate Multiple Solution Strategies
        strategy_instruction_template = (
            "Based on the following analysis:\n{analysis}\n"
            "Develop a detailed solution strategy for the problem. "
            "Consider different mathematical approaches (e.g., algebraic, geometric, combinatorial). "
            "Provide step-by-step reasoning for each approach, ensuring all constraints are addressed."
        )
        strategy_instructions = [
            strategy_instruction_template.format(analysis=problem_analysis),
            strategy_instruction_template.format(analysis=problem_analysis) + " Focus on an alternative method.",
            strategy_instruction_template.format(analysis=problem_analysis) + " Explore a creative or unconventional approach."
        ]
        candidate_solutions = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in strategy_instructions]
        )

        # Step 3: Refine and Verify Solutions
        refinement_instruction_template = (
            "Critically evaluate the following solution:\n{solution}\n"
            "Check for mathematical correctness, logical consistency, and adherence to all constraints. "
            "Simplify expressions where possible and provide a revised version of the solution."
        )
        refined_solutions = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction_template.format(solution=sol), context=sol) for sol in candidate_solutions]
        )

        # Step 4: Summarize Complex Reasoning (Optional)
        summarization_instruction = (
            "Condense the following detailed reasoning into a concise summary, "
            "highlighting the key steps and final result:\n{reasoning}"
        )
        summarized_solutions = await asyncio.gather(
            *[self.summarize(instruction=summarization_instruction.format(reasoning=sol), context=sol) for sol in refined_solutions]
        )

        # Step 5: Select the Best Solution
        ensemble_instruction = (
            "Evaluate the following candidate solutions:\n{solutions}\n"
            "Select the most mathematically sound, efficient, and clearly explained solution. "
            "Provide a justification for your choice."
        )
        final_solution = await self.ensemble(
            instruction=ensemble_instruction.format(solutions="\n".join(summarized_solutions)),
            contexts=summarized_solutions
        )

        return final_solution