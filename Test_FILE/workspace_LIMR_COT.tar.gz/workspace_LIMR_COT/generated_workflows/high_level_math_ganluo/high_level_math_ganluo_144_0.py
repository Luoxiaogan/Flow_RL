# Workflow ID: high_level_math_ganluo_144_0
# Benchmark: high_level_math_ganluo
# Data Indices: [289, 400]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Initial Problem Analysis and Decomposition
        analysis_instruction = (
            "Carefully analyze the given problem. Identify its domain (e.g., geometry, combinatorics, number theory), "
            "key components (e.g., numerical values, constraints, relationships), and any special conditions. "
            "Provide a structured breakdown of the problem, including possible solution strategies."
        )
        problem_analysis = await self.generate(instruction=analysis_instruction, context=self.problem_text)

        # Step 2: Parallel Exploration of Solution Paths
        algebraic_instruction = (
            f"Based on the problem analysis: {problem_analysis}\n"
            "Solve the problem using an algebraic or computational approach. Focus on deriving equations, "
            "manipulating expressions, and solving step-by-step. Ensure all constraints are satisfied."
        )
        geometric_instruction = (
            f"Based on the problem analysis: {problem_analysis}\n"
            "Solve the problem using a geometric or visual approach. Focus on interpreting the problem spatially, "
            "applying relevant theorems, and calculating required quantities. Ensure all constraints are satisfied."
        )

        # Generate solutions in parallel
        algebraic_solution, geometric_solution = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text)
        )

        # Step 3: Evaluation and Synthesis
        evaluation_instruction = (
            "Compare the following two solutions and determine which one is more accurate, efficient, and adheres "
            "to the problem's constraints. If both are valid, select the clearer and more elegant solution. "
            "If neither is satisfactory, identify the issues and suggest improvements."
        )
        best_solution = await self.ensemble(
            instruction=evaluation_instruction,
            contexts=[algebraic_solution, geometric_solution]
        )

        # Step 4: Refinement (if necessary)
        refinement_instruction = (
            "Review the selected solution carefully. Check for any errors, ambiguities, or omissions. "
            "Refine the solution to ensure it is mathematically rigorous, logically consistent, and "
            "clearly presented."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Final Output Preparation
        summary_instruction = (
            "Condense the refined solution into a concise and clear format. Ensure it directly answers the "
            "problem's question and includes all necessary details (e.g., final numerical result, simplified form)."
        )
        final_solution = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_solution