# Workflow ID: high_level_math_ganluo_136_0
# Benchmark: high_level_math_ganluo
# Data Indices: [769, 879]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Problem Understanding and Decomposition
        decomposition_instruction = (
            "Analyze the problem to identify its mathematical domain (e.g., geometry, algebra, combinatorics), "
            "key variables, constraints, and relationships. Extract all numerical values, equations, or geometric properties. "
            "Provide a structured summary of the problem's requirements and structure."
        )
        problem_decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Solution Strategy Formulation
        strategy_instruction = (
            f"Based on the following problem decomposition:\n{problem_decomposition}\n"
            "Generate multiple potential solution strategies. For each strategy, provide a detailed plan of action, "
            "including the mathematical techniques or formulas to be used, and how the constraints will be addressed. "
            "Ensure the strategies are generic and adaptable to similar problems."
        )
        solution_strategies = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Parallel Exploration of Strategies
        strategies = solution_strategies.split("\n\n")  # Assuming strategies are separated by double newlines
        parallel_tasks = [
            self.generate(
                instruction=f"Execute the following solution strategy step-by-step:\n{strategy}",
                context=self.problem_text
            )
            for strategy in strategies
        ]
        intermediate_results = await asyncio.gather(*parallel_tasks)

        # Step 4: Evaluation and Selection of Best Solution
        evaluation_instruction = (
            "Evaluate the following candidate solutions and select the best one. "
            "Criteria for selection include correctness, alignment with problem constraints, and simplicity. "
            "Provide a justification for your choice."
        )
        best_solution = await self.ensemble(instruction=evaluation_instruction, contexts=intermediate_results)

        # Step 5: Refinement and Finalization
        refinement_instruction = (
            "Refine the following solution to ensure mathematical rigor and clarity. "
            "Check that all constraints are satisfied and that the solution is presented in a logical and concise manner."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        final_instruction = (
            "Summarize the following solution into a concise and clear format suitable for submission. "
            "Include only the essential steps and the final answer."
        )
        final_answer = await self.summarize(instruction=final_instruction, context=refined_solution)

        return final_answer