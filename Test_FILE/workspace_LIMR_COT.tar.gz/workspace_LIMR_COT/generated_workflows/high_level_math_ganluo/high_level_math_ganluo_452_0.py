# Workflow ID: high_level_math_ganluo_452_0
# Benchmark: high_level_math_ganluo
# Data Indices: [388, 543]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Carefully analyze the problem and extract all critical information, including numerical values, "
            "geometric relationships, algebraic expressions, and constraints. Organize the information clearly "
            "and label each piece for easy reference."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Explore multiple solution paths in parallel
        algebraic_instruction = (
            f"Based on the extracted information: {extracted_info}, solve the problem using algebraic techniques. "
            "Include all steps, justify each transformation, and ensure the solution satisfies all constraints."
        )
        geometric_instruction = (
            f"Based on the extracted information: {extracted_info}, solve the problem using geometric reasoning. "
            "Include all steps, justify each construction, and ensure the solution satisfies all constraints."
        )
        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text)
        )

        # Step 3: Refine the candidate solutions
        refinement_instruction = (
            "Critically review the provided solution. Check for logical consistency, computational accuracy, "
            "and adherence to the problem's constraints. Suggest improvements if necessary and produce a refined version."
        )
        refined_results = await asyncio.gather(
            self.revise(instruction=refinement_instruction, context=results[0]),
            self.revise(instruction=refinement_instruction, context=results[1])
        )

        # Step 4: Ensemble decision-making
        ensemble_instruction = (
            "Compare the two refined solutions. Evaluate their correctness, elegance, and adherence to the problem's requirements. "
            "Select the best solution or synthesize a new one if necessary."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_results)

        # Step 5: Prepare the final output
        summary_instruction = (
            "Condense the solution into a clear and concise format. Include all key steps, the final answer, "
            "and any relevant explanations. Ensure the output is professional and easy to understand."
        )
        final_output = await self.summarize(instruction=summary_instruction, context=final_solution)

        return final_output