# Workflow ID: high_level_math_ganluo_80_0
# Benchmark: high_level_math_ganluo
# Data Indices: [91, 966]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio
        
        # Step 1: Problem Understanding and Decomposition
        problem_understanding = await self.generate(
            instruction="Thoroughly analyze the problem statement. Identify all mathematical entities, constraints, and relationships. Extract key numerical values, equations, or geometric properties.",
            context=self.problem_text
        )
        
        # Step 2: Generate Multiple Solution Approaches
        algebraic_approach = await self.generate(
            instruction=f"Using the extracted information: {problem_understanding}, devise a solution approach based on algebraic methods. Include equations, transformations, and logical reasoning.",
            context=self.problem_text
        )
        geometric_approach = await self.generate(
            instruction=f"Using the extracted information: {problem_understanding}, devise a solution approach based on geometric methods. Include constructions, properties, and visual reasoning.",
            context=self.problem_text
        )
        
        # Step 3: Evaluate and Select Best Approach
        best_approach = await self.ensemble(
            instruction="Compare the algebraic and geometric approaches. Select the one that is most feasible, computationally efficient, and adheres to the problem constraints.",
            contexts=[algebraic_approach, geometric_approach]
        )
        
        # Step 4: Detailed Solution Construction
        detailed_solution = await self.generate(
            instruction=f"Based on the selected approach: {best_approach}, construct a detailed step-by-step solution. Ensure all mathematical steps are rigorous and logical.",
            context=self.problem_text
        )
        
        # Step 5: Verification and Refinement
        verified_solution = await self.revise(
            instruction="Verify the solution against the problem constraints. Refine any steps that are unclear or incorrect.",
            context=detailed_solution
        )
        
        # Step 6: Summarize the Final Solution
        final_solution = await self.summarize(
            instruction="Condense the verified solution into a concise and clear format. Highlight the key steps and final answer.",
            context=verified_solution
        )
        
        return final_solution