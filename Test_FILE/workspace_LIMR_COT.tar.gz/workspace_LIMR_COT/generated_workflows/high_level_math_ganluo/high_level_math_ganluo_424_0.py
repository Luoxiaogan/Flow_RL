# Workflow ID: high_level_math_ganluo_424_0
# Benchmark: high_level_math_ganluo
# Data Indices: [514, 337]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract critical components and understand the problem
        extraction_instruction = (
            "Analyze the problem thoroughly. Identify all variables, constants, "
            "constraints, and relationships. Highlight what is being asked and any "
            "specific conditions that must be satisfied. Format the output as a "
            "structured summary."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        approach_instructions = [
            f"Using the extracted information: {extracted_info}, solve the problem algebraically. "
            "Provide step-by-step reasoning and show all intermediate calculations.",

            f"Using the extracted information: {extracted_info}, solve the problem geometrically. "
            "Visualize the scenario if applicable and describe the geometric relationships.",

            f"Using the extracted information: {extracted_info}, solve the problem using combinatorial or probabilistic methods. "
            "Focus on counting principles, recursive structures, or probabilistic reasoning."
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Evaluate and select the best approach
        ensemble_instruction = (
            "Compare the following candidate solutions. Select the most promising one based "
            "on correctness, clarity, and alignment with the problem's requirements. If none "
            "are satisfactory, suggest a synthesis of their strengths."
        )
        best_approach = await self.ensemble(instruction=ensemble_instruction, contexts=approaches)

        # Step 4: Refine the selected approach
        refinement_instruction = (
            "Critique and improve the following solution. Ensure it is mathematically rigorous, "
            "satisfies all constraints, and is expressed clearly. Address any gaps or ambiguities."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_approach)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the following solution into a concise summary. Highlight the key steps, "
            "final answer, and any important insights. Ensure the summary is accessible and precise."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_summary