# Workflow ID: high_level_math_ganluo_340_0
# Benchmark: high_level_math_ganluo
# Data Indices: [952, 982]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Problem Decomposition
        decomposition_instruction = (
            "Carefully analyze the problem statement and identify the following:\n"
            "- The mathematical domain(s) involved (e.g., algebra, geometry, number theory)\n"
            "- Key variables, constants, and relationships\n"
            "- Constraints and conditions that must be satisfied\n"
            "- Potential solution strategies or approaches\n"
            "Provide a structured breakdown of the problem."
        )
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Parallel Exploration of Solution Paths
        # Define multiple solution strategies dynamically
        strategy_1_instruction = f"Using algebraic manipulation, solve the problem based on this decomposition: {decomposition}"
        strategy_2_instruction = f"Using combinatorial reasoning, solve the problem based on this decomposition: {decomposition}"
        strategy_3_instruction = f"Using geometric interpretation, solve the problem based on this decomposition: {decomposition}"

        # Execute strategies in parallel
        results = await asyncio.gather(
            self.generate(instruction=strategy_1_instruction, context=self.problem_text),
            self.generate(instruction=strategy_2_instruction, context=self.problem_text),
            self.generate(instruction=strategy_3_instruction, context=self.problem_text)
        )

        # Step 3: Evaluation and Synthesis
        ensemble_instruction = (
            "Compare the following candidate solutions and determine the most mathematically sound and complete solution:\n"
            "- Evaluate each solution's adherence to the problem constraints\n"
            "- Consider computational simplicity and clarity\n"
            "- Provide a final recommendation with justification."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 4: Refinement
        refinement_instruction = (
            "Refine the chosen solution to ensure it is:\n"
            "- Fully compliant with all problem constraints\n"
            "- Expressed in the clearest and most concise form possible\n"
            "- Verifiable and logically sound."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Final Verification and Summary
        summary_instruction = (
            "Summarize the final solution in a concise, verifiable form. Ensure:\n"
            "- All key steps and reasoning are included\n"
            "- The answer is clearly stated and satisfies all problem requirements."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_summary