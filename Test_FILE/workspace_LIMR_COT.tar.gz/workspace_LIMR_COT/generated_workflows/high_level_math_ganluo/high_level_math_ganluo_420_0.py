# Workflow ID: high_level_math_ganluo_420_0
# Benchmark: high_level_math_ganluo
# Data Indices: [845, 892]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key components from the problem text
        extraction_instruction = (
            "Extract all key components from the problem, including variables, constants, "
            "constraints, and the objective. Organize the information clearly."
        )
        key_components = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        approach_instructions = [
            f"Using algebraic methods, solve the problem based on the following extracted information: {key_components}",
            f"Using geometric reasoning, solve the problem based on the following extracted information: {key_components}",
            f"Using combinatorial analysis, solve the problem based on the following extracted information: {key_components}",
        ]
        candidate_solutions = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Refine each candidate solution
        refinement_instruction_template = (
            "Critique and refine the following solution to ensure correctness, clarity, and adherence to the problem constraints. "
            "Verify that all conditions are satisfied and address any edge cases."
        )
        refined_solutions = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction_template, context=sol) for sol in candidate_solutions]
        )

        # Step 4: Select or synthesize the best solution
        ensemble_instruction = (
            "Evaluate the following solutions and select the best one based on correctness, simplicity, and elegance. "
            "If multiple solutions are valid, synthesize them into a single optimal solution."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_solutions)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Summarize the solution concisely while ensuring it directly addresses the problem and includes all necessary steps."
        )
        summarized_solution = await self.summarize(instruction=summary_instruction, context=final_solution)

        return summarized_solution