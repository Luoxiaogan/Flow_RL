# Workflow ID: high_level_math_ganluo_124_0
# Benchmark: high_level_math_ganluo
# Data Indices: [372, 274]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key mathematical elements and understand the problem
        extraction = await self.generate(
            instruction="Extract all key mathematical elements from the problem, including equations, variables, constraints, and the goal. Provide this information in a structured format.",
            context=self.problem_text
        )

        # Step 2: Explore multiple solution paths in parallel
        approach_algebraic = self.generate(
            instruction=f"Based on the extracted information: {extraction}, solve the problem using algebraic methods. Include step-by-step reasoning and verify all constraints.",
            context=self.problem_text
        )
        approach_geometric = self.generate(
            instruction=f"Based on the extracted information: {extraction}, solve the problem using geometric reasoning. Include step-by-step reasoning and verify all constraints.",
            context=self.problem_text
        )
        approach_combinatorial = self.generate(
            instruction=f"Based on the extracted information: {extraction}, solve the problem using combinatorial or probabilistic methods if applicable. Include step-by-step reasoning and verify all constraints.",
            context=self.problem_text
        )

        # Execute approaches in parallel
        results = await asyncio.gather(approach_algebraic, approach_geometric, approach_combinatorial)

        # Step 3: Refine each solution path
        refined_results = await asyncio.gather(
            self.revise(
                instruction="Critique and refine this solution. Ensure it satisfies all constraints, handles edge cases, and is mathematically rigorous.",
                context=results[0]
            ),
            self.revise(
                instruction="Critique and refine this solution. Ensure it satisfies all constraints, handles edge cases, and is mathematically rigorous.",
                context=results[1]
            ),
            self.revise(
                instruction="Critique and refine this solution. Ensure it satisfies all constraints, handles edge cases, and is mathematically rigorous.",
                context=results[2]
            )
        )

        # Step 4: Select the best solution using Ensemble
        final_solution = await self.ensemble(
            instruction="Compare these solutions and select the best one. The chosen solution must satisfy all problem constraints, be mathematically sound, and provide the clearest path to the answer.",
            contexts=refined_results
        )

        # Step 5: Summarize the final answer
        final_answer = await self.summarize(
            instruction="Condense the final solution into a concise format, focusing on the requested output (e.g., numerical value, symbolic expression).",
            context=final_solution
        )

        return final_answer