# Workflow ID: high_level_math_ganluo_271_0
# Benchmark: high_level_math_ganluo
# Data Indices: [673, 798]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information and understand the problem
        extraction_instruction = (
            "Extract all key information from the problem, including variables, constants, constraints, "
            "and the goal. Identify the mathematical domain (e.g., algebra, geometry, combinatorics) and "
            "any specific techniques that might apply (e.g., casework, symmetry, modular arithmetic)."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution paths in parallel
        generate_instruction_template = (
            f"Based on the extracted information: {extracted_info}\n"
            "Generate a solution path using the following strategy: {{strategy}}. "
            "Ensure that all constraints are addressed and the reasoning is mathematically rigorous."
        )

        strategies = [
            "algebraic manipulation and equation solving",
            "geometric interpretation and visualization",
            "combinatorial reasoning and counting principles",
            "number theory techniques such as modular arithmetic or divisibility"
        ]

        generation_tasks = [
            self.generate(instruction=generate_instruction_template.format(strategy=strategy), context=self.problem_text)
            for strategy in strategies
        ]
        solution_paths = await asyncio.gather(*generation_tasks)

        # Step 3: Refine each solution path
        refine_instruction_template = (
            "Critique and improve the following solution path: {{solution_path}}.\n"
            "Ensure that all constraints are satisfied, the reasoning is mathematically sound, "
            "and the solution is as concise as possible."
        )

        refinement_tasks = [
            self.revise(instruction=refine_instruction_template.format(solution_path=path), context=path)
            for path in solution_paths
        ]
        refined_solutions = await asyncio.gather(*refinement_tasks)

        # Step 4: Summarize each refined solution
        summarize_instruction = (
            "Summarize the following solution, highlighting the key steps, main insights, "
            "and the final result. Ensure that the summary is concise but retains all critical information."
        )

        summarization_tasks = [
            self.summarize(instruction=summarize_instruction, context=solution)
            for solution in refined_solutions
        ]
        summarized_solutions = await asyncio.gather(*summarization_tasks)

        # Step 5: Select the best solution using Ensemble
        ensemble_instruction = (
            "Compare the following summarized solutions and select the best one. "
            "The best solution should be mathematically rigorous, satisfy all constraints, "
            "and demonstrate clarity and elegance in reasoning."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=summarized_solutions)

        return best_solution