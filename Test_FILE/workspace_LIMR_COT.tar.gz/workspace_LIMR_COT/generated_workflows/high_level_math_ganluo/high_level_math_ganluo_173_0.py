# Workflow ID: high_level_math_ganluo_173_0
# Benchmark: high_level_math_ganluo
# Data Indices: [697, 136]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract and Understand the Problem
        extraction_instruction = (
            "Extract all key components from the problem statement, including variables, constants, "
            "constraints, and the specific question being asked. Provide a structured summary."
        )
        problem_understanding = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate Multiple Solution Strategies
        strategy_instruction_template = (
            "Based on the following problem understanding: {understanding}\n"
            "Formulate a detailed step-by-step strategy to solve the problem using {approach}. "
            "Include all necessary calculations and reasoning steps."
        )
        strategies = await asyncio.gather(
            self.generate(instruction=strategy_instruction_template.format(understanding=problem_understanding, approach="algebraic methods")),
            self.generate(instruction=strategy_instruction_template.format(understanding=problem_understanding, approach="combinatorial analysis")),
            self.generate(instruction=strategy_instruction_template.format(understanding=problem_understanding, approach="geometric reasoning"))
        )

        # Step 3: Execute and Refine Each Strategy
        refine_instruction_template = (
            "Review and refine the following solution strategy to ensure correctness and completeness:\n{strategy}"
        )
        refined_strategies = await asyncio.gather(
            *[self.revise(instruction=refine_instruction_template.format(strategy=strategy), context=problem_understanding) for strategy in strategies]
        )

        # Step 4: Compare and Select the Best Solution
        ensemble_instruction = (
            "Evaluate the following solution strategies and select the most accurate and efficient one. "
            "Provide a justification for your choice."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_strategies)

        # Step 5: Summarize the Final Answer
        summarize_instruction = (
            "Summarize the final solution derived from the following detailed strategy:\n{solution}\n"
            "Ensure the answer is presented clearly and concisely, meeting all problem requirements."
        )
        final_answer = await self.summarize(instruction=summarize_instruction.format(solution=best_solution), context=problem_understanding)

        return final_answer