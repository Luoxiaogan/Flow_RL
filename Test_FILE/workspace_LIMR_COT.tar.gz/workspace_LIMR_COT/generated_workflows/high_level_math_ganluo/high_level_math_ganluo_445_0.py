# Workflow ID: high_level_math_ganluo_445_0
# Benchmark: high_level_math_ganluo
# Data Indices: [680, 531]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all relevant information from the problem
        extraction_instruction = (
            "Extract all numerical values, variables, constraints, and the question being asked. "
            "Organize this information clearly and label each component."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Propose multiple solution strategies
        strategy_instruction = (
            f"Based on the extracted information: {extracted_info}, propose multiple solution strategies. "
            "Include algebraic, geometric, combinatorial, and number-theoretic approaches if applicable. "
            "For each strategy, provide a detailed plan of action."
        )
        strategies = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Execute strategies in parallel
        parallel_instructions = [
            f"Execute this strategy step-by-step: {strategy}" for strategy in strategies.split("\n\n")
        ]
        results = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in parallel_instructions]
        )

        # Step 4: Evaluate and select the best solution
        ensemble_instruction = (
            "Compare the following solutions and select the most rigorous, efficient, and mathematically sound one. "
            "Provide a justification for your choice."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 5: Refine the selected solution
        refine_instruction = (
            "Critique and improve the following solution. Ensure it is clear, correct, and adheres to all constraints."
        )
        refined_solution = await self.revise(instruction=refine_instruction, context=best_solution)

        # Step 6: Summarize the final solution
        summary_instruction = (
            "Condense the following solution into a concise, well-structured format that directly answers the problem."
        )
        final_output = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_output