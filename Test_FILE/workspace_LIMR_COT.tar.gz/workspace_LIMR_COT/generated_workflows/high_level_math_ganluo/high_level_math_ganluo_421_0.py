# Workflow ID: high_level_math_ganluo_421_0
# Benchmark: high_level_math_ganluo
# Data Indices: [516, 183]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information and identify solution paths
        extraction = await self.generate(
            instruction="Extract all numerical values, variables, and constraints from the problem. "
                        "Identify potential solution paths (e.g., algebraic, geometric, combinatorial).",
            context=self.problem_text
        )

        # Step 2: Generate multiple solution approaches in parallel
        approaches = await asyncio.gather(
            self.generate(
                instruction=f"Using the extracted information: {extraction}, solve the problem algebraically. "
                            "Provide step-by-step reasoning.",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"Using the extracted information: {extraction}, solve the problem geometrically. "
                            "Provide step-by-step reasoning.",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"Using the extracted information: {extraction}, solve the problem using combinatorics or number theory. "
                            "Provide step-by-step reasoning.",
                context=self.problem_text
            )
        )

        # Step 3: Refine each approach for mathematical rigor
        refined_approaches = await asyncio.gather(
            self.revise(
                instruction="Critique and refine this algebraic solution. Ensure all steps are mathematically valid and satisfy the problem's constraints.",
                context=approaches[0]
            ),
            self.revise(
                instruction="Critique and refine this geometric solution. Ensure all steps are mathematically valid and satisfy the problem's constraints.",
                context=approaches[1]
            ),
            self.revise(
                instruction="Critique and refine this combinatorial/number-theoretic solution. Ensure all steps are mathematically valid and satisfy the problem's constraints.",
                context=approaches[2]
            )
        )

        # Step 4: Ensemble to select or synthesize the best solution
        final_solution = await self.ensemble(
            instruction="Compare the refined solutions and select the most robust, elegant, and mathematically rigorous one. "
                        "If multiple solutions are equally valid, synthesize them into a unified answer.",
            contexts=refined_approaches
        )

        # Step 5: Summarize the final solution for clarity
        summary = await self.summarize(
            instruction="Condense the final solution into a clear and concise form, ensuring all key steps and the final answer are included.",
            context=final_solution
        )

        return summary