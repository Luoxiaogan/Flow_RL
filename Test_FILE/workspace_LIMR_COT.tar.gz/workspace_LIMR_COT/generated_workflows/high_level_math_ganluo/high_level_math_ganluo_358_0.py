# Workflow ID: high_level_math_ganluo_358_0
# Benchmark: high_level_math_ganluo
# Data Indices: [422, 658]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract Key Information
        extraction_instruction = (
            "Carefully analyze the problem statement to identify all key elements, including variables, "
            "constraints, relationships, and any specific mathematical structures. Organize this information "
            "in a structured format that can guide subsequent steps."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate Multiple Solution Approaches
        algebra_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using algebraic methods. "
            "Focus on equations, inequalities, and functional relationships. Provide a detailed step-by-step solution."
        )
        combinatorics_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using combinatorial methods. "
            "Consider counting principles, recursive structures, or generating functions. Provide a detailed step-by-step solution."
        )
        number_theory_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using number theory techniques. "
            "Focus on divisibility, modular arithmetic, or prime factorization. Provide a detailed step-by-step solution."
        )

        # Execute approaches in parallel
        results = await asyncio.gather(
            self.generate(instruction=algebra_instruction, context=self.problem_text),
            self.generate(instruction=combinatorics_instruction, context=self.problem_text),
            self.generate(instruction=number_theory_instruction, context=self.problem_text)
        )

        # Step 3: Refine Each Solution
        refined_results = await asyncio.gather(
            *[self.revise(
                instruction="Critique and refine this solution. Ensure it adheres to all problem constraints, "
                            "is mathematically rigorous, and addresses any logical gaps.",
                context=result
            ) for result in results]
        )

        # Step 4: Select the Best Solution
        selection_instruction = (
            "Evaluate the provided solutions and select the one that is most complete, accurate, and elegant. "
            "Ensure the chosen solution satisfies all constraints and demonstrates clear reasoning."
        )
        best_solution = await self.ensemble(instruction=selection_instruction, contexts=refined_results)

        # Step 5: Summarize the Final Solution
        summary_instruction = (
            "Condense the solution into a concise format while preserving all essential details. "
            "Ensure the final output is clear, readable, and directly answers the problem."
        )
        final_output = await self.summarize(instruction=summary_instruction, context=best_solution)

        return final_output