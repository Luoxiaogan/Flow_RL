# Workflow ID: high_level_math_ganluo_444_0
# Benchmark: high_level_math_ganluo
# Data Indices: [262, 492]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key components of the problem
        extraction_instruction = (
            "Identify and extract all key components of the problem, including numerical values, variables, "
            "constraints, relationships, and the objective. Organize the extracted information clearly."
        )
        problem_extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution paths in parallel
        algebraic_instruction = (
            f"Given the extracted information: {problem_extraction}, solve the problem using algebraic techniques. "
            "Include step-by-step reasoning, equations, and calculations. Ensure all constraints are satisfied."
        )
        geometric_instruction = (
            f"Given the extracted information: {problem_extraction}, solve the problem using geometric reasoning. "
            "Include diagrams if necessary, and explain relationships between geometric entities."
        )
        combinatorial_instruction = (
            f"Given the extracted information: {problem_extraction}, solve the problem using combinatorial methods. "
            "Consider counting principles, recursive structures, and generating functions if applicable."
        )

        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Refine each solution path
        refinement_instruction = (
            "Critique and refine the provided solution. Address logical gaps, verify calculations, check edge cases, "
            "and ensure all constraints are satisfied. Provide a polished and mathematically rigorous version."
        )
        refined_results = await asyncio.gather(
            self.revise(instruction=refinement_instruction, context=results[0]),
            self.revise(instruction=refinement_instruction, context=results[1]),
            self.revise(instruction=refinement_instruction, context=results[2])
        )

        # Step 4: Compare and select the best solution
        ensemble_instruction = (
            "Evaluate the provided solutions and select the most robust, elegant, and accurate one. "
            "Consider clarity, correctness, and adherence to the problem's requirements."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_results)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the provided solution into a concise and well-structured final answer. "
            "Include only the essential steps and the final result."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=final_solution)

        return final_answer