# Workflow ID: high_level_math_ganluo_189_0
# Benchmark: high_level_math_ganluo
# Data Indices: [37, 311]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract problem details
        extraction_instruction = (
            "Extract all variables, constraints, and objectives from the problem. "
            "Identify the mathematical domain (e.g., algebra, geometry, combinatorics) and any special techniques required. "
            "Provide a structured summary of the problem's components."
        )
        problem_details = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        generate_instructions = [
            f"Develop an algebraic solution approach for the problem. Consider equations, inequalities, and functional relationships. Problem details: {problem_details}",
            f"Develop a geometric solution approach for the problem. Consider coordinate geometry, synthetic geometry, and trigonometric relationships. Problem details: {problem_details}",
            f"Develop a combinatorial or probabilistic solution approach for the problem. Consider counting principles, recursive structures, and expected values. Problem details: {problem_details}"
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in generate_instructions]
        )

        # Step 3: Refine each approach
        refine_instructions = [
            f"Critique and refine the following solution approach. Ensure mathematical rigor, check for edge cases, and verify adherence to constraints. Approach: {approach}"
            for approach in approaches
        ]
        refined_approaches = await asyncio.gather(
            *[self.revise(instruction=instr, context=approach) for instr, approach in zip(refine_instructions, approaches)]
        )

        # Step 4: Ensemble decision-making
        ensemble_instruction = (
            "Evaluate the following refined solution approaches. Select the most robust, efficient, and elegant solution. "
            "Ensure the chosen approach satisfies all problem constraints and provides a clear path to the final answer."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_approaches)

        # Step 5: Summarize the final answer
        summarize_instruction = (
            "Condense the following solution into a concise, well-structured final answer. "
            "Include all key steps and results, ensuring clarity and correctness."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=best_solution)

        return final_answer