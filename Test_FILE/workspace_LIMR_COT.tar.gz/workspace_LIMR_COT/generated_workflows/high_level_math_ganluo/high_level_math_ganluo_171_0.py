# Workflow ID: high_level_math_ganluo_171_0
# Benchmark: high_level_math_ganluo
# Data Indices: [705, 316]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all key information from the problem, including variables, constraints, "
            "and what is being asked. Organize this information clearly for further analysis."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        approach_instructions = [
            f"Using the extracted information: {extracted_info}, develop an algebraic approach to solve the problem.",
            f"Using the extracted information: {extracted_info}, develop a geometric approach to solve the problem.",
            f"Using the extracted information: {extracted_info}, develop a combinatorial or number-theoretic approach to solve the problem."
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Evaluate and select the best approach
        evaluation_instruction = (
            "Compare the following approaches based on their feasibility, correctness, and efficiency. "
            "Select the most promising approach and explain your reasoning."
        )
        best_approach = await self.ensemble(instruction=evaluation_instruction, contexts=approaches)

        # Step 4: Refine the selected approach
        refinement_instruction = (
            "Critique and refine the following approach to ensure it is mathematically rigorous, "
            "free of errors, and optimized for clarity."
        )
        refined_approach = await self.revise(instruction=refinement_instruction, context=best_approach)

        # Step 5: Execute the refined approach and summarize the solution
        execution_instruction = (
            "Execute the following refined approach step by step to derive the final solution. "
            "Ensure all calculations are accurate and all constraints are satisfied."
        )
        solution = await self.generate(instruction=execution_instruction, context=refined_approach)

        summary_instruction = (
            "Summarize the final solution in a clear and concise manner, highlighting the key steps "
            "and the final answer."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=solution)

        return final_summary