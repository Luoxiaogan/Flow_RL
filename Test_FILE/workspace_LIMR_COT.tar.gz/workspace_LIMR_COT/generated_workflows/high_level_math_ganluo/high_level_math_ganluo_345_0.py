# Workflow ID: high_level_math_ganluo_345_0
# Benchmark: high_level_math_ganluo
# Data Indices: [632, 903]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all numerical values, constraints, and relationships from the problem. "
            "Organize the information into categories such as 'given values', 'unknowns', "
            "'constraints', and 'relationships'. Ensure the output is structured and easy to parse."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        approach_instructions = [
            f"Using the extracted information: {extracted_info}, solve the problem using an algebraic approach. "
            "Focus on equations, inequalities, and functional relationships.",

            f"Using the extracted information: {extracted_info}, solve the problem using a combinatorial approach. "
            "Consider counting principles, permutations, combinations, and recursive structures.",

            f"Using the extracted information: {extracted_info}, solve the problem using a geometric approach. "
            "Leverage coordinate geometry, synthetic geometry, or trigonometric relationships.",

            f"Using the extracted information: {extracted_info}, solve the problem using number theory. "
            "Apply modular arithmetic, divisibility rules, or prime factorization techniques."
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Refine each solution approach
        refine_instruction = (
            "Critically analyze the provided solution. Identify any logical gaps, calculation errors, "
            "or missed constraints. Improve the clarity and correctness of the solution while ensuring "
            "it adheres to the problem's requirements."
        )
        refined_approaches = await asyncio.gather(
            *[self.revise(instruction=refine_instruction, context=approach) for approach in approaches]
        )

        # Step 4: Summarize each refined solution
        summarize_instruction = (
            "Condense the solution into a concise summary. Highlight the key steps, reasoning, "
            "and final answer. Ensure the summary is clear and captures the essence of the solution."
        )
        summaries = await asyncio.gather(
            *[self.summarize(instruction=summarize_instruction, context=approach) for approach in refined_approaches]
        )

        # Step 5: Ensemble decision to select the best solution
        ensemble_instruction = (
            "Compare the provided solutions and select the most robust, elegant, and correct one. "
            "Consider factors such as clarity, adherence to constraints, computational simplicity, "
            "and mathematical rigor. Provide a justification for your choice."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=summaries)

        return final_solution