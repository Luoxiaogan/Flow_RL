# Workflow ID: high_level_math_ganluo_302_0
# Benchmark: high_level_math_ganluo
# Data Indices: [448, 779]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Problem Decomposition
        decomposition_instruction = (
            "Analyze the given problem to identify its mathematical domain (e.g., algebra, geometry, combinatorics), "
            "key constraints, and the type of reasoning required (e.g., casework, symmetry exploitation). "
            "Extract all numerical values, variables, and relationships explicitly stated or implied in the problem."
        )
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Generate Multiple Solution Paths
        algebraic_instruction = (
            f"Based on the problem decomposition: {decomposition}, "
            "develop an algebraic solution strategy. Include steps for equation setup, simplification, "
            "and solving. Ensure all constraints are satisfied."
        )
        geometric_instruction = (
            f"Based on the problem decomposition: {decomposition}, "
            "develop a geometric solution strategy. Include steps for visualization, coordinate transformations, "
            "and calculations of areas, lengths, or angles as needed."
        )
        combinatorial_instruction = (
            f"Based on the problem decomposition: {decomposition}, "
            "develop a combinatorial solution strategy. Include steps for counting arrangements, "
            "using recursive formulas, or applying generating functions if applicable."
        )

        solutions = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Refine Each Solution Path
        refine_instruction_template = (
            "Critically evaluate the following solution strategy: {solution}. "
            "Check for logical consistency, mathematical correctness, and adherence to problem constraints. "
            "Suggest improvements or corrections if necessary."
        )
        refined_solutions = await asyncio.gather(
            self.revise(instruction=refine_instruction_template.format(solution=solutions[0]), context=solutions[0]),
            self.revise(instruction=refine_instruction_template.format(solution=solutions[1]), context=solutions[1]),
            self.revise(instruction=refine_instruction_template.format(solution=solutions[2]), context=solutions[2])
        )

        # Step 4: Synthesize and Decide on the Best Solution
        ensemble_instruction = (
            "Compare the following refined solution strategies and determine the most robust and efficient one. "
            "If multiple strategies are equally valid, synthesize their insights into a unified solution. "
            "Ensure the final solution satisfies all problem constraints and is mathematically rigorous."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_solutions)

        # Step 5: Final Verification and Summarization
        summarize_instruction = (
            "Summarize the final solution in a concise and clear format. "
            "Include the key steps, reasoning, and the final answer. Ensure the summary is self-contained and "
            "understandable without referring back to intermediate steps."
        )
        summary = await self.summarize(instruction=summarize_instruction, context=final_solution)

        return summary