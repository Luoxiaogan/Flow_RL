# Workflow ID: high_level_math_ganluo_13_0
# Benchmark: high_level_math_ganluo
# Data Indices: [557, 606]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Understand the problem and extract key components
        extraction_instruction = (
            "Carefully analyze the problem statement to identify all key components, including variables, "
            "constraints, and the target objective. Organize this information in a structured format."
        )
        problem_components = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        algebraic_instruction = (
            f"Using the extracted problem components: {problem_components}, "
            "solve the problem using algebraic techniques. Provide a step-by-step solution."
        )
        geometric_instruction = (
            f"Using the extracted problem components: {problem_components}, "
            "solve the problem using geometric reasoning. Provide a step-by-step solution."
        )
        combinatorial_instruction = (
            f"Using the extracted problem components: {problem_components}, "
            "solve the problem using combinatorial methods. Provide a step-by-step solution."
        )

        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and select the best solution
        ensemble_instruction = (
            "Compare the provided solutions and select the one that is most accurate, efficient, "
            "and adheres to the problem constraints. Justify your selection."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 4: Refine the selected solution
        refine_instruction = (
            "Critique and improve the selected solution to ensure mathematical rigor, clarity, "
            "and correctness. Address any potential errors or ambiguities."
        )
        refined_solution = await self.revise(instruction=refine_instruction, context=best_solution)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the refined solution into a concise summary that clearly states the final answer "
            "and includes any critical steps or insights."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_summary