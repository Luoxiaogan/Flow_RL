# Workflow ID: high_level_math_ganluo_162_0
# Benchmark: high_level_math_ganluo
# Data Indices: [402, 575]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Problem Understanding and Decomposition
        problem_analysis = await self.generate(
            instruction="Analyze the problem thoroughly. Identify what is being asked, key variables, constraints, and any mathematical structures or patterns. Provide a detailed breakdown.",
            context=self.problem_text
        )

        # Step 2: Parallel Exploration of Solution Paths
        algebraic_solution = self.generate(
            instruction=f"Using algebraic techniques, solve the problem step by step. Ensure all constraints are satisfied. Problem analysis: {problem_analysis}",
            context=self.problem_text
        )
        geometric_solution = self.generate(
            instruction=f"Using geometric reasoning, solve the problem step by step. Ensure all constraints are satisfied. Problem analysis: {problem_analysis}",
            context=self.problem_text
        )
        combinatorial_solution = self.generate(
            instruction=f"Using combinatorial methods, solve the problem step by step. Ensure all constraints are satisfied. Problem analysis: {problem_analysis}",
            context=self.problem_text
        )

        # Execute solution paths in parallel
        solutions = await asyncio.gather(algebraic_solution, geometric_solution, combinatorial_solution)

        # Step 3: Refinement and Verification
        refined_solutions = await asyncio.gather(
            *[self.revise(
                instruction="Critique and refine the solution. Check for correctness, completeness, and adherence to constraints. Suggest improvements if necessary.",
                context=solution
            ) for solution in solutions]
        )

        # Step 4: Ensemble Decision
        final_solution = await self.ensemble(
            instruction="Compare the refined solutions and select the best one. Consider clarity, correctness, efficiency, and adherence to the problem requirements.",
            contexts=refined_solutions
        )

        # Step 5: Summarize Final Answer
        summary = await self.summarize(
            instruction="Condense the final solution into a concise summary. Include the final answer and key reasoning steps.",
            context=final_solution
        )

        return summary