# Workflow ID: high_level_math_ganluo_282_0
# Benchmark: high_level_math_ganluo
# Data Indices: [99, 119]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract Problem Structure and Key Components
        extraction_instruction = (
            "Analyze the problem thoroughly. Identify and list all variables, functions, equations, "
            "constraints, and objectives. Highlight any specific mathematical domains (algebra, geometry, etc.) "
            "that are relevant. Provide a structured summary of the problem's requirements."
        )
        problem_structure = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Explore Multiple Solution Paths in Parallel
        # Approach 1: Algebraic/Analytical Reasoning
        algebraic_instruction = (
            f"Based on the following problem structure:\n{problem_structure}\n"
            "Solve the problem using algebraic or analytical methods. Perform step-by-step reasoning, "
            "including any necessary substitutions, simplifications, or derivations. Ensure all constraints "
            "are satisfied and provide intermediate results where applicable."
        )
        algebraic_solution = self.generate(instruction=algebraic_instruction, context=self.problem_text)

        # Approach 2: Geometric/Visual Reasoning (if applicable)
        geometric_instruction = (
            f"Based on the following problem structure:\n{problem_structure}\n"
            "Attempt to solve the problem using geometric or visual reasoning. Translate the problem into "
            "a geometric representation if possible, and derive the solution using geometric principles. "
            "If geometric reasoning is not applicable, state why and suggest an alternative approach."
        )
        geometric_solution = self.generate(instruction=geometric_instruction, context=self.problem_text)

        # Execute both approaches in parallel
        solutions = await asyncio.gather(algebraic_solution, geometric_solution)

        # Step 3: Evaluate and Select the Best Solution Path
        evaluation_instruction = (
            "Compare the following candidate solutions and select the most rigorous, clear, and correct one. "
            "Provide a justification for your choice. If neither solution is satisfactory, suggest improvements."
        )
        best_solution = await self.ensemble(instruction=evaluation_instruction, contexts=solutions)

        # Step 4: Refine and Verify the Selected Solution
        refinement_instruction = (
            f"Refine the following solution to ensure it is mathematically rigorous and satisfies all "
            "constraints:\n{best_solution}\nCheck for edge cases, verify intermediate steps, and confirm "
            "the final answer is correct. If there are errors, correct them and explain the fixes."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the Final Answer
        summary_instruction = (
            "Condense the following solution into a concise, structured format. Clearly state the final "
            "answer and include key steps or reasoning that led to it."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_summary