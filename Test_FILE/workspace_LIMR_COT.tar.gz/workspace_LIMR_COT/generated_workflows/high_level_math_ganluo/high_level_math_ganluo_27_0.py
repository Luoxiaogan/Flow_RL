# Workflow ID: high_level_math_ganluo_27_0
# Benchmark: high_level_math_ganluo
# Data Indices: [904, 529]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = """
        Extract all key information from the problem, including variables, constants, constraints, and the specific question being asked.
        Format the output as a structured summary, clearly labeling each piece of information.
        """
        key_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Propose multiple solution strategies
        strategy_instruction_template = f"""
        Given the following extracted information: {key_info}
        Propose a detailed solution strategy based on the problem type. Consider the following approaches:
        - Algebraic manipulation (e.g., solving equations, inequalities)
        - Geometric reasoning (e.g., coordinate geometry, synthetic geometry)
        - Combinatorial analysis (e.g., counting principles, recursive formulas)
        - Number theory (e.g., modular arithmetic, divisibility)
        Ensure the strategy is comprehensive and includes step-by-step reasoning.
        """

        # Generate multiple strategies in parallel
        strategies = await asyncio.gather(
            self.generate(instruction=strategy_instruction_template + "Focus on algebraic manipulation."),
            self.generate(instruction=strategy_instruction_template + "Focus on geometric reasoning."),
            self.generate(instruction=strategy_instruction_template + "Focus on combinatorial analysis.")
        )

        # Step 3: Evaluate and select the best strategy
        evaluation_instruction = """
        Compare the following solution strategies and select the best one based on:
        - Correctness and mathematical rigor
        - Simplicity and clarity
        - Adherence to the problem's constraints
        Provide a justification for your selection.
        """
        best_strategy = await self.ensemble(instruction=evaluation_instruction, contexts=strategies)

        # Step 4: Refine the selected strategy
        refinement_instruction = f"""
        Refine the following solution strategy to ensure it satisfies all constraints and is presented in a clear, rigorous format:
        Strategy: {best_strategy}
        Include detailed calculations, verify intermediate steps, and ensure the final answer is boxed or highlighted.
        """
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_strategy)

        # Step 5: Summarize the final solution
        summary_instruction = """
        Summarize the final solution in a concise format, including:
        - The key steps of the solution
        - The final answer
        Ensure the summary is easy to understand and captures all essential details.
        """
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_summary