# Workflow ID: high_level_math_ganluo_270_0
# Benchmark: high_level_math_ganluo
# Data Indices: [81, 877]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract and Understand the Problem
        extraction_instruction = (
            "Thoroughly analyze the problem statement. Identify all given variables, constraints, "
            "and relationships. Determine the mathematical domain (e.g., algebra, number theory, geometry) "
            "and the type of solution required. Highlight any special conditions or edge cases."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate Multiple Solution Approaches
        approach_instructions = [
            f"Based on the extracted information: {extracted_info}, develop an algebraic solution approach. "
            "Include step-by-step reasoning and justify each step.",
            
            f"Based on the extracted information: {extracted_info}, develop a combinatorial or probabilistic "
            "solution approach. Include step-by-step reasoning and justify each step.",

            f"Based on the extracted information: {extracted_info}, develop a geometric or visual solution "
            "approach. Include step-by-step reasoning and justify each step."
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Evaluate and Select the Best Approach
        selection_instruction = (
            "Compare the provided solution approaches. Evaluate them based on clarity, efficiency, alignment "
            "with the problem constraints, and likelihood of correctness. Select the most promising approach."
        )
        best_approach = await self.ensemble(instruction=selection_instruction, contexts=approaches)

        # Step 4: Refine the Selected Approach
        refinement_instruction = (
            f"Refine the selected approach: {best_approach}. Address any potential edge cases, simplify "
            "calculations where possible, and ensure all constraints are satisfied. Provide a polished version "
            "of the solution."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_approach)

        # Step 5: Summarize the Final Answer
        summary_instruction = (
            "Condense the refined solution into a concise and clear format. Ensure the final answer is "
            "explicitly stated and satisfies all problem constraints."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer