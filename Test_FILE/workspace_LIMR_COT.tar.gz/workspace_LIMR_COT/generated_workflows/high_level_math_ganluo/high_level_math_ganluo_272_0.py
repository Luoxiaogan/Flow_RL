# Workflow ID: high_level_math_ganluo_272_0
# Benchmark: high_level_math_ganluo
# Data Indices: [922, 348]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Problem Decomposition
        decomposition_instruction = (
            "Analyze the problem to identify all key components, including variables, equations, "
            "constraints, and relationships. Highlight any mathematical structures, patterns, or "
            "potential solution strategies. Ensure the output is structured and comprehensive."
        )
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Parallel Exploration of Solution Paths
        algebraic_instruction = (
            f"Using the following problem decomposition: {decomposition}\n"
            "Solve the problem using algebraic techniques such as substitution, simplification, "
            "and equation solving. Provide a detailed step-by-step solution."
        )
        geometric_instruction = (
            f"Using the following problem decomposition: {decomposition}\n"
            "Solve the problem using geometric reasoning, focusing on properties of shapes, angles, "
            "and spatial relationships. Provide a detailed step-by-step solution."
        )
        combinatorial_instruction = (
            f"Using the following problem decomposition: {decomposition}\n"
            "Solve the problem using combinatorial methods, such as counting principles, recursion, "
            "or generating functions. Provide a detailed step-by-step solution."
        )

        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Evaluation and Synthesis
        ensemble_instruction = (
            "Compare the following candidate solutions and select the most rigorous, efficient, "
            "and mathematically sound approach. If multiple solutions are valid, synthesize them "
            "into a unified solution. Ensure the final output adheres to the problem's constraints."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 4: Refinement
        refinement_instruction = (
            "Review the following solution for clarity, correctness, and completeness. "
            "Refine the explanation if necessary, ensuring all steps are justified and "
            "the final answer is clearly stated."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Final Answer Extraction
        summary_instruction = (
            "Extract the final answer from the following solution. Ensure the output is concise, "
            "clear, and includes only the numerical or symbolic result."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer