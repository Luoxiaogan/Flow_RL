# Workflow ID: high_level_math_ganluo_219_0
# Benchmark: high_level_math_ganluo
# Data Indices: [656, 363]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key components from the problem
        extraction_instruction = (
            "Thoroughly analyze the problem statement to identify and extract all key components, "
            "including variables, equations, constraints, relationships, and any implicit conditions. "
            "Format the output as a structured summary."
        )
        extracted_components = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution strategies
        strategy_instructions = [
            f"Using the extracted components: {extracted_components}, develop a solution strategy "
            "based on algebraic manipulation and symbolic reasoning.",
            f"Using the extracted components: {extracted_components}, develop a solution strategy "
            "based on geometric interpretation and visualization.",
            f"Using the extracted components: {extracted_components}, develop a solution strategy "
            "based on combinatorial analysis and counting principles."
        ]
        strategies = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in strategy_instructions]
        )

        # Step 3: Evaluate and select the best strategy
        ensemble_instruction = (
            "Compare the provided solution strategies and select the most mathematically sound, "
            "efficient, and promising approach. Provide a justification for your choice."
        )
        best_strategy = await self.ensemble(instruction=ensemble_instruction, contexts=strategies)

        # Step 4: Refine the chosen strategy
        refinement_instruction = (
            f"Refine the following solution strategy: {best_strategy}. Ensure that all steps are "
            "rigorous, logical, and optimized. Address any gaps or ambiguities."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_strategy)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the refined solution into a concise and clear format. Highlight the final "
            "answer prominently, ensuring it satisfies all problem constraints."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer