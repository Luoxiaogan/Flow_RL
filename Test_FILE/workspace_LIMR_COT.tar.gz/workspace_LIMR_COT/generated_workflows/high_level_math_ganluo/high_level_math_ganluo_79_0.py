# Workflow ID: high_level_math_ganluo_79_0
# Benchmark: high_level_math_ganluo
# Data Indices: [202, 193]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract problem details
        extraction_instruction = (
            "Extract all key information from the problem, including variables, constants, "
            "relationships, constraints, and the specific question being asked. Organize this "
            "information clearly for further analysis."
        )
        problem_details = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        approaches = await asyncio.gather(
            self.generate(
                instruction=f"Develop an algebraic approach to solve the problem based on: {problem_details}",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"Develop a geometric approach to solve the problem based on: {problem_details}",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"Develop a combinatorial or number-theoretic approach to solve the problem based on: {problem_details}",
                context=self.problem_text
            )
        )

        # Step 3: Refine and validate each approach
        refined_approaches = await asyncio.gather(
            *[self.revise(
                instruction="Critique and refine this solution approach. Ensure mathematical rigor, address any gaps, "
                            "and validate correctness.",
                context=approach
            ) for approach in approaches]
        )

        # Step 4: Ensemble decision-making
        ensemble_instruction = (
            "Compare the provided solution approaches. Evaluate their mathematical validity, clarity, "
            "and alignment with the problem's requirements. Select the most promising approach or synthesize "
            "a hybrid solution if appropriate."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_approaches)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the solution into a concise, clear format. Highlight the key steps, reasoning, "
            "and final result. Ensure the summary is easy to understand and directly addresses the problem."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=final_solution)

        return final_summary