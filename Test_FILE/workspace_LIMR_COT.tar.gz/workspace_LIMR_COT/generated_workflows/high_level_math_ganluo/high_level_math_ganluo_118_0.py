# Workflow ID: high_level_math_ganluo_118_0
# Benchmark: high_level_math_ganluo
# Data Indices: [476, 181]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Understand the problem and extract key information
        problem_analysis = await self.generate(
            instruction="Analyze the problem thoroughly. Identify all variables, constants, constraints, and relationships. "
                        "Explain the type of problem (e.g., algebra, geometry) and any specific techniques that might apply. "
                        "Provide a structured breakdown of the problem.",
            context=self.problem_text
        )

        # Step 2: Generate multiple solution approaches in parallel
        algebraic_approach = self.generate(
            instruction=f"Using the following analysis: {problem_analysis}, solve the problem using algebraic techniques. "
                        "Include step-by-step reasoning and intermediate results.",
            context=self.problem_text
        )
        geometric_approach = self.generate(
            instruction=f"Using the following analysis: {problem_analysis}, solve the problem using geometric reasoning. "
                        "Include step-by-step reasoning and intermediate results.",
            context=self.problem_text
        )
        combinatorial_approach = self.generate(
            instruction=f"Using the following analysis: {problem_analysis}, solve the problem using combinatorial or probabilistic methods. "
                        "Include step-by-step reasoning and intermediate results.",
            context=self.problem_text
        )

        # Execute approaches in parallel
        approaches = await asyncio.gather(algebraic_approach, geometric_approach, combinatorial_approach)

        # Step 3: Evaluate and select the best approach
        best_approach = await self.ensemble(
            instruction="Compare the following solution approaches and select the most promising one. "
                        "Consider correctness, clarity, and alignment with the problem requirements. "
                        "Provide a justification for your choice.",
            contexts=approaches
        )

        # Step 4: Refine the selected solution
        refined_solution = await self.revise(
            instruction="Review the following solution carefully. Ensure it is correct, clear, and complete. "
                        "Address any gaps in reasoning or calculations. Improve formatting if necessary.",
            context=best_approach
        )

        # Step 5: Summarize the final solution
        final_solution = await self.summarize(
            instruction="Condense the following solution into a concise and well-structured answer. "
                        "Include only the essential steps and the final result.",
            context=refined_solution
        )

        return final_solution