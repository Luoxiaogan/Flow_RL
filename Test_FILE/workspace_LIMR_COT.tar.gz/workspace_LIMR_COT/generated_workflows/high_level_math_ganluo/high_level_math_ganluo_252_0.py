# Workflow ID: high_level_math_ganluo_252_0
# Benchmark: high_level_math_ganluo
# Data Indices: [730, 836]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information and decompose the problem
        extraction_instruction = (
            "Carefully analyze the problem statement and extract all key information, "
            "including numerical values, variables, constraints, and relationships. "
            "Identify the type of problem (e.g., algebraic, geometric, combinatorial) "
            "and list any formulas or theorems that might be relevant."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Explore multiple solution paths in parallel
        algebraic_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "solve the problem using an algebraic approach. Clearly show all steps, "
            "including variable definitions, equation setup, and intermediate calculations."
        )
        geometric_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "solve the problem using a geometric or visual approach. Clearly explain "
            "any diagrams, transformations, or spatial reasoning used."
        )
        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text)
        )
        algebraic_solution, geometric_solution = results

        # Step 3: Refine both solutions
        refine_instruction = (
            "Critically review the provided solution. Check for mathematical accuracy, "
            "logical consistency, and adherence to the problem's constraints. "
            "Refine the solution by addressing any errors or ambiguities, and provide "
            "a clear, step-by-step explanation of the corrected approach."
        )
        refined_algebraic = await self.revise(instruction=refine_instruction, context=algebraic_solution)
        refined_geometric = await self.revise(instruction=refine_instruction, context=geometric_solution)

        # Step 4: Compare and select the best solution
        ensemble_instruction = (
            "Evaluate the two refined solutions. Select the one that is most accurate, "
            "efficient, and aligned with the problem's requirements. If both solutions "
            "are valid, synthesize their insights to produce a unified final answer."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=[refined_algebraic, refined_geometric])

        # Step 5: Extract and format the final answer
        summarize_instruction = (
            "From the provided solution, extract the final answer in the required format. "
            "Ensure the answer is clearly stated and includes any necessary justification."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=final_solution)

        return final_answer