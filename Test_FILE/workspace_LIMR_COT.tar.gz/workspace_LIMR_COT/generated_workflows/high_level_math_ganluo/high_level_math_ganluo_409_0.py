# Workflow ID: high_level_math_ganluo_409_0
# Benchmark: high_level_math_ganluo
# Data Indices: [167, 143]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio
        
        # Step 1: Decompose the problem into key components
        decomposition_instruction = (
            "Analyze the problem thoroughly to identify all key variables, constraints, "
            "and relationships. Organize this information into a structured format that "
            "can guide subsequent reasoning steps."
        )
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)
        
        # Step 2: Generate multiple solution paths in parallel
        algebraic_instruction = (
            f"Using the following decomposition: {decomposition}, "
            "solve the problem using an algebraic approach. Ensure all steps are justified."
        )
        geometric_instruction = (
            f"Using the following decomposition: {decomposition}, "
            "solve the problem using a geometric approach. Ensure all steps are justified."
        )
        combinatorial_instruction = (
            f"Using the following decomposition: {decomposition}, "
            "solve the problem using a combinatorial approach. Ensure all steps are justified."
        )
        
        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )
        
        # Step 3: Refine each solution path
        refine_instructions = [
            "Critique and improve the following solution. Ensure all constraints are satisfied, "
            "and the reasoning is rigorous and complete."
        ] * len(results)
        
        refined_results = await asyncio.gather(
            *[self.revise(instruction=refine_instructions[i], context=results[i]) for i in range(len(results))]
        )
        
        # Step 4: Ensemble decision-making to select the best solution
        ensemble_instruction = (
            "Evaluate the following candidate solutions. Select the most rigorous, efficient, "
            "and mathematically sound approach. Provide a justification for your choice."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_results)
        
        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the following solution into a concise and clear format. Ensure all key "
            "steps and the final answer are included."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=final_solution)
        
        return final_summary