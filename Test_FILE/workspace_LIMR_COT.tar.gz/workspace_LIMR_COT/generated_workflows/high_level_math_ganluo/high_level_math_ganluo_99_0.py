# Workflow ID: high_level_math_ganluo_99_0
# Benchmark: high_level_math_ganluo
# Data Indices: [668, 968]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract critical features from the problem statement
        feature_extraction_instruction = """
        Analyze the problem statement and extract all critical features, such as:
        - Numerical values and their relationships
        - Geometric properties (if applicable)
        - Algebraic expressions or equations
        - Constraints and conditions
        - Any identifiable mathematical structure (e.g., combinatorics, number theory, geometry)
        Organize this information clearly and concisely.
        """
        features = await self.generate(instruction=feature_extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        approach_generation_instruction = f"""
        Based on the extracted features: {features}
        Propose multiple solution approaches for the problem. Consider different mathematical techniques, such as:
        - Algebraic manipulation
        - Geometric reasoning (synthetic or coordinate-based)
        - Combinatorial analysis
        - Number theory tools (e.g., modular arithmetic, prime factorization)
        - Symmetry exploitation or recursive formulas
        For each approach, provide a brief rationale and outline the steps required.
        """
        approaches = await self.generate(instruction=approach_generation_instruction, context=self.problem_text)

        # Step 3: Execute parallel explorations of the proposed approaches
        parallel_instructions = [
            f"Implement the following approach step-by-step: {approach}"
            for approach in approaches.split("\n\n")  # Assuming approaches are separated by double newlines
        ]
        parallel_results = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in parallel_instructions]
        )

        # Step 4: Evaluate and select the best solution
        evaluation_instruction = """
        Compare the provided candidate solutions and select the most appropriate one based on:
        - Correctness and adherence to problem constraints
        - Simplicity and elegance of the solution
        - Computational feasibility
        Provide a rationale for your selection.
        """
        best_solution = await self.ensemble(instruction=evaluation_instruction, contexts=parallel_results)

        # Step 5: Refine the selected solution (if necessary)
        refinement_instruction = """
        Critically review the selected solution and refine it if needed. Ensure that:
        - All constraints and conditions are satisfied
        - The solution is mathematically rigorous
        - Any edge cases or special scenarios are addressed
        """
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 6: Summarize the final solution
        summarization_instruction = """
        Condense the final solution into a concise, verifiable format. Include:
        - The main result or answer
        - Key steps or reasoning highlights
        - Verification against problem constraints
        """
        final_summary = await self.summarize(instruction=summarization_instruction, context=refined_solution)

        return final_summary