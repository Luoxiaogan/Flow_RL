# Workflow ID: high_level_math_ganluo_168_0
# Benchmark: high_level_math_ganluo
# Data Indices: [973, 121]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract problem components
        extraction_instruction = (
            "Extract all key components of the problem, including variables, constants, constraints, "
            "and the objective. Identify the mathematical domain (e.g., algebra, geometry, combinatorics) "
            "and any special techniques required (e.g., symmetry, modular arithmetic)."
        )
        problem_components = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        approach_1_instruction = (
            f"Using the extracted components: {problem_components}, develop a solution approach "
            "based on algebraic manipulation. Include detailed steps and reasoning."
        )
        approach_2_instruction = (
            f"Using the extracted components: {problem_components}, develop a solution approach "
            "based on geometric reasoning or coordinate geometry. Include detailed steps and reasoning."
        )
        approach_3_instruction = (
            f"Using the extracted components: {problem_components}, develop a solution approach "
            "based on number theory or combinatorics. Include detailed steps and reasoning."
        )

        # Execute approaches in parallel
        approaches = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text),
            self.generate(instruction=approach_3_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and select the best approach
        ensemble_instruction = (
            "Compare the following solution approaches and select the most promising one. "
            "Consider mathematical rigor, adherence to constraints, and computational feasibility."
        )
        best_approach = await self.ensemble(instruction=ensemble_instruction, contexts=approaches)

        # Step 4: Refine the chosen solution
        refinement_instruction = (
            f"Refine the following solution: {best_approach}. Ensure it adheres to all constraints, "
            "is mathematically rigorous, and provides a clear path to the final answer."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_approach)

        # Step 5: Summarize the final answer
        summary_instruction = (
            f"Summarize the following solution: {refined_solution}. Provide a concise, well-structured "
            "final answer that satisfies the problem's requirements."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer