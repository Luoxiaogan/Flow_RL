# Workflow ID: high_level_math_ganluo_151_0
# Benchmark: high_level_math_ganluo
# Data Indices: [674, 315]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key components and outline a plan
        extraction_instruction = (
            "Extract all numerical values, variables, constraints, and relationships from the problem. "
            "Identify the question being asked and outline a high-level plan to solve it. "
            "Consider potential mathematical techniques that could be applied."
        )
        problem_outline = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        approach_1_instruction = (
            f"Based on the extracted information: {problem_outline}, "
            "solve the problem using an algebraic approach. "
            "Provide step-by-step reasoning and intermediate results."
        )
        approach_2_instruction = (
            f"Based on the extracted information: {problem_outline}, "
            "solve the problem using a geometric or combinatorial approach. "
            "Provide step-by-step reasoning and intermediate results."
        )
        approach_3_instruction = (
            f"Based on the extracted information: {problem_outline}, "
            "solve the problem using number theory or modular arithmetic. "
            "Provide step-by-step reasoning and intermediate results."
        )

        results = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text),
            self.generate(instruction=approach_3_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and synthesize the best solution
        evaluation_instruction = (
            "Compare the following solution approaches and determine the most efficient and accurate one. "
            "If multiple approaches are valid, synthesize their strengths into a single solution. "
            "Ensure the chosen solution satisfies all problem constraints."
        )
        best_solution = await self.ensemble(instruction=evaluation_instruction, contexts=results)

        # Step 4: Refine the chosen solution
        refinement_instruction = (
            "Critique and refine the following solution to ensure correctness, address edge cases, "
            "and improve clarity. Verify that all steps logically follow and satisfy the problem constraints."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize to extract the final answer
        summary_instruction = (
            "Summarize the refined solution to extract the final answer. "
            "Ensure the answer is concise, boxed, and satisfies all problem constraints."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer