# Workflow ID: high_level_math_ganluo_183_0
# Benchmark: high_level_math_ganluo
# Data Indices: [748, 261]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Problem Decomposition
        decomposition_instruction = (
            "Extract all key information from the problem statement, including variables, constants, "
            "constraints, and relationships. Identify the domain of the problem (e.g., algebra, geometry, "
            "combinatorics) and any specific techniques that might be relevant."
        )
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Strategy Generation
        strategy_instruction_template = (
            "Based on the following problem decomposition:\n{decomposition}\n"
            "Generate a detailed solution strategy for solving the problem using {approach}. "
            "Include step-by-step reasoning and specify any formulas, theorems, or methods required."
        )
        strategies = await asyncio.gather(
            self.generate(
                instruction=strategy_instruction_template.format(decomposition=decomposition, approach="algebraic manipulation"),
                context=self.problem_text
            ),
            self.generate(
                instruction=strategy_instruction_template.format(decomposition=decomposition, approach="geometric reasoning"),
                context=self.problem_text
            ),
            self.generate(
                instruction=strategy_instruction_template.format(decomposition=decomposition, approach="combinatorial analysis"),
                context=self.problem_text
            )
        )

        # Step 3: Solution Execution
        solution_instruction_template = (
            "Execute the following solution strategy step by step:\n{strategy}\n"
            "Ensure all calculations are accurate and provide intermediate results where necessary."
        )
        solutions = await asyncio.gather(
            *[self.generate(instruction=solution_instruction_template.format(strategy=strategy), context=self.problem_text)
              for strategy in strategies]
        )

        # Step 4: Validation and Refinement
        refinement_instruction_template = (
            "Critique and refine the following solution:\n{solution}\n"
            "Check for mathematical correctness, logical consistency, and adherence to problem constraints. "
            "Suggest improvements if necessary."
        )
        refined_solutions = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction_template.format(solution=solution), context=self.problem_text)
              for solution in solutions]
        )

        # Step 5: Final Selection
        ensemble_instruction = (
            "Compare the following candidate solutions and select the best one:\n{solutions}\n"
            "Consider mathematical rigor, clarity of reasoning, and alignment with the problem requirements. "
            "Provide justification for your selection."
        )
        final_solution = await self.ensemble(
            instruction=ensemble_instruction.format(solutions="\n".join(refined_solutions)),
            contexts=refined_solutions
        )

        # Step 6: Output Formatting
        summary_instruction = (
            "Summarize the following solution into a concise and well-structured format:\n{solution}\n"
            "Ensure the final answer is clearly stated and formatted appropriately."
        )
        final_output = await self.summarize(
            instruction=summary_instruction.format(solution=final_solution),
            context=self.problem_text
        )

        return final_output