# Workflow ID: high_level_math_ganluo_364_0
# Benchmark: high_level_math_ganluo
# Data Indices: [926, 484]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Carefully analyze the problem statement and extract all key information, "
            "including variables, constants, relationships, constraints, and what is being asked. "
            "Format the output as a structured list or summary."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        algebra_instruction = (
            f"Based on the extracted information: {extracted_info}, "
            "solve the problem using algebraic techniques. Include detailed steps, transformations, "
            "and reasoning. Ensure all constraints are satisfied."
        )
        geometry_instruction = (
            f"Based on the extracted information: {extracted_info}, "
            "solve the problem using geometric reasoning. Include diagrams (if applicable), "
            "relationships between elements, and step-by-step calculations."
        )
        combinatorics_instruction = (
            f"Based on the extracted information: {extracted_info}, "
            "solve the problem using combinatorial or probabilistic methods. "
            "Include counting principles, recursive formulas, or generating functions if needed."
        )

        # Parallel execution of different approaches
        results = await asyncio.gather(
            self.generate(instruction=algebra_instruction, context=self.problem_text),
            self.generate(instruction=geometry_instruction, context=self.problem_text),
            self.generate(instruction=combinatorics_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and select the best approach
        ensemble_instruction = (
            "Compare the following candidate solutions and select the most appropriate one. "
            "Consider clarity, correctness, alignment with the problem constraints, and computational efficiency. "
            "Provide a brief justification for your choice."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 4: Refine the selected solution
        refine_instruction = (
            "Critique and refine the following solution. Address any gaps, simplify expressions, "
            "verify correctness, and ensure all constraints are satisfied. Format the output clearly."
        )
        refined_solution = await self.revise(instruction=refine_instruction, context=best_solution)

        # Step 5: Summarize the final solution
        summarize_instruction = (
            "Summarize the final solution in a concise and structured format. "
            "Include the key steps, the final answer, and any important remarks."
        )
        final_summary = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_summary