# Workflow ID: high_level_math_ganluo_116_0
# Benchmark: high_level_math_ganluo
# Data Indices: [578, 253]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = """
        Analyze the problem statement and extract all essential information, including:
        - Numerical values and their relationships
        - Constraints and conditions
        - Any implicit or explicit requirements
        Present the extracted information in a structured format.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate an initial solution
        initial_solution_instruction = f"""
        Based on the following extracted information:
        {extracted_info}
        Propose an initial solution to the problem using appropriate mathematical techniques. Consider:
        - Algebraic manipulation
        - Geometric reasoning
        - Combinatorial analysis
        - Number theory principles
        Ensure the solution is detailed and addresses all constraints.
        """
        initial_solution = await self.generate(instruction=initial_solution_instruction, context=self.problem_text)

        # Step 3: Refine and validate the initial solution
        refinement_instruction = """
        Critique the provided solution and refine it to ensure correctness and clarity. Check for:
        - Adherence to all constraints
        - Mathematical rigor
        - Logical consistency
        - Boundary conditions and edge cases
        Provide a revised version of the solution if necessary.
        """
        refined_solution = await self.revise(instruction=refinement_instruction, context=initial_solution)

        # Step 4: Explore alternative approaches in parallel
        approach_1_instruction = """
        Solve the problem using an algebraic approach. Focus on:
        - Polynomial equations
        - Functional equations
        - Sequences and series
        """
        approach_2_instruction = """
        Solve the problem using a geometric approach. Focus on:
        - Coordinate geometry
        - Synthetic geometry
        - Area/volume calculations
        """
        approach_3_instruction = """
        Solve the problem using a combinatorial approach. Focus on:
        - Counting arrangements
        - Recursive structures
        - Generating functions
        """
        results = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text),
            self.generate(instruction=approach_3_instruction, context=self.problem_text)
        )

        # Step 5: Ensemble decision-making
        ensemble_instruction = """
        Compare the following candidate solutions and select the best one based on:
        - Clarity and simplicity
        - Correctness and completeness
        - Computational feasibility
        Provide a justification for your choice.
        """
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 6: Summarize the final solution
        summary_instruction = """
        Condense the final solution into a concise and well-structured format. Ensure:
        - All key steps are included
        - The solution is easy to understand
        - The answer satisfies all constraints
        """
        summarized_solution = await self.summarize(instruction=summary_instruction, context=final_solution)

        return summarized_solution