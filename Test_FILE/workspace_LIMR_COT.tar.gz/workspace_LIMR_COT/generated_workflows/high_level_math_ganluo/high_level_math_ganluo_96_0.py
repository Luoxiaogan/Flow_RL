# Workflow ID: high_level_math_ganluo_96_0
# Benchmark: high_level_math_ganluo
# Data Indices: [820, 859]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Initial Analysis and Problem Decomposition
        initial_analysis = await self.generate(
            instruction="Analyze the problem thoroughly. Identify all variables, constraints, and relationships. "
                        "Determine the mathematical domain (e.g., algebra, geometry, combinatorics) and any special techniques required.",
            context=self.problem_text
        )

        # Step 2: Parallel Exploration of Multiple Solution Paths
        algebraic_approach = self.generate(
            instruction=f"Using algebraic methods, solve the problem step by step. Ensure all constraints are satisfied. "
                        f"Reference the following analysis: {initial_analysis}",
            context=self.problem_text
        )
        geometric_approach = self.generate(
            instruction=f"Using geometric reasoning, solve the problem step by step. Ensure all constraints are satisfied. "
                        f"Reference the following analysis: {initial_analysis}",
            context=self.problem_text
        )
        number_theory_approach = self.generate(
            instruction=f"Using number-theoretic techniques, solve the problem step by step. Ensure all constraints are satisfied. "
                        f"Reference the following analysis: {initial_analysis}",
            context=self.problem_text
        )

        approaches = await asyncio.gather(algebraic_approach, geometric_approach, number_theory_approach)

        # Step 3: Refinement and Validation
        refined_approaches = []
        for approach in approaches:
            refined = await self.revise(
                instruction="Critique and refine this solution. Ensure it is mathematically rigorous, satisfies all constraints, "
                            "and is free of errors. Highlight any assumptions or edge cases.",
                context=approach
            )
            refined_approaches.append(refined)

        # Step 4: Synthesis and Final Decision
        final_solution = await self.ensemble(
            instruction="Compare the refined solutions and select the best one. Consider correctness, elegance, efficiency, "
                        "and adherence to the problem constraints. If there are discrepancies, resolve them.",
            contexts=refined_approaches
        )

        # Step 5: Summarization (Optional)
        summarized_solution = await self.summarize(
            instruction="Condense the final solution into a concise and clear format. Ensure all key steps and results are preserved.",
            context=final_solution
        )

        return summarized_solution