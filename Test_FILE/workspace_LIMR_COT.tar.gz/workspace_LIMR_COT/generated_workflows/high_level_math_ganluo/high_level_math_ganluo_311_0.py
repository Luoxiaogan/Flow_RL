# Workflow ID: high_level_math_ganluo_311_0
# Benchmark: high_level_math_ganluo
# Data Indices: [447, 621]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information and understand the problem
        extraction_instruction = (
            "Extract all numerical values, constraints, and the mathematical domain "
            "(e.g., combinatorics, number theory, algebra) from the problem. "
            "Identify what the question is asking for and any special conditions."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Decompose the problem into sub-problems
        decomposition_instruction = (
            f"Based on the extracted information: {extracted_info}, "
            "decompose the problem into smaller, solvable sub-problems. "
            "Provide a structured plan for solving each sub-problem."
        )
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 3: Generate multiple solution paths in parallel
        solution_instruction_template = (
            "Solve the following sub-problem using {approach}. "
            "Ensure all constraints are satisfied and provide a clear, step-by-step solution."
        )
        approaches = ["an algebraic approach", "a combinatorial approach", "a geometric approach"]
        solution_tasks = [
            self.generate(instruction=solution_instruction_template.format(approach=approach), context=decomposition)
            for approach in approaches
        ]
        raw_solutions = await asyncio.gather(*solution_tasks)

        # Step 4: Refine and critique each solution
        refinement_instruction = (
            "Critique and refine the following solution. "
            "Check for correctness, adherence to constraints, and consideration of edge cases. "
            "Improve clarity and mathematical rigor where needed."
        )
        refinement_tasks = [
            self.revise(instruction=refinement_instruction, context=solution)
            for solution in raw_solutions
        ]
        refined_solutions = await asyncio.gather(*refinement_tasks)

        # Step 5: Ensemble decision-making to select the best solution
        ensemble_instruction = (
            "Compare the following solutions and select the best one. "
            "If multiple solutions are valid, synthesize them into a single, optimal answer. "
            "Ensure the final solution satisfies all problem constraints."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_solutions)

        # Step 6: Summarize the final solution in the required format
        summary_instruction = (
            "Summarize the final solution in the required format (e.g., common fraction, largest integer). "
            "Ensure the answer is concise and clearly addresses the problem."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=final_solution)

        return final_answer