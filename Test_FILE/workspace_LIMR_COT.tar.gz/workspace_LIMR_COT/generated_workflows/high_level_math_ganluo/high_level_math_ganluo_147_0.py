# Workflow ID: high_level_math_ganluo_147_0
# Benchmark: high_level_math_ganluo
# Data Indices: [370, 811]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information and decompose the problem
        extraction_instruction = (
            "Analyze the problem statement carefully. Identify all variables, constants, constraints, and the goal. "
            "Break the problem into smaller sub-problems or steps if possible. Provide a structured summary."
        )
        decomposition = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        approach_instructions = [
            f"Using algebraic manipulation, solve the problem step by step. Problem details: {decomposition}",
            f"Using geometric reasoning, analyze and solve the problem. Problem details: {decomposition}",
            f"Using combinatorial or probabilistic methods, derive a solution. Problem details: {decomposition}",
            f"Using number theory techniques, solve the problem. Problem details: {decomposition}"
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Refine and validate each approach
        refinement_instruction = (
            "Critique and refine the solution approach. Ensure all constraints are satisfied, edge cases are considered, "
            "and the reasoning is mathematically rigorous. Correct any errors or gaps in the solution."
        )
        refined_approaches = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction, context=approach) for approach in approaches]
        )

        # Step 4: Ensemble decision to select or synthesize the best solution
        ensemble_instruction = (
            "Compare the provided solutions. Evaluate their correctness, completeness, and mathematical elegance. "
            "Select the best solution or synthesize insights from multiple solutions if necessary."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_approaches)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the solution into a concise, structured format. Include the final answer and a brief explanation "
            "of the reasoning process."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=final_solution)

        return final_answer