# Workflow ID: high_level_math_ganluo_441_0
# Benchmark: high_level_math_ganluo
# Data Indices: [702, 521]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information and decompose the problem
        decomposition_instruction = (
            "Analyze the problem thoroughly. Identify all numerical values, variables, "
            "constraints, and relationships. Break the problem into smaller, manageable steps."
        )
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Generate multiple candidate solutions in parallel
        algebraic_instruction = (
            f"Using the decomposition: {decomposition}, solve the problem algebraically. "
            "Focus on equations, inequalities, and functional relationships."
        )
        geometric_instruction = (
            f"Using the decomposition: {decomposition}, solve the problem geometrically. "
            "Consider coordinate geometry, synthetic geometry, and trigonometric relationships."
        )
        combinatorial_instruction = (
            f"Using the decomposition: {decomposition}, solve the problem combinatorially. "
            "Count arrangements, use recursion, or apply probabilistic methods."
        )

        candidate_solutions = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Refine each candidate solution
        refinement_instruction_template = (
            "Critique and refine the following solution. Ensure it is mathematically rigorous, "
            "satisfies all constraints, and accounts for edge cases. Improve clarity and precision."
        )
        refined_solutions = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction_template, context=solution) 
              for solution in candidate_solutions]
        )

        # Step 4: Select the best solution using Ensemble
        selection_instruction = (
            "Evaluate the following solutions. Select the most elegant, efficient, and correct one. "
            "Consider simplicity, adherence to constraints, and mathematical rigor."
        )
        best_solution = await self.ensemble(instruction=selection_instruction, contexts=refined_solutions)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the following solution into a concise and clear final answer. "
            "Include only the essential steps and the final result."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=best_solution)

        return final_answer