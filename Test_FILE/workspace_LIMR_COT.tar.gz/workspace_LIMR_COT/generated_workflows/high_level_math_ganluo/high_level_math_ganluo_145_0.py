# Workflow ID: high_level_math_ganluo_145_0
# Benchmark: high_level_math_ganluo
# Data Indices: [452, 267]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extract_instruction = (
            "Carefully analyze the problem statement and extract all key information, "
            "including numerical values, relationships, constraints, and the specific question being asked. "
            "Format the extracted information clearly and categorize it by type (e.g., given data, goal)."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Explore multiple solution paths in parallel
        algebraic_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Solve the problem using algebraic methods. Include all steps and justify each transformation."
        )
        geometric_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Solve the problem using geometric reasoning. Include diagrams if necessary and explain all steps."
        )
        combinatorial_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Solve the problem using combinatorial or probabilistic methods. Enumerate cases if needed."
        )

        # Parallel execution of different solution approaches
        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and synthesize the best solution
        ensemble_instruction = (
            "Compare the provided solutions and select the most accurate, complete, and mathematically rigorous one. "
            "If multiple solutions are equally valid, choose the one with the clearest explanation."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 4: Refine the chosen solution if necessary
        refine_instruction = (
            "Review the solution for correctness, clarity, and completeness. "
            "Ensure all constraints are satisfied and the final answer is boxed."
        )
        refined_solution = await self.revise(instruction=refine_instruction, context=best_solution)

        # Step 5: Summarize the final solution
        summarize_instruction = (
            "Condense the solution into a concise and well-structured format. "
            "Include only the essential steps and the final answer."
        )
        final_output = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_output