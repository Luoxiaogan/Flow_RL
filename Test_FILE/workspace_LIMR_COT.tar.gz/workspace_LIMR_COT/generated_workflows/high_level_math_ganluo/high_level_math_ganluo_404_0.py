# Workflow ID: high_level_math_ganluo_404_0
# Benchmark: high_level_math_ganluo
# Data Indices: [134, 896]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Problem Decomposition
        decomposition_instruction = (
            "Extract all critical components of the problem, including variables, equations, "
            "constraints, and any hidden structures. Identify potential solution strategies "
            "and outline the reasoning steps required to solve the problem."
        )
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Parallel Exploration of Solution Paths
        algebraic_instruction = (
            f"Using the extracted information: {decomposition}, solve the problem using algebraic methods. "
            "Include step-by-step reasoning and verify intermediate results against the problem's constraints."
        )
        geometric_instruction = (
            f"Using the extracted information: {decomposition}, solve the problem using geometric reasoning. "
            "Include step-by-step reasoning and verify intermediate results against the problem's constraints."
        )
        combinatorial_instruction = (
            f"Using the extracted information: {decomposition}, solve the problem using combinatorial analysis. "
            "Include step-by-step reasoning and verify intermediate results against the problem's constraints."
        )

        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Refinement and Validation
        refinement_instruction = (
            "Critique and refine the provided solution. Ensure it adheres to the problem's constraints, "
            "is mathematically rigorous, and includes all necessary steps. Highlight any errors or gaps."
        )
        refined_results = await asyncio.gather(
            self.revise(instruction=refinement_instruction, context=results[0]),
            self.revise(instruction=refinement_instruction, context=results[1]),
            self.revise(instruction=refinement_instruction, context=results[2])
        )

        # Step 4: Ensemble Decision-Making
        ensemble_instruction = (
            "Evaluate the provided solutions and select the best one based on mathematical correctness, "
            "clarity, and adherence to the problem's constraints. If possible, synthesize insights from multiple solutions."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_results)

        # Step 5: Final Answer Extraction
        summarization_instruction = (
            "Condense the final solution into a concise answer format. Include only the essential steps "
            "and the final result. Ensure the answer satisfies all problem constraints."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=final_solution)

        return final_answer