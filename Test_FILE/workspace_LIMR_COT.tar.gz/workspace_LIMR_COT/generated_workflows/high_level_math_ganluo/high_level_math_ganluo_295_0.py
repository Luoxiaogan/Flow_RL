# Workflow ID: high_level_math_ganluo_295_0
# Benchmark: high_level_math_ganluo
# Data Indices: [987, 970]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key components from the problem
        extraction = await self.generate(
            instruction="Extract all key components from the problem, including variables, equations, constraints, and objectives. Organize them into categories such as numerical values, algebraic expressions, geometric properties, etc.",
            context=self.problem_text
        )

        # Step 2: Generate multiple solution paths in parallel
        algebraic_solution = self.generate(
            instruction=f"Using the extracted components: {extraction}\n Solve the problem using algebraic techniques such as equation manipulation, substitution, and simplification. Ensure all steps are justified mathematically.",
            context=self.problem_text
        )
        geometric_solution = self.generate(
            instruction=f"Using the extracted components: {extraction}\n Solve the problem using geometric reasoning. Consider coordinate geometry, synthetic geometry, trigonometric relationships, and area/volume calculations.",
            context=self.problem_text
        )
        combinatorial_solution = self.generate(
            instruction=f"Using the extracted components: {extraction}\n Solve the problem using combinatorial or probabilistic methods. Consider counting principles, recursive formulas, generating functions, and expected value calculations.",
            context=self.problem_text
        )
        number_theory_solution = self.generate(
            instruction=f"Using the extracted components: {extraction}\n Solve the problem using number theory techniques such as modular arithmetic, divisibility rules, prime factorization, and Diophantine equations.",
            context=self.problem_text
        )

        # Execute solution paths in parallel
        solutions = await asyncio.gather(algebraic_solution, geometric_solution, combinatorial_solution, number_theory_solution)

        # Step 3: Evaluate and synthesize the best solution
        best_solution = await self.ensemble(
            instruction="Evaluate the provided candidate solutions based on correctness, completeness, and adherence to the problem constraints. Select the most robust and elegant solution, or synthesize a new one if necessary.",
            contexts=solutions
        )

        # Step 4: Refine the selected solution
        refined_solution = await self.revise(
            instruction="Review the selected solution for clarity, correctness, and compliance with the problem requirements. Improve any ambiguous or incomplete steps, and ensure the final answer satisfies all constraints.",
            context=best_solution
        )

        # Step 5: Summarize the final result
        final_summary = await self.summarize(
            instruction="Condense the refined solution into a concise and structured format. Include the final answer and key reasoning steps.",
            context=refined_solution
        )

        return final_summary