# Workflow ID: high_level_math_ganluo_98_0
# Benchmark: high_level_math_ganluo
# Data Indices: [310, 817]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Analyze the problem and extract key information
        analysis_instruction = (
            "Analyze the problem thoroughly. Identify the mathematical domain (e.g., geometry, algebra), "
            "extract all numerical values, constraints, and relationships, and determine the required techniques. "
            "Provide a structured breakdown of the problem."
        )
        analysis = await self.generate(instruction=analysis_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution paths in parallel
        algebraic_instruction = (
            f"Based on the analysis: {analysis}\n"
            "Solve the problem using an algebraic approach. Include all steps, intermediate results, "
            "and reasoning. Ensure the solution satisfies all constraints."
        )
        geometric_instruction = (
            f"Based on the analysis: {analysis}\n"
            "Solve the problem using a geometric approach. Include all steps, intermediate results, "
            "and reasoning. Ensure the solution satisfies all constraints."
        )
        combinatorial_instruction = (
            f"Based on the analysis: {analysis}\n"
            "Solve the problem using a combinatorial or probabilistic approach. Include all steps, "
            "intermediate results, and reasoning. Ensure the solution satisfies all constraints."
        )

        solutions = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and select the best solution
        ensemble_instruction = (
            "Evaluate the following candidate solutions. Select the one that is most correct, "
            "efficient, and adheres to all constraints. Provide justification for your choice."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=solutions)

        # Step 4: Verify and refine the selected solution
        revise_instruction = (
            "Critique and refine the following solution. Check for correctness, completeness, "
            "and adherence to all constraints. Improve clarity and rigor where necessary."
        )
        refined_solution = await self.revise(instruction=revise_instruction, context=best_solution)

        # Step 5: Summarize the final solution
        summarize_instruction = (
            "Condense the following solution into a concise and clear format. Highlight the key steps, "
            "results, and reasoning. Ensure the summary is easy to understand."
        )
        final_summary = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_summary