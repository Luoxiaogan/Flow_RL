# Workflow ID: high_level_math_ganluo_226_0
# Benchmark: high_level_math_ganluo
# Data Indices: [552, 540]

```python
class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Problem Understanding and Decomposition
        understanding_instruction = (
            "Carefully analyze the problem statement. Identify the key components, constraints, "
            "and what is being asked. Provide a structured breakdown of the problem."
        )
        problem_understanding = await self.generate(instruction=understanding_instruction, context=self.problem_text)

        # Step 2: Strategy Formulation
        strategy_instruction_template = (
            "Based on the problem breakdown: {problem_breakdown}\n"
            "Propose a detailed strategy to solve the problem. Consider different approaches such as "
            "algebraic manipulation, combinatorial reasoning, geometric analysis, or number theory techniques. "
            "Provide step-by-step reasoning for your approach."
        )

        # Generate multiple strategies in parallel
        strategies = await asyncio.gather(
            self.generate(instruction=strategy_instruction_template.format(problem_breakdown=problem_understanding), context=self.problem_text),
            self.generate(instruction=strategy_instruction_template.format(problem_breakdown=problem_understanding), context=self.problem_text),
            self.generate(instruction=strategy_instruction_template.format(problem_breakdown=problem_understanding), context=self.problem_text)
        )

        # Step 3: Execution of Strategies
        execution_instruction_template = (
            "Execute the following strategy step by step: {strategy}\n"
            "Perform all necessary calculations, transformations, or derivations. Ensure that each step "
            "is clearly explained and logically sound."
        )

        # Execute each strategy and refine the results
        refined_results = []
        for strategy in strategies:
            execution_result = await self.generate(instruction=execution_instruction_template.format(strategy=strategy), context=self.problem_text)
            refined_result = await self.revise(instruction="Review and refine the following solution. Check for accuracy, completeness, and clarity.", context=execution_result)
            refined_results.append(refined_result)

        # Step 4: Solution Synthesis
        synthesis_instruction = (
            "Evaluate the following candidate solutions: {solutions}\n"
            "Compare their accuracy, clarity, and adherence to the problem constraints. Select the best solution "
            "and provide a justification for your choice."
        )
        final_solution = await self.ensemble(instruction=synthesis_instruction.format(solutions="\n".join(refined_results)), contexts=refined_results)

        # Step 5: Final Verification
        verification_instruction = (
            "Verify the following solution against the original problem statement: {solution}\n"
            "Ensure that it satisfies all constraints and requirements. Provide a concise summary of the solution."
        )
        verified_solution = await self.summarize(instruction=verification_instruction.format(solution=final_solution), context=final_solution)

        return verified_solution
```