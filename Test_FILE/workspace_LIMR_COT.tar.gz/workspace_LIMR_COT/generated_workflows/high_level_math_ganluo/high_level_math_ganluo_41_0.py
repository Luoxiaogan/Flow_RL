# Workflow ID: high_level_math_ganluo_41_0
# Benchmark: high_level_math_ganluo
# Data Indices: [248, 266]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract and decompose the problem
        decomposition_instruction = (
            "Carefully analyze the problem statement to identify all key components, "
            "including numerical values, constraints, relationships, and the specific question being asked. "
            "Categorize the problem into one or more mathematical domains (e.g., algebra, geometry, number theory). "
            "Provide a structured summary of the problem's requirements."
        )
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        solution_instruction_template = (
            "Based on the problem decomposition, solve the problem using the following strategy: {strategy}. "
            "Ensure your solution is mathematically rigorous and satisfies all constraints. "
            "Clearly explain your reasoning and calculations."
        )
        strategies = [
            "algebraic manipulation and equation solving",
            "geometric reasoning and visualization",
            "combinatorial analysis and counting techniques",
            "number theory principles such as modular arithmetic or divisibility"
        ]
        solution_tasks = [
            self.generate(instruction=solution_instruction_template.format(strategy=strategy), context=decomposition)
            for strategy in strategies
        ]
        candidate_solutions = await asyncio.gather(*solution_tasks)

        # Step 3: Refine each candidate solution
        refinement_instruction_template = (
            "Critically evaluate the provided solution. Check for logical consistency, mathematical correctness, "
            "and adherence to all problem constraints. Identify and address any edge cases or hidden assumptions. "
            "Refine the solution to ensure it is complete and robust."
        )
        refinement_tasks = [
            self.revise(instruction=refinement_instruction_template, context=solution)
            for solution in candidate_solutions
        ]
        refined_solutions = await asyncio.gather(*refinement_tasks)

        # Step 4: Compare and select the best solution
        ensemble_instruction = (
            "Compare the provided solutions to determine which one is the most correct, elegant, and robust. "
            "Consider mathematical rigor, clarity of reasoning, and alignment with the problem's requirements. "
            "If possible, synthesize insights from multiple solutions to produce an improved final answer."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_solutions)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the final solution into a concise, well-structured format. "
            "Ensure the summary clearly addresses the problem's requirements and provides the final answer."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=final_solution)

        return final_summary