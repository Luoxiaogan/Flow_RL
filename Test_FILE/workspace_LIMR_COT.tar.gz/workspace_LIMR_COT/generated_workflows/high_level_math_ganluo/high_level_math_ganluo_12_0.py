# Workflow ID: high_level_math_ganluo_12_0
# Benchmark: high_level_math_ganluo
# Data Indices: [115, 256]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Problem Understanding & Decomposition
        decomposition = await self.generate(
            instruction="Extract all key components of the problem, including variables, equations, constraints, and the specific question being asked. Identify the mathematical domain (e.g., algebra, geometry, combinatorics).",
            context=self.problem_text
        )

        # Step 2: Solution Exploration (Parallel Execution)
        algebraic_solution = self.generate(
            instruction=f"Using algebraic methods, solve the problem step by step. Consider all constraints and ensure the solution is mathematically rigorous. Key components: {decomposition}",
            context=self.problem_text
        )
        geometric_solution = self.generate(
            instruction=f"Using geometric reasoning, interpret and solve the problem. Consider all constraints and ensure the solution is mathematically rigorous. Key components: {decomposition}",
            context=self.problem_text
        )
        combinatorial_solution = self.generate(
            instruction=f"Using combinatorial or recursive reasoning, solve the problem step by step. Consider all constraints and ensure the solution is mathematically rigorous. Key components: {decomposition}",
            context=self.problem_text
        )

        # Execute all solution paths in parallel
        solutions = await asyncio.gather(algebraic_solution, geometric_solution, combinatorial_solution)

        # Step 3: Refinement & Validation
        refined_solutions = []
        for solution in solutions:
            refined = await self.revise(
                instruction="Critique and refine this solution. Check for logical consistency, verify all constraints are satisfied, and simplify expressions where possible.",
                context=solution
            )
            refined_solutions.append(refined)

        # Step 4: Final Synthesis
        final_solution = await self.ensemble(
            instruction="Evaluate and synthesize the following candidate solutions. Select the most robust, mathematically sound approach that satisfies all problem requirements.",
            contexts=refined_solutions
        )

        # Step 5: Summary & Output
        summary = await self.summarize(
            instruction="Condense the final solution into a concise, well-structured format suitable for submission. Include all necessary details and ensure clarity.",
            context=final_solution
        )

        return summary