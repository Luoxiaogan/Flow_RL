# Workflow ID: high_level_math_ganluo_258_0
# Benchmark: high_level_math_ganluo
# Data Indices: [577, 210]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key components of the problem
        extraction_instruction = (
            "Identify and extract all numerical values, variables, constraints, "
            "and relationships from the problem. Categorize them into groups such as "
            "'given values', 'unknowns', 'constraints', and 'relationships'. Ensure "
            "that the extraction is complete and includes any implicit assumptions."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        approach_1_instruction = (
            f"Given the extracted information: {extracted_info}, solve the problem "
            "using an algebraic or computational approach. Perform step-by-step reasoning, "
            "clearly showing all calculations and transformations. Ensure that the solution "
            "adheres to all constraints and conditions specified in the problem."
        )
        approach_2_instruction = (
            f"Given the extracted information: {extracted_info}, solve the problem "
            "using a geometric or combinatorial approach. Explore patterns, symmetries, "
            "or recursive structures if applicable. Clearly justify each step and ensure "
            "that the solution satisfies all problem requirements."
        )

        # Execute both approaches in parallel
        results = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and synthesize the best solution
        ensemble_instruction = (
            "Compare the following candidate solutions and select the most correct, "
            "efficient, and well-justified one. If there are discrepancies, attempt "
            "to merge or reconcile them. Provide a rationale for your choice."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 4: Refine the chosen solution if necessary
        refinement_instruction = (
            "Review the provided solution for clarity, correctness, and completeness. "
            "Address any ambiguities, gaps, or errors. Ensure that the solution is "
            "presented in a logical and rigorous manner."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the solution into a concise and well-structured format. Include "
            "all key steps, results, and justifications. Ensure that the summary is "
            "clear, precise, and directly addresses the problem statement."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_summary