# Workflow ID: high_level_math_ganluo_377_0
# Benchmark: high_level_math_ganluo
# Data Indices: [260, 572]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Problem Decomposition
        decomposition_instruction = (
            "Analyze the problem statement to identify its core components, including "
            "numerical values, constraints, and the specific question being asked. "
            "Classify the problem into one or more mathematical domains (e.g., algebra, geometry, combinatorics). "
            "Suggest potential solution strategies based on the identified structure."
        )
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Parallel Exploration of Solution Paths
        algebraic_instruction = (
            f"Using the problem decomposition: {decomposition}, "
            "solve the problem using algebraic methods. Include all steps, transformations, and reasoning. "
            "Ensure that the solution satisfies all constraints."
        )
        geometric_instruction = (
            f"Using the problem decomposition: {decomposition}, "
            "solve the problem using geometric methods. Include all steps, diagrams (if applicable), and reasoning. "
            "Ensure that the solution satisfies all constraints."
        )
        combinatorial_instruction = (
            f"Using the problem decomposition: {decomposition}, "
            "solve the problem using combinatorial or probabilistic methods. Include all steps, calculations, and reasoning. "
            "Ensure that the solution satisfies all constraints."
        )

        algebraic_solution, geometric_solution, combinatorial_solution = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Evaluation and Synthesis
        ensemble_instruction = (
            "Compare the following solution approaches and select the most robust, efficient, and correct solution. "
            "Ensure that the chosen solution satisfies all constraints and provides a complete answer. "
            "If multiple solutions are valid, synthesize them into a single coherent solution."
        )
        best_solution = await self.ensemble(
            instruction=ensemble_instruction,
            contexts=[algebraic_solution, geometric_solution, combinatorial_solution]
        )

        # Step 4: Refinement and Verification
        refinement_instruction = (
            "Critique the following solution for correctness, completeness, and clarity. "
            "Identify and address any gaps, errors, or ambiguities. Refine the solution to ensure it is mathematically rigorous."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarization
        summarization_instruction = (
            "Condense the following solution into a concise, well-structured format suitable for submission. "
            "Include only the essential steps and the final answer."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_solution)

        return final_answer