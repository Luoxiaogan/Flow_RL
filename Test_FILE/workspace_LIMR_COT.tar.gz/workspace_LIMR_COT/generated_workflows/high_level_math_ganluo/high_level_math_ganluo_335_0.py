# Workflow ID: high_level_math_ganluo_335_0
# Benchmark: high_level_math_ganluo
# Data Indices: [791, 117]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all numerical values, variables, relationships, and constraints from the problem. "
            "Organize this information in a structured format, such as bullet points or a table. "
            "Ensure no detail is omitted."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution strategies
        strategy_instruction_template = (
            "Based on the following extracted information:\n{info}\n"
            "Propose a detailed solution strategy for solving the problem. "
            "Consider different mathematical techniques (e.g., algebraic manipulation, geometric reasoning, combinatorial analysis). "
            "Provide step-by-step reasoning and justify why this approach is valid."
        )
        strategy_instructions = [
            strategy_instruction_template.format(info=extracted_info),
            strategy_instruction_template.format(info=extracted_info) + " Focus on algebraic techniques.",
            strategy_instruction_template.format(info=extracted_info) + " Focus on geometric techniques."
        ]
        strategies = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in strategy_instructions]
        )

        # Step 3: Evaluate and synthesize the best strategy
        ensemble_instruction = (
            "You are provided with multiple solution strategies:\n{strategies}\n"
            "Evaluate each strategy based on clarity, efficiency, and mathematical rigor. "
            "Select the best strategy and provide a justification for your choice."
        )
        best_strategy = await self.ensemble(
            instruction=ensemble_instruction.format(strategies="\n".join(strategies)),
            contexts=strategies
        )

        # Step 4: Execute the chosen strategy step-by-step
        execution_instruction = (
            "Using the following strategy:\n{strategy}\n"
            "Solve the problem step-by-step. Perform all necessary calculations, transformations, and derivations. "
            "Ensure the solution is complete and satisfies all problem constraints."
        )
        solution = await self.generate(
            instruction=execution_instruction.format(strategy=best_strategy),
            context=self.problem_text
        )

        # Step 5: Verify and refine the solution
        verification_instruction = (
            "Verify the following solution:\n{solution}\n"
            "Check if it satisfies all constraints and conditions in the original problem. "
            "If there are any errors or ambiguities, refine the solution accordingly."
        )
        refined_solution = await self.revise(
            instruction=verification_instruction.format(solution=solution),
            context=self.problem_text
        )

        # Return the final refined solution
        return refined_solution