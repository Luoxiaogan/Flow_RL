# Workflow ID: high_level_math_ganluo_160_0
# Benchmark: high_level_math_ganluo
# Data Indices: [182, 190]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract problem components and identify domains
        extraction_instruction = (
            "Extract all key components of the problem, including variables, constraints, "
            "equations, inequalities, and any special conditions. Identify the mathematical "
            "domains involved (e.g., algebra, geometry, combinatorics)."
        )
        problem_components = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate candidate approaches
        approach_instruction_template = (
            f"Based on the extracted problem components: {problem_components}, "
            "propose a solution strategy. Consider multiple mathematical domains and techniques. "
            "Provide a detailed plan for solving the problem step by step."
        )
        approaches = await asyncio.gather(
            self.generate(instruction=approach_instruction_template + " Focus on algebraic methods.", context=self.problem_text),
            self.generate(instruction=approach_instruction_template + " Focus on geometric reasoning.", context=self.problem_text),
            self.generate(instruction=approach_instruction_template + " Focus on combinatorial techniques.", context=self.problem_text)
        )

        # Step 3: Execute candidate approaches in parallel
        execution_instruction_template = (
            "Follow the provided solution strategy step by step. Perform all necessary calculations, "
            "derivations, and logical reasoning. Ensure the solution satisfies all problem constraints."
        )
        solutions = await asyncio.gather(
            self.generate(instruction=execution_instruction_template, context=approaches[0]),
            self.generate(instruction=execution_instruction_template, context=approaches[1]),
            self.generate(instruction=execution_instruction_template, context=approaches[2])
        )

        # Step 4: Evaluate and synthesize results
        ensemble_instruction = (
            "Compare the provided solutions and select the most accurate and complete one. "
            "If multiple solutions provide complementary insights, synthesize them into a single answer. "
            "Ensure the final solution satisfies all problem constraints."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=solutions)

        # Step 5: Verify and refine the solution
        refinement_instruction = (
            "Verify the solution against the original problem constraints. "
            "Check for mathematical correctness, completeness, and clarity. "
            "Refine the solution if necessary to address any issues."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=final_solution)

        # Step 6: Summarize the final solution
        summary_instruction = (
            "Summarize the final solution in a concise and clear format. "
            "Include all key steps and the final answer."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_summary