# Workflow ID: high_level_math_ganluo_43_0
# Benchmark: high_level_math_ganluo
# Data Indices: [161, 146]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all critical information from the problem, including variables, constants, "
            "constraints, equations, and relationships. Categorize the information into mathematical domains "
            "(e.g., algebra, geometry, combinatorics) and identify potential solution strategies."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution attempts in parallel
        algebraic_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem algebraically. "
            "Focus on equations, substitutions, and simplifications. Provide a step-by-step solution."
        )
        geometric_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem geometrically. "
            "Consider coordinate geometry, synthetic geometry, and trigonometric relationships. Provide a step-by-step solution."
        )
        combinatorial_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem combinatorially. "
            "Focus on counting principles, recursive structures, and generating functions. Provide a step-by-step solution."
        )

        # Execute solution attempts in parallel
        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and synthesize the best solution
        ensemble_instruction = (
            "Compare the following candidate solutions and select the most robust, accurate, and elegant one. "
            "Provide justification for your choice. If none are satisfactory, suggest improvements."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 4: Refine the chosen solution if necessary
        refinement_instruction = (
            "Critique and improve the following solution. Address any gaps, inconsistencies, or overly complex steps. "
            "Ensure the solution satisfies all constraints and is mathematically rigorous."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the following solution into a concise and rigorous format. Include all key steps, "
            "final results, and verification that the solution satisfies all constraints."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_summary