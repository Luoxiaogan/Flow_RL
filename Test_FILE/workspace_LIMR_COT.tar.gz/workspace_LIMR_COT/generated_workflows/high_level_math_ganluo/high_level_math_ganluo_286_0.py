# Workflow ID: high_level_math_ganluo_286_0
# Benchmark: high_level_math_ganluo
# Data Indices: [526, 403]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract and Understand the Problem
        extraction_instruction = (
            "Thoroughly analyze the problem statement. Identify the key variables, constraints, "
            "and the type of mathematical reasoning required (e.g., algebra, geometry, combinatorics). "
            "Organize this information into a structured format."
        )
        problem_structure = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate Multiple Solution Approaches in Parallel
        approach_instructions = [
            f"Using {problem_structure}, solve the problem using algebraic methods. Focus on equations, inequalities, and transformations.",
            f"Using {problem_structure}, solve the problem using geometric reasoning. Consider properties of shapes, angles, and spatial relationships.",
            f"Using {problem_structure}, solve the problem using combinatorial analysis. Count possibilities, consider arrangements, and apply probabilistic reasoning."
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Refine Each Approach
        refinement_instruction_template = (
            "Critique and improve the following solution approach. Ensure it is logically consistent, "
            "mathematically correct, and satisfies all problem constraints. Highlight any assumptions made."
        )
        refined_approaches = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction_template, context=approach) for approach in approaches]
        )

        # Step 4: Evaluate and Select the Best Approach
        evaluation_instruction = (
            "Compare the following solution approaches. Select the one that is most mathematically rigorous, "
            "clearly explained, and aligned with the problem constraints. Provide a justification for your choice."
        )
        best_solution = await self.ensemble(instruction=evaluation_instruction, contexts=refined_approaches)

        # Step 5: Summarize the Final Solution
        summary_instruction = (
            "Condense the following solution into a concise and clear format. Ensure it directly answers the problem "
            "and includes all necessary steps and reasoning."
        )
        final_solution = await self.summarize(instruction=summary_instruction, context=best_solution)

        return final_solution