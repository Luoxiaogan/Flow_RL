# Workflow ID: high_level_math_ganluo_235_0
# Benchmark: high_level_math_ganluo
# Data Indices: [651, 338]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information and decompose the problem
        extraction_instruction = (
            "Extract all numerical values, variables, constraints, and relationships from the problem. "
            "Identify the type of problem (e.g., algebraic, geometric, combinatorial). "
            "Provide a structured breakdown of the problem components."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        algebraic_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Solve the problem using algebraic techniques such as equations, substitutions, and simplifications. "
            "Ensure all steps are clearly explained and justified."
        )
        geometric_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Solve the problem using geometric reasoning or coordinate geometry. "
            "Include diagrams if necessary and explain all steps thoroughly."
        )
        combinatorial_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Solve the problem using combinatorial analysis or counting principles. "
            "Consider casework or recursive structures if applicable."
        )

        # Execute parallel approaches
        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and synthesize the best solution
        ensemble_instruction = (
            "Compare the following candidate solutions and select the most complete, elegant, and correct one. "
            "If none are fully correct, synthesize a new solution combining the best elements from each. "
            "Ensure the final solution satisfies all constraints and is mathematically rigorous."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 4: Refine the solution if necessary
        refine_instruction = (
            "Critically analyze the solution for correctness, clarity, and completeness. "
            "Refine any unclear or incorrect steps. Ensure the reasoning is precise and the answer is boxed."
        )
        refined_solution = await self.revise(instruction=refine_instruction, context=final_solution)

        # Step 5: Summarize the solution
        summary_instruction = (
            "Condense the solution into a concise summary. "
            "Include only the key steps and the final answer, boxed for clarity."
        )
        summary = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return summary