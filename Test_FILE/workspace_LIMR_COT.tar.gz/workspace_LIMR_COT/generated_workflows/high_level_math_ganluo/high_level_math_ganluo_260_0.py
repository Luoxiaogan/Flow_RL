# Workflow ID: high_level_math_ganluo_260_0
# Benchmark: high_level_math_ganluo
# Data Indices: [373, 601]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem text
        extraction_instruction = (
            "Carefully analyze the problem statement and extract all relevant information, including numerical values, "
            "constraints, relationships, and any implicit assumptions. Organize this information into categories such as "
            "'given data', 'unknowns', 'constraints', and 'problem type' (e.g., combinatorics, geometry, algebra)."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        algebra_instruction = (
            f"Using the extracted information: {extracted_info}, develop an algebraic solution approach. "
            "Focus on equations, inequalities, sequences, or functional relationships."
        )
        geometry_instruction = (
            f"Using the extracted information: {extracted_info}, develop a geometric solution approach. "
            "Consider coordinate geometry, synthetic geometry, trigonometry, or area/volume calculations."
        )
        combinatorics_instruction = (
            f"Using the extracted information: {extracted_info}, develop a combinatorial solution approach. "
            "Focus on counting principles, recursive structures, or probabilistic methods."
        )

        solutions = await asyncio.gather(
            self.generate(instruction=algebra_instruction, context=self.problem_text),
            self.generate(instruction=geometry_instruction, context=self.problem_text),
            self.generate(instruction=combinatorics_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and select the best solution
        evaluation_instruction = (
            "Compare the provided solution approaches and select the most accurate, efficient, and mathematically sound one. "
            "Consider whether each solution satisfies all problem constraints and provides a clear path to the answer."
        )
        best_solution = await self.ensemble(instruction=evaluation_instruction, contexts=solutions)

        # Step 4: Refine the selected solution if necessary
        refinement_instruction = (
            "Critically review the selected solution. Identify any gaps, ambiguities, or areas for improvement. "
            "Ensure the solution is complete, rigorous, and formatted appropriately."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the refined solution into a concise, well-structured format. Ensure it directly answers the problem "
            "and includes all necessary steps and justifications."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer