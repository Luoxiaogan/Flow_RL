# Workflow ID: high_level_math_ganluo_142_0
# Benchmark: high_level_math_ganluo
# Data Indices: [760, 675]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction = await self.generate(
            instruction="Identify all variables, constants, constraints, and the mathematical domain "
                        "(e.g., algebra, geometry, number theory) relevant to solving the problem. "
                        "Provide a structured breakdown of the problem's components.",
            context=self.problem_text
        )

        # Step 2: Generate multiple solution approaches in parallel
        approaches = await asyncio.gather(
            self.generate(
                instruction=f"Based on the extracted information: {extraction}, "
                            "develop an algebraic approach to solve the problem. Include detailed steps.",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"Based on the extracted information: {extraction}, "
                            "develop a geometric approach to solve the problem. Include detailed steps.",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"Based on the extracted information: {extraction}, "
                            "develop a combinatorial or number-theoretic approach to solve the problem. Include detailed steps.",
                context=self.problem_text
            )
        )

        # Step 3: Evaluate and synthesize the best solution
        best_solution = await self.ensemble(
            instruction="Compare the following approaches and select the most promising one. "
                        "If possible, synthesize elements from multiple approaches to form a hybrid solution. "
                        "Ensure the chosen solution adheres to all problem constraints.",
            contexts=approaches
        )

        # Step 4: Refine and verify the chosen solution
        refined_solution = await self.revise(
            instruction="Critique and refine the following solution to ensure correctness. "
                        "Verify that all problem constraints are satisfied and provide a rigorous justification.",
            context=best_solution
        )

        # Step 5: Summarize the final answer
        final_answer = await self.summarize(
            instruction="Condense the following solution into a concise and structured format. "
                        "Include only the essential steps and the final answer.",
            context=refined_solution
        )

        return final_answer