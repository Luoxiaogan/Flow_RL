# Workflow ID: high_level_math_ganluo_287_0
# Benchmark: high_level_math_ganluo
# Data Indices: [703, 423]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information and constraints
        extraction_instruction = (
            "Analyze the problem thoroughly and extract all key components, including equations, "
            "numerical values, constraints, and relationships. Provide this information in a structured format."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution strategies
        strategy_instruction_template = (
            "Based on the following extracted information: {info}, formulate a detailed and comprehensive "
            "solution strategy. Consider all possible mathematical techniques applicable to the problem, including "
            "algebraic manipulation, geometric reasoning, combinatorial analysis, number theory, and symmetry exploitation. "
            "Provide step-by-step reasoning for each approach."
        )
        strategy_instruction = strategy_instruction_template.format(info=extracted_info)
        strategies = await asyncio.gather(
            self.generate(instruction=strategy_instruction, context=self.problem_text),
            self.generate(instruction=strategy_instruction, context=self.problem_text)
        )

        # Step 3: Execute strategies in parallel
        execution_instruction_template = (
            "Using the following strategy: {strategy}, solve the problem step by step. Ensure all calculations "
            "are accurate and all constraints are satisfied. Provide a detailed explanation of each step."
        )
        executions = await asyncio.gather(
            self.generate(instruction=execution_instruction_template.format(strategy=strategies[0]), context=self.problem_text),
            self.generate(instruction=execution_instruction_template.format(strategy=strategies[1]), context=self.problem_text)
        )

        # Step 4: Evaluate and synthesize results
        ensemble_instruction = (
            "Compare the following solutions: {sol1} and {sol2}. Select the most mathematically rigorous, "
            "complete, and accurate solution. If there are discrepancies, identify the source and recommend refinements."
        )
        ensemble_instruction = ensemble_instruction.format(sol1=executions[0], sol2=executions[1])
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=executions)

        # Step 5: Final verification and summarization
        summary_instruction = (
            "Condense the following solution into a concise, well-structured format. Ensure all constraints "
            "and conditions from the original problem are satisfied. Highlight the final answer clearly."
        )
        summarized_solution = await self.summarize(instruction=summary_instruction, context=final_solution)

        return summarized_solution