# Workflow ID: high_level_math_ganluo_416_0
# Benchmark: high_level_math_ganluo
# Data Indices: [147, 687]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all critical information from the problem statement, including numerical values, variables, "
            "equations, constraints, and the specific question being asked. Format the output as a structured summary."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        approach_instructions = [
            f"Using algebraic manipulation, solve the problem based on the following extracted information: {extracted_info}",
            f"Using geometric reasoning or symmetry exploitation, solve the problem based on the following extracted information: {extracted_info}",
            f"Using combinatorial analysis or recursive reasoning, solve the problem based on the following extracted information: {extracted_info}"
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Refine each approach
        refinement_instruction = (
            "Critique and refine the given solution approach to ensure logical consistency and mathematical correctness. "
            "Address any ambiguities or errors in the reasoning."
        )
        refined_approaches = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction, context=approach) for approach in approaches]
        )

        # Step 4: Select the best approach
        ensemble_instruction = (
            "Evaluate the following solution approaches and select the one that is most elegant, mathematically sound, "
            "and adheres to the problem constraints. Provide a justification for your choice."
        )
        best_approach = await self.ensemble(instruction=ensemble_instruction, contexts=refined_approaches)

        # Step 5: Summarize the final solution
        summarization_instruction = (
            "Condense the given solution into a concise, verifiable form. Ensure that it satisfies all problem constraints "
            "and is presented clearly."
        )
        final_solution = await self.summarize(instruction=summarization_instruction, context=best_approach)

        return final_solution