# Workflow ID: high_level_math_ganluo_211_0
# Benchmark: high_level_math_ganluo
# Data Indices: [809, 419]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key components of the problem
        extraction_instruction = (
            "Extract all key components of the problem, including variables, constraints, and the goal. "
            "Provide them in a structured format for further analysis."
        )
        problem_components = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Explore multiple solution approaches in parallel
        algebraic_instruction = (
            f"Using the extracted components: {problem_components}, solve the problem using algebraic methods. "
            "Focus on equations, inequalities, and symbolic manipulation."
        )
        geometric_instruction = (
            f"Using the extracted components: {problem_components}, solve the problem using geometric methods. "
            "Consider coordinate geometry, synthetic geometry, and trigonometric relationships."
        )
        combinatorial_instruction = (
            f"Using the extracted components: {problem_components}, solve the problem using combinatorial methods. "
            "Focus on counting principles, recursive structures, and probability."
        )

        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and synthesize the results
        ensemble_instruction = (
            "Evaluate the provided solutions and select the most appropriate one. "
            "Consider correctness, simplicity, and adherence to the problem constraints. "
            "If multiple solutions are valid, combine their insights."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 4: Refine the chosen solution
        refinement_instruction = (
            "Critique and refine the provided solution. Ensure it satisfies all constraints, "
            "is mathematically rigorous, and is presented clearly."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the solution into a concise, clear format. Include only the essential steps and the final answer."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer