# Workflow ID: high_level_math_ganluo_414_0
# Benchmark: high_level_math_ganluo
# Data Indices: [824, 878]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract and Understand the Problem
        extraction_instruction = (
            "Carefully analyze the problem statement to identify all key components, "
            "including numerical values, variables, constraints, and relationships. "
            "Clearly explain what the problem is asking for and any specific conditions that must be satisfied."
        )
        problem_analysis = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate Multiple Solution Paths
        generate_instructions = [
            f"Using the following analysis: {problem_analysis}\n"
            "Solve the problem using an algebraic approach. Show all steps and justify each transformation.",
            f"Using the following analysis: {problem_analysis}\n"
            "Solve the problem using a combinatorial or probabilistic approach. Clearly define events, probabilities, or counting principles.",
            f"Using the following analysis: {problem_analysis}\n"
            "Solve the problem using geometric or trigonometric reasoning. Include diagrams or visual explanations if applicable."
        ]
        solution_paths = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in generate_instructions]
        )

        # Step 3: Revise and Critique Each Solution
        revise_instruction = (
            "Critically evaluate the provided solution. Check for logical consistency, mathematical correctness, "
            "and adherence to the problem's constraints. Suggest improvements or corrections where necessary."
        )
        revised_solutions = await asyncio.gather(
            *[self.revise(instruction=revise_instruction, context=solution) for solution in solution_paths]
        )

        # Step 4: Ensemble to Select or Synthesize the Best Solution
        ensemble_instruction = (
            "Compare the following solutions and determine the best approach. Consider factors such as clarity, "
            "efficiency, correctness, and alignment with the problem's requirements. If possible, synthesize insights from multiple solutions."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=revised_solutions)

        # Step 5: Summarize the Final Solution
        summarize_instruction = (
            "Condense the final solution into a concise, well-structured format. Ensure it includes all key steps, "
            "final answers, and any necessary explanations. Format the answer clearly and professionally."
        )
        summary = await self.summarize(instruction=summarize_instruction, context=final_solution)

        return summary