# Workflow ID: high_level_math_ganluo_448_0
# Benchmark: high_level_math_ganluo
# Data Indices: [258, 225]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract critical components of the problem
        extraction_instruction = (
            "Carefully analyze the problem statement and extract all critical components, "
            "including numerical values, variables, constraints, and the specific question being asked. "
            "Identify any mathematical patterns, categories (e.g., combinatorics, geometry), "
            "and potential solution paths."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        approach_instructions = [
            f"Using the extracted information: {extracted_info}, solve the problem using algebraic methods. "
            "Focus on equations, inequalities, and functional relationships.",
            
            f"Using the extracted information: {extracted_info}, solve the problem using combinatorial methods. "
            "Consider counting principles, recursive structures, and generating functions.",
            
            f"Using the extracted information: {extracted_info}, solve the problem using geometric reasoning. "
            "Apply coordinate geometry, synthetic geometry, and trigonometric principles."
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Evaluate and synthesize approaches
        ensemble_instruction = (
            "Compare the following solution approaches and determine which one is most promising. "
            "If multiple approaches are valid, synthesize them into a unified solution. "
            "Ensure the chosen approach satisfies all constraints and is mathematically rigorous."
        )
        best_approach = await self.ensemble(instruction=ensemble_instruction, contexts=approaches)

        # Step 4: Refine the chosen approach
        refinement_instruction = (
            "Critically evaluate the following solution and refine it to ensure it is complete, accurate, "
            "and adheres to all constraints. Address any gaps in reasoning or calculations."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_approach)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the following refined solution into a concise, final answer. "
            "Ensure the output is clear, satisfies the problem's requirements, and is formatted appropriately."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer