# Workflow ID: high_level_math_ganluo_199_0
# Benchmark: high_level_math_ganluo
# Data Indices: [610, 198]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract and Understand the Problem
        extraction_instruction = (
            "Extract all mathematical expressions, variables, constraints, and goals from the problem. "
            "Organize them into a structured format for further analysis."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate Multiple Solution Strategies in Parallel
        algebraic_strategy = self.generate(
            instruction=f"Using algebraic methods, solve the problem based on the following extracted information: {extracted_info}. "
                        "Provide step-by-step reasoning and verify all constraints.",
            context=self.problem_text
        )
        geometric_strategy = self.generate(
            instruction=f"Using geometric or coordinate-based methods, solve the problem based on the following extracted information: {extracted_info}. "
                        "Provide step-by-step reasoning and verify all constraints.",
            context=self.problem_text
        )
        combinatorial_strategy = self.generate(
            instruction=f"Using combinatorial or number-theoretic methods, solve the problem based on the following extracted information: {extracted_info}. "
                        "Provide step-by-step reasoning and verify all constraints.",
            context=self.problem_text
        )

        # Execute strategies in parallel
        strategies = await asyncio.gather(algebraic_strategy, geometric_strategy, combinatorial_strategy)

        # Step 3: Refine Each Candidate Solution
        refined_solutions = await asyncio.gather(
            *[self.revise(
                instruction="Critique and refine this solution. Ensure it satisfies all constraints, handles edge cases, and is mathematically rigorous.",
                context=strategy
            ) for strategy in strategies]
        )

        # Step 4: Compare and Select the Best Solution
        ensemble_instruction = (
            "Compare the following candidate solutions and select the most correct, elegant, and complete one. "
            "Ensure the chosen solution satisfies all problem constraints and is generalizable."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_solutions)

        # Step 5: Summarize the Final Solution
        summary_instruction = (
            "Condense the final solution into a concise format while preserving all key steps and results. "
            "Ensure the output adheres to the problem's requirements."
        )
        summarized_solution = await self.summarize(instruction=summary_instruction, context=final_solution)

        return summarized_solution