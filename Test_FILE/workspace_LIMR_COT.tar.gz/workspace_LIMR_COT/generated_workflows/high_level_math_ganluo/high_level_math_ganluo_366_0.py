# Workflow ID: high_level_math_ganluo_366_0
# Benchmark: high_level_math_ganluo
# Data Indices: [171, 576]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio
        
        # Step 1: Problem Decomposition and Key Insight Extraction
        decomposition_instruction = (
            "Carefully analyze the problem statement to identify key mathematical structures, "
            "constraints, and patterns. Extract all numerical values, variables, and relationships. "
            "Provide a detailed breakdown of the problem and suggest potential solution strategies."
        )
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)
        
        # Step 2: Parallel Exploration of Solution Paths
        algebraic_instruction = (
            f"Based on the following problem analysis: {decomposition}\n"
            "Develop a solution using algebraic techniques. Focus on equations, inequalities, "
            "and functional relationships. Provide a step-by-step explanation."
        )
        geometric_instruction = (
            f"Based on the following problem analysis: {decomposition}\n"
            "Develop a solution using geometric reasoning. Consider coordinate geometry, synthetic geometry, "
            "and trigonometric relationships. Provide a step-by-step explanation."
        )
        combinatorial_instruction = (
            f"Based on the following problem analysis: {decomposition}\n"
            "Develop a solution using combinatorial methods. Consider counting principles, recursion, "
            "and generating functions. Provide a step-by-step explanation."
        )
        
        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )
        
        # Step 3: Evaluation and Selection of the Best Approach
        ensemble_instruction = (
            "Evaluate the following solution approaches and select the most promising one. "
            "Consider factors such as simplicity, computational feasibility, and alignment with the problem's constraints. "
            "If multiple approaches are complementary, synthesize them into a unified solution."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)
        
        # Step 4: Detailed Solution Development
        revise_instruction = (
            f"Refine the following solution: {best_solution}\n"
            "Ensure mathematical rigor, check for edge cases, and verify that all problem constraints are satisfied. "
            "Provide a detailed critique and improve the solution if necessary."
        )
        refined_solution = await self.revise(instruction=revise_instruction, context=best_solution)
        
        # Step 5: Final Verification and Summary
        summary_instruction = (
            f"Summarize the following solution: {refined_solution}\n"
            "Provide a concise and clear final answer. Include a final verification to ensure correctness."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)
        
        return final_answer