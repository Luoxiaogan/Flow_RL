# Workflow ID: high_level_math_ganluo_227_0
# Benchmark: high_level_math_ganluo
# Data Indices: [805, 435]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract key information from the problem
        extract_instruction = (
            "Identify all variables, constants, equations, constraints, and relationships "
            "in the problem. Organize them into categories such as 'variables', 'constants', "
            "'equations', and 'constraints'. Ensure no detail is missed."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        algebra_instruction = (
            f"Given the extracted information: {extracted_info}\n"
            "Solve the problem using algebraic methods. Include step-by-step reasoning, "
            "simplify expressions where possible, and verify intermediate results."
        )
        geometry_instruction = (
            f"Given the extracted information: {extracted_info}\n"
            "Solve the problem using geometric reasoning. Consider coordinate geometry, "
            "synthetic geometry, and trigonometric methods if applicable."
        )
        combinatorics_instruction = (
            f"Given the extracted information: {extracted_info}\n"
            "Solve the problem using combinatorial analysis. Include counting principles, "
            "recursive formulas, or generating functions if relevant."
        )

        approaches = await asyncio.gather(
            self.generate(instruction=algebra_instruction, context=self.problem_text),
            self.generate(instruction=geometry_instruction, context=self.problem_text),
            self.generate(instruction=combinatorics_instruction, context=self.problem_text)
        )

        # Step 3: Revise each approach for correctness and clarity
        revise_instruction = (
            "Critique this solution approach for logical consistency, mathematical rigor, "
            "and clarity. Suggest improvements if necessary, especially for edge cases or "
            "complex calculations."
        )
        revised_approaches = await asyncio.gather(
            *[self.revise(instruction=revise_instruction, context=approach) for approach in approaches]
        )

        # Step 4: Select the best solution using Ensemble
        ensemble_instruction = (
            "Compare these solution approaches and select the most rigorous, efficient, "
            "and elegant one. Ensure the chosen solution satisfies all problem constraints "
            "and is mathematically sound."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=revised_approaches)

        # Step 5: Summarize the final solution
        summarize_instruction = (
            "Condense the final solution into a concise, verifiable format. Ensure it "
            "includes all necessary steps and satisfies the problem's requirements."
        )
        summary = await self.summarize(instruction=summarize_instruction, context=final_solution)

        return summary