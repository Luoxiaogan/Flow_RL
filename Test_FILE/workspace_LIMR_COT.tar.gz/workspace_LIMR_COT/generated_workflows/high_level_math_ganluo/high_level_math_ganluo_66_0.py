# Workflow ID: high_level_math_ganluo_66_0
# Benchmark: high_level_math_ganluo
# Data Indices: [33, 873]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information and identify problem type
        extraction_instruction = (
            "Extract all numerical values, variables, constraints, and relationships from the problem. "
            "Identify the mathematical domain (e.g., algebra, number theory, geometry) and suggest potential solution strategies. "
            "Format the output as a structured summary."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution paths
        algebraic_instruction = f"Using algebraic methods, solve the problem based on the following extracted information: {extracted_info}. Provide step-by-step reasoning."
        number_theory_instruction = f"Using number theory techniques, solve the problem based on the following extracted information: {extracted_info}. Provide step-by-step reasoning."
        geometric_instruction = f"Using geometric reasoning, solve the problem based on the following extracted information: {extracted_info}. Provide step-by-step reasoning."

        # Execute solution paths in parallel
        algebraic_solution, number_theory_solution, geometric_solution = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=number_theory_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text)
        )

        # Step 3: Synthesize results
        synthesis_instruction = (
            "Compare and synthesize the following candidate solutions. "
            "Select the most mathematically sound and complete solution. "
            "If multiple solutions are valid, combine their strengths into a single result."
        )
        synthesized_solution = await self.ensemble(
            instruction=synthesis_instruction,
            contexts=[algebraic_solution, number_theory_solution, geometric_solution]
        )

        # Step 4: Revise and refine the final solution
        revision_instruction = (
            "Critique and refine the following solution. Ensure it satisfies all constraints, is mathematically rigorous, and is presented clearly. "
            "Correct any errors or ambiguities."
        )
        refined_solution = await self.revise(instruction=revision_instruction, context=synthesized_solution)

        # Step 5: Summarize the final result
        summary_instruction = (
            "Condense the following solution into a concise, well-structured answer. "
            "Include only the essential steps and the final result."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer