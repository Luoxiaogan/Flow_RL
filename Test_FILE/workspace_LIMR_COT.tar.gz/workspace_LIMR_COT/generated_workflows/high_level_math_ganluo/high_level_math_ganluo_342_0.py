# Workflow ID: high_level_math_ganluo_342_0
# Benchmark: high_level_math_ganluo
# Data Indices: [380, 461]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information and problem structure
        extraction_instruction = (
            "Extract all numerical values, relationships, constraints, and the question being asked. "
            "Identify the mathematical domain (e.g., geometry, combinatorics) and any specific techniques required. "
            "Provide this information in a structured format."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        approach_instructions = [
            f"Using algebraic methods, solve the problem based on the following extracted information: {extracted_info}",
            f"Using geometric reasoning, solve the problem based on the following extracted information: {extracted_info}",
            f"Using combinatorial or probabilistic analysis, solve the problem based on the following extracted information: {extracted_info}"
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Refine and validate each solution approach
        refinement_instruction = (
            "Critically evaluate the solution approach. Check for logical consistency, mathematical correctness, "
            "and adherence to all constraints. Suggest improvements if necessary."
        )
        refined_approaches = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction, context=approach) for approach in approaches]
        )

        # Step 4: Compare and synthesize the best solution
        ensemble_instruction = (
            "Compare the provided solution approaches. Evaluate their correctness, clarity, and efficiency. "
            "Select the most robust and well-supported solution. If multiple approaches are valid, synthesize them into a unified solution."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_approaches)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the solution into a clear, concise format. Ensure it directly answers the question and includes all necessary steps and reasoning."
        )
        summarized_solution = await self.summarize(instruction=summary_instruction, context=final_solution)

        return summarized_solution