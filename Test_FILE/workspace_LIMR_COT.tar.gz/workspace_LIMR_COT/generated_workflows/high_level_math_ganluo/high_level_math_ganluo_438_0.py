# Workflow ID: high_level_math_ganluo_438_0
# Benchmark: high_level_math_ganluo
# Data Indices: [720, 432]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information and understand the problem
        extraction_instruction = (
            "Thoroughly analyze the problem statement and extract all critical information, including numerical values, "
            "constraints, and the type of mathematical reasoning required (e.g., algebraic, combinatorial, geometric). "
            "Organize this information clearly for subsequent steps."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate solution strategies
        strategy_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Outline multiple potential solution strategies. Include specific approaches such as casework analysis, "
            "recursive formulas, generating functions, or symmetry exploitation where applicable. Ensure each strategy "
            "is described in detail and can be executed independently."
        )
        strategies = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Parallel exploration of solution paths
        solution_paths = []
        for i, strategy in enumerate(strategies.split("\n\n")):
            path_instruction = (
                f"Execute the following solution strategy step-by-step:\n{strategy}\n"
                "Ensure all calculations are accurate and intermediate results are clearly documented."
            )
            solution_paths.append(self.generate(instruction=path_instruction, context=self.problem_text))

        candidate_solutions = await asyncio.gather(*solution_paths)

        # Step 4: Evaluate and select the best solution
        ensemble_instruction = (
            "Evaluate the following candidate solutions and select the most appropriate one based on correctness, "
            "efficiency, and clarity. Consider whether each solution satisfies all problem constraints and handles "
            "edge cases appropriately."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=candidate_solutions)

        # Step 5: Verify and refine the selected solution
        refinement_instruction = (
            "Critically review the following solution for correctness, completeness, and computational accuracy. "
            "Refine it if necessary, ensuring all constraints are satisfied and edge cases are addressed."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 6: Prepare the final output
        summary_instruction = (
            "Condense the following solution into a concise yet complete format. Ensure all key steps and results "
            "are included, and the final answer is clearly stated."
        )
        final_output = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_output