# Workflow ID: high_level_math_ganluo_165_0
# Benchmark: high_level_math_ganluo
# Data Indices: [387, 23]

```python
class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = """
        Analyze the problem thoroughly and extract all key components, including:
        - Equations or mathematical expressions
        - Constraints or conditions
        - Variables and their relationships
        - What is being asked (the goal of the problem)
        Provide this information in a structured format for further processing.
        """
        key_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Propose multiple solution strategies
        strategy_instruction = f"""
        Based on the extracted information: {key_info}
        Propose multiple solution strategies that could solve the problem. Consider:
        - Algebraic manipulation
        - Geometric reasoning
        - Combinatorial analysis
        - Number theory techniques
        - Any other relevant mathematical approaches
        For each strategy, provide a brief explanation of how it applies to the problem.
        """
        strategies = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Explore solution paths in parallel
        solution_paths = []
        for i, strategy in enumerate(strategies.split("\n\n")):  # Assuming strategies are separated by double newlines
            path_instruction = f"""
            Solve the problem using the following strategy:
            {strategy}
            Ensure the solution is complete, correct, and adheres to the problem constraints.
            """
            solution_paths.append(self.generate(instruction=path_instruction, context=self.problem_text))

        candidate_solutions = await asyncio.gather(*solution_paths)

        # Step 4: Evaluate and select the best solution
        evaluation_instruction = """
        Evaluate the provided candidate solutions and select the best one based on:
        - Correctness and completeness
        - Adherence to the problem constraints
        - Clarity and logical structure
        Provide the selected solution along with a justification for your choice.
        """
        best_solution = await self.ensemble(instruction=evaluation_instruction, contexts=candidate_solutions)

        # Step 5: Refine the selected solution
        refinement_instruction = """
        Critique and refine the selected solution to ensure:
        - Clarity and readability
        - Proper formatting
        - Logical flow and correctness
        Make any necessary improvements while preserving the solution's integrity.
        """
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 6: Summarize the final solution
        summary_instruction = """
        Condense the final solution into a concise, readable format that directly answers the problem.
        Include only the essential steps and the final answer.
        """
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_summary
```