# Workflow ID: high_level_math_ganluo_407_0
# Benchmark: high_level_math_ganluo
# Data Indices: [962, 118]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Analyze the problem and extract key components
        analysis_instruction = (
            "Analyze the problem statement thoroughly. Identify the main equation(s), "
            "constraints, and the target quantity to compute. List all given information "
            "and what needs to be determined."
        )
        problem_analysis = await self.generate(instruction=analysis_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution paths in parallel
        algebraic_instruction = (
            f"Using the following analysis: {problem_analysis}\n"
            "Solve the problem using algebraic manipulation. Simplify expressions, "
            "solve equations, and derive the target quantity step by step."
        )
        recursive_instruction = (
            f"Using the following analysis: {problem_analysis}\n"
            "Attempt a recursive or iterative approach. Look for patterns, sequences, "
            "or relationships that can help compute the target quantity."
        )
        substitution_instruction = (
            f"Using the following analysis: {problem_analysis}\n"
            "Use substitution methods to find the target quantity. Substitute known "
            "values or relationships into equations and simplify."
        )

        algebraic_solution, recursive_solution, substitution_solution = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=recursive_instruction, context=self.problem_text),
            self.generate(instruction=substitution_instruction, context=self.problem_text)
        )

        # Step 3: Refine and validate each solution path
        refinement_instruction = (
            "Critique the provided solution. Check for logical consistency, "
            "correctness of calculations, and adherence to the problem's constraints. "
            "Provide suggestions for improvement if necessary."
        )
        refined_algebraic = await self.revise(instruction=refinement_instruction, context=algebraic_solution)
        refined_recursive = await self.revise(instruction=refinement_instruction, context=recursive_solution)
        refined_substitution = await self.revise(instruction=refinement_instruction, context=substitution_solution)

        # Step 4: Synthesize results and select the best solution
        synthesis_instruction = (
            "Compare the following solutions and select the most robust and accurate one. "
            "Ensure the chosen solution satisfies all problem constraints and is mathematically sound."
        )
        final_solution = await self.ensemble(
            instruction=synthesis_instruction,
            contexts=[refined_algebraic, refined_recursive, refined_substitution]
        )

        # Step 5: Summarize the final result
        summary_instruction = (
            "Condense the final solution into a clear and concise format. Include only "
            "the essential steps and the final answer."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=final_solution)

        return final_answer