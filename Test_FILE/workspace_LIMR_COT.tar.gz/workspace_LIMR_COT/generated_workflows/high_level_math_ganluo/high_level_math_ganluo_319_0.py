# Workflow ID: high_level_math_ganluo_319_0
# Benchmark: high_level_math_ganluo
# Data Indices: [799, 396]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Problem Understanding and Decomposition
        problem_analysis = await self.generate(
            instruction="Analyze the problem thoroughly. Identify all variables, constraints, and relationships. "
                        "Break the problem into smaller, manageable components. Highlight any special conditions or edge cases.",
            context=self.problem_text
        )

        # Step 2: Parallel Exploration of Solution Approaches
        algebraic_approach = self.generate(
            instruction=f"Based on the analysis: {problem_analysis}, develop an algebraic solution approach. "
                        "Use equations, substitutions, and transformations as needed.",
            context=self.problem_text
        )
        geometric_approach = self.generate(
            instruction=f"Based on the analysis: {problem_analysis}, develop a geometric solution approach. "
                        "Use diagrams, coordinate geometry, and trigonometric relationships as needed.",
            context=self.problem_text
        )
        combinatorial_approach = self.generate(
            instruction=f"Based on the analysis: {problem_analysis}, develop a combinatorial or probabilistic solution approach. "
                        "Use counting principles, recursive formulas, or generating functions as needed.",
            context=self.problem_text
        )
        approaches = await asyncio.gather(algebraic_approach, geometric_approach, combinatorial_approach)

        # Step 3: Evaluation and Synthesis
        best_approach = await self.ensemble(
            instruction="Evaluate the provided solution approaches. Consider correctness, elegance, and feasibility. "
                        "Select the best approach or synthesize elements from multiple approaches if necessary.",
            contexts=approaches
        )

        # Step 4: Refinement and Verification
        refined_solution = await self.revise(
            instruction=f"Refine the selected solution: {best_approach}. Ensure it is correct, clear, and adheres to all constraints. "
                        "Verify that all edge cases are handled and the solution is mathematically sound.",
            context=self.problem_text
        )

        # Step 5: Summarization
        final_solution = await self.summarize(
            instruction="Condense the refined solution into a concise and polished form. "
                        "Include only the essential steps and final answer.",
            context=refined_solution
        )

        return final_solution