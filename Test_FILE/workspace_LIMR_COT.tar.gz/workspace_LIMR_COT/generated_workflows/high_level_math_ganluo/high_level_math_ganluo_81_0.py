# Workflow ID: high_level_math_ganluo_81_0
# Benchmark: high_level_math_ganluo
# Data Indices: [358, 293]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract critical information from the problem
        extraction_instruction = (
            "Extract all key information from the problem, including numerical values, conditions, "
            "constraints, and the specific question being asked. Organize this information clearly."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate multiple solution strategies
        strategy_instruction = (
            f"Based on the extracted information: {extracted_info}, formulate at least three distinct "
            "solution strategies. Include algebraic, geometric, and combinatorial approaches if applicable. "
            "Provide detailed reasoning for each strategy."
        )
        strategies = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Execute strategies in parallel
        parallel_instructions = [
            f"Follow this strategy step-by-step: {strategy}" for strategy in strategies.split("\n\n")
        ]
        parallel_results = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in parallel_instructions]
        )

        # Step 4: Evaluate and synthesize results
        ensemble_instruction = (
            "Compare the following candidate solutions, check their consistency with the original problem, "
            "and select the best approach. Provide justification for your choice."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=parallel_results)

        # Step 5: Verify and refine the solution
        verification_instruction = (
            f"Verify this solution against the original problem constraints: {best_solution}. "
            "If necessary, refine the solution to ensure it satisfies all conditions."
        )
        refined_solution = await self.revise(instruction=verification_instruction, context=best_solution)

        # Step 6: Extract the final answer
        summary_instruction = (
            "Summarize the final solution and extract the answer in the required format. Ensure clarity and precision."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer