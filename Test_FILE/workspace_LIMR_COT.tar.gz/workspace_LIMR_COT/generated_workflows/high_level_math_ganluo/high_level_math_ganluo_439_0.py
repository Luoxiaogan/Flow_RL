# Workflow ID: high_level_math_ganluo_439_0
# Benchmark: high_level_math_ganluo
# Data Indices: [51, 757]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract and Understand the Problem
        extraction_instruction = (
            "Carefully analyze the problem statement and extract all key components, "
            "such as equations, variables, constraints, geometric properties, or numerical values. "
            "Organize the extracted information in a structured format for further processing."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Explore Multiple Solution Approaches in Parallel
        approach_1_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using algebraic methods. "
            "Focus on symbolic manipulation, substitution, and simplification. "
            "Clearly show all steps and reasoning."
        )
        approach_2_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using geometric reasoning. "
            "If applicable, convert the problem into a geometric representation and use properties like symmetry, "
            "area/volume calculations, or trigonometric relationships. Clearly show all steps and reasoning."
        )
        approach_3_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using combinatorial or number-theoretic methods. "
            "Focus on counting principles, modular arithmetic, or recursive structures. Clearly show all steps and reasoning."
        )

        approaches = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text),
            self.generate(instruction=approach_3_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and Select the Best Approach
        ensemble_instruction = (
            "Compare the following candidate solutions and select the most appropriate one. "
            "Consider factors such as correctness, mathematical rigor, elegance, and adherence to the problem constraints. "
            "If necessary, synthesize elements from multiple solutions to form a complete answer."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=approaches)

        # Step 4: Refine and Verify the Selected Solution
        refinement_instruction = (
            "Critically review the selected solution and refine it to ensure mathematical correctness and clarity. "
            "Check that all constraints are satisfied and that the solution is fully justified. "
            "Address any edge cases or ambiguities."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the Final Answer
        summary_instruction = (
            "Condense the refined solution into a concise and well-structured final answer. "
            "Include only the essential steps and the final result, formatted appropriately."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer