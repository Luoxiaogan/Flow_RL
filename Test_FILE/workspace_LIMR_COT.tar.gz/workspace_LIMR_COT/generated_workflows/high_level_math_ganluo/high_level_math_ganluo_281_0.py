# Workflow ID: high_level_math_ganluo_281_0
# Benchmark: high_level_math_ganluo
# Data Indices: [915, 424]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Initial Analysis - Extract key information and identify problem type
        analysis_instruction = (
            "Analyze the problem to identify its type (e.g., combinatorics, number theory, geometry). "
            "Extract all key numerical values, constraints, and mathematical structures. "
            "Provide a brief summary of the problem's requirements and any special conditions."
        )
        analysis = await self.generate(instruction=analysis_instruction, context=self.problem_text)

        # Step 2: Generate Multiple Solution Paths in Parallel
        algebraic_instruction = (
            f"Based on the analysis: {analysis}, solve the problem using algebraic methods. "
            "Include all steps, transformations, and intermediate results. Ensure the solution satisfies all constraints."
        )
        geometric_instruction = (
            f"Based on the analysis: {analysis}, solve the problem using geometric methods. "
            "Include all steps, diagrams (if applicable), and intermediate results. Ensure the solution satisfies all constraints."
        )
        combinatorial_instruction = (
            f"Based on the analysis: {analysis}, solve the problem using combinatorial methods. "
            "Include all steps, counting principles, and intermediate results. Ensure the solution satisfies all constraints."
        )

        # Parallel execution of multiple approaches
        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Refine Each Solution Path
        refined_results = await asyncio.gather(
            self.revise(instruction="Critique and improve this solution. Check for logical consistency, mathematical correctness, and adherence to constraints.", context=results[0]),
            self.revise(instruction="Critique and improve this solution. Check for logical consistency, mathematical correctness, and adherence to constraints.", context=results[1]),
            self.revise(instruction="Critique and improve this solution. Check for logical consistency, mathematical correctness, and adherence to constraints.", context=results[2])
        )

        # Step 4: Synthesize the Best Solution
        synthesis_instruction = (
            "Compare the following solutions and select the most rigorous, efficient, and correct one. "
            "If possible, synthesize a hybrid solution that combines the strengths of multiple approaches."
        )
        final_solution = await self.ensemble(instruction=synthesis_instruction, contexts=refined_results)

        # Step 5: Summarize the Final Solution
        summary_instruction = (
            "Condense the final solution into a clear and concise format. "
            "Include only the essential steps and the final answer. Ensure the summary is easy to understand."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=final_solution)

        return final_summary