# Workflow ID: high_level_math_ganluo_163_0
# Benchmark: high_level_math_ganluo
# Data Indices: [246, 434]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key components and decompose the problem
        decomposition = await self.generate(
            instruction="Identify and extract all key components of the problem, including numerical values, variables, constraints, and relationships. Organize this information clearly.",
            context=self.problem_text
        )

        # Step 2: Generate multiple solution approaches in parallel
        algebraic_approach = self.generate(
            instruction=f"Using the extracted components: {decomposition}, solve the problem algebraically. Provide a detailed step-by-step solution.",
            context=self.problem_text
        )
        geometric_approach = self.generate(
            instruction=f"Using the extracted components: {decomposition}, solve the problem geometrically. Provide a detailed step-by-step solution.",
            context=self.problem_text
        )
        combinatorial_approach = self.generate(
            instruction=f"Using the extracted components: {decomposition}, solve the problem using combinatorial methods. Provide a detailed step-by-step solution.",
            context=self.problem_text
        )
        results = await asyncio.gather(algebraic_approach, geometric_approach, combinatorial_approach)

        # Step 3: Refine the generated solutions
        refined_results = await asyncio.gather(
            self.revise(instruction="Critique and improve the following solution for correctness, clarity, and completeness.", context=results[0]),
            self.revise(instruction="Critique and improve the following solution for correctness, clarity, and completeness.", context=results[1]),
            self.revise(instruction="Critique and improve the following solution for correctness, clarity, and completeness.", context=results[2])
        )

        # Step 4: Ensemble decision-making to select or synthesize the best solution
        final_solution = await self.ensemble(
            instruction="Evaluate the following solutions and either select the best one or synthesize a new solution combining their strongest aspects. Ensure the final solution satisfies all problem constraints.",
            contexts=refined_results
        )

        # Step 5: Prepare the final output
        final_output = await self.summarize(
            instruction="Condense the following solution into a clear, concise format that matches the problem's requested form. Preserve all critical details.",
            context=final_solution
        )

        return final_output