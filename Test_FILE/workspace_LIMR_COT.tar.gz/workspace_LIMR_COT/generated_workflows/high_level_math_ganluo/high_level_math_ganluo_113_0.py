# Workflow ID: high_level_math_ganluo_113_0
# Benchmark: high_level_math_ganluo
# Data Indices: [245, 92]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key components and constraints
        extraction_instruction = (
            "Carefully analyze the problem statement and extract all critical components, "
            "including variables, constants, constraints, and relationships. Organize them into "
            "categories such as numerical values, equations, inequalities, geometric properties, "
            "and logical conditions. Ensure no detail is overlooked."
        )
        extracted_components = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        approach_instructions = [
            (
                f"Based on the extracted components: {extracted_components}, develop a solution "
                "using an algebraic approach. Focus on equations, inequalities, and functional relationships."
            ),
            (
                f"Based on the extracted components: {extracted_components}, develop a solution "
                "using a combinatorial approach. Consider counting principles, permutations, combinations, "
                "and probabilistic methods."
            ),
            (
                f"Based on the extracted components: {extracted_components}, develop a solution "
                "using a geometric approach. Analyze shapes, angles, areas, and spatial relationships."
            ),
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Evaluate and synthesize the best approach
        ensemble_instruction = (
            "Compare the following solution approaches and determine the most effective one. "
            "Consider factors such as simplicity, correctness, computational feasibility, and alignment "
            "with the problem constraints. If multiple approaches are complementary, synthesize them into a unified solution."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=approaches)

        # Step 4: Refine the selected solution
        refinement_instruction = (
            "Critically review the following solution and refine it for clarity, correctness, and completeness. "
            "Ensure all constraints are satisfied, and verify the solution against edge cases and boundary conditions."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the following solution into a concise summary that highlights the key steps, reasoning, "
            "and final result. Ensure the summary is easy to understand and captures the essence of the solution."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_summary