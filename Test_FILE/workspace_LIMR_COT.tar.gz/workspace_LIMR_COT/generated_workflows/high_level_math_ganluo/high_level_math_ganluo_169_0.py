# Workflow ID: high_level_math_ganluo_169_0
# Benchmark: high_level_math_ganluo
# Data Indices: [826, 804]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract critical components from the problem
        extraction_instruction = (
            "Identify and extract all key components of the problem, including variables, constraints, "
            "relationships, and objectives. Focus on mathematical structures such as equations, inequalities, "
            "geometric properties, or combinatorial elements. Provide the extracted information in a structured format."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate initial solution approaches
        initial_solution_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Generate an initial solution or approach to solve the problem. Consider multiple strategies such as "
            "algebraic manipulation, geometric reasoning, combinatorial analysis, or number theory techniques. "
            "Provide a detailed reasoning process and intermediate steps."
        )
        initial_solution = await self.generate(instruction=initial_solution_instruction, context=self.problem_text)

        # Step 3: Refine and validate the solution
        refinement_instruction = (
            "Critique and refine the provided solution. Ensure it satisfies all constraints and handles edge cases. "
            "Simplify expressions where possible and verify mathematical correctness. Highlight any assumptions made."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=initial_solution)

        # Step 4: Explore alternative approaches in parallel
        alternative_approach_1 = (
            "Solve the problem using an algebraic approach. Focus on equations, inequalities, and symbolic manipulation."
        )
        alternative_approach_2 = (
            "Solve the problem using a geometric approach. Utilize coordinate geometry, synthetic geometry, or trigonometry."
        )
        alternative_approach_3 = (
            "Solve the problem using combinatorial or probabilistic methods. Consider counting principles, recursion, or expected values."
        )

        results = await asyncio.gather(
            self.generate(instruction=alternative_approach_1, context=self.problem_text),
            self.generate(instruction=alternative_approach_2, context=self.problem_text),
            self.generate(instruction=alternative_approach_3, context=self.problem_text)
        )

        # Step 5: Select the best approach or synthesize insights
        ensemble_instruction = (
            "Evaluate the provided solutions and select the most robust and correct one. If multiple approaches "
            "are valid, synthesize their insights to produce a comprehensive solution."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 6: Summarize the final answer
        summary_instruction = (
            "Condense the solution into a concise final answer. Ensure clarity and precision in presenting the result."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=final_solution)

        return final_answer