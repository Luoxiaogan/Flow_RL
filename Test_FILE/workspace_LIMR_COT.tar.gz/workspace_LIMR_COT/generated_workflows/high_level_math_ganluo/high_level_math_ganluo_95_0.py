# Workflow ID: high_level_math_ganluo_95_0
# Benchmark: high_level_math_ganluo
# Data Indices: [708, 671]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information and categorize the problem
        extraction_instruction = (
            "Extract all key information from the problem, including variables, constraints, "
            "and relationships. Categorize the problem into one or more mathematical domains "
            "(e.g., algebra, geometry, combinatorics)."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        approach_instructions = [
            f"Using algebraic methods, solve the problem based on the following extracted information: {extracted_info}",
            f"Using geometric methods, solve the problem based on the following extracted information: {extracted_info}",
            f"Using combinatorial or number-theoretic methods, solve the problem based on the following extracted information: {extracted_info}",
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Refine each solution approach for accuracy and completeness
        refinement_instruction = (
            "Critique and refine the given solution approach. Ensure all steps are logically consistent, "
            "calculations are accurate, and all problem constraints are satisfied."
        )
        refined_approaches = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction, context=approach) for approach in approaches]
        )

        # Step 4: Select the best solution using Ensemble
        ensemble_instruction = (
            "Compare the provided solution approaches and select the best one based on criteria such as "
            "simplicity, elegance, and adherence to the problem constraints. Provide justification for your choice."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_approaches)

        # Step 5: Extract the final answer in a standardized format
        answer_extraction_instruction = (
            "Extract the final answer from the selected solution. Ensure it is in the required format "
            "(e.g., numerical value, simplified expression)."
        )
        final_answer = await self.generate(instruction=answer_extraction_instruction, context=best_solution)

        return final_answer