# Workflow ID: high_level_math_ganluo_275_0
# Benchmark: high_level_math_ganluo
# Data Indices: [127, 558]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Problem Understanding and Decomposition
        extraction_instruction = (
            "Thoroughly analyze the given problem. Extract and summarize all key mathematical elements, "
            "including variables, equations, geometric structures, combinatorial setups, and constraints. "
            "Ensure the summary is complete and structured for further processing."
        )
        problem_summary = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Solution Strategy Formulation
        strategy_instruction = (
            f"Based on the following problem summary:\n{problem_summary}\n"
            "Propose multiple solution strategies. Consider approaches from algebra, geometry, combinatorics, "
            "and number theory. For each strategy, provide a brief justification and outline the steps required."
        )
        strategies = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Parallel Exploration of Solution Paths
        # Dynamically construct instructions for each strategy
        strategy_list = strategies.split("\n\n")  # Assuming strategies are separated by double newlines
        tasks = []
        for i, strategy in enumerate(strategy_list):
            task_instruction = (
                f"Follow this solution strategy:\n{strategy}\n"
                "Execute the outlined steps carefully, ensuring all calculations and reasoning are correct. "
                "Provide a complete solution based on this approach."
            )
            tasks.append(self.generate(instruction=task_instruction, context=self.problem_text))

        # Run tasks in parallel
        parallel_results = await asyncio.gather(*tasks)

        # Step 4: Evaluation and Selection of Best Solution
        ensemble_instruction = (
            "Evaluate the following candidate solutions and select the best one. "
            "Consider correctness, clarity, and alignment with the problem constraints. "
            "Provide a justification for your selection."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=parallel_results)

        # Step 5: Final Refinement and Verification
        refinement_instruction = (
            f"Refine the following solution:\n{best_solution}\n"
            "Check for correctness, simplify expressions, verify edge cases, and ensure the solution "
            "is presented clearly and logically. Address any gaps or ambiguities."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 6: Output Construction
        output_instruction = (
            f"Summarize the following refined solution into a concise and well-structured final answer:\n{refined_solution}\n"
            "Ensure the final output is clear, complete, and ready for submission."
        )
        final_answer = await self.summarize(instruction=output_instruction, context=refined_solution)

        return final_answer