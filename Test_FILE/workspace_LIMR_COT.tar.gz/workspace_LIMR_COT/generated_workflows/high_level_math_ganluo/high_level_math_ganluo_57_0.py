# Workflow ID: high_level_math_ganluo_57_0
# Benchmark: high_level_math_ganluo
# Data Indices: [743, 350]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Problem Decomposition
        decomposition = await self.generate(
            instruction="Analyze the problem to identify its mathematical domain (e.g., algebra, geometry, combinatorics), key constraints, and objectives. Extract any numerical values, equations, or geometric descriptions explicitly mentioned.",
            context=self.problem_text
        )

        # Step 2: Generate Multiple Solution Approaches
        algebraic_approach = self.generate(
            instruction=f"Using algebraic methods, solve the problem step-by-step. Consider polynomial equations, functional relationships, and inequalities. Use the following extracted information: {decomposition}",
            context=self.problem_text
        )
        geometric_approach = self.generate(
            instruction=f"Using geometric reasoning, interpret the problem visually or spatially. Consider coordinate geometry, synthetic geometry, and trigonometric relationships. Use the following extracted information: {decomposition}",
            context=self.problem_text
        )
        combinatorial_approach = self.generate(
            instruction=f"Using combinatorial or probabilistic methods, count possibilities, calculate expected values, or use recursive structures. Use the following extracted information: {decomposition}",
            context=self.problem_text
        )

        # Execute approaches in parallel
        results = await asyncio.gather(algebraic_approach, geometric_approach, combinatorial_approach)

        # Step 3: Refine Each Solution
        refined_results = await asyncio.gather(
            self.revise(
                instruction="Critique and improve this solution. Ensure all constraints are satisfied and the reasoning is mathematically sound.",
                context=results[0]
            ),
            self.revise(
                instruction="Critique and improve this solution. Ensure all constraints are satisfied and the reasoning is mathematically sound.",
                context=results[1]
            ),
            self.revise(
                instruction="Critique and improve this solution. Ensure all constraints are satisfied and the reasoning is mathematically sound.",
                context=results[2]
            )
        )

        # Step 4: Ensemble Decision
        final_solution = await self.ensemble(
            instruction="Compare the refined solutions and select the most robust, elegant, and mathematically sound approach. Ensure the chosen solution satisfies all problem constraints.",
            contexts=refined_results
        )

        # Step 5: Final Verification and Summarization
        summary = await self.summarize(
            instruction="Condense the final solution into a concise format, ensuring clarity and correctness. Include all necessary steps and the final answer.",
            context=final_solution
        )

        return summary