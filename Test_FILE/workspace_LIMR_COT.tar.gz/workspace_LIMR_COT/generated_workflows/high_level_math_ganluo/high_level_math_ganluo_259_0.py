# Workflow ID: high_level_math_ganluo_259_0
# Benchmark: high_level_math_ganluo
# Data Indices: [84, 841]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Understand and decompose the problem
        decomposition_instruction = (
            "Carefully analyze the problem statement. Identify all variables, constants, constraints, "
            "and the specific question being asked. Break the problem into smaller, manageable sub-problems. "
            "Provide a structured outline of the problem's components and relationships."
        )
        problem_decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        algebraic_approach_instruction = (
            f"Based on the problem decomposition: {problem_decomposition}, "
            "solve the problem using algebraic methods. Include all steps, equations, and reasoning. "
            "Ensure the solution is mathematically rigorous and addresses all constraints."
        )
        geometric_approach_instruction = (
            f"Based on the problem decomposition: {problem_decomposition}, "
            "solve the problem using geometric reasoning. Include diagrams (if applicable), relationships, "
            "and calculations. Ensure the solution is clear and logically sound."
        )
        combinatorial_approach_instruction = (
            f"Based on the problem decomposition: {problem_decomposition}, "
            "solve the problem using combinatorial or probabilistic methods. Include counting principles, "
            "expected values, or recursive structures as needed. Ensure the solution is complete and accurate."
        )

        results = await asyncio.gather(
            self.generate(instruction=algebraic_approach_instruction, context=self.problem_text),
            self.generate(instruction=geometric_approach_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_approach_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and select the best solution
        selection_instruction = (
            "Compare the provided solutions and select the most accurate, efficient, and mathematically rigorous one. "
            "Ensure the chosen solution satisfies all constraints and provides a clear path to the final answer."
        )
        best_solution = await self.ensemble(instruction=selection_instruction, contexts=results)

        # Step 4: Refine the selected solution
        refinement_instruction = (
            "Review the selected solution for mathematical accuracy, clarity, and completeness. "
            "Correct any errors, fill gaps in reasoning, and improve the presentation. Ensure the solution "
            "is polished and ready for final submission."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the refined solution into a concise summary. Include the final answer, key steps, "
            "and any critical insights. Ensure the summary is clear and easy to understand."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_summary