# Workflow ID: high_level_math_ganluo_338_0
# Benchmark: high_level_math_ganluo
# Data Indices: [777, 222]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all numerical values, variables, relationships, and constraints from the problem. "
            "Identify any implicit conditions or assumptions. Organize the information clearly."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        approach_1_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Develop an algebraic or computational approach to solve the problem. "
            "Include all necessary steps, formulas, and reasoning. Ensure the solution is rigorous."
        )
        approach_2_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Develop a geometric or visual approach to solve the problem. "
            "Include diagrams, geometric properties, and spatial reasoning if applicable."
        )
        results = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text)
        )
        approach_1, approach_2 = results

        # Step 3: Refine each approach
        refine_instruction_1 = (
            "Critically evaluate the following solution approach. Identify and correct any errors, "
            "ambiguities, or missing steps. Ensure the solution is complete and mathematically sound."
        )
        refine_instruction_2 = refine_instruction_1  # Same refinement criteria for both approaches
        refined_results = await asyncio.gather(
            self.revise(instruction=refine_instruction_1, context=approach_1),
            self.revise(instruction=refine_instruction_2, context=approach_2)
        )
        refined_approach_1, refined_approach_2 = refined_results

        # Step 4: Ensemble selection of the best solution
        ensemble_instruction = (
            "Compare the following two refined solution approaches. Evaluate them based on correctness, "
            "clarity, mathematical rigor, and adherence to the problem's constraints. Select the best approach, "
            "or synthesize a new solution combining the strengths of both if necessary."
        )
        final_solution = await self.ensemble(
            instruction=ensemble_instruction,
            contexts=[refined_approach_1, refined_approach_2]
        )

        # Step 5: Summarize the final answer
        summarize_instruction = (
            "Condense the following solution into a concise, well-structured answer. "
            "Ensure the final answer directly addresses the problem and includes all necessary details."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=final_solution)

        return final_answer