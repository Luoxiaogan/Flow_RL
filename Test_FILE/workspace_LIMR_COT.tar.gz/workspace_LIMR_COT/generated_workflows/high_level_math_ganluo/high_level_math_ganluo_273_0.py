# Workflow ID: high_level_math_ganluo_273_0
# Benchmark: high_level_math_ganluo
# Data Indices: [865, 264]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Problem Decomposition
        decomposition_instruction = (
            "Identify and extract all key components of the problem, including equations, variables, "
            "constraints, and any special conditions. Organize the information in a structured format."
        )
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Exploration of Solution Paths
        # Generate multiple solution approaches in parallel
        approach_instructions = [
            "Solve the problem using algebraic manipulation techniques. Focus on simplifying expressions, "
            "factoring, or solving equations step-by-step.",
            "Solve the problem using recursive formulas or sequences. Identify patterns and build the solution iteratively.",
            "Solve the problem using symmetry or geometric reasoning. Look for symmetrical properties or geometric interpretations.",
            "Solve the problem using combinatorial or probabilistic methods. Count possibilities or calculate expected values."
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=decomposition) for instr in approach_instructions]
        )

        # Step 3: Evaluation and Selection of Best Approach
        evaluation_instruction = (
            "Evaluate the provided solution approaches based on clarity, feasibility, and alignment with the problem requirements. "
            "Select the most promising approach and provide reasoning for your choice."
        )
        best_approach = await self.ensemble(instruction=evaluation_instruction, contexts=approaches)

        # Step 4: Refinement of Chosen Solution
        refinement_instruction = (
            "Critique and refine the chosen solution. Ensure it is mathematically rigorous, free of errors, "
            "and satisfies all problem constraints. Provide detailed reasoning for each step."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_approach)

        # Step 5: Final Answer Extraction
        summary_instruction = (
            "Extract the final answer from the refined solution. Ensure the answer is concise, clear, "
            "and formatted according to the problem requirements."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer