# Workflow ID: high_level_math_ganluo_240_0
# Benchmark: high_level_math_ganluo
# Data Indices: [330, 72]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Problem Understanding and Decomposition
        problem_decomposition = await self.generate(
            instruction="Analyze the problem statement thoroughly. Identify all variables, constraints, and the goal. "
                        "Provide a structured breakdown of the problem, including any mathematical relationships or patterns.",
            context=self.problem_text
        )

        # Step 2: Exploration of Solution Approaches
        algebraic_approach = self.generate(
            instruction=f"Based on the problem decomposition: {problem_decomposition}, "
                        "develop an algebraic approach to solve the problem. Include equations, transformations, "
                        "and any relevant mathematical techniques.",
            context=self.problem_text
        )
        geometric_approach = self.generate(
            instruction=f"Based on the problem decomposition: {problem_decomposition}, "
                        "develop a geometric approach to solve the problem. Include diagrams, coordinate systems, "
                        "and geometric properties if applicable.",
            context=self.problem_text
        )
        combinatorial_approach = self.generate(
            instruction=f"Based on the problem decomposition: {problem_decomposition}, "
                        "develop a combinatorial approach to solve the problem. Include counting principles, "
                        "recursive formulas, or generating functions if applicable.",
            context=self.problem_text
        )

        # Execute approaches in parallel
        approaches = await asyncio.gather(algebraic_approach, geometric_approach, combinatorial_approach)

        # Step 3: Evaluation and Refinement
        best_approach = await self.ensemble(
            instruction="Compare the following solution approaches and select the most promising one. "
                        "Consider clarity, feasibility, and alignment with the problem requirements.",
            contexts=approaches
        )

        refined_approach = await self.revise(
            instruction="Critically review the selected approach. Identify any gaps, ambiguities, or errors. "
                        "Refine the solution to ensure it is complete, accurate, and well-reasoned.",
            context=best_approach
        )

        # Step 4: Execution and Verification
        solution_steps = await self.generate(
            instruction=f"Execute the refined approach step-by-step. Verify each intermediate result for correctness. "
                        f"Ensure the final solution satisfies all problem constraints. Refined approach: {refined_approach}",
            context=self.problem_text
        )

        # Step 5: Summarization
        final_solution = await self.summarize(
            instruction="Condense the solution into a clear and concise format. Include the final answer and any key insights.",
            context=solution_steps
        )

        return final_solution