# Workflow ID: high_level_math_ganluo_419_0
# Benchmark: high_level_math_ganluo
# Data Indices: [782, 0]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all numerical values, variables, constraints, and relationships "
            "from the problem statement. Organize them into categories such as constants, "
            "variables, inequalities, equations, and conditions."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        approach_1_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using an algebraic approach. "
            "Include step-by-step reasoning, intermediate calculations, and clearly state the final answer."
        )
        approach_2_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using a combinatorial or geometric approach. "
            "Include step-by-step reasoning, intermediate calculations, and clearly state the final answer."
        )

        results = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text)
        )
        solution_1, solution_2 = results

        # Step 3: Verify and refine the generated solutions
        verification_instruction = (
            "Verify the correctness of the provided solution by checking it against the original problem constraints. "
            "If any issues are found, revise the solution to ensure it satisfies all conditions."
        )
        refined_solution_1 = await self.revise(instruction=verification_instruction, context=solution_1)
        refined_solution_2 = await self.revise(instruction=verification_instruction, context=solution_2)

        # Step 4: Use Ensemble to decide the best solution or synthesize insights
        ensemble_instruction = (
            "Evaluate the two refined solutions. Select the best one based on correctness, clarity, "
            "and adherence to the problem constraints. If both are valid, synthesize insights from both."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=[refined_solution_1, refined_solution_2])

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Summarize the final solution in a concise and well-structured format. Ensure it includes "
            "the final answer and a brief explanation of how it was derived."
        )
        summarized_solution = await self.summarize(instruction=summary_instruction, context=final_solution)

        return summarized_solution