# Workflow ID: high_level_math_ganluo_32_0
# Benchmark: high_level_math_ganluo
# Data Indices: [281, 619]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Understand and decompose the problem
        decomposition = await self.generate(
            instruction="Extract all key information from the problem, including variables, constants, constraints, and relationships. Organize this information clearly.",
            context=self.problem_text
        )

        # Step 2: Generate multiple solution approaches in parallel
        algebraic_solution = self.generate(
            instruction=f"Attempt an algebraic solution using the following extracted information: {decomposition}. Focus on equations, inequalities, and functional relationships.",
            context=self.problem_text
        )
        geometric_solution = self.generate(
            instruction=f"Attempt a geometric solution using the following extracted information: {decomposition}. Focus on coordinate geometry, synthetic geometry, and trigonometric relationships.",
            context=self.problem_text
        )
        combinatorial_solution = self.generate(
            instruction=f"Attempt a combinatorial or probabilistic solution using the following extracted information: {decomposition}. Focus on counting techniques, recursive structures, and expected values.",
            context=self.problem_text
        )
        number_theory_solution = self.generate(
            instruction=f"Attempt a number theory solution using the following extracted information: {decomposition}. Focus on divisibility, modular arithmetic, and prime factorization.",
            context=self.problem_text
        )

        # Execute all approaches in parallel
        approaches = await asyncio.gather(algebraic_solution, geometric_solution, combinatorial_solution, number_theory_solution)

        # Step 3: Evaluate and synthesize the best approach
        best_approach = await self.ensemble(
            instruction="Compare the provided solution approaches and select the most robust, efficient, and mathematically sound one. Consider all constraints and verify completeness.",
            contexts=approaches
        )

        # Step 4: Refine the selected solution
        refined_solution = await self.revise(
            instruction="Critically review and refine the selected solution. Ensure all steps are logically sound, constraints are satisfied, and calculations are accurate.",
            context=best_approach
        )

        # Step 5: Summarize the final solution
        final_solution = await self.summarize(
            instruction="Condense the refined solution into a concise and clear format. Include only the essential steps and the final answer.",
            context=refined_solution
        )

        return final_solution