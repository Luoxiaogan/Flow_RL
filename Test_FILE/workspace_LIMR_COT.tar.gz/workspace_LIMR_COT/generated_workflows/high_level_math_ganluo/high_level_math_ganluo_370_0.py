# Workflow ID: high_level_math_ganluo_370_0
# Benchmark: high_level_math_ganluo
# Data Indices: [6, 548]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all numerical values, variables, constraints, and the question being asked. "
            "Identify the mathematical domain (e.g., algebra, geometry, combinatorics) and any advanced techniques required."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution strategies in parallel
        algebra_strategy = self.generate(
            instruction=f"Using algebraic methods, solve the problem based on the following information: {extracted_info}",
            context=self.problem_text
        )
        geometry_strategy = self.generate(
            instruction=f"Using geometric reasoning, solve the problem based on the following information: {extracted_info}",
            context=self.problem_text
        )
        combinatorics_strategy = self.generate(
            instruction=f"Using combinatorial analysis, solve the problem based on the following information: {extracted_info}",
            context=self.problem_text
        )

        # Execute strategies in parallel
        strategies = await asyncio.gather(algebra_strategy, geometry_strategy, combinatorics_strategy)

        # Step 3: Select the best solution using Ensemble
        ensemble_instruction = (
            "Evaluate the following candidate solutions. Select the most mathematically rigorous, "
            "computationally efficient, and constraint-satisfying solution. Provide reasoning for your choice."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=strategies)

        # Step 4: Refine the selected solution
        refinement_instruction = (
            "Critique and improve the following solution. Ensure it is mathematically correct, "
            "clearly explained, and adheres to all problem constraints."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the final answer
        summary_instruction = (
            "Condense the following solution into a concise, polished answer. Highlight the key steps and the final result."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer