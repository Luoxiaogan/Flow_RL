# Workflow ID: high_level_math_ganluo_93_0
# Benchmark: high_level_math_ganluo
# Data Indices: [935, 213]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Problem Understanding and Decomposition
        problem_understanding = await self.generate(
            instruction="Extract and analyze all key components of the problem, including variables, constraints, and relationships. "
                        "Identify the type of problem (e.g., algebraic, geometric, combinatorial) and highlight any special conditions or symmetries. "
                        "Provide a structured breakdown of the problem.",
            context=self.problem_text
        )

        # Step 2: Generate Multiple Solution Paths
        algebraic_solution = self.generate(
            instruction=f"Using algebraic methods, solve the problem step by step. "
                        f"Refer to the following problem understanding: {problem_understanding}. "
                        f"Ensure all constraints are satisfied and calculations are rigorous.",
            context=self.problem_text
        )
        geometric_solution = self.generate(
            instruction=f"Using geometric reasoning or coordinate geometry, solve the problem step by step. "
                        f"Refer to the following problem understanding: {problem_understanding}. "
                        f"Visualize the problem if necessary and justify all steps.",
            context=self.problem_text
        )
        combinatorial_solution = self.generate(
            instruction=f"Using combinatorial or probabilistic methods, solve the problem step by step. "
                        f"Refer to the following problem understanding: {problem_understanding}. "
                        f"Count possibilities systematically and verify consistency.",
            context=self.problem_text
        )

        # Execute the three solution paths in parallel
        solutions = await asyncio.gather(algebraic_solution, geometric_solution, combinatorial_solution)

        # Step 3: Evaluate and Select the Best Path
        best_solution = await self.ensemble(
            instruction="Compare the provided solutions and select the most rigorous, complete, and correct one. "
                        "Consider whether the solution satisfies all problem constraints and aligns with the problem understanding. "
                        "If multiple solutions are valid, synthesize them into a single coherent answer.",
            contexts=solutions
        )

        # Step 4: Refinement and Final Answer Extraction
        refined_solution = await self.revise(
            instruction="Critique and refine the selected solution. "
                        "Address any gaps, inconsistencies, or ambiguities. "
                        "Ensure the reasoning is clear, concise, and mathematically sound.",
            context=best_solution
        )

        final_answer = await self.summarize(
            instruction="Extract the final answer from the refined solution. "
                        "Ensure it is presented clearly and concisely. "
                        "Verify that the answer satisfies all problem constraints and makes mathematical sense.",
            context=refined_solution
        )

        return final_answer