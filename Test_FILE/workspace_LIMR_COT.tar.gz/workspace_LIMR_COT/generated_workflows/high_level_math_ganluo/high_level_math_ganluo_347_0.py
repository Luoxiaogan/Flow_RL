# Workflow ID: high_level_math_ganluo_347_0
# Benchmark: high_level_math_ganluo
# Data Indices: [977, 546]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Problem Understanding and Decomposition
        extraction_instruction = (
            "Extract all key information from the problem, including variables, constraints, "
            "and the goal. Identify any numerical values, relationships, or conditions explicitly stated."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Approach Generation
        algebraic_instruction = (
            f"Given the extracted information: {extracted_info}\n"
            "Develop an algebraic approach to solve the problem. Include equations, variables, "
            "and any necessary transformations."
        )
        geometric_instruction = (
            f"Given the extracted information: {extracted_info}\n"
            "Develop a geometric approach to solve the problem. Consider visual representations, "
            "coordinate systems, and spatial relationships."
        )
        combinatorial_instruction = (
            f"Given the extracted information: {extracted_info}\n"
            "Develop a combinatorial approach to solve the problem. Focus on counting principles, "
            "arrangements, and probabilistic methods if applicable."
        )

        approaches = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Solution Refinement
        refine_instructions = [
            f"Critique and improve the following approach:\n{approach}\n"
            "Ensure it adheres to all constraints and logical consistency."
            for approach in approaches
        ]
        refined_approaches = await asyncio.gather(
            *[self.revise(instruction=instr, context=approach) 
              for instr, approach in zip(refine_instructions, approaches)]
        )

        # Step 4: Evaluation and Selection
        ensemble_instruction = (
            "Compare the following approaches and select the most promising one. "
            "Consider correctness, simplicity, and adherence to constraints. "
            "If possible, synthesize elements from multiple approaches."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_approaches)

        # Step 5: Final Answer Extraction
        summarize_instruction = (
            "Condense the following solution into a concise answer format. "
            "Focus on delivering the requested output clearly and accurately."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=final_solution)

        return final_answer