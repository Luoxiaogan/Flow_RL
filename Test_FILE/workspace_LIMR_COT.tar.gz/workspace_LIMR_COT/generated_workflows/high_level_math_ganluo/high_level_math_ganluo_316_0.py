# Workflow ID: high_level_math_ganluo_316_0
# Benchmark: high_level_math_ganluo
# Data Indices: [374, 151]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract and Understand the Problem
        problem_breakdown = await self.generate(
            instruction="Extract all key information, constraints, and the goal from the problem. "
                        "Organize this information into categories such as known values, unknowns, "
                        "relationships, and any special conditions. Provide a clear breakdown.",
            context=self.problem_text
        )

        # Step 2: Generate Multiple Solution Strategies
        algebraic_solution = self.generate(
            instruction=f"Using the following breakdown: {problem_breakdown}, "
                        "develop an algebraic solution to the problem. Include step-by-step reasoning, "
                        "equations, and intermediate results.",
            context=self.problem_text
        )
        geometric_solution = self.generate(
            instruction=f"Using the following breakdown: {problem_breakdown}, "
                        "develop a geometric solution to the problem. Include diagrams (if applicable), "
                        "key geometric principles, and step-by-step reasoning.",
            context=self.problem_text
        )
        combinatorial_solution = self.generate(
            instruction=f"Using the following breakdown: {problem_breakdown}, "
                        "develop a combinatorial or probabilistic solution to the problem. "
                        "Include counting principles, recursive formulas, or expected value calculations.",
            context=self.problem_text
        )

        # Execute solution generation in parallel
        solutions = await asyncio.gather(algebraic_solution, geometric_solution, combinatorial_solution)

        # Step 3: Refine and Validate Solutions
        refined_solutions = await asyncio.gather(
            self.revise(
                instruction="Critique and refine the following solution. Ensure it adheres to all "
                            "constraints, is mathematically rigorous, and addresses edge cases. "
                            "Provide a revised version.",
                context=solutions[0]
            ),
            self.revise(
                instruction="Critique and refine the following solution. Ensure it adheres to all "
                            "constraints, is mathematically rigorous, and addresses edge cases. "
                            "Provide a revised version.",
                context=solutions[1]
            ),
            self.revise(
                instruction="Critique and refine the following solution. Ensure it adheres to all "
                            "constraints, is mathematically rigorous, and addresses edge cases. "
                            "Provide a revised version.",
                context=solutions[2]
            )
        )

        # Step 4: Select the Best Solution
        best_solution = await self.ensemble(
            instruction="Evaluate the following solutions and select the best one. "
                        "Consider clarity, correctness, efficiency, and adherence to the problem's constraints. "
                        "Provide a justification for your choice.",
            contexts=refined_solutions
        )

        # Step 5: Summarize the Final Answer
        final_answer = await self.summarize(
            instruction="Condense the selected solution into a concise and clear final answer. "
                        "Ensure it directly addresses the problem's goal and includes the final result.",
            context=best_solution
        )

        return final_answer