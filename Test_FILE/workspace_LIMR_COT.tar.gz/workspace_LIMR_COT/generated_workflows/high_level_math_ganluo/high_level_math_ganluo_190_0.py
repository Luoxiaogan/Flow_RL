# Workflow ID: high_level_math_ganluo_190_0
# Benchmark: high_level_math_ganluo
# Data Indices: [223, 634]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information and understand the problem
        extraction_instruction = (
            "Extract all numerical values, variables, constraints, and mathematical domains "
            "(e.g., algebra, geometry, combinatorics) from the problem. "
            "Identify what the question is asking for and any special conditions."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution strategies
        strategy_instruction = (
            f"Based on the extracted information: {extracted_info}, "
            "generate at least three distinct solution strategies. "
            "Consider different mathematical techniques and approaches, such as algebraic manipulation, "
            "geometric reasoning, combinatorial analysis, or number theory. "
            "Ensure each strategy is feasible and addresses all constraints."
        )
        strategies = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Execute strategies in parallel
        execution_instruction_template = (
            "Execute the following strategy step-by-step: {strategy}. "
            "Ensure all calculations are accurate and intermediate results are clearly stated. "
            "If the strategy involves assumptions or approximations, explicitly state them."
        )
        strategy_list = strategies.split("\n\n")  # Assume strategies are separated by double newlines
        execution_tasks = [
            self.generate(instruction=execution_instruction_template.format(strategy=strategy), context=self.problem_text)
            for strategy in strategy_list
        ]
        executed_results = await asyncio.gather(*execution_tasks)

        # Step 4: Refine intermediate results
        refinement_instruction_template = (
            "Critique and refine the following solution: {solution}. "
            "Check for calculation errors, logical inconsistencies, and adherence to problem constraints. "
            "Improve clarity and ensure all steps are mathematically rigorous."
        )
        refinement_tasks = [
            self.revise(instruction=refinement_instruction_template.format(solution=result), context=self.problem_text)
            for result in executed_results
        ]
        refined_results = await asyncio.gather(*refinement_tasks)

        # Step 5: Select the best solution using Ensemble
        ensemble_instruction = (
            "Evaluate the following candidate solutions and select the best one. "
            "Ensure the chosen solution satisfies all problem constraints, is mathematically sound, "
            "and is presented in a clear and concise manner."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_results)

        # Step 6: Summarize the final solution
        summary_instruction = (
            "Condense the following solution into a concise, verifiable format. "
            "Include only the essential steps and the final answer. Ensure clarity and correctness."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=best_solution)

        return final_summary