# Workflow ID: high_level_math_ganluo_429_0
# Benchmark: high_level_math_ganluo
# Data Indices: [699, 788]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all key information from the problem, including variables, constraints, "
            "known values, and the goal. Organize this information clearly."
        )
        key_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        approach_instruction = (
            f"Based on the extracted key information: {key_info}, propose multiple solution approaches. "
            "Consider different mathematical domains (e.g., algebra, geometry, combinatorics) and "
            "outline the steps for each approach."
        )
        approaches = await self.generate(instruction=approach_instruction, context=self.problem_text)

        # Step 3: Execute approaches in parallel
        approach_list = approaches.split("\n\n")  # Split into individual approaches
        tasks = [
            self.generate(
                instruction=f"Follow these steps to solve the problem: {approach}",
                context=self.problem_text
            )
            for approach in approach_list
        ]
        results = await asyncio.gather(*tasks)

        # Step 4: Validate and refine solutions
        refine_instruction = (
            "Validate the solution to ensure it satisfies all constraints and is mathematically sound. "
            "Refine the solution if necessary, providing clear reasoning for any changes."
        )
        refined_results = [
            await self.revise(instruction=refine_instruction, context=result)
            for result in results
        ]

        # Step 5: Ensemble decision-making
        ensemble_instruction = (
            "Compare the refined solutions and select the best one. If multiple solutions are valid, "
            "choose the most elegant and efficient one. Provide justification for your choice."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_results)

        # Step 6: Prepare the final output
        summarize_instruction = (
            "Condense the final solution into a clear and concise format. Ensure it is easy to interpret "
            "and meets the problem's requirements."
        )
        final_output = await self.summarize(instruction=summarize_instruction, context=final_solution)

        return final_output