# Workflow ID: high_level_math_ganluo_379_0
# Benchmark: high_level_math_ganluo
# Data Indices: [116, 654]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Carefully analyze the problem statement and extract all key information, including variables, "
            "constraints, and the specific question being asked. Organize the information clearly for further use."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Propose multiple solution strategies
        strategy_instruction = (
            f"Based on the following extracted information: {extracted_info}\n"
            "Propose multiple solution strategies. Consider different mathematical domains (e.g., algebra, geometry, combinatorics) "
            "and advanced techniques (e.g., casework, symmetry, modular arithmetic). Rank the strategies by their likelihood of success."
        )
        strategies = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Explore strategies in parallel
        strategy_list = strategies.split("\n")  # Assume strategies are separated by newlines
        parallel_tasks = [
            self.generate(
                instruction=f"Using the following strategy: {strategy}\n"
                            "Solve the problem step by step. Ensure all constraints are satisfied.",
                context=self.problem_text
            )
            for strategy in strategy_list
        ]
        solutions = await asyncio.gather(*parallel_tasks)

        # Step 4: Evaluate and synthesize solutions
        ensemble_instruction = (
            "Evaluate the following candidate solutions. Select the most robust and efficient solution, "
            "or synthesize insights from multiple solutions if necessary. Ensure the final solution satisfies all problem constraints."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=solutions)

        # Step 5: Refine and verify the solution
        refinement_instruction = (
            "Critique and refine the following solution. Verify its correctness, ensure all constraints are satisfied, "
            "and simplify the solution if possible."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=final_solution)

        # Step 6: Prepare the final output
        summary_instruction = (
            "Condense the following solution into a clear and concise format. Ensure it is ready for submission."
        )
        final_output = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_output