# Workflow ID: high_level_math_ganluo_413_0
# Benchmark: high_level_math_ganluo
# Data Indices: [188, 53]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key components of the problem
        extraction_instruction = (
            "Carefully analyze the problem statement and extract all key components, "
            "including variables, equations, constraints, and the goal. Organize this "
            "information in a structured format to facilitate further reasoning."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        generate_instructions = [
            f"Using algebraic methods, solve the problem based on the following extracted information: {extracted_info}. "
            "Provide a step-by-step solution.",

            f"Using geometric reasoning, interpret the problem and provide a solution based on the following extracted information: {extracted_info}. "
            "Include diagrams if necessary and explain each step clearly.",

            f"Using combinatorial or probabilistic techniques, analyze the problem and provide a solution based on the following extracted information: {extracted_info}. "
            "Ensure all cases are considered and calculations are accurate."
        ]
        candidate_solutions = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in generate_instructions]
        )

        # Step 3: Refine each solution
        refine_instruction_template = (
            "Critique and improve the following solution. Ensure it is logically consistent, "
            "mathematically rigorous, and adheres to the problem's constraints. Provide detailed feedback "
            "and suggest corrections where necessary."
        )
        refined_solutions = await asyncio.gather(
            *[self.revise(instruction=refine_instruction_template, context=sol) for sol in candidate_solutions]
        )

        # Step 4: Select the best solution using Ensemble
        ensemble_instruction = (
            "Evaluate the following solutions and select the most mathematically sound, efficient, and elegant one. "
            "Ensure the chosen solution satisfies all constraints and provides a complete answer to the problem."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_solutions)

        # Step 5: Summarize the final solution
        summarize_instruction = (
            "Condense the following solution into a concise, well-structured format that directly answers the problem. "
            "Include only the essential steps and the final result."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=best_solution)

        return final_answer