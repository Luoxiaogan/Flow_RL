# Workflow ID: high_level_math_ganluo_392_0
# Benchmark: high_level_math_ganluo
# Data Indices: [165, 683]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = """
        Extract all numerical values, variables, and constraints from the problem. 
        Identify the mathematical domain (e.g., algebra, geometry, combinatorics) and any specific techniques required (e.g., modular arithmetic, symmetry exploitation).
        Format the output as follows:
        - Numerical Values: [list]
        - Variables: [list]
        - Constraints: [list]
        - Domain: [description]
        - Techniques: [list]
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan the solution based on extracted information
        planning_instruction = f"""
        Based on the following extracted information:
        {extracted_info}
        Plan a solution strategy. Identify multiple possible approaches (e.g., algebraic manipulation, geometric reasoning, combinatorial analysis) and describe each approach in detail.
        Output the planned approaches as a list of descriptions.
        """
        planned_approaches = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Execute multiple approaches in parallel
        approaches = planned_approaches.split("\n")  # Assuming each approach is on a new line
        tasks = []
        for approach in approaches:
            task_instruction = f"""
            Solve the problem using the following approach:
            {approach}
            Ensure the solution satisfies all constraints and is presented in a clear, step-by-step manner.
            """
            tasks.append(self.generate(instruction=task_instruction, context=self.problem_text))
        results = await asyncio.gather(*tasks)

        # Step 4: Evaluate and select the best solution
        ensemble_instruction = """
        Compare the following candidate solutions and select the most robust and correct one. 
        If multiple solutions are valid, synthesize them into a single, comprehensive solution.
        Ensure the final solution satisfies all constraints and is mathematically sound.
        """
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 5: Refine and summarize the final solution
        refinement_instruction = """
        Critique and refine the following solution for clarity, correctness, and completeness. 
        Ensure all steps are logically sound and the final answer is clearly presented.
        """
        refined_solution = await self.revise(instruction=refinement_instruction, context=final_solution)

        summary_instruction = """
        Summarize the following solution into a concise, well-structured final answer. 
        Include only the essential steps and present the final result in the required format.
        """
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer