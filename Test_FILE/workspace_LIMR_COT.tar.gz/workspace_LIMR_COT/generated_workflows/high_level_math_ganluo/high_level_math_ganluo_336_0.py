# Workflow ID: high_level_math_ganluo_336_0
# Benchmark: high_level_math_ganluo
# Data Indices: [692, 13]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract and Understand the Problem
        extraction_instruction = (
            "Extract all key mathematical entities, relationships, and constraints from the problem. "
            "Identify potential solution approaches (e.g., algebraic, geometric, combinatorial). "
            "Provide a clear breakdown of the problem structure."
        )
        problem_analysis = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Explore Multiple Solution Paths in Parallel
        algebraic_instruction = (
            f"Using the following analysis: {problem_analysis}, "
            "solve the problem using algebraic techniques. Include step-by-step reasoning and verify each step."
        )
        geometric_instruction = (
            f"Using the following analysis: {problem_analysis}, "
            "solve the problem using geometric reasoning. Include diagrams if necessary and verify each step."
        )
        combinatorial_instruction = (
            f"Using the following analysis: {problem_analysis}, "
            "solve the problem using combinatorial methods. Consider casework, recursion, or generating functions if applicable."
        )

        algebraic_solution, geometric_solution, combinatorial_solution = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and Synthesize Solutions
        evaluation_instruction = (
            "Compare the following solutions and select the most complete, correct, and efficient one. "
            "If multiple solutions are valid, synthesize them into a unified answer. "
            "Ensure the final solution satisfies all constraints and conditions."
        )
        final_solution = await self.ensemble(
            instruction=evaluation_instruction,
            contexts=[algebraic_solution, geometric_solution, combinatorial_solution]
        )

        # Step 4: Refine the Final Solution
        refinement_instruction = (
            "Refine the following solution to improve clarity, correctness, and conciseness. "
            "Verify that all steps are mathematically sound and address any ambiguities."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=final_solution)

        # Step 5: Summarize the Final Answer
        summary_instruction = (
            "Summarize the solution in a concise and structured format. "
            "Include the final answer and key reasoning steps."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer