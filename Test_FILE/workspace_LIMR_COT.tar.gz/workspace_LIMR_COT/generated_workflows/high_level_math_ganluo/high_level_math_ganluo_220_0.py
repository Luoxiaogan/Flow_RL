# Workflow ID: high_level_math_ganluo_220_0
# Benchmark: high_level_math_ganluo
# Data Indices: [179, 979]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extract_instruction = (
            "Carefully analyze the problem statement and extract all relevant information, "
            "including variables, constants, constraints, and relationships. "
            "Organize this information in a structured format."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        generate_algebra_instruction = (
            f"Based on the extracted information: {extracted_info}, "
            "develop an algebraic solution approach. Consider all equations, expressions, "
            "and relationships provided in the problem. Solve step by step."
        )
        generate_combinatorics_instruction = (
            f"Based on the extracted information: {extracted_info}, "
            "develop a combinatorial or probabilistic solution approach. "
            "Consider counting principles, permutations, combinations, and probability rules."
        )
        generate_geometry_instruction = (
            f"Based on the extracted information: {extracted_info}, "
            "develop a geometric solution approach. Consider coordinate geometry, "
            "synthetic geometry, and trigonometric relationships."
        )

        # Parallel execution for multiple approaches
        algebra_solution, combinatorics_solution, geometry_solution = await asyncio.gather(
            self.generate(instruction=generate_algebra_instruction, context=self.problem_text),
            self.generate(instruction=generate_combinatorics_instruction, context=self.problem_text),
            self.generate(instruction=generate_geometry_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and select the best solution
        ensemble_instruction = (
            "Compare the following solution approaches and select the most appropriate one. "
            "Consider clarity, correctness, and computational feasibility. "
            "If multiple approaches are valid, choose the simplest and most elegant solution."
        )
        best_solution = await self.ensemble(
            instruction=ensemble_instruction,
            contexts=[algebra_solution, combinatorics_solution, geometry_solution]
        )

        # Step 4: Refine the selected solution if necessary
        refine_instruction = (
            "Review the selected solution for any errors, ambiguities, or areas for improvement. "
            "Ensure all steps are logically sound and the final answer satisfies all constraints."
        )
        refined_solution = await self.revise(instruction=refine_instruction, context=best_solution)

        # Step 5: Summarize the final solution
        summarize_instruction = (
            "Condense the solution into a concise and clear format. "
            "Include only the essential steps and the final answer."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_answer