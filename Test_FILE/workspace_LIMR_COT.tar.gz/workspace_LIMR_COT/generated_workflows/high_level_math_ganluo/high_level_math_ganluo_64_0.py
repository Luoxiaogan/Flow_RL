# Workflow ID: high_level_math_ganluo_64_0
# Benchmark: high_level_math_ganluo
# Data Indices: [40, 642]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Initial Analysis - Extract key information and understand the problem
        initial_analysis = await self.generate(
            instruction="Analyze the problem thoroughly. Identify all variables, constants, and constraints. "
                        "Determine the mathematical domain(s) involved (e.g., algebra, geometry, combinatorics). "
                        "Provide a structured breakdown of the problem.",
            context=self.problem_text
        )

        # Step 2: Generate Multiple Solution Approaches in Parallel
        results = await asyncio.gather(
            self.generate(
                instruction=f"Based on the following analysis: {initial_analysis} "
                            "Solve the problem using an algebraic approach. Include step-by-step reasoning.",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"Based on the following analysis: {initial_analysis} "
                            "Solve the problem using a geometric approach. Include step-by-step reasoning.",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"Based on the following analysis: {initial_analysis} "
                            "Solve the problem using a combinatorial or probabilistic approach. Include step-by-step reasoning.",
                context=self.problem_text
            )
        )

        # Step 3: Evaluate and Select the Best Approach
        best_solution = await self.ensemble(
            instruction="Compare the following solutions. Select the one that is most correct, logically consistent, "
                        "and computationally feasible. Provide justification for your choice.",
            contexts=results
        )

        # Step 4: Refine the Selected Solution
        refined_solution = await self.revise(
            instruction="Critique and refine the following solution. Ensure it is clear, correct, and complete. "
                        "Verify that it satisfies all constraints and requirements.",
            context=best_solution
        )

        # Step 5: Summarize the Final Solution
        final_solution = await self.summarize(
            instruction="Condense the following solution into a concise, well-structured format. "
                        "Include only the essential steps and the final answer.",
            context=refined_solution
        )

        return final_solution