# Workflow ID: high_level_math_ganluo_215_0
# Benchmark: high_level_math_ganluo
# Data Indices: [648, 177]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Problem Analysis
        analysis_instruction = (
            "Extract all key information from the problem, including numerical values, variables, constraints, "
            "and relationships. Identify the mathematical domain (e.g., geometry, algebra, combinatorics) and "
            "required techniques (e.g., recursion, symmetry, modular arithmetic)."
        )
        analysis = await self.generate(instruction=analysis_instruction, context=self.problem_text)

        # Step 2: Approach Generation (Parallel Execution)
        approach_instructions = [
            f"Develop an algebraic approach to solve the problem using the following analysis: {analysis}",
            f"Develop a geometric approach to solve the problem using the following analysis: {analysis}",
            f"Develop a combinatorial or probabilistic approach to solve the problem using the following analysis: {analysis}"
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Solution Refinement
        refinement_tasks = []
        for approach in approaches:
            refinement_instruction = (
                f"Critique and refine the following solution approach to ensure mathematical rigor and correctness: {approach}. "
                "Address edge cases, hidden constraints, and computational complexity."
            )
            refinement_tasks.append(self.revise(instruction=refinement_instruction, context=approach))
        refined_approaches = await asyncio.gather(*refinement_tasks)

        # Step 4: Ensemble Decision
        ensemble_instruction = (
            "Compare and synthesize the following refined approaches to select the most efficient and robust solution. "
            "Consider clarity, simplicity, and adherence to problem constraints."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_approaches)

        # Step 5: Final Answer Extraction
        summary_instruction = (
            "Condense the final solution into a concise answer format, ensuring all constraints are satisfied. "
            "Provide the answer in a boxed format if applicable."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=final_solution)

        return final_answer