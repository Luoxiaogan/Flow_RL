# Workflow ID: high_level_math_ganluo_241_0
# Benchmark: high_level_math_ganluo
# Data Indices: [891, 909]

```python
class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract critical information from the problem text
        extraction_instruction = (
            "Carefully analyze the problem statement and extract all critical information. "
            "This includes numerical values, variables, constraints, relationships, and the specific question being asked. "
            "Organize the extracted information clearly and categorize it (e.g., known values, unknowns, conditions)."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a solution strategy
        strategy_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Devise a detailed solution strategy. Identify applicable mathematical techniques (e.g., modular arithmetic, geometry, algebra) "
            "and outline a step-by-step plan to solve the problem. Consider multiple approaches if possible."
        )
        solution_strategy = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Explore multiple solution paths in parallel
        parallel_instructions = [
            (
                f"Follow this approach to solve the problem:\n{solution_strategy}\n"
                "Ensure all steps are clearly explained and justified. Verify intermediate results as you proceed."
            ),
            (
                f"Explore an alternative approach to solve the problem:\n{solution_strategy}\n"
                "Ensure all steps are clearly explained and justified. Verify intermediate results as you proceed."
            )
        ]
        parallel_results = await asyncio.gather(
            self.generate(instruction=parallel_instructions[0], context=self.problem_text),
            self.generate(instruction=parallel_instructions[1], context=self.problem_text)
        )

        # Step 4: Evaluate and select the best solution
        ensemble_instruction = (
            "Evaluate the following candidate solutions and select the best one:\n"
            f"Candidate Solution 1:\n{parallel_results[0]}\n\n"
            f"Candidate Solution 2:\n{parallel_results[1]}\n\n"
            "Criteria for selection include correctness, simplicity, and adherence to all problem constraints."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=parallel_results)

        # Step 5: Refine and verify the final solution
        refinement_instruction = (
            f"Refine the following solution to ensure clarity, correctness, and completeness:\n{best_solution}\n"
            "Verify that the solution satisfies all constraints and answers the original question."
        )
        final_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        return final_solution
```