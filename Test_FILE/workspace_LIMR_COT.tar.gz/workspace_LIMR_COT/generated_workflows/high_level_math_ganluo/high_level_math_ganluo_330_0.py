# Workflow ID: high_level_math_ganluo_330_0
# Benchmark: high_level_math_ganluo
# Data Indices: [75, 9]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Problem Decomposition
        decomposition_instruction = (
            "Analyze the given problem and extract its core components, "
            "such as variables, inequalities, equations, and constraints. "
            "Identify the type of mathematical reasoning required (e.g., algebraic, geometric, combinatorial)."
        )
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Solution Exploration (Parallel Execution)
        algebraic_instruction = (
            f"Using the extracted components: {decomposition}, "
            "solve the problem algebraically. Consider all constraints and provide a step-by-step solution."
        )
        graphical_instruction = (
            f"Using the extracted components: {decomposition}, "
            "analyze the problem graphically. Identify key points, regions, or behaviors that satisfy the constraints."
        )
        combinatorial_instruction = (
            f"Using the extracted components: {decomposition}, "
            "apply combinatorial reasoning if applicable. Count possibilities or use recursive structures as needed."
        )

        solutions = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=graphical_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Refinement and Validation
        refinement_instruction = (
            "Critique and refine the provided solution. Ensure all constraints are satisfied, "
            "and consider edge cases or special scenarios."
        )
        refined_solutions = [
            await self.revise(instruction=refinement_instruction, context=solution)
            for solution in solutions
        ]

        # Step 4: Final Synthesis
        synthesis_instruction = (
            "Compare the refined solutions and select the best one based on correctness, clarity, "
            "and completeness. Provide a final answer in the required format."
        )
        final_solution = await self.ensemble(instruction=synthesis_instruction, contexts=refined_solutions)

        return final_solution