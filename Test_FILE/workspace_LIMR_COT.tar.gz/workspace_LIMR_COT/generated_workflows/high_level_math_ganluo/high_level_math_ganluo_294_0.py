# Workflow ID: high_level_math_ganluo_294_0
# Benchmark: high_level_math_ganluo
# Data Indices: [20, 659]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key components of the problem
        extraction = await self.generate(
            instruction="Extract all critical components of the problem, including variables, equations, constraints, and the goal. Identify any mathematical structures (e.g., polynomials, inequalities) and relationships between variables.",
            context=self.problem_text
        )

        # Step 2: Generate multiple solution approaches in parallel
        algebraic_approach = self.generate(
            instruction=f"Using the extracted components: {extraction}, solve the problem algebraically. Focus on factoring, substitution, or simplifying expressions.",
            context=self.problem_text
        )
        geometric_approach = self.generate(
            instruction=f"Using the extracted components: {extraction}, interpret the problem geometrically if applicable. Consider coordinate geometry, synthetic geometry, or trigonometric relationships.",
            context=self.problem_text
        )
        combinatorial_approach = self.generate(
            instruction=f"Using the extracted components: {extraction}, explore combinatorial or recursive reasoning. Count arrangements, calculate probabilities, or derive recursive formulas.",
            context=self.problem_text
        )
        approaches = await asyncio.gather(algebraic_approach, geometric_approach, combinatorial_approach)

        # Step 3: Refine each approach
        refined_approaches = await asyncio.gather(
            self.revise(
                instruction="Critique and refine this algebraic solution. Check calculations, verify constraints, and ensure logical consistency.",
                context=approaches[0]
            ),
            self.revise(
                instruction="Critique and refine this geometric solution. Validate geometric interpretations, check edge cases, and ensure alignment with the problem's requirements.",
                context=approaches[1]
            ),
            self.revise(
                instruction="Critique and refine this combinatorial solution. Verify counts, check recursive logic, and ensure all constraints are satisfied.",
                context=approaches[2]
            )
        )

        # Step 4: Synthesize and select the best solution
        final_solution = await self.ensemble(
            instruction="Compare and synthesize these refined solutions. Select the most robust, efficient, and elegant approach. Combine insights from multiple solutions if necessary.",
            contexts=refined_approaches
        )

        # Step 5: Summarize the final solution
        summary = await self.summarize(
            instruction="Condense the final solution into a concise, well-structured format. Include all critical details while ensuring clarity and readability.",
            context=final_solution
        )

        return summary