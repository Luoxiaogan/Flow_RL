# Workflow ID: high_level_math_ganluo_28_0
# Benchmark: high_level_math_ganluo
# Data Indices: [803, 588]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all numerical values, variables, constraints, and relationships "
            "from the problem statement. Categorize them into knowns, unknowns, and conditions."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution paths in parallel
        algebraic_instruction = (
            f"Given the extracted information: {extracted_info}\n"
            "Solve the problem using algebraic methods. Include step-by-step reasoning."
        )
        geometric_instruction = (
            f"Given the extracted information: {extracted_info}\n"
            "Solve the problem using geometric reasoning. Include step-by-step reasoning."
        )
        combinatorial_instruction = (
            f"Given the extracted information: {extracted_info}\n"
            "Solve the problem using combinatorial techniques. Include step-by-step reasoning."
        )

        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )
        algebraic_solution, geometric_solution, combinatorial_solution = results

        # Step 3: Refine each solution path
        refine_instruction_template = (
            "Critique and refine the following solution:\n{solution}\n"
            "Ensure it is mathematically correct, clear, and adheres to the problem's constraints."
        )
        refined_algebraic = await self.revise(instruction=refine_instruction_template.format(solution=algebraic_solution), context=algebraic_solution)
        refined_geometric = await self.revise(instruction=refine_instruction_template.format(solution=geometric_solution), context=geometric_solution)
        refined_combinatorial = await self.revise(instruction=refine_instruction_template.format(solution=combinatorial_solution), context=combinatorial_solution)

        # Step 4: Compare and synthesize solutions
        ensemble_instruction = (
            "Evaluate the following refined solutions:\n"
            f"1. Algebraic: {refined_algebraic}\n"
            f"2. Geometric: {refined_geometric}\n"
            f"3. Combinatorial: {refined_combinatorial}\n"
            "Select the most appropriate solution or synthesize them into a unified answer. "
            "Verify that the chosen solution satisfies all constraints and consider edge cases."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=[refined_algebraic, refined_geometric, refined_combinatorial])

        # Step 5: Summarize and verify the final solution
        summarize_instruction = (
            "Condense the following solution into a concise summary:\n{solution}\n"
            "Ensure all key insights and reasoning steps are preserved."
        )
        summary = await self.summarize(instruction=summarize_instruction.format(solution=final_solution), context=final_solution)

        return summary