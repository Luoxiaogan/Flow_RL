# Workflow ID: high_level_math_ganluo_174_0
# Benchmark: high_level_math_ganluo
# Data Indices: [530, 335]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem text
        extracted_info = await self.generate(
            instruction="Extract all key information from the problem, including variables, constraints, and the objective. "
                        "Identify the mathematical domain (e.g., algebra, geometry, combinatorics) and any special techniques required. "
                        "Organize the information into structured categories for further processing.",
            context=self.problem_text
        )

        # Step 2: Explore multiple solution approaches in parallel
        algebraic_solution = self.generate(
            instruction=f"Using the extracted information: {extracted_info}, solve the problem using algebraic methods. "
                        "Focus on equations, inequalities, and symbolic manipulation. "
                        "Provide a detailed step-by-step solution.",
            context=self.problem_text
        )
        geometric_solution = self.generate(
            instruction=f"Using the extracted information: {extracted_info}, solve the problem using geometric methods. "
                        "Focus on visual interpretations, coordinate geometry, and spatial reasoning. "
                        "Provide a detailed step-by-step solution.",
            context=self.problem_text
        )
        combinatorial_solution = self.generate(
            instruction=f"Using the extracted information: {extracted_info}, solve the problem using combinatorial methods. "
                        "Focus on counting principles, recursive structures, and probabilistic reasoning. "
                        "Provide a detailed step-by-step solution.",
            context=self.problem_text
        )

        # Execute the parallel tasks
        solutions = await asyncio.gather(algebraic_solution, geometric_solution, combinatorial_solution)

        # Step 3: Evaluate and synthesize the results
        best_solution = await self.ensemble(
            instruction="Evaluate the provided solutions based on correctness, completeness, and mathematical rigor. "
                        "Select the most promising solution or synthesize insights from multiple approaches if necessary. "
                        "Ensure the final solution satisfies all constraints and objectives.",
            contexts=solutions
        )

        # Step 4: Refine the selected solution
        refined_solution = await self.revise(
            instruction="Critique and refine the selected solution to ensure it is mathematically rigorous and satisfies all constraints. "
                        "Check for computational errors, logical gaps, and edge cases. "
                        "Improve clarity and presentation.",
            context=best_solution
        )

        # Step 5: Summarize the final solution
        final_solution = await self.summarize(
            instruction="Condense the refined solution into a concise, well-structured format. "
                        "Include only the essential steps and the final answer. "
                        "Ensure the summary is clear and easy to understand.",
            context=refined_solution
        )

        return final_solution