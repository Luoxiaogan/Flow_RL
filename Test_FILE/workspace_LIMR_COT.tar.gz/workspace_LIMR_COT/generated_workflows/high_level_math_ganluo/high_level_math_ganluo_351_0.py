# Workflow ID: high_level_math_ganluo_351_0
# Benchmark: high_level_math_ganluo
# Data Indices: [78, 712]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key components from the problem
        extract_instruction = (
            "Carefully analyze the problem statement and extract all key components, "
            "including variables, constraints, objectives, and any special conditions. "
            "Organize the information in a structured format for further processing."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        approach_1_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Develop a solution using an algebraic or analytical approach. "
            "Ensure all steps are clearly explained and justified. "
            "Address all constraints and verify intermediate results."
        )
        approach_2_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Develop a solution using a combinatorial, geometric, or symmetry-based approach. "
            "Provide detailed reasoning and ensure the solution satisfies all problem conditions."
        )
        approach_1, approach_2 = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text)
        )

        # Step 3: Refine the generated solutions
        refine_instruction_1 = (
            "Critically review the following solution and improve it for clarity, correctness, and completeness. "
            "Ensure all constraints are satisfied, simplify expressions where possible, and verify edge cases."
        )
        refine_instruction_2 = (
            "Critically review the following solution and enhance its presentation and rigor. "
            "Check for logical consistency, address any missing details, and ensure the solution is fully justified."
        )
        refined_1, refined_2 = await asyncio.gather(
            self.revise(instruction=refine_instruction_1, context=approach_1),
            self.revise(instruction=refine_instruction_2, context=approach_2)
        )

        # Step 4: Compare and select the best solution
        ensemble_instruction = (
            "Evaluate the following two solutions and determine which one is superior. "
            "Consider factors such as correctness, elegance, clarity, and adherence to the problem's requirements. "
            "If neither solution is satisfactory, suggest improvements or synthesize a better approach."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=[refined_1, refined_2])

        # Step 5: Summarize the final solution
        summarize_instruction = (
            "Condense the following solution into a concise, well-structured format. "
            "Include only the essential steps and the final answer, ensuring clarity and correctness."
        )
        summarized_solution = await self.summarize(instruction=summarize_instruction, context=final_solution)

        return summarized_solution