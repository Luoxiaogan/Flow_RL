# Workflow ID: high_level_math_ganluo_77_0
# Benchmark: high_level_math_ganluo
# Data Indices: [925, 326]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information and structure the problem
        extraction = await self.generate(
            instruction="Analyze the problem statement carefully. "
                       "Extract all variables, equations, constraints, and relationships explicitly mentioned. "
                       "Identify any implicit mathematical structures or patterns (e.g., modular arithmetic, recursion). "
                       "Organize the information in a structured format suitable for further reasoning.",
            context=self.problem_text
        )

        # Step 2: Explore multiple solution approaches in parallel
        algebraic_approach = self.generate(
            instruction=f"Using the extracted information: {extraction}, "
                        "develop an algebraic solution path. Focus on solving equations, inequalities, "
                        "or functional relationships. Provide step-by-step reasoning and intermediate results.",
            context=self.problem_text
        )
        combinatorial_approach = self.generate(
            instruction=f"Using the extracted information: {extraction}, "
                        "develop a combinatorial solution path. Consider counting principles, recursive formulas, "
                        "or probabilistic methods. Provide step-by-step reasoning and intermediate results.",
            context=self.problem_text
        )
        geometric_approach = self.generate(
            instruction=f"Using the extracted information: {extraction}, "
                        "develop a geometric solution path. Consider coordinate geometry, synthetic geometry, "
                        "or trigonometric relationships. Provide step-by-step reasoning and intermediate results.",
            context=self.problem_text
        )

        # Execute the three approaches in parallel
        results = await asyncio.gather(algebraic_approach, combinatorial_approach, geometric_approach)

        # Step 3: Evaluate and select the best approach
        best_approach = await self.ensemble(
            instruction="Compare the following solution approaches and select the most promising one. "
                        "Consider clarity, correctness, computational feasibility, and alignment with the problem's requirements. "
                        "If multiple approaches are equally valid, synthesize them into a unified solution.",
            contexts=results
        )

        # Step 4: Develop the detailed solution
        detailed_solution = await self.generate(
            instruction=f"Based on the selected approach: {best_approach}, "
                        "develop a complete, step-by-step solution. Ensure all constraints are satisfied, "
                        "intermediate results are verified, and the final answer is clearly stated.",
            context=self.problem_text
        )

        # Step 5: Revise and finalize the solution
        final_solution = await self.revise(
            instruction="Critique and improve the following solution. "
                        "Ensure it is mathematically correct, logically sound, and addresses all parts of the problem. "
                        "Highlight any assumptions or edge cases considered.",
            context=detailed_solution
        )

        return final_solution