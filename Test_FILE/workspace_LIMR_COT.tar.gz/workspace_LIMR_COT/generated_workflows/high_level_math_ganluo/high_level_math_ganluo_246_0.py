# Workflow ID: high_level_math_ganluo_246_0
# Benchmark: high_level_math_ganluo
# Data Indices: [236, 417]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio
        
        # Step 1: Extract key information and decompose the problem
        decomposition_instruction = (
            "Analyze the problem statement thoroughly. Identify all given values, constraints, "
            "and the specific question being asked. Break down the problem into smaller, "
            "manageable sub-problems. Highlight any relationships or patterns that can guide "
            "the solution process."
        )
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)
        
        # Step 2: Generate multiple solution approaches
        approach_instructions = [
            f"Using algebraic methods, solve the problem based on the following decomposition: {decomposition}",
            f"Using geometric reasoning, solve the problem based on the following decomposition: {decomposition}",
            f"Using combinatorial analysis, solve the problem based on the following decomposition: {decomposition}"
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )
        
        # Step 3: Evaluate and synthesize the best solution
        ensemble_instruction = (
            "Compare the following candidate solutions and select the most appropriate one. "
            "Consider factors such as correctness, simplicity, and adherence to the problem constraints. "
            "If multiple solutions are valid, choose the one that is easiest to verify and explain."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=approaches)
        
        # Step 4: Refine the selected solution if necessary
        refinement_instruction = (
            "Review the selected solution for accuracy and completeness. Ensure that it satisfies "
            "all problem constraints and provides a clear path to the final answer. Make any necessary "
            "corrections or improvements."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)
        
        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the solution into a concise summary. Include the final answer and a brief "
            "explanation of how it was derived. Ensure that the summary is easy to understand and "
            "verifies that all problem requirements are met."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_solution)
        
        return final_summary