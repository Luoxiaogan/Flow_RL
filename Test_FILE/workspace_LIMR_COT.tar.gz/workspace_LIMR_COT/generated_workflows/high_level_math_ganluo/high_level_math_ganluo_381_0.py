# Workflow ID: high_level_math_ganluo_381_0
# Benchmark: high_level_math_ganluo
# Data Indices: [591, 278]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Understand and decompose the problem
        problem_summary_instruction = (
            "Identify and summarize the key components of the problem, including variables, constraints, "
            "and the mathematical domain. Ensure all critical information is captured clearly."
        )
        problem_summary = await self.generate(instruction=problem_summary_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        approach_1_instruction = (
            f"Based on the problem summary: {problem_summary}, develop an algebraic approach to solve the problem. "
            "Include step-by-step reasoning and calculations."
        )
        approach_2_instruction = (
            f"Based on the problem summary: {problem_summary}, develop a geometric or visual approach to solve the problem. "
            "Include diagrams or visual reasoning if applicable."
        )
        approach_3_instruction = (
            f"Based on the problem summary: {problem_summary}, explore a combinatorial or number-theoretic approach. "
            "Focus on patterns, symmetries, or modular arithmetic if relevant."
        )

        approaches = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text),
            self.generate(instruction=approach_3_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and select the best approach
        selection_instruction = (
            "Compare the following solution approaches and select the one that is most correct, efficient, "
            "and adheres to the problem constraints. Provide a rationale for your choice."
        )
        best_approach = await self.ensemble(instruction=selection_instruction, contexts=approaches)

        # Step 4: Refine the selected approach
        refinement_instruction = (
            f"Improve the clarity, correctness, and completeness of the following solution: {best_approach}. "
            "Ensure all steps are logically sound and fully explained."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_approach)

        # Step 5: Extract the final answer
        final_answer_instruction = (
            f"From the refined solution: {refined_solution}, extract the final numerical or symbolic answer. "
            "Ensure it is boxed and clearly presented."
        )
        final_answer = await self.generate(instruction=final_answer_instruction, context=refined_solution)

        return final_answer