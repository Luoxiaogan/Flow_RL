# Workflow ID: high_level_math_ganluo_8_0
# Benchmark: high_level_math_ganluo
# Data Indices: [538, 392]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Problem Decomposition
        decomposition_instruction = (
            "Analyze the problem to identify its domain (e.g., algebra, geometry, combinatorics), "
            "key variables, constraints, and what is being asked. Provide a structured breakdown."
        )
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Generate Multiple Solution Approaches
        generate_algebra_instruction = (
            f"Based on the problem decomposition: {decomposition}, "
            "solve the problem using algebraic techniques such as equations, inequalities, or sequences."
        )
        generate_geometry_instruction = (
            f"Based on the problem decomposition: {decomposition}, "
            "solve the problem using geometric reasoning, including coordinate geometry or trigonometry."
        )
        generate_combinatorics_instruction = (
            f"Based on the problem decomposition: {decomposition}, "
            "solve the problem using combinatorial methods such as counting principles or probability."
        )

        algebra_solution, geometry_solution, combinatorics_solution = await asyncio.gather(
            self.generate(instruction=generate_algebra_instruction, context=self.problem_text),
            self.generate(instruction=generate_geometry_instruction, context=self.problem_text),
            self.generate(instruction=generate_combinatorics_instruction, context=self.problem_text)
        )

        # Step 3: Refine and Validate Solutions
        refine_algebra_instruction = (
            "Critique and improve the algebraic solution. Ensure it satisfies all constraints, "
            "is mathematically rigorous, and provides a complete explanation."
        )
        refine_geometry_instruction = (
            "Critique and improve the geometric solution. Ensure it satisfies all constraints, "
            "is mathematically rigorous, and provides a complete explanation."
        )
        refine_combinatorics_instruction = (
            "Critique and improve the combinatorial solution. Ensure it satisfies all constraints, "
            "is mathematically rigorous, and provides a complete explanation."
        )

        refined_algebra, refined_geometry, refined_combinatorics = await asyncio.gather(
            self.revise(instruction=refine_algebra_instruction, context=algebra_solution),
            self.revise(instruction=refine_geometry_instruction, context=geometry_solution),
            self.revise(instruction=refine_combinatorics_instruction, context=combinatorics_solution)
        )

        # Step 4: Ensemble for Final Decision
        ensemble_instruction = (
            "Compare the refined algebraic, geometric, and combinatorial solutions. "
            "Select the most robust, elegant, and computationally feasible solution. "
            "If multiple solutions are valid, synthesize them into a unified answer."
        )
        final_solution = await self.ensemble(
            instruction=ensemble_instruction,
            contexts=[refined_algebra, refined_geometry, refined_combinatorics]
        )

        # Step 5: Summarize the Final Answer
        summarize_instruction = (
            "Condense the final solution into a concise, clear format. "
            "Include only the essential steps and the final answer."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=final_solution)

        return final_answer