# Workflow ID: high_level_math_ganluo_104_0
# Benchmark: high_level_math_ganluo
# Data Indices: [502, 874]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all key information from the problem, including variables, constants, "
            "constraints, and the specific question being asked. Format the output as a structured list."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        approach_1_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using an algebraic approach. "
            "Include detailed reasoning and calculations."
        )
        approach_2_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using a geometric approach. "
            "Include detailed reasoning and calculations."
        )
        approach_3_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using a combinatorial approach. "
            "Include detailed reasoning and calculations."
        )

        results = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text),
            self.generate(instruction=approach_3_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and select the best solution
        ensemble_instruction = (
            "Compare the following candidate solutions and select the most promising one. "
            "If possible, synthesize a hybrid solution that combines the strengths of multiple approaches."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 4: Refine the chosen solution
        refine_instruction = (
            "Critique and improve the following solution. Ensure it addresses all constraints, "
            "is mathematically rigorous, and is presented in a clear and concise manner."
        )
        refined_solution = await self.revise(instruction=refine_instruction, context=best_solution)

        # Step 5: Summarize the final answer
        summarize_instruction = (
            "Condense the following solution into a concise, well-structured response. "
            "Ensure the answer is in the required format and satisfies all problem constraints."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_answer