# Workflow ID: high_level_math_ganluo_425_0
# Benchmark: high_level_math_ganluo
# Data Indices: [957, 212]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio
        
        # Step 1: Problem Understanding and Decomposition
        understanding_instruction = (
            "Thoroughly analyze the problem statement. Identify and extract all numerical values, "
            "variables, constraints, and the specific question being asked. Organize this information "
            "into a structured format that clearly outlines the problem's components."
        )
        problem_understanding = await self.generate(instruction=understanding_instruction, context=self.problem_text)
        
        # Step 2: Strategy Formulation
        strategy_instruction_template = (
            f"Given the extracted problem components: {problem_understanding}, formulate a detailed "
            "solution strategy. Consider multiple approaches, including algebraic, geometric, combinatorial, "
            "and number-theoretic methods. Clearly outline the steps required for each approach."
        )
        strategies = await asyncio.gather(
            self.generate(instruction=strategy_instruction_template + " Focus on an algebraic approach.", context=self.problem_text),
            self.generate(instruction=strategy_instruction_template + " Focus on a geometric approach.", context=self.problem_text),
            self.generate(instruction=strategy_instruction_template + " Focus on a combinatorial approach.", context=self.problem_text)
        )
        
        # Step 3: Execution and Verification
        execution_instruction_template = (
            "Execute the following strategy step-by-step: {strategy}. Ensure all calculations are accurate "
            "and verify that the solution satisfies all constraints and conditions from the problem statement."
        )
        refined_solutions = await asyncio.gather(
            *[self.revise(instruction=execution_instruction_template.format(strategy=strategy), context=strategy) for strategy in strategies]
        )
        
        # Step 4: Synthesis and Final Selection
        ensemble_instruction = (
            "Compare the following candidate solutions and select the most robust and accurate one. "
            "Ensure the chosen solution fully addresses the problem and resolves any conflicts between approaches."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_solutions)
        
        # Step 5: Output Simplification
        summary_instruction = (
            "Condense the following solution into a clear and concise final answer. Include only the essential "
            "steps and results while maintaining mathematical rigor."
        )
        final_output = await self.summarize(instruction=summary_instruction, context=final_solution)
        
        return final_output