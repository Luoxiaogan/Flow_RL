# Workflow ID: high_level_math_ganluo_450_0
# Benchmark: high_level_math_ganluo
# Data Indices: [35, 244]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key components of the problem
        extraction_instruction = (
            "Extract all key components from the problem, including equations, variables, "
            "constraints, and what is being asked. Organize this information clearly."
        )
        problem_structure = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution paths in parallel
        algebra_instruction = (
            f"Using algebraic methods, solve the problem based on the extracted components: {problem_structure}. "
            "Show all steps and ensure the solution satisfies all constraints."
        )
        geometry_instruction = (
            f"Using geometric reasoning, solve the problem based on the extracted components: {problem_structure}. "
            "Provide a clear explanation of the approach and verify the solution."
        )
        combinatorics_instruction = (
            f"Using combinatorial or probabilistic methods, solve the problem based on the extracted components: {problem_structure}. "
            "Ensure the solution accounts for all possible cases."
        )

        # Execute parallel generation of candidate solutions
        candidates = await asyncio.gather(
            self.generate(instruction=algebra_instruction, context=self.problem_text),
            self.generate(instruction=geometry_instruction, context=self.problem_text),
            self.generate(instruction=combinatorics_instruction, context=self.problem_text)
        )

        # Step 3: Validate and refine each candidate solution
        refinement_instruction = (
            "Critique the provided solution to ensure it satisfies all problem constraints. "
            "Refine the solution if necessary, providing detailed reasoning for any changes."
        )
        refined_solutions = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction, context=candidate) for candidate in candidates]
        )

        # Step 4: Synthesize the best solution using Ensemble
        synthesis_instruction = (
            "Compare the provided solutions, evaluate their correctness and completeness, "
            "and select the best one. If multiple solutions are valid, combine them into a single answer."
        )
        final_solution = await self.ensemble(instruction=synthesis_instruction, contexts=refined_solutions)

        # Step 5: Format the final solution for output
        formatting_instruction = (
            "Condense the solution into a concise and clear format suitable for submission. "
            "Ensure all required components (e.g., numerical answers, units) are included."
        )
        formatted_solution = await self.summarize(instruction=formatting_instruction, context=final_solution)

        return formatted_solution