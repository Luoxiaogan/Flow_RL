# Workflow ID: high_level_math_ganluo_45_0
# Benchmark: high_level_math_ganluo
# Data Indices: [242, 382]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract and Understand the Problem
        problem_analysis = await self.generate(
            instruction="Carefully analyze the problem statement. Identify the mathematical domain, key variables, constraints, and what is being asked. Provide a structured breakdown of the problem.",
            context=self.problem_text
        )

        # Step 2: Generate Multiple Solution Approaches
        approaches = await asyncio.gather(
            self.generate(
                instruction=f"Based on the problem analysis: {problem_analysis}, solve the problem using an algebraic approach. Focus on equations, formulas, and symbolic manipulation.",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"Based on the problem analysis: {problem_analysis}, solve the problem using a geometric approach. Use diagrams, coordinate geometry, or synthetic geometry techniques.",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"Based on the problem analysis: {problem_analysis}, solve the problem using a combinatorial or probabilistic approach. Consider counting principles, recursion, or expected value calculations.",
                context=self.problem_text
            )
        )

        # Step 3: Refine Each Approach
        refined_approaches = await asyncio.gather(
            *[self.revise(
                instruction=f"Critique and improve the following solution: {approach}. Ensure it satisfies all constraints and is mathematically rigorous.",
                context=approach
            ) for approach in approaches]
        )

        # Step 4: Summarize Each Refined Approach
        summarized_approaches = await asyncio.gather(
            *[self.summarize(
                instruction=f"Condense the following solution into a concise summary, highlighting the key steps and result: {refined_approach}",
                context=refined_approach
            ) for refined_approach in refined_approaches]
        )

        # Step 5: Select the Best Solution
        final_solution = await self.ensemble(
            instruction="Evaluate the following solutions based on correctness, elegance, and computational simplicity. Select the best one and provide justification for your choice.",
            contexts=summarized_approaches
        )

        return final_solution