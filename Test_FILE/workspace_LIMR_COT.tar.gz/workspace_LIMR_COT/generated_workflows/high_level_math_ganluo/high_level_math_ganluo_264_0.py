# Workflow ID: high_level_math_ganluo_264_0
# Benchmark: high_level_math_ganluo
# Data Indices: [902, 3]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract key information and decompose the problem
        problem_analysis = await self.generate(
            instruction="Analyze the problem thoroughly. Identify all variables, equations, constraints, and the goal. "
                        "Determine the mathematical domain (e.g., algebra, geometry, number theory) and suggest possible solution strategies. "
                        "Provide a structured breakdown of the problem.",
            context=self.problem_text
        )

        # Step 2: Explore multiple solution approaches in parallel
        algebraic_solution = self.generate(
            instruction=f"Using algebraic methods, solve the problem step by step. "
                        f"Focus on equations, inverses, and transformations. Problem analysis: {problem_analysis}",
            context=self.problem_text
        )
        geometric_solution = self.generate(
            instruction=f"Using geometric reasoning, analyze the problem. "
                        f"Look for symmetries, transformations, or coordinate-based solutions. Problem analysis: {problem_analysis}",
            context=self.problem_text
        )
        number_theory_solution = self.generate(
            instruction=f"Using number theory techniques, solve the problem. "
                        f"Consider divisibility, modular arithmetic, and prime factorization. Problem analysis: {problem_analysis}",
            context=self.problem_text
        )

        # Execute the parallel tasks
        results = await asyncio.gather(algebraic_solution, geometric_solution, number_theory_solution)

        # Step 3: Evaluate and select the best approach
        best_solution = await self.ensemble(
            instruction="Compare the provided solutions. Select the one that is most correct, complete, and aligned with the problem's constraints. "
                        "If none are satisfactory, indicate why and suggest improvements.",
            contexts=results
        )

        # Step 4: Refine and verify the selected solution
        refined_solution = await self.revise(
            instruction="Critique and improve the solution. Ensure it satisfies all constraints, is mathematically rigorous, and is presented clearly. "
                        "If there are errors or ambiguities, correct them.",
            context=best_solution
        )

        # Step 5: Summarize the final solution (optional)
        final_solution = await self.summarize(
            instruction="Condense the solution into a concise, well-structured format. "
                        "Include only the essential steps and the final answer.",
            context=refined_solution
        )

        return final_solution