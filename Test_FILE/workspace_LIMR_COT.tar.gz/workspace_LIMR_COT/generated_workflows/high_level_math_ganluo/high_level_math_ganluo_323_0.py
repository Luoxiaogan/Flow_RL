# Workflow ID: high_level_math_ganluo_323_0
# Benchmark: high_level_math_ganluo
# Data Indices: [314, 598]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Problem Understanding and Categorization
        extraction_instruction = (
            "Extract all numerical values, constraints, and mathematical domains "
            "(e.g., combinatorics, geometry, number theory) from the problem. "
            "Categorize the problem based on these features."
        )
        problem_analysis = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Initial Solution Exploration
        algebraic_instruction = (
            f"Using algebraic methods, solve the problem based on the following analysis: {problem_analysis}. "
            "Include all necessary steps and verify intermediate results."
        )
        geometric_instruction = (
            f"Using geometric methods, solve the problem based on the following analysis: {problem_analysis}. "
            "Include all necessary steps and verify intermediate results."
        )
        combinatorial_instruction = (
            f"Using combinatorial methods, solve the problem based on the following analysis: {problem_analysis}. "
            "Include all necessary steps and verify intermediate results."
        )

        # Parallel execution of multiple solution paths
        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Solution Refinement
        refinement_instruction = (
            "Critique and refine the provided solution. Ensure all constraints are satisfied, "
            "simplify expressions where possible, and verify mathematical correctness."
        )
        refined_solutions = [
            await self.revise(instruction=refinement_instruction, context=solution)
            for solution in results
        ]

        # Step 4: Ensemble Decision
        ensemble_instruction = (
            "Compare the following solutions and select the most elegant, efficient, "
            "and mathematically sound one. Provide justification for your choice."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_solutions)

        # Step 5: Final Answer Extraction
        summarization_instruction = (
            "Extract the final answer from the provided solution. Ensure the answer is in the required format, "
            "such as simplest radical form or a simplified fraction."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=final_solution)

        return final_answer