# Workflow ID: high_level_math_ganluo_225_0
# Benchmark: high_level_math_ganluo
# Data Indices: [327, 487]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all key information from the problem, including numerical values, variables, "
            "constraints, relationships, and any specific requirements. Organize this information "
            "in a structured format for further analysis."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        approach_1_instruction = (
            f"Using the following extracted information: {extracted_info}\n"
            "Solve the problem using an algebraic approach. Include step-by-step reasoning, "
            "intermediate calculations, and ensure all constraints are satisfied."
        )
        approach_2_instruction = (
            f"Using the following extracted information: {extracted_info}\n"
            "Solve the problem using a geometric or visual reasoning approach. Include diagrams, "
            "relationships between elements, and ensure all constraints are satisfied."
        )
        approach_3_instruction = (
            f"Using the following extracted information: {extracted_info}\n"
            "Solve the problem using a combinatorial or probabilistic approach. Include counting principles, "
            "cases, and ensure all constraints are satisfied."
        )

        results = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text),
            self.generate(instruction=approach_3_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and select the best solution path
        ensemble_instruction = (
            "Compare the following candidate solutions and select the best one based on clarity, "
            "correctness, and alignment with the problem's requirements. Provide a justification "
            "for your selection."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 4: Refine the selected solution
        refinement_instruction = (
            "Critique and refine the following solution to ensure it satisfies all constraints, "
            "is mathematically rigorous, and is presented in a clear and logical manner."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the following solution into a concise, clear format that highlights the key steps, "
            "final answer, and any important insights."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_summary