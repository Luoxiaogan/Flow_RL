# Workflow ID: high_level_math_ganluo_436_0
# Benchmark: high_level_math_ganluo
# Data Indices: [590, 727]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information and problem type
        extraction_instruction = (
            "Extract all key numerical values, constraints, and relationships from the problem. "
            "Identify the mathematical domain (e.g., combinatorics, number theory, algebra, geometry) "
            "and describe potential solution strategies."
        )
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Explore multiple solution paths in parallel
        algebraic_instruction = (
            f"Based on the extracted information: {extraction}, "
            "solve the problem using algebraic methods. Include detailed steps and reasoning."
        )
        combinatorial_instruction = (
            f"Based on the extracted information: {extraction}, "
            "solve the problem using combinatorial reasoning. Include detailed steps and reasoning."
        )
        geometric_instruction = (
            f"Based on the extracted information: {extraction}, "
            "solve the problem using geometric or coordinate-based methods. Include detailed steps and reasoning."
        )

        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text)
        )

        # Step 3: Refine each solution path
        refinement_instructions = [
            "Critique and refine the solution. Check for logical consistency, computational accuracy, and adherence to constraints.",
            "Critique and refine the solution. Verify edge cases and ensure all problem conditions are satisfied.",
            "Critique and refine the solution. Ensure geometric reasoning is rigorous and calculations are correct."
        ]
        refined_results = await asyncio.gather(
            self.revise(instruction=refinement_instructions[0], context=results[0]),
            self.revise(instruction=refinement_instructions[1], context=results[1]),
            self.revise(instruction=refinement_instructions[2], context=results[2])
        )

        # Step 4: Synthesize results using ensemble
        ensemble_instruction = (
            "Compare the refined solutions. Select the most robust, elegant, and mathematically sound solution. "
            "If multiple solutions are valid, combine insights to produce a final answer."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_results)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the final solution into a concise, verifiable format. "
            "Include the key steps, reasoning, and final answer."
        )
        summary = await self.summarize(instruction=summary_instruction, context=final_solution)

        return summary