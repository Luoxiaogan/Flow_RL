# Workflow ID: high_level_math_ganluo_455_0
# Benchmark: high_level_math_ganluo
# Data Indices: [366, 409]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Understand the problem and extract key components
        problem_understanding = await self.generate(
            instruction="Analyze the problem thoroughly. Identify the type of problem (e.g., geometry, algebra, combinatorics), extract all numerical values, constraints, and relationships, and determine what is being asked. Provide a structured summary.",
            context=self.problem_text
        )

        # Step 2: Generate multiple candidate solutions in parallel
        candidates = await asyncio.gather(
            self.generate(
                instruction=f"Based on the problem understanding: {problem_understanding}, solve the problem using an algebraic approach. Show all steps and reasoning.",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"Based on the problem understanding: {problem_understanding}, solve the problem using a geometric approach. Show all steps and reasoning.",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"Based on the problem understanding: {problem_understanding}, solve the problem using a combinatorial or probabilistic approach. Show all steps and reasoning.",
                context=self.problem_text
            )
        )

        # Step 3: Refine each candidate solution
        refined_solutions = await asyncio.gather(
            *[self.revise(
                instruction="Critique this solution. Ensure mathematical rigor, address edge cases, and verify that all constraints are satisfied. Improve clarity and correctness.",
                context=candidate
            ) for candidate in candidates]
        )

        # Step 4: Summarize each refined solution
        summarized_solutions = await asyncio.gather(
            *[self.summarize(
                instruction="Condense this solution into its essential components while preserving clarity and correctness.",
                context=solution
            ) for solution in refined_solutions]
        )

        # Step 5: Select the best solution using Ensemble
        final_solution = await self.ensemble(
            instruction="Evaluate these solutions. Select the most elegant, accurate, and efficient solution based on clarity, correctness, and simplicity. Provide the final answer.",
            contexts=summarized_solutions
        )

        return final_solution