# Workflow ID: high_level_math_ganluo_380_0
# Benchmark: high_level_math_ganluo
# Data Indices: [930, 559]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key components and categorize the problem domain
        extraction_instruction = """
        Analyze the problem to identify its key components:
        - Variables and constants involved
        - Constraints and conditions
        - Objective or goal
        Categorize the problem into one or more mathematical domains (e.g., combinatorics, number theory, algebra).
        """
        problem_analysis = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        approach_instructions = [
            f"""
            Solve the problem using combinatorial reasoning. Consider counting techniques, casework analysis, and recursive structures.
            Problem analysis: {problem_analysis}
            """,
            f"""
            Solve the problem using number theory. Focus on divisibility, modular arithmetic, and properties of integers.
            Problem analysis: {problem_analysis}
            """,
            f"""
            Solve the problem using algebraic methods. Explore polynomial equations, sequences, and inequalities.
            Problem analysis: {problem_analysis}
            """
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Refine each approach for correctness and completeness
        refinement_instruction = """
        Critique and improve the given solution approach. Ensure it:
        - Satisfies all constraints and conditions
        - Is mathematically rigorous
        - Handles edge cases and special scenarios
        """
        refined_approaches = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction, context=approach) for approach in approaches]
        )

        # Step 4: Select the best approach using ensemble
        ensemble_instruction = """
        Compare the provided solution approaches and select the best one based on:
        - Clarity and logical structure
        - Correctness and adherence to problem constraints
        - Efficiency and elegance
        If multiple approaches are valid, synthesize them into a single solution.
        """
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_approaches)

        # Step 5: Summarize the final solution
        summary_instruction = """
        Condense the solution into a clear and concise format. Ensure it:
        - Directly addresses the problem objective
        - Includes all necessary steps and reasoning
        - Is easy to follow and understand
        """
        summarized_solution = await self.summarize(instruction=summary_instruction, context=final_solution)

        return summarized_solution