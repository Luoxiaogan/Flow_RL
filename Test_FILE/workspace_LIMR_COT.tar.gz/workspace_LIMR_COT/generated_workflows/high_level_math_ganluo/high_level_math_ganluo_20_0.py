# Workflow ID: high_level_math_ganluo_20_0
# Benchmark: high_level_math_ganluo
# Data Indices: [855, 164]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information and decompose the problem
        decomposition_instruction = (
            "Carefully analyze the problem statement to identify all key components, including numerical values, "
            "constraints, variables, and relationships. Provide a detailed breakdown of what is being asked, "
            "any given conditions, and potential solution strategies."
        )
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Generate multiple candidate solutions in parallel
        algebraic_instruction = (
            f"Based on the following problem breakdown:\n{decomposition}\n"
            "Solve the problem using algebraic techniques. Focus on equations, inequalities, and symbolic manipulation. "
            "Ensure all steps are clearly explained and justified."
        )
        geometric_instruction = (
            f"Based on the following problem breakdown:\n{decomposition}\n"
            "Solve the problem using geometric reasoning. Consider visual representations, coordinate geometry, "
            "and spatial relationships. Ensure all steps are clearly explained and justified."
        )
        combinatorial_instruction = (
            f"Based on the following problem breakdown:\n{decomposition}\n"
            "Solve the problem using combinatorial methods. Focus on counting principles, recursion, and symmetry. "
            "Ensure all steps are clearly explained and justified."
        )

        candidates = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=decomposition),
            self.generate(instruction=geometric_instruction, context=decomposition),
            self.generate(instruction=combinatorial_instruction, context=decomposition)
        )

        # Step 3: Evaluate and synthesize the best solution
        ensemble_instruction = (
            "Compare the following candidate solutions and select the most appropriate one. "
            "Consider correctness, clarity, elegance, and adherence to the problem constraints. "
            "Provide a justification for your choice."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=candidates)

        # Step 4: Refine the chosen solution for rigor and clarity
        refinement_instruction = (
            "Critically review the following solution and improve it for clarity, rigor, and correctness. "
            "Ensure all steps are logically sound and explicitly address the problem constraints."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the solution to extract the final answer
        summary_instruction = (
            "Condense the following solution into a concise summary that includes the final answer. "
            "Ensure the answer is clearly stated and formatted according to the problem requirements."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer