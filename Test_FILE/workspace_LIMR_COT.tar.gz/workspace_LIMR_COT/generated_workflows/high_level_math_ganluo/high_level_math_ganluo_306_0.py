# Workflow ID: high_level_math_ganluo_306_0
# Benchmark: high_level_math_ganluo
# Data Indices: [581, 18]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all numerical values, variables, and relationships from the problem. "
            "Identify the type of problem (e.g., algebra, geometry, combinatorics) and any specific constraints."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        generate_algebra_instruction = (
            f"Based on the extracted information: {extracted_info}, solve the problem using algebraic methods. "
            "Provide a step-by-step solution, clearly showing all calculations and reasoning."
        )
        generate_geometry_instruction = (
            f"Based on the extracted information: {extracted_info}, solve the problem using geometric reasoning. "
            "Include diagrams or visual representations if applicable."
        )
        generate_combinatorics_instruction = (
            f"Based on the extracted information: {extracted_info}, solve the problem using combinatorial analysis. "
            "Consider cases, permutations, or combinations as needed."
        )

        algebra_solution, geometry_solution, combinatorics_solution = await asyncio.gather(
            self.generate(instruction=generate_algebra_instruction, context=self.problem_text),
            self.generate(instruction=generate_geometry_instruction, context=self.problem_text),
            self.generate(instruction=generate_combinatorics_instruction, context=self.problem_text)
        )

        # Step 3: Refine and validate each solution
        refine_algebra_instruction = (
            "Critique and refine the algebraic solution. Ensure all steps are logically consistent, "
            "mathematically correct, and satisfy the problem's constraints."
        )
        refine_geometry_instruction = (
            "Critique and refine the geometric solution. Check for accuracy in calculations, "
            "validity of assumptions, and adherence to geometric principles."
        )
        refine_combinatorics_instruction = (
            "Critique and refine the combinatorial solution. Verify all cases are considered, "
            "and calculations are accurate."
        )

        refined_algebra = await self.revise(instruction=refine_algebra_instruction, context=algebra_solution)
        refined_geometry = await self.revise(instruction=refine_geometry_instruction, context=geometry_solution)
        refined_combinatorics = await self.revise(instruction=refine_combinatorics_instruction, context=combinatorics_solution)

        # Step 4: Select the best solution using ensemble
        ensemble_instruction = (
            "Compare the refined algebraic, geometric, and combinatorial solutions. "
            "Select the solution that is most correct, complete, and elegant. "
            "If multiple solutions are equally valid, choose the one with the clearest reasoning."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=[refined_algebra, refined_geometry, refined_combinatorics])

        # Step 5: Summarize the final answer
        summarize_instruction = (
            "Condense the selected solution into a concise and clear final answer. "
            "Ensure the answer directly addresses the problem's question."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=best_solution)

        return final_answer