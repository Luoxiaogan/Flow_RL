# Workflow ID: high_level_math_ganluo_208_0
# Benchmark: high_level_math_ganluo
# Data Indices: [901, 444]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract and Understand the Problem
        extraction_instruction = (
            "Carefully analyze the problem statement. Identify all key variables, constants, relationships, "
            "and constraints. Highlight any special conditions or requirements. Provide a structured summary."
        )
        problem_understanding = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate Multiple Solution Paths in Parallel
        algebraic_instruction = (
            f"Using algebraic reasoning, solve the problem step by step. Consider the following: {problem_understanding}. "
            "Ensure all steps are mathematically valid and aligned with the problem constraints."
        )
        geometric_instruction = (
            f"Using geometric reasoning, solve the problem step by step. Consider the following: {problem_understanding}. "
            "Ensure all steps are logically consistent and aligned with the problem constraints."
        )
        combinatorial_instruction = (
            f"Using combinatorial reasoning, solve the problem step by step. Consider the following: {problem_understanding}. "
            "Ensure all steps are systematic and aligned with the problem constraints."
        )

        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and Select the Best Solution
        ensemble_instruction = (
            "Compare the provided solutions. Evaluate each solution based on correctness, clarity, and adherence "
            "to the problem constraints. Select the most accurate and efficient solution."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 4: Revise and Refine the Selected Solution
        revise_instruction = (
            "Critique the selected solution. Check for logical consistency, computational accuracy, and alignment "
            "with the problem requirements. Suggest improvements if necessary."
        )
        refined_solution = await self.revise(instruction=revise_instruction, context=best_solution)

        # Step 5: Summarize the Final Answer
        summarize_instruction = (
            "Condense the refined solution into a concise and clear final answer. Ensure the answer directly "
            "addresses the problem question and includes all necessary details."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_answer