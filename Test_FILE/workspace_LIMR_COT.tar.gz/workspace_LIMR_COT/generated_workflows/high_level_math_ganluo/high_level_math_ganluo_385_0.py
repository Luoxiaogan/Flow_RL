# Workflow ID: high_level_math_ganluo_385_0
# Benchmark: high_level_math_ganluo
# Data Indices: [644, 946]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract and decompose the problem
        decomposition_instruction = (
            "Carefully analyze the problem statement and identify its key components. "
            "Determine the type of mathematical problem (e.g., combinatorics, number theory, geometry, algebra). "
            "List all given variables, constraints, and what is being asked. "
            "If possible, break the problem into smaller sub-problems."
        )
        problem_decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Explore multiple solution paths in parallel
        algebraic_instruction = (
            f"Based on the following problem decomposition:\n{problem_decomposition}\n"
            "Develop a solution using algebraic techniques. Include all steps and intermediate results. "
            "Ensure the solution is mathematically rigorous and satisfies all constraints."
        )
        combinatorial_instruction = (
            f"Based on the following problem decomposition:\n{problem_decomposition}\n"
            "Develop a solution using combinatorial or probabilistic techniques. Include all steps and intermediate results. "
            "Ensure the solution is mathematically rigorous and satisfies all constraints."
        )
        solutions = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Refine the solutions
        refinement_instruction = (
            "Critique the provided solution and suggest improvements. Check for computational accuracy, logical consistency, "
            "and adherence to all problem constraints. Provide a revised version of the solution."
        )
        refined_solutions = await asyncio.gather(
            self.revise(instruction=refinement_instruction, context=solutions[0]),
            self.revise(instruction=refinement_instruction, context=solutions[1])
        )

        # Step 4: Compare and select the best solution
        ensemble_instruction = (
            "Compare the following refined solutions and select the best one. "
            "Evaluate based on clarity, correctness, and efficiency. If possible, synthesize elements from both solutions."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_solutions)

        # Step 5: Summarize the final solution
        summarization_instruction = (
            "Condense the final solution into a clear and concise format. Ensure all key steps and results are included. "
            "The summary should be easy to follow and directly address the problem requirements."
        )
        summarized_solution = await self.summarize(instruction=summarization_instruction, context=final_solution)

        return summarized_solution