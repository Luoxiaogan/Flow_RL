# Workflow ID: high_level_math_ganluo_9_0
# Benchmark: high_level_math_ganluo
# Data Indices: [749, 28]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all key information from the problem, including variables, equations, constraints, "
            "and the type of mathematical techniques required. Organize the information in a structured format."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Explore multiple solution paths in parallel
        algebra_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using algebraic techniques. "
            "Include all steps and reasoning."
        )
        geometry_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using geometric reasoning. "
            "Include all steps and reasoning."
        )
        combinatorics_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using combinatorial analysis. "
            "Include all steps and reasoning."
        )

        results = await asyncio.gather(
            self.generate(instruction=algebra_instruction, context=self.problem_text),
            self.generate(instruction=geometry_instruction, context=self.problem_text),
            self.generate(instruction=combinatorics_instruction, context=self.problem_text)
        )

        # Step 3: Refine intermediate results
        refinement_instruction = (
            "Critique and improve the provided solution. Ensure all steps are correct, logical, and complete. "
            "Address any inconsistencies or missing details."
        )
        refined_results = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction, context=result) for result in results]
        )

        # Step 4: Synthesize the final solution
        ensemble_instruction = (
            "Compare the provided solutions and select the best one based on correctness, completeness, "
            "and clarity. If multiple solutions are valid, combine their insights into a single coherent answer."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_results)

        # Step 5: Final verification and summarization
        summary_instruction = (
            "Condense the final solution into a concise, verifiable form. Ensure it satisfies all constraints "
            "and is presented clearly."
        )
        verified_solution = await self.summarize(instruction=summary_instruction, context=final_solution)

        return verified_solution