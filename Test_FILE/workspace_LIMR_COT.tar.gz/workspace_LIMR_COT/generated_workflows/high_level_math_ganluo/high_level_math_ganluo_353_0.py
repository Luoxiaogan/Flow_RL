# Workflow ID: high_level_math_ganluo_353_0
# Benchmark: high_level_math_ganluo
# Data Indices: [254, 407]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Understand the problem and extract key information
        problem_analysis = await self.generate(
            instruction="Analyze the problem thoroughly. Identify all variables, constraints, and relationships. "
                        "Provide a structured breakdown of the problem, including any implicit assumptions or conditions.",
            context=self.problem_text
        )

        # Step 2: Generate multiple solution approaches in parallel
        algebraic_approach = self.generate(
            instruction=f"Based on the problem analysis: {problem_analysis}, "
                        "develop an algebraic solution. Focus on equations, inequalities, and functional relationships. "
                        "Ensure all steps are logically justified.",
            context=self.problem_text
        )
        geometric_approach = self.generate(
            instruction=f"Based on the problem analysis: {problem_analysis}, "
                        "develop a geometric solution. Use synthetic or coordinate geometry techniques. "
                        "Include diagrams or visual reasoning if applicable.",
            context=self.problem_text
        )
        combinatorial_approach = self.generate(
            instruction=f"Based on the problem analysis: {problem_analysis}, "
                        "develop a combinatorial or probabilistic solution. Consider counting principles, recursion, "
                        "or generating functions as needed.",
            context=self.problem_text
        )

        # Execute approaches in parallel
        approaches = await asyncio.gather(algebraic_approach, geometric_approach, combinatorial_approach)

        # Step 3: Refine each approach for correctness and completeness
        refined_approaches = await asyncio.gather(
            *[self.revise(
                instruction=f"Review and refine the following solution approach: {approach}. "
                            "Ensure all steps are mathematically valid, address all constraints, and lead to a correct solution.",
                context=self.problem_text
            ) for approach in approaches]
        )

        # Step 4: Compare and select the best solution
        best_solution = await self.ensemble(
            instruction="Compare the following refined solutions and select the most robust, efficient, and elegant one. "
                        "Consider clarity, correctness, and adherence to the problem's requirements.",
            contexts=refined_approaches
        )

        # Step 5: Summarize the final solution
        final_summary = await self.summarize(
            instruction=f"Condense the following solution into a concise, clear format: {best_solution}. "
                        "Highlight the key steps and final answer.",
            context=self.problem_text
        )

        return final_summary