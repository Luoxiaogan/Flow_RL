# Workflow ID: high_level_math_ganluo_231_0
# Benchmark: high_level_math_ganluo
# Data Indices: [807, 916]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key mathematical components
        extraction_instruction = (
            "Identify and extract all mathematical entities, relationships, and constraints from the problem. "
            "Include equations, variables, constants, and any special conditions. "
            "Format the output as a structured list for easy reference."
        )
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution strategies
        strategy_instruction = (
            f"Based on the extracted information: {extraction}, propose multiple solution strategies. "
            "Consider different mathematical techniques such as algebraic manipulation, geometric reasoning, "
            "combinatorial analysis, and number theory. Provide detailed reasoning for each strategy."
        )
        strategies = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Execute strategies in parallel
        strategy_list = strategies.split("\n\n")  # Split into individual strategies
        parallel_tasks = []
        for strategy in strategy_list:
            task_instruction = (
                f"Follow this strategy step-by-step: {strategy}. "
                "Ensure all calculations are precise and logical. "
                "Provide intermediate results and the final answer."
            )
            parallel_tasks.append(self.generate(instruction=task_instruction, context=self.problem_text))
        candidate_solutions = await asyncio.gather(*parallel_tasks)

        # Step 4: Refine and validate solutions
        refinement_tasks = []
        for solution in candidate_solutions:
            refine_instruction = (
                f"Critique and refine this solution: {solution}. "
                "Check for mathematical correctness, edge cases, and adherence to problem constraints. "
                "Improve clarity and precision where necessary."
            )
            refinement_tasks.append(self.revise(instruction=refine_instruction, context=solution))
        refined_solutions = await asyncio.gather(*refinement_tasks)

        # Step 5: Synthesize the best solution
        synthesis_instruction = (
            "Compare and synthesize the following solutions: "
            f"{refined_solutions}. "
            "Select the most accurate and elegant solution, or combine insights from multiple solutions. "
            "Ensure the final answer satisfies all problem conditions."
        )
        final_solution = await self.ensemble(instruction=synthesis_instruction, contexts=refined_solutions)

        return final_solution