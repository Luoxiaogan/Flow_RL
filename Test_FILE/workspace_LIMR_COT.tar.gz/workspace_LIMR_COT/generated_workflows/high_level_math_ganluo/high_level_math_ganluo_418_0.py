# Workflow ID: high_level_math_ganluo_418_0
# Benchmark: high_level_math_ganluo
# Data Indices: [518, 813]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information and understand the problem
        extraction_instruction = (
            "Extract all key variables, constraints, and the goal from the problem. "
            "Identify the mathematical domain(s) involved (e.g., combinatorics, geometry, algebra). "
            "Note any special techniques that might be required (e.g., modular arithmetic, symmetry)."
        )
        key_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution strategies in parallel
        algebraic_strategy = self.generate(
            instruction=f"Develop an algebraic solution strategy based on the following information: {key_info}.",
            context=self.problem_text
        )
        geometric_strategy = self.generate(
            instruction=f"Develop a geometric solution strategy based on the following information: {key_info}.",
            context=self.problem_text
        )
        combinatorial_strategy = self.generate(
            instruction=f"Develop a combinatorial or recursive solution strategy based on the following information: {key_info}.",
            context=self.problem_text
        )

        # Execute strategies in parallel
        strategies = await asyncio.gather(algebraic_strategy, geometric_strategy, combinatorial_strategy)

        # Step 3: Select the best strategy using Ensemble
        selection_instruction = (
            "Evaluate the following solution strategies and select the most promising one. "
            "Consider clarity, feasibility, and alignment with the problem's constraints."
        )
        best_strategy = await self.ensemble(instruction=selection_instruction, contexts=strategies)

        # Step 4: Develop a detailed solution using the selected strategy
        detailed_solution = await self.generate(
            instruction=f"Develop a detailed, step-by-step solution based on the following strategy: {best_strategy}.",
            context=self.problem_text
        )

        # Step 5: Revise the solution for correctness and clarity
        revision_instruction = (
            "Critique and refine the following solution. Ensure it is mathematically correct, "
            "addresses all constraints, and is expressed clearly. Simplify expressions where possible."
        )
        refined_solution = await self.revise(instruction=revision_instruction, context=detailed_solution)

        # Step 6: Summarize the final answer
        summary_instruction = (
            "Condense the following solution into a concise, final answer. "
            "Ensure the answer satisfies all problem constraints and is presented clearly."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer