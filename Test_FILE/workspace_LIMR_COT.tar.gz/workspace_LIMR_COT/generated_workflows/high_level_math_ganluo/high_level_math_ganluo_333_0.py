# Workflow ID: high_level_math_ganluo_333_0
# Benchmark: high_level_math_ganluo
# Data Indices: [849, 839]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Problem Understanding and Decomposition
        extraction_instruction = (
            "Carefully analyze the problem statement to identify its type (e.g., algebraic, geometric, combinatorial). "
            "Extract all numerical values, variables, and constraints. Highlight the goal of the problem. "
            "Provide a structured summary of the problem's key components."
        )
        problem_analysis = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Strategy Formulation
        strategy_instruction = (
            f"Based on the following analysis:\n{problem_analysis}\n"
            "Formulate multiple solution strategies. Consider techniques such as factoring, substitution, symmetry exploitation, "
            "coordinate geometry, or combinatorial reasoning. Provide detailed descriptions of each strategy."
        )
        strategies = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Parallel Execution of Strategies
        strategy_list = strategies.split("\n\n")  # Assuming strategies are separated by double newlines
        tasks = [
            self.generate(
                instruction=f"Execute the following strategy step by step:\n{strategy}",
                context=self.problem_text
            )
            for strategy in strategy_list
        ]
        candidate_solutions = await asyncio.gather(*tasks)

        # Step 4: Solution Evaluation and Selection
        ensemble_instruction = (
            "Evaluate the following candidate solutions based on correctness, elegance, and adherence to problem constraints. "
            "Select the best solution or synthesize a final answer if needed."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=candidate_solutions)

        # Step 5: Verification and Refinement
        refinement_instruction = (
            "Verify the selected solution against all constraints and conditions in the problem. "
            "Refine the solution if necessary to ensure it satisfies all requirements."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=final_solution)

        # Step 6: Summarization
        summarization_instruction = (
            "Summarize the final solution in a concise and clear manner. Ensure the answer directly addresses the problem's goal."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_solution)

        return final_answer