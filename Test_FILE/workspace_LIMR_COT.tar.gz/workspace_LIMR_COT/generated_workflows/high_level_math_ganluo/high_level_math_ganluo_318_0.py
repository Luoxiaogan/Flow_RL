# Workflow ID: high_level_math_ganluo_318_0
# Benchmark: high_level_math_ganluo
# Data Indices: [148, 649]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Understand the problem and extract key components
        understanding_instruction = (
            "Carefully analyze the problem statement. Identify all numerical values, variables, "
            "constraints, and relationships. Highlight the main objective and any special conditions. "
            "Provide a structured breakdown of the problem."
        )
        problem_breakdown = await self.generate(instruction=understanding_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        algebraic_instruction = (
            f"Based on the problem breakdown: {problem_breakdown}\n"
            "Solve the problem using algebraic methods. Include step-by-step reasoning, define all variables, "
            "and show all calculations. Ensure the solution satisfies all constraints."
        )
        geometric_instruction = (
            f"Based on the problem breakdown: {problem_breakdown}\n"
            "Solve the problem using geometric reasoning. If applicable, describe the geometric setup, "
            "use diagrams conceptually, and derive the solution step by step."
        )
        combinatorial_instruction = (
            f"Based on the problem breakdown: {problem_breakdown}\n"
            "Solve the problem using combinatorial or probabilistic methods. Consider all possible cases, "
            "use counting principles, and verify the solution against the problem's constraints."
        )

        # Parallel execution of multiple solution paths
        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Refine each solution independently
        refined_results = await asyncio.gather(
            self.revise(instruction="Critically review this solution. Check for logical consistency, "
                                    "computational accuracy, and adherence to constraints. Suggest improvements.", 
                        context=results[0]),
            self.revise(instruction="Critically review this solution. Check for logical consistency, "
                                    "computational accuracy, and adherence to constraints. Suggest improvements.", 
                        context=results[1]),
            self.revise(instruction="Critically review this solution. Check for logical consistency, "
                                    "computational accuracy, and adherence to constraints. Suggest improvements.", 
                        context=results[2])
        )

        # Step 4: Select the best solution using ensemble
        selection_instruction = (
            "Compare the provided solutions. Evaluate their correctness, elegance, and completeness. "
            "Select the best solution based on these criteria. If multiple solutions are equally valid, "
            "synthesize them into a single coherent answer."
        )
        final_solution = await self.ensemble(instruction=selection_instruction, contexts=refined_results)

        # Step 5: Summarize the final solution for clarity
        summary_instruction = (
            "Condense the solution into a clear and concise summary. Retain all critical steps, "
            "key insights, and the final answer. Ensure the summary is easy to follow and verifies "
            "against the original problem statement."
        )
        summarized_solution = await self.summarize(instruction=summary_instruction, context=final_solution)

        return summarized_solution