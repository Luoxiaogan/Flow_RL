# Workflow ID: high_level_math_ganluo_159_0
# Benchmark: high_level_math_ganluo
# Data Indices: [906, 570]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract and Analyze the Problem
        analysis_instruction = (
            "Carefully analyze the problem statement. Identify all variables, equations, constraints, "
            "and the desired output format. Highlight any special conditions or requirements. "
            "Provide a structured breakdown of the problem."
        )
        problem_analysis = await self.generate(instruction=analysis_instruction, context=self.problem_text)

        # Step 2: Generate Multiple Solution Approaches in Parallel
        algebra_instruction = (
            f"Using the problem analysis: {problem_analysis}, solve the problem algebraically. "
            "Show all steps, including substitutions, simplifications, and transformations. "
            "Ensure the solution satisfies all constraints."
        )
        geometry_instruction = (
            f"Using the problem analysis: {problem_analysis}, approach the problem geometrically. "
            "If applicable, convert algebraic expressions into geometric interpretations. "
            "Provide a clear reasoning path and verify the solution."
        )
        combinatorics_instruction = (
            f"Using the problem analysis: {problem_analysis}, explore combinatorial or probabilistic methods. "
            "Consider counting principles, recursive formulas, or symmetry arguments. "
            "Ensure the solution is mathematically sound."
        )

        # Parallel execution of multiple approaches
        approaches = await asyncio.gather(
            self.generate(instruction=algebra_instruction, context=self.problem_text),
            self.generate(instruction=geometry_instruction, context=self.problem_text),
            self.generate(instruction=combinatorics_instruction, context=self.problem_text)
        )

        # Step 3: Revise and Critique Each Approach
        revise_instruction = (
            "Critique the provided solution. Check for mathematical correctness, logical consistency, "
            "and adherence to the problem's constraints. Suggest improvements if necessary."
        )
        revised_approaches = await asyncio.gather(
            *[self.revise(instruction=revise_instruction, context=approach) for approach in approaches]
        )

        # Step 4: Summarize Key Insights (Optional)
        summarize_instruction = (
            "Condense the key insights and results from the revised solution. Focus on clarity and relevance "
            "to the problem's requirements."
        )
        summaries = await asyncio.gather(
            *[self.summarize(instruction=summarize_instruction, context=revised) for revised in revised_approaches]
        )

        # Step 5: Ensemble Decision
        ensemble_instruction = (
            "Compare and evaluate the provided solutions. Select the most robust, elegant, and correct approach. "
            "If multiple solutions are valid, synthesize them into a unified answer. Ensure the final result "
            "meets the problem's requirements."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=summaries)

        return final_solution