# Workflow ID: high_level_math_ganluo_277_0
# Benchmark: high_level_math_ganluo
# Data Indices: [678, 228]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all numerical values, variables, constraints, and relationships "
            "from the problem statement. Organize them into categories such as "
            "'knowns', 'unknowns', and 'conditions'."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        algebraic_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem algebraically. "
            "Provide a detailed step-by-step reasoning process, including any formulas or equations used."
        )
        combinatorial_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using combinatorial methods. "
            "Include counting principles, recursive structures, or generating functions if applicable."
        )
        geometry_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem geometrically. "
            "Convert the problem into coordinate geometry or synthetic geometry if possible."
        )

        # Run three approaches in parallel
        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text),
            self.generate(instruction=geometry_instruction, context=self.problem_text)
        )

        # Step 3: Revise each solution for correctness and clarity
        revised_results = await asyncio.gather(
            self.revise(
                instruction="Critique and refine this solution. Ensure it satisfies all problem constraints, "
                            "is mathematically correct, and considers edge cases.",
                context=results[0]
            ),
            self.revise(
                instruction="Critique and refine this solution. Ensure it satisfies all problem constraints, "
                            "is mathematically correct, and considers edge cases.",
                context=results[1]
            ),
            self.revise(
                instruction="Critique and refine this solution. Ensure it satisfies all problem constraints, "
                            "is mathematically correct, and considers edge cases.",
                context=results[2]
            )
        )

        # Step 4: Ensemble to select the best solution
        ensemble_instruction = (
            "Compare the following solutions and select the best one. "
            "Evaluate based on clarity, completeness, mathematical correctness, and alignment with the problem requirements."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=revised_results)

        # Step 5: Summarize the final answer
        summary_instruction = (
            "Condense the solution into a concise form while retaining all essential details. "
            "Ensure the final answer is clearly stated and formatted appropriately."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=best_solution)

        return final_answer