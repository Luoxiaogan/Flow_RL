# Workflow ID: high_level_math_ganluo_263_0
# Benchmark: high_level_math_ganluo
# Data Indices: [843, 324]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = """
        Analyze the problem statement thoroughly. Identify and extract:
        - Variables involved (e.g., x, y, z)
        - Constraints or conditions (e.g., equations, inequalities)
        - The goal or question being asked (e.g., find a value, prove a property)
        - Any special structures or patterns (e.g., symmetry, recursion)
        Ensure the output is structured clearly for further processing.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        approach_instructions = [
            f"""
            Solve the problem using an algebraic approach. Leverage the following extracted information:
            {extracted_info}
            Focus on symbolic manipulation, equations, and inequalities. Provide step-by-step reasoning.
            """,
            f"""
            Solve the problem using a geometric approach. Leverage the following extracted information:
            {extracted_info}
            Consider visual representations, coordinate geometry, or synthetic geometry techniques. Provide step-by-step reasoning.
            """,
            f"""
            Solve the problem using a combinatorial or number-theoretic approach. Leverage the following extracted information:
            {extracted_info}
            Focus on counting principles, modular arithmetic, or divisibility properties. Provide step-by-step reasoning.
            """
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Evaluate and synthesize the best solution
        ensemble_instruction = """
        Compare the provided solution approaches. Select the most promising one based on:
        - Correctness and adherence to problem constraints
        - Simplicity and clarity of reasoning
        - Completeness and rigor of the solution
        If multiple approaches are valid, synthesize them into a unified solution.
        """
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=approaches)

        # Step 4: Refine the chosen solution
        refinement_instruction = """
        Critically review the solution for correctness and completeness. Ensure:
        - All constraints and conditions are satisfied
        - Mathematical rigor is maintained
        - The reasoning is clear and concise
        Make improvements as needed.
        """
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the final solution
        summary_instruction = """
        Condense the solution into a clear, concise format. Include:
        - The final answer
        - Key steps or reasoning highlights
        - Any assumptions or special cases considered
        Ensure the output is easy to understand and directly addresses the problem.
        """
        final_output = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_output