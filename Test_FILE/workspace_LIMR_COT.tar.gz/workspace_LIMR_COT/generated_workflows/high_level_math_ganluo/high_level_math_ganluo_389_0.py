# Workflow ID: high_level_math_ganluo_389_0
# Benchmark: high_level_math_ganluo
# Data Indices: [496, 655]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key components from the problem
        extraction_instruction = (
            "Thoroughly analyze the problem statement and extract all key components, "
            "including numerical values, variables, equations, constraints, and relationships. "
            "Organize the extracted information clearly for subsequent steps."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution paths in parallel
        generate_instruction_1 = (
            f"Based on the extracted information: {extracted_info}\n"
            "Solve the problem using an algebraic or analytical approach. "
            "Provide step-by-step reasoning and ensure all constraints are satisfied."
        )
        generate_instruction_2 = (
            f"Based on the extracted information: {extracted_info}\n"
            "Solve the problem using a geometric or combinatorial approach. "
            "Provide step-by-step reasoning and ensure all constraints are satisfied."
        )
        results = await asyncio.gather(
            self.generate(instruction=generate_instruction_1, context=self.problem_text),
            self.generate(instruction=generate_instruction_2, context=self.problem_text)
        )
        solution_1, solution_2 = results

        # Step 3: Revise and refine each solution
        revise_instruction = (
            "Critically evaluate the provided solution. Identify and correct any errors, "
            "clarify ambiguous steps, and ensure all problem constraints are satisfied. "
            "Improve the overall structure and presentation of the solution."
        )
        revised_solution_1 = await self.revise(instruction=revise_instruction, context=solution_1)
        revised_solution_2 = await self.revise(instruction=revise_instruction, context=solution_2)

        # Step 4: Compare and synthesize the best solution
        ensemble_instruction = (
            "Compare the two revised solutions carefully. Select the most accurate, "
            "efficient, and well-justified solution. If both solutions are valid, "
            "synthesize them into a single coherent answer."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=[revised_solution_1, revised_solution_2])

        # Step 5: Summarize the final solution
        summarize_instruction = (
            "Condense the final solution into a clear and concise format. "
            "Highlight the key steps and ensure the answer directly addresses the problem statement."
        )
        summary = await self.summarize(instruction=summarize_instruction, context=final_solution)

        return summary