# Workflow ID: high_level_math_ganluo_195_0
# Benchmark: high_level_math_ganluo
# Data Indices: [131, 959]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Problem Decomposition
        decomposition_instruction = (
            "Analyze the problem statement to identify all variables, constraints, "
            "and relationships. Outline potential solution strategies, including algebraic, "
            "geometric, combinatorial, or number-theoretic approaches. Ensure the output "
            "is structured and includes all necessary information for solving the problem."
        )
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Parallel Exploration of Solution Paths
        algebraic_instruction = (
            f"Using the following decomposition: {decomposition}, solve the problem using "
            "algebraic techniques. Include all steps, transformations, and justifications."
        )
        geometric_instruction = (
            f"Using the following decomposition: {decomposition}, solve the problem using "
            "geometric reasoning. Include diagrams (if applicable), relationships, and proofs."
        )
        combinatorial_instruction = (
            f"Using the following decomposition: {decomposition}, solve the problem using "
            "combinatorial or probabilistic methods. Include counting arguments, cases, and expected values."
        )

        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Evaluation and Refinement
        ensemble_instruction = (
            "Compare the following candidate solutions and determine the most correct, "
            "efficient, and elegant approach. Provide a rationale for your choice. If none "
            "are satisfactory, suggest improvements."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        refinement_instruction = (
            f"Refine the following solution: {best_solution}. Ensure it is mathematically "
            "rigorous, satisfies all constraints, and is presented clearly."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 4: Final Output
        summary_instruction = (
            "Summarize the final solution in a concise and clear format. Include only the "
            "key steps and the final answer, ensuring it is easy to understand."
        )
        final_output = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_output