# Workflow ID: high_level_math_ganluo_390_0
# Benchmark: high_level_math_ganluo
# Data Indices: [238, 30]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extract_instruction = (
            "Extract all key information from the problem, including variables, constraints, equations, "
            "and relationships. Organize the information in a structured format."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        generate_instruction_template = (
            "Given the extracted information: {info}, develop a solution approach using {method}. "
            "Ensure the approach is mathematically rigorous and aligns with the problem's constraints."
        )
        methods = ["algebraic manipulation", "geometric reasoning", "combinatorial analysis", "number theory"]
        generate_tasks = [
            self.generate(instruction=generate_instruction_template.format(info=extracted_info, method=method), context=self.problem_text)
            for method in methods
        ]
        approaches = await asyncio.gather(*generate_tasks)

        # Step 3: Evaluate and select the best approach
        ensemble_instruction = (
            "Evaluate the following solution approaches based on correctness, feasibility, and alignment "
            "with the problem's constraints. Select the most promising approach and provide justification."
        )
        selected_approach = await self.ensemble(instruction=ensemble_instruction, contexts=approaches)

        # Step 4: Refine the selected solution
        refine_instruction = (
            "Refine the following solution: {solution}. Address any errors, optimize the reasoning, "
            "and ensure all steps are mathematically sound. Verify intermediate results and consider edge cases."
        )
        refined_solution = await self.revise(
            instruction=refine_instruction.format(solution=selected_approach),
            context=self.problem_text
        )

        # Step 5: Summarize the final solution
        summarize_instruction = (
            "Condense the following solution into a concise, verifiable form: {solution}. "
            "Ensure the final answer satisfies all problem constraints and is presented clearly."
        )
        final_solution = await self.summarize(
            instruction=summarize_instruction.format(solution=refined_solution),
            context=self.problem_text
        )

        return final_solution