# Workflow ID: high_level_math_ganluo_332_0
# Benchmark: high_level_math_ganluo
# Data Indices: [21, 672]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key components of the problem
        extraction_instruction = (
            "Analyze the problem and extract the following information: "
            "1. Variables involved (e.g., x, y, z). "
            "2. Constraints (e.g., inequalities, equations). "
            "3. Objective (e.g., maximize, minimize, find). "
            "4. Mathematical domain (e.g., algebra, geometry, combinatorics). "
            "Organize the extracted information into a structured format."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple candidate solutions in parallel
        algebra_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "solve the problem using algebraic techniques. "
            "Include all steps and reasoning explicitly."
        )
        geometry_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "solve the problem using geometric techniques. "
            "Include all steps and reasoning explicitly."
        )
        combinatorics_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "solve the problem using combinatorial techniques. "
            "Include all steps and reasoning explicitly."
        )
        candidates = await asyncio.gather(
            self.generate(instruction=algebra_instruction, context=self.problem_text),
            self.generate(instruction=geometry_instruction, context=self.problem_text),
            self.generate(instruction=combinatorics_instruction, context=self.problem_text)
        )

        # Step 3: Refine each candidate solution
        refine_instruction_template = (
            "Review the solution and refine it to ensure correctness and clarity. "
            "Check that it satisfies all constraints and is mathematically sound. "
            "Provide detailed feedback on any improvements made."
        )
        refined_solutions = await asyncio.gather(
            *[self.revise(instruction=refine_instruction_template, context=candidate) for candidate in candidates]
        )

        # Step 4: Ensemble decision-making to select the best solution
        ensemble_instruction = (
            "Compare the refined solutions and select the best one based on the following criteria: "
            "1. Simplicity and elegance of the approach. "
            "2. Adherence to the problem constraints. "
            "3. Computational efficiency. "
            "If multiple solutions are valid, synthesize them into a single coherent answer."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_solutions)

        # Step 5: Summarize the final solution
        summarize_instruction = (
            "Summarize the final solution into a concise and well-structured format. "
            "Ensure that it directly addresses the problem and includes all key steps."
        )
        summary = await self.summarize(instruction=summarize_instruction, context=final_solution)

        return summary