# Workflow ID: high_level_math_ganluo_464_0
# Benchmark: high_level_math_ganluo
# Data Indices: [539, 722]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all numerical values, relationships, constraints, and the question being asked. "
            "Organize this information clearly and categorize it into knowns and unknowns."
        )
        key_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution strategies in parallel
        strategy_instructions = [
            f"Develop an algebraic solution strategy for the problem using the following extracted information: {key_info}. "
            "Focus on equations, variables, and relationships.",
            
            f"Develop a geometric solution strategy for the problem using the following extracted information: {key_info}. "
            "Consider shapes, dimensions, and spatial relationships.",
            
            f"Develop a combinatorial or probabilistic solution strategy for the problem using the following extracted information: {key_info}. "
            "Focus on counting principles, arrangements, and probabilities."
        ]
        strategies = await asyncio.gather(
            *[self.generate(instruction=instr, context=key_info) for instr in strategy_instructions]
        )

        # Step 3: Execute and refine each strategy
        refined_solutions = []
        for strategy in strategies:
            execution_instruction = (
                f"Execute the following solution strategy step-by-step: {strategy}. "
                "Ensure all calculations are accurate and logical reasoning is sound."
            )
            executed_solution = await self.generate(instruction=execution_instruction, context=strategy)
            
            refinement_instruction = (
                "Review the executed solution for any errors, ambiguities, or inefficiencies. "
                "Refine it to improve clarity, correctness, and mathematical rigor."
            )
            refined_solution = await self.revise(instruction=refinement_instruction, context=executed_solution)
            refined_solutions.append(refined_solution)

        # Step 4: Select the best solution using Ensemble
        ensemble_instruction = (
            "Evaluate the following candidate solutions and select the most accurate, efficient, and elegant one. "
            "Ensure the chosen solution satisfies all problem constraints and demonstrates mathematical rigor."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_solutions)

        # Step 5: Verify and summarize the final solution
        verification_instruction = (
            "Verify that the following solution satisfies all problem constraints and conditions. "
            "Check calculations, logical consistency, and adherence to the problem statement."
        )
        verified_solution = await self.revise(instruction=verification_instruction, context=best_solution)
        
        summary_instruction = (
            "Summarize the verified solution concisely while preserving all key steps, results, and reasoning. "
            "Ensure the summary is clear and easy to follow."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=verified_solution)

        return final_summary