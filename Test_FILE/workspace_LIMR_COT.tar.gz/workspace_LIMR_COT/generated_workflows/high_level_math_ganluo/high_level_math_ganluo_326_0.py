# Workflow ID: high_level_math_ganluo_326_0
# Benchmark: high_level_math_ganluo
# Data Indices: [352, 307]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract problem components
        extraction_instruction = (
            "Carefully analyze the problem statement and extract the following information:\n"
            "- Variables involved\n"
            "- Constraints or conditions\n"
            "- Objective or goal\n"
            "Provide this information in a structured format for further processing."
        )
        problem_components = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate two independent solution approaches in parallel
        approach_1_instruction = (
            f"Given the extracted problem components: {problem_components}\n"
            "Develop a detailed solution using an ALGEBRAIC approach. "
            "Include step-by-step reasoning, intermediate calculations, and justification for each step."
        )
        approach_2_instruction = (
            f"Given the extracted problem components: {problem_components}\n"
            "Develop a detailed solution using a GEOMETRIC or COMBINATORIAL approach. "
            "Include step-by-step reasoning, intermediate calculations, and justification for each step."
        )
        approaches = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text)
        )

        # Step 3: Refine each solution
        refinement_instruction_1 = (
            "Critique and improve the following solution:\n"
            "Ensure logical consistency, correct calculations, and clarity of reasoning. "
            "Suggest improvements where necessary."
        )
        refinement_instruction_2 = refinement_instruction_1  # Same refinement criteria for both approaches
        refined_approaches = await asyncio.gather(
            self.revise(instruction=refinement_instruction_1, context=approaches[0]),
            self.revise(instruction=refinement_instruction_2, context=approaches[1])
        )

        # Step 4: Synthesize the best solution
        synthesis_instruction = (
            "Evaluate the following two refined solutions and determine the best one:\n"
            "- Consider accuracy, simplicity, and adherence to problem constraints.\n"
            "- If both solutions are valid, choose the more elegant or efficient one.\n"
            "- Provide a justification for your choice."
        )
        final_solution = await self.ensemble(instruction=synthesis_instruction, contexts=refined_approaches)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Summarize the final solution in a concise and clear format:\n"
            "- Highlight the key steps and reasoning.\n"
            "- Ensure all constraints and conditions are satisfied.\n"
            "- Present the answer in the required format."
        )
        summarized_solution = await self.summarize(instruction=summary_instruction, context=final_solution)

        return summarized_solution