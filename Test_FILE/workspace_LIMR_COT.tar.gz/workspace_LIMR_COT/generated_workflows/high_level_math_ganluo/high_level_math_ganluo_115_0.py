# Workflow ID: high_level_math_ganluo_115_0
# Benchmark: high_level_math_ganluo
# Data Indices: [50, 133]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information and problem type
        extraction_instruction = (
            "Extract all numerical values, variables, constraints, and relationships from the problem. "
            "Identify the type of problem (e.g., algebraic, combinatorial, geometric) and the key mathematical techniques required. "
            "Provide this information in a structured format."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution paths in parallel
        generate_algebraic = self.generate(
            instruction=f"Using algebraic techniques, solve the problem step-by-step. Extracted information: {extracted_info}",
            context=self.problem_text
        )
        generate_combinatorial = self.generate(
            instruction=f"Using combinatorial techniques, solve the problem step-by-step. Extracted information: {extracted_info}",
            context=self.problem_text
        )
        generate_geometric = self.generate(
            instruction=f"Using geometric techniques, solve the problem step-by-step. Extracted information: {extracted_info}",
            context=self.problem_text
        )

        # Execute in parallel
        solutions = await asyncio.gather(generate_algebraic, generate_combinatorial, generate_geometric)

        # Step 3: Refine each solution for correctness and clarity
        refine_instructions = (
            "Critique and refine the solution to ensure mathematical correctness, clarity, and adherence to all constraints. "
            "Provide detailed feedback and corrections if necessary."
        )
        refined_solutions = [
            await self.revise(instruction=refine_instructions, context=solution)
            for solution in solutions
        ]

        # Step 4: Summarize each refined solution
        summarize_instructions = (
            "Condense the refined solution into a concise summary, highlighting the key steps and final result."
        )
        summarized_solutions = [
            await self.summarize(instruction=summarize_instructions, context=solution)
            for solution in refined_solutions
        ]

        # Step 5: Ensemble to select the best solution
        ensemble_instruction = (
            "Compare the summarized solutions and select the most robust, efficient, and correct one. "
            "Consider simplicity, computational feasibility, and adherence to problem constraints."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=summarized_solutions)

        return final_solution