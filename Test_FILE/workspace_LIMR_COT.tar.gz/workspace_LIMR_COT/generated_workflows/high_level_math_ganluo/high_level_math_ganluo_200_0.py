# Workflow ID: high_level_math_ganluo_200_0
# Benchmark: high_level_math_ganluo
# Data Indices: [761, 12]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = """
        Analyze the problem statement and extract all relevant information, including:
        - Variables involved
        - Known values and constraints
        - The specific question or goal
        Provide this information in a structured format.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        approach_instruction_template = f"""
        Based on the extracted information: {extracted_info}
        Propose a solution approach for the problem. Consider the following strategies:
        - Algebraic manipulation (e.g., solving equations, simplifying expressions)
        - Geometric reasoning (e.g., coordinate geometry, synthetic geometry)
        - Combinatorial analysis (e.g., counting, recursive formulas)
        - Number theory (e.g., modular arithmetic, divisibility)
        Provide a detailed plan for solving the problem using one of these strategies.
        """
        approaches = await asyncio.gather(
            self.generate(instruction=approach_instruction_template + " Focus on an algebraic approach.", context=self.problem_text),
            self.generate(instruction=approach_instruction_template + " Focus on a geometric approach.", context=self.problem_text),
            self.generate(instruction=approach_instruction_template + " Focus on a combinatorial approach.", context=self.problem_text)
        )

        # Step 3: Execute each approach
        execution_instruction_template = """
        Follow the provided solution approach step-by-step. Ensure all calculations are shown and intermediate results are clearly stated.
        """
        executed_solutions = await asyncio.gather(
            *[self.generate(instruction=execution_instruction_template, context=approach) for approach in approaches]
        )

        # Step 4: Validate and refine solutions
        refinement_instruction = """
        Review the provided solution for correctness and completeness. Check for:
        - Logical consistency
        - Adherence to problem constraints
        - Accuracy of calculations
        Suggest corrections if necessary.
        """
        refined_solutions = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction, context=solution) for solution in executed_solutions]
        )

        # Step 5: Ensemble decision to select the best solution
        ensemble_instruction = """
        Compare the provided solutions and select the most robust and accurate one. Consider:
        - Clarity of reasoning
        - Correctness of calculations
        - Alignment with problem constraints
        Provide the final selected solution.
        """
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_solutions)

        # Step 6: Summarize the final solution
        summary_instruction = """
        Condense the final solution into a concise, well-structured format. Include:
        - The final answer
        - Key steps or reasoning
        Ensure the output directly answers the problem.
        """
        summarized_solution = await self.summarize(instruction=summary_instruction, context=final_solution)

        return summarized_solution