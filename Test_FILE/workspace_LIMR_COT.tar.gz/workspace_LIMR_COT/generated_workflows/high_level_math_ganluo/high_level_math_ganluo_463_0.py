# Workflow ID: high_level_math_ganluo_463_0
# Benchmark: high_level_math_ganluo
# Data Indices: [993, 573]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information and constraints
        extract_instruction = (
            "Analyze the problem thoroughly. Identify all key numerical values, variables, constraints, "
            "and relationships. Highlight any special conditions or requirements that must be satisfied. "
            "Ensure the output is structured and easy to use in subsequent steps."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        approach_instructions = [
            f"Using algebraic methods, solve the problem step by step. Incorporate the following extracted information: {extracted_info}",
            f"Using geometric reasoning, solve the problem step by step. Incorporate the following extracted information: {extracted_info}",
            f"Using combinatorial or probabilistic methods, solve the problem step by step. Incorporate the following extracted information: {extracted_info}"
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Evaluate and select the best approach
        ensemble_instruction = (
            "Compare the provided solution approaches. Evaluate their correctness, completeness, and adherence "
            "to the problem's constraints. Select the most promising approach or synthesize a new one if needed."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=approaches)

        # Step 4: Refine and verify the selected solution
        refine_instruction = (
            "Critique and refine the provided solution. Ensure it is mathematically rigorous, satisfies all "
            "problem constraints, and is presented clearly. Highlight any assumptions or edge cases."
        )
        refined_solution = await self.revise(instruction=refine_instruction, context=best_solution)

        # Optional Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the solution into a concise and clear format. Include only the essential steps and results."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_summary