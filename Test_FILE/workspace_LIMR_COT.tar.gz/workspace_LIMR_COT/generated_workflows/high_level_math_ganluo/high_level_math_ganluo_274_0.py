# Workflow ID: high_level_math_ganluo_274_0
# Benchmark: high_level_math_ganluo
# Data Indices: [561, 8]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract Core Components of the Problem
        extraction_instruction = """
        Carefully analyze the problem statement and extract the following:
        - Variables involved
        - Constraints or conditions
        - Objective or goal of the problem
        Ensure the extraction is complete and accurate.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Explore Multiple Solution Paths in Parallel
        algebraic_instruction = f"""
        Using the extracted information: {extracted_info}
        Solve the problem using an algebraic approach. Consider equations, inequalities, and functional relationships.
        Provide a detailed step-by-step solution.
        """
        geometric_instruction = f"""
        Using the extracted information: {extracted_info}
        Solve the problem using a geometric approach. Consider coordinate geometry, synthetic geometry, and trigonometric relationships.
        Provide a detailed step-by-step solution.
        """
        combinatorial_instruction = f"""
        Using the extracted information: {extracted_info}
        Solve the problem using a combinatorial approach. Consider counting principles, recursive structures, and generating functions.
        Provide a detailed step-by-step solution.
        """
        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and Synthesize the Best Approach
        ensemble_instruction = """
        Compare the provided solutions and select the most appropriate one based on:
        - Accuracy and correctness
        - Simplicity and elegance
        - Adherence to problem constraints
        If multiple approaches are valid, synthesize them into a unified solution.
        """
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 4: Refine and Verify the Solution
        refinement_instruction = """
        Critically review the solution for correctness and completeness. Ensure:
        - All constraints are satisfied
        - Edge cases are considered
        - Calculations are accurate
        Refine the solution as needed.
        """
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the Final Solution
        summary_instruction = """
        Condense the solution into a concise, well-structured format. Include:
        - Key steps and reasoning
        - Final answer
        Ensure clarity and precision.
        """
        final_output = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_output