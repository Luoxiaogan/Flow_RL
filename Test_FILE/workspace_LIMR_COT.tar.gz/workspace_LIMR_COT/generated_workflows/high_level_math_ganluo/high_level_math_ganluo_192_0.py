# Workflow ID: high_level_math_ganluo_192_0
# Benchmark: high_level_math_ganluo
# Data Indices: [857, 665]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract and Understand the Problem
        extraction_instruction = """
        Carefully analyze the problem statement and extract all key components, including:
        - Variables involved
        - Constraints or conditions
        - The objective or question being asked
        Ensure the extracted information is complete and accurate.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate Multiple Solution Approaches
        approach_instructions = [
            f"""
            Solve the problem using an algebraic approach. Focus on:
            - Identifying equations or relationships
            - Simplifying expressions
            - Solving step-by-step
            Extracted information: {extracted_info}
            """,
            f"""
            Solve the problem using a geometric approach. Focus on:
            - Visualizing the problem
            - Using coordinate geometry or synthetic geometry techniques
            - Calculating areas, lengths, or angles as needed
            Extracted information: {extracted_info}
            """,
            f"""
            Solve the problem using combinatorial or number-theoretic reasoning. Focus on:
            - Counting arrangements or possibilities
            - Applying modular arithmetic or divisibility rules
            - Using recursive structures or generating functions
            Extracted information: {extracted_info}
            """
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Refine Each Approach
        refine_instruction_template = """
        Critique and refine the following solution approach:
        - Identify any logical gaps or computational errors
        - Verify that all constraints and conditions are satisfied
        - Improve clarity and efficiency where possible
        Solution Approach: {approach}
        """
        refined_approaches = await asyncio.gather(
            *[self.revise(instruction=refine_instruction_template.format(approach=approach), context=self.problem_text) 
              for approach in approaches]
        )

        # Step 4: Select the Best Solution
        selection_instruction = """
        Compare the following refined solution approaches and select the best one:
        - Evaluate correctness and completeness
        - Consider elegance and efficiency
        - Ensure the chosen solution satisfies all problem constraints
        Refined Approaches: {approaches}
        """
        best_solution = await self.ensemble(
            instruction=selection_instruction.format(approaches=refined_approaches),
            contexts=refined_approaches
        )

        # Step 5: Summarize the Final Solution
        summary_instruction = """
        Summarize the final solution in a clear and concise format:
        - Include all key steps and reasoning
        - Present the final answer prominently
        - Ensure the summary is easy to follow and mathematically sound
        Final Solution: {solution}
        """
        final_summary = await self.summarize(
            instruction=summary_instruction.format(solution=best_solution),
            context=self.problem_text
        )

        return final_summary