# Workflow ID: high_level_math_ganluo_42_0
# Benchmark: high_level_math_ganluo
# Data Indices: [627, 976]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract critical information and analyze the problem
        analysis_instruction = (
            "Analyze the problem thoroughly. Identify the mathematical domain (e.g., geometry, number theory), "
            "key constraints, numerical values, and relationships. Determine potential techniques or strategies "
            "that might be applicable, such as casework analysis, recursive formulas, or symmetry exploitation."
        )
        problem_analysis = await self.generate(instruction=analysis_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        algebraic_instruction = (
            f"Based on the analysis: {problem_analysis}, develop an algebraic approach to solve the problem. "
            "Include equations, inequalities, or functional relationships as needed."
        )
        geometric_instruction = (
            f"Based on the analysis: {problem_analysis}, develop a geometric approach to solve the problem. "
            "Include coordinate geometry, synthetic geometry, or trigonometric reasoning as appropriate."
        )
        combinatorial_instruction = (
            f"Based on the analysis: {problem_analysis}, develop a combinatorial or probabilistic approach. "
            "Consider counting principles, expected values, or recursive structures."
        )

        # Execute approaches in parallel
        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Select the best approach using Ensemble
        ensemble_instruction = (
            "Evaluate the provided solution approaches. Select the one that is most rigorous, computationally "
            "feasible, and aligned with the problem's constraints. Provide justification for your choice."
        )
        best_approach = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 4: Refine the selected approach
        refinement_instruction = (
            "Critically review and refine the selected solution approach. Verify intermediate steps, handle "
            "edge cases, and ensure the final answer satisfies all problem constraints. Correct any errors."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_approach)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the refined solution into a clear and concise explanation. Include the final answer, "
            "any key insights, and a brief justification of the chosen approach."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_summary