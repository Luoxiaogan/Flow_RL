# Workflow ID: high_level_math_ganluo_401_0
# Benchmark: high_level_math_ganluo
# Data Indices: [663, 395]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Problem Understanding and Decomposition
        decomposition_instruction = (
            "Analyze the problem statement carefully. Identify all variables, constants, "
            "constraints, and relationships. Determine the type of mathematical reasoning required "
            "(e.g., algebraic manipulation, combinatorial analysis, number theory). Provide a "
            "structured summary of the problem components."
        )
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Exploration of Solution Paths
        # Define multiple approaches to solve the problem
        algebraic_instruction = (
            f"Using the following problem decomposition: {decomposition}\n"
            "Solve the problem using algebraic techniques. Include all steps, transformations, "
            "and intermediate results. Ensure the solution satisfies all constraints."
        )
        geometric_instruction = (
            f"Using the following problem decomposition: {decomposition}\n"
            "Solve the problem using geometric reasoning. Include all steps, diagrams (if applicable), "
            "and intermediate results. Ensure the solution satisfies all constraints."
        )
        combinatorial_instruction = (
            f"Using the following problem decomposition: {decomposition}\n"
            "Solve the problem using combinatorial analysis. Include all steps, counting principles, "
            "and intermediate results. Ensure the solution satisfies all constraints."
        )

        # Execute approaches in parallel
        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Evaluation and Synthesis
        ensemble_instruction = (
            "Compare the following candidate solutions and select the most appropriate one. "
            "If multiple solutions are valid, combine their insights to form a unified answer. "
            "Ensure the final solution satisfies all constraints and is mathematically rigorous."
        )
        synthesis = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 4: Refinement (if necessary)
        refinement_instruction = (
            "Critically review the following solution. Identify any errors, gaps, or areas for improvement. "
            "Refine the solution to ensure correctness, clarity, and completeness."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=synthesis)

        # Step 5: Final Answer Extraction
        summarization_instruction = (
            "Condense the following solution into a concise final answer. Ensure the answer is clear, "
            "unambiguous, and satisfies all constraints of the problem."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_solution)

        return final_answer