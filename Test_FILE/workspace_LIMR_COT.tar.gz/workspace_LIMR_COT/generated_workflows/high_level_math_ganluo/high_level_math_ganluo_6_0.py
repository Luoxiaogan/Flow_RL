# Workflow ID: high_level_math_ganluo_6_0
# Benchmark: high_level_math_ganluo
# Data Indices: [682, 224]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract and Understand the Problem
        problem_analysis_instruction = (
            "Analyze the given problem thoroughly. Identify all variables, constraints, "
            "relationships, and the desired output. Provide a clear breakdown of the problem's structure."
        )
        problem_analysis = await self.generate(instruction=problem_analysis_instruction, context=self.problem_text)

        # Step 2: Generate Multiple Solution Strategies
        algebra_strategy_instruction = (
            f"Based on the problem analysis: {problem_analysis}\n"
            "Develop an algebraic solution strategy. Include steps for equation setup, simplification, "
            "and solving. Ensure the approach aligns with the problem's constraints."
        )
        geometry_strategy_instruction = (
            f"Based on the problem analysis: {problem_analysis}\n"
            "Develop a geometric solution strategy. Consider coordinate geometry, synthetic geometry, "
            "and trigonometric methods. Provide a step-by-step plan."
        )
        combinatorics_strategy_instruction = (
            f"Based on the problem analysis: {problem_analysis}\n"
            "Develop a combinatorial solution strategy. Focus on counting principles, recursive formulas, "
            "and generating functions if applicable."
        )

        strategies = await asyncio.gather(
            self.generate(instruction=algebra_strategy_instruction, context=problem_analysis),
            self.generate(instruction=geometry_strategy_instruction, context=problem_analysis),
            self.generate(instruction=combinatorics_strategy_instruction, context=problem_analysis)
        )

        # Step 3: Evaluate and Select the Best Strategy
        selection_instruction = (
            "Evaluate the provided solution strategies. Consider clarity, feasibility, "
            "alignment with the problem's constraints, and computational complexity. "
            "Select the most appropriate strategy and justify your choice."
        )
        best_strategy = await self.ensemble(instruction=selection_instruction, contexts=strategies)

        # Step 4: Refine the Chosen Strategy
        refinement_instruction = (
            f"Refine the selected strategy: {best_strategy}\n"
            "Address any edge cases, simplify expressions, and ensure correctness. "
            "Provide a polished and error-free solution."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_strategy)

        # Step 5: Summarize the Final Answer
        summary_instruction = (
            f"Summarize the refined solution: {refined_solution}\n"
            "Present the final answer in a clear, concise format. Ensure it satisfies all problem constraints."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer