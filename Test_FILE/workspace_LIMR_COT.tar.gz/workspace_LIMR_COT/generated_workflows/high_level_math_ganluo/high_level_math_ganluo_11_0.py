# Workflow ID: high_level_math_ganluo_11_0
# Benchmark: high_level_math_ganluo
# Data Indices: [321, 899]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all key information from the problem, including variables, equations, constraints, "
            "and relationships. Identify the type of problem (e.g., algebra, geometry, combinatorics) "
            "and any specific techniques that might be applicable."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        algebra_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using algebraic methods. "
            "Include all steps and explain the reasoning behind each transformation."
        )
        geometry_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using geometric reasoning. "
            "Include all steps and explain the reasoning behind each construction or calculation."
        )
        combinatorics_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using combinatorial methods. "
            "Include all steps and explain the reasoning behind each counting or arrangement."
        )

        results = await asyncio.gather(
            self.generate(instruction=algebra_instruction, context=self.problem_text),
            self.generate(instruction=geometry_instruction, context=self.problem_text),
            self.generate(instruction=combinatorics_instruction, context=self.problem_text)
        )
        algebra_solution, geometry_solution, combinatorics_solution = results

        # Step 3: Refine the generated solutions
        refine_instruction = (
            "Critique and refine the given solution. Check for correctness, clarity, and adherence to the problem constraints. "
            "Highlight any missing steps, assumptions, or edge cases."
        )
        refined_algebra = await self.revise(instruction=refine_instruction, context=algebra_solution)
        refined_geometry = await self.revise(instruction=refine_instruction, context=geometry_solution)
        refined_combinatorics = await self.revise(instruction=refine_instruction, context=combinatorics_solution)

        # Step 4: Select the best solution using Ensemble
        ensemble_instruction = (
            "Compare the following solutions and select the best one based on correctness, elegance, and computational efficiency. "
            "Provide a justification for your choice."
        )
        final_solution = await self.ensemble(
            instruction=ensemble_instruction,
            contexts=[refined_algebra, refined_geometry, refined_combinatorics]
        )

        return final_solution