# Workflow ID: high_level_math_ganluo_85_0
# Benchmark: high_level_math_ganluo
# Data Indices: [695, 519]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all key information from the problem, including numerical values, relationships, "
            "constraints, and any specific conditions. Organize the information clearly."
        )
        key_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Explore multiple solution paths in parallel
        algebraic_instruction = (
            f"Using the extracted information: {key_info}\n"
            "Solve the problem using algebraic methods. Show all steps and justify each transformation."
        )
        geometric_instruction = (
            f"Using the extracted information: {key_info}\n"
            "Solve the problem using geometric reasoning. Clearly explain any diagrams or constructions used."
        )
        combinatorial_instruction = (
            f"Using the extracted information: {key_info}\n"
            "Solve the problem using combinatorial or probabilistic methods. Include all cases and calculations."
        )

        # Generate solutions in parallel
        solutions = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Validate and refine each solution
        refinement_instruction_template = (
            "Critique the following solution thoroughly. Check for logical consistency, mathematical correctness, "
            "and adherence to the problem's constraints. Suggest improvements if necessary and refine the solution."
        )
        refined_solutions = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction_template, context=solution) for solution in solutions]
        )

        # Step 4: Ensemble decision-making
        ensemble_instruction = (
            "Compare the following candidate solutions. Evaluate their correctness, elegance, and completeness. "
            "Select the best solution or synthesize insights from multiple solutions if needed."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_solutions)

        # Step 5: Summarize the final answer
        summary_instruction = (
            "Condense the final solution into a clear and concise format. Ensure the answer satisfies all "
            "problem constraints and is presented in a structured manner."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=final_solution)

        return final_answer