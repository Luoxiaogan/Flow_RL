# Workflow ID: high_level_math_ganluo_156_0
# Benchmark: high_level_math_ganluo
# Data Indices: [932, 607]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio
        
        # Step 1: Initial Problem Analysis
        analysis_instruction = (
            "Analyze the given problem comprehensively. Identify all variables, constants, "
            "constraints, and relationships. Provide a structured breakdown of the problem, "
            "highlighting potential solution strategies."
        )
        problem_analysis = await self.generate(instruction=analysis_instruction, context=self.problem_text)
        
        # Step 2: Explore Multiple Solution Paths
        algebra_instruction = (
            f"Based on the analysis: {problem_analysis}, solve the problem using algebraic methods. "
            "Focus on equations, expressions, and algebraic manipulations. Ensure all steps are justified."
        )
        geometry_instruction = (
            f"Based on the analysis: {problem_analysis}, approach the problem geometrically. "
            "Use geometric principles, diagrams, and spatial reasoning to derive a solution."
        )
        combinatorics_instruction = (
            f"Based on the analysis: {problem_analysis}, apply combinatorial techniques. "
            "Consider permutations, combinations, probabilities, and counting principles."
        )
        
        algebra_solution, geometry_solution, combinatorics_solution = await asyncio.gather(
            self.generate(instruction=algebra_instruction, context=self.problem_text),
            self.generate(instruction=geometry_instruction, context=self.problem_text),
            self.generate(instruction=combinatorics_instruction, context=self.problem_text)
        )
        
        # Step 3: Refine Solutions
        refine_instruction_template = (
            "Critically evaluate and refine the following solution. Check for mathematical accuracy, "
            "logical consistency, and adherence to problem constraints. Improve clarity and rigor where needed."
        )
        refined_algebra = await self.revise(instruction=refine_instruction_template, context=algebra_solution)
        refined_geometry = await self.revise(instruction=refine_instruction_template, context=geometry_solution)
        refined_combinatorics = await self.revise(instruction=refine_instruction_template, context=combinatorics_solution)
        
        # Step 4: Select the Best Solution
        ensemble_instruction = (
            "Evaluate and compare the following solutions. Select the most accurate, elegant, "
            "and insightful solution that fully addresses the problem. Justify your choice."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=[refined_algebra, refined_geometry, refined_combinatorics])
        
        # Step 5: Extract Final Answer
        summarize_instruction = (
            "From the selected solution, extract the final answer. Ensure it is concise, clear, "
            "and directly answers the problem's question."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=best_solution)
        
        return final_answer