# Workflow ID: high_level_math_ganluo_120_0
# Benchmark: high_level_math_ganluo
# Data Indices: [443, 837]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Understand the problem and decompose it
        understanding_instruction = (
            "Carefully analyze the problem statement. Identify what is being asked, "
            "the given constraints, and any mathematical structures or patterns present. "
            "Provide a detailed breakdown of the problem components."
        )
        problem_understanding = await self.generate(instruction=understanding_instruction, context=self.problem_text)

        # Step 2: Explore multiple solution paths in parallel
        algebraic_instruction = f"Using algebraic techniques, solve the problem based on this understanding: {problem_understanding}"
        combinatorial_instruction = f"Using combinatorial reasoning, solve the problem based on this understanding: {problem_understanding}"
        geometric_instruction = f"Using geometric interpretation, solve the problem based on this understanding: {problem_understanding}"

        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text)
        )

        # Step 3: Refine each solution path
        refinement_instruction = (
            "Critique and refine the provided solution. Check for mathematical correctness, "
            "consider edge cases, and ensure all constraints are satisfied."
        )
        refined_results = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction, context=result) for result in results]
        )

        # Step 4: Compare and synthesize the best solution
        ensemble_instruction = (
            "Evaluate the provided solutions. Select the most robust, elegant, and mathematically sound solution. "
            "If multiple solutions are valid, synthesize their insights into a unified answer."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_results)

        # Step 5: Summarize the final solution
        summarization_instruction = (
            "Condense the solution into a concise and clear format. Ensure all key steps and reasoning are preserved."
        )
        summary = await self.summarize(instruction=summarization_instruction, context=final_solution)

        return summary