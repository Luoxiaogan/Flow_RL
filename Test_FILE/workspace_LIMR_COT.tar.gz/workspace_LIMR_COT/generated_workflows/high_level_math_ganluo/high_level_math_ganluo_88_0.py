# Workflow ID: high_level_math_ganluo_88_0
# Benchmark: high_level_math_ganluo
# Data Indices: [196, 734]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Initial Analysis - Extract key components and problem type
        initial_analysis_instruction = (
            "Analyze the problem to identify its mathematical structure, constraints, and key components. "
            "Determine the problem type (e.g., algebraic, combinatorial, geometric) and extract all numerical or symbolic data. "
            "Provide a structured summary of the findings."
        )
        analysis = await self.generate(instruction=initial_analysis_instruction, context=self.problem_text)

        # Step 2: Solution Exploration - Generate multiple solution paths in parallel
        algebraic_instruction = (
            f"Using the extracted information: {analysis}, solve the problem using algebraic methods. "
            "Focus on equations, transformations, and symbolic manipulations. Provide a step-by-step solution."
        )
        combinatorial_instruction = (
            f"Using the extracted information: {analysis}, solve the problem using combinatorial reasoning. "
            "Consider counting principles, recursive structures, or probabilistic methods. Provide a step-by-step solution."
        )
        geometric_instruction = (
            f"Using the extracted information: {analysis}, solve the problem using geometric methods. "
            "Focus on coordinate geometry, synthetic geometry, or trigonometric relationships. Provide a step-by-step solution."
        )

        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text)
        )

        # Step 3: Intermediate Refinement - Critique and refine each solution
        refinement_instruction = (
            "Critique the provided solution for mathematical correctness, logical consistency, and alignment with the problem's constraints. "
            "Refine the solution to address any issues and ensure it is complete and rigorous."
        )
        refined_results = await asyncio.gather(
            self.revise(instruction=refinement_instruction, context=results[0]),
            self.revise(instruction=refinement_instruction, context=results[1]),
            self.revise(instruction=refinement_instruction, context=results[2])
        )

        # Step 4: Synthesis and Decision - Select the best solution
        ensemble_instruction = (
            "Compare the provided solutions and select the most rigorous, complete, and clear approach. "
            "Ensure the chosen solution satisfies all problem constraints and provides the correct answer."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_results)

        # Step 5: Final Summarization - Condense the solution into a concise format
        summarization_instruction = (
            "Summarize the final solution in a clear and concise manner. "
            "Include the key steps, reasoning, and the final answer. Ensure the summary directly addresses the problem's question."
        )
        summary = await self.summarize(instruction=summarization_instruction, context=final_solution)

        return summary