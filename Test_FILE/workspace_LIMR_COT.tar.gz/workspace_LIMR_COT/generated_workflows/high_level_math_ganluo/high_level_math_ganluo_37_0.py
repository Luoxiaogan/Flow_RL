# Workflow ID: high_level_math_ganluo_37_0
# Benchmark: high_level_math_ganluo
# Data Indices: [756, 317]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key components of the problem
        extraction_instruction = (
            "Extract all numerical values, variables, constraints, and relationships from the problem. "
            "Categorize them into groups such as 'given values', 'unknowns', 'constraints', and 'goals'. "
            "Provide a structured summary of these components."
        )
        extracted_components = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate potential solution strategies
        strategy_instruction = (
            f"Based on the extracted components: {extracted_components}, "
            "propose multiple solution strategies. Consider approaches from algebra, geometry, combinatorics, "
            "and number theory. For each strategy, outline the steps required to solve the problem."
        )
        strategies = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Execute strategies in parallel
        execution_instructions = []
        for i, strategy in enumerate(strategies.split("\n\n")):  # Assuming strategies are separated by double newlines
            execution_instructions.append(
                f"Follow this strategy to solve the problem: {strategy}. "
                "Provide a detailed step-by-step solution, ensuring all constraints are satisfied."
            )
        execution_results = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in execution_instructions]
        )

        # Step 4: Refine solutions
        refinement_tasks = []
        for result in execution_results:
            refinement_instruction = (
                f"Review this solution: {result}. Identify any errors, gaps, or areas for improvement. "
                "Ensure the solution satisfies all problem constraints and is mathematically rigorous."
            )
            refinement_tasks.append(self.revise(instruction=refinement_instruction, context=result))
        refined_solutions = await asyncio.gather(*refinement_tasks)

        # Step 5: Synthesize the best solution
        synthesis_instruction = (
            "Compare the following solutions and select the best one, or merge insights from multiple solutions "
            "if applicable. Ensure the final solution is complete, correct, and concise."
        )
        final_solution = await self.ensemble(instruction=synthesis_instruction, contexts=refined_solutions)

        # Step 6: Summarize the final solution
        summary_instruction = (
            "Condense the final solution into a clear and concise format. Include the answer and a brief explanation "
            "of how it was derived."
        )
        summarized_solution = await self.summarize(instruction=summary_instruction, context=final_solution)

        return summarized_solution