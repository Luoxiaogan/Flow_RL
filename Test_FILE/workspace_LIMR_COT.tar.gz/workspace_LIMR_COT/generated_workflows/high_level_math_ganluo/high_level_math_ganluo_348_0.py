# Workflow ID: high_level_math_ganluo_348_0
# Benchmark: high_level_math_ganluo
# Data Indices: [972, 554]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract Key Components
        extraction = await self.generate(
            instruction="Extract all numerical values, constraints, and relationships from the problem. "
                        "Identify the mathematical domain (e.g., number theory, algebra) and any specific techniques "
                        "that might be relevant (e.g., modular arithmetic, combinatorics).",
            context=self.problem_text
        )

        # Step 2: Generate Multiple Solution Approaches
        algebraic_approach = self.generate(
            instruction=f"Based on the extracted information: {extraction}, "
                        "solve the problem using algebraic methods. Provide step-by-step reasoning.",
            context=self.problem_text
        )
        combinatorial_approach = self.generate(
            instruction=f"Based on the extracted information: {extraction}, "
                        "solve the problem using combinatorial or probabilistic methods. Provide step-by-step reasoning.",
            context=self.problem_text
        )
        geometric_approach = self.generate(
            instruction=f"Based on the extracted information: {extraction}, "
                        "solve the problem using geometric or coordinate-based methods. Provide step-by-step reasoning.",
            context=self.problem_text
        )

        # Execute approaches in parallel
        results = await asyncio.gather(algebraic_approach, combinatorial_approach, geometric_approach)

        # Step 3: Revise and Validate Solutions
        revised_solutions = await asyncio.gather(
            self.revise(
                instruction="Critique this solution for logical consistency, mathematical correctness, "
                            "and adherence to the problem's constraints. Suggest improvements if necessary.",
                context=results[0]
            ),
            self.revise(
                instruction="Critique this solution for logical consistency, mathematical correctness, "
                            "and adherence to the problem's constraints. Suggest improvements if necessary.",
                context=results[1]
            ),
            self.revise(
                instruction="Critique this solution for logical consistency, mathematical correctness, "
                            "and adherence to the problem's constraints. Suggest improvements if necessary.",
                context=results[2]
            )
        )

        # Step 4: Ensemble to Select the Best Solution
        final_solution = await self.ensemble(
            instruction="Compare these solutions based on correctness, clarity, and adherence to the problem's "
                        "constraints. Select the best solution or synthesize a combined solution if appropriate.",
            contexts=revised_solutions
        )

        # Step 5: Summarize the Final Answer
        summary = await self.summarize(
            instruction="Condense the final solution into a concise answer that directly addresses the problem.",
            context=final_solution
        )

        return summary