# Workflow ID: high_level_math_ganluo_103_0
# Benchmark: high_level_math_ganluo
# Data Indices: [758, 542]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Problem Understanding and Categorization
        categorization = await self.generate(
            instruction="Analyze the problem to identify its mathematical domain (e.g., algebra, geometry, number theory) "
                        "and extract key constraints or conditions. Provide a clear summary of the problem type and requirements.",
            context=self.problem_text
        )

        # Step 2: Generate Multiple Solution Approaches
        algebraic_approach = self.generate(
            instruction=f"Based on the problem categorization: {categorization}, "
                        "develop an algebraic approach to solve the problem. Include step-by-step reasoning and any necessary calculations.",
            context=self.problem_text
        )
        geometric_approach = self.generate(
            instruction=f"Based on the problem categorization: {categorization}, "
                        "develop a geometric approach to solve the problem. Include step-by-step reasoning and any necessary diagrams or visualizations.",
            context=self.problem_text
        )
        combinatorial_approach = self.generate(
            instruction=f"Based on the problem categorization: {categorization}, "
                        "develop a combinatorial approach to solve the problem. Include step-by-step reasoning and any necessary counting strategies.",
            context=self.problem_text
        )

        # Execute approaches in parallel
        approaches = await asyncio.gather(algebraic_approach, geometric_approach, combinatorial_approach)

        # Step 3: Evaluate and Select the Best Approach
        selected_approach = await self.ensemble(
            instruction="Compare the provided solution approaches and select the most promising one. "
                        "Consider clarity, correctness, and alignment with the problem's constraints. "
                        "Provide a justification for your selection.",
            contexts=approaches
        )

        # Step 4: Refine the Selected Solution
        refined_solution = await self.revise(
            instruction="Refine the selected solution to ensure it satisfies all problem constraints and is mathematically rigorous. "
                        "Check for any errors, ambiguities, or missing steps. Improve clarity and correctness.",
            context=selected_approach
        )

        # Step 5: Summarize the Final Solution
        final_solution = await self.summarize(
            instruction="Condense the refined solution into a concise and clear format. "
                        "Include only the essential steps and the final answer.",
            context=refined_solution
        )

        return final_solution