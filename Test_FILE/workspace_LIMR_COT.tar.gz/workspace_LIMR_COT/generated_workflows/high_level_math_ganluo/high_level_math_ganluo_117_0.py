# Workflow ID: high_level_math_ganluo_117_0
# Benchmark: high_level_math_ganluo
# Data Indices: [217, 616]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all key mathematical information from the problem, including equations, constraints, "
            "numerical values, and relationships. Identify the type of problem (e.g., algebra, geometry, combinatorics)."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution paths in parallel
        path_instructions = [
            f"Solve the problem using algebraic manipulation. Utilize the following extracted information: {extracted_info}.",
            f"Solve the problem using geometric reasoning. Utilize the following extracted information: {extracted_info}.",
            f"Solve the problem using combinatorial or probabilistic methods. Utilize the following extracted information: {extracted_info}."
        ]
        results = await asyncio.gather(
            *[self.generate(instruction=path, context=self.problem_text) for path in path_instructions]
        )

        # Step 3: Synthesize and select the best solution
        ensemble_instruction = (
            "Compare the following candidate solutions and select the most appropriate one. "
            "Evaluate based on correctness, clarity, and adherence to the problem constraints."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 4: Refine the selected solution
        refinement_instruction = (
            "Critique and refine the following solution to ensure it is mathematically rigorous, "
            "clearly explained, and satisfies all problem constraints."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the final answer (optional)
        summary_instruction = "Summarize the final solution concisely, highlighting the key result."
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer