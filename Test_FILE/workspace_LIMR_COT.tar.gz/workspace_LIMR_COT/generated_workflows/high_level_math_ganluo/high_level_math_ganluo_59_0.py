# Workflow ID: high_level_math_ganluo_59_0
# Benchmark: high_level_math_ganluo
# Data Indices: [688, 80]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Problem Understanding and Decomposition
        decomposition_instruction = (
            "Analyze the problem thoroughly. Identify the mathematical domain(s) involved (e.g., algebra, geometry, combinatorics), "
            "key variables, constraints, and relationships. Structure the problem into clear components and outline potential solution strategies."
        )
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Generate Multiple Solution Paths
        solution_instruction_template = (
            "Based on the following decomposition: {decomposition}\n"
            "Generate a complete solution using the specified approach. Ensure all steps are clearly explained, "
            "and verify that the solution satisfies all constraints. If multiple cases exist, handle them systematically."
        )
        solution_instructions = [
            solution_instruction_template.format(decomposition=decomposition),
            solution_instruction_template.format(decomposition=decomposition) + " Focus on an algebraic approach.",
            solution_instruction_template.format(decomposition=decomposition) + " Focus on a geometric or combinatorial approach."
        ]
        candidate_solutions = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in solution_instructions]
        )

        # Step 3: Validate and Refine Solutions
        refinement_instruction = (
            "Critically evaluate the following solution. Check for mathematical correctness, logical consistency, "
            "and adherence to problem constraints. Suggest improvements if necessary."
        )
        refined_solutions = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction, context=solution) for solution in candidate_solutions]
        )

        # Step 4: Select the Best Solution
        selection_instruction = (
            "Compare the following solutions and select the most robust, elegant, and mathematically sound one. "
            "Ensure that edge cases and alternative interpretations are considered."
        )
        best_solution = await self.ensemble(instruction=selection_instruction, contexts=refined_solutions)

        # Step 5: Final Output
        summary_instruction = (
            "Summarize the final solution concisely while ensuring all key steps and results are included. "
            "Format the output clearly to match the problem's requirements."
        )
        final_result = await self.summarize(instruction=summary_instruction, context=best_solution)

        return final_result