# Workflow ID: high_level_math_ganluo_48_0
# Benchmark: high_level_math_ganluo
# Data Indices: [130, 880]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Problem Understanding and Decomposition
        extraction_instruction = (
            "Extract all key information from the problem, including numerical values, variables, "
            "constraints, and the type of mathematical reasoning required. Identify any special "
            "conditions or edge cases that need to be considered."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate Multiple Candidate Solutions
        generate_instruction_template = (
            f"Based on the following extracted information: {extracted_info}\n"
            "Develop a detailed solution to the problem using the specified reasoning strategy. "
            "Ensure that all constraints are satisfied and explain your steps clearly."
        )

        # Define multiple reasoning strategies
        strategies = [
            "Algebraic manipulation and equation solving",
            "Geometric interpretation and visualization",
            "Combinatorial analysis and counting techniques",
            "Number theory and modular arithmetic"
        ]

        # Generate candidate solutions in parallel
        candidate_solutions = await asyncio.gather(
            *[self.generate(instruction=generate_instruction_template.replace("specified reasoning strategy", strategy), context=self.problem_text)
              for strategy in strategies]
        )

        # Step 3: Evaluate and Synthesize Solutions
        ensemble_instruction = (
            "Compare the following candidate solutions and select the most appropriate one. "
            "Evaluate each solution based on correctness, mathematical rigor, clarity, and adherence "
            "to the problem constraints. If possible, synthesize the best aspects of multiple solutions "
            "into a single robust solution."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=candidate_solutions)

        # Step 4: Refinement and Verification
        revise_instruction = (
            "Review the following solution for mathematical accuracy, completeness, and clarity. "
            "Ensure that all constraints are satisfied and that edge cases are properly handled. "
            "Refine the solution as needed to make it more rigorous and concise."
        )
        refined_solution = await self.revise(instruction=revise_instruction, context=final_solution)

        return refined_solution