# Workflow ID: high_level_math_ganluo_36_0
# Benchmark: high_level_math_ganluo
# Data Indices: [83, 893]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract critical information from the problem
        extraction_instruction = (
            "Extract all variables, constraints, and objectives from the problem. "
            "Identify the mathematical domain (e.g., algebra, geometry, number theory). "
            "Highlight any special conditions or relationships between variables."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        approach_instructions = [
            f"Using algebraic manipulation, solve the problem based on the following information: {extracted_info}.",
            f"Using symmetry and pattern recognition, analyze the problem based on: {extracted_info}.",
            f"Using combinatorial reasoning or case analysis, break down the problem as follows: {extracted_info}."
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Refine each approach
        refinement_instruction = (
            "Critique and refine the given solution approach. "
            "Ensure all steps are mathematically valid and logically consistent. "
            "Highlight any assumptions or missing details."
        )
        refined_approaches = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction, context=approach) for approach in approaches]
        )

        # Step 4: Summarize refined approaches
        summary_instruction = (
            "Condense the refined solution approach into a concise summary. "
            "Focus on key insights, critical steps, and the final result."
        )
        summaries = await asyncio.gather(
            *[self.summarize(instruction=summary_instruction, context=approach) for approach in refined_approaches]
        )

        # Step 5: Select the best approach
        ensemble_instruction = (
            "Compare the provided solution summaries and select the most efficient and accurate approach. "
            "Ensure the chosen approach satisfies all problem constraints and provides a clear path to the solution."
        )
        best_summary = await self.ensemble(instruction=ensemble_instruction, contexts=summaries)

        # Step 6: Generate the final answer
        final_instruction = (
            f"Based on the selected approach: {best_summary}, generate the final answer. "
            "Ensure the answer is fully simplified, boxed, and satisfies all problem constraints."
        )
        final_answer = await self.generate(instruction=final_instruction, context=self.problem_text)

        return final_answer