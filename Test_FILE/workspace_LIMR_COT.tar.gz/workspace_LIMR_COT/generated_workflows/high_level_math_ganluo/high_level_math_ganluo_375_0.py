# Workflow ID: high_level_math_ganluo_375_0
# Benchmark: high_level_math_ganluo
# Data Indices: [868, 724]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key problem components
        extraction_instruction = (
            "Extract all key mathematical entities, constraints, and relationships from the problem. "
            "Identify variables, equations, geometric descriptions, or combinatorial structures. "
            "Format the output as a structured summary."
        )
        problem_components = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        algebraic_instruction = (
            f"Using the extracted components: {problem_components}, "
            "solve the problem using algebraic techniques. "
            "Include equations, substitutions, and logical steps."
        )
        combinatorial_instruction = (
            f"Using the extracted components: {problem_components}, "
            "solve the problem using combinatorial techniques. "
            "Count arrangements, paths, or probabilities as needed."
        )
        geometric_instruction = (
            f"Using the extracted components: {problem_components}, "
            "solve the problem using geometric reasoning. "
            "Include diagrams, coordinate transformations, or area/volume calculations if applicable."
        )

        # Execute approaches in parallel
        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and synthesize solutions
        ensemble_instruction = (
            "Compare the provided solutions and select the most accurate, elegant, and complete one. "
            "Ensure the chosen solution satisfies all constraints and directly answers the problem."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 4: Refine the solution if necessary
        refinement_instruction = (
            "Critique and improve the solution. Ensure all steps are clear, logical, and verifiable. "
            "Address any missing details or potential errors."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the final answer
        summary_instruction = (
            "Summarize the solution in a concise format. Include only the final answer and key insights. "
            "Ensure the response directly addresses the problem's question."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer