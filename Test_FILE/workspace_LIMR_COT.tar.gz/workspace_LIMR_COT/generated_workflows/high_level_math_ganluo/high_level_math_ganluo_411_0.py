# Workflow ID: high_level_math_ganluo_411_0
# Benchmark: high_level_math_ganluo
# Data Indices: [145, 405]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information and decompose the problem
        extract_instruction = (
            "Extract all numerical values, constraints, and relationships from the problem. "
            "Identify the mathematical domain(s) involved (e.g., algebra, geometry, number theory). "
            "Provide a structured summary of the problem's requirements."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Explore multiple solution paths in parallel
        algebra_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "solve the problem using algebraic techniques. Show all steps clearly."
        )
        combinatorics_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "solve the problem using combinatorial techniques. Show all steps clearly."
        )
        geometry_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "solve the problem using geometric techniques. Show all steps clearly."
        )

        results = await asyncio.gather(
            self.generate(instruction=algebra_instruction, context=self.problem_text),
            self.generate(instruction=combinatorics_instruction, context=self.problem_text),
            self.generate(instruction=geometry_instruction, context=self.problem_text)
        )

        # Step 3: Refine each solution
        refine_instructions = [
            "Critique and improve this solution. Ensure it is mathematically sound and satisfies all constraints.",
            "Critique and improve this solution. Ensure it is mathematically sound and satisfies all constraints.",
            "Critique and improve this solution. Ensure it is mathematically sound and satisfies all constraints."
        ]
        refined_results = await asyncio.gather(
            *[self.revise(instruction=refine_instructions[i], context=results[i]) for i in range(len(results))]
        )

        # Step 4: Select the best solution using Ensemble
        ensemble_instruction = (
            "Evaluate the following solutions and select the best one based on clarity, correctness, "
            "and adherence to the problem constraints. Provide justification for your choice."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_results)

        # Step 5: Summarize the final solution
        summarize_instruction = (
            "Condense the final solution into a concise and well-structured format. "
            "Include all key steps and the final answer."
        )
        summarized_solution = await self.summarize(instruction=summarize_instruction, context=final_solution)

        return summarized_solution