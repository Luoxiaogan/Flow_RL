# Workflow ID: high_level_math_ganluo_430_0
# Benchmark: high_level_math_ganluo
# Data Indices: [838, 97]

```python
class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Problem Understanding and Decomposition
        problem_understanding = await self.generate(
            instruction="Extract all key information, constraints, and requirements from the problem. "
                        "Identify the type of problem (e.g., combinatorics, number theory, geometry) and any "
                        "specific techniques or formulas that might be relevant. Provide a structured summary.",
            context=self.problem_text
        )

        # Step 2: Solution Approach Exploration (Parallel Execution)
        approaches = await asyncio.gather(
            self.generate(
                instruction="Solve the problem using an algebraic approach. Focus on equations, inequalities, "
                            "and transformations. Provide a step-by-step solution.",
                context=problem_understanding
            ),
            self.generate(
                instruction="Solve the problem using a combinatorial or probabilistic approach. Focus on counting, "
                            "arrangements, and probability calculations. Provide a step-by-step solution.",
                context=problem_understanding
            ),
            self.generate(
                instruction="Solve the problem using a geometric approach. Focus on shapes, areas, volumes, and "
                            "trigonometric relationships. Provide a step-by-step solution.",
                context=problem_understanding
            )
        )

        # Step 3: Evaluation and Selection of Best Approach
        best_approach = await self.ensemble(
            instruction="Compare the provided solution approaches. Evaluate each based on correctness, clarity, "
                        "simplicity, and computational feasibility. Select the best approach and explain your choice.",
            contexts=approaches
        )

        # Step 4: Detailed Solution Execution
        detailed_solution = await self.generate(
            instruction=f"Implement the selected approach step-by-step. Ensure all calculations are accurate and "
                        f"all constraints are satisfied. Provide a complete and rigorous solution. Selected approach: {best_approach}",
            context=problem_understanding
        )

        # Step 5: Verification and Refinement
        refined_solution = await self.revise(
            instruction="Verify the correctness of the solution. Check if all problem constraints are satisfied and "
                        "if the reasoning is mathematically sound. Suggest improvements if necessary.",
            context=detailed_solution
        )

        # Step 6: Final Answer Extraction
        final_answer = await self.summarize(
            instruction="Extract and format the final answer from the solution. Ensure it directly addresses the "
                        "problem and is presented concisely.",
            context=refined_solution
        )

        return final_answer
```