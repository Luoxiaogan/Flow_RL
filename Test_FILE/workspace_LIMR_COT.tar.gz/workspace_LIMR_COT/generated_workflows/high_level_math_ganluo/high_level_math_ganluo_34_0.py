# Workflow ID: high_level_math_ganluo_34_0
# Benchmark: high_level_math_ganluo
# Data Indices: [234, 764]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all numerical values, variables, relationships, constraints, "
            "and the specific question being asked from the problem. "
            "Organize this information in a structured format."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        approach_instruction = (
            f"Based on the extracted information: {extracted_info}, generate multiple detailed solution approaches. "
            "Consider algebraic, geometric, combinatorial, and number-theoretic techniques. "
            "Each approach should include step-by-step reasoning and intermediate calculations."
        )
        approaches = await self.generate(instruction=approach_instruction, context=self.problem_text)

        # Step 3: Execute approaches in parallel
        approach_list = approaches.split("\n\n")  # Assuming each approach is separated by double newlines
        parallel_tasks = [
            self.generate(instruction=f"Execute this approach step-by-step: {approach}", context=self.problem_text)
            for approach in approach_list
        ]
        results = await asyncio.gather(*parallel_tasks)

        # Step 4: Evaluate and select the best solution
        ensemble_instruction = (
            "Evaluate the provided solutions, checking their validity against the problem constraints. "
            "Select the most robust and accurate solution. If possible, synthesize parts of different solutions "
            "to create a hybrid approach."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 5: Refine the selected solution
        refinement_instruction = (
            "Critique and refine the selected solution. Ensure it satisfies all problem constraints, "
            "is mathematically sound, and is presented clearly. Simplify complex expressions if possible."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 6: Summarize the final solution
        summary_instruction = (
            "Condense the final solution into a concise, well-structured format. "
            "Highlight the key steps and present the final answer clearly."
        )
        final_output = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_output