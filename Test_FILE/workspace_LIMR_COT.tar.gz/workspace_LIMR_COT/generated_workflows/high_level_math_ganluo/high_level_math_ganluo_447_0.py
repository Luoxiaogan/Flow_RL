# Workflow ID: high_level_math_ganluo_447_0
# Benchmark: high_level_math_ganluo
# Data Indices: [377, 15]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Initial Analysis - Extract key problem elements
        analysis_instruction = (
            "Carefully analyze the problem statement and extract all key components, including variables, "
            "equations, constraints, and the target goal. Identify the mathematical domain(s) involved, such as "
            "algebra, number theory, geometry, or combinatorics. Provide a structured summary of the problem."
        )
        problem_analysis = await self.generate(instruction=analysis_instruction, context=self.problem_text)

        # Step 2: Parallel Exploration of Solution Paths
        # Define instructions for three distinct approaches
        algebraic_instruction = (
            f"Based on the problem analysis: {problem_analysis}, solve the problem using algebraic manipulation "
            "or direct computation. Show all steps clearly and justify each transformation."
        )
        modular_instruction = (
            f"Based on the problem analysis: {problem_analysis}, solve the problem using modular arithmetic or "
            "number-theoretic techniques. Highlight any patterns or symmetries that simplify the problem."
        )
        geometric_instruction = (
            f"Based on the problem analysis: {problem_analysis}, solve the problem using geometric reasoning or "
            "coordinate geometry. If applicable, include diagrams or visual representations."
        )

        # Explore approaches in parallel
        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=modular_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text)
        )

        # Step 3: Refinement - Critique and improve each solution
        refinement_instruction = (
            "Critique the provided solution for logical consistency, computational accuracy, and adherence to "
            "the problem's constraints. Suggest improvements if necessary and provide a revised version."
        )
        refined_results = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction, context=result) for result in results]
        )

        # Step 4: Final Synthesis - Select the best solution
        synthesis_instruction = (
            "Compare the following candidate solutions and select the most robust, elegant, and generalizable one. "
            "Provide a justification for your choice."
        )
        final_solution = await self.ensemble(instruction=synthesis_instruction, contexts=refined_results)

        return final_solution