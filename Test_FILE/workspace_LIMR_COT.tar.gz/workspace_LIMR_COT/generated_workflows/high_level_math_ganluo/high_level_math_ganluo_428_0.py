# Workflow ID: high_level_math_ganluo_428_0
# Benchmark: high_level_math_ganluo
# Data Indices: [709, 840]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract critical information from the problem
        extraction_instruction = (
            "Extract all numerical values, relationships, constraints, and the specific question being asked. "
            "Identify the mathematical domain(s) relevant to the problem (e.g., algebra, geometry, combinatorics). "
            "Organize the information in a structured format for further processing."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        algebra_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Solve the problem using algebraic techniques. Consider equations, inequalities, and functional relationships. "
            "Provide a detailed step-by-step solution."
        )
        geometry_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Solve the problem using geometric reasoning. Consider properties of shapes, angles, areas, and trigonometric relationships. "
            "Provide a detailed step-by-step solution."
        )
        combinatorics_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Solve the problem using combinatorial analysis. Consider counting principles, permutations, combinations, and probability. "
            "Provide a detailed step-by-step solution."
        )

        # Parallel execution of multiple solution attempts
        results = await asyncio.gather(
            self.generate(instruction=algebra_instruction, context=self.problem_text),
            self.generate(instruction=geometry_instruction, context=self.problem_text),
            self.generate(instruction=combinatorics_instruction, context=self.problem_text)
        )

        # Step 3: Refine and verify each solution
        refine_instruction_template = (
            "Critique and refine the following solution attempt. Ensure it satisfies all constraints, is mathematically sound, "
            "and addresses any edge cases. Provide a revised version with clear reasoning."
        )
        refined_solutions = await asyncio.gather(
            *[self.revise(instruction=refine_instruction_template, context=result) for result in results]
        )

        # Step 4: Synthesize the best solution
        ensemble_instruction = (
            "Evaluate and compare the following refined solutions. Select the most accurate, elegant, and complete solution. "
            "If multiple solutions are valid, choose the one that best satisfies the problem constraints."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_solutions)

        # Step 5: Extract the final answer
        summarize_instruction = (
            "Summarize the chosen solution to extract the final answer in the required format (e.g., numerical value, fraction, or expression). "
            "Ensure the answer is clearly stated and satisfies the problem's requirements."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=best_solution)

        return final_answer