# Workflow ID: high_level_math_ganluo_217_0
# Benchmark: high_level_math_ganluo
# Data Indices: [139, 796]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all numerical values, variables, constraints, and relationships from the problem. "
            "Organize the information clearly and concisely."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a solution strategy
        strategy_instruction = (
            f"Based on the extracted information: {extracted_info}, formulate a detailed solution strategy. "
            "Identify applicable mathematical techniques and outline the steps needed to solve the problem."
        )
        solution_strategy = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Explore multiple solution paths in parallel
        algebraic_instruction = (
            f"Solve the problem algebraically using the following strategy: {solution_strategy}. "
            "Provide step-by-step reasoning and calculations."
        )
        geometric_instruction = (
            f"Solve the problem geometrically using the following strategy: {solution_strategy}. "
            "Provide step-by-step reasoning and calculations."
        )
        combinatorial_instruction = (
            f"Solve the problem combinatorially using the following strategy: {solution_strategy}. "
            "Provide step-by-step reasoning and calculations."
        )

        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 4: Evaluate and select the best solution
        ensemble_instruction = (
            "Evaluate the following candidate solutions and select the best one. "
            "Consider correctness, clarity, and adherence to the problem constraints."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 5: Verify and refine the selected solution
        refinement_instruction = (
            "Critique and refine the following solution to ensure it satisfies all constraints and is mathematically sound. "
            "Make improvements where necessary."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 6: Summarize the final solution
        summary_instruction = (
            "Summarize the final solution in a concise and clear format suitable for presentation."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_summary