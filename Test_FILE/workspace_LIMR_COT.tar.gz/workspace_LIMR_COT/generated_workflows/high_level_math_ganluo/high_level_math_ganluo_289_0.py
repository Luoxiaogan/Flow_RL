# Workflow ID: high_level_math_ganluo_289_0
# Benchmark: high_level_math_ganluo
# Data Indices: [197, 553]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all key information from the problem, including variables, constants, "
            "constraints, and the specific question being asked. Organize the information clearly."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution strategies
        strategy_instructions = [
            "Develop an algebraic approach to solve the problem. Include step-by-step reasoning.",
            "Develop a geometric approach to solve the problem. Include step-by-step reasoning.",
            "Develop a combinatorial or probabilistic approach to solve the problem. Include step-by-step reasoning."
        ]
        strategies = await asyncio.gather(
            *[self.generate(instruction=instr, context=extracted_info) for instr in strategy_instructions]
        )

        # Step 3: Evaluate and select the best strategy
        ensemble_instruction = (
            "Evaluate the provided strategies based on their feasibility, alignment with the problem's constraints, "
            "and computational complexity. Select the most promising strategy and provide a justification."
        )
        selected_strategy = await self.ensemble(instruction=ensemble_instruction, contexts=strategies)

        # Step 4: Refine the selected strategy if needed
        refine_instruction = (
            "Critique the selected strategy and refine it to address any ambiguities, gaps, or inefficiencies. "
            "Ensure the strategy is clear, precise, and actionable."
        )
        refined_strategy = await self.revise(instruction=refine_instruction, context=selected_strategy)

        # Step 5: Execute the refined strategy
        execution_instruction = (
            f"Using the refined strategy: {refined_strategy}, solve the problem step-by-step. "
            "Ensure all calculations are accurate and all reasoning is explained clearly. "
            "Format the solution neatly, including intermediate steps and the final answer."
        )
        solution = await self.generate(instruction=execution_instruction, context=extracted_info)

        # Step 6: Summarize the solution
        summarize_instruction = (
            "Condense the solution into a concise final answer. Ensure the answer satisfies all problem constraints "
            "and is presented in a clear, professional format."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=solution)

        return final_answer