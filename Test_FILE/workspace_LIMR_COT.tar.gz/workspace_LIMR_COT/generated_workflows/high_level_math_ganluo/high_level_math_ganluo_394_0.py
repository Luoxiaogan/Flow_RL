# Workflow ID: high_level_math_ganluo_394_0
# Benchmark: high_level_math_ganluo
# Data Indices: [774, 144]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information and decompose the problem
        decomposition = await self.generate(
            instruction="Analyze the problem and identify its type (e.g., combinatorics, number theory, algebra, geometry). "
                        "Extract all numerical values, constraints, and the desired output format. "
                        "Provide a structured breakdown of the problem.",
            context=self.problem_text
        )

        # Step 2: Explore multiple solution paths in parallel
        algebraic_solution = self.generate(
            instruction=f"Using algebraic methods, solve the problem step by step. "
                        f"Ensure all constraints from the following decomposition are satisfied: {decomposition}.",
            context=self.problem_text
        )
        geometric_solution = self.generate(
            instruction=f"Using geometric reasoning, solve the problem step by step. "
                        f"Ensure all constraints from the following decomposition are satisfied: {decomposition}.",
            context=self.problem_text
        )
        combinatorial_solution = self.generate(
            instruction=f"Using combinatorial or probabilistic methods, solve the problem step by step. "
                        f"Ensure all constraints from the following decomposition are satisfied: {decomposition}.",
            context=self.problem_text
        )
        solutions = await asyncio.gather(algebraic_solution, geometric_solution, combinatorial_solution)

        # Step 3: Refine and validate each solution
        refined_solutions = await asyncio.gather(
            self.revise(
                instruction="Critique and refine the solution. Check for mathematical correctness, "
                            "adherence to constraints, and logical consistency. "
                            "Suggest improvements if necessary.",
                context=solutions[0]
            ),
            self.revise(
                instruction="Critique and refine the solution. Check for mathematical correctness, "
                            "adherence to constraints, and logical consistency. "
                            "Suggest improvements if necessary.",
                context=solutions[1]
            ),
            self.revise(
                instruction="Critique and refine the solution. Check for mathematical correctness, "
                            "adherence to constraints, and logical consistency. "
                            "Suggest improvements if necessary.",
                context=solutions[2]
            )
        )

        # Step 4: Synthesize and select the best solution
        final_solution = await self.ensemble(
            instruction="Compare the refined solutions and select the best one. "
                        "Criteria for selection include correctness, clarity, efficiency, and adherence to problem constraints. "
                        "Provide a justification for your choice.",
            contexts=refined_solutions
        )

        # Step 5: Prepare the final output
        summary = await self.summarize(
            instruction="Condense the final solution into a concise, well-structured format. "
                        "Ensure the output is clear, accurate, and adheres to AIME standards.",
            context=final_solution
        )

        return summary