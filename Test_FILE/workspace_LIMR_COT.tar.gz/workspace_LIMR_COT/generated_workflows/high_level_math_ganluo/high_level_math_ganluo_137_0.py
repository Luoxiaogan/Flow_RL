# Workflow ID: high_level_math_ganluo_137_0
# Benchmark: high_level_math_ganluo
# Data Indices: [469, 369]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all numerical values, geometric relationships, constraints, and the goal from the problem. "
            "Organize the information into categories: known values, unknowns, relationships, and constraints."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        approach_instructions = [
            f"Using the extracted information: {extracted_info}, solve the problem using an algebraic approach. "
            "Include all steps, formulas, and reasoning.",
            
            f"Using the extracted information: {extracted_info}, solve the problem using a geometric approach. "
            "Include all steps, diagrams (if applicable), and reasoning.",
            
            f"Using the extracted information: {extracted_info}, solve the problem using a combinatorial or probabilistic approach. "
            "Include all steps, counting methods, and reasoning."
        ]
        approaches = await asyncio.gather(
            *(self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions)
        )

        # Step 3: Refine each approach
        refine_instructions = [
            f"Critique and improve the following solution approach: {approach}. "
            "Ensure all steps are logically consistent, calculations are correct, and constraints are satisfied."
            for approach in approaches
        ]
        refined_approaches = await asyncio.gather(
            *(self.revise(instruction=instr, context=approach) for instr, approach in zip(refine_instructions, approaches))
        )

        # Step 4: Select the best approach using Ensemble
        ensemble_instruction = (
            "Compare the following refined approaches and select the best one. "
            "Criteria for selection: simplicity, computational feasibility, adherence to constraints, and handling of edge cases. "
            "Provide a justification for your choice."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_approaches)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the following solution into a concise and clear format. "
            "Ensure the output directly addresses the problem's requirements and is easy to understand."
        )
        final_output = await self.summarize(instruction=summary_instruction, context=best_solution)

        return final_output