# Workflow ID: high_level_math_ganluo_19_0
# Benchmark: high_level_math_ganluo
# Data Indices: [802, 612]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key components from the problem
        extraction_instruction = (
            "Extract all key mathematical components, including variables, equations, constraints, and relationships. "
            "Identify any hidden structures or patterns that could simplify the problem. "
            "Ensure the extraction is comprehensive and includes all necessary information for solving the problem."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        approach_instruction_template = (
            f"Using the extracted information: {extracted_info}, generate a detailed solution approach based on the following strategy: {{strategy}}. "
            "Ensure the approach is mathematically rigorous and adheres to the problem constraints."
        )
        strategies = [
            "Algebraic manipulation and simplification",
            "Geometric reasoning and visualization",
            "Combinatorial analysis and counting techniques"
        ]
        approach_instructions = [approach_instruction_template.format(strategy=strategy) for strategy in strategies]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Evaluate and select the best approach
        evaluation_instruction = (
            "Evaluate the provided solution approaches based on correctness, mathematical rigor, simplicity, and adherence to problem constraints. "
            "Select the best approach and provide a justification for your choice."
        )
        best_approach = await self.ensemble(instruction=evaluation_instruction, contexts=approaches)

        # Step 4: Verify and refine the selected solution
        refinement_instruction = (
            "Verify that the selected solution satisfies all problem constraints and is mathematically correct. "
            "Refine the solution if necessary to ensure clarity and precision."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_approach)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Summarize the final solution in a concise and clear format. "
            "Include all key steps and results while omitting unnecessary details."
        )
        final_solution = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_solution