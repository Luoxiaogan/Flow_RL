# Workflow ID: high_level_math_ganluo_229_0
# Benchmark: high_level_math_ganluo
# Data Indices: [346, 68]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract problem structure and key components
        extraction_instruction = (
            "Carefully analyze the given problem. Identify all variables, equations, constraints, "
            "and the specific goal. Organize this information clearly and concisely."
        )
        problem_structure = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        approach_1_instruction = (
            f"Based on the extracted problem structure:\n{problem_structure}\n"
            "Solve the problem using algebraic manipulation. Show all steps clearly, "
            "including substitutions, simplifications, and intermediate results."
        )
        approach_2_instruction = (
            f"Based on the extracted problem structure:\n{problem_structure}\n"
            "Solve the problem using geometric reasoning or coordinate geometry if applicable. "
            "Clearly explain any transformations or assumptions made."
        )
        approach_3_instruction = (
            f"Based on the extracted problem structure:\n{problem_structure}\n"
            "Solve the problem using combinatorial or probabilistic methods if applicable. "
            "Enumerate cases systematically and justify each step."
        )

        results = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text),
            self.generate(instruction=approach_3_instruction, context=self.problem_text)
        )

        # Step 3: Refine each candidate solution
        refinement_instruction = (
            "Critically review the provided solution. Check for correctness, logical consistency, "
            "and adherence to the problem's constraints. Improve clarity and formatting as needed."
        )
        refined_results = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction, context=result) for result in results]
        )

        # Step 4: Select the best solution or synthesize results
        ensemble_instruction = (
            "Evaluate the provided solutions. Select the most accurate, elegant, and complete solution. "
            "If multiple solutions are valid, synthesize them into a single cohesive answer."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_results)

        # Step 5: Prepare the final output
        summary_instruction = (
            "Condense the final solution into a concise and clear format. Ensure it directly answers "
            "the problem's question and adheres to any specified output requirements."
        )
        final_output = await self.summarize(instruction=summary_instruction, context=final_solution)

        return final_output