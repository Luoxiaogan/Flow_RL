# Workflow ID: high_level_math_ganluo_180_0
# Benchmark: high_level_math_ganluo
# Data Indices: [474, 821]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Problem Decomposition
        decomposition_instruction = (
            "Analyze the problem to identify its core components, including mathematical concepts, "
            "constraints, and the goal. Provide a structured breakdown of the problem."
        )
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Generate Multiple Approaches
        approach_instructions = [
            "Develop an algebraic approach to solve the problem. Include step-by-step reasoning.",
            "Develop a geometric approach to solve the problem. Include step-by-step reasoning.",
            "Develop a combinatorial or probabilistic approach to solve the problem. Include step-by-step reasoning."
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=decomposition) for instr in approach_instructions]
        )

        # Step 3: Analyze and Refine Approaches
        refine_instruction_template = (
            "Critique and refine the following approach. Ensure it adheres to the problem's constraints, "
            "is mathematically sound, and leads to a complete solution. Provide detailed feedback."
        )
        refined_approaches = await asyncio.gather(
            *[self.revise(instruction=refine_instruction_template, context=approach) for approach in approaches]
        )

        # Step 4: Ensemble Decision
        ensemble_instruction = (
            "Compare the following approaches and select the most robust, efficient, and accurate solution. "
            "Provide a justification for your choice."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_approaches)

        # Step 5: Final Verification
        summarize_instruction = (
            "Summarize the chosen solution, ensuring it satisfies all problem constraints and provides a "
            "clear, concise answer. Highlight the key steps and reasoning."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=best_solution)

        return final_answer