# Workflow ID: high_level_math_ganluo_17_0
# Benchmark: high_level_math_ganluo
# Data Indices: [368, 141]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Decompose the problem into key components
        decomposition_instruction = """
        Analyze the problem statement and extract all key components, including:
        - Variables and their relationships
        - Constraints and conditions
        - Implicit or explicit mathematical structures
        - Any special properties or symmetries
        Organize these components clearly for further processing.
        """
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        algebraic_instruction = f"""
        Using the following decomposition: {decomposition}
        Solve the problem using algebraic techniques. This may include:
        - Setting up equations or inequalities
        - Applying transformations or substitutions
        - Leveraging polynomial properties or functional equations
        Ensure all steps are justified and constraints are satisfied.
        """
        combinatorial_instruction = f"""
        Using the following decomposition: {decomposition}
        Solve the problem using combinatorial or probabilistic techniques. This may include:
        - Counting arrangements or permutations
        - Calculating probabilities or expected values
        - Using recursive formulas or generating functions
        Ensure all steps are justified and constraints are satisfied.
        """
        geometric_instruction = f"""
        Using the following decomposition: {decomposition}
        Solve the problem using geometric techniques. This may include:
        - Coordinate geometry or synthetic geometry
        - Area/volume calculations or trigonometric relationships
        - Exploiting symmetry or geometric transformations
        Ensure all steps are justified and constraints are satisfied.
        """

        # Execute approaches in parallel
        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text)
        )

        # Step 3: Revise and validate the generated solutions
        revise_instruction = """
        Critique the provided solution and ensure it satisfies all problem constraints:
        - Verify all steps are logically sound
        - Check for computational errors or oversights
        - Confirm the solution adheres to the problem's requirements
        Provide a revised version if necessary.
        """
        revised_results = await asyncio.gather(
            *[self.revise(instruction=revise_instruction, context=result) for result in results]
        )

        # Step 4: Summarize key insights from each approach
        summarize_instruction = """
        Condense the solution into a concise summary that highlights:
        - The main approach used
        - Key insights or breakthroughs
        - Final result or conclusion
        Ensure the summary is clear and actionable.
        """
        summaries = await asyncio.gather(
            *[self.summarize(instruction=summarize_instruction, context=result) for result in revised_results]
        )

        # Step 5: Ensemble to select the best solution
        ensemble_instruction = """
        Evaluate the provided summaries and select the best solution based on:
        - Clarity and simplicity
        - Adherence to problem constraints
        - Mathematical elegance and correctness
        Provide the final solution with justification.
        """
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=summaries)

        return final_solution