# Workflow ID: high_level_math_ganluo_412_0
# Benchmark: high_level_math_ganluo
# Data Indices: [427, 491]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information and understand the problem
        extraction_instruction = (
            "Extract all numerical values, constraints, and relationships from the problem. "
            "Identify the type of mathematical problem (e.g., algebraic, geometric, combinatorial). "
            "Provide a structured summary of the key components."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Decompose the problem into sub-problems
        decomposition_instruction = (
            f"Based on the extracted information: {extracted_info}, "
            "decompose the problem into smaller sub-problems or cases. "
            "For each sub-problem, outline the approach needed to solve it. "
            "Consider different mathematical techniques that could apply."
        )
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 3: Explore multiple solution approaches in parallel
        approach_1_instruction = (
            f"Solve the problem using an algebraic or number-theoretic approach. "
            f"Key information: {extracted_info}. Decomposition: {decomposition}. "
            "Ensure all constraints are satisfied."
        )
        approach_2_instruction = (
            f"Solve the problem using a combinatorial or probabilistic approach. "
            f"Key information: {extracted_info}. Decomposition: {decomposition}. "
            "Ensure all constraints are satisfied."
        )
        approach_3_instruction = (
            f"Solve the problem using a geometric or trigonometric approach. "
            f"Key information: {extracted_info}. Decomposition: {decomposition}. "
            "Ensure all constraints are satisfied."
        )

        results = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text),
            self.generate(instruction=approach_3_instruction, context=self.problem_text)
        )

        # Step 4: Synthesize or select the best solution
        synthesis_instruction = (
            "Evaluate the provided solutions and select the most accurate and complete one. "
            "If multiple solutions are valid, synthesize them into a single coherent solution. "
            "Ensure the final solution satisfies all constraints and is mathematically rigorous."
        )
        final_solution = await self.ensemble(instruction=synthesis_instruction, contexts=results)

        # Step 5: Refine and verify the final solution
        refinement_instruction = (
            "Critique the final solution for correctness, clarity, and completeness. "
            "Check for edge cases and ensure all constraints are satisfied. "
            "Simplify the solution if possible."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=final_solution)

        # Step 6: Format the solution for output
        formatting_instruction = (
            "Format the solution clearly and concisely. "
            "Ensure it adheres to the problem's requirements and is easy to understand."
        )
        formatted_solution = await self.generate(instruction=formatting_instruction, context=refined_solution)

        return formatted_solution