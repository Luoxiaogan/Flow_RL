# Workflow ID: high_level_math_ganluo_343_0
# Benchmark: high_level_math_ganluo
# Data Indices: [660, 889]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem text
        extraction_instruction = (
            "Extract all key numerical values, constraints, and relationships from the problem. "
            "Identify any hidden structures or patterns that might guide the solution process. "
            "Provide this information in a structured format."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Summarize the extracted information for clarity
        summary_instruction = (
            "Condense the extracted information into a concise summary. "
            "Focus on the essential elements needed to solve the problem."
        )
        summarized_info = await self.summarize(instruction=summary_instruction, context=extracted_info)

        # Step 3: Explore multiple solution paths in parallel
        algebraic_instruction = (
            f"Using the following information: {summarized_info}, "
            "solve the problem using algebraic techniques. "
            "Include step-by-step reasoning and intermediate results."
        )
        geometric_instruction = (
            f"Using the following information: {summarized_info}, "
            "solve the problem using geometric techniques. "
            "Include step-by-step reasoning and intermediate results."
        )
        combinatorial_instruction = (
            f"Using the following information: {summarized_info}, "
            "solve the problem using combinatorial techniques. "
            "Include step-by-step reasoning and intermediate results."
        )

        # Parallel execution for different approaches
        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 4: Evaluate and select the best solution path
        ensemble_instruction = (
            "Evaluate the following candidate solutions. "
            "Select the most promising approach based on mathematical rigor, completeness, and adherence to the problem's constraints. "
            "Provide justification for your selection."
        )
        selected_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 5: Refine the selected solution
        refinement_instruction = (
            "Refine the selected solution to ensure it is complete, accurate, and well-structured. "
            "Verify that it satisfies all constraints and conditions of the problem."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=selected_solution)

        # Step 6: Summarize the final solution
        final_summary_instruction = (
            "Summarize the refined solution into a clear and concise final answer. "
            "Ensure the answer directly addresses the problem's question."
        )
        final_answer = await self.summarize(instruction=final_summary_instruction, context=refined_solution)

        return final_answer