# Workflow ID: high_level_math_ganluo_114_0
# Benchmark: high_level_math_ganluo
# Data Indices: [562, 876]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key components of the problem
        extraction_instruction = (
            "Extract all key components of the problem, including equations, constraints, variables, "
            "and any specific requirements. Identify the mathematical domain (e.g., algebra, geometry, number theory)."
        )
        problem_components = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        algebraic_instruction = (
            f"Given the problem components: {problem_components}, solve the problem using algebraic methods. "
            "Include step-by-step reasoning and verify intermediate results."
        )
        geometric_instruction = (
            f"Given the problem components: {problem_components}, interpret the problem geometrically if applicable. "
            "Provide a visual or spatial reasoning approach."
        )
        combinatorial_instruction = (
            f"Given the problem components: {problem_components}, explore combinatorial or recursive reasoning. "
            "Consider counting principles, generating functions, or recurrence relations."
        )

        # Execute approaches in parallel
        approaches = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and synthesize the best approach
        ensemble_instruction = (
            "Compare the following solution approaches and select the most rigorous and complete one. "
            "If multiple approaches are valid, synthesize them into a unified solution."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=approaches)

        # Step 4: Refine the chosen solution
        refine_instruction = (
            "Critique and refine the following solution to ensure mathematical rigor, correctness, "
            "and clarity. Address any gaps or ambiguities."
        )
        refined_solution = await self.revise(instruction=refine_instruction, context=best_solution)

        # Step 5: Summarize the final answer
        summarize_instruction = (
            "Condense the following solution into a concise and clear final answer. "
            "Ensure it directly addresses the problem and satisfies all constraints."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_answer