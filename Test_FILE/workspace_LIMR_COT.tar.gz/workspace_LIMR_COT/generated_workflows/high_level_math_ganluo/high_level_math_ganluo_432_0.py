# Workflow ID: high_level_math_ganluo_432_0
# Benchmark: high_level_math_ganluo
# Data Indices: [481, 294]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key components of the problem
        extraction_instruction = (
            "Extract all key components of the problem, including variables, constants, "
            "constraints, relationships, and any special conditions. Organize the extracted "
            "information into a structured format for further analysis."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple candidate solutions in parallel
        candidate_instructions = [
            f"Using an algebraic approach, solve the problem based on the following extracted information: {extracted_info}",
            f"Using a geometric approach, solve the problem based on the following extracted information: {extracted_info}",
            f"Using combinatorial or number-theoretic reasoning, solve the problem based on the following extracted information: {extracted_info}"
        ]
        candidate_solutions = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in candidate_instructions]
        )

        # Step 3: Refine each candidate solution
        refinement_instructions = [
            "Critique and improve the following solution by checking for mathematical rigor, "
            "logical consistency, and adherence to the problem constraints. Ensure all edge cases are considered.",
            "Critique and improve the following solution by verifying calculations, simplifying expressions, "
            "and ensuring alignment with the extracted problem information.",
            "Critique and improve the following solution by focusing on clarity, correctness, and completeness."
        ]
        refined_solutions = await asyncio.gather(
            *[self.revise(instruction=refinement_instructions[i], context=candidate_solutions[i]) 
              for i in range(len(candidate_solutions))]
        )

        # Step 4: Synthesize the best solution
        synthesis_instruction = (
            "Evaluate the following candidate solutions and select the best one based on correctness, "
            "simplicity, and alignment with the problem constraints. If multiple solutions are valid, "
            "combine their insights into a unified answer."
        )
        final_solution = await self.ensemble(instruction=synthesis_instruction, contexts=refined_solutions)

        # Step 5: Prepare the final output
        summary_instruction = (
            "Summarize the final solution in a concise and professional format. Ensure all steps are clearly "
            "explained, and the answer is boxed or highlighted for easy identification."
        )
        final_output = await self.summarize(instruction=summary_instruction, context=final_solution)

        return final_output