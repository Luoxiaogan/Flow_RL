# Workflow ID: high_level_math_ganluo_71_0
# Benchmark: high_level_math_ganluo
# Data Indices: [822, 290]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all key information from the problem, including variables, constraints, "
            "and the desired output. Identify any mathematical structures or patterns that could "
            "guide the solution process."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        approach_instructions = [
            f"Using the extracted information: {extracted_info}, develop an algebraic solution to the problem.",
            f"Using the extracted information: {extracted_info}, develop a combinatorial or probabilistic solution to the problem.",
            f"Using the extracted information: {extracted_info}, develop a geometric or visual solution to the problem."
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Refine and validate each approach
        refinement_instruction = (
            "Critique and refine the given solution. Ensure all constraints are satisfied, simplify expressions, "
            "and verify correctness. Identify any edge cases or missing details."
        )
        refined_approaches = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction, context=approach) for approach in approaches]
        )

        # Step 4: Ensemble decision-making
        ensemble_instruction = (
            "Compare the provided solutions and select the most robust, efficient, and mathematically sound approach. "
            "If possible, synthesize elements from multiple solutions to create a superior result."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_approaches)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the final solution into a concise, well-structured format. Ensure clarity and readability "
            "for the end user."
        )
        final_output = await self.summarize(instruction=summary_instruction, context=final_solution)

        return final_output