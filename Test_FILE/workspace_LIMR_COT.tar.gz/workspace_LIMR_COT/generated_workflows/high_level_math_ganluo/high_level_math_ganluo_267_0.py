# Workflow ID: high_level_math_ganluo_267_0
# Benchmark: high_level_math_ganluo
# Data Indices: [71, 480]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information and understand the problem
        extraction_instruction = (
            "Thoroughly analyze the problem statement. Identify all variables, constraints, "
            "and objectives. Determine the mathematical domain (e.g., algebra, combinatorics, geometry). "
            "Provide a structured breakdown of the problem."
        )
        problem_analysis = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution attempts in parallel
        solution_attempt_1_instruction = (
            f"Using the following problem analysis: {problem_analysis}\n"
            "Attempt to solve the problem using an algebraic approach. Focus on equations, inequalities, "
            "and transformations. Provide a detailed step-by-step solution."
        )
        solution_attempt_2_instruction = (
            f"Using the following problem analysis: {problem_analysis}\n"
            "Attempt to solve the problem using a combinatorial or number-theoretic approach. "
            "Focus on counting principles, modular arithmetic, or recursive structures. "
            "Provide a detailed step-by-step solution."
        )
        solution_attempts = await asyncio.gather(
            self.generate(instruction=solution_attempt_1_instruction, context=self.problem_text),
            self.generate(instruction=solution_attempt_2_instruction, context=self.problem_text)
        )

        # Step 3: Refine each solution attempt
        refinement_instruction = (
            "Critically review the provided solution attempt. Check for mathematical correctness, "
            "logical consistency, and adherence to all constraints. Simplify where possible and "
            "address any edge cases or boundary conditions."
        )
        refined_solutions = await asyncio.gather(
            self.revise(instruction=refinement_instruction, context=solution_attempts[0]),
            self.revise(instruction=refinement_instruction, context=solution_attempts[1])
        )

        # Step 4: Ensemble decision-making to select the best solution
        ensemble_instruction = (
            "Compare the following refined solutions and select the most robust and elegant one. "
            "Ensure the chosen solution satisfies all problem constraints and is mathematically rigorous. "
            "If possible, synthesize insights from both solutions."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_solutions)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the final solution into a clear and concise format. Retain all critical details "
            "and ensure the solution is easy to interpret."
        )
        summarized_solution = await self.summarize(instruction=summary_instruction, context=final_solution)

        return summarized_solution