# Workflow ID: high_level_math_ganluo_108_0
# Benchmark: high_level_math_ganluo
# Data Indices: [681, 305]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information and identify problem type
        extraction_instruction = (
            "Extract all key numerical values, variables, and relationships from the problem. "
            "Identify the mathematical domain (e.g., algebra, geometry, combinatorics) and any specific techniques required. "
            "Format the output as a structured summary."
        )
        problem_analysis = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution paths in parallel
        algebraic_instruction = (
            f"Using the following analysis: {problem_analysis}\n"
            "Solve the problem using algebraic methods. Include all steps, transformations, and intermediate results. "
            "Ensure the solution satisfies all constraints and conditions."
        )
        geometric_instruction = (
            f"Using the following analysis: {problem_analysis}\n"
            "Solve the problem using geometric reasoning. Include diagrams (if applicable), formulas, and logical deductions. "
            "Ensure the solution satisfies all constraints and conditions."
        )
        combinatorial_instruction = (
            f"Using the following analysis: {problem_analysis}\n"
            "Solve the problem using combinatorial or probabilistic methods. Include counting principles, recursive structures, "
            "and any relevant theorems. Ensure the solution satisfies all constraints and conditions."
        )

        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and synthesize the best solution
        ensemble_instruction = (
            "Compare the following candidate solutions and select the most accurate, complete, and elegant one. "
            "Provide justification for your choice and highlight any errors or shortcomings in the alternatives."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 4: Refine the chosen solution if necessary
        refinement_instruction = (
            "Review the following solution for correctness, clarity, and completeness. "
            "Revise any ambiguous or incorrect parts, ensuring all steps are logically sound and well-explained."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=final_solution)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the following solution into a concise, well-structured format. "
            "Include only the essential steps and final answer, ensuring clarity and correctness."
        )
        final_output = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_output