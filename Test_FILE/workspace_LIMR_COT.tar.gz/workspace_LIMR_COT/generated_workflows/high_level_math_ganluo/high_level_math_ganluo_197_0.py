# Workflow ID: high_level_math_ganluo_197_0
# Benchmark: high_level_math_ganluo
# Data Indices: [150, 940]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract and Understand the Problem
        extraction_instruction = (
            "Carefully analyze the problem statement to identify key components such as equations, variables, "
            "constraints, and the specific question being asked. Categorize the problem into one of the following "
            "domains: algebra, geometry, combinatorics, number theory, or cross-domain. Provide a clear summary of "
            "the problem's structure and requirements."
        )
        problem_summary = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate Multiple Solution Strategies
        strategy_instruction = (
            f"Based on the problem summary: {problem_summary}, propose multiple solution strategies. "
            "For example, consider algebraic manipulation, recursive formulas, geometric interpretations, "
            "or combinatorial techniques. Ensure each strategy is detailed and mathematically sound."
        )
        strategies = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Parallel Execution of Solution Paths
        solution_paths = strategies.split("\n\n")  # Assume strategies are separated by double newlines
        solution_tasks = [
            self.generate(
                instruction=f"Follow this solution strategy step-by-step: {path}",
                context=self.problem_text
            )
            for path in solution_paths
        ]
        candidate_solutions = await asyncio.gather(*solution_tasks)

        # Step 4: Evaluate and Select the Best Solution
        evaluation_instruction = (
            "Compare the following candidate solutions and select the most mathematically sound and efficient one. "
            "Ensure the chosen solution satisfies all constraints and conditions specified in the problem."
        )
        best_solution = await self.ensemble(instruction=evaluation_instruction, contexts=candidate_solutions)

        # Step 5: Refine the Selected Solution
        refinement_instruction = (
            "Critique and refine the following solution to ensure clarity, correctness, and mathematical rigor. "
            "Address any ambiguities or gaps in reasoning."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 6: Summarize the Final Solution
        summary_instruction = (
            "Condense the following solution into a concise, well-structured format suitable for submission. "
            "Include all key steps and the final answer."
        )
        final_solution = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_solution