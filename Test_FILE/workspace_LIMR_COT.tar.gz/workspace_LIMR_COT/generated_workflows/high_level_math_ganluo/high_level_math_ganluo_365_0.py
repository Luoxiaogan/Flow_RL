# Workflow ID: high_level_math_ganluo_365_0
# Benchmark: high_level_math_ganluo
# Data Indices: [356, 184]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract critical information from the problem
        extraction_instruction = """
        Analyze the problem text thoroughly and extract all relevant information:
        - Known values, variables, and constants
        - Relationships, equations, or constraints
        - The specific question or goal
        Ensure all extracted information is explicitly stated and categorized.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Propose multiple solution strategies
        strategy_instruction = f"""
        Based on the extracted information: {extracted_info}
        Propose multiple distinct solution strategies. Consider approaches such as:
        - Algebraic manipulation
        - Geometric reasoning
        - Combinatorial analysis
        - Number theory techniques
        For each strategy, provide a detailed plan of action, including intermediate steps and expected outcomes.
        """
        strategies = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Execute strategies in parallel
        execution_instruction_template = """
        Follow the provided strategy step by step to solve the problem. Ensure all calculations are accurate,
        and verify that the solution satisfies all constraints and conditions. Present the final answer clearly.
        """
        strategy_list = strategies.split("\n\n")  # Assuming strategies are separated by double newlines
        tasks = [
            self.generate(instruction=execution_instruction_template, context=strategy)
            for strategy in strategy_list
        ]
        results = await asyncio.gather(*tasks)

        # Step 4: Evaluate and select the best solution
        evaluation_instruction = """
        Compare the provided solutions based on the following criteria:
        - Correctness: Does the solution satisfy all constraints and conditions?
        - Completeness: Are all parts of the problem addressed?
        - Mathematical rigor: Is the reasoning sound and well-supported?
        Select the best solution and justify your choice.
        """
        best_solution = await self.ensemble(instruction=evaluation_instruction, contexts=results)

        # Step 5: Refine the selected solution
        refinement_instruction = """
        Review the selected solution and refine it as needed:
        - Ensure all steps are clear and logically connected
        - Verify calculations and eliminate any errors
        - Format the final answer appropriately (e.g., simplest radical form, exact values)
        """
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        return refined_solution