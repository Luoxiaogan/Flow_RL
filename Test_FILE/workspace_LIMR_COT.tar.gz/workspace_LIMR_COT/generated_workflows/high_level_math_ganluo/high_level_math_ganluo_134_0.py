# Workflow ID: high_level_math_ganluo_134_0
# Benchmark: high_level_math_ganluo
# Data Indices: [247, 978]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key components of the problem
        extraction_instruction = (
            "Identify and extract all key components of the problem, including variables, equations, "
            "constraints, relationships, and any other relevant information. Organize the extracted "
            "information in a structured format for further analysis."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Analyze the problem and generate a solution strategy
        analysis_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Analyze the problem systematically. Determine the type of problem (e.g., algebraic, geometric, combinatorial) "
            "and propose a detailed plan for solving it. Include potential techniques, formulas, and reasoning steps."
        )
        solution_strategy = await self.generate(instruction=analysis_instruction, context=self.problem_text)

        # Step 3: Generate multiple candidate solutions in parallel
        candidate_instructions = [
            (
                f"Using the following solution strategy:\n{solution_strategy}\n"
                "Solve the problem using an algebraic approach. Show all steps and calculations clearly."
            ),
            (
                f"Using the following solution strategy:\n{solution_strategy}\n"
                "Solve the problem using a geometric approach. Show all steps and calculations clearly."
            ),
            (
                f"Using the following solution strategy:\n{solution_strategy}\n"
                "Solve the problem using a combinatorial or number-theoretic approach. Show all steps and calculations clearly."
            )
        ]
        candidate_solutions = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in candidate_instructions]
        )

        # Step 4: Evaluate and synthesize the best solution
        ensemble_instruction = (
            "Evaluate the following candidate solutions and select the most robust and efficient one. "
            "Ensure that the chosen solution satisfies all constraints and is mathematically rigorous. "
            "If necessary, synthesize elements from multiple candidates to form a complete solution."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=candidate_solutions)

        # Step 5: Refine the chosen solution
        refinement_instruction = (
            "Critique and refine the following solution to ensure it is clear, concise, and mathematically sound. "
            "Correct any errors, fill gaps in reasoning, and improve formatting if needed."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 6: Summarize the final solution
        summary_instruction = (
            "Summarize the following solution in a concise and clear format. Include only the key steps "
            "and the final answer, ensuring that the result is easy to understand."
        )
        final_output = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_output