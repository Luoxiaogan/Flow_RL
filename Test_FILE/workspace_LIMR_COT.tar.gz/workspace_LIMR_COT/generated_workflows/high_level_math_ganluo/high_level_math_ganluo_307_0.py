# Workflow ID: high_level_math_ganluo_307_0
# Benchmark: high_level_math_ganluo
# Data Indices: [967, 345]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information and decompose the problem
        decomposition_instruction = (
            "Analyze the problem to identify its domain (e.g., algebra, geometry, number theory), "
            "key variables, constraints, and what is being asked. Provide a structured breakdown."
        )
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution paths in parallel
        algebraic_instruction = (
            f"Based on the decomposition: {decomposition}, solve the problem using algebraic methods. "
            "Provide a step-by-step solution."
        )
        geometric_instruction = (
            f"Based on the decomposition: {decomposition}, solve the problem using geometric reasoning. "
            "Provide a step-by-step solution."
        )
        modular_instruction = (
            f"Based on the decomposition: {decomposition}, solve the problem using modular arithmetic or number theory. "
            "Provide a step-by-step solution."
        )

        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=modular_instruction, context=self.problem_text)
        )

        # Step 3: Refine each solution for correctness and clarity
        refine_instruction = (
            "Critique and improve the following solution to ensure it is mathematically rigorous, "
            "logically consistent, and adheres to the problem's constraints."
        )
        refined_results = await asyncio.gather(
            *[self.revise(instruction=refine_instruction, context=result) for result in results]
        )

        # Step 4: Ensemble decision-making to select the best solution
        ensemble_instruction = (
            "Evaluate the following solutions and select the best one based on correctness, simplicity, "
            "and alignment with the problem's requirements. If possible, synthesize insights from multiple solutions."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_results)

        # Step 5: Summarize the final solution to extract the answer
        summarize_instruction = (
            "Extract the final answer from the solution, ensuring it is in the required format (e.g., numerical value, symbolic expression)."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=final_solution)

        return final_answer