# Workflow ID: high_level_math_ganluo_148_0
# Benchmark: high_level_math_ganluo
# Data Indices: [971, 936]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Problem Decomposition
        decomposition_instruction = (
            "Analyze the problem thoroughly. Identify all variables, constants, constraints, "
            "and relationships. Highlight any special conditions or edge cases. "
            "Provide a structured breakdown of the problem."
        )
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Strategy Formulation
        strategy_instruction = (
            f"Based on the following problem decomposition:\n{decomposition}\n"
            "Formulate potential solution strategies. Consider algebraic, geometric, combinatorial, "
            "and number-theoretic approaches. Outline each strategy step-by-step."
        )
        strategies = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Parallel Exploration of Solution Paths
        # Split strategies into individual approaches
        strategy_list = strategies.split("\n\n")  # Assuming each strategy is separated by double newlines
        parallel_tasks = [
            self.generate(
                instruction=f"Solve the problem using the following strategy:\n{strategy}",
                context=self.problem_text
            )
            for strategy in strategy_list
        ]
        solutions = await asyncio.gather(*parallel_tasks)

        # Step 4: Evaluation and Selection
        ensemble_instruction = (
            "Evaluate the following candidate solutions. Select the most accurate, efficient, "
            "and mathematically rigorous solution. Provide justification for your choice."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=solutions)

        # Step 5: Verification and Refinement
        refinement_instruction = (
            "Critically review the selected solution. Ensure it satisfies all constraints "
            "and is free of errors. Refine the solution if necessary to improve clarity and correctness."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=final_solution)

        # Step 6: Summarization
        summary_instruction = (
            "Summarize the final solution concisely. Highlight the key steps, results, "
            "and any important insights derived from the problem."
        )
        summary = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return summary