# Workflow ID: high_level_math_ganluo_355_0
# Benchmark: high_level_math_ganluo
# Data Indices: [62, 969]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key components and understand the problem
        problem_analysis = await self.generate(
            instruction="Analyze the problem thoroughly. Identify all variables, constraints, and relationships. "
                        "Determine the mathematical domain(s) involved (e.g., algebra, geometry, combinatorics). "
                        "Provide a clear breakdown of what is being asked.",
            context=self.problem_text
        )

        # Step 2: Explore multiple solution approaches in parallel
        algebraic_solution = self.generate(
            instruction=f"Based on the analysis: {problem_analysis}, solve the problem using algebraic methods. "
                        "Include all intermediate steps and justify each transformation.",
            context=self.problem_text
        )
        geometric_solution = self.generate(
            instruction=f"Based on the analysis: {problem_analysis}, solve the problem using geometric reasoning. "
                        "If applicable, convert the problem into a coordinate geometry setup or use synthetic geometry principles.",
            context=self.problem_text
        )
        combinatorial_solution = self.generate(
            instruction=f"Based on the analysis: {problem_analysis}, solve the problem using combinatorial or probabilistic methods. "
                        "Consider counting techniques, recursive structures, or generating functions if relevant.",
            context=self.problem_text
        )

        # Execute the three approaches in parallel
        results = await asyncio.gather(algebraic_solution, geometric_solution, combinatorial_solution)

        # Step 3: Evaluate and synthesize the results
        best_solution = await self.ensemble(
            instruction="Compare the following solutions and select the most complete, accurate, and elegant one. "
                        "Ensure the chosen solution satisfies all constraints and provides a clear path to the final answer.",
            contexts=results
        )

        # Step 4: Refine the selected solution for rigor and clarity
        refined_solution = await self.revise(
            instruction="Critically review the solution. Ensure all steps are mathematically sound, all constraints are satisfied, "
                        "and the reasoning is clear. Fix any errors or omissions.",
            context=best_solution
        )

        # Step 5: Summarize the final solution
        final_summary = await self.summarize(
            instruction="Condense the solution into a concise summary. Highlight the key steps, main insights, and the final answer. "
                        "Ensure the summary is easy to follow and captures the essence of the solution.",
            context=refined_solution
        )

        return final_summary