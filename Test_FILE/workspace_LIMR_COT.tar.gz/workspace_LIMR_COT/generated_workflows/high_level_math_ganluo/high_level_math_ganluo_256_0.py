# Workflow ID: high_level_math_ganluo_256_0
# Benchmark: high_level_math_ganluo
# Data Indices: [773, 504]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Thoroughly analyze the problem statement and extract all numerical values, "
            "variables, equations, constraints, and relationships explicitly or implicitly mentioned. "
            "Organize this information in a structured format for further processing."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        approach_1_instruction = (
            f"Using the extracted information: {extracted_info}, develop a solution approach based on "
            "algebraic manipulation or direct computation. Ensure all steps are clearly explained."
        )
        approach_2_instruction = (
            f"Using the extracted information: {extracted_info}, develop a solution approach based on "
            "geometric reasoning or combinatorial analysis. Ensure all steps are clearly explained."
        )
        approaches = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text)
        )

        # Step 3: Refine each approach
        refine_instruction_template = (
            "Critique and improve the following solution approach. Check for logical consistency, "
            "mathematical accuracy, and completeness. Provide suggestions for improvement and revise accordingly."
        )
        refined_approaches = await asyncio.gather(
            self.revise(instruction=refine_instruction_template, context=approaches[0]),
            self.revise(instruction=refine_instruction_template, context=approaches[1])
        )

        # Step 4: Summarize the refined approaches
        summarize_instruction = (
            "Condense the solution approach into a concise summary that highlights the key steps, "
            "results, and reasoning. Ensure the summary is clear and focused on the essential elements."
        )
        summarized_approaches = await asyncio.gather(
            self.summarize(instruction=summarize_instruction, context=refined_approaches[0]),
            self.summarize(instruction=summarize_instruction, context=refined_approaches[1])
        )

        # Step 5: Select the best approach or synthesize them
        ensemble_instruction = (
            "Evaluate the provided solution summaries. Select the most accurate, efficient, and complete "
            "solution, or synthesize the best elements from both if appropriate. Provide the final answer."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=summarized_approaches)

        return final_solution