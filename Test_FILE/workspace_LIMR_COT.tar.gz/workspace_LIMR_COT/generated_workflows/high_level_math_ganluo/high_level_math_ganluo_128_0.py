# Workflow ID: high_level_math_ganluo_128_0
# Benchmark: high_level_math_ganluo
# Data Indices: [391, 32]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Initial Analysis - Extract key components
        extraction = await self.generate(
            instruction="Extract all variables, constraints, and relationships from the problem. "
                        "Identify any mathematical structures (e.g., equations, inequalities, patterns). "
                        "Provide a structured summary of the problem's key elements.",
            context=self.problem_text
        )

        # Step 2: Parallel Solution Generation - Explore multiple approaches
        algebraic_solution = self.generate(
            instruction=f"Using the extracted components: {extraction}, "
                        "solve the problem using algebraic methods. "
                        "Include step-by-step reasoning and verify all constraints.",
            context=self.problem_text
        )
        geometric_solution = self.generate(
            instruction=f"Using the extracted components: {extraction}, "
                        "solve the problem using geometric methods. "
                        "Include diagrams if necessary and verify all constraints.",
            context=self.problem_text
        )
        combinatorial_solution = self.generate(
            instruction=f"Using the extracted components: {extraction}, "
                        "solve the problem using combinatorial methods. "
                        "Include counting principles and verify all constraints.",
            context=self.problem_text
        )

        # Execute solutions in parallel
        solutions = await asyncio.gather(algebraic_solution, geometric_solution, combinatorial_solution)

        # Step 3: Evaluation and Synthesis - Select or combine the best solution
        best_solution = await self.ensemble(
            instruction="Compare the provided solutions and select the most rigorous, complete, and elegant one. "
                        "If multiple solutions are complementary, synthesize them into a single coherent solution.",
            contexts=solutions
        )

        # Step 4: Refinement - Critique and improve the solution
        refined_solution = await self.revise(
            instruction="Critique the solution for correctness, completeness, and clarity. "
                        "Ensure all constraints are satisfied and the reasoning is mathematically sound. "
                        "Suggest improvements if necessary.",
            context=best_solution
        )

        # Step 5: Final Summary - Condense the solution
        final_summary = await self.summarize(
            instruction="Condense the solution into a clear and concise form. "
                        "Include only the essential steps and the final answer.",
            context=refined_solution
        )

        return final_summary