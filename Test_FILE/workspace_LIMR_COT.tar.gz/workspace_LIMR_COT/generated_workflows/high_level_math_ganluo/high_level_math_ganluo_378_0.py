# Workflow ID: high_level_math_ganluo_378_0
# Benchmark: high_level_math_ganluo
# Data Indices: [490, 911]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key components of the problem
        extraction_instruction = (
            "Analyze the problem statement and extract all key components, "
            "including variables, equations, constraints, and the specific question being asked. "
            "Organize the information clearly and label each component."
        )
        problem_components = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        algebraic_instruction = (
            f"Using the extracted components: {problem_components}, "
            "solve the problem using algebraic methods. Provide a step-by-step solution, "
            "ensuring all steps are mathematically valid and clearly explained."
        )
        geometric_instruction = (
            f"Using the extracted components: {problem_components}, "
            "solve the problem using geometric reasoning or visualization. "
            "Provide a step-by-step solution, ensuring all steps are mathematically valid."
        )
        combinatorial_instruction = (
            f"Using the extracted components: {problem_components}, "
            "solve the problem using combinatorial or probabilistic methods. "
            "Provide a step-by-step solution, ensuring all steps are mathematically valid."
        )

        solutions = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Critique and refine each solution
        refinement_instruction = (
            "Critique the following solution for correctness, completeness, and mathematical rigor. "
            "Refine the solution if necessary, ensuring it satisfies all problem constraints."
        )
        refined_solutions = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction, context=solution) for solution in solutions]
        )

        # Step 4: Select the best solution using ensemble
        ensemble_instruction = (
            "Compare the following solutions and select the most rigorous, elegant, and correct one. "
            "If solutions are equivalent, choose the most concise. Provide reasoning for your choice."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_solutions)

        # Step 5: Summarize the final answer if needed
        summary_instruction = (
            "Summarize the final solution in a concise and clear manner, ensuring the answer is easy to understand."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=final_solution)

        return final_answer