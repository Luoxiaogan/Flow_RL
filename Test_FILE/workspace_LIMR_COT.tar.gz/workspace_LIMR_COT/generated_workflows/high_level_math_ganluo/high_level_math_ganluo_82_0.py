# Workflow ID: high_level_math_ganluo_82_0
# Benchmark: high_level_math_ganluo
# Data Indices: [137, 158]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Initial Problem Decomposition
        decomposition_instruction = (
            "Carefully read the problem and identify all key components, "
            "including variables, constants, equations, constraints, and relationships. "
            "Break the problem into smaller sub-problems and outline potential solution paths."
        )
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Parallel Exploration of Solution Paths
        algebraic_instruction = f"Using the following decomposition: {decomposition}, " \
                                "solve the problem algebraically by manipulating equations and expressions."
        geometric_instruction = f"Using the following decomposition: {decomposition}, " \
                                "translate the problem into a geometric context and solve using geometric principles."
        combinatorial_instruction = f"Using the following decomposition: {decomposition}, " \
                                    "analyze the problem using combinatorial or number-theoretic techniques."

        algebraic_result, geometric_result, combinatorial_result = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Intermediate Refinement
        refine_instruction_template = (
            "Critique and refine the following solution approach. Ensure logical consistency, "
            "mathematical correctness, and alignment with the problem constraints. "
            "Provide a revised version if necessary."
        )
        refined_algebraic = await self.revise(instruction=refine_instruction_template, context=algebraic_result)
        refined_geometric = await self.revise(instruction=refine_instruction_template, context=geometric_result)
        refined_combinatorial = await self.revise(instruction=refine_instruction_template, context=combinatorial_result)

        # Step 4: Ensemble Decision-Making
        ensemble_instruction = (
            "Evaluate the following three refined solutions and select the best one. "
            "Prioritize clarity, simplicity, and adherence to the problem requirements. "
            "If multiple solutions are valid, synthesize them into a single coherent answer."
        )
        final_solution = await self.ensemble(
            instruction=ensemble_instruction,
            contexts=[refined_algebraic, refined_geometric, refined_combinatorial]
        )

        # Step 5: Final Summarization
        summarize_instruction = (
            "Condense the following solution into a concise and well-structured format. "
            "Ensure the answer satisfies all constraints and is presented clearly."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=final_solution)

        return final_answer