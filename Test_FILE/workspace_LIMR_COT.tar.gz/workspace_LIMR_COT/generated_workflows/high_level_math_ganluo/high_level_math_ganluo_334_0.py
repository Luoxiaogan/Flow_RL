# Workflow ID: high_level_math_ganluo_334_0
# Benchmark: high_level_math_ganluo
# Data Indices: [870, 343]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Problem Decomposition
        decomposition = await self.generate(
            instruction="Extract and analyze all mathematical components, equations, variables, and constraints from the problem. Identify the type of problem (e.g., algebraic, geometric, combinatorial) and list all knowns and unknowns.",
            context=self.problem_text
        )

        # Step 2: Strategy Formulation
        strategies = await self.generate(
            instruction=f"Based on the following analysis: {decomposition}, propose multiple solution strategies. Include algebraic manipulation, geometric interpretation, combinatorial reasoning, and number-theoretic approaches if applicable. Provide detailed reasoning for each strategy.",
            context=self.problem_text
        )

        # Step 3: Parallel Execution of Strategies
        strategy_list = strategies.split("\n\n")  # Assuming strategies are separated by double newlines
        parallel_results = await asyncio.gather(
            *[self.generate(instruction=f"Execute the following strategy step-by-step: {strategy}", context=self.problem_text) for strategy in strategy_list]
        )

        # Step 4: Evaluation and Selection
        best_solution = await self.ensemble(
            instruction="Evaluate the following candidate solutions and select the most rigorous, correct, and efficient one. Ensure it satisfies all problem constraints and provides a complete solution.",
            contexts=parallel_results
        )

        # Optional: Refinement
        refined_solution = await self.revise(
            instruction="Critique and refine the following solution to ensure mathematical rigor, clarity, and correctness. Address any gaps or ambiguities.",
            context=best_solution
        )

        # Step 5: Final Answer Extraction
        final_answer = await self.summarize(
            instruction="Condense the following solution into a concise and clear final answer. Ensure it directly addresses the problem's question and is easy to interpret.",
            context=refined_solution
        )

        return final_answer