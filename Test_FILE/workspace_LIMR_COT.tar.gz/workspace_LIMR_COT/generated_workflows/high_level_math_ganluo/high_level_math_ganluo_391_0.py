# Workflow ID: high_level_math_ganluo_391_0
# Benchmark: high_level_math_ganluo
# Data Indices: [974, 605]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information and identify problem type
        extraction_instruction = (
            "Extract all numerical values, variables, relationships, and constraints from the problem. "
            "Identify the type of problem (e.g., algebraic, geometric, combinatorial) and the required techniques "
            "(e.g., casework, symmetry exploitation). Provide a structured summary of the problem's key components."
        )
        key_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        algebraic_instruction = (
            f"Using the extracted information: {key_info}, solve the problem using algebraic manipulation or equation-solving. "
            "Provide a detailed step-by-step solution."
        )
        geometric_instruction = (
            f"Using the extracted information: {key_info}, solve the problem using geometric reasoning or coordinate bashing. "
            "Provide a detailed step-by-step solution."
        )
        combinatorial_instruction = (
            f"Using the extracted information: {key_info}, solve the problem using combinatorial analysis or recursive formulas. "
            "Provide a detailed step-by-step solution."
        )

        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and synthesize the best solution
        ensemble_instruction = (
            "Compare the following solution approaches and select the most promising one. "
            "Ensure the chosen solution satisfies all constraints and is mathematically rigorous. "
            "If necessary, suggest refinements."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 4: Refine the chosen solution
        refine_instruction = (
            "Critique and refine the following solution to ensure it is complete, accurate, and satisfies all constraints. "
            "Provide a polished version of the solution."
        )
        refined_solution = await self.revise(instruction=refine_instruction, context=best_solution)

        # Step 5: Summarize the final answer
        summarize_instruction = (
            "Condense the following solution into a concise and clear final answer. "
            "Include all key steps and the final result in a boxed format."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_answer