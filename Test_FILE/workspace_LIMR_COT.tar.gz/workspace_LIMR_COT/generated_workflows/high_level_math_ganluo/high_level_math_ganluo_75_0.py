# Workflow ID: high_level_math_ganluo_75_0
# Benchmark: high_level_math_ganluo
# Data Indices: [42, 939]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Initial Problem Analysis
        analysis_instruction = ("Thoroughly analyze the given problem. Identify all variables, constraints, "
                                "and relationships. Clearly state what is being asked and any hidden structures "
                                "or patterns that might be relevant.")
        problem_analysis = await self.generate(instruction=analysis_instruction, context=self.problem_text)

        # Step 2: Approach Generation
        approach_instruction = (f"Based on the following analysis:\n{problem_analysis}\n"
                                "Generate multiple detailed solution approaches. Consider algebraic, geometric, "
                                "combinatorial, and number-theoretic methods. Each approach should include step-by-step "
                                "instructions for solving the problem.")
        approaches = await self.generate(instruction=approach_instruction, context=self.problem_text)

        # Step 3: Parallel Execution of Approaches
        approach_list = approaches.split("\n\n")  # Split into individual approaches
        tasks = [
            self.generate(
                instruction=f"Follow this approach step-by-step:\n{approach}",
                context=self.problem_text
            )
            for approach in approach_list
        ]
        intermediate_results = await asyncio.gather(*tasks)

        # Step 4: Intermediate Results Refinement
        refined_results = []
        for result in intermediate_results:
            refine_instruction = ("Critique and refine the following solution. Check for mathematical correctness, "
                                  "clarity, and adherence to the problem's constraints. Address any errors or ambiguities.")
            refined_result = await self.revise(instruction=refine_instruction, context=result)
            refined_results.append(refined_result)

        # Step 5: Ensemble Decision-Making
        ensemble_instruction = ("Evaluate the following refined solutions. Select the most correct and complete solution, "
                                "or synthesize insights from multiple solutions if necessary. Ensure the final solution "
                                "satisfies all problem constraints.")
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_results)

        # Step 6: Final Solution Summarization
        summarize_instruction = ("Condense the following solution into a clear and concise format. Include all necessary "
                                 "details to demonstrate that the solution satisfies the problem's requirements.")
        final_summary = await self.summarize(instruction=summarize_instruction, context=final_solution)

        return final_summary