# Workflow ID: high_level_math_ganluo_157_0
# Benchmark: high_level_math_ganluo
# Data Indices: [723, 679]

```python
class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract key information from the problem text
        extract_instruction = """
        Identify all key components of the problem including variables, constants, constraints, and the specific question being asked.
        Provide a structured summary of the extracted information.
        """
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        gen_instructions = [
            f"""
            Based on the extracted information: {extracted_info}
            Develop an algebraic solution approach addressing the problem constraints systematically.
            """,
            f"""
            Based on the extracted information: {extracted_info}
            Develop a geometric solution approach utilizing spatial relationships and properties.
            """,
            f"""
            Based on the extracted information: {extracted_info}
            Develop a combinatorial or probabilistic solution approach considering arrangements, combinations, or expected values.
            """
        ]

        # Parallel execution for different solution approaches
        candidate_solutions = await asyncio.gather(
            *[self.generate(instruction=inst, context=self.problem_text) for inst in gen_instructions]
        )

        # Step 3: Refine and verify each solution
        refine_instructions = [
            f"""
            Critique and improve the following solution ensuring it adheres to the problem constraints and is mathematically sound:
            {sol}
            """
            for sol in candidate_solutions
        ]

        refined_solutions = await asyncio.gather(
            *[self.revise(instruction=inst, context=sol) for inst, sol in zip(refine_instructions, candidate_solutions)]
        )

        # Step 4: Summarize each refined solution
        summarize_instructions = [
            f"""
            Summarize the following refined solution highlighting key steps and results:
            {ref_sol}
            """
            for ref_sol in refined_solutions
        ]

        summarized_solutions = await asyncio.gather(
            *[self.summarize(instruction=inst, context=ref_sol) for inst, ref_sol in zip(summarize_instructions, refined_solutions)]
        )

        # Step 5: Select the best solution
        ensemble_instruction = """
        Evaluate the following summarized solutions and select the most appropriate one based on correctness, simplicity, and completeness.
        Provide justification for your selection.
        """
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=summarized_solutions)

        return final_solution
```