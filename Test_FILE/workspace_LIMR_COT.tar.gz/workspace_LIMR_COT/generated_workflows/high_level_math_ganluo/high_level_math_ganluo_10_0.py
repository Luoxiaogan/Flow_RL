# Workflow ID: high_level_math_ganluo_10_0
# Benchmark: high_level_math_ganluo
# Data Indices: [114, 406]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract and Understand the Problem
        extraction_instruction = (
            "Carefully analyze the problem statement to identify all key components, "
            "including variables, constraints, and relationships. Organize this information "
            "in a structured format for further processing."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate Multiple Solution Strategies
        strategy_instruction = (
            f"Based on the extracted information: {extracted_info}, propose multiple solution strategies. "
            "Consider different mathematical domains (e.g., algebra, combinatorics, geometry) and "
            "outline the reasoning steps for each approach."
        )
        strategies = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Execute Parallel Solution Paths
        async def solve_with_strategy(strategy):
            solve_instruction = (
                f"Follow this strategy: {strategy}. Solve the problem step by step, ensuring "
                "all constraints and conditions are satisfied. Provide a detailed explanation "
                "of the reasoning process."
            )
            return await self.generate(instruction=solve_instruction, context=self.problem_text)

        # Split strategies into individual tasks
        strategy_list = strategies.split("\n\n")  # Assuming strategies are separated by double newlines
        solution_tasks = [solve_with_strategy(strategy) for strategy in strategy_list]
        solutions = await asyncio.gather(*solution_tasks)

        # Step 4: Validate and Refine Solutions
        async def validate_solution(solution):
            validation_instruction = (
                f"Review this solution: {solution}. Check for logical consistency, adherence to constraints, "
                "and mathematical correctness. Revise any errors or ambiguities."
            )
            return await self.revise(instruction=validation_instruction, context=solution)

        refined_solutions = await asyncio.gather(*[validate_solution(sol) for sol in solutions])

        # Step 5: Ensemble Decision-Making
        ensemble_instruction = (
            "Compare the following solutions and select the most accurate and robust one. "
            "If multiple solutions are valid, synthesize them into a unified answer."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_solutions)

        # Step 6: Summarize the Final Output
        summary_instruction = (
            "Condense the final solution into a concise, well-structured format. "
            "Ensure all required information is included and presented clearly."
        )
        summarized_output = await self.summarize(instruction=summary_instruction, context=final_solution)

        return summarized_output