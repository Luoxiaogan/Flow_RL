# Workflow ID: high_level_math_ganluo_299_0
# Benchmark: high_level_math_ganluo
# Data Indices: [646, 594]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract Key Information
        extraction_instruction = (
            "Extract all key information from the problem, including numerical values, variables, "
            "constraints, and relationships. Organize the information clearly for further analysis."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate Multiple Solution Approaches
        algebraic_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Develop an algebraic solution approach. Include step-by-step reasoning, equations, "
            "and any transformations needed to solve the problem."
        )
        combinatorial_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Develop a combinatorial or probabilistic solution approach. Include counting methods, "
            "recursive structures, or expected value calculations as applicable."
        )
        geometric_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Develop a geometric solution approach. Include coordinate geometry, synthetic geometry, "
            "or trigonometric reasoning as applicable."
        )

        # Generate solutions in parallel
        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and Synthesize Solution Paths
        ensemble_instruction = (
            "Compare the following solution approaches and determine the most rigorous and efficient one. "
            "Provide a justification for your choice. If multiple approaches are equally valid, combine them."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 4: Refine the Chosen Solution
        refinement_instruction = (
            "Review the chosen solution for mathematical correctness, clarity, and completeness. "
            "Address any gaps, ambiguities, or errors. Ensure the solution satisfies all problem constraints."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the Final Answer
        summary_instruction = (
            "Condense the solution into a concise final answer. Ensure the answer directly addresses "
            "the problem and includes any required explanations or justifications."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer