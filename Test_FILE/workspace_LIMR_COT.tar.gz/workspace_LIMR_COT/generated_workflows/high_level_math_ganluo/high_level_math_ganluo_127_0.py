# Workflow ID: high_level_math_ganluo_127_0
# Benchmark: high_level_math_ganluo
# Data Indices: [291, 166]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Carefully analyze the problem statement to extract all numerical values, variables, "
            "constraints, and the specific question being asked. Identify the mathematical domain "
            "(e.g., geometry, algebra) and any special techniques that might be applicable."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        generate_instruction = (
            f"Based on the extracted information: {extracted_info}, propose at least three distinct "
            "solution approaches. Consider different mathematical techniques, such as algebraic manipulation, "
            "geometric reasoning, or combinatorial analysis. Ensure each approach is detailed and includes "
            "step-by-step reasoning."
        )
        solutions = await asyncio.gather(
            self.generate(instruction=generate_instruction, context=self.problem_text),
            self.generate(instruction=generate_instruction, context=self.problem_text),
            self.generate(instruction=generate_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and select the best solution path
        ensemble_instruction = (
            "Compare the provided solution approaches based on their mathematical rigor, feasibility, "
            "and efficiency. Select the approach that is most likely to lead to the correct solution while "
            "minimizing computational complexity. Provide a justification for your choice."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=solutions)

        # Step 4: Refine the selected solution path
        refine_instruction = (
            f"Review and refine the selected solution approach: {best_solution}. Ensure all steps are "
            "mathematically sound, address any gaps or ambiguities, and verify that the solution satisfies "
            "all constraints of the problem."
        )
        refined_solution = await self.revise(instruction=refine_instruction, context=best_solution)

        # Step 5: Summarize the final answer
        summarize_instruction = (
            f"Condense the refined solution: {refined_solution} into a concise and polished final answer. "
            "Ensure the answer is clear, well-structured, and presented in the required format (e.g., "
            "interval notation, exact value)."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_answer