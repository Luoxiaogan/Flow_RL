# Workflow ID: high_level_math_ganluo_153_0
# Benchmark: high_level_math_ganluo
# Data Indices: [263, 172]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key components of the problem
        extraction_instruction = (
            "Extract all key components of the problem, including variables, constraints, "
            "relationships, and any specific requirements. Organize the information clearly."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Explore multiple solution paths in parallel
        # Define detailed instructions for different approaches
        algebraic_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem algebraically. "
            "Focus on equations, inequalities, and functional relationships."
        )
        geometric_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem geometrically. "
            "Consider coordinate geometry, synthetic geometry, and trigonometric methods."
        )
        combinatorial_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem combinatorially. "
            "Apply counting principles, recursive formulas, and probabilistic methods."
        )

        # Execute approaches in parallel
        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Refine each solution path
        refine_instruction = (
            "Critique and refine the given solution. Check for correctness, completeness, "
            "and adherence to the problem constraints. Provide a revised version if necessary."
        )
        refined_results = await asyncio.gather(
            *[self.revise(instruction=refine_instruction, context=result) for result in results]
        )

        # Step 4: Synthesize results using Ensemble
        ensemble_instruction = (
            "Evaluate the provided solutions and select the most robust and elegant one. "
            "Consider simplicity, accuracy, and alignment with the problem requirements."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_results)

        # Step 5: Summarize the final solution
        summarize_instruction = (
            "Condense the final solution into a clear and concise format. Include only essential details."
        )
        summarized_solution = await self.summarize(instruction=summarize_instruction, context=final_solution)

        return summarized_solution