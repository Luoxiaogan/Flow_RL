# Workflow ID: high_level_math_ganluo_7_0
# Benchmark: high_level_math_ganluo
# Data Indices: [460, 1]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information and decompose the problem
        extraction_instruction = (
            "Extract all key information from the problem, including variables, constraints, "
            "and relationships. Organize this information into categories such as numerical values, "
            "mathematical operations, and conditions. Provide a structured summary."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        algebraic_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using algebraic methods. "
            "Focus on equations, inequalities, and functional relationships. Provide step-by-step reasoning."
        )
        combinatorial_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using combinatorial methods. "
            "Focus on counting principles, permutations, and recursive structures. Provide step-by-step reasoning."
        )
        geometric_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using geometric methods. "
            "Focus on shapes, areas, volumes, and coordinate transformations. Provide step-by-step reasoning."
        )

        # Parallel execution of multiple approaches
        approaches = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text)
        )

        # Step 3: Revise and refine the solutions
        revise_instructions = [
            "Critique and refine the following solution. Ensure logical consistency, correctness, and clarity. "
            "Simplify calculations where possible and verify adherence to all constraints."
        ] * len(approaches)

        refined_solutions = await asyncio.gather(
            *[self.revise(instruction=revise_instructions[i], context=approaches[i]) for i in range(len(approaches))]
        )

        # Step 4: Select the best solution using ensemble
        ensemble_instruction = (
            "Compare the following solutions and select the best one. Evaluate based on correctness, "
            "elegance, computational simplicity, and adherence to constraints. Consider edge cases and "
            "ensure all problem conditions are satisfied."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_solutions)

        # Step 5: Summarize the final result (optional)
        summarize_instruction = (
            "Condense the following solution into a clear and concise form. Highlight the key steps and "
            "the final answer. Ensure the result is easy to understand and mathematically rigorous."
        )
        final_output = await self.summarize(instruction=summarize_instruction, context=best_solution)

        return final_output