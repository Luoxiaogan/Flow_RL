# Workflow ID: high_level_math_ganluo_303_0
# Benchmark: high_level_math_ganluo
# Data Indices: [937, 301]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction = await self.generate(
            instruction="Extract all numerical values, constraints, and the type of problem (e.g., combinatorics, number theory, geometry). "
                        "Provide a structured summary of the problem's requirements.",
            context=self.problem_text
        )

        # Step 2: Generate multiple solution approaches
        approaches = await asyncio.gather(
            self.generate(
                instruction=f"Based on the extracted information: {extraction}, develop an algebraic approach to solve the problem. "
                            "Include all steps and intermediate calculations.",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"Based on the extracted information: {extraction}, develop a geometric approach to solve the problem. "
                            "Include all steps and intermediate calculations.",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"Based on the extracted information: {extraction}, develop a combinatorial or probabilistic approach to solve the problem. "
                            "Include all steps and intermediate calculations.",
                context=self.problem_text
            )
        )

        # Step 3: Evaluate and select the best approach
        best_solution = await self.ensemble(
            instruction="Compare the following candidate solutions and select the most accurate, clear, and robust one. "
                        "Ensure the chosen solution satisfies all problem constraints.",
            contexts=approaches
        )

        # Step 4: Refine the selected solution
        final_solution = await self.revise(
            instruction="Refine the following solution to ensure it is polished, well-structured, and satisfies all problem requirements. "
                        "Correct any errors or ambiguities.",
            context=best_solution
        )

        return final_solution