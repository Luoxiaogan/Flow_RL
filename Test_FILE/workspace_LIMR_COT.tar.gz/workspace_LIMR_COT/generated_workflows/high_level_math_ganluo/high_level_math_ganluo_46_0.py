# Workflow ID: high_level_math_ganluo_46_0
# Benchmark: high_level_math_ganluo
# Data Indices: [65, 527]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all numerical values, variables, equations, geometric properties, "
            "constraints, and the desired output format from the problem. "
            "Organize this information clearly and label each component."
        )
        key_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        approach_instruction = (
            f"Based on the extracted information: {key_info}, propose at least three distinct solution approaches. "
            "Each approach should detail the mathematical techniques used, intermediate steps, and how it satisfies the problem's constraints. "
            "Ensure the approaches are self-contained and sufficiently detailed to proceed independently."
        )
        approaches = await self.generate(instruction=approach_instruction, context=self.problem_text)

        # Step 3: Refine each approach in parallel
        refine_instruction_template = (
            "Refine the following solution approach by verifying calculations, applying constraints, "
            "and ensuring correctness. If errors or ambiguities are found, correct them and provide a revised version."
        )
        refined_approaches = await asyncio.gather(
            *[self.revise(instruction=refine_instruction_template, context=approach) for approach in approaches.split("\n\n")]
        )

        # Step 4: Ensemble the refined approaches
        ensemble_instruction = (
            "Evaluate the following solution approaches, considering their correctness, clarity, "
            "and adherence to the problem's constraints. Select the best approach or synthesize them into a single coherent solution."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_approaches)

        # Step 5: Summarize the final solution
        summarize_instruction = (
            "Condense the final solution into the required format. Ensure it satisfies all constraints, "
            "is presented clearly, and includes all necessary details."
        )
        formatted_solution = await self.summarize(instruction=summarize_instruction, context=final_solution)

        return formatted_solution