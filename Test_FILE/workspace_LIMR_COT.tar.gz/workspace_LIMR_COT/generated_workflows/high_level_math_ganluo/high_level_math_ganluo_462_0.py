# Workflow ID: high_level_math_ganluo_462_0
# Benchmark: high_level_math_ganluo
# Data Indices: [355, 215]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract problem components
        extraction_instruction = (
            "Extract all variables, constraints, and objectives from the problem. "
            "Identify the mathematical domain (e.g., algebra, geometry, number theory). "
            "List any special conditions or symmetries that might simplify the solution."
        )
        problem_components = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Explore multiple solution paths in parallel
        algebra_instruction = (
            f"Given the problem components: {problem_components}, "
            "solve the problem using algebraic manipulation. Focus on simplifying expressions, "
            "solving equations, and applying inequalities if relevant."
        )
        geometry_instruction = (
            f"Given the problem components: {problem_components}, "
            "interpret the problem geometrically. Use coordinate geometry, synthetic geometry, "
            "or trigonometric relationships as needed."
        )
        combinatorics_instruction = (
            f"Given the problem components: {problem_components}, "
            "apply combinatorial reasoning. Count arrangements, calculate probabilities, "
            "or use recursive formulas if applicable."
        )
        number_theory_instruction = (
            f"Given the problem components: {problem_components}, "
            "use number-theoretic techniques such as modular arithmetic, divisibility, "
            "or prime factorization to solve the problem."
        )

        # Execute parallel exploration
        results = await asyncio.gather(
            self.generate(instruction=algebra_instruction, context=self.problem_text),
            self.generate(instruction=geometry_instruction, context=self.problem_text),
            self.generate(instruction=combinatorics_instruction, context=self.problem_text),
            self.generate(instruction=number_theory_instruction, context=self.problem_text)
        )

        # Step 3: Refine and validate intermediate results
        refined_results = []
        for result in results:
            refinement_instruction = (
                f"Critique and refine the following solution: {result}. "
                "Ensure it satisfies all constraints and optimize for clarity and correctness."
            )
            refined_result = await self.revise(instruction=refinement_instruction, context=result)
            refined_results.append(refined_result)

        # Step 4: Synthesize and select the best solution
        synthesis_instruction = (
            "Compare the following candidate solutions and select the most accurate and efficient one. "
            "Ensure the final answer satisfies all problem constraints and is presented in the required format."
        )
        final_answer = await self.ensemble(instruction=synthesis_instruction, contexts=refined_results)

        return final_answer