# Workflow ID: high_level_math_ganluo_291_0
# Benchmark: high_level_math_ganluo
# Data Indices: [214, 637]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extract_instruction = (
            "Extract all key mathematical elements from the problem, including variables, equations, "
            "constraints, and the type of problem (e.g., algebraic, geometric, combinatorial). "
            "Organize the information in a structured format."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        approach_instructions = [
            f"Using the extracted information: {extracted_info}, solve the problem algebraically. "
            "Provide step-by-step reasoning and show all intermediate calculations.",

            f"Using the extracted information: {extracted_info}, solve the problem geometrically. "
            "Interpret the problem in terms of shapes, coordinates, or spatial relationships.",

            f"Using the extracted information: {extracted_info}, solve the problem combinatorially. "
            "Consider counting principles, recursive structures, or probabilistic methods."
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Evaluate and synthesize the best solution
        ensemble_instruction = (
            "Compare the following candidate solutions and select the most mathematically rigorous, "
            "efficient, and complete approach. Provide a justification for your choice."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=approaches)

        # Step 4: Refine the chosen solution
        refine_instruction = (
            "Critique the following solution for mathematical correctness, logical consistency, "
            "and clarity. Suggest improvements if necessary and provide the revised version."
        )
        refined_solution = await self.revise(instruction=refine_instruction, context=best_solution)

        # Step 5: Summarize the final answer
        summarize_instruction = (
            "Condense the following solution into a concise, clear summary that includes the final answer "
            "and satisfies all problem constraints."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_answer