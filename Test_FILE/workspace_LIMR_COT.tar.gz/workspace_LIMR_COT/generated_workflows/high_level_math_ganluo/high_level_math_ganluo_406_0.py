# Workflow ID: high_level_math_ganluo_406_0
# Benchmark: high_level_math_ganluo
# Data Indices: [721, 292]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio
        
        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all key information from the problem, including variables, constraints, "
            "and the main objective. Identify any mathematical structures such as equations, "
            "inequalities, or combinatorial setups. Format the output clearly."
        )
        key_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)
        
        # Step 2: Explore multiple solution paths in parallel
        algebra_instruction = (
            f"Using the extracted information: {key_info}, solve the problem using algebraic methods. "
            "Focus on equations, substitutions, and simplifications. Provide step-by-step reasoning."
        )
        combinatorics_instruction = (
            f"Using the extracted information: {key_info}, solve the problem using combinatorial methods. "
            "Consider counting principles, permutations, combinations, and recursive structures. "
            "Provide step-by-step reasoning."
        )
        number_theory_instruction = (
            f"Using the extracted information: {key_info}, solve the problem using number theory techniques. "
            "Focus on divisibility, modular arithmetic, prime factorization, and Diophantine equations. "
            "Provide step-by-step reasoning."
        )
        
        results = await asyncio.gather(
            self.generate(instruction=algebra_instruction, context=self.problem_text),
            self.generate(instruction=combinatorics_instruction, context=self.problem_text),
            self.generate(instruction=number_theory_instruction, context=self.problem_text)
        )
        
        # Step 3: Refine each solution path
        refine_instructions = [
            "Critique and refine the following solution path. Check for mathematical correctness, "
            "logical consistency, and adherence to problem constraints. Correct any errors and "
            "provide a revised solution with clear reasoning."
        ] * len(results)
        
        refined_results = await asyncio.gather(
            *[self.revise(instruction=refine_instructions[i], context=results[i]) for i in range(len(results))]
        )
        
        # Step 4: Ensemble decision to select the best approach
        ensemble_instruction = (
            "Compare the following solution paths and select the most robust, correct, and elegant one. "
            "If multiple paths are valid, combine their insights into a single cohesive solution. "
            "Ensure the final solution satisfies all problem constraints."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_results)
        
        # Step 5: Summarize the final answer
        summarize_instruction = (
            "Condense the following solution into a concise and clear format. Box the final answer "
            "and ensure it is easy to read and understand."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=final_solution)
        
        return final_answer