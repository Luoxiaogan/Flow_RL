# Workflow ID: high_level_math_ganluo_458_0
# Benchmark: high_level_math_ganluo
# Data Indices: [669, 694]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem text
        extraction_instruction = (
            "Extract all key information from the problem, including numerical values, constraints, "
            "and the type of mathematical reasoning required (e.g., combinatorics, number theory, geometry). "
            "Identify any hidden structures or patterns that might simplify the problem."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution paths in parallel
        algebraic_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using algebraic methods. "
            "Include all steps and justify each transformation."
        )
        combinatorial_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using combinatorial methods. "
            "Consider casework analysis, recursive formulas, or generating functions if applicable."
        )
        geometric_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using geometric methods. "
            "Convert the problem into a geometric representation if necessary."
        )

        algebraic_solution, combinatorial_solution, geometric_solution = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and select the best solution
        evaluation_instruction = (
            "Compare the following candidate solutions and select the most efficient and correct one. "
            "If multiple solutions are valid, synthesize a hybrid solution that combines their strengths."
        )
        best_solution = await self.ensemble(
            instruction=evaluation_instruction,
            contexts=[algebraic_solution, combinatorial_solution, geometric_solution]
        )

        # Step 4: Refine the selected solution
        refinement_instruction = (
            "Critically review the selected solution. Ensure it satisfies all constraints, is mathematically rigorous, "
            "and is presented in a clear and logical manner. Fix any errors or ambiguities."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the final solution
        summarization_instruction = (
            "Condense the solution into a concise and clear format. Include only the essential steps and the final answer."
        )
        final_summary = await self.summarize(instruction=summarization_instruction, context=refined_solution)

        return final_summary