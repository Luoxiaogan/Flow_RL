# Workflow ID: high_level_math_ganluo_371_0
# Benchmark: high_level_math_ganluo
# Data Indices: [647, 265]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information and decompose the problem
        extraction_instruction = (
            "Extract all key information from the problem, including variables, constraints, "
            "and relationships. Identify the mathematical domain (e.g., algebra, geometry) "
            "and the type of reasoning required (e.g., pattern recognition, recursive formulas)."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Explore multiple solution approaches in parallel
        approach_instructions = [
            f"Using algebraic reasoning, solve the problem based on the following extracted information: {extracted_info}",
            f"Using combinatorial reasoning, solve the problem based on the following extracted information: {extracted_info}",
            f"Using geometric reasoning, solve the problem based on the following extracted information: {extracted_info}"
        ]
        results = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Evaluate and select the best solution
        ensemble_instruction = (
            "Compare the following candidate solutions and select the most mathematically rigorous and complete one. "
            "Ensure the chosen solution satisfies all constraints and is computationally sound."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 4: Refine the selected solution
        refinement_instruction = (
            "Critique and refine the following solution to ensure clarity, correctness, and adherence to the problem's requirements. "
            "Address any ambiguities or potential errors."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the following solution into a concise and well-structured format. "
            "Include only the essential steps and the final answer."
        )
        final_solution = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_solution