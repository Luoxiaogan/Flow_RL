# Workflow ID: high_level_math_ganluo_396_0
# Benchmark: high_level_math_ganluo
# Data Indices: [613, 110]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all numerical values, constraints, and relationships between entities "
            "from the problem. Organize the information clearly and label each component."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        approach_instructions = [
            f"Develop an algebraic approach to solve the problem using the following extracted information: {extracted_info}.",
            f"Develop a geometric approach to solve the problem using the following extracted information: {extracted_info}.",
            f"Develop a combinatorial approach to solve the problem using the following extracted information: {extracted_info}."
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Evaluate and select the best approach
        ensemble_instruction = (
            "Evaluate the provided solution approaches based on clarity, feasibility, and alignment with the problem's constraints. "
            "Select the most promising approach and justify your choice."
        )
        best_approach = await self.ensemble(instruction=ensemble_instruction, contexts=approaches)

        # Step 4: Execute the selected approach step-by-step
        execution_instruction = (
            f"Implement the selected approach step-by-step. Ensure each step logically follows from the previous one. "
            f"Use the following extracted information: {extracted_info}. Approach: {best_approach}."
        )
        solution = await self.generate(instruction=execution_instruction, context=self.problem_text)

        # Step 5: Verify and refine the solution
        refinement_instruction = (
            "Critique the solution for mathematical correctness, logical consistency, and adherence to the problem's constraints. "
            "Refine the solution if necessary and provide a revised version."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=solution)

        # Step 6: Summarize the final result
        summary_instruction = (
            "Condense the solution into a concise and clear format. Highlight the key steps and the final answer."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_summary