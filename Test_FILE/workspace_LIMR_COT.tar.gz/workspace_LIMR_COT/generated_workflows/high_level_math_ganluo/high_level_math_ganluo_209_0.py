# Workflow ID: high_level_math_ganluo_209_0
# Benchmark: high_level_math_ganluo
# Data Indices: [22, 732]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Problem Decomposition
        decomposition_instruction = (
            "Analyze the problem thoroughly. Identify all known values, unknowns, constraints, "
            "and relationships. Categorize the problem into its primary mathematical domain(s) "
            "(e.g., algebra, geometry, number theory). Provide a structured breakdown of the problem."
        )
        problem_decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Solution Path Exploration
        solution_paths = await asyncio.gather(
            self.generate(
                instruction=f"Using the following problem breakdown:\n{problem_decomposition}\n"
                            "Develop an algebraic solution approach. Include equations, variables, "
                            "and step-by-step reasoning.",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"Using the following problem breakdown:\n{problem_decomposition}\n"
                            "Develop a geometric solution approach. Include diagrams (if applicable), "
                            "key geometric properties, and step-by-step reasoning.",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"Using the following problem breakdown:\n{problem_decomposition}\n"
                            "Develop a combinatorial or probabilistic solution approach. Include "
                            "counting principles, probabilities, and step-by-step reasoning.",
                context=self.problem_text
            )
        )

        # Step 3: Select Best Approach
        selection_instruction = (
            "Evaluate the provided solution approaches. Consider clarity, feasibility, and alignment "
            "with the problem's requirements. Select the best approach and explain your reasoning."
        )
        best_approach = await self.ensemble(instruction=selection_instruction, contexts=solution_paths)

        # Step 4: Detailed Solution Development
        detailed_solution = await self.generate(
            instruction=f"Develop the selected solution approach step-by-step:\n{best_approach}\n"
                        "Ensure all calculations are accurate and all constraints are satisfied.",
            context=self.problem_text
        )

        # Step 5: Refinement and Verification
        refinement_instruction = (
            "Critique and refine the detailed solution. Ensure all steps are logically sound, "
            "all constraints are satisfied, and the final answer is clearly stated. Address any "
            "potential edge cases or ambiguities."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=detailed_solution)

        # Step 6: Final Answer Summarization
        summary_instruction = (
            "Condense the refined solution into a concise final answer. Ensure the answer is "
            "clear, precise, and satisfies the problem's requirements."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer