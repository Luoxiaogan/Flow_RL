# Workflow ID: high_level_math_ganluo_327_0
# Benchmark: high_level_math_ganluo
# Data Indices: [94, 269]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key components of the problem
        extraction_instruction = (
            "Extract all key components of the problem, including numerical values, constraints, "
            "relationships, and the specific question being asked. Organize the information clearly."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        approach_instructions = [
            f"Using algebraic reasoning, solve the problem step by step. Extracted info: {extracted_info}",
            f"Using geometric reasoning, solve the problem step by step. Extracted info: {extracted_info}",
            f"Using combinatorial analysis, solve the problem step by step. Extracted info: {extracted_info}",
            f"Using number theory, solve the problem step by step. Extracted info: {extracted_info}"
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Revise and refine each approach
        revise_instructions = [
            "Critique and refine this solution approach. Ensure logical consistency, adherence to constraints, "
            "and computational feasibility."
        ] * len(approaches)
        refined_approaches = await asyncio.gather(
            *[self.revise(instruction=revise_instr, context=approach) 
              for revise_instr, approach in zip(revise_instructions, approaches)]
        )

        # Step 4: Ensemble to select or synthesize the best solution
        ensemble_instruction = (
            "Evaluate these solution approaches. Select the most promising one or synthesize insights "
            "from multiple approaches to form a comprehensive solution. Ensure clarity, correctness, "
            "and alignment with the problem's requirements."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_approaches)

        # Step 5: Summarize the final answer
        summarize_instruction = (
            "Condense the final solution into a concise and well-structured answer. Ensure it directly "
            "addresses the problem and includes all necessary details."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=final_solution)

        return final_answer