# Workflow ID: high_level_math_ganluo_443_0
# Benchmark: high_level_math_ganluo
# Data Indices: [74, 298]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Problem Understanding and Decomposition
        problem_analysis = await self.generate(
            instruction="Extract all key information from the problem, including variables, equations, constraints, and what is being asked.",
            context=self.problem_text
        )

        # Step 2: Generate Multiple Solution Approaches
        approach_1 = self.generate(
            instruction=f"Using the following problem analysis: {problem_analysis}\nDevelop an algebraic approach to solve the problem step by step.",
            context=self.problem_text
        )
        approach_2 = self.generate(
            instruction=f"Using the following problem analysis: {problem_analysis}\nDevelop a combinatorial or probabilistic approach to solve the problem step by step.",
            context=self.problem_text
        )
        approach_3 = self.generate(
            instruction=f"Using the following problem analysis: {problem_analysis}\nDevelop a geometric or trigonometric approach to solve the problem step by step.",
            context=self.problem_text
        )

        # Execute approaches in parallel
        approaches = await asyncio.gather(approach_1, approach_2, approach_3)

        # Step 3: Evaluate and Select the Best Approach
        best_approach = await self.ensemble(
            instruction="Compare the following approaches and select the one that is most rigorous, feasible, and aligned with the problem requirements.",
            contexts=approaches
        )

        # Step 4: Develop Detailed Solution
        detailed_solution = await self.generate(
            instruction=f"Based on the selected approach: {best_approach}\nDevelop a detailed step-by-step solution to the problem.",
            context=self.problem_text
        )

        # Step 5: Verify and Improve the Solution
        revised_solution = await self.revise(
            instruction="Critique and refine the following solution to ensure it is accurate, complete, and free of errors.",
            context=detailed_solution
        )

        # Step 6: Summarize the Final Answer
        final_answer = await self.summarize(
            instruction="Condense the following solution into a concise final answer that directly addresses the problem's question.",
            context=revised_solution
        )

        return final_answer