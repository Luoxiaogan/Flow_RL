# Workflow ID: high_level_math_ganluo_368_0
# Benchmark: high_level_math_ganluo
# Data Indices: [57, 31]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key components of the problem
        extraction_instruction = (
            "Analyze the problem statement and extract all critical components, including variables, "
            "constraints, relationships, and the goal. Identify any patterns, symmetries, or special cases. "
            "Provide this information in a structured format."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Propose multiple solution strategies
        strategy_instruction = (
            f"Based on the extracted information: {extracted_info}, propose multiple solution strategies. "
            "Consider different mathematical domains (algebra, geometry, combinatorics, number theory) and "
            "approaches (casework, recursion, symmetry exploitation, modular arithmetic). Provide a detailed "
            "rationale for each strategy."
        )
        strategies = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Execute strategies in parallel
        execution_instruction_template = (
            "Using the following strategy: {{strategy}}, solve the problem step by step. "
            "Ensure all constraints are satisfied and provide intermediate results."
        )
        strategy_list = strategies.split("\n\n")  # Assuming strategies are separated by double newlines
        execution_tasks = [
            self.generate(instruction=execution_instruction_template.format(strategy=strategy), context=self.problem_text)
            for strategy in strategy_list
        ]
        results = await asyncio.gather(*execution_tasks)

        # Step 4: Ensemble decision-making
        ensemble_instruction = (
            "Compare and evaluate the following candidate solutions: {results}. "
            "Select the most robust and correct solution, ensuring it satisfies all constraints "
            "and aligns with the original problem statement. Provide a justification for your choice."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction.format(results=results), contexts=results)

        # Step 5: Final verification and summarization
        verification_instruction = (
            "Condense the final solution into a concise, verifiable form. Ensure it satisfies all "
            "constraints and clearly answers the original question."
        )
        verified_solution = await self.summarize(instruction=verification_instruction, context=final_solution)

        return verified_solution