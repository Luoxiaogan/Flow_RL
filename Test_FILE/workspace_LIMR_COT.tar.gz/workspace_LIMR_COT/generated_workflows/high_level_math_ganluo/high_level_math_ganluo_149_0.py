# Workflow ID: high_level_math_ganluo_149_0
# Benchmark: high_level_math_ganluo
# Data Indices: [169, 943]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information and identify problem type
        extraction_instruction = (
            "Extract all key mathematical entities (e.g., variables, equations, constraints) "
            "and identify the type of problem (e.g., algebraic, geometric, combinatorial). "
            "Provide a structured summary of the problem's requirements and constraints."
        )
        problem_summary = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        algebraic_instruction = (
            f"Given the problem summary: {problem_summary}, "
            "solve the problem using algebraic techniques such as equation solving, polynomial manipulation, "
            "or functional analysis. Provide detailed reasoning and intermediate steps."
        )
        geometric_instruction = (
            f"Given the problem summary: {problem_summary}, "
            "solve the problem using geometric techniques such as coordinate geometry, synthetic geometry, "
            "or trigonometric analysis. Provide detailed reasoning and intermediate steps."
        )
        combinatorial_instruction = (
            f"Given the problem summary: {problem_summary}, "
            "solve the problem using combinatorial techniques such as counting principles, recursive formulas, "
            "or generating functions. Provide detailed reasoning and intermediate steps."
        )
        number_theory_instruction = (
            f"Given the problem summary: {problem_summary}, "
            "solve the problem using number theory techniques such as modular arithmetic, divisibility, "
            "or prime factorization. Provide detailed reasoning and intermediate steps."
        )

        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text),
            self.generate(instruction=number_theory_instruction, context=self.problem_text)
        )

        # Step 3: Revise and refine intermediate results
        revised_results = await asyncio.gather(
            self.revise(instruction="Critique and refine this solution, ensuring all steps are logically sound.", context=results[0]),
            self.revise(instruction="Critique and refine this solution, ensuring all steps are logically sound.", context=results[1]),
            self.revise(instruction="Critique and refine this solution, ensuring all steps are logically sound.", context=results[2]),
            self.revise(instruction="Critique and refine this solution, ensuring all steps are logically sound.", context=results[3])
        )

        # Step 4: Ensemble decision-making
        ensemble_instruction = (
            "Compare the following solutions and select the most promising one. "
            "If multiple solutions are partially correct, synthesize them into a single coherent answer. "
            "Ensure the final solution satisfies all problem constraints."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=revised_results)

        # Step 5: Final answer validation
        summarization_instruction = (
            "Condense the final reasoning into a concise summary. "
            "Verify that the solution satisfies all problem constraints and is mathematically sound."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=final_solution)

        return final_answer