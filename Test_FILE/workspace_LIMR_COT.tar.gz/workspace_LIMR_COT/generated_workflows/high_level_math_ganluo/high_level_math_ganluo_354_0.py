# Workflow ID: high_level_math_ganluo_354_0
# Benchmark: high_level_math_ganluo
# Data Indices: [170, 635]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all numerical values, constraints, and the specific question being asked. "
            "Organize the information clearly and label each part (e.g., 'Numerical Values:', 'Constraints:', 'Question:')."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        algebraic_instruction = (
            f"Given the extracted information: {extracted_info}\n"
            "Solve the problem using algebraic methods. Include all steps, transformations, and reasoning."
        )
        geometric_instruction = (
            f"Given the extracted information: {extracted_info}\n"
            "Solve the problem using geometric reasoning. Include diagrams (if applicable), coordinate transformations, and area/volume calculations."
        )
        combinatorial_instruction = (
            f"Given the extracted information: {extracted_info}\n"
            "Solve the problem using combinatorial techniques. Consider counting principles, recursive formulas, and generating functions."
        )

        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and select the best approach
        ensemble_instruction = (
            "Compare the following candidate solutions and select the most promising one. "
            "Criteria include correctness, clarity, and adherence to the problem constraints. "
            "Provide a brief justification for your choice."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 4: Refine the selected solution
        refinement_instruction = (
            "Critique and improve the following solution. Ensure it is mathematically rigorous, "
            "free of errors, and clearly presented. Correct any inconsistencies or ambiguities."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the following solution into a concise summary. Include only the key steps "
            "and the final answer. Ensure the summary directly addresses the problem."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_summary