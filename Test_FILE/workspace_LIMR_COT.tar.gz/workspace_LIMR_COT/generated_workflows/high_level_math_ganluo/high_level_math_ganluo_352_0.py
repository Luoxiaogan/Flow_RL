# Workflow ID: high_level_math_ganluo_352_0
# Benchmark: high_level_math_ganluo
# Data Indices: [19, 221]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all relevant information from the problem, including variables, "
            "constraints, relationships, and the final goal. Organize this information "
            "in a structured format for further reasoning."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        algebraic_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Solve the problem using algebraic methods. Show all steps and reasoning."
        )
        geometric_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Solve the problem using geometric methods. Show all steps and reasoning."
        )
        combinatorial_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Solve the problem using combinatorial methods. Show all steps and reasoning."
        )

        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )
        algebraic_solution, geometric_solution, combinatorial_solution = results

        # Step 3: Validate and refine each solution
        refinement_instruction = (
            "Critically evaluate the solution for correctness, completeness, and clarity. "
            "Identify any errors or inconsistencies and revise them. Ensure the solution "
            "satisfies all constraints and conditions stated in the problem."
        )
        refined_solutions = await asyncio.gather(
            self.revise(instruction=refinement_instruction, context=algebraic_solution),
            self.revise(instruction=refinement_instruction, context=geometric_solution),
            self.revise(instruction=refinement_instruction, context=combinatorial_solution)
        )

        # Step 4: Select the best solution
        selection_instruction = (
            "Compare the following solutions and select the best one. Consider correctness, "
            "clarity, and efficiency. If multiple solutions are equally valid, choose the most elegant one."
        )
        final_solution = await self.ensemble(instruction=selection_instruction, contexts=refined_solutions)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Summarize the final solution in a concise and clear manner. Include only the key steps "
            "and the final answer. Ensure the summary is easy to understand and directly addresses "
            "the problem's requirements."
        )
        summarized_solution = await self.summarize(instruction=summary_instruction, context=final_solution)

        return summarized_solution