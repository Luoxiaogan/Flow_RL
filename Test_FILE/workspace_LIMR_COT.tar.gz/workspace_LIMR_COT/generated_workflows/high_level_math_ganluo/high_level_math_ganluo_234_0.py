# Workflow ID: high_level_math_ganluo_234_0
# Benchmark: high_level_math_ganluo
# Data Indices: [500, 233]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key components of the problem
        extraction_instruction = (
            "Identify and extract all numerical values, variables, constraints, and relationships "
            "from the problem statement. Organize them clearly for further analysis."
        )
        key_components = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        approach_instructions = [
            f"Using the extracted components: {key_components}, solve the problem using an algebraic approach. "
            "Focus on equations, expressions, and transformations.",
            f"Using the extracted components: {key_components}, solve the problem using a geometric approach. "
            "Focus on shapes, angles, and spatial relationships.",
            f"Using the extracted components: {key_components}, solve the problem using a combinatorial or number-theoretic approach. "
            "Focus on counting principles, modular arithmetic, or divisibility rules."
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Evaluate and synthesize the best solution
        ensemble_instruction = (
            "Compare the following candidate solutions and select the most valid and efficient one. "
            "Ensure the chosen solution adheres to all constraints and is mathematically correct. "
            "If multiple solutions are valid, choose the one with the clearest reasoning."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=approaches)

        # Step 4: Refine the final solution
        refinement_instruction = (
            "Refine the following solution to ensure it is mathematically rigorous, fully satisfies all constraints, "
            "and is presented in the required format (e.g., simplest radical form, base-2 representation)."
        )
        final_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        return final_solution