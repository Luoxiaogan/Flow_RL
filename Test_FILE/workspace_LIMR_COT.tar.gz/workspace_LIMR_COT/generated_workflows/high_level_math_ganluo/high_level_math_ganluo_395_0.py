# Workflow ID: high_level_math_ganluo_395_0
# Benchmark: high_level_math_ganluo
# Data Indices: [685, 862]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key components from the problem statement
        extraction_instruction = (
            "Extract all numerical values, constraints, relationships, and objectives from the problem statement. "
            "Format the output as a structured summary, including any implicit conditions or assumptions."
        )
        key_components = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        approach_instruction = (
            f"Based on the extracted key components: {key_components}, generate multiple distinct approaches to solve the problem. "
            "Each approach should include a clear step-by-step reasoning process. Consider algebraic, geometric, combinatorial, "
            "and number-theoretic methods where applicable. Ensure each approach is mathematically valid and directly addresses "
            "the problem's requirements."
        )
        approaches = await self.generate(instruction=approach_instruction, context=self.problem_text)

        # Step 3: Execute approaches in parallel
        parallel_instructions = [
            f"Execute the following approach step-by-step: {approach}. Ensure all calculations are precise and logical."
            for approach in approaches.split("\n\n")  # Assuming approaches are separated by double newlines
        ]
        parallel_results = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in parallel_instructions]
        )

        # Step 4: Evaluate and synthesize results
        ensemble_instruction = (
            "Compare and evaluate the following candidate solutions. Select the most rigorous, complete, and mathematically "
            "sound solution. If multiple solutions are equally valid, synthesize them into a unified answer."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=parallel_results)

        # Step 5: Final verification
        verification_instruction = (
            f"Verify the following solution against the original problem statement: {final_solution}. "
            "Ensure it satisfies all constraints, conditions, and objectives. Highlight any discrepancies or ambiguities."
        )
        verified_solution = await self.revise(instruction=verification_instruction, context=final_solution)

        return verified_solution