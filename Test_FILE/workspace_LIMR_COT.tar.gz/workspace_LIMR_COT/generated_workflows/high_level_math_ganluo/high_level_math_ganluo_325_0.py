# Workflow ID: high_level_math_ganluo_325_0
# Benchmark: high_level_math_ganluo
# Data Indices: [410, 24]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Problem Understanding and Decomposition
        decomposition_instruction = (
            "Analyze the problem to identify key mathematical elements such as variables, equations, "
            "constraints, and the type of problem (algebraic, geometric, combinatorial, etc.). "
            "Extract all numerical values, relationships, and conditions explicitly stated in the problem."
        )
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Exploration of Solution Paths
        approaches = [
            "Solve the problem using algebraic manipulation and symbolic reasoning.",
            "Solve the problem using geometric reasoning, including coordinate geometry or synthetic geometry.",
            "Solve the problem using combinatorial analysis or number theory techniques."
        ]
        tasks = [
            self.generate(
                instruction=f"Based on the following decomposition:\n{decomposition}\n"
                            f"Solve the problem using the following approach: {approach}",
                context=self.problem_text
            )
            for approach in approaches
        ]
        results = await asyncio.gather(*tasks)

        # Step 3: Evaluation and Selection of Best Approach
        ensemble_instruction = (
            "Compare the provided solutions and select the most promising one based on criteria such as "
            "simplicity, computational feasibility, and alignment with the problem's constraints. "
            "Provide a justification for your choice."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 4: Refinement and Verification
        refinement_instruction = (
            "Critique and refine the selected solution to ensure clarity, correctness, and adherence to all constraints. "
            "Check if the solution satisfies all conditions of the problem."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarization
        summary_instruction = (
            "Condense the solution into a concise, well-structured format that includes the final answer "
            "and key steps of the reasoning process."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_summary