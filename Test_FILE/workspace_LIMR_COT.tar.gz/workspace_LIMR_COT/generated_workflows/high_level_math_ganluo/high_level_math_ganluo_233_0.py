# Workflow ID: high_level_math_ganluo_233_0
# Benchmark: high_level_math_ganluo
# Data Indices: [60, 565]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key components from the problem
        extraction_instruction = """
        Analyze the problem statement carefully and extract all critical components:
        - Variables involved
        - Constraints or conditions
        - Mathematical relationships (equations, inequalities, etc.)
        - Any specific numerical values or ranges
        - The type of problem (algebra, geometry, combinatorics, etc.)
        Ensure the extraction is complete and structured for further reasoning.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        approach_instruction = f"""
        Based on the extracted information: {extracted_info}
        Propose at least three distinct solution strategies for solving the problem. 
        Consider different mathematical techniques such as:
        - Algebraic manipulation
        - Combinatorial reasoning
        - Number theory methods
        - Geometric interpretations
        For each approach, provide a brief outline of the steps involved and why it might work.
        """
        approaches = await self.generate(instruction=approach_instruction, context=self.problem_text)

        # Step 3: Execute the approaches in parallel
        # Split the approaches into individual strings for parallel processing
        approach_list = approaches.split("\n\n")  # Assuming each approach is separated by double newlines
        parallel_tasks = [
            self.generate(
                instruction=f"Follow this approach step-by-step: {approach}",
                context=self.problem_text
            )
            for approach in approach_list
        ]
        results = await asyncio.gather(*parallel_tasks)

        # Step 4: Evaluate and synthesize the results
        evaluation_instruction = """
        Compare the provided solutions and select the best one based on the following criteria:
        - Correctness: Does the solution satisfy all constraints and conditions?
        - Simplicity: Is the solution straightforward and easy to follow?
        - Completeness: Does the solution address all parts of the problem?
        Provide a justification for your choice.
        """
        best_solution = await self.ensemble(instruction=evaluation_instruction, contexts=results)

        # Step 5: Refine the best solution if necessary
        refinement_instruction = """
        Review the selected solution and refine it if needed. Ensure:
        - All steps are clear and logically sound
        - The final answer is explicitly stated
        - Any potential edge cases or special conditions are addressed
        """
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 6: Summarize the final result
        summary_instruction = """
        Condense the solution into a concise and clear format. Include:
        - The final answer
        - Key steps or reasoning used to arrive at the solution
        Ensure the summary is easy to understand while preserving all essential details.
        """
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_summary