# Workflow ID: high_level_math_ganluo_207_0
# Benchmark: high_level_math_ganluo
# Data Indices: [451, 795]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem text
        extraction_instruction = (
            "Extract all key numerical values, constraints, relationships, and conditions from the problem. "
            "Identify the type of mathematical problem (e.g., combinatorics, number theory, geometry, algebra) "
            "and any advanced techniques that might be required (e.g., modular arithmetic, recursive formulas)."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Explore multiple solution paths in parallel
        algebraic_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using algebraic techniques. "
            "Include polynomial equations, functional equations, sequences, and inequalities if applicable."
        )
        combinatorial_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using combinatorial techniques. "
            "Consider counting arrangements, expected values, and recursive structures."
        )
        geometric_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using geometric techniques. "
            "Include coordinate geometry, synthetic geometry, area/volume calculations, and trigonometry."
        )

        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text)
        )

        # Step 3: Refine each candidate solution
        refinement_instruction = (
            "Critique and refine the given solution. Ensure it satisfies all constraints, handles edge cases, "
            "and is computationally accurate. Provide detailed reasoning for any changes made."
        )
        refined_solutions = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction, context=result) for result in results]
        )

        # Step 4: Select the best solution using Ensemble
        ensemble_instruction = (
            "Compare the given solutions and select the best one based on clarity, efficiency, and adherence "
            "to problem requirements. If multiple solutions are equally valid, synthesize their insights."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_solutions)

        # Step 5: Summarize the final solution
        summarization_instruction = (
            "Condense the final solution into a concise and readable format. Include all key steps and box the final answer."
        )
        summary = await self.summarize(instruction=summarization_instruction, context=final_solution)

        return summary