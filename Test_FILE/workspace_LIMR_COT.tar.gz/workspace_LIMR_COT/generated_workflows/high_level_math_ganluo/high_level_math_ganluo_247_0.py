# Workflow ID: high_level_math_ganluo_247_0
# Benchmark: high_level_math_ganluo
# Data Indices: [334, 574]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Understand the problem by extracting key components
        problem_analysis = await self.generate(
            instruction="""Extract and analyze all key components of the problem, including:
            - Variables and their domains
            - Equations or relationships
            - Constraints
            - Mathematical domain (e.g., algebra, geometry, combinatorics)
            Provide a structured breakdown of the problem.""",
            context=self.problem_text
        )

        # Step 2: Generate multiple solution candidates in parallel
        candidate_solutions = await asyncio.gather(
            self.generate(
                instruction=f"""Using the problem analysis: {problem_analysis}
                Solve the problem using an algebraic approach. Include all steps and reasoning.""",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"""Using the problem analysis: {problem_analysis}
                Solve the problem using a geometric approach. Include all steps and reasoning.""",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"""Using the problem analysis: {problem_analysis}
                Solve the problem using combinatorial or number-theoretic techniques. Include all steps and reasoning.""",
                context=self.problem_text
            )
        )

        # Step 3: Refine and validate each candidate solution
        refined_solutions = await asyncio.gather(
            *[self.revise(
                instruction="""Critique and refine the solution to ensure it satisfies all problem constraints.
                Check for mathematical correctness, logical consistency, and completeness.""",
                context=solution
            ) for solution in candidate_solutions]
        )

        # Step 4: Select the best solution using ensemble
        final_solution = await self.ensemble(
            instruction="""Compare the refined solutions and select the best one based on:
            - Correctness and completeness
            - Clarity and elegance
            - Adherence to problem constraints""",
            contexts=refined_solutions
        )

        # Step 5: Summarize the final solution
        summarized_solution = await self.summarize(
            instruction="Condense the final solution into a concise, clear format while preserving all key steps and reasoning.",
            context=final_solution
        )

        return summarized_solution