# Workflow ID: high_level_math_ganluo_372_0
# Benchmark: high_level_math_ganluo
# Data Indices: [716, 437]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract critical information and identify problem domain
        extraction_instruction = (
            "Extract all numerical values, variables, constraints, and relationships from the problem. "
            "Identify the mathematical domain (e.g., algebra, geometry, combinatorics) and suggest potential techniques. "
            "Ensure the output is structured and easy to parse."
        )
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple independent solution approaches
        generate_instructions = [
            f"Using an algebraic approach, solve the problem based on the following extracted information: {extraction}. "
            "Provide step-by-step reasoning and ensure all constraints are satisfied.",

            f"Using a geometric approach, solve the problem based on the following extracted information: {extraction}. "
            "If applicable, include diagrams or coordinate transformations.",

            f"Using a combinatorial or probabilistic approach, solve the problem based on the following extracted information: {extraction}. "
            "Consider casework, recursive formulas, or generating functions if needed."
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in generate_instructions]
        )

        # Step 3: Revise and validate each approach
        revise_instruction = (
            "Critique and refine the provided solution. "
            "Check for mathematical correctness, logical consistency, and adherence to all constraints. "
            "Identify and address any edge cases or alternative interpretations."
        )
        refined_approaches = await asyncio.gather(
            *[self.revise(instruction=revise_instruction, context=approach) for approach in approaches]
        )

        # Step 4: Synthesize and select the best solution
        ensemble_instruction = (
            "Evaluate the following candidate solutions. "
            "Select the most robust, elegant, and mathematically rigorous solution. "
            "Provide justification for your choice and summarize the final answer in a concise format."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_approaches)

        return final_solution