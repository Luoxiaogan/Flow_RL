# Workflow ID: high_level_math_ganluo_248_0
# Benchmark: high_level_math_ganluo
# Data Indices: [789, 696]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Carefully analyze the problem statement and extract all key components, "
            "including variables, constants, relationships, and constraints. "
            "Identify the type of mathematical problem (e.g., algebraic, geometric, combinatorial) "
            "and note any special conditions or edge cases."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        generate_instruction_template = (
            "Based on the extracted information: {info}, "
            "develop a detailed step-by-step solution using the following approach: {approach}. "
            "Ensure all calculations are rigorous and clearly explained."
        )
        approaches = ["algebraic manipulation", "geometric reasoning", "combinatorial analysis", "number theory"]
        tasks = [
            self.generate(
                instruction=generate_instruction_template.format(info=extracted_info, approach=approach),
                context=self.problem_text
            )
            for approach in approaches
        ]
        solutions = await asyncio.gather(*tasks)

        # Step 3: Refine each solution to ensure correctness
        refine_instruction_template = (
            "Review the following solution: {solution}. "
            "Critique its reasoning, verify all calculations, and suggest improvements where necessary. "
            "Ensure the solution satisfies all constraints and conditions of the problem."
        )
        refinement_tasks = [
            self.revise(
                instruction=refine_instruction_template.format(solution=solution),
                context=self.problem_text
            )
            for solution in solutions
        ]
        refined_solutions = await asyncio.gather(*refinement_tasks)

        # Step 4: Select the best solution using Ensemble
        ensemble_instruction = (
            "Evaluate the following candidate solutions: {solutions}. "
            "Compare their correctness, clarity, and efficiency. "
            "Select the most robust and mathematically sound solution, or synthesize a new one "
            "if necessary."
        )
        best_solution = await self.ensemble(
            instruction=ensemble_instruction.format(solutions=refined_solutions),
            contexts=refined_solutions
        )

        # Step 5: Summarize the final result
        summarize_instruction = (
            "Condense the following solution: {solution}. "
            "Present the final answer in a clear and concise format, ensuring it directly addresses "
            "the problem statement."
        )
        final_answer = await self.summarize(
            instruction=summarize_instruction.format(solution=best_solution),
            context=self.problem_text
        )

        return final_answer