# Workflow ID: high_level_math_ganluo_202_0
# Benchmark: high_level_math_ganluo
# Data Indices: [698, 639]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Problem Understanding and Decomposition
        problem_analysis = await self.generate(
            instruction="Carefully analyze the problem statement. Identify all given information, constraints, and what is being asked. Break the problem into smaller, manageable sub-problems. Highlight any mathematical concepts or techniques that might be relevant.",
            context=self.problem_text
        )

        # Step 2: Explore Multiple Solution Approaches in Parallel
        algebraic_approach = self.generate(
            instruction="Attempt to solve the problem using algebraic methods. Focus on equations, inequalities, or functional relationships. Provide a step-by-step explanation of your reasoning.",
            context=problem_analysis
        )
        geometric_approach = self.generate(
            instruction="Attempt to solve the problem using geometric methods. Consider coordinate geometry, synthetic geometry, or trigonometric relationships. Provide a step-by-step explanation of your reasoning.",
            context=problem_analysis
        )
        combinatorial_approach = self.generate(
            instruction="Attempt to solve the problem using combinatorial or probabilistic methods. Consider counting principles, recursive structures, or expected value calculations. Provide a step-by-step explanation of your reasoning.",
            context=problem_analysis
        )
        
        # Run the approaches in parallel
        approaches = await asyncio.gather(algebraic_approach, geometric_approach, combinatorial_approach)

        # Step 3: Evaluate and Synthesize the Best Solution
        best_solution = await self.ensemble(
            instruction="Compare the three candidate solutions. Evaluate them based on correctness, completeness, and elegance. Select the best solution or synthesize a new one by combining insights from multiple approaches.",
            contexts=approaches
        )

        # Step 4: Refine the Chosen Solution
        refined_solution = await self.revise(
            instruction="Critique and refine the chosen solution. Ensure all constraints are satisfied, calculations are accurate, and the reasoning is clear. Improve the presentation if necessary.",
            context=best_solution
        )

        # Step 5: Summarize the Final Answer
        final_summary = await self.summarize(
            instruction="Provide a concise summary of the solution. Include the key steps, reasoning, and the final answer in a clear and structured format.",
            context=refined_solution
        )

        return final_summary