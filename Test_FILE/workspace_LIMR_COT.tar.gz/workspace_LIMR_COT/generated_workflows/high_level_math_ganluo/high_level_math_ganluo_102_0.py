# Workflow ID: high_level_math_ganluo_102_0
# Benchmark: high_level_math_ganluo
# Data Indices: [942, 341]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key mathematical entities and interpret the problem
        extraction = await self.generate(
            instruction="Extract all variables, equations, constraints, and relationships from the problem. "
                        "Identify the type of mathematical reasoning required (e.g., algebraic, geometric, combinatorial). "
                        "Provide a structured summary of the problem's components.",
            context=self.problem_text
        )

        # Step 2: Explore multiple solution approaches in parallel
        algebraic_solution = self.generate(
            instruction=f"Using algebraic reasoning, solve the problem step-by-step. "
                        f"Ensure all constraints are satisfied. Extracted information: {extraction}",
            context=self.problem_text
        )
        geometric_solution = self.generate(
            instruction=f"Using geometric reasoning, solve the problem step-by-step. "
                        f"Ensure all constraints are satisfied. Extracted information: {extraction}",
            context=self.problem_text
        )
        combinatorial_solution = self.generate(
            instruction=f"Using combinatorial or probabilistic reasoning, solve the problem step-by-step. "
                        f"Ensure all constraints are satisfied. Extracted information: {extraction}",
            context=self.problem_text
        )

        # Execute parallel exploration
        results = await asyncio.gather(algebraic_solution, geometric_solution, combinatorial_solution)

        # Step 3: Evaluate and select the best solution
        best_solution = await self.ensemble(
            instruction="Compare the provided solutions. Select the most rigorous, complete, and valid solution. "
                        "Ensure the chosen solution satisfies all constraints and edge cases.",
            contexts=results
        )

        # Step 4: Refine the chosen solution
        refined_solution = await self.revise(
            instruction="Critique and refine the solution. Ensure mathematical rigor, clarity, and correctness. "
                        "Address any gaps or ambiguities.",
            context=best_solution
        )

        # Step 5: Summarize the final result
        final_result = await self.summarize(
            instruction="Condense the solution into a concise, well-structured format. "
                        "Include only the essential steps and the final answer.",
            context=refined_solution
        )

        return final_result