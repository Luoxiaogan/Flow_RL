# Workflow ID: high_level_math_ganluo_398_0
# Benchmark: high_level_math_ganluo
# Data Indices: [686, 609]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Problem Decomposition
        decomposition_instruction = (
            "Extract all key components of the problem, including numerical values, constraints, "
            "relationships, and the objective. Organize this information clearly."
        )
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Explore Multiple Solution Paths
        algebra_instruction = (
            f"Based on the extracted information: {decomposition}\n"
            "Solve the problem using algebraic methods. Show all steps and reasoning."
        )
        geometry_instruction = (
            f"Based on the extracted information: {decomposition}\n"
            "Solve the problem using geometric methods. Show all steps and reasoning."
        )
        combinatorics_instruction = (
            f"Based on the extracted information: {decomposition}\n"
            "Solve the problem using combinatorial methods. Show all steps and reasoning."
        )

        algebra_solution, geometry_solution, combinatorics_solution = await asyncio.gather(
            self.generate(instruction=algebra_instruction, context=self.problem_text),
            self.generate(instruction=geometry_instruction, context=self.problem_text),
            self.generate(instruction=combinatorics_instruction, context=self.problem_text)
        )

        # Step 3: Refine Solutions
        refinement_instruction = (
            "Critique and refine the given solution. Address any errors, omissions, or ambiguities. "
            "Ensure the solution is mathematically rigorous and satisfies all problem constraints."
        )
        refined_algebra = await self.revise(instruction=refinement_instruction, context=algebra_solution)
        refined_geometry = await self.revise(instruction=refinement_instruction, context=geometry_solution)
        refined_combinatorics = await self.revise(instruction=refinement_instruction, context=combinatorics_solution)

        # Step 4: Summarize Intermediate Results
        summary_instruction = (
            "Condense the given solution into a concise summary while preserving all key insights and results."
        )
        summarized_algebra = await self.summarize(instruction=summary_instruction, context=refined_algebra)
        summarized_geometry = await self.summarize(instruction=summary_instruction, context=refined_geometry)
        summarized_combinatorics = await self.summarize(instruction=summary_instruction, context=refined_combinatorics)

        # Step 5: Final Synthesis
        synthesis_instruction = (
            "Compare the given solutions and select the best one, or synthesize elements from multiple solutions "
            "to form a complete and optimal solution. Ensure the final solution satisfies all problem constraints."
        )
        final_solution = await self.ensemble(
            instruction=synthesis_instruction,
            contexts=[summarized_algebra, summarized_geometry, summarized_combinatorics]
        )

        # Step 6: Verification
        verification_instruction = (
            "Verify that the given solution satisfies all constraints and objectives of the original problem. "
            "Provide a final confirmation or suggest further refinements if needed."
        )
        verified_solution = await self.generate(instruction=verification_instruction, context=final_solution)

        return verified_solution