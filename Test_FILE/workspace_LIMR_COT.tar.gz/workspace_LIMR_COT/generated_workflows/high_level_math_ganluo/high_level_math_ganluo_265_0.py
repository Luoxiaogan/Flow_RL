# Workflow ID: high_level_math_ganluo_265_0
# Benchmark: high_level_math_ganluo
# Data Indices: [652, 483]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract core problem elements
        extraction_instruction = (
            "Analyze the problem statement and extract all key elements, including variables, "
            "constraints, relationships, and the goal. Organize these elements into categories such as "
            "numerical values, equations, inequalities, geometric properties, or combinatorial structures. "
            "Ensure the extraction is comprehensive and structured."
        )
        extracted_elements = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Identify mathematical domain and generate solution strategies
        strategy_instruction_template = (
            "Based on the extracted elements: {elements}, identify the mathematical domain of the problem "
            "(e.g., algebra, geometry, combinatorics, number theory). Propose at least two distinct solution "
            "strategies, detailing the reasoning process for each. Include step-by-step plans for solving "
            "the problem using these strategies."
        )
        strategy_instruction = strategy_instruction_template.format(elements=extracted_elements)
        strategies = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Execute solution strategies in parallel
        approach_instructions = [
            f"Follow this solution strategy step by step: {strategy}" for strategy in strategies.split("\n\n")
        ]
        results = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 4: Refine and validate solutions
        refine_instruction_template = (
            "Review the following solution: {solution}. Check for correctness, completeness, and clarity. "
            "Ensure all constraints from the problem are satisfied. Revise the solution if necessary, "
            "providing detailed improvements."
        )
        refined_results = await asyncio.gather(
            *[self.revise(instruction=refine_instruction_template.format(solution=result), context=result)
              for result in results]
        )

        # Step 5: Select the best solution using Ensemble
        ensemble_instruction = (
            "Compare the following solutions and select the best one based on correctness, clarity, and efficiency. "
            "Provide a justification for your choice."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_results)

        # Step 6: Summarize the final solution
        summary_instruction = (
            "Condense the following solution into a concise, well-structured format suitable for presentation. "
            "Include all key steps and the final answer."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=best_solution)

        return final_summary