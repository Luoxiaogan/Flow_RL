# Workflow ID: high_level_math_ganluo_255_0
# Benchmark: high_level_math_ganluo
# Data Indices: [201, 797]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Thoroughly analyze the problem statement and extract all critical components, "
            "such as equations, variables, constraints, and mathematical objects. "
            "Identify the type of problem (e.g., algebra, geometry, number theory) and any specific techniques that might apply. "
            "Provide the extracted information in a structured format."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution strategies in parallel
        strategy_instructions = [
            f"Using the extracted information: {extracted_info}, solve the problem using algebraic techniques. "
            "Focus on equations, substitutions, and simplifications. Provide a step-by-step solution.",

            f"Using the extracted information: {extracted_info}, solve the problem using number theory. "
            "Focus on divisibility, modular arithmetic, and prime factorization. Provide a step-by-step solution.",

            f"Using the extracted information: {extracted_info}, solve the problem using geometric reasoning. "
            "Focus on coordinate geometry, synthetic geometry, and trigonometric relationships. Provide a step-by-step solution."
        ]
        strategies = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in strategy_instructions]
        )

        # Step 3: Evaluate and select the best approach
        ensemble_instruction = (
            "Compare the following candidate solutions and select the most rigorous, clear, and mathematically sound approach. "
            "Ensure the chosen solution satisfies all constraints and aligns with the problem requirements. "
            "If multiple solutions are valid, choose the one that is most efficient or elegant."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=strategies)

        # Step 4: Refine the selected solution
        refinement_instruction = (
            "Critically review the selected solution and refine it for mathematical accuracy, clarity, and completeness. "
            "Ensure all steps are justified, and verify that the solution satisfies all problem constraints. "
            "Address any edge cases or special conditions explicitly."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the refined solution into a concise and clear answer. "
            "Include only the essential steps and the final result. Ensure the summary directly addresses the problem."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer