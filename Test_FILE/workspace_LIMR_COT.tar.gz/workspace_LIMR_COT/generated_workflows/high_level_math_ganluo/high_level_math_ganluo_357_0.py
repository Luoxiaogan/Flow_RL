# Workflow ID: high_level_math_ganluo_357_0
# Benchmark: high_level_math_ganluo
# Data Indices: [852, 617]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Understand and decompose the problem
        understanding = await self.generate(
            instruction="Analyze the problem thoroughly. Identify all variables, constraints, "
                        "and relationships. Highlight any special conditions or edge cases.",
            context=self.problem_text
        )

        # Step 2: Generate multiple solution approaches in parallel
        algebraic_approach = self.generate(
            instruction="Solve the problem using algebraic methods. Include detailed steps "
                        "for equations, substitutions, and simplifications.",
            context=understanding
        )
        geometric_approach = self.generate(
            instruction="Solve the problem using geometric reasoning. Consider coordinate geometry, "
                        "synthetic geometry, or trigonometric methods as applicable.",
            context=understanding
        )
        combinatorial_approach = self.generate(
            instruction="Solve the problem using combinatorial analysis. Count arrangements, "
                        "apply recursive formulas, or use generating functions if needed.",
            context=understanding
        )
        number_theory_approach = self.generate(
            instruction="Solve the problem using number theory techniques. Apply modular arithmetic, "
                        "prime factorization, or divisibility rules as appropriate.",
            context=understanding
        )

        # Execute all approaches in parallel
        approaches = await asyncio.gather(
            algebraic_approach,
            geometric_approach,
            combinatorial_approach,
            number_theory_approach
        )

        # Step 3: Evaluate and synthesize the best solution
        best_solution = await self.ensemble(
            instruction="Compare the provided solutions. Select the most mathematically rigorous, "
                        "efficient, and elegant approach. Resolve any discrepancies between solutions.",
            contexts=approaches
        )

        # Step 4: Refine the selected solution
        refined_solution = await self.revise(
            instruction="Critique and improve the solution. Ensure all steps are clear, logical, "
                        "and fully address the problem's requirements.",
            context=best_solution
        )

        # Step 5: Summarize the final answer
        final_answer = await self.summarize(
            instruction="Condense the solution into a concise, well-structured response. "
                        "Highlight the key steps and the final answer.",
            context=refined_solution
        )

        return final_answer