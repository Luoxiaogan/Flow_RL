# Workflow ID: high_level_math_ganluo_203_0
# Benchmark: high_level_math_ganluo
# Data Indices: [495, 11]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information and categorize the problem
        extraction_instruction = (
            "Analyze the problem statement to identify the following:\n"
            "- Key numerical values and constraints\n"
            "- The type of mathematical problem (e.g., combinatorics, geometry, algebra)\n"
            "- Any special conditions or requirements\n"
            "Provide this information in a structured format."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        approach_instructions = [
            f"Using an algebraic approach, solve the problem based on the following extracted information: {extracted_info}",
            f"Using a geometric approach, solve the problem based on the following extracted information: {extracted_info}",
            f"Using a combinatorial approach, solve the problem based on the following extracted information: {extracted_info}",
            f"Using number theory, solve the problem based on the following extracted information: {extracted_info}"
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Evaluate and select the best solution
        evaluation_instruction = (
            "Compare the provided candidate solutions and select the best one based on the following criteria:\n"
            "- Correctness and alignment with problem constraints\n"
            "- Simplicity and clarity of reasoning\n"
            "- Mathematical rigor and completeness\n"
            "If none are satisfactory, indicate that further refinement is needed."
        )
        best_solution = await self.ensemble(instruction=evaluation_instruction, contexts=approaches)

        # Step 4: Refine the selected solution if necessary
        refinement_instruction = (
            "Critically review the selected solution and make improvements if needed.\n"
            "Ensure the solution satisfies all problem constraints and is presented clearly."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the solution into a concise and clear format.\n"
            "Include all critical steps and the final answer."
        )
        final_output = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_output