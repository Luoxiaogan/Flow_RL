# Workflow ID: high_level_math_ganluo_76_0
# Benchmark: high_level_math_ganluo
# Data Indices: [564, 494]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all key information from the problem, including variables, equations, constraints, "
            "and the specific question being asked. Organize this information clearly."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple candidate solutions in parallel
        candidate_instructions = [
            "Solve the problem using algebraic manipulation and symbolic reasoning.",
            "Solve the problem using recursive formulas or iterative methods.",
            "Solve the problem using geometric or combinatorial reasoning."
        ]
        candidate_solutions = await asyncio.gather(
            *(self.generate(instruction=instr, context=extracted_info) for instr in candidate_instructions)
        )

        # Step 3: Refine each candidate solution
        refinement_instruction_template = (
            "Critique and refine the following solution. Ensure all steps are mathematically rigorous, "
            "verify intermediate results, and confirm the final answer satisfies the problem's requirements."
        )
        refined_solutions = await asyncio.gather(
            *(self.revise(instruction=refinement_instruction_template, context=sol) for sol in candidate_solutions)
        )

        # Step 4: Synthesize the best solution
        synthesis_instruction = (
            "Evaluate the provided solutions. Select the most correct, elegant, and complete solution. "
            "If multiple solutions are valid, synthesize their insights into a unified answer."
        )
        final_solution = await self.ensemble(instruction=synthesis_instruction, contexts=refined_solutions)

        # Step 5: Summarize the final answer
        summary_instruction = (
            "Extract and present the final answer in a clear and concise format. Include any necessary "
            "justification or boxed results as required by the problem."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=final_solution)

        return final_answer