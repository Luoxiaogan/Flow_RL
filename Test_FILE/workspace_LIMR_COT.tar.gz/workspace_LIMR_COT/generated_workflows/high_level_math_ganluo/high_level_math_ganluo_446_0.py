# Workflow ID: high_level_math_ganluo_446_0
# Benchmark: high_level_math_ganluo
# Data Indices: [385, 833]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract problem details and identify mathematical structure
        extraction_instruction = """
        Analyze the problem thoroughly and extract all relevant information, including:
        - Known values and variables
        - Constraints and conditions
        - The specific question being asked
        - Any implicit mathematical structures (e.g., equations, geometric relationships)
        Provide the extracted information in a structured format.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution strategies in parallel
        strategies = await asyncio.gather(
            self.generate(
                instruction=f"""
                Based on the extracted information: {extracted_info}
                Develop an algebraic solution strategy. Include step-by-step reasoning and calculations.
                """,
                context=self.problem_text
            ),
            self.generate(
                instruction=f"""
                Based on the extracted information: {extracted_info}
                Develop a geometric solution strategy. Include step-by-step reasoning and calculations.
                """,
                context=self.problem_text
            ),
            self.generate(
                instruction=f"""
                Based on the extracted information: {extracted_info}
                Develop a combinatorial or number-theoretic solution strategy. Include step-by-step reasoning and calculations.
                """,
                context=self.problem_text
            )
        )

        # Step 3: Revise and refine each solution strategy
        refined_strategies = await asyncio.gather(
            *[self.revise(
                instruction=f"Carefully review and improve the following solution strategy: {strategy}",
                context=strategy
            ) for strategy in strategies]
        )

        # Step 4: Summarize the refined strategies
        summarized_strategies = await asyncio.gather(
            *[self.summarize(
                instruction=f"Condense the following refined solution strategy into a concise summary: {strategy}",
                context=strategy
            ) for strategy in refined_strategies]
        )

        # Step 5: Select the best solution using Ensemble
        final_solution = await self.ensemble(
            instruction="""
            Compare the following summarized solution strategies and select the best one based on:
            - Correctness and mathematical rigor
            - Simplicity and elegance
            - Alignment with the problem's constraints
            Provide the selected solution along with a brief justification.
            """,
            contexts=summarized_strategies
        )

        return final_solution