# Workflow ID: high_level_math_ganluo_314_0
# Benchmark: high_level_math_ganluo
# Data Indices: [923, 725]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key problem components
        extraction_instruction = (
            "Carefully analyze the problem statement and extract all key mathematical entities, "
            "including variables, constraints, and relationships. Organize the information clearly."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        algebraic_instruction = (
            f"Using the extracted information: {extracted_info}, develop an algebraic approach to solve the problem. "
            "Focus on equations, inequalities, and functional relationships."
        )
        combinatorial_instruction = (
            f"Using the extracted information: {extracted_info}, develop a combinatorial or probabilistic approach. "
            "Consider counting principles, recursive structures, and symmetry."
        )
        geometric_instruction = (
            f"Using the extracted information: {extracted_info}, develop a geometric approach. "
            "Use coordinate geometry, synthetic geometry, or trigonometric methods as appropriate."
        )

        approaches = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and select the best approach
        ensemble_instruction = (
            "Compare the provided solution approaches and select the most promising one. "
            "Consider correctness, simplicity, and computational feasibility. Provide a justification for your choice."
        )
        best_approach = await self.ensemble(instruction=ensemble_instruction, contexts=approaches)

        # Step 4: Refine the selected approach
        refinement_instruction = (
            f"Refine the following solution approach to ensure it adheres to all constraints and is mathematically rigorous: {best_approach}. "
            "Address any gaps or ambiguities in the reasoning."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_approach)

        # Step 5: Summarize the final solution
        summary_instruction = (
            f"Summarize the refined solution concisely while preserving all key steps and results: {refined_solution}. "
            "Ensure the summary is clear and easy to follow."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_summary