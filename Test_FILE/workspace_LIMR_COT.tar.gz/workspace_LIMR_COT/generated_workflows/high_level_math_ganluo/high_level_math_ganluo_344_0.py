# Workflow ID: high_level_math_ganluo_344_0
# Benchmark: high_level_math_ganluo
# Data Indices: [466, 450]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Problem Understanding and Decomposition
        decomposition_instruction = (
            "Extract all key components of the problem, including variables, constraints, "
            "mathematical relationships, and the goal. Provide a structured breakdown of the problem."
        )
        problem_decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Exploration of Multiple Solution Paths
        approach_1_instruction = (
            f"Based on the problem decomposition: {problem_decomposition}, solve the problem using algebraic methods. "
            "Provide a detailed step-by-step solution."
        )
        approach_2_instruction = (
            f"Based on the problem decomposition: {problem_decomposition}, solve the problem using combinatorial or recursive reasoning. "
            "Provide a detailed step-by-step solution."
        )
        approach_3_instruction = (
            f"Based on the problem decomposition: {problem_decomposition}, solve the problem using geometric or number-theoretic methods. "
            "Provide a detailed step-by-step solution."
        )

        candidate_solutions = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text),
            self.generate(instruction=approach_3_instruction, context=self.problem_text)
        )

        # Step 3: Refinement and Validation
        refine_instruction_template = (
            "Critique and improve the following solution: {solution}. Check for mathematical correctness, "
            "alignment with problem constraints, and handling of edge cases. Provide a revised solution."
        )
        refined_solutions = await asyncio.gather(
            self.revise(instruction=refine_instruction_template.format(solution=candidate_solutions[0]), context=self.problem_text),
            self.revise(instruction=refine_instruction_template.format(solution=candidate_solutions[1]), context=self.problem_text),
            self.revise(instruction=refine_instruction_template.format(solution=candidate_solutions[2]), context=self.problem_text)
        )

        # Step 4: Ensemble Decision-Making
        ensemble_instruction = (
            "Compare and synthesize the following solutions: {solutions}. Select the most robust and efficient solution "
            "or combine insights from multiple approaches. Ensure the final solution satisfies all problem constraints."
        )
        final_solution = await self.ensemble(
            instruction=ensemble_instruction.format(solutions=refined_solutions),
            contexts=refined_solutions
        )

        # Step 5: Final Output Preparation
        summarize_instruction = (
            "Condense the following solution into a clear, concise format suitable for presentation: {solution}. "
            "Ensure the answer is explicit and meets AIME standards."
        )
        final_output = await self.summarize(instruction=summarize_instruction.format(solution=final_solution), context=self.problem_text)

        return final_output