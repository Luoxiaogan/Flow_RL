# Workflow ID: high_level_math_ganluo_179_0
# Benchmark: high_level_math_ganluo
# Data Indices: [713, 897]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract and classify the problem
        extraction_instruction = (
            "Extract all numerical values, variables, and constraints from the problem. "
            "Classify the problem into one of the following domains: algebra, geometry, "
            "number theory, combinatorics, or a combination. Provide a brief summary of "
            "the problem's requirements and any special considerations."
        )
        problem_summary = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution strategies
        strategy_instructions = [
            f"Develop an algebraic approach to solve the problem. Use the following summary: {problem_summary}",
            f"Develop a geometric approach to solve the problem. Use the following summary: {problem_summary}",
            f"Develop a number-theoretic approach to solve the problem. Use the following summary: {problem_summary}",
            f"Develop a combinatorial approach to solve the problem. Use the following summary: {problem_summary}"
        ]
        strategies = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in strategy_instructions]
        )

        # Step 3: Refine each strategy
        refinement_instruction = (
            "Critically analyze the provided solution strategy. Identify any logical gaps, "
            "inconsistencies, or areas for improvement. Revise the strategy to make it more "
            "robust and mathematically sound."
        )
        refined_strategies = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction, context=strategy) for strategy in strategies]
        )

        # Step 4: Synthesize the best solution
        synthesis_instruction = (
            "Evaluate the provided solution strategies. Select the most robust and mathematically "
            "sound approach that satisfies all constraints and conditions. If multiple strategies "
            "are equally valid, combine their strengths into a single solution."
        )
        final_solution = await self.ensemble(instruction=synthesis_instruction, contexts=refined_strategies)

        # Step 5: Verify and finalize the solution
        verification_instruction = (
            "Verify that the solution satisfies all constraints and conditions stated in the problem. "
            "Check for edge cases and ensure the solution is mathematically rigorous. Summarize the "
            "final answer in a clear and concise format."
        )
        verified_solution = await self.revise(instruction=verification_instruction, context=final_solution)

        return verified_solution