# Workflow ID: high_level_math_ganluo_18_0
# Benchmark: high_level_math_ganluo
# Data Indices: [567, 276]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information and categorize the problem
        extraction_instruction = (
            "Carefully analyze the problem to extract all numerical values, constraints, "
            "and the specific question being asked. Identify the mathematical domain "
            "(e.g., algebra, geometry, combinatorics) and any patterns or structures present."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution strategies in parallel
        strategy_instructions = [
            f"Using the extracted information: {extracted_info}, solve the problem using an algebraic approach. "
            "Include detailed steps and reasoning.",

            f"Using the extracted information: {extracted_info}, solve the problem using a geometric approach. "
            "Include detailed steps and reasoning.",

            f"Using the extracted information: {extracted_info}, solve the problem using a combinatorial approach. "
            "Include detailed steps and reasoning."
        ]
        strategies = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in strategy_instructions]
        )

        # Step 3: Revise and refine each solution strategy
        refinement_instruction = (
            "Critique the provided solution strategy. Check for mathematical correctness, logical consistency, "
            "and adherence to the problem constraints. Suggest improvements if necessary."
        )
        refined_strategies = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction, context=strategy) for strategy in strategies]
        )

        # Step 4: Select the best solution using Ensemble
        ensemble_instruction = (
            "Evaluate the provided solution strategies. Select the one that is most mathematically rigorous, "
            "clearly explained, and aligned with the problem constraints. Provide a justification for your choice."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_strategies)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the selected solution into a concise and well-structured final answer. Ensure all key steps "
            "and reasoning are included, and the answer is presented in a clear format."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=best_solution)

        return final_answer