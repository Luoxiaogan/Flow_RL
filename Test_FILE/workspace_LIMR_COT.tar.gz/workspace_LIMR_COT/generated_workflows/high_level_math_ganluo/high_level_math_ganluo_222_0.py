# Workflow ID: high_level_math_ganluo_222_0
# Benchmark: high_level_math_ganluo
# Data Indices: [174, 475]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key components of the problem
        extraction_instruction = (
            "Extract all key components of the problem, including equations, inequalities, "
            "constraints, variables, and constants. Identify the mathematical domain "
            "(e.g., number theory, algebra, geometry) and any specific techniques likely required."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution strategies
        strategy_instructions = [
            f"Formulate an algebraic solution strategy based on the following extracted information: {extracted_info}",
            f"Formulate a modular arithmetic solution strategy based on the following extracted information: {extracted_info}",
            f"Formulate a combinatorial or recursive solution strategy based on the following extracted information: {extracted_info}"
        ]
        strategies = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in strategy_instructions]
        )

        # Step 3: Select the best strategy using Ensemble
        selection_instruction = (
            "Evaluate the following solution strategies and select the one that is most feasible, "
            "clear, and aligned with the problem's constraints. Provide a justification for your choice."
        )
        best_strategy = await self.ensemble(instruction=selection_instruction, contexts=strategies)

        # Step 4: Execute the chosen strategy step-by-step
        execution_instruction = (
            f"Execute the chosen solution strategy step-by-step. Ensure each step is mathematically sound "
            f"and verify intermediate results against the problem's constraints. Use the following strategy: {best_strategy}"
        )
        solution_steps = await self.generate(instruction=execution_instruction, context=self.problem_text)

        # Step 5: Refine the solution if necessary
        refinement_instruction = (
            "Critique and refine the following solution to ensure correctness, clarity, and completeness. "
            "Address any gaps or ambiguities."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=solution_steps)

        # Step 6: Summarize the final solution
        summary_instruction = (
            "Condense the following solution into a concise, well-structured format. Include the final answer "
            "and ensure it satisfies all problem constraints."
        )
        final_solution = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_solution