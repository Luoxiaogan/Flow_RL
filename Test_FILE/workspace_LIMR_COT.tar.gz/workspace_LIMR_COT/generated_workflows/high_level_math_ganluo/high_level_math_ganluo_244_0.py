# Workflow ID: high_level_math_ganluo_244_0
# Benchmark: high_level_math_ganluo
# Data Indices: [354, 120]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Problem Understanding & Decomposition
        decomposition_instruction = (
            "Analyze the problem to identify its core components, including equations, variables, and constraints. "
            "Determine the mathematical domain (e.g., algebra, geometry, combinatorics) and suggest potential techniques or approaches. "
            "Provide a structured breakdown of the problem."
        )
        problem_breakdown = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Generate Multiple Solution Paths
        generate_instruction_template = (
            "Based on the following problem breakdown:\n{breakdown}\n"
            "Develop a complete solution using {approach}. Ensure the solution is mathematically rigorous and addresses all constraints. "
            "If multiple steps are required, explain them clearly."
        )

        # Define multiple approaches dynamically
        approaches = [
            "algebraic manipulation",
            "geometric reasoning",
            "combinatorial analysis",
            "number theory techniques"
        ]
        generate_tasks = [
            self.generate(
                instruction=generate_instruction_template.format(breakdown=problem_breakdown, approach=approach),
                context=self.problem_text
            )
            for approach in approaches
        ]
        raw_solutions = await asyncio.gather(*generate_tasks)

        # Step 3: Refinement & Validation
        refine_instruction_template = (
            "Review the following solution:\n{solution}\n"
            "Ensure it is mathematically correct, complete, and satisfies all constraints in the original problem. "
            "Refine any unclear or incorrect steps, and provide a polished version of the solution."
        )
        refine_tasks = [
            self.revise(
                instruction=refine_instruction_template.format(solution=solution),
                context=self.problem_text
            )
            for solution in raw_solutions
        ]
        refined_solutions = await asyncio.gather(*refine_tasks)

        # Step 4: Ensemble Selection
        ensemble_instruction = (
            "Compare the following candidate solutions:\n{solutions}\n"
            "Select the most robust, elegant, and mathematically sound solution. "
            "If multiple solutions are equally valid, synthesize them into a single coherent answer."
        )
        final_solution = await self.ensemble(
            instruction=ensemble_instruction.format(solutions="\n---\n".join(refined_solutions)),
            contexts=refined_solutions
        )

        # Step 5: Summarization
        summarize_instruction = (
            "Condense the following solution into a concise, clear answer:\n{solution}\n"
            "Ensure the final response directly addresses the original problem and includes all necessary details."
        )
        final_answer = await self.summarize(
            instruction=summarize_instruction.format(solution=final_solution),
            context=self.problem_text
        )

        return final_answer