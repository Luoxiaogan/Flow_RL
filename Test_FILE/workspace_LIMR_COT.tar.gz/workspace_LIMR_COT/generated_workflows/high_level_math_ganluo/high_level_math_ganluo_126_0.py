# Workflow ID: high_level_math_ganluo_126_0
# Benchmark: high_level_math_ganluo
# Data Indices: [465, 76]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key components from the problem
        extraction_instruction = (
            "Extract all relevant mathematical entities from the problem, including variables, equations, "
            "constraints, and the specific question being asked. Organize the information clearly."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate solution strategies based on extracted information
        strategy_instruction = (
            f"Based on the following extracted information:\n{extracted_info}\n"
            "Formulate a detailed plan for solving the problem. Consider multiple approaches (e.g., algebraic, "
            "combinatorial, geometric) and outline the steps for each approach."
        )
        solution_strategies = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Explore multiple solution paths in parallel
        approaches = ["algebraic", "combinatorial", "geometric", "number_theory"]
        tasks = []
        for approach in approaches:
            task_instruction = (
                f"Using the {approach} approach, solve the problem step by step based on the following plan:\n"
                f"{solution_strategies}\nEnsure all steps are clear and logical."
            )
            tasks.append(self.generate(instruction=task_instruction, context=self.problem_text))
        candidate_solutions = await asyncio.gather(*tasks)

        # Step 4: Evaluate and select the best solution
        ensemble_instruction = (
            "Compare the following candidate solutions and select the best one. Ensure the chosen solution "
            "satisfies all constraints and conditions from the original problem. Provide justification for your choice."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=candidate_solutions)

        # Step 5: Refine and finalize the solution
        refinement_instruction = (
            "Refine the following solution to ensure clarity, correctness, and completeness. Check all calculations "
            "and reasoning steps carefully."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 6: Summarize the final answer
        summary_instruction = (
            "Summarize the solution concisely, highlighting the key steps and the final answer. Ensure the summary "
            "is easy to understand and directly addresses the problem."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_summary