# Workflow ID: high_level_math_ganluo_360_0
# Benchmark: high_level_math_ganluo
# Data Indices: [956, 710]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract and Understand the Problem
        problem_understanding = await self.generate(
            instruction="Analyze the problem statement thoroughly. Identify the key components, such as variables, constraints, relationships, and the question being asked. Determine the mathematical domain (e.g., geometry, number theory) and any specific techniques that might be applicable.",
            context=self.problem_text
        )

        # Step 2: Generate Multiple Solution Approaches
        algebraic_approach = self.generate(
            instruction=f"Based on the problem understanding: {problem_understanding}, solve the problem using algebraic methods. Include all steps, transformations, and justifications.",
            context=self.problem_text
        )
        geometric_approach = self.generate(
            instruction=f"Based on the problem understanding: {problem_understanding}, solve the problem using geometric reasoning. Reference relevant theorems, properties, and relationships.",
            context=self.problem_text
        )
        combinatorial_approach = self.generate(
            instruction=f"Based on the problem understanding: {problem_understanding}, solve the problem using combinatorial or probabilistic methods. Consider all possible cases and calculate probabilities or counts where applicable.",
            context=self.problem_text
        )

        # Execute approaches in parallel
        approaches = await asyncio.gather(algebraic_approach, geometric_approach, combinatorial_approach)

        # Step 3: Evaluate and Synthesize Approaches
        best_solution = await self.ensemble(
            instruction="Compare the provided solutions. Evaluate their correctness, efficiency, and adherence to the problem constraints. Select the most robust and elegant solution, or synthesize elements from multiple solutions if necessary.",
            contexts=approaches
        )

        # Step 4: Refine the Chosen Solution
        refined_solution = await self.revise(
            instruction="Review the selected solution for completeness and accuracy. Address any gaps, clarify ambiguous steps, and ensure all constraints are satisfied.",
            context=best_solution
        )

        # Step 5: Summarize the Final Answer
        final_answer = await self.summarize(
            instruction="Condense the solution into a clear and concise format. Include only the essential steps and the final answer, ensuring it is easy to understand and verify.",
            context=refined_solution
        )

        return final_answer