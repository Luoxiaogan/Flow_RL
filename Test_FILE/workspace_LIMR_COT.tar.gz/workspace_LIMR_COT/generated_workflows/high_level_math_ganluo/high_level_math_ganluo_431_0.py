# Workflow ID: high_level_math_ganluo_431_0
# Benchmark: high_level_math_ganluo
# Data Indices: [545, 125]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract key components and analyze the problem
        problem_analysis = await self.generate(
            instruction="Analyze the problem thoroughly. Identify the type of problem (e.g., combinatorics, geometry, algebra), key variables, constraints, and any specific techniques required. Provide a structured breakdown of the problem.",
            context=self.problem_text
        )

        # Step 2: Generate multiple solution approaches
        approaches = await asyncio.gather(
            self.generate(
                instruction="Develop a solution approach using algebraic methods. Include detailed reasoning and any necessary formulas or equations.",
                context=problem_analysis
            ),
            self.generate(
                instruction="Develop a solution approach using combinatorial methods. Include detailed reasoning and any necessary counting principles or recursive structures.",
                context=problem_analysis
            ),
            self.generate(
                instruction="Develop a solution approach using geometric methods. Include detailed reasoning and any necessary diagrams, coordinate transformations, or trigonometric relationships.",
                context=problem_analysis
            )
        )

        # Step 3: Evaluate and select the best approach
        best_approach = await self.ensemble(
            instruction="Compare the provided solution approaches. Select the one that is most feasible, clear, and directly addresses the problem constraints. Justify your choice.",
            contexts=approaches
        )

        # Step 4: Execute the detailed solution
        detailed_solution = await self.generate(
            instruction=f"Using the selected approach: {best_approach}, solve the problem step by step. Show all calculations and reasoning explicitly.",
            context=problem_analysis
        )

        # Step 5: Refine intermediate results if needed
        refined_solution = await self.revise(
            instruction="Review the detailed solution. Clarify any ambiguous steps, correct errors, and ensure all calculations are accurate.",
            context=detailed_solution
        )

        # Step 6: Summarize the final solution
        final_solution = await self.summarize(
            instruction="Condense the solution into a concise, verifiable form. Ensure all problem constraints are satisfied and the answer is clearly stated.",
            context=refined_solution
        )

        return final_solution