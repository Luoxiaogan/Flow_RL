# Workflow ID: high_level_math_ganluo_164_0
# Benchmark: high_level_math_ganluo
# Data Indices: [998, 534]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extract_instruction = """Extract all numerical values, variables, relationships, and constraints from the problem. 
        Ensure that every piece of information is captured explicitly and is ready for use in subsequent steps."""
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        generate_instruction_template = f"""Using the extracted information ({extracted_info}), solve the problem using the following approach: {{approach}}. 
        Ensure all constraints are satisfied, and provide step-by-step reasoning."""
        approaches = [
            "Algebraic manipulation and equation solving",
            "Geometric reasoning and visualization",
            "Combinatorial analysis and counting principles",
            "Number theory techniques such as modular arithmetic or prime factorization"
        ]
        generate_tasks = [
            self.generate(instruction=generate_instruction_template.format(approach=approach), context=self.problem_text)
            for approach in approaches
        ]
        raw_solutions = await asyncio.gather(*generate_tasks)

        # Step 3: Refine and validate each solution
        refine_instruction_template = f"""Critique and refine the following solution attempt: {{solution}}. 
        Ensure it adheres to all constraints, is mathematically rigorous, and handles edge cases appropriately."""
        refine_tasks = [
            self.revise(instruction=refine_instruction_template.format(solution=solution), context=self.problem_text)
            for solution in raw_solutions
        ]
        refined_solutions = await asyncio.gather(*refine_tasks)

        # Step 4: Select the best solution using Ensemble
        ensemble_instruction = f"""Compare the following refined solutions and select the most elegant, efficient, and mathematically sound one. 
        Ensure the chosen solution satisfies all problem constraints and is presented clearly."""
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_solutions)

        # Step 5: Summarize the final answer
        summarize_instruction = """Condense the final solution into a concise, clear format. 
        Include the key steps, final answer, and any necessary explanations."""
        final_answer = await self.summarize(instruction=summarize_instruction, context=best_solution)

        return final_answer