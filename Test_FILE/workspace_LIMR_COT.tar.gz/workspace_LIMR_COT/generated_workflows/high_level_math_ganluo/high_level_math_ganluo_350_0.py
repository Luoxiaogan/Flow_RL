# Workflow ID: high_level_math_ganluo_350_0
# Benchmark: high_level_math_ganluo
# Data Indices: [135, 715]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all numerical values, variables, equations, inequalities, "
            "constraints, and relationships from the problem. Organize this information "
            "in a structured format suitable for further analysis."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Identify mathematical domain and propose solution approaches
        approach_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Determine the mathematical domain (e.g., algebra, geometry, combinatorics) "
            "and propose multiple solution approaches. Include specific techniques "
            "(e.g., completing the square, modular arithmetic) and outline each approach step-by-step."
        )
        proposed_approaches = await self.generate(instruction=approach_instruction, context=self.problem_text)

        # Step 3: Execute multiple solution paths in parallel
        async def solve_with_approach(approach):
            # Generate intermediate results
            intermediate_instruction = (
                f"Using the approach: {approach}\n"
                "Solve the problem step-by-step. Show all calculations, transformations, "
                "and logical reasoning explicitly."
            )
            intermediate_result = await self.generate(instruction=intermediate_instruction, context=self.problem_text)

            # Revise the intermediate result for correctness
            revision_instruction = (
                "Critique and refine the following solution. Ensure all steps are mathematically "
                "correct and address any potential errors or ambiguities."
            )
            revised_result = await self.revise(instruction=revision_instruction, context=intermediate_result)

            # Summarize key insights
            summary_instruction = (
                "Condense the solution into key insights and the final result. Ensure clarity "
                "and relevance to the original problem."
            )
            summarized_result = await self.summarize(instruction=summary_instruction, context=revised_result)

            return summarized_result

        # Split proposed approaches into individual tasks
        approaches = proposed_approaches.split("\n\n")  # Assuming each approach is separated by double newlines
        tasks = [solve_with_approach(approach) for approach in approaches]
        results = await asyncio.gather(*tasks)

        # Step 4: Select or synthesize the best solution
        ensemble_instruction = (
            "Evaluate the following candidate solutions. Select the most rigorous, "
            "efficient, and correct solution, or synthesize a new one if needed. "
            "Ensure the final solution satisfies all constraints and is mathematically valid."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 5: Final output
        return final_solution