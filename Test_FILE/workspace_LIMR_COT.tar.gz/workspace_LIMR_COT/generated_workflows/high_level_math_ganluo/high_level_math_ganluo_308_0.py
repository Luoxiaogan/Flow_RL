# Workflow ID: high_level_math_ganluo_308_0
# Benchmark: high_level_math_ganluo
# Data Indices: [282, 227]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all key information from the problem, including variables, constants, "
            "constraints, and the specific question being asked. Organize the information clearly."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        algebra_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using algebraic methods. "
            "Include all steps and reasoning."
        )
        geometry_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using geometric reasoning. "
            "Include all steps and reasoning."
        )
        combinatorics_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using combinatorial methods. "
            "Include all steps and reasoning."
        )

        results = await asyncio.gather(
            self.generate(instruction=algebra_instruction, context=self.problem_text),
            self.generate(instruction=geometry_instruction, context=self.problem_text),
            self.generate(instruction=combinatorics_instruction, context=self.problem_text)
        )
        algebra_solution, geometry_solution, combinatorics_solution = results

        # Step 3: Refine and validate each solution
        refine_instruction = (
            "Critique and refine the provided solution. Ensure it satisfies all constraints, "
            "handles edge cases, and is mathematically rigorous."
        )
        refined_algebra = await self.revise(instruction=refine_instruction, context=algebra_solution)
        refined_geometry = await self.revise(instruction=refine_instruction, context=geometry_solution)
        refined_combinatorics = await self.revise(instruction=refine_instruction, context=combinatorics_solution)

        # Step 4: Ensemble decision to select the best solution
        ensemble_instruction = (
            "Compare the following solutions and select the best one. If multiple solutions are valid, "
            "synthesize them into a single coherent answer. Ensure the final solution is clear and concise."
        )
        final_solution = await self.ensemble(
            instruction=ensemble_instruction,
            contexts=[refined_algebra, refined_geometry, refined_combinatorics]
        )

        # Step 5: Summarize the final solution
        summarize_instruction = (
            "Summarize the final solution in a clear and concise manner. Include only the essential details."
        )
        summary = await self.summarize(instruction=summarize_instruction, context=final_solution)

        return summary