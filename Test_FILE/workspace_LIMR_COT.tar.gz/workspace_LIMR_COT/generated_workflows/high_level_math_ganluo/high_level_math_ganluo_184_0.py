# Workflow ID: high_level_math_ganluo_184_0
# Benchmark: high_level_math_ganluo
# Data Indices: [381, 273]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Understand and decompose the problem
        problem_understanding = await self.generate(
            instruction="Extract all key components of the problem, including variables, constraints, "
                        "and the type of mathematical domain (e.g., algebra, geometry). "
                        "Identify what is being asked and any hidden structures or patterns.",
            context=self.problem_text
        )

        # Step 2: Generate multiple solution approaches
        algebraic_approach = self.generate(
            instruction=f"Using algebraic techniques, solve the problem based on the following understanding: {problem_understanding}. "
                        "Include detailed steps and reasoning.",
            context=self.problem_text
        )
        geometric_approach = self.generate(
            instruction=f"Using geometric techniques, solve the problem based on the following understanding: {problem_understanding}. "
                        "Include detailed steps and reasoning.",
            context=self.problem_text
        )
        combinatorial_approach = self.generate(
            instruction=f"Using combinatorial techniques, solve the problem based on the following understanding: {problem_understanding}. "
                        "Include detailed steps and reasoning.",
            context=self.problem_text
        )

        # Execute approaches in parallel
        approaches = await asyncio.gather(algebraic_approach, geometric_approach, combinatorial_approach)

        # Step 3: Critique and refine each approach
        refined_approaches = await asyncio.gather(
            *[self.revise(
                instruction="Critique this solution for mathematical correctness, adherence to constraints, "
                            "and logical consistency. Suggest improvements if necessary.",
                context=approach
            ) for approach in approaches]
        )

        # Step 4: Select the best solution using Ensemble
        best_solution = await self.ensemble(
            instruction="Compare the following solutions and select the most robust, elegant, and mathematically sound one. "
                        "Ensure it satisfies all constraints and provides the correct answer.",
            contexts=refined_approaches
        )

        # Step 5: Verify and summarize the final solution
        final_answer = await self.summarize(
            instruction="Summarize the solution, ensuring it clearly answers the problem and satisfies all constraints. "
                        "Highlight the key steps and reasoning.",
            context=best_solution
        )

        return final_answer