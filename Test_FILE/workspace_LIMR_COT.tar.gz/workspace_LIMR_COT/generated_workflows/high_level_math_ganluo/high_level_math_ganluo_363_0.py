# Workflow ID: high_level_math_ganluo_363_0
# Benchmark: high_level_math_ganluo
# Data Indices: [203, 823]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Problem Decomposition
        decomposition_instruction = (
            "Analyze the problem statement thoroughly. Identify all given values, "
            "unknowns, constraints, and relationships. Extract any numerical values, "
            "formulas, or conditions explicitly stated or implied in the problem. "
            "Organize this information clearly."
        )
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Generate Multiple Solution Strategies
        algebra_strategy_instruction = (
            f"Using the extracted information: {decomposition}, develop an algebraic solution strategy. "
            "Include step-by-step reasoning, formulas, and calculations. Highlight any assumptions made."
        )
        geometry_strategy_instruction = (
            f"Using the extracted information: {decomposition}, develop a geometric solution strategy. "
            "Consider coordinate geometry, synthetic geometry, or trigonometric methods. Provide detailed steps."
        )
        combinatorics_strategy_instruction = (
            f"Using the extracted information: {decomposition}, develop a combinatorial solution strategy. "
            "Focus on counting principles, recursive structures, or probabilistic methods. Explain each step."
        )

        strategies = await asyncio.gather(
            self.generate(instruction=algebra_strategy_instruction, context=self.problem_text),
            self.generate(instruction=geometry_strategy_instruction, context=self.problem_text),
            self.generate(instruction=combinatorics_strategy_instruction, context=self.problem_text)
        )

        # Step 3: Ensemble Evaluation
        ensemble_instruction = (
            "Evaluate the provided solution strategies. Select the most appropriate one based on clarity, "
            "efficiency, and adherence to the problem's constraints. If multiple strategies are valid, "
            "synthesize them into a single coherent solution."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=strategies)

        # Step 4: Verification and Refinement
        verification_instruction = (
            "Verify the correctness of the solution. Check that it satisfies all constraints and conditions. "
            "Refine the solution if necessary, ensuring it is mathematically rigorous and presented clearly."
        )
        refined_solution = await self.revise(instruction=verification_instruction, context=best_solution)

        # Step 5: Output Formatting
        summary_instruction = (
            "Summarize the final solution in a clear and concise format. Include the final answer and any "
            "necessary explanations. Ensure the output adheres to the problem's requirements."
        )
        final_output = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_output