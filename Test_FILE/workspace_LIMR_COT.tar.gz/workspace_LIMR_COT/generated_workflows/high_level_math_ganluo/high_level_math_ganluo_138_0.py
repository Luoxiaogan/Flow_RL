# Workflow ID: high_level_math_ganluo_138_0
# Benchmark: high_level_math_ganluo
# Data Indices: [442, 331]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Problem Understanding and Decomposition
        problem_analysis = await self.generate(
            instruction="Carefully analyze the problem statement. Identify the type of problem "
                        "(e.g., algebraic, combinatorial, geometric, number-theoretic) and break it into "
                        "sub-problems or logical steps. Extract all key variables, constraints, and relationships. "
                        "Provide a structured overview of the problem.",
            context=self.problem_text
        )

        # Step 2: Parallel Exploration of Solution Paths
        algebraic_solution = self.generate(
            instruction=f"Using algebraic methods, solve the problem step by step. "
                        f"Ensure all constraints are satisfied. Problem details: {problem_analysis}",
            context=self.problem_text
        )
        recursive_solution = self.generate(
            instruction=f"Using recursive reasoning or generating functions, solve the problem step by step. "
                        f"Ensure all constraints are satisfied. Problem details: {problem_analysis}",
            context=self.problem_text
        )
        geometric_solution = self.generate(
            instruction=f"Using geometric reasoning or coordinate geometry, solve the problem step by step. "
                        f"Ensure all constraints are satisfied. Problem details: {problem_analysis}",
            context=self.problem_text
        )
        number_theory_solution = self.generate(
            instruction=f"Using number-theoretic methods (e.g., modular arithmetic, divisibility), "
                        f"solve the problem step by step. Ensure all constraints are satisfied. "
                        f"Problem details: {problem_analysis}",
            context=self.problem_text
        )

        # Execute all solution paths in parallel
        solutions = await asyncio.gather(algebraic_solution, recursive_solution, geometric_solution, number_theory_solution)

        # Step 3: Synthesis and Evaluation of Results
        final_solution = await self.ensemble(
            instruction="Compare the provided solutions. Select the most robust, accurate, and complete solution. "
                        "Ensure the chosen solution satisfies all constraints and is mathematically rigorous. "
                        "If necessary, synthesize elements from multiple solutions to form a hybrid approach.",
            contexts=solutions
        )

        # Step 4: Refinement and Verification
        refined_solution = await self.revise(
            instruction="Critique and refine the provided solution. Check for mathematical accuracy, "
                        "logical consistency, and adherence to all problem constraints. Correct any errors.",
            context=final_solution
        )

        # Step 5: Summarization
        final_answer = await self.summarize(
            instruction="Produce a concise and clear final answer. Include only the essential steps and results. "
                        "Ensure the answer directly addresses the problem statement.",
            context=refined_solution
        )

        return final_answer