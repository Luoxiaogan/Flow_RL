# Workflow ID: high_level_math_ganluo_433_0
# Benchmark: high_level_math_ganluo
# Data Indices: [566, 884]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract problem components and classify the problem type
        extraction_instruction = (
            "Extract all numerical values, variables, equations, constraints, and objectives from the problem. "
            "Identify the primary mathematical domain (e.g., algebra, geometry, combinatorics) and any secondary domains. "
            "Provide a structured summary of the problem's key elements."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution pathways
        generate_instruction_template = (
            "Based on the following extracted information:\n{info}\n"
            "Propose a detailed solution approach using {strategy}. Include all steps, reasoning, and calculations. "
            "Ensure the approach addresses all constraints and objectives."
        )
        strategies = ["algebraic manipulation", "combinatorial analysis", "geometric reasoning", "number theory techniques"]
        generation_tasks = [
            self.generate(instruction=generate_instruction_template.format(info=extracted_info, strategy=strategy), context=self.problem_text)
            for strategy in strategies
        ]
        raw_solutions = await asyncio.gather(*generation_tasks)

        # Step 3: Refine each solution pathway
        refine_instruction_template = (
            "Critically evaluate the following solution approach:\n{solution}\n"
            "Check for mathematical correctness, completeness, and adherence to the problem's constraints. "
            "Suggest improvements and corrections where necessary. Ensure the solution is rigorous and well-justified."
        )
        refinement_tasks = [
            self.revise(instruction=refine_instruction_template.format(solution=solution), context=self.problem_text)
            for solution in raw_solutions
        ]
        refined_solutions = await asyncio.gather(*refinement_tasks)

        # Step 4: Summarize key insights from each refined solution
        summarize_instruction_template = (
            "Condense the following solution into a concise summary, focusing on the main reasoning steps and final result:\n{solution}"
        )
        summarization_tasks = [
            self.summarize(instruction=summarize_instruction_template.format(solution=solution), context=self.problem_text)
            for solution in refined_solutions
        ]
        summarized_solutions = await asyncio.gather(*summarization_tasks)

        # Step 5: Ensemble decision-making to select the best solution
        ensemble_instruction = (
            "Evaluate the following candidate solutions and select the most robust, correct, and efficient one. "
            "Provide a justification for your choice. If multiple solutions are equally valid, synthesize them into a single answer."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=summarized_solutions)

        return final_solution