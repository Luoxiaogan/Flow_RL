# Workflow ID: high_level_math_ganluo_65_0
# Benchmark: high_level_math_ganluo
# Data Indices: [633, 815]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Analyze the problem statement carefully. Identify all variables, equations, "
            "constraints, and the type of solution required. Organize this information "
            "in a structured format for further processing."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        approach_instructions = [
            f"Using the extracted information: {extracted_info}, develop a solution approach based on algebraic manipulation.",
            f"Using the extracted information: {extracted_info}, develop a solution approach based on geometric reasoning.",
            f"Using the extracted information: {extracted_info}, develop a solution approach based on combinatorial analysis.",
            f"Using the extracted information: {extracted_info}, develop a solution approach based on number theory techniques."
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Evaluate and select the best approach
        ensemble_instruction = (
            "Evaluate the provided solution approaches. Consider factors such as simplicity, "
            "alignment with the problem's constraints, and feasibility. Select the most promising approach."
        )
        best_approach = await self.ensemble(instruction=ensemble_instruction, contexts=approaches)

        # Step 4: Refine the selected approach
        refinement_instruction = (
            "Refine the selected solution approach. Check for mathematical rigor, simplify expressions, "
            "and verify that all constraints are satisfied. Ensure the solution is computationally accurate."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_approach)

        # Step 5: Summarize the final answer
        summary_instruction = (
            "Condense the refined solution into a concise final answer. Ensure the answer is clear, "
            "complete, and directly addresses the problem's requirements."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer