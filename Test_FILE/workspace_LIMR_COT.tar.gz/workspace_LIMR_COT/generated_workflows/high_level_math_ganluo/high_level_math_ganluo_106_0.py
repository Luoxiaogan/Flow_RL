# Workflow ID: high_level_math_ganluo_106_0
# Benchmark: high_level_math_ganluo
# Data Indices: [353, 175]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key components from the problem
        extract_instruction = (
            "Extract all key components from the problem, including variables, constants, constraints, "
            "and relationships. Organize them in a structured format for further analysis."
        )
        extracted_components = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        algebra_instruction = (
            f"Using the extracted components: {extracted_components}, solve the problem using algebraic methods. "
            "Include step-by-step reasoning and validate intermediate results."
        )
        geometry_instruction = (
            f"Using the extracted components: {extracted_components}, solve the problem using geometric reasoning. "
            "Include diagrams if necessary and validate intermediate results."
        )
        combinatorics_instruction = (
            f"Using the extracted components: {extracted_components}, solve the problem using combinatorial methods. "
            "Include counting principles and validate intermediate results."
        )

        # Parallel execution for independent solution paths
        results = await asyncio.gather(
            self.generate(instruction=algebra_instruction, context=self.problem_text),
            self.generate(instruction=geometry_instruction, context=self.problem_text),
            self.generate(instruction=combinatorics_instruction, context=self.problem_text)
        )

        # Step 3: Refine and validate each solution
        refine_instruction_template = (
            "Critique and refine the following solution. Ensure mathematical rigor, address edge cases, "
            "and validate against the problem's constraints. Provide a revised version if necessary."
        )
        refined_results = await asyncio.gather(
            *[self.revise(instruction=refine_instruction_template, context=result) for result in results]
        )

        # Step 4: Synthesize the best solution
        ensemble_instruction = (
            "Compare the following refined solutions and select the most elegant, efficient, or insightful one. "
            "Provide justification for your choice."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_results)

        # Step 5: Summarize the final answer
        summarize_instruction = (
            "Condense the final solution into a concise, well-structured format. Include the answer in the required form."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=best_solution)

        return final_answer