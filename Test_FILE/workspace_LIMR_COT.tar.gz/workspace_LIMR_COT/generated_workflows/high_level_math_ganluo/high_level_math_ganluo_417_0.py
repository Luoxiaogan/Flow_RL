# Workflow ID: high_level_math_ganluo_417_0
# Benchmark: high_level_math_ganluo
# Data Indices: [436, 488]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all numerical values, variables, constraints, and objectives from the problem. "
            "Organize this information clearly and concisely."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        approach_instructions = [
            f"Using the extracted information: {extracted_info}, solve the problem using an algebraic approach. "
            "Provide step-by-step reasoning and calculations.",

            f"Using the extracted information: {extracted_info}, solve the problem using a geometric approach. "
            "Include diagrams or visual reasoning if applicable.",

            f"Using the extracted information: {extracted_info}, solve the problem using a combinatorial approach. "
            "Focus on counting techniques, recursive formulas, or generating functions if relevant."
        ]
        approaches = await asyncio.gather(
            *(self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions)
        )

        # Step 3: Revise each approach to improve clarity and correctness
        revise_instructions = [
            "Critique and improve the following solution approach. Ensure all steps are logically sound, "
            "calculations are correct, and the solution satisfies all constraints."
        ] * len(approaches)
        revised_approaches = await asyncio.gather(
            *(self.revise(instruction=revise_instr, context=approach) 
              for revise_instr, approach in zip(revise_instructions, approaches))
        )

        # Step 4: Use Ensemble to select the best solution
        ensemble_instruction = (
            "Compare the following solution approaches and select the most elegant, efficient, or accurate one. "
            "Provide justification for your choice."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=revised_approaches)

        # Step 5: Summarize the final solution
        summarize_instruction = (
            "Condense the following solution into a concise format. Ensure it is clear, complete, and satisfies "
            "all problem constraints."
        )
        final_solution = await self.summarize(instruction=summarize_instruction, context=best_solution)

        return final_solution