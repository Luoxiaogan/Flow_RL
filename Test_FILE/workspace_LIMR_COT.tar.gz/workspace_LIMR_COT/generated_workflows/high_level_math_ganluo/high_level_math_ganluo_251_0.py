# Workflow ID: high_level_math_ganluo_251_0
# Benchmark: high_level_math_ganluo
# Data Indices: [429, 505]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Problem Decomposition
        decomposition_instruction = (
            "Extract all key components of the problem, including variables, equations, constraints, "
            "and relationships. Identify the type of problem (e.g., algebra, geometry, combinatorics) "
            "and any special structures or patterns."
        )
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Approach Generation
        generate_instruction_template = (
            "Propose a solution strategy for the problem based on the following decomposition: {decomposition}. "
            "Consider multiple approaches, such as algebraic manipulation, geometric reasoning, "
            "combinatorial analysis, or number theory techniques. Ensure each approach is mathematically sound."
        )
        approaches = await asyncio.gather(
            self.generate(instruction=generate_instruction_template.format(decomposition=decomposition), context=self.problem_text),
            self.generate(instruction=generate_instruction_template.format(decomposition=decomposition), context=self.problem_text),
            self.generate(instruction=generate_instruction_template.format(decomposition=decomposition), context=self.problem_text)
        )

        # Step 3: Solution Refinement
        refine_instruction_template = (
            "Critique and refine the following solution strategy: {approach}. "
            "Ensure it is mathematically rigorous, addresses all constraints, and handles edge cases. "
            "Provide detailed feedback and suggest improvements."
        )
        refined_approaches = await asyncio.gather(
            *[self.revise(instruction=refine_instruction_template.format(approach=approach), context=approach) for approach in approaches]
        )

        # Step 4: Decision Making
        ensemble_instruction = (
            "Compare the following refined solution strategies and select the most robust and efficient approach. "
            "If multiple strategies are complementary, synthesize them into a single solution. "
            "Ensure the final solution satisfies all problem constraints and is mathematically sound."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_approaches)

        # Step 5: Final Answer Extraction
        summarize_instruction = (
            "Condense the following solution into a concise, well-structured answer that satisfies all problem constraints. "
            "Include only the final result and any necessary intermediate steps."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=final_solution)

        return final_answer