# Workflow ID: high_level_math_ganluo_135_0
# Benchmark: high_level_math_ganluo
# Data Indices: [887, 250]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Problem Decomposition
        decomposition_instruction = (
            "Analyze the problem statement to identify the type of problem (e.g., algebra, geometry, combinatorics). "
            "Extract all key components, including variables, constraints, and relationships. "
            "Provide a structured breakdown of the problem."
        )
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Explore Multiple Approaches
        algebraic_instruction = f"Using the following problem breakdown:\n{decomposition}\nSolve the problem using an algebraic approach. Show all steps."
        geometric_instruction = f"Using the following problem breakdown:\n{decomposition}\nSolve the problem using a geometric approach. Show all steps."
        combinatorial_instruction = f"Using the following problem breakdown:\n{decomposition}\nSolve the problem using a combinatorial approach. Show all steps."

        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and Synthesize Approaches
        ensemble_instruction = (
            "Compare the following candidate solutions and select the most promising one. "
            "If multiple solutions are valid, synthesize them into a single coherent solution."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 4: Refine the Chosen Solution
        refinement_instruction = (
            "Critique and refine the following solution to ensure correctness, clarity, and completeness. "
            "Address any missing steps or ambiguities."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Final Answer Extraction
        summarization_instruction = (
            "Condense the following solution into a concise and clear final answer. "
            "Ensure the answer directly addresses the problem's requirements."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_solution)

        return final_answer