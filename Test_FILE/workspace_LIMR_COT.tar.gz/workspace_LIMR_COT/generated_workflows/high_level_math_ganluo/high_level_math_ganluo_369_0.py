# Workflow ID: high_level_math_ganluo_369_0
# Benchmark: high_level_math_ganluo
# Data Indices: [173, 478]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem text
        extraction_instruction = (
            "Extract all variables, constraints, and the target objective from the problem. "
            "Organize the information into a structured format, including any equations, inequalities, "
            "or conditions that must be satisfied."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        algebra_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using algebraic methods. "
            "Include step-by-step reasoning, intermediate calculations, and verify that all constraints are satisfied."
        )
        geometry_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using geometric reasoning. "
            "Focus on visualizing the problem, applying relevant theorems, and ensuring logical consistency."
        )
        combinatorics_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using combinatorial analysis. "
            "Consider counting principles, recursive structures, and probabilistic methods if applicable."
        )

        approaches = await asyncio.gather(
            self.generate(instruction=algebra_instruction, context=self.problem_text),
            self.generate(instruction=geometry_instruction, context=self.problem_text),
            self.generate(instruction=combinatorics_instruction, context=self.problem_text)
        )

        # Step 3: Refine each approach
        refinement_instruction_template = (
            "Critique and refine the following solution approach. "
            "Ensure that all steps are logically consistent, calculations are correct, "
            "and all constraints from the problem are satisfied. Provide suggestions for improvement if needed."
        )
        refined_approaches = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction_template, context=approach) for approach in approaches]
        )

        # Step 4: Ensemble decision to select the best solution
        ensemble_instruction = (
            "Compare the following refined approaches and synthesize the best solution. "
            "Prioritize clarity, correctness, and efficiency. Ensure that the final solution satisfies all constraints."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_approaches)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the final solution into a concise, well-structured format. "
            "Highlight the key steps, reasoning, and results. Ensure that the output is easy to follow."
        )
        summarized_solution = await self.summarize(instruction=summary_instruction, context=final_solution)

        return summarized_solution