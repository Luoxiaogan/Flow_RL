# Workflow ID: high_level_math_ganluo_187_0
# Benchmark: high_level_math_ganluo
# Data Indices: [587, 783]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information and understand the problem
        extraction = await self.generate(
            instruction="Extract all key information from the problem, including numerical values, constraints, and relationships. Identify the domain (e.g., algebra, geometry, number theory) and any specific techniques that might be relevant.",
            context=self.problem_text
        )

        # Step 2: Explore multiple solution paths in parallel
        algebraic_approach = self.generate(
            instruction=f"Using algebraic techniques, solve the problem step by step. Key information: {extraction}",
            context=self.problem_text
        )
        geometric_approach = self.generate(
            instruction=f"Using geometric reasoning, solve the problem step by step. Key information: {extraction}",
            context=self.problem_text
        )
        combinatorial_approach = self.generate(
            instruction=f"Using combinatorial techniques, solve the problem step by step. Key information: {extraction}",
            context=self.problem_text
        )
        number_theory_approach = self.generate(
            instruction=f"Using number-theoretic techniques, solve the problem step by step. Key information: {extraction}",
            context=self.problem_text
        )

        # Execute approaches in parallel
        results = await asyncio.gather(
            algebraic_approach,
            geometric_approach,
            combinatorial_approach,
            number_theory_approach
        )

        # Step 3: Evaluate and synthesize results
        synthesized_solution = await self.ensemble(
            instruction="Compare the provided solutions. Select the most correct, efficient, and elegant solution that satisfies all constraints. If multiple solutions are valid, choose the simplest one.",
            contexts=results
        )

        # Step 4: Refine the selected solution
        refined_solution = await self.revise(
            instruction="Critique and refine the solution to ensure it is mathematically rigorous, adheres to all constraints, and is presented clearly.",
            context=synthesized_solution
        )

        # Optional: Summarize the final solution
        final_summary = await self.summarize(
            instruction="Condense the solution into a concise and clear format, highlighting the key steps and final answer.",
            context=refined_solution
        )

        return final_summary