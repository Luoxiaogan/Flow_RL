# Workflow ID: high_level_math_ganluo_322_0
# Benchmark: high_level_math_ganluo
# Data Indices: [271, 667]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem text
        extraction_instruction = (
            "Extract all key information from the problem, including variables, equations, constraints, "
            "and the specific question being asked. Organize this information clearly."
        )
        key_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        approach_instructions = [
            f"Using algebraic methods, solve the problem based on the following extracted information: {key_info}.",
            f"Using geometric reasoning, interpret and solve the problem based on the following extracted information: {key_info}.",
            f"Using combinatorial or number-theoretic techniques, analyze and solve the problem based on the following extracted information: {key_info}."
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Refine each generated solution
        refinement_instruction_template = (
            "Critically evaluate the following solution approach. Identify and correct any logical gaps, "
            "computational errors, or ambiguities. Ensure the solution satisfies all constraints and is mathematically rigorous."
        )
        refined_approaches = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction_template, context=approach) for approach in approaches]
        )

        # Step 4: Ensemble decision-making to select the best solution
        ensemble_instruction = (
            "Compare the following refined solutions and select the most accurate, elegant, and mathematically sound one. "
            "Ensure the chosen solution fully addresses the problem's requirements."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_approaches)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the following solution into a concise, well-structured format suitable for submission. "
            "Include all necessary details such as numerical answers, symbolic expressions, or step-by-step reasoning."
        )
        final_output = await self.summarize(instruction=summary_instruction, context=final_solution)

        return final_output