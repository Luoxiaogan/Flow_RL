# Workflow ID: high_level_math_ganluo_166_0
# Benchmark: high_level_math_ganluo
# Data Indices: [920, 999]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = """
        Analyze the problem statement carefully. Extract all numerical values, variables, relationships, and constraints. 
        Identify what is being asked and any hidden patterns or symmetries that might simplify the solution.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate two distinct solution approaches in parallel
        approach_1_instruction = f"""
        Based on the extracted information: {extracted_info}
        Solve the problem using an algebraic or formula-based approach. Ensure all steps are clearly explained and justified.
        """
        approach_2_instruction = f"""
        Based on the extracted information: {extracted_info}
        Solve the problem using a geometric, combinatorial, or recursive approach. Ensure all steps are clearly explained and justified.
        """
        results = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text)
        )
        approach_1_result, approach_2_result = results

        # Step 3: Evaluate and select the best solution
        ensemble_instruction = """
        Compare the two solutions provided. Select the one that is most mathematically rigorous, aligns with the problem constraints, 
        and provides the clearest explanation. If both are valid, choose the more elegant or efficient solution.
        """
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=[approach_1_result, approach_2_result])

        # Step 4: Refine the selected solution
        refinement_instruction = """
        Review the solution for mathematical accuracy, logical consistency, and clarity. Improve any weak areas, 
        and ensure the final answer is explicitly stated and boxed if necessary.
        """
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the final solution
        summary_instruction = """
        Condense the solution into a concise summary that includes the key steps and the final answer. 
        Ensure the summary is easy to follow while retaining all critical information.
        """
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_summary