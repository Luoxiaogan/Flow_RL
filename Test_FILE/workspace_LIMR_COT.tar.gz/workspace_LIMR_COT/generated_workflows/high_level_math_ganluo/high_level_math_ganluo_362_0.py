# Workflow ID: high_level_math_ganluo_362_0
# Benchmark: high_level_math_ganluo
# Data Indices: [433, 163]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information and understand the problem
        extraction_instruction = (
            "Analyze the problem and extract all critical information, including variables, constants, "
            "constraints, and the type of mathematical problem (e.g., polynomial, functional equation). "
            "Organize the information clearly."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        algebraic_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using algebraic methods. "
            "Include step-by-step reasoning and ensure all constraints are satisfied."
        )
        geometric_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using geometric reasoning. "
            "Include step-by-step reasoning and ensure all constraints are satisfied."
        )
        combinatorial_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using combinatorial analysis. "
            "Include step-by-step reasoning and ensure all constraints are satisfied."
        )
        approaches = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and synthesize the best solution
        ensemble_instruction = (
            "Compare the provided solution approaches and select the most correct, efficient, and elegant one. "
            "Provide justification for your choice."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=approaches)

        # Step 4: Verify and refine the chosen solution
        refinement_instruction = (
            "Critically review the solution for correctness, rigor, and completeness. "
            "Check that all constraints are satisfied and refine if necessary."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the solution into a concise, well-structured format suitable for submission. "
            "Ensure clarity and precision."
        )
        final_output = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_output