# Workflow ID: high_level_math_ganluo_119_0
# Benchmark: high_level_math_ganluo
# Data Indices: [132, 579]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem text
        extraction_instruction = """
        Carefully analyze the problem statement and extract all relevant information, including:
        - Numerical values and their roles (e.g., constants, variables, coefficients)
        - Constraints and conditions
        - Relationships between entities (e.g., equations, inequalities, geometric properties)
        - The specific question being asked
        Organize the extracted information into a structured format for further processing.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate multiple solution strategies
        strategy_instruction = f"""
        Based on the following extracted information:
        {extracted_info}
        Propose multiple high-level strategies to solve the problem. Consider different mathematical domains and techniques, such as:
        - Algebraic manipulation
        - Geometric reasoning
        - Combinatorial analysis
        - Number theory
        - Recursive formulas or generating functions
        For each strategy, provide a brief justification and outline the steps required to implement it.
        """
        strategies = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Refine and evaluate the strategies
        refinement_instruction = f"""
        Critically evaluate the following proposed strategies:
        {strategies}
        Identify potential strengths and weaknesses of each approach. Suggest improvements or modifications to make them more robust and efficient.
        """
        refined_strategies = await self.revise(instruction=refinement_instruction, context=strategies)

        # Step 4: Explore solution paths in parallel
        solution_paths = []
        for i, strategy in enumerate(refined_strategies.split("\n\n")):
            path_instruction = f"""
            Implement the following strategy step-by-step:
            {strategy}
            Ensure that all calculations and reasoning are clear and precise. If intermediate results are needed, compute them explicitly.
            """
            solution_paths.append(self.generate(instruction=path_instruction, context=self.problem_text))

        # Execute solution paths in parallel
        solutions = await asyncio.gather(*solution_paths)

        # Step 5: Evaluate and synthesize the results
        evaluation_instruction = f"""
        Compare and evaluate the following candidate solutions:
        {solutions}
        Select the most accurate and efficient solution while considering edge cases and constraints. Provide a justification for your choice.
        """
        final_solution = await self.ensemble(instruction=evaluation_instruction, contexts=solutions)

        # Step 6: Final refinement and verification
        verification_instruction = f"""
        Review and refine the following solution:
        {final_solution}
        Ensure that it satisfies all constraints and makes mathematical sense. Verify calculations and clarify any ambiguous steps.
        """
        refined_solution = await self.revise(instruction=verification_instruction, context=final_solution)

        return refined_solution