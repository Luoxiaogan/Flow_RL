# Workflow ID: high_level_math_ganluo_52_0
# Benchmark: high_level_math_ganluo
# Data Indices: [52, 512]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all numerical values, constraints, and mathematical categories "
            "(e.g., combinatorics, geometry, algebra) from the problem. "
            "Identify what the question is asking for and any special conditions."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Explore multiple solution paths in parallel
        algebraic_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem algebraically. "
            "Focus on equations, inequalities, or functional relationships."
        )
        geometric_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem geometrically. "
            "Consider coordinate geometry, synthetic geometry, or trigonometric methods."
        )
        combinatorial_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem combinatorially. "
            "Focus on counting principles, recursive structures, or generating functions."
        )

        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Refine each candidate solution
        refinement_instruction = (
            "Critique and refine the provided solution. Ensure it satisfies all constraints, "
            "is mathematically rigorous, and addresses the problem's requirements."
        )
        refined_results = await asyncio.gather(
            self.revise(instruction=refinement_instruction, context=results[0]),
            self.revise(instruction=refinement_instruction, context=results[1]),
            self.revise(instruction=refinement_instruction, context=results[2])
        )

        # Step 4: Synthesize the best solution
        synthesis_instruction = (
            "Evaluate the provided solutions. Select the most correct, elegant, and complete solution. "
            "If multiple solutions are equally valid, merge them into a single coherent answer."
        )
        final_solution = await self.ensemble(instruction=synthesis_instruction, contexts=refined_results)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the final solution into a concise, well-structured format. "
            "Include all key steps and the final answer."
        )
        summarized_solution = await self.summarize(instruction=summary_instruction, context=final_solution)

        return summarized_solution