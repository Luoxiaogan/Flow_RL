# Workflow ID: high_level_math_ganluo_212_0
# Benchmark: high_level_math_ganluo
# Data Indices: [398, 189]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract Key Information
        extraction_instruction = (
            "Extract all key mathematical entities, relationships, and constraints from the problem. "
            "Identify variables, constants, equations, sequences, or any other relevant structures. "
            "Organize the information in a structured format."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate Multiple Solution Approaches
        algebra_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using algebraic techniques. "
            "Focus on equations, inequalities, and functional relationships. Provide a step-by-step solution."
        )
        geometry_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using geometric reasoning. "
            "Consider coordinate geometry, synthetic geometry, and trigonometric relationships. Provide a step-by-step solution."
        )
        combinatorics_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using combinatorial methods. "
            "Consider counting principles, recursive formulas, and probabilistic reasoning. Provide a step-by-step solution."
        )

        # Parallel execution for different approaches
        results = await asyncio.gather(
            self.generate(instruction=algebra_instruction, context=self.problem_text),
            self.generate(instruction=geometry_instruction, context=self.problem_text),
            self.generate(instruction=combinatorics_instruction, context=self.problem_text)
        )

        # Step 3: Critique and Refine Solutions
        refined_results = []
        for result in results:
            refinement_instruction = (
                "Critically evaluate the provided solution. Check for logical consistency, adherence to constraints, "
                "and mathematical correctness. Suggest improvements if necessary."
            )
            refined_result = await self.revise(instruction=refinement_instruction, context=result)
            refined_results.append(refined_result)

        # Step 4: Select the Best Solution
        ensemble_instruction = (
            "Compare the provided solutions and select the most appropriate one. "
            "Consider clarity, correctness, efficiency, and adherence to the problem's requirements. "
            "If multiple solutions are equally valid, choose the one with the simplest reasoning."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_results)

        # Step 5: Summarize the Final Answer
        summary_instruction = (
            "Condense the final solution into a concise format. Clearly state the answer and provide a brief explanation "
            "of the reasoning process."
        )
        summarized_answer = await self.summarize(instruction=summary_instruction, context=final_solution)

        return summarized_answer