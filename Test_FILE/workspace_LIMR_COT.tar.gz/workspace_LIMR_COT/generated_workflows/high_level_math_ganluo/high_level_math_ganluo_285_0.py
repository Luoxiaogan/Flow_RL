# Workflow ID: high_level_math_ganluo_285_0
# Benchmark: high_level_math_ganluo
# Data Indices: [611, 938]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information and structure the problem
        extraction_instruction = (
            "Extract all key mathematical expressions, variables, constraints, and relationships "
            "from the problem. Organize them into a structured format that highlights what is given, "
            "what needs to be solved, and any implicit assumptions or conditions."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Explore multiple solution paths in parallel
        algebraic_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem algebraically. "
            "Show all steps, including substitutions, simplifications, and transformations. "
            "Ensure the solution satisfies all constraints."
        )
        geometric_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem geometrically. "
            "If applicable, use coordinate geometry, synthetic geometry, or trigonometric methods. "
            "Provide detailed reasoning and verify the solution."
        )
        combinatorial_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using combinatorial "
            "or probabilistic methods. Include casework analysis, recursive formulas, or generating functions "
            "if needed. Validate the solution against the problem's conditions."
        )

        # Execute three approaches in parallel
        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Refine each candidate solution
        refine_instruction_template = (
            "Critique and refine the following solution: {solution}. "
            "Check for logical consistency, mathematical correctness, and adherence to the problem's constraints. "
            "Simplify expressions where possible and ensure all steps are justified."
        )
        refined_results = await asyncio.gather(
            self.revise(instruction=refine_instruction_template.format(solution=results[0]), context=results[0]),
            self.revise(instruction=refine_instruction_template.format(solution=results[1]), context=results[1]),
            self.revise(instruction=refine_instruction_template.format(solution=results[2]), context=results[2])
        )

        # Step 4: Ensemble decision-making
        ensemble_instruction = (
            "Evaluate the following candidate solutions: {solutions}. "
            "Select the most mathematically rigorous, efficient, and correct solution. "
            "Synthesize insights from all approaches if necessary to produce the best possible answer."
        )
        final_solution = await self.ensemble(
            instruction=ensemble_instruction.format(solutions=refined_results),
            contexts=refined_results
        )

        # Step 5: Summarize the final solution
        summarize_instruction = (
            "Summarize the following solution: {solution}. "
            "Present it in a clear, concise, and well-organized format. "
            "Include the final answer and any key intermediate results."
        )
        summary = await self.summarize(
            instruction=summarize_instruction.format(solution=final_solution),
            context=final_solution
        )

        return summary