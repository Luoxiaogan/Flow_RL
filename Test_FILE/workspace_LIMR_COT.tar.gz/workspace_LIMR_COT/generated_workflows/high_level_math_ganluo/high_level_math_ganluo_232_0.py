# Workflow ID: high_level_math_ganluo_232_0
# Benchmark: high_level_math_ganluo
# Data Indices: [67, 26]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key components and understand the problem
        extraction_instruction = (
            "Extract all numerical values, variables, equations, and constraints from the problem. "
            "Identify the type of problem (e.g., algebra, geometry, combinatorics) and list possible solution approaches."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple candidate solutions in parallel
        algebraic_instruction = f"Using algebraic methods, solve the problem based on the following extracted information: {extracted_info}."
        geometric_instruction = f"Using geometric reasoning, solve the problem based on the following extracted information: {extracted_info}."
        combinatorial_instruction = f"Using combinatorial techniques, solve the problem based on the following extracted information: {extracted_info}."

        candidates = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and select the best solution
        ensemble_instruction = (
            "Evaluate the following candidate solutions based on correctness, efficiency, and adherence to the problem constraints. "
            "Select the best solution and provide justification for your choice."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=candidates)

        # Step 4: Refine the selected solution
        refinement_instruction = (
            "Critique and refine the following solution to ensure it is mathematically sound, well-structured, and free of errors. "
            "Provide a polished version of the solution."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Summarize the following solution in a concise and clear format. "
            "Include only the key steps and the final answer."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_summary