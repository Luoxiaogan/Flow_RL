# Workflow ID: high_level_math_ganluo_38_0
# Benchmark: high_level_math_ganluo
# Data Indices: [701, 830]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information and identify the problem domain
        extraction_instruction = (
            "Extract all key information from the problem, including variables, constraints, and objectives. "
            "Identify the mathematical domain (e.g., algebra, geometry, combinatorics) and any specific techniques "
            "that might be applicable (e.g., symmetry, modular arithmetic)."
        )
        key_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        algebra_instruction = (
            f"Given the extracted information: {key_info}\n"
            "Solve the problem using algebraic techniques. Include all reasoning steps, simplify expressions, "
            "and ensure all constraints are satisfied."
        )
        geometry_instruction = (
            f"Given the extracted information: {key_info}\n"
            "Solve the problem using geometric reasoning. If applicable, convert the problem into coordinate geometry "
            "or use synthetic geometry principles."
        )
        combinatorics_instruction = (
            f"Given the extracted information: {key_info}\n"
            "Solve the problem using combinatorial techniques. Consider casework analysis, recursive formulas, "
            "or generating functions if applicable."
        )

        results = await asyncio.gather(
            self.generate(instruction=algebra_instruction, context=self.problem_text),
            self.generate(instruction=geometry_instruction, context=self.problem_text),
            self.generate(instruction=combinatorics_instruction, context=self.problem_text)
        )

        # Step 3: Refine and validate each solution approach
        refinement_instruction = (
            "Critique the provided solution. Ensure it satisfies all constraints, is mathematically rigorous, "
            "and follows logical reasoning. Suggest improvements if necessary."
        )
        refined_results = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction, context=result) for result in results]
        )

        # Step 4: Summarize refined solutions for comparison
        summary_instruction = (
            "Condense the solution into a concise summary, preserving key reasoning steps and the final answer."
        )
        summarized_results = await asyncio.gather(
            *[self.summarize(instruction=summary_instruction, context=result) for result in refined_results]
        )

        # Step 5: Select the best solution or synthesize multiple solutions
        ensemble_instruction = (
            "Evaluate the provided solutions. Select the most accurate, elegant, and complete solution. "
            "If multiple solutions are valid, synthesize them into a unified answer."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=summarized_results)

        return final_solution