# Workflow ID: high_level_math_ganluo_3_0
# Benchmark: high_level_math_ganluo
# Data Indices: [636, 454]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract problem components
        extraction_instruction = (
            "Identify and extract all critical components of the problem, including numerical values, variables, "
            "constraints, relationships, and any specific conditions. Organize the extracted information clearly."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        algebra_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Solve the problem using algebraic methods. Focus on equations, inequalities, and functional relationships. "
            "Provide a step-by-step reasoning process."
        )
        combinatorics_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Solve the problem using combinatorial reasoning. Focus on counting principles, permutations, combinations, "
            "and recursive structures. Provide a step-by-step reasoning process."
        )
        geometry_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Solve the problem using geometric methods. Focus on coordinate geometry, synthetic geometry, and trigonometric "
            "relationships. Provide a step-by-step reasoning process."
        )

        # Parallel execution for independent solution paths
        results = await asyncio.gather(
            self.generate(instruction=algebra_instruction, context=self.problem_text),
            self.generate(instruction=combinatorics_instruction, context=self.problem_text),
            self.generate(instruction=geometry_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and select the best solution
        selection_instruction = (
            "Compare the following solutions and select the most mathematically sound, efficient, and complete one. "
            "Ensure the chosen solution satisfies all problem constraints and is verified for correctness."
        )
        best_solution = await self.ensemble(instruction=selection_instruction, contexts=results)

        # Step 4: Refine the selected solution
        refinement_instruction = (
            "Critique and refine the following solution. Address any ambiguities, inefficiencies, or gaps in reasoning. "
            "Polish the explanation to ensure clarity and precision."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the following solution into a clear and concise format. Highlight the key steps and results."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_summary