# Workflow ID: high_level_math_ganluo_309_0
# Benchmark: high_level_math_ganluo
# Data Indices: [379, 684]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key components from the problem
        extraction_instruction = (
            "Extract all key components from the problem, including variables, equations, "
            "constraints, and relationships. Organize the information clearly and concisely."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        approach_instruction = (
            f"Based on the extracted information: {extracted_info}, propose multiple solution approaches. "
            "Consider algebraic manipulation, combinatorial reasoning, geometric interpretations, and other relevant techniques. "
            "Provide detailed reasoning for each approach."
        )
        approaches = await self.generate(instruction=approach_instruction, context=self.problem_text)

        # Step 3: Execute approaches in parallel
        approach_list = approaches.split("\n\n")  # Split into individual approaches
        parallel_tasks = [
            self.generate(
                instruction=f"Solve the problem using the following approach: {approach}",
                context=self.problem_text
            )
            for approach in approach_list
        ]
        results = await asyncio.gather(*parallel_tasks)

        # Step 4: Evaluate and select the best solution
        ensemble_instruction = (
            "Compare the provided solutions and select the best one. "
            "Ensure the chosen solution satisfies all constraints and aligns with the problem's requirements. "
            "If multiple solutions are valid, choose the most elegant or efficient one."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 5: Refine the selected solution
        refinement_instruction = (
            "Review and refine the selected solution to ensure accuracy and completeness. "
            "Check that all steps are logically sound and that the solution satisfies all problem constraints."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 6: Verify the final solution
        verification_instruction = (
            "Verify that the final solution satisfies all conditions stated in the original problem. "
            "Provide a detailed justification for why the solution is correct."
        )
        final_verification = await self.generate(instruction=verification_instruction, context=refined_solution)

        return final_verification