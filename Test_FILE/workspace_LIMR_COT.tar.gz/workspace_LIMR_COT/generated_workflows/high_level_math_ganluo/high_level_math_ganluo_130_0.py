# Workflow ID: high_level_math_ganluo_130_0
# Benchmark: high_level_math_ganluo
# Data Indices: [528, 524]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all key information from the problem, including variables, constraints, "
            "and the specific question being asked. Organize this information clearly."
        )
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        algebraic_instruction = (
            f"Using the extracted information: {extraction}, solve the problem using algebraic methods. "
            "Include all steps and ensure all constraints are satisfied."
        )
        geometric_instruction = (
            f"Using the extracted information: {extraction}, solve the problem using geometric reasoning. "
            "Include all steps and ensure all constraints are satisfied."
        )
        combinatorial_instruction = (
            f"Using the extracted information: {extraction}, solve the problem using combinatorial methods. "
            "Include all steps and ensure all constraints are satisfied."
        )

        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Refine each solution path
        refine_instructions = [
            "Critique and refine this solution. Ensure all constraints are satisfied and the reasoning is rigorous.",
            "Critique and refine this solution. Ensure all constraints are satisfied and the reasoning is rigorous.",
            "Critique and refine this solution. Ensure all constraints are satisfied and the reasoning is rigorous."
        ]
        refined_results = await asyncio.gather(
            *[self.revise(instruction=refine_instructions[i], context=results[i]) for i in range(len(results))]
        )

        # Step 4: Select the best solution using Ensemble
        ensemble_instruction = (
            "Compare the following solutions and select the best one. "
            "Criteria for selection include correctness, simplicity, and adherence to constraints."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_results)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the solution into a concise, verifiable format. "
            "Ensure all critical steps and the final answer are included."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=best_solution)

        return final_summary