# Workflow ID: high_level_math_ganluo_70_0
# Benchmark: high_level_math_ganluo
# Data Indices: [300, 834]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Problem Decomposition
        decomposition_instruction = (
            "Extract all key components of the problem, including numerical values, constraints, "
            "relationships, and any implicit assumptions. Organize this information in a structured format."
        )
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Parallel Exploration of Solution Paths
        algebraic_instruction = (
            f"Based on the extracted information: {decomposition}\n"
            "Solve the problem using algebraic methods. Include detailed reasoning and calculations."
        )
        geometric_instruction = (
            f"Based on the extracted information: {decomposition}\n"
            "Solve the problem using geometric methods. Include detailed reasoning and calculations."
        )
        combinatorial_instruction = (
            f"Based on the extracted information: {decomposition}\n"
            "Solve the problem using combinatorial methods. Include detailed reasoning and calculations."
        )

        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Refinement and Validation
        refinement_instruction = (
            "Critique and refine the provided solution. Ensure it adheres to all constraints, "
            "is mathematically rigorous, and addresses the problem requirements fully."
        )
        refined_results = await asyncio.gather(
            self.revise(instruction=refinement_instruction, context=results[0]),
            self.revise(instruction=refinement_instruction, context=results[1]),
            self.revise(instruction=refinement_instruction, context=results[2])
        )

        # Step 4: Final Decision and Synthesis
        ensemble_instruction = (
            "Compare the provided solutions and select the most robust, mathematically sound, "
            "and complete one. If necessary, synthesize elements from multiple solutions."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_results)

        # Step 5: Summarization
        summarization_instruction = (
            "Condense the final solution into a concise, clear format. Ensure it is easy to understand "
            "while retaining all critical details."
        )
        summary = await self.summarize(instruction=summarization_instruction, context=final_solution)

        return summary