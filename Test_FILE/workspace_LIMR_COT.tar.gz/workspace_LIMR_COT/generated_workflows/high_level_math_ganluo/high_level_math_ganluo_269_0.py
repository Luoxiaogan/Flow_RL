# Workflow ID: high_level_math_ganluo_269_0
# Benchmark: high_level_math_ganluo
# Data Indices: [428, 235]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Identify and extract all key components from the problem, including variables, equations, constraints, "
            "and the objective. Organize the information clearly and label each component (e.g., 'Variables:', 'Equations:', etc.)."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        approach1_instruction = (
            f"Using the extracted information:\n{extracted_info}\n"
            "Solve the problem using an algebraic approach. Focus on substituting variables, simplifying equations, "
            "and deriving a solution step by step. Ensure all constraints are satisfied."
        )
        approach2_instruction = (
            f"Using the extracted information:\n{extracted_info}\n"
            "Solve the problem using a combinatorial or probabilistic approach if applicable. Consider cases, count possibilities, "
            "or calculate probabilities systematically."
        )
        approach3_instruction = (
            f"Using the extracted information:\n{extracted_info}\n"
            "Solve the problem using geometric reasoning or symmetry exploitation if applicable. Translate geometric properties "
            "into algebraic expressions or vice versa."
        )

        # Execute approaches in parallel
        results = await asyncio.gather(
            self.generate(instruction=approach1_instruction, context=self.problem_text),
            self.generate(instruction=approach2_instruction, context=self.problem_text),
            self.generate(instruction=approach3_instruction, context=self.problem_text)
        )

        # Step 3: Refine each solution
        refine_instructions = [
            "Critique and improve this solution. Check for mathematical correctness, logical consistency, and adherence to constraints.",
            "Critique and improve this solution. Ensure all steps are justified and the final answer satisfies the problem's requirements.",
            "Critique and improve this solution. Verify that the reasoning is sound and the solution is complete."
        ]
        refined_results = await asyncio.gather(
            *[self.revise(instruction=refine_instructions[i], context=results[i]) for i in range(len(results))]
        )

        # Step 4: Select the best solution
        ensemble_instruction = (
            "Compare the following candidate solutions and select the best one. "
            "Prioritize correctness, elegance, and adherence to the problem's constraints. "
            "If multiple solutions are valid, choose the most straightforward and well-explained one."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_results)

        # Step 5: Summarize the final answer
        summary_instruction = (
            "Condense the final solution into a concise, well-structured format. "
            "Include only the essential steps and the final answer. Ensure clarity and correctness."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=final_solution)

        return final_summary