# Workflow ID: high_level_math_ganluo_109_0
# Benchmark: high_level_math_ganluo
# Data Indices: [325, 180]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract essential information from the problem
        extraction_instruction = (
            "Extract all numerical values, variables, constraints, and the type of mathematical reasoning "
            "required (e.g., algebraic manipulation, combinatorial analysis, geometry). "
            "Identify any special conditions or edge cases that need consideration."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Explore multiple solution paths in parallel
        algebraic_instruction = (
            f"Given the extracted information: {extracted_info}. "
            "Solve the problem using algebraic manipulation. Focus on simplifying expressions, "
            "solving equations, and handling inequalities if applicable."
        )
        geometric_instruction = (
            f"Given the extracted information: {extracted_info}. "
            "Solve the problem using geometric reasoning. Consider coordinate geometry, synthetic geometry, "
            "and trigonometric relationships if applicable."
        )
        combinatorial_instruction = (
            f"Given the extracted information: {extracted_info}. "
            "Solve the problem using combinatorial analysis. Count arrangements, calculate probabilities, "
            "and use recursive formulas if applicable."
        )

        algebraic_solution, geometric_solution, combinatorial_solution = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and select the best solution
        evaluation_instruction = (
            "Compare the following solutions and select the best one based on correctness, simplicity, "
            "and alignment with the problem's constraints. Provide reasoning for your choice."
        )
        best_solution = await self.ensemble(
            instruction=evaluation_instruction,
            contexts=[algebraic_solution, geometric_solution, combinatorial_solution]
        )

        # Step 4: Refine the selected solution
        refinement_instruction = (
            "Critique and improve the following solution. Ensure it is mathematically rigorous, "
            "free of errors, and satisfies all constraints and edge cases."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the following solution into a clear and concise format. Highlight the key steps "
            "and the final answer."
        )
        final_solution = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_solution