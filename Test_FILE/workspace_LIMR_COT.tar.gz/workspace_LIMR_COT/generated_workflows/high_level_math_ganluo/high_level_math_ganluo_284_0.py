# Workflow ID: high_level_math_ganluo_284_0
# Benchmark: high_level_math_ganluo
# Data Indices: [615, 479]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all known values, unknowns, constraints, and the type of mathematical reasoning required. "
            "Provide this information in a structured format, including any equations, formulas, or relationships mentioned."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        approach_1_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Solve the problem using an algebraic approach. Include step-by-step reasoning and calculations."
        )
        approach_2_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Solve the problem using a geometric approach. Include step-by-step reasoning and calculations."
        )
        approach_3_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Solve the problem using a combinatorial or probabilistic approach. Include step-by-step reasoning and calculations."
        )

        # Execute approaches in parallel
        results = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text),
            self.generate(instruction=approach_3_instruction, context=self.problem_text)
        )

        # Step 3: Refine each solution
        refine_instructions = [
            "Critique and refine the following solution. Ensure it satisfies all constraints and is mathematically correct.",
            "Critique and refine the following solution. Ensure it satisfies all constraints and is mathematically correct.",
            "Critique and refine the following solution. Ensure it satisfies all constraints and is mathematically correct."
        ]
        refined_results = await asyncio.gather(
            self.revise(instruction=refine_instructions[0], context=results[0]),
            self.revise(instruction=refine_instructions[1], context=results[1]),
            self.revise(instruction=refine_instructions[2], context=results[2])
        )

        # Step 4: Select the best solution
        ensemble_instruction = (
            "Compare the following solutions and select the best one. "
            "The best solution should be mathematically correct, clear, and efficient. Provide reasoning for your choice."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_results)

        # Step 5: Summarize the final solution
        summarize_instruction = (
            "Condense the following solution into a concise, verifiable form. "
            "Ensure it satisfies all constraints and clearly answers the original problem."
        )
        final_solution = await self.summarize(instruction=summarize_instruction, context=best_solution)

        return final_solution