# Workflow ID: high_level_math_ganluo_382_0
# Benchmark: high_level_math_ganluo
# Data Indices: [912, 762]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract essential information from the problem
        extraction_instruction = (
            "Extract all numerical values, variables, constraints, and the goal from the problem. "
            "Identify any implicit assumptions or relationships. Format the output clearly."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Explore multiple solution approaches in parallel
        algebra_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using algebraic methods. "
            "Include step-by-step reasoning and justify each transformation."
        )
        geometry_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using geometric reasoning. "
            "If applicable, convert the problem into a geometric representation and analyze it."
        )
        combinatorics_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using combinatorial methods. "
            "Consider counting principles, recursive structures, or generating functions if relevant."
        )

        results = await asyncio.gather(
            self.generate(instruction=algebra_instruction, context=self.problem_text),
            self.generate(instruction=geometry_instruction, context=self.problem_text),
            self.generate(instruction=combinatorics_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and synthesize the best solution
        ensemble_instruction = (
            "Compare the following solutions and select the most rigorous, clear, and efficient one. "
            "If multiple solutions are valid, synthesize them into a unified explanation."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 4: Refine the chosen solution
        refine_instruction = (
            "Critique and improve the following solution. Ensure all steps are justified, "
            "all constraints are satisfied, and the answer is explicitly stated."
        )
        refined_solution = await self.revise(instruction=refine_instruction, context=best_solution)

        # Step 5: Summarize the final answer
        summarize_instruction = (
            "Condense the following solution into a concise summary. Clearly state the final answer."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_answer