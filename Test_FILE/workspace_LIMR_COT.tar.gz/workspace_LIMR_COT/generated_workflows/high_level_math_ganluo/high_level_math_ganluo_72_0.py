# Workflow ID: high_level_math_ganluo_72_0
# Benchmark: high_level_math_ganluo
# Data Indices: [304, 111]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Carefully analyze the problem statement and extract all relevant information, "
            "including numerical values, constraints, relationships, and the mathematical domain. "
            "Provide the extracted information in a structured format."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Formulate a solution strategy
        strategy_instruction = (
            f"Based on the following extracted information: {extracted_info}\n"
            "Formulate a detailed solution strategy. Identify potential approaches (e.g., algebraic, geometric, combinatorial) "
            "and outline the steps required to solve the problem. Consider edge cases and constraints."
        )
        strategy = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Parallel exploration of solution paths
        algebraic_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Solve the problem using an algebraic approach. Show all steps and calculations clearly."
        )
        geometric_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Solve the problem using a geometric approach. Include diagrams or visual reasoning if applicable."
        )
        combinatorial_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Solve the problem using a combinatorial or probabilistic approach. Highlight any recursive structures or patterns."
        )

        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 4: Evaluate and select the best solution
        evaluation_instruction = (
            "Compare the following candidate solutions and select the best one. "
            "Ensure the chosen solution is correct, complete, and adheres to all problem constraints. "
            "Provide a justification for your selection."
        )
        best_solution = await self.ensemble(instruction=evaluation_instruction, contexts=results)

        # Step 5: Refine the final solution
        refinement_instruction = (
            "Review the following solution and refine it for clarity, correctness, and formatting. "
            "Ensure the final answer is presented in the required format (e.g., simplified fractions, degrees)."
        )
        final_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        return final_solution