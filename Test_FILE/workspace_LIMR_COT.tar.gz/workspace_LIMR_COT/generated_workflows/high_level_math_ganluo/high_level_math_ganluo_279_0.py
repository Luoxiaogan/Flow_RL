# Workflow ID: high_level_math_ganluo_279_0
# Benchmark: high_level_math_ganluo
# Data Indices: [775, 555]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract and Understand the Problem
        extraction_instruction = (
            "Extract all key information from the problem, including variables, equations, constraints, "
            "and relationships. Organize this information into a structured format that can be used for solving."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate Multiple Solution Approaches
        algebra_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using algebraic methods. "
            "Include all steps and reasoning explicitly."
        )
        geometry_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using geometric reasoning. "
            "Include all steps and reasoning explicitly."
        )
        combinatorics_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using combinatorial methods. "
            "Include all steps and reasoning explicitly."
        )

        algebra_solution, geometry_solution, combinatorics_solution = await asyncio.gather(
            self.generate(instruction=algebra_instruction, context=self.problem_text),
            self.generate(instruction=geometry_instruction, context=self.problem_text),
            self.generate(instruction=combinatorics_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and Synthesize Approaches
        ensemble_instruction = (
            "Compare the following solution approaches and select the most efficient, insightful, and correct one. "
            "If multiple approaches are valid, synthesize them into a single coherent solution."
        )
        best_solution = await self.ensemble(
            instruction=ensemble_instruction,
            contexts=[algebra_solution, geometry_solution, combinatorics_solution]
        )

        # Step 4: Refine the Selected Solution
        refinement_instruction = (
            "Critique and refine the following solution to ensure correctness, clarity, and completeness. "
            "Address any missing steps, ambiguities, or errors."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the Final Solution
        summary_instruction = (
            "Condense the following solution into a concise and structured format that highlights the key steps "
            "and the final answer."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_summary