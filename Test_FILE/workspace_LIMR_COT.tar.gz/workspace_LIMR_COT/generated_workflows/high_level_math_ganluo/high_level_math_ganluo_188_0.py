# Workflow ID: high_level_math_ganluo_188_0
# Benchmark: high_level_math_ganluo
# Data Indices: [882, 16]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Problem Understanding and Decomposition
        decomposition = await self.generate(
            instruction="Extract all numerical values, constraints, and relationships from the problem. "
                        "Break down the problem into smaller sub-problems and outline potential solution strategies.",
            context=self.problem_text
        )

        # Step 2: Parallel Exploration of Solution Paths
        algebraic_solution = self.generate(
            instruction=f"Using algebraic techniques, solve the problem based on the following decomposition: {decomposition}",
            context=self.problem_text
        )
        geometric_solution = self.generate(
            instruction=f"Using geometric techniques, solve the problem based on the following decomposition: {decomposition}",
            context=self.problem_text
        )
        combinatorial_solution = self.generate(
            instruction=f"Using combinatorial techniques, solve the problem based on the following decomposition: {decomposition}",
            context=self.problem_text
        )

        # Execute the three solution approaches in parallel
        results = await asyncio.gather(algebraic_solution, geometric_solution, combinatorial_solution)

        # Step 3: Evaluation and Selection of the Best Approach
        best_solution = await self.ensemble(
            instruction="Compare the following candidate solutions and select the most correct, efficient, and simplest one. "
                        "Ensure the solution satisfies all constraints and is mathematically rigorous.",
            contexts=results
        )

        # Step 4: Refinement and Verification
        refined_solution = await self.revise(
            instruction="Critique and refine the following solution to ensure it is mathematically correct, "
                        "satisfies all constraints, and is presented clearly.",
            context=best_solution
        )

        # Step 5: Summarize the Final Answer
        final_answer = await self.summarize(
            instruction="Condense the following solution into a concise final answer, ensuring all key steps and results are preserved.",
            context=refined_solution
        )

        return final_answer