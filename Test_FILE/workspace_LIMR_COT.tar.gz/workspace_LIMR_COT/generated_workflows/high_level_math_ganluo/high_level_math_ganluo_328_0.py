# Workflow ID: high_level_math_ganluo_328_0
# Benchmark: high_level_math_ganluo
# Data Indices: [93, 229]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Problem Understanding and Decomposition
        extraction_instruction = """
        Extract all key information from the problem text, including:
        - Known numerical values and variables
        - Constraints or conditions
        - The specific question being asked
        - Any implicit assumptions or patterns
        Format the output as a structured list or bullet points for clarity.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Exploration of Multiple Solution Paths
        algebra_instruction = f"""
        Solve the problem using algebraic methods. Consider:
        - Setting up equations based on the extracted information: {extracted_info}
        - Solving step-by-step with clear justification for each transformation
        - Verifying intermediate results against constraints
        Provide a detailed explanation of your reasoning.
        """

        combinatorics_instruction = f"""
        Solve the problem using combinatorial reasoning. Consider:
        - Counting principles, permutations, or combinations
        - Recursive structures or generating functions if applicable
        - Ensuring all cases are accounted for based on: {extracted_info}
        Provide a detailed explanation of your reasoning.
        """

        geometry_instruction = f"""
        Solve the problem using geometric methods. Consider:
        - Converting textual descriptions into geometric representations
        - Applying coordinate geometry or synthetic geometry techniques
        - Calculating areas, volumes, or angles as needed based on: {extracted_info}
        Provide a detailed explanation of your reasoning.
        """

        # Parallel execution of multiple approaches
        results = await asyncio.gather(
            self.generate(instruction=algebra_instruction, context=self.problem_text),
            self.generate(instruction=combinatorics_instruction, context=self.problem_text),
            self.generate(instruction=geometry_instruction, context=self.problem_text)
        )

        # Step 3: Refinement and Verification
        refinement_instruction = """
        Critique the provided solution and refine it based on:
        - Logical consistency and mathematical correctness
        - Adherence to the problem's constraints and conditions
        - Clarity and completeness of the explanation
        Highlight any errors or areas for improvement.
        """
        refined_results = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction, context=result) for result in results]
        )

        # Step 4: Synthesis and Final Selection
        ensemble_instruction = """
        Evaluate the provided solutions and select the best one based on:
        - Accuracy and robustness of the reasoning
        - Alignment with the problem's requirements
        - Simplicity and elegance of the approach
        Provide a justification for your selection.
        """
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_results)

        # Step 5: Summarization for Clarity
        summarization_instruction = """
        Condense the final solution into a clear and concise format. Include:
        - Key steps of the reasoning process
        - The final answer with appropriate units or formatting
        Ensure the summary is easy to understand and directly addresses the problem.
        """
        summary = await self.summarize(instruction=summarization_instruction, context=final_solution)

        return summary