# Workflow ID: high_level_math_ganluo_194_0
# Benchmark: high_level_math_ganluo
# Data Indices: [462, 313]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract problem components
        extraction_instruction = ("Extract all key components of the problem including variables, equations, "
                                  "constraints, and what is being asked. Format the output as a structured summary.")
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        approach_instructions = [
            ("Using algebraic methods, solve the problem step-by-step. Include all intermediate steps and reasoning."),
            ("Apply geometric reasoning if applicable. Focus on visual or spatial insights."),
            ("Use combinatorial or number-theoretic techniques if relevant. Highlight any patterns or symmetries.")
        ]
        approach_tasks = [self.generate(instruction=instr, context=extracted_info) for instr in approach_instructions]
        approach_results = await asyncio.gather(*approach_tasks)

        # Step 3: Evaluate and ensemble the best solution
        ensemble_instruction = ("Compare the following solution approaches and select the most complete and accurate one. "
                                "Ensure the chosen solution satisfies all problem constraints.")
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=approach_results)

        # Step 4: Refine the chosen solution
        refinement_instruction = ("Critically review and refine the solution. Check for mathematical correctness, "
                                  "ensure all constraints are satisfied, and format the solution clearly.")
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the final result
        summary_instruction = ("Summarize the final solution in a concise and clear format. Include only the key results.")
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_summary