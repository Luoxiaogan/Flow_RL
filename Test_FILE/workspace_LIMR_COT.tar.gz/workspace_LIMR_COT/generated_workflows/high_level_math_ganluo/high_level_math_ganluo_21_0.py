# Workflow ID: high_level_math_ganluo_21_0
# Benchmark: high_level_math_ganluo
# Data Indices: [945, 69]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = """
        Analyze the problem thoroughly and extract all relevant information, including:
        - Known numerical values and their relationships
        - Constraints or conditions that must be satisfied
        - The specific question or goal being asked
        - Any implicit assumptions or symmetries in the problem
        Organize this information into a structured format for further use.
        """
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        approach_instructions = [
            f"""
            Solve the problem using an algebraic approach. Leverage the following extracted information:
            {extracted_info}
            Focus on equations, inequalities, and functional relationships. Ensure all steps are mathematically rigorous.
            """,
            f"""
            Solve the problem using a geometric approach. Leverage the following extracted information:
            {extracted_info}
            Consider coordinate geometry, synthetic geometry, and trigonometric relationships. Provide clear diagrams if needed.
            """,
            f"""
            Solve the problem using a combinatorial or probabilistic approach. Leverage the following extracted information:
            {extracted_info}
            Explore counting principles, recursive structures, or generating functions. Ensure all cases are considered systematically.
            """
        ]

        # Execute approaches in parallel
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Evaluate and select the best approach
        ensemble_instruction = """
        Compare the following candidate solutions and select the most appropriate one:
        - Ensure the solution satisfies all constraints and conditions from the original problem
        - Check for mathematical correctness and logical consistency
        - Consider computational simplicity and clarity of explanation
        - Verify that edge cases are handled appropriately
        Provide a justification for your selection.
        """
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=approaches)

        # Step 4: Refine the selected solution
        refinement_instruction = """
        Review and refine the selected solution to ensure:
        - All steps are clearly explained and mathematically sound
        - The final answer is presented in the required format
        - Any unnecessary complexity is removed
        - Edge cases are explicitly addressed
        """
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the final answer
        summary_instruction = """
        Condense the refined solution into a concise and structured format. Include:
        - The final answer
        - Key insights or techniques used
        - Any important caveats or assumptions
        """
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer