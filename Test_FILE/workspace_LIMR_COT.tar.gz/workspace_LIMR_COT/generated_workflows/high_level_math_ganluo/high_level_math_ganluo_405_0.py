# Workflow ID: high_level_math_ganluo_405_0
# Benchmark: high_level_math_ganluo
# Data Indices: [662, 319]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information and decompose the problem
        extraction_instruction = (
            "Extract all key variables, constraints, and relationships from the problem. "
            "Identify the mathematical domain (e.g., algebra, geometry, combinatorics) and any specific techniques required."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Explore multiple solution approaches in parallel
        algebra_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "solve the problem using algebraic techniques. Include all steps and justify each transformation."
        )
        geometry_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "solve the problem using geometric reasoning. Provide clear diagrams or coordinate transformations if applicable."
        )
        combinatorics_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "solve the problem using combinatorial methods. Include counting principles and recursive structures if needed."
        )

        algebra_solution, geometry_solution, combinatorics_solution = await asyncio.gather(
            self.generate(instruction=algebra_instruction, context=self.problem_text),
            self.generate(instruction=geometry_instruction, context=self.problem_text),
            self.generate(instruction=combinatorics_instruction, context=self.problem_text)
        )

        # Step 3: Refine and validate each solution path
        refinement_instruction = (
            "Critique the provided solution. Check for logical consistency, adherence to constraints, and mathematical correctness. "
            "Suggest improvements if necessary."
        )
        refined_algebra = await self.revise(instruction=refinement_instruction, context=algebra_solution)
        refined_geometry = await self.revise(instruction=refinement_instruction, context=geometry_solution)
        refined_combinatorics = await self.revise(instruction=refinement_instruction, context=combinatorics_solution)

        # Step 4: Synthesize and decide the best solution
        synthesis_instruction = (
            "Compare the following solutions and select the most robust and elegant one. "
            "Consider simplicity, clarity, and adherence to the problem constraints."
        )
        final_solution = await self.ensemble(
            instruction=synthesis_instruction,
            contexts=[refined_algebra, refined_geometry, refined_combinatorics]
        )

        # Step 5: Prepare the final output
        summary_instruction = (
            "Condense the final solution into a concise and clear format. "
            "Ensure all steps are logically connected and the answer satisfies the problem requirements."
        )
        final_output = await self.summarize(instruction=summary_instruction, context=final_solution)

        return final_output