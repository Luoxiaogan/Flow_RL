# Workflow ID: high_level_math_ganluo_213_0
# Benchmark: high_level_math_ganluo
# Data Indices: [421, 49]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio
        
        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all key mathematical entities, relationships, and constraints from the problem. "
            "Include variables, equations, inequalities, functions, and any other relevant information. "
            "Format the output as a structured list or explanation."
        )
        key_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)
        
        # Step 2: Generate multiple solution paths in parallel
        algebraic_instruction = (
            f"Based on the extracted information: {key_info}\n"
            "Solve the problem using algebraic techniques. Focus on equations, transformations, "
            "and substitutions. Provide a step-by-step solution."
        )
        geometric_instruction = (
            f"Based on the extracted information: {key_info}\n"
            "Solve the problem using geometric reasoning. Consider coordinate geometry, synthetic "
            "geometry, or trigonometric methods. Provide a step-by-step solution."
        )
        combinatorial_instruction = (
            f"Based on the extracted information: {key_info}\n"
            "Solve the problem using combinatorial or probabilistic reasoning. Consider counting, "
            "recursive structures, or expected values. Provide a step-by-step solution."
        )
        
        solutions = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )
        
        # Step 3: Refine each solution path
        refinement_instruction = (
            "Critique and refine the provided solution. Identify and correct any logical errors, "
            "simplify complex expressions, and ensure all constraints are satisfied. "
            "Provide a revised step-by-step solution."
        )
        refined_solutions = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction, context=sol) for sol in solutions]
        )
        
        # Step 4: Synthesize the best solution
        ensemble_instruction = (
            "Compare the provided solutions and select the most robust and efficient one. "
            "If multiple solutions are valid, combine their insights into a unified approach. "
            "Ensure the final solution explicitly answers the problem's question."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_solutions)
        
        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the solution into a concise format while preserving key steps and the final answer. "
            "Ensure the summary is clear and easy to follow."
        )
        summarized_solution = await self.summarize(instruction=summary_instruction, context=final_solution)
        
        return summarized_solution