# Workflow ID: high_level_math_ganluo_268_0
# Benchmark: high_level_math_ganluo
# Data Indices: [984, 156]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information and decompose the problem
        extraction_instruction = (
            "Extract all key information from the problem, including numerical values, variables, "
            "constraints, and the specific question being asked. Identify the mathematical domain "
            "(e.g., algebra, geometry, number theory) and any relevant formulas or theorems."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        algebraic_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Solve the problem using algebraic methods. Include all steps and reasoning."
        )
        geometric_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Solve the problem using geometric methods. Include all steps and reasoning."
        )
        combinatorial_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Solve the problem using combinatorial reasoning. Include all steps and reasoning."
        )
        number_theory_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Solve the problem using number-theoretic methods. Include all steps and reasoning."
        )

        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text),
            self.generate(instruction=number_theory_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and synthesize the best solution
        ensemble_instruction = (
            "Compare the following candidate solutions and select the most rigorous and elegant one. "
            "Critique each solution for correctness, completeness, and adherence to the problem constraints. "
            "If necessary, synthesize elements from multiple solutions to form a final answer."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 4: Verify and refine the selected solution
        refinement_instruction = (
            "Critically review the following solution for correctness and completeness. "
            "Ensure it satisfies all constraints and makes mathematical sense. "
            "Refine the solution if necessary, providing a polished final answer."
        )
        final_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        return final_solution