# Workflow ID: high_level_math_ganluo_83_0
# Benchmark: high_level_math_ganluo
# Data Indices: [955, 986]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract and Understand the Problem
        extraction_instruction = (
            "Extract all numerical values, constraints, and relationships from the problem. "
            "Identify the type of problem (e.g., algebraic, geometric, combinatorial). "
            "Provide a clear summary of what needs to be solved."
        )
        problem_summary = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Explore Multiple Solution Paths
        algebraic_instruction = (
            f"Using the problem details: {problem_summary}, solve the problem algebraically. "
            "Include all intermediate steps and verify calculations."
        )
        geometric_instruction = (
            f"Using the problem details: {problem_summary}, solve the problem geometrically. "
            "Include visual reasoning if applicable."
        )
        combinatorial_instruction = (
            f"Using the problem details: {problem_summary}, solve the problem combinatorially. "
            "Consider recursive formulas, generating functions, or probabilistic methods."
        )

        # Parallel execution of different approaches
        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and Synthesize Results
        ensemble_instruction = (
            "Compare the following solutions and select the most efficient or accurate one. "
            "Ensure the chosen solution satisfies all constraints and is mathematically rigorous."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 4: Refine and Verify the Solution
        refinement_instruction = (
            f"Review the solution: {best_solution}. Critique and refine it to ensure correctness. "
            "Address any potential errors or ambiguities."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the Final Answer
        summarization_instruction = (
            f"Condense the refined solution: {refined_solution} into a concise final answer. "
            "Ensure the answer is clear, precise, and formatted appropriately."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_solution)

        return final_answer