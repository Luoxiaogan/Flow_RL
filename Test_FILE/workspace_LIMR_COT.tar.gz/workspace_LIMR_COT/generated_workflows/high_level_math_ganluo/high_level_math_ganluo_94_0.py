# Workflow ID: high_level_math_ganluo_94_0
# Benchmark: high_level_math_ganluo
# Data Indices: [846, 390]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem statement
        extraction_instruction = (
            "Extract all numerical values, variables, relationships, and constraints from the problem. "
            "Organize them into a structured format, such as a list or table, for easy reference. "
            "Ensure no critical detail is missed."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Plan the solution approach
        planning_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Devise a detailed step-by-step plan to solve the problem. "
            "Identify the mathematical techniques or strategies required, such as algebraic manipulation, "
            "geometric reasoning, or combinatorial analysis. Ensure the plan addresses all constraints."
        )
        solution_plan = await self.generate(instruction=planning_instruction, context=self.problem_text)

        # Step 3: Execute the solution
        execution_instruction = (
            f"Follow this plan step-by-step: {solution_plan}\n"
            "Perform all necessary calculations and reasoning. Clearly document each step of the process. "
            "If intermediate results are obtained, refine them to ensure accuracy."
        )
        raw_solution = await self.generate(instruction=execution_instruction, context=self.problem_text)

        # Refine the raw solution if needed
        refinement_instruction = (
            "Review the solution for accuracy and completeness. "
            "Correct any errors, fill gaps in reasoning, and simplify expressions where possible."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=raw_solution)

        # Step 4: Validate the solution
        validation_instruction = (
            f"Summarize the solution: {refined_solution}\n"
            "Ensure it satisfies all constraints and conditions stated in the original problem. "
            "Highlight the final answer and confirm it is expressed in the required format."
        )
        validated_solution = await self.summarize(instruction=validation_instruction, context=refined_solution)

        # Step 5: Output the final answer
        return validated_solution