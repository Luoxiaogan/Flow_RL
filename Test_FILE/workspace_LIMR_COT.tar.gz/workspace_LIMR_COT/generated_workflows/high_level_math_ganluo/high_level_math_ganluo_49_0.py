# Workflow ID: high_level_math_ganluo_49_0
# Benchmark: high_level_math_ganluo
# Data Indices: [129, 123]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key components and classify the problem
        extraction_instruction = (
            "Extract all mathematical entities (equations, variables, constraints, etc.) "
            "from the problem statement. Identify the domain of the problem (e.g., algebra, geometry, combinatorics). "
            "Provide a structured summary of these components."
        )
        problem_structure = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Explore multiple solution paths in parallel
        algebraic_instruction = (
            f"Using the extracted components: {problem_structure}, "
            "solve the problem using algebraic methods. Show all steps clearly, including substitutions and simplifications."
        )
        geometric_instruction = (
            f"Using the extracted components: {problem_structure}, "
            "solve the problem using geometric reasoning. Include diagrams or coordinate transformations if applicable."
        )
        combinatorial_instruction = (
            f"Using the extracted components: {problem_structure}, "
            "solve the problem using combinatorial or probabilistic methods. Consider casework or recursive structures if needed."
        )

        algebraic_solution, geometric_solution, combinatorial_solution = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Refine each candidate solution
        refine_instruction_template = (
            "Critically analyze the provided solution. Check for logical consistency, completeness, "
            "and adherence to the problem's constraints. Suggest improvements if necessary."
        )
        refined_algebraic = await self.revise(instruction=refine_instruction_template, context=algebraic_solution)
        refined_geometric = await self.revise(instruction=refine_instruction_template, context=geometric_solution)
        refined_combinatorial = await self.revise(instruction=refine_instruction_template, context=combinatorial_solution)

        # Step 4: Synthesize and decide on the best solution
        synthesis_instruction = (
            "Evaluate the three refined solutions. Select the most rigorous, complete, and elegant solution. "
            "If multiple solutions are valid, synthesize them into a unified answer."
        )
        final_solution = await self.ensemble(
            instruction=synthesis_instruction,
            contexts=[refined_algebraic, refined_geometric, refined_combinatorial]
        )

        # Step 5: Verify and format the final answer
        verification_instruction = (
            "Verify that the final solution satisfies all constraints and conditions of the problem. "
            "Format the answer clearly, including any necessary units or simplifications."
        )
        verified_solution = await self.revise(instruction=verification_instruction, context=final_solution)

        return verified_solution