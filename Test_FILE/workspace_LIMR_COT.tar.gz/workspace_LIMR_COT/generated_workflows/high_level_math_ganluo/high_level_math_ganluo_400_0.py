# Workflow ID: high_level_math_ganluo_400_0
# Benchmark: high_level_math_ganluo
# Data Indices: [27, 270]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Initial Analysis - Extract key information
        initial_analysis = await self.generate(
            instruction="Extract all numerical values, constraints, and the type of question being asked. "
                        "Provide a structured breakdown of the problem components.",
            context=self.problem_text
        )

        # Step 2: Solution Exploration - Generate multiple approaches
        # Approach 1: Algebraic/Analytical
        algebraic_approach = self.generate(
            instruction=f"Using the following extracted information: {initial_analysis} "
                        "Propose an algebraic or analytical solution strategy. "
                        "Include step-by-step reasoning and calculations.",
            context=self.problem_text
        )
        # Approach 2: Combinatorial/Geometric
        combinatorial_approach = self.generate(
            instruction=f"Using the following extracted information: {initial_analysis} "
                        "Propose a combinatorial or geometric solution strategy. "
                        "Include step-by-step reasoning and calculations.",
            context=self.problem_text
        )

        # Execute approaches in parallel
        approaches = await asyncio.gather(algebraic_approach, combinatorial_approach)

        # Step 3: Refinement - Critique and improve each approach
        refined_approaches = []
        for i, approach in enumerate(approaches):
            refined = await self.revise(
                instruction="Critique this approach for logical consistency, mathematical rigor, and completeness. "
                            "Suggest improvements if necessary.",
                context=approach
            )
            refined_approaches.append(refined)

        # Step 4: Synthesis - Compare and select the best approach
        final_solution = await self.ensemble(
            instruction="Compare the following refined approaches and select the most appropriate one. "
                        "If multiple approaches are valid, combine their insights into a unified solution.",
            contexts=refined_approaches
        )

        # Step 5: Final Output - Summarize the chosen solution
        summary = await self.summarize(
            instruction="Condense the final solution into a clear and concise format. "
                        "Ensure all key steps and the final answer are included.",
            context=final_solution
        )

        return summary