# Workflow ID: high_level_math_ganluo_61_0
# Benchmark: high_level_math_ganluo
# Data Indices: [851, 657]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract and Understand the Problem
        problem_structure = await self.generate(
            instruction="Extract all key information from the problem, including variables, constraints, and the question being asked. Organize this information into a structured format.",
            context=self.problem_text
        )

        # Step 2: Generate Candidate Solution Strategies
        algebraic_strategy = self.generate(
            instruction="Develop an algebraic solution strategy for the problem. Include steps for variable manipulation, equation solving, and verification of constraints.",
            context=problem_structure
        )
        geometric_strategy = self.generate(
            instruction="Develop a geometric solution strategy for the problem. Include steps for visualization, coordinate transformations, and area/volume calculations if applicable.",
            context=problem_structure
        )
        combinatorial_strategy = self.generate(
            instruction="Develop a combinatorial solution strategy for the problem. Include steps for counting arrangements, recursive formulas, or probabilistic methods if applicable.",
            context=problem_structure
        )

        # Execute strategies in parallel
        strategies = await asyncio.gather(algebraic_strategy, geometric_strategy, combinatorial_strategy)

        # Step 3: Evaluate and Select the Best Strategy
        best_strategy = await self.ensemble(
            instruction="Evaluate the provided solution strategies. Select the one that is most efficient, accurate, and adheres to the problem constraints. Provide justification for your choice.",
            contexts=strategies
        )

        # Step 4: Refine the Selected Solution
        refined_solution = await self.revise(
            instruction="Critique and refine the selected solution. Ensure all steps are clear, logical, and mathematically sound. Address any ambiguities or errors.",
            context=best_strategy
        )

        # Step 5: Summarize the Final Solution
        final_solution = await self.summarize(
            instruction="Condense the refined solution into a concise and polished form. Highlight the key steps and the final answer.",
            context=refined_solution
        )

        return final_solution