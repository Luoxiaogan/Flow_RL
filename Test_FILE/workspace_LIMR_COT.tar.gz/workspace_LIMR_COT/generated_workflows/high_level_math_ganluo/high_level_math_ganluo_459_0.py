# Workflow ID: high_level_math_ganluo_459_0
# Benchmark: high_level_math_ganluo
# Data Indices: [471, 59]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Problem Decomposition
        decomposition_instruction = (
            "Analyze the problem to identify key components, constraints, and relationships. "
            "Break it into smaller sub-problems or steps. Highlight any patterns, symmetries, "
            "or mathematical structures that could simplify the solution. Ensure the output "
            "is structured and comprehensive."
        )
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Explore Multiple Solution Paths
        algebraic_instruction = (
            f"Using the following problem decomposition:\n{decomposition}\n"
            "Solve the problem using algebraic techniques. Focus on equations, inequalities, "
            "and functional relationships. Provide a step-by-step solution."
        )
        combinatorial_instruction = (
            f"Using the following problem decomposition:\n{decomposition}\n"
            "Solve the problem using combinatorial techniques. Focus on counting principles, "
            "recursion, and probabilistic methods. Provide a step-by-step solution."
        )
        geometric_instruction = (
            f"Using the following problem decomposition:\n{decomposition}\n"
            "Solve the problem using geometric techniques. Focus on properties of shapes, "
            "coordinate geometry, and trigonometric relationships. Provide a step-by-step solution."
        )

        # Parallel execution of multiple approaches
        algebraic_solution, combinatorial_solution, geometric_solution = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text)
        )

        # Step 3: Refinement of Solutions
        refine_instruction_template = (
            "Critique and refine the following solution. Check for logical consistency, "
            "mathematical correctness, and adherence to the problem constraints. Improve "
            "clarity and structure where necessary. Provide the revised solution."
        )
        refined_algebraic = await self.revise(instruction=refine_instruction_template, context=algebraic_solution)
        refined_combinatorial = await self.revise(instruction=refine_instruction_template, context=combinatorial_solution)
        refined_geometric = await self.revise(instruction=refine_instruction_template, context=geometric_solution)

        # Step 4: Synthesis of Results
        ensemble_instruction = (
            "Compare the following solutions and select the most robust, efficient, and "
            "mathematically sound approach. Ensure the chosen solution satisfies all problem "
            "constraints and is presented clearly."
        )
        final_solution = await self.ensemble(
            instruction=ensemble_instruction,
            contexts=[refined_algebraic, refined_combinatorial, refined_geometric]
        )

        # Step 5: Output Compression
        summarize_instruction = (
            "Condense the following solution into a concise, well-structured format. "
            "Ensure all key steps and results are preserved while removing unnecessary details."
        )
        compressed_solution = await self.summarize(instruction=summarize_instruction, context=final_solution)

        return compressed_solution