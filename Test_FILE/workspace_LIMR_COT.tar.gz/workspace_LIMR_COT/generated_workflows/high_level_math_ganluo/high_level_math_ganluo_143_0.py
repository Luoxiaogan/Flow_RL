# Workflow ID: high_level_math_ganluo_143_0
# Benchmark: high_level_math_ganluo
# Data Indices: [596, 988]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all key information from the problem, including variables, constraints, "
            "relationships, and any given numerical values. Organize the information in a structured format."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Explore multiple solution approaches in parallel
        approach_instructions = [
            f"Using algebraic methods, solve the problem based on the following extracted information: {extracted_info}",
            f"Using geometric reasoning, solve the problem based on the following extracted information: {extracted_info}",
            f"Using combinatorial analysis, solve the problem based on the following extracted information: {extracted_info}",
            f"Using number theory techniques, solve the problem based on the following extracted information: {extracted_info}"
        ]
        solutions = await asyncio.gather(
            *(self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions)
        )

        # Step 3: Refine and critique each solution
        refinement_instruction_template = (
            "Critique and refine the following solution. Ensure logical consistency, computational accuracy, "
            "and adherence to all constraints. Verify intermediate steps and consider edge cases."
        )
        refined_solutions = await asyncio.gather(
            *(self.revise(instruction=refinement_instruction_template, context=sol) for sol in solutions)
        )

        # Step 4: Synthesize and select the best solution
        synthesis_instruction = (
            "Compare the following solutions and select the most robust, correct, and elegant one. "
            "Evaluate based on completeness, clarity, and alignment with the problem's requirements."
        )
        final_solution = await self.ensemble(instruction=synthesis_instruction, contexts=refined_solutions)

        # Step 5: Final verification and summarization
        verification_instruction = (
            "Verify that the solution satisfies all constraints and conditions stated in the problem. "
            "Condense the solution into a concise, verifiable form."
        )
        verified_solution = await self.summarize(instruction=verification_instruction, context=final_solution)

        return verified_solution