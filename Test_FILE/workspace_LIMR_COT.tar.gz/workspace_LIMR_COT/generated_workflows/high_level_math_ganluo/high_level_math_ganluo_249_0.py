# Workflow ID: high_level_math_ganluo_249_0
# Benchmark: high_level_math_ganluo
# Data Indices: [303, 364]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem text
        extraction_instruction = (
            "Extract all numerical values, variables, constraints, and relationships from the problem. "
            "Identify the type of problem (e.g., algebraic, geometric, combinatorial) and any specific techniques "
            "that might be applicable. Provide a structured summary of the problem's requirements."
        )
        problem_summary = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Explore multiple solution paths in parallel
        algebraic_instruction = (
            f"Using the extracted information: {problem_summary}, solve the problem algebraically. "
            "Focus on equations, inequalities, and functional relationships. Show all steps clearly."
        )
        geometric_instruction = (
            f"Using the extracted information: {problem_summary}, solve the problem geometrically. "
            "Consider coordinate geometry, synthetic geometry, and trigonometric relationships. Show all steps clearly."
        )
        combinatorial_instruction = (
            f"Using the extracted information: {problem_summary}, solve the problem combinatorially. "
            "Use counting principles, recursive formulas, and generating functions if applicable. Show all steps clearly."
        )

        # Execute parallel solution paths
        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and synthesize the best solution
        ensemble_instruction = (
            "Compare the provided solutions and select the most accurate, complete, and elegant one. "
            "If multiple solutions are valid, synthesize them into a single coherent solution. "
            "Ensure the final solution satisfies all problem constraints."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 4: Verify and refine the solution
        revision_instruction = (
            "Critique the solution for accuracy, logical consistency, and adherence to problem constraints. "
            "Refine the solution if necessary, correcting any errors or omissions. Ensure the final result is robust."
        )
        refined_solution = await self.revise(instruction=revision_instruction, context=best_solution)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the solution into a concise, well-structured format. Include only the essential steps "
            "and the final answer. Ensure clarity and precision."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer