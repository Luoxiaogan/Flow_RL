# Workflow ID: high_level_math_ganluo_123_0
# Benchmark: high_level_math_ganluo
# Data Indices: [104, 643]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all key information from the problem, including variables, equations, "
            "constraints, and the specific question being asked. Organize this information "
            "in a structured format for further analysis."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution paths in parallel
        algebraic_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using algebraic "
            "manipulation. Focus on simplifying equations, solving for variables, and verifying constraints."
        )
        combinatorial_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using combinatorial "
            "or number-theoretic techniques. Consider counting principles, modular arithmetic, or recursive structures."
        )
        geometric_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using geometric reasoning. "
            "Consider coordinate geometry, synthetic geometry, or trigonometric relationships."
        )

        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text)
        )

        # Step 3: Refine each solution path
        refinement_instruction = (
            "Critique and refine the provided solution. Ensure it adheres to all problem constraints, "
            "is mathematically rigorous, and provides a clear path to the final answer."
        )
        refined_results = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction, context=result) for result in results]
        )

        # Step 4: Compare and synthesize solutions
        ensemble_instruction = (
            "Evaluate the provided solutions and select the best one. If multiple solutions are valid, "
            "synthesize them into a single coherent answer. Ensure the final solution satisfies all problem constraints."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_results)

        # Step 5: Summarize the final answer
        summary_instruction = (
            "Summarize the final solution to extract the answer in a clear and concise format. "
            "Ensure the answer directly addresses the question posed in the problem."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=final_solution)

        return final_answer