# Workflow ID: high_level_math_ganluo_139_0
# Benchmark: high_level_math_ganluo
# Data Indices: [122, 56]

```python
class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information and categorize the problem
        problem_analysis = await self.generate(
            instruction="Analyze the problem to identify its domain (e.g., algebra, geometry, combinatorics), "
                        "key numerical values, constraints, and the specific question being asked. "
                        "Provide a structured summary of this information.",
            context=self.problem_text
        )

        # Step 2: Generate multiple solution approaches in parallel
        algebraic_approach = self.generate(
            instruction=f"Using algebraic techniques, solve the problem step by step. "
                        f"Consider equations, inequalities, and functional relationships. "
                        f"Key information: {problem_analysis}",
            context=self.problem_text
        )
        geometric_approach = self.generate(
            instruction=f"Using geometric reasoning, solve the problem step by step. "
                        f"Consider coordinate geometry, synthetic geometry, and trigonometric relationships. "
                        f"Key information: {problem_analysis}",
            context=self.problem_text
        )
        combinatorial_approach = self.generate(
            instruction=f"Using combinatorial or probabilistic methods, solve the problem step by step. "
                        f"Consider counting principles, recursive structures, and expected values. "
                        f"Key information: {problem_analysis}",
            context=self.problem_text
        )

        # Execute approaches in parallel
        results = await asyncio.gather(algebraic_approach, geometric_approach, combinatorial_approach)

        # Step 3: Evaluate and select the best solution
        best_solution = await self.ensemble(
            instruction="Evaluate the following candidate solutions based on correctness, "
                        "simplicity, and adherence to the problem constraints. "
                        "Select the best solution or synthesize parts of different solutions if needed.",
            contexts=results
        )

        # Step 4: Refine the chosen solution
        refined_solution = await self.revise(
            instruction="Critique and refine the solution to ensure all constraints are satisfied, "
                        "errors are corrected, and the reasoning is simplified where possible.",
            context=best_solution
        )

        # Step 5: Summarize the final answer
        final_answer = await self.summarize(
            instruction="Condense the solution into a concise, well-structured answer that directly "
                        "addresses the problem. Include all necessary steps and the final result.",
            context=refined_solution
        )

        return final_answer
```