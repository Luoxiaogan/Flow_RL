# Workflow ID: high_level_math_ganluo_155_0
# Benchmark: high_level_math_ganluo
# Data Indices: [714, 863]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Analyze the problem to extract key components
        problem_analysis = await self.generate(
            instruction="Identify all numerical values, variables, relationships, and constraints in the problem. "
                        "Determine the goal and any special conditions (e.g., modular arithmetic, geometric properties).",
            context=self.problem_text
        )

        # Step 2: Explore multiple solution paths in parallel
        algebraic_solution = self.generate(
            instruction=f"Using algebraic methods, solve the problem step-by-step. Extracted information: {problem_analysis}",
            context=self.problem_text
        )
        geometric_solution = self.generate(
            instruction=f"Using geometric reasoning, solve the problem step-by-step. Extracted information: {problem_analysis}",
            context=self.problem_text
        )
        combinatorial_solution = self.generate(
            instruction=f"Using combinatorial analysis, solve the problem step-by-step. Extracted information: {problem_analysis}",
            context=self.problem_text
        )

        # Execute the parallel tasks
        solutions = await asyncio.gather(algebraic_solution, geometric_solution, combinatorial_solution)

        # Step 3: Evaluate and select the best approach
        best_solution = await self.ensemble(
            instruction="Compare the provided solutions and select the most correct, efficient, and feasible one. "
                        "Consider simplicity, computational complexity, and adherence to problem constraints.",
            contexts=solutions
        )

        # Step 4: Refine the selected solution if necessary
        refined_solution = await self.revise(
            instruction="Critique and improve the selected solution. Address any gaps, errors, or ambiguities. "
                        "Ensure the solution is complete and accurate.",
            context=best_solution
        )

        # Step 5: Compute the final answer
        final_answer = await self.generate(
            instruction="Based on the refined solution, compute the final answer step-by-step. "
                        "Ensure the result satisfies all problem constraints and is presented in the required format.",
            context=refined_solution
        )

        # Step 6: Summarize the solution for clarity and verification
        summary = await self.summarize(
            instruction="Condense the solution into a concise summary. Include all key steps, reasoning, and the final answer.",
            context=final_answer
        )

        return summary