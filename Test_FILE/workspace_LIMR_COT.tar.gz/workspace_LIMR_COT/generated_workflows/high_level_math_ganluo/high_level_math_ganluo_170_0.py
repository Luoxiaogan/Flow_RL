# Workflow ID: high_level_math_ganluo_170_0
# Benchmark: high_level_math_ganluo
# Data Indices: [77, 858]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio
        
        # Step 1: Understand and decompose the problem
        initial_analysis = await self.generate(
            instruction="Analyze the problem thoroughly. Identify the type of mathematics involved (e.g., algebra, geometry, number theory), extract all key variables, equations, constraints, and the goal. Provide a structured breakdown of the problem.",
            context=self.problem_text
        )
        
        # Step 2: Generate multiple solution paths in parallel
        algebraic_solution, alternative_solution = await asyncio.gather(
            self.generate(
                instruction=f"Based on the following analysis: {initial_analysis}\nDevelop an algebraic/analytical solution path. Solve step-by-step, showing all intermediate calculations and reasoning.",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"Based on the following analysis: {initial_analysis}\nExplore a combinatorial, geometric, or alternative solution path. Solve step-by-step, showing all intermediate calculations and reasoning.",
                context=self.problem_text
            )
        )
        
        # Step 3: Critique and refine both solutions
        refined_algebraic, refined_alternative = await asyncio.gather(
            self.revise(
                instruction="Critique the algebraic solution. Check for logical consistency, computational accuracy, and adherence to problem constraints. Improve the solution where necessary.",
                context=algebraic_solution
            ),
            self.revise(
                instruction="Critique the alternative solution. Check for logical consistency, computational accuracy, and adherence to problem constraints. Improve the solution where necessary.",
                context=alternative_solution
            )
        )
        
        # Step 4: Select the best solution
        final_solution = await self.ensemble(
            instruction="Compare the two refined solutions. Select the one that is most accurate, complete, and adheres best to the problem constraints. Justify your choice.",
            contexts=[refined_algebraic, refined_alternative]
        )
        
        # Step 5: Final verification and presentation
        verified_solution = await self.summarize(
            instruction="Verify that the chosen solution satisfies all problem constraints. Present the final answer in a clear, concise format with all necessary details.",
            context=final_solution
        )
        
        return verified_solution