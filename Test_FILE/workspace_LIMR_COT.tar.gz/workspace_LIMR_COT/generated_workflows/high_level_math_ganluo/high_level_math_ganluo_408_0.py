# Workflow ID: high_level_math_ganluo_408_0
# Benchmark: high_level_math_ganluo
# Data Indices: [477, 485]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Carefully analyze the problem statement and extract all numerical values, "
            "relationships, constraints, and the specific question being asked. "
            "Ensure no critical detail is missed and organize the information clearly."
        )
        key_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        approach_instructions = [
            f"Using the extracted information: {key_info}, develop an algebraic approach to solve the problem. "
            "Include all steps and reasoning.",
            f"Using the extracted information: {key_info}, develop a geometric approach to solve the problem. "
            "Include all steps and reasoning.",
            f"Using the extracted information: {key_info}, develop a combinatorial approach to solve the problem. "
            "Include all steps and reasoning."
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Refine each approach
        refine_instructions = [
            f"Review and refine the following approach: {approach}. Correct any errors, clarify ambiguities, "
            "and ensure the reasoning is mathematically sound."
            for approach in approaches
        ]
        refined_approaches = await asyncio.gather(
            *[self.revise(instruction=instr, context=approach) for instr, approach in zip(refine_instructions, approaches)]
        )

        # Step 4: Select the best approach using Ensemble
        ensemble_instruction = (
            "Evaluate the following refined approaches and select the most promising one. "
            "Consider factors such as simplicity, computational feasibility, and alignment with the problem constraints. "
            "Provide a justification for your choice."
        )
        best_approach = await self.ensemble(instruction=ensemble_instruction, contexts=refined_approaches)

        # Step 5: Construct the final solution
        solution_instruction = (
            f"Using the selected approach: {best_approach}, construct the final solution step by step. "
            "Ensure all constraints are satisfied and the solution is mathematically rigorous."
        )
        final_solution = await self.generate(instruction=solution_instruction, context=self.problem_text)

        # Step 6: Summarize the final solution
        summary_instruction = (
            "Condense the final solution into a concise and clear format. "
            "Highlight the key steps and the final answer."
        )
        summarized_solution = await self.summarize(instruction=summary_instruction, context=final_solution)

        return summarized_solution