# Workflow ID: high_level_math_ganluo_457_0
# Benchmark: high_level_math_ganluo
# Data Indices: [888, 162]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key components of the problem
        extraction_instruction = (
            "Carefully analyze the problem statement and extract all critical components, "
            "including variables, constants, relationships, constraints, and the specific question being asked. "
            "Organize this information in a structured format for further processing."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        generate_instructions = [
            f"Using the extracted information: {extracted_info}, solve the problem algebraically. "
            "Provide a step-by-step reasoning process.",
            
            f"Using the extracted information: {extracted_info}, solve the problem geometrically. "
            "Include diagrams or visual representations if applicable.",
            
            f"Using the extracted information: {extracted_info}, solve the problem using combinatorics or probability. "
            "Clearly explain the counting principles or probabilistic methods applied."
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in generate_instructions]
        )

        # Step 3: Evaluate and select the best approach
        ensemble_instruction = (
            "Compare the following solution approaches and determine which one is the most accurate, efficient, "
            "and aligned with the problem's requirements. If multiple approaches are valid, synthesize them "
            "into a unified solution."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=approaches)

        # Step 4: Refine the chosen solution
        refine_instruction = (
            "Critically review the provided solution and improve it by ensuring accuracy, completeness, "
            "and adherence to all problem constraints. Address any gaps or ambiguities."
        )
        refined_solution = await self.revise(instruction=refine_instruction, context=best_solution)

        # Step 5: Summarize the final answer
        summarize_instruction = (
            "Condense the refined solution into a concise, well-structured answer. Ensure the final result "
            "is clear, directly addresses the problem's question, and includes all necessary supporting details."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_answer