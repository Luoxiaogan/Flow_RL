# Workflow ID: high_level_math_ganluo_131_0
# Benchmark: high_level_math_ganluo
# Data Indices: [786, 501]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Understand the Problem
        problem_understanding = await self.generate(
            instruction="Extract all numerical values, variables, constraints, and the specific question being asked. "
                        "Organize this information clearly for further analysis.",
            context=self.problem_text
        )

        # Step 2: Develop Multiple Solution Strategies
        strategies = await asyncio.gather(
            self.generate(
                instruction=f"Based on the extracted information: {problem_understanding}, "
                            "develop an algebraic solution strategy. Include step-by-step reasoning.",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"Based on the extracted information: {problem_understanding}, "
                            "develop a geometric solution strategy. Include step-by-step reasoning.",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"Based on the extracted information: {problem_understanding}, "
                            "develop a combinatorial or probabilistic solution strategy. Include step-by-step reasoning.",
                context=self.problem_text
            )
        )

        # Step 3: Execute the Most Promising Strategy
        selected_strategy = await self.ensemble(
            instruction="Evaluate the provided solution strategies and select the most promising one. "
                        "Consider clarity, feasibility, and alignment with the problem constraints.",
            contexts=strategies
        )

        execution_result = await self.generate(
            instruction=f"Execute the selected strategy: {selected_strategy}. "
                        "Perform all calculations and logical deductions step by step. Ensure all constraints are satisfied.",
            context=self.problem_text
        )

        # Step 4: Validate the Solution
        validation_summary = await self.summarize(
            instruction="Summarize the solution and verify that it satisfies all problem constraints. "
                        "Highlight any discrepancies or missing steps.",
            context=execution_result
        )

        # Final Step: Revise if Necessary
        final_solution = await self.revise(
            instruction="Review the solution and validation summary. Revise the solution if discrepancies are found. "
                        "Ensure the final result is correct and complete.",
            context=validation_summary
        )

        return final_solution