# Workflow ID: high_level_math_ganluo_54_0
# Benchmark: high_level_math_ganluo
# Data Indices: [623, 853]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key components of the problem
        extraction_instruction = (
            "Identify and extract all key components of the problem, including equations, variables, "
            "constraints, and any relevant mathematical structures. Organize the information clearly."
        )
        key_components = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        algebraic_instruction = (
            f"Using the extracted components: {key_components}, solve the problem algebraically. "
            "Provide detailed reasoning and intermediate steps."
        )
        geometric_instruction = (
            f"Using the extracted components: {key_components}, solve the problem geometrically. "
            "Provide detailed reasoning and intermediate steps."
        )
        combinatorial_instruction = (
            f"Using the extracted components: {key_components}, solve the problem using combinatorial methods. "
            "Provide detailed reasoning and intermediate steps."
        )

        # Parallel execution for multiple approaches
        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Refine each solution approach
        refine_instruction_template = (
            "Critique and refine the following solution. Ensure it satisfies all problem constraints, "
            "is mathematically rigorous, and includes all necessary steps. If errors are found, correct them."
        )
        refined_results = await asyncio.gather(
            *[self.revise(instruction=refine_instruction_template, context=result) for result in results]
        )

        # Step 4: Summarize key insights from each refined solution
        summarize_instruction = (
            "Condense the key insights and final result from the following solution. "
            "Ensure the summary is concise but retains all essential information."
        )
        summaries = await asyncio.gather(
            *[self.summarize(instruction=summarize_instruction, context=result) for result in refined_results]
        )

        # Step 5: Ensemble evaluation to select or synthesize the best solution
        ensemble_instruction = (
            "Evaluate the following candidate solutions. Select the most correct and complete solution, "
            "or synthesize a new solution if necessary. Provide justification for your choice."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=summaries)

        return final_solution