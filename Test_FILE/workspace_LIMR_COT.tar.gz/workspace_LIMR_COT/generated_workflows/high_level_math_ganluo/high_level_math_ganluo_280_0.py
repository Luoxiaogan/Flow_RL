# Workflow ID: high_level_math_ganluo_280_0
# Benchmark: high_level_math_ganluo
# Data Indices: [602, 860]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all key information from the problem, including variables, constants, "
            "relationships, constraints, and the goal. Organize the information clearly."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple candidate solutions in parallel
        candidate_instructions = [
            f"Using an algebraic approach, solve the problem based on the following extracted information: {extracted_info}",
            f"Using a geometric approach, solve the problem based on the following extracted information: {extracted_info}",
            f"Using a combinatorial or number-theoretic approach, solve the problem based on the following extracted information: {extracted_info}"
        ]
        candidate_solutions = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in candidate_instructions]
        )

        # Step 3: Refine each candidate solution
        refinement_instruction_template = (
            "Critically evaluate and refine the following solution. Ensure it is mathematically rigorous, "
            "satisfies all constraints, and accounts for edge cases. Provide detailed reasoning."
        )
        refined_solutions = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction_template, context=sol) for sol in candidate_solutions]
        )

        # Step 4: Select the best solution using Ensemble
        ensemble_instruction = (
            "Compare the following solutions and select the most appropriate one. "
            "Consider correctness, elegance, clarity, and adherence to the problem constraints. "
            "Provide justification for your choice."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_solutions)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the following solution into a concise and clear format suitable for presentation. "
            "Ensure all key steps and reasoning are preserved."
        )
        final_output = await self.summarize(instruction=summary_instruction, context=best_solution)

        return final_output