# Workflow ID: high_level_math_ganluo_317_0
# Benchmark: high_level_math_ganluo
# Data Indices: [192, 199]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Analyze the problem and extract key information
        analysis_instruction = (
            "Thoroughly analyze the given problem. Identify the mathematical domain (e.g., algebra, geometry, combinatorics), "
            "extract all numerical values, variables, and constraints, and describe any hidden structures or patterns. "
            "Provide a detailed breakdown of the problem."
        )
        problem_analysis = await self.generate(instruction=analysis_instruction, context=self.problem_text)

        # Step 2: Generate multiple candidate solutions in parallel
        algebraic_instruction = (
            f"Using the problem analysis: {problem_analysis}, solve the problem using an algebraic approach. "
            "Show all steps, justify each transformation, and ensure the solution satisfies all constraints."
        )
        geometric_instruction = (
            f"Using the problem analysis: {problem_analysis}, solve the problem using a geometric approach. "
            "Visualize the problem if necessary, and provide a step-by-step solution."
        )
        combinatorial_instruction = (
            f"Using the problem analysis: {problem_analysis}, solve the problem using a combinatorial approach. "
            "Consider counting techniques, recursive structures, or generating functions as needed."
        )

        candidates = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Refine each candidate solution
        refinement_instruction = (
            "Carefully review the provided solution. Check for mathematical correctness, logical consistency, "
            "and adherence to all constraints. Suggest improvements if necessary and refine the solution."
        )
        refined_solutions = await asyncio.gather(
            self.revise(instruction=refinement_instruction, context=candidates[0]),
            self.revise(instruction=refinement_instruction, context=candidates[1]),
            self.revise(instruction=refinement_instruction, context=candidates[2])
        )

        # Step 4: Select the best solution using Ensemble
        ensemble_instruction = (
            "Compare the provided solutions and select the best one. Consider correctness, elegance, efficiency, "
            "and clarity. If possible, synthesize elements from multiple solutions to create an optimal answer."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_solutions)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Summarize the final solution in a concise and clear format. Highlight the key steps, results, "
            "and any important insights. Ensure the summary is easy to understand and verify."
        )
        summarized_solution = await self.summarize(instruction=summary_instruction, context=final_solution)

        return summarized_solution