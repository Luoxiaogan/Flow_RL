# Workflow ID: high_level_math_ganluo_161_0
# Benchmark: high_level_math_ganluo
# Data Indices: [411, 754]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information and understand the problem
        extraction_instruction = (
            "Carefully analyze the problem statement to identify all variables, constants, "
            "constraints, and objectives. Provide a structured summary of the problem, including "
            "any implicit assumptions or relationships."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Explore multiple solution approaches in parallel
        algebraic_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Solve the problem using algebraic techniques. Consider equations, inequalities, "
            "and functional relationships. Ensure all constraints are satisfied."
        )
        geometric_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Solve the problem using geometric reasoning. Analyze shapes, coordinates, areas, "
            "or volumes. Leverage symmetry and spatial relationships if applicable."
        )
        combinatorial_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Solve the problem using combinatorial methods. Count arrangements, calculate "
            "probabilities, or use recursive formulas. Apply principles like linearity of expectation if needed."
        )

        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and select the best approach
        ensemble_instruction = (
            "Compare the following candidate solutions and select the most appropriate one. "
            "Ensure the chosen solution satisfies all constraints, is mathematically rigorous, "
            "and aligns with the problem's requirements."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 4: Refine the selected solution
        refine_instruction = (
            "Critically review and improve the following solution. Ensure clarity, correctness, "
            "and adherence to the problem's constraints. Simplify expressions and verify all steps."
        )
        refined_solution = await self.revise(instruction=refine_instruction, context=best_solution)

        # Step 5: Verify the final solution
        verification_instruction = (
            "Verify that the following solution satisfies all constraints and requirements of the problem. "
            "Check for edge cases, hidden assumptions, and computational accuracy."
        )
        final_verification = await self.revise(instruction=verification_instruction, context=refined_solution)

        return final_verification