# Workflow ID: high_level_math_ganluo_167_0
# Benchmark: high_level_math_ganluo
# Data Indices: [209, 536]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all numerical values, variables, constraints, and relationships from the problem. "
            "Identify the type of mathematical problem (e.g., algebraic, geometric, combinatorial) and "
            "list any special techniques or formulas that might be relevant."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple candidate solutions in parallel
        candidate_instructions = [
            f"Using the following extracted information: {extracted_info}, solve the problem using an algebraic approach.",
            f"Using the following extracted information: {extracted_info}, solve the problem using a geometric approach.",
            f"Using the following extracted information: {extracted_info}, solve the problem using a combinatorial approach."
        ]
        candidate_solutions = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in candidate_instructions]
        )

        # Step 3: Evaluate and select the best solution
        ensemble_instruction = (
            "Compare the following candidate solutions and select the most correct, complete, and efficient one. "
            "If multiple solutions are partially correct, synthesize them into a single robust solution."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=candidate_solutions)

        # Step 4: Refine the selected solution
        refinement_instruction = (
            "Critique and refine the following solution to ensure it satisfies all constraints, is mathematically rigorous, "
            "and is presented clearly."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the final answer
        summary_instruction = (
            "Extract the final answer from the following solution, ensuring it is concise and directly addresses the problem."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer