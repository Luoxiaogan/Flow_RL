# Workflow ID: high_level_math_ganluo_290_0
# Benchmark: high_level_math_ganluo
# Data Indices: [755, 43]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all numerical values, variables, constraints, and relationships "
            "from the problem. Organize them into a structured format for analysis."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        algebra_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "solve the problem using algebraic methods. Include step-by-step reasoning."
        )
        geometry_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "solve the problem using geometric reasoning. Include step-by-step reasoning."
        )
        combinatorics_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "solve the problem using combinatorial or probabilistic methods. Include step-by-step reasoning."
        )

        # Execute solution approaches in parallel
        results = await asyncio.gather(
            self.generate(instruction=algebra_instruction, context=self.problem_text),
            self.generate(instruction=geometry_instruction, context=self.problem_text),
            self.generate(instruction=combinatorics_instruction, context=self.problem_text)
        )

        # Step 3: Ensemble to select or synthesize the best solution
        ensemble_instruction = (
            "Evaluate the provided solutions. Select the most appropriate one or synthesize a hybrid solution. "
            "Ensure the final solution satisfies all constraints and is mathematically sound."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 4: Refine the chosen solution
        refinement_instruction = (
            "Critically analyze and refine the solution. Ensure it is complete, correct, and addresses all edge cases."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the solution into a concise, well-structured format. "
            "Include only the essential steps and the final answer."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_summary