# Workflow ID: high_level_math_ganluo_181_0
# Benchmark: high_level_math_ganluo
# Data Indices: [625, 61]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Problem Decomposition
        decomposition_instruction = (
            "Analyze the problem and identify its key components, such as variables, constraints, "
            "and relationships. Provide a structured breakdown of the problem, including any "
            "mathematical structures or patterns that are evident."
        )
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Generate Multiple Solution Approaches
        approach_instructions = [
            "Solve the problem using an algebraic approach. Focus on equations, transformations, "
            "and manipulations. Ensure all steps are mathematically rigorous.",
            "Solve the problem using a geometric approach. Consider visual representations, "
            "coordinate systems, and spatial relationships.",
            "Solve the problem using a combinatorial or number-theoretic approach. Focus on "
            "counting principles, modular arithmetic, or divisibility properties."
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=decomposition) for instr in approach_instructions]
        )

        # Step 3: Evaluate and Select the Best Approach
        evaluation_instruction = (
            "Compare the provided solution approaches based on correctness, elegance, and feasibility. "
            "Select the most appropriate approach that satisfies all problem constraints and provides "
            "a clear path to the solution."
        )
        best_approach = await self.ensemble(instruction=evaluation_instruction, contexts=approaches)

        # Step 4: Refine the Selected Solution
        refinement_instruction = (
            "Critique and refine the selected solution. Ensure mathematical rigor, clarify any "
            "ambiguous steps, and verify that all constraints are satisfied. Improve the solution's "
            "presentation for clarity and precision."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_approach)

        # Step 5: Summarize the Final Answer
        summary_instruction = (
            "Summarize the refined solution into a concise and clear final answer. Include only the "
            "essential steps and the final result, ensuring it is easy to understand and verify."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer