# Workflow ID: high_level_math_ganluo_4_0
# Benchmark: high_level_math_ganluo
# Data Indices: [308, 844]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all numerical values, variables, constraints, and relationships from the problem. "
            "Organize them into categories such as 'Given', 'Find', and 'Constraints'."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple independent solutions in parallel
        generate_instructions = [
            f"Using an algebraic approach, solve the problem step by step. Given information: {extracted_info}.",
            f"Using a geometric approach, solve the problem step by step. Given information: {extracted_info}.",
            f"Using a combinatorial or probabilistic approach, solve the problem step by step. Given information: {extracted_info}."
        ]
        solutions = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in generate_instructions]
        )

        # Step 3: Revise each solution for correctness and rigor
        revise_instruction_template = (
            "Critically evaluate the solution. Check for logical consistency, adherence to constraints, "
            "and proper handling of edge cases. Improve clarity and correctness where needed."
        )
        revised_solutions = await asyncio.gather(
            *[self.revise(instruction=revise_instruction_template, context=sol) for sol in solutions]
        )

        # Step 4: Select the best solution using Ensemble
        ensemble_instruction = (
            "Compare the provided solutions and select the best one based on correctness, clarity, and efficiency. "
            "Provide a justification for your choice."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=revised_solutions)

        # Step 5: Summarize the final solution
        summarize_instruction = (
            "Condense the solution into a concise summary. Include the key steps and the final answer. "
            "Ensure the summary is easy to understand and verify."
        )
        final_summary = await self.summarize(instruction=summarize_instruction, context=best_solution)

        return final_summary