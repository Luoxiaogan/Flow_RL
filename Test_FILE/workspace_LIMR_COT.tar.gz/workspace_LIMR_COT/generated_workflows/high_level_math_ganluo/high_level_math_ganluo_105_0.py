# Workflow ID: high_level_math_ganluo_105_0
# Benchmark: high_level_math_ganluo
# Data Indices: [592, 731]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem text
        extraction = await self.generate(
            instruction="Extract all numerical values, variables, constraints, and the type of mathematical operation required from the problem. "
                        "Organize the information into categories such as 'Numerical Values', 'Constraints', and 'Objective'.",
            context=self.problem_text
        )

        # Step 2: Generate multiple solution paths in parallel
        algebraic_approach = self.generate(
            instruction=f"Using the extracted information: {extraction}, "
                        "solve the problem using algebraic manipulation. Provide step-by-step reasoning and intermediate results.",
            context=self.problem_text
        )
        geometric_approach = self.generate(
            instruction=f"Using the extracted information: {extraction}, "
                        "solve the problem using geometric reasoning or coordinate geometry. Provide step-by-step reasoning and intermediate results.",
            context=self.problem_text
        )
        combinatorial_approach = self.generate(
            instruction=f"Using the extracted information: {extraction}, "
                        "solve the problem using combinatorial methods or recursive patterns. Provide step-by-step reasoning and intermediate results.",
            context=self.problem_text
        )

        # Run the three approaches in parallel
        results = await asyncio.gather(algebraic_approach, geometric_approach, combinatorial_approach)

        # Step 3: Evaluate and synthesize the best solution
        best_solution = await self.ensemble(
            instruction="Compare the three candidate solutions provided in the contexts. "
                        "Evaluate them based on correctness, clarity, and adherence to the problem's constraints. "
                        "Select the most appropriate solution and provide justification for your choice.",
            contexts=results
        )

        # Step 4: Refine and verify the selected solution
        refined_solution = await self.revise(
            instruction="Critique and refine the selected solution. Ensure all constraints are satisfied, "
                        "simplify any complex expressions, and verify the solution against edge cases. "
                        "Provide a polished and mathematically rigorous final answer.",
            context=best_solution
        )

        # Step 5: Summarize the final result
        final_answer = await self.summarize(
            instruction="Condense the refined solution into a concise final answer. "
                        "Include only the essential steps and the final result.",
            context=refined_solution
        )

        return final_answer