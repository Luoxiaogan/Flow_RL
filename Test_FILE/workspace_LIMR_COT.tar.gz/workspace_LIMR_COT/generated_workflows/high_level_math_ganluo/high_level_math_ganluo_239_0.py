# Workflow ID: high_level_math_ganluo_239_0
# Benchmark: high_level_math_ganluo
# Data Indices: [620, 997]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key components from the problem text
        extraction_instruction = (
            "Extract all key components from the problem, including numerical values, constraints, "
            "relationships, and any special conditions. Organize the information in a structured format."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Explore multiple solution paths in parallel
        algebraic_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using algebraic methods. "
            "Include all steps and reasoning explicitly."
        )
        combinatorial_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using combinatorial methods. "
            "Include all steps and reasoning explicitly."
        )
        geometric_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using geometric methods. "
            "Include all steps and reasoning explicitly."
        )

        # Parallel execution of multiple approaches
        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text)
        )

        # Step 3: Refine intermediate results
        refined_results = []
        for result in results:
            refinement_instruction = (
                "Critique and refine the following solution to ensure correctness, logical consistency, "
                "and adherence to the problem's constraints. Provide detailed feedback and improvements."
            )
            refined_result = await self.revise(instruction=refinement_instruction, context=result)
            refined_results.append(refined_result)

        # Step 4: Synthesize results using Ensemble
        synthesis_instruction = (
            "Evaluate the following candidate solutions and select the most robust, mathematically sound, "
            "and efficient solution. Provide justification for your choice."
        )
        final_solution = await self.ensemble(instruction=synthesis_instruction, contexts=refined_results)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the following solution into a concise and verifiable form. Ensure that all constraints "
            "are satisfied and the solution is presented clearly."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=final_solution)

        return final_summary