# Workflow ID: high_level_math_ganluo_253_0
# Benchmark: high_level_math_ganluo
# Data Indices: [473, 73]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key components from the problem
        extraction_instruction = (
            "Extract all key mathematical elements from the problem, including equations, variables, "
            "constraints, and what is being asked. Organize the information clearly."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution strategies in parallel
        algebra_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Solve the problem using algebraic manipulation. Show all steps and justify each transformation."
        )
        geometry_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Interpret the problem geometrically if applicable. Solve using geometric reasoning."
        )
        combinatorics_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Approach the problem using combinatorial reasoning. Count or calculate systematically."
        )

        algebra_solution, geometry_solution, combinatorics_solution = await asyncio.gather(
            self.generate(instruction=algebra_instruction, context=self.problem_text),
            self.generate(instruction=geometry_instruction, context=self.problem_text),
            self.generate(instruction=combinatorics_instruction, context=self.problem_text)
        )

        # Step 3: Refine each solution strategy
        refine_instruction_template = (
            "Critically evaluate the following solution. Check for correctness, completeness, and adherence "
            "to the problem's constraints. Revise as needed to ensure it is mathematically sound."
        )
        refined_algebra = await self.revise(instruction=refine_instruction_template, context=algebra_solution)
        refined_geometry = await self.revise(instruction=refine_instruction_template, context=geometry_solution)
        refined_combinatorics = await self.revise(instruction=refine_instruction_template, context=combinatorics_solution)

        # Step 4: Select the best solution using Ensemble
        ensemble_instruction = (
            "Compare the following solutions and select the best one. Consider clarity, correctness, "
            "and alignment with the problem's requirements. Provide a justification for your choice."
        )
        best_solution = await self.ensemble(
            instruction=ensemble_instruction,
            contexts=[refined_algebra, refined_geometry, refined_combinatorics]
        )

        # Step 5: Summarize the final result (if needed)
        summarize_instruction = (
            "Condense the final solution into a clear and concise format. Ensure all key steps and results are included."
        )
        final_result = await self.summarize(instruction=summarize_instruction, context=best_solution)

        return final_result