# Workflow ID: high_level_math_ganluo_97_0
# Benchmark: high_level_math_ganluo
# Data Indices: [603, 808]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Initial Analysis - Extract critical information
        extraction = await self.generate(
            instruction="Extract all numerical values, variables, relationships, and constraints from the problem. "
                        "Identify the mathematical domain (e.g., algebra, geometry, combinatorics) and any specific techniques that might apply.",
            context=self.problem_text
        )

        # Step 2: Generate Multiple Solution Approaches in Parallel
        algebraic_solution = self.generate(
            instruction=f"Using algebraic methods, solve the problem. Extracted information: {extraction}. "
                        "Include step-by-step reasoning and validate the solution against all constraints.",
            context=self.problem_text
        )
        geometric_solution = self.generate(
            instruction=f"Using geometric reasoning, solve the problem. Extracted information: {extraction}. "
                        "Include step-by-step reasoning and validate the solution against all constraints.",
            context=self.problem_text
        )
        combinatorial_solution = self.generate(
            instruction=f"Using combinatorial or recursive methods, solve the problem. Extracted information: {extraction}. "
                        "Include step-by-step reasoning and validate the solution against all constraints.",
            context=self.problem_text
        )

        # Execute approaches in parallel
        results = await asyncio.gather(algebraic_solution, geometric_solution, combinatorial_solution)

        # Step 3: Refine and Validate Solutions
        refined_results = await asyncio.gather(
            *[self.revise(
                instruction=f"Critique and refine this solution. Ensure it satisfies all constraints and is mathematically rigorous. "
                            f"Extracted information: {extraction}.",
                context=result
            ) for result in results]
        )

        # Step 4: Ensemble Decision-Making - Select the Best Solution
        final_solution = await self.ensemble(
            instruction="Compare the refined solutions and select the best one. Synthesize insights from different approaches if necessary.",
            contexts=refined_results
        )

        # Step 5: Summarize Final Answer
        summary = await self.summarize(
            instruction="Condense the final solution into a concise, well-structured format. Include the answer and key reasoning steps.",
            context=final_solution
        )

        return summary