# Workflow ID: high_level_math_ganluo_437_0
# Benchmark: high_level_math_ganluo
# Data Indices: [733, 718]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information and understand the problem
        problem_understanding = await self.generate(
            instruction="Extract all key information from the problem, including variables, constraints, and relationships. Identify the type of problem (e.g., algebraic, geometric, combinatorial) and any specific techniques that might be relevant.",
            context=self.problem_text
        )

        # Step 2: Generate multiple solution approaches in parallel
        algebraic_approach, geometric_approach, combinatorial_approach = await asyncio.gather(
            self.generate(
                instruction=f"Based on the extracted information: {problem_understanding}, solve the problem using algebraic techniques such as equations, inequalities, or functional relationships.",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"Based on the extracted information: {problem_understanding}, solve the problem using geometric reasoning, including coordinate geometry, synthetic geometry, or trigonometric methods.",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"Based on the extracted information: {problem_understanding}, solve the problem using combinatorial techniques such as counting principles, recursion, or generating functions.",
                context=self.problem_text
            )
        )

        # Step 3: Refine each approach
        refined_algebraic = await self.revise(
            instruction="Critique and improve this algebraic solution. Ensure it satisfies all constraints, addresses edge cases, and is mathematically rigorous.",
            context=algebraic_approach
        )
        refined_geometric = await self.revise(
            instruction="Critique and improve this geometric solution. Ensure it satisfies all constraints, addresses edge cases, and is mathematically rigorous.",
            context=geometric_approach
        )
        refined_combinatorial = await self.revise(
            instruction="Critique and improve this combinatorial solution. Ensure it satisfies all constraints, addresses edge cases, and is mathematically rigorous.",
            context=combinatorial_approach
        )

        # Step 4: Ensemble decision to select or synthesize the best solution
        final_solution = await self.ensemble(
            instruction="Compare these refined solutions and select the most robust and efficient one. If applicable, synthesize insights from multiple approaches to create a superior solution.",
            contexts=[refined_algebraic, refined_geometric, refined_combinatorial]
        )

        # Step 5: Summarize the final solution
        final_answer = await self.summarize(
            instruction="Condense the final solution into a concise and well-structured format. Highlight the key steps, reasoning, and the final result.",
            context=final_solution
        )

        return final_answer