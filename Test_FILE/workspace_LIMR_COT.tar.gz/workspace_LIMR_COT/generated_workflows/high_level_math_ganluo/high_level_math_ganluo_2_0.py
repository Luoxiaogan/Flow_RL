# Workflow ID: high_level_math_ganluo_2_0
# Benchmark: high_level_math_ganluo
# Data Indices: [441, 996]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information and understand the problem
        extraction_instruction = (
            "Extract all numerical values, variables, constraints, and the target question from the problem. "
            "Organize this information in a structured format for further analysis."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Explore multiple solution approaches in parallel
        algebraic_approach = self.generate(
            instruction=f"Using algebraic methods, solve the problem based on the following extracted information: {extracted_info}.",
            context=self.problem_text
        )
        geometric_approach = self.generate(
            instruction=f"Using geometric reasoning, solve the problem based on the following extracted information: {extracted_info}.",
            context=self.problem_text
        )
        combinatorial_approach = self.generate(
            instruction=f"Using combinatorial or probabilistic methods, solve the problem based on the following extracted information: {extracted_info}.",
            context=self.problem_text
        )

        # Execute approaches in parallel
        results = await asyncio.gather(algebraic_approach, geometric_approach, combinatorial_approach)

        # Step 3: Refine each candidate solution
        refinement_instructions = (
            "Critique the solution for mathematical correctness, logical consistency, and adherence to constraints. "
            "Identify and correct any errors or oversights."
        )
        refined_results = await asyncio.gather(
            *[self.revise(instruction=refinement_instructions, context=result) for result in results]
        )

        # Step 4: Synthesize results using Ensemble
        synthesis_instruction = (
            "Compare the provided solutions and select the most elegant, efficient, and mathematically sound approach. "
            "If multiple solutions are valid, combine their insights into a unified answer."
        )
        final_solution = await self.ensemble(instruction=synthesis_instruction, contexts=refined_results)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the solution into a clear and concise format, preserving all key steps and reasoning. "
            "Ensure the final answer is explicitly stated and satisfies all problem constraints."
        )
        summarized_solution = await self.summarize(instruction=summary_instruction, context=final_solution)

        return summarized_solution