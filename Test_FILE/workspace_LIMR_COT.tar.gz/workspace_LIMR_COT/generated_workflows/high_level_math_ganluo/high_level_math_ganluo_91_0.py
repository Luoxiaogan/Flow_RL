# Workflow ID: high_level_math_ganluo_91_0
# Benchmark: high_level_math_ganluo
# Data Indices: [784, 770]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Carefully analyze the problem statement to extract all variables, constraints, relationships, "
            "and the goal. Organize the information in a structured format, clearly separating known values, "
            "unknowns, and conditions."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        algebraic_instruction = (
            f"Using the extracted information: {extracted_info}, develop an algebraic solution approach. "
            "Focus on equations, inequalities, and transformations. Clearly outline each step."
        )
        geometric_instruction = (
            f"Using the extracted information: {extracted_info}, develop a geometric solution approach. "
            "Consider visual representations, coordinate geometry, and symmetry properties."
        )
        combinatorial_instruction = (
            f"Using the extracted information: {extracted_info}, develop a combinatorial solution approach. "
            "Focus on counting principles, recursive structures, and probabilistic methods."
        )

        approaches = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and synthesize the best approach
        ensemble_instruction = (
            "Compare the provided solution approaches and select the most promising one. "
            "Consider factors such as correctness, simplicity, and computational feasibility. "
            "If possible, synthesize elements from multiple approaches into a unified solution."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=approaches)

        # Step 4: Refine the selected solution
        refinement_instruction = (
            "Critically review the selected solution. Identify and address any gaps, errors, or ambiguities. "
            "Ensure the solution satisfies all constraints and is mathematically rigorous."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the refined solution into a clear and concise format. Highlight the key steps, "
            "final result, and any important insights."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_summary