# Workflow ID: high_level_math_ganluo_191_0
# Benchmark: high_level_math_ganluo
# Data Indices: [375, 794]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract critical components of the problem
        extraction_instruction = (
            "Carefully analyze the problem and extract all key components, including numerical values, "
            "variables, constraints, and relationships. Organize the extracted information clearly."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        approach_instructions = [
            f"Develop an algebraic approach to solve the problem. Use the following extracted information: {extracted_info}.",
            f"Develop a geometric reasoning approach to solve the problem. Use the following extracted information: {extracted_info}.",
            f"Develop a combinatorial or number-theoretic approach to solve the problem. Use the following extracted information: {extracted_info}."
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Evaluate and select the best approach
        ensemble_instruction = (
            "Compare the provided solution approaches and select the one that is most feasible, clear, "
            "and aligned with the problem's requirements. Provide a justification for your choice."
        )
        best_approach = await self.ensemble(instruction=ensemble_instruction, contexts=approaches)

        # Step 4: Refine the selected approach
        refine_instruction = (
            "Critique and refine the selected solution approach. Ensure it is mathematically rigorous, "
            "satisfies all constraints, and is presented in a clear and logical manner."
        )
        refined_solution = await self.revise(instruction=refine_instruction, context=best_approach)

        # Step 5: Summarize the final solution
        summarize_instruction = (
            "Condense the refined solution into a concise and readable format. Include the final answer "
            "and ensure it is easy to understand."
        )
        final_output = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_output