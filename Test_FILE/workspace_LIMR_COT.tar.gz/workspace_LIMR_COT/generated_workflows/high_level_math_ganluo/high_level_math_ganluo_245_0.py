# Workflow ID: high_level_math_ganluo_245_0
# Benchmark: high_level_math_ganluo
# Data Indices: [187, 109]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract relevant information from the problem
        extraction_instruction = (
            "Extract all numerical values, variables, relationships, and constraints from the problem. "
            "Include any equations, inequalities, geometric properties, or combinatorial structures explicitly mentioned. "
            "Format the output as a structured list for clarity."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate parallel reasoning attempts
        algebraic_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Solve the problem using algebraic methods. Perform step-by-step calculations, simplify expressions, "
            "and verify intermediate results. If there are multiple cases, handle them systematically."
        )
        geometric_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Solve the problem using geometric reasoning. Consider coordinate geometry, synthetic geometry, "
            "or trigonometric methods as appropriate. Clearly justify all steps and assumptions."
        )
        combinatorial_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Solve the problem using combinatorial or probabilistic methods. Count arrangements, calculate expected values, "
            "or use recursive structures if applicable. Ensure all cases are considered."
        )

        # Parallel execution of reasoning attempts
        reasoning_attempts = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Refine each reasoning attempt
        refinement_instruction = (
            "Critique and refine the provided solution. Check for logical consistency, computational accuracy, "
            "and adherence to all problem constraints. Address any gaps or ambiguities in the reasoning process. "
            "Provide a revised version of the solution with improvements highlighted."
        )
        refined_solutions = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction, context=attempt) for attempt in reasoning_attempts]
        )

        # Step 4: Ensemble decision-making
        ensemble_instruction = (
            "Compare the provided solutions and determine the most robust, accurate, and complete one. "
            "If multiple solutions are valid, synthesize their insights to produce a final answer. "
            "Ensure the chosen solution satisfies all problem constraints and is mathematically rigorous."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_solutions)

        # Step 5: Summarize the final answer
        summary_instruction = (
            "Condense the final solution into a clear and concise format. Include only the essential steps "
            "and the final answer. Format the output for readability and precision."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=final_solution)

        return final_answer