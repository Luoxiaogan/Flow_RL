# Workflow ID: high_level_math_ganluo_393_0
# Benchmark: high_level_math_ganluo
# Data Indices: [992, 740]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information and understand the problem
        extraction_instruction = (
            "Extract all key information from the problem, including variables, constants, constraints, "
            "and the goal. Organize this information in a structured format for further reasoning."
        )
        key_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Explore multiple solution paths in parallel
        algebraic_instruction = (
            f"Using the extracted information: {key_info}, solve the problem using algebraic methods. "
            "Include all steps, transformations, and reasoning explicitly."
        )
        geometric_instruction = (
            f"Using the extracted information: {key_info}, solve the problem using geometric reasoning. "
            "Include diagrams, visual representations, and spatial relationships if applicable."
        )
        combinatorial_instruction = (
            f"Using the extracted information: {key_info}, solve the problem using combinatorial analysis. "
            "Count possibilities, consider arrangements, and apply principles of probability if needed."
        )

        # Execute parallel approaches
        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and synthesize the results
        ensemble_instruction = (
            "Evaluate the following solution approaches and select the most promising one. "
            "Consider correctness, elegance, and computational feasibility. If possible, synthesize insights "
            "from multiple approaches to produce a superior solution."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 4: Refine the selected solution
        refinement_instruction = (
            "Critique the following solution for correctness, clarity, and adherence to all problem constraints. "
            "Revise it to ensure it is mathematically rigorous and well-presented."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the following solution into a concise, clear format that highlights the key steps "
            "and the final answer."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_summary