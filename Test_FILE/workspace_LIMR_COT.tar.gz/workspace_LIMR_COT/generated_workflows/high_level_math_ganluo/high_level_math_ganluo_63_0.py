# Workflow ID: high_level_math_ganluo_63_0
# Benchmark: high_level_math_ganluo
# Data Indices: [468, 753]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information and understand the problem
        extraction = await self.generate(
            instruction="Extract all numerical values, variables, constraints, and the specific question being asked. "
                        "Identify the mathematical domain (e.g., geometry, algebra, combinatorics).",
            context=self.problem_text
        )

        # Step 2: Generate multiple solution strategies in parallel
        strategies = await asyncio.gather(
            self.generate(
                instruction=f"Based on the extracted information: {extraction}, "
                            "develop an algebraic solution strategy. Include step-by-step reasoning.",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"Based on the extracted information: {extraction}, "
                            "develop a geometric solution strategy. Include step-by-step reasoning.",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"Based on the extracted information: {extraction}, "
                            "develop a combinatorial or number-theoretic solution strategy. Include step-by-step reasoning.",
                context=self.problem_text
            )
        )

        # Step 3: Refine each solution strategy
        refined_strategies = await asyncio.gather(
            *[self.revise(
                instruction="Critique and improve this solution strategy. Ensure all constraints are satisfied, "
                            "and the reasoning is mathematically rigorous.",
                context=strategy
            ) for strategy in strategies]
        )

        # Step 4: Select the best solution using Ensemble
        best_solution = await self.ensemble(
            instruction="Evaluate these solution strategies. Select the most complete, efficient, and mathematically sound approach.",
            contexts=refined_strategies
        )

        # Step 5: Summarize the final answer
        final_answer = await self.summarize(
            instruction="Condense this solution into a clear and concise final answer. Box the result.",
            context=best_solution
        )

        return final_answer