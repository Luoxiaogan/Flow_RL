# Workflow ID: high_level_math_ganluo_276_0
# Benchmark: high_level_math_ganluo
# Data Indices: [693, 961]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key details and understand the problem
        extraction_instruction = (
            "Extract all numerical values, variables, constraints, and relationships from the problem. "
            "Identify the mathematical domain (e.g., geometry, number theory) and any specific techniques required."
        )
        extracted_details = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution paths
        generate_instruction = (
            f"Based on the extracted details: {extracted_details}, generate at least two distinct solution approaches. "
            "Include algebraic, geometric, or combinatorial reasoning as appropriate. Ensure all constraints are addressed."
        )
        solution_paths = await asyncio.gather(
            self.generate(instruction=generate_instruction, context=self.problem_text),
            self.generate(instruction=generate_instruction, context=self.problem_text)
        )

        # Step 3: Refine each solution path
        refine_instruction = (
            "Critique and refine the given solution approach. Ensure all constraints are satisfied, "
            "and the reasoning is mathematically rigorous. Address any ambiguities or missing steps."
        )
        refined_solutions = await asyncio.gather(
            self.revise(instruction=refine_instruction, context=solution_paths[0]),
            self.revise(instruction=refine_instruction, context=solution_paths[1])
        )

        # Step 4: Summarize refined solutions
        summarize_instruction = (
            "Condense the refined solution into a concise summary. Highlight key insights, results, "
            "and how the solution satisfies all problem constraints."
        )
        summarized_solutions = await asyncio.gather(
            self.summarize(instruction=summarize_instruction, context=refined_solutions[0]),
            self.summarize(instruction=summarize_instruction, context=refined_solutions[1])
        )

        # Step 5: Ensemble to select the best solution
        ensemble_instruction = (
            "Compare the summarized solutions and determine the most robust and accurate one. "
            "Consider edge cases, clarity of reasoning, and adherence to constraints."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=summarized_solutions)

        return final_solution