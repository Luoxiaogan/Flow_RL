# Workflow ID: high_level_math_ganluo_305_0
# Benchmark: high_level_math_ganluo
# Data Indices: [517, 401]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Carefully analyze the problem statement and extract all relevant information, "
            "including variables, constants, constraints, and the specific question being asked. "
            "Format the output as a structured summary."
        )
        key_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        approach_1_instruction = (
            f"Based on the extracted information: {key_info}\n"
            "Develop a solution using an algebraic or analytical approach. "
            "Provide step-by-step reasoning and ensure all constraints are satisfied."
        )
        approach_2_instruction = (
            f"Based on the extracted information: {key_info}\n"
            "Develop a solution using a geometric or combinatorial approach. "
            "Provide step-by-step reasoning and ensure all constraints are satisfied."
        )
        candidate_solutions = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and select the best approach
        evaluation_instruction = (
            "Compare the following candidate solutions and select the one that is most correct, "
            "clear, and adheres to the problem constraints. Provide a brief justification for your choice."
        )
        best_solution = await self.ensemble(instruction=evaluation_instruction, contexts=candidate_solutions)

        # Step 4: Refine the selected solution
        refinement_instruction = (
            "Review the selected solution for mathematical correctness, logical consistency, and clarity. "
            "Make improvements where necessary and ensure all steps are well-explained."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the refined solution into a concise and clear summary. "
            "Include the final answer and any key insights or results."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_summary