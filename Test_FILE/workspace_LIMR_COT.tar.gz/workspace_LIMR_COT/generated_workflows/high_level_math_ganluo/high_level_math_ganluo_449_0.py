# Workflow ID: high_level_math_ganluo_449_0
# Benchmark: high_level_math_ganluo
# Data Indices: [872, 112]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all key information from the problem, including variables, constants, "
            "constraints, relationships, and any implicit conditions. Organize the information "
            "in a structured format for further analysis."
        )
        key_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        approach_instructions = [
            f"Develop an algebraic solution approach for the problem. Use the extracted information: {key_info}.",
            f"Develop a combinatorial or probabilistic solution approach for the problem. Use the extracted information: {key_info}.",
            f"Develop a geometric or trigonometric solution approach for the problem. Use the extracted information: {key_info}."
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Evaluate and select the best approach
        ensemble_instruction = (
            "Evaluate the provided solution approaches based on correctness, simplicity, and computational feasibility. "
            "Select the most appropriate approach and provide a justification for your choice."
        )
        best_approach = await self.ensemble(instruction=ensemble_instruction, contexts=approaches)

        # Step 4: Refine the selected approach
        refine_instruction = (
            "Refine the selected solution approach to ensure it is mathematically rigorous, satisfies all constraints, "
            "and handles edge cases. Verify the solution step-by-step and make any necessary corrections."
        )
        refined_solution = await self.revise(instruction=refine_instruction, context=best_approach)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Summarize the refined solution in a concise and clear format. Include the final answer and any key insights."
        )
        final_output = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_output