# Workflow ID: high_level_math_ganluo_146_0
# Benchmark: high_level_math_ganluo
# Data Indices: [918, 864]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key components and understand the problem
        extraction_instruction = (
            "Analyze the problem thoroughly. Identify all variables, constants, equations, "
            "constraints, and any hidden patterns or structures. Provide a detailed breakdown "
            "of the problem's requirements and mathematical domain."
        )
        extraction = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        algebra_instruction = (
            f"Using the extracted information: {extraction}, solve the problem using algebraic methods. "
            "Include all steps, transformations, and reasoning. Ensure the solution satisfies all constraints."
        )
        combinatorics_instruction = (
            f"Using the extracted information: {extraction}, solve the problem using combinatorial methods. "
            "Include all steps, counting principles, and reasoning. Ensure the solution satisfies all constraints."
        )
        geometry_instruction = (
            f"Using the extracted information: {extraction}, solve the problem using geometric methods. "
            "Include all steps, diagrams (if applicable), and reasoning. Ensure the solution satisfies all constraints."
        )

        results = await asyncio.gather(
            self.generate(instruction=algebra_instruction, context=self.problem_text),
            self.generate(instruction=combinatorics_instruction, context=self.problem_text),
            self.generate(instruction=geometry_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and synthesize the best approach
        ensemble_instruction = (
            "Compare the provided solutions. Select the most rigorous, efficient, and correct approach. "
            "Ensure the chosen solution satisfies all problem constraints and provides clear reasoning."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 4: Refine the chosen solution
        refine_instruction = (
            "Critically review the solution. Improve clarity, correctness, and rigor. "
            "Verify that all steps are mathematically sound and satisfy the problem's requirements."
        )
        refined_solution = await self.revise(instruction=refine_instruction, context=best_solution)

        # Step 5: Final verification
        verification_instruction = (
            "Verify the solution against the original problem. Ensure it satisfies all constraints, "
            "is mathematically valid, and addresses the question completely."
        )
        final_solution = await self.revise(instruction=verification_instruction, context=refined_solution)

        return final_solution