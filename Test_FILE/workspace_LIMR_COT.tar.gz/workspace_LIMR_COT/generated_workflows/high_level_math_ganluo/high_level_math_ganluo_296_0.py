# Workflow ID: high_level_math_ganluo_296_0
# Benchmark: high_level_math_ganluo
# Data Indices: [597, 508]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all key information from the problem statement, including variables, constraints, "
            "and the target objective. Format the output as a structured summary with clear labels."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution paths in parallel
        # Define instructions for different solution approaches
        algebraic_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Solve the problem using algebraic methods. Include step-by-step reasoning, intermediate results, "
            "and ensure all constraints are satisfied."
        )
        geometric_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Solve the problem using geometric reasoning. Include diagrams (if applicable), relationships between "
            "geometric elements, and calculations."
        )
        combinatorial_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Solve the problem using combinatorial or probabilistic methods. Include counting principles, "
            "recursive formulas, or generating functions as needed."
        )

        # Execute solution paths in parallel
        solution_paths = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and synthesize the best solution
        ensemble_instruction = (
            "Compare the provided candidate solutions and select the most rigorous, accurate, and complete one. "
            "Ensure the chosen solution satisfies all constraints and provides a clear explanation."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=solution_paths)

        # Step 4: Verify and refine the final solution
        verification_instruction = (
            "Verify the correctness of the solution by checking all constraints and conditions. "
            "Refine the solution if necessary to address any gaps or ambiguities."
        )
        refined_solution = await self.revise(instruction=verification_instruction, context=final_solution)

        return refined_solution