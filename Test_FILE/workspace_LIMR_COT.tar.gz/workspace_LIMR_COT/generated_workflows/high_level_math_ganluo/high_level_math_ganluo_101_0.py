# Workflow ID: high_level_math_ganluo_101_0
# Benchmark: high_level_math_ganluo
# Data Indices: [176, 467]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract and Understand the Problem
        extraction_instruction = (
            "Extract all key components of the problem, including numerical values, variables, "
            "constraints, and the objective. Organize them into clear categories such as 'Given', "
            "'Find', and 'Constraints'. Ensure no information is omitted."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate Two Distinct Approaches in Parallel
        approach_1_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Develop a solution approach focusing on algebraic or analytical methods. "
            "Provide step-by-step reasoning, ensuring all constraints are addressed."
        )
        approach_2_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Develop a solution approach focusing on geometric, combinatorial, or number-theoretic methods. "
            "Provide step-by-step reasoning, ensuring all constraints are addressed."
        )
        approach_1, approach_2 = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text)
        )

        # Step 3: Refine Both Approaches
        refine_instruction_1 = (
            "Critically review the following solution approach. Identify and correct any logical errors, "
            "ensure all constraints are satisfied, and simplify expressions where possible. "
            "Provide the revised solution with clear justification."
        )
        refine_instruction_2 = (
            "Critically review the following solution approach. Identify and correct any logical errors, "
            "ensure all constraints are satisfied, and simplify expressions where possible. "
            "Provide the revised solution with clear justification."
        )
        refined_approach_1, refined_approach_2 = await asyncio.gather(
            self.revise(instruction=refine_instruction_1, context=approach_1),
            self.revise(instruction=refine_instruction_2, context=approach_2)
        )

        # Step 4: Ensemble Decision to Select the Best Approach
        ensemble_instruction = (
            "Evaluate the two refined approaches. Select the most rigorous, elegant, and efficient solution. "
            "If neither approach is satisfactory, synthesize a hybrid solution or identify gaps requiring further exploration."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=[refined_approach_1, refined_approach_2])

        # Step 5: Summarize the Final Solution
        summary_instruction = (
            "Summarize the final solution concisely while preserving all key steps and the final answer. "
            "Ensure the summary is clear and interpretable."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=final_solution)

        return final_summary