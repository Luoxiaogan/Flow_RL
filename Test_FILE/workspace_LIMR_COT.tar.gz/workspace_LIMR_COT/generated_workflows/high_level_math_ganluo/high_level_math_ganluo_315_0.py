# Workflow ID: high_level_math_ganluo_315_0
# Benchmark: high_level_math_ganluo
# Data Indices: [793, 741]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all key information from the problem, including variables, constants, "
            "constraints, and relationships. Identify the mathematical domain (e.g., algebra, "
            "geometry, number theory) and any specific techniques that might be applicable."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution strategies
        strategy_instruction = (
            f"Based on the following extracted information: {extracted_info}\n"
            "Formulate multiple potential solution strategies. Consider different mathematical "
            "approaches such as algebraic manipulation, geometric reasoning, combinatorial analysis, "
            "or number-theoretic techniques. Ensure each strategy is detailed and actionable."
        )
        strategies = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Execute strategies in parallel
        strategies_list = strategies.split("\n\n")  # Assuming strategies are separated by double newlines
        parallel_tasks = [
            self.generate(
                instruction=f"Execute the following strategy step-by-step: {strategy}",
                context=self.problem_text
            )
            for strategy in strategies_list
        ]
        results = await asyncio.gather(*parallel_tasks)

        # Step 4: Evaluate and select the best strategy
        evaluation_instruction = (
            "Compare the following candidate solutions and select the best one. "
            "Criteria for selection include correctness, simplicity, and computational feasibility. "
            "If multiple solutions are valid, choose the most elegant or efficient one."
        )
        best_solution = await self.ensemble(instruction=evaluation_instruction, contexts=results)

        # Step 5: Refine the selected solution
        refinement_instruction = (
            "Refine the following solution to ensure it is mathematically rigorous, satisfies all "
            "constraints, and is presented clearly and concisely. Critique and improve any weak points."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 6: Summarize the final solution
        summary_instruction = (
            "Summarize the following solution in a concise yet complete manner. Ensure all key steps "
            "and the final answer are included."
        )
        final_output = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_output