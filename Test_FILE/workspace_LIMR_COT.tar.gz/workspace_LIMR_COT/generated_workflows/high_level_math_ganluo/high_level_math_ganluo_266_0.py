# Workflow ID: high_level_math_ganluo_266_0
# Benchmark: high_level_math_ganluo
# Data Indices: [751, 219]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Problem Decomposition
        extraction_instruction = (
            "Extract all key components from the problem, including equations, variables, "
            "constraints, and any implicit assumptions. Identify the domain (e.g., algebra, "
            "geometry, combinatorics) and note any special techniques required (e.g., symmetry, "
            "modular arithmetic)."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate Multiple Solution Approaches
        generate_instruction_template = (
            "Given the extracted information: {info}, propose a detailed solution approach. "
            "Include all reasoning steps, intermediate calculations, and ensure alignment with the "
            "problem constraints. Consider using techniques like casework analysis, recursion, "
            "or symmetry where applicable."
        )
        instructions = [
            generate_instruction_template.format(info=extracted_info),
            generate_instruction_template.format(info=extracted_info) + " Focus on an algebraic approach.",
            generate_instruction_template.format(info=extracted_info) + " Focus on a geometric interpretation."
        ]
        solutions = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in instructions]
        )

        # Step 3: Refine Solutions
        refine_instruction = (
            "Critically review the following solution. Check for mathematical correctness, logical "
            "consistency, and alignment with the problem constraints. Suggest improvements if needed."
        )
        refined_solutions = await asyncio.gather(
            *[self.revise(instruction=refine_instruction, context=sol) for sol in solutions]
        )

        # Step 4: Final Synthesis
        ensemble_instruction = (
            "Compare the following candidate solutions. Select the most rigorous, elegant, and "
            "correct solution. If multiple solutions are valid, synthesize them into a single coherent answer."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_solutions)

        # Step 5: Summarize the Final Answer
        summarize_instruction = (
            "Condense the following solution into a concise, clear, and verifiable final answer. "
            "Ensure all key steps and reasoning are preserved."
        )
        summary = await self.summarize(instruction=summarize_instruction, context=final_solution)

        return summary