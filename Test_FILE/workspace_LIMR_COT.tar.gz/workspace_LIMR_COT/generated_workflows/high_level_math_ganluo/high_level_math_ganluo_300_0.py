# Workflow ID: high_level_math_ganluo_300_0
# Benchmark: high_level_math_ganluo
# Data Indices: [160, 371]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Problem Decomposition
        decomposition_instruction = (
            "Extract all numerical values, variables, and constraints from the problem. "
            "Identify the type of problem (e.g., algebraic, geometric, combinatorial) and the required techniques. "
            "Provide a structured breakdown of the problem components."
        )
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Generate Multiple Solution Paths
        approaches = [
            "Use algebraic manipulation and equations to solve the problem.",
            "Apply geometric reasoning or coordinate geometry techniques.",
            "Employ combinatorial analysis or probabilistic methods.",
            "Utilize number theory principles such as modular arithmetic or divisibility."
        ]
        tasks = [
            self.generate(
                instruction=f"Based on the problem decomposition: {decomposition}\n"
                            f"Solve the problem using the following approach: {approach}",
                context=self.problem_text
            ) for approach in approaches
        ]
        solutions = await asyncio.gather(*tasks)

        # Step 3: Refine Each Solution Path
        refinement_tasks = [
            self.revise(
                instruction="Critically evaluate this solution. Check for logical consistency, completeness, "
                            "and adherence to all constraints. Address any gaps or errors.",
                context=solution
            ) for solution in solutions
        ]
        refined_solutions = await asyncio.gather(*refinement_tasks)

        # Step 4: Synthesize Results
        synthesis_instruction = (
            "Compare the refined solutions provided. Select the most robust, accurate, and complete solution. "
            "If multiple solutions are valid, combine their insights into a single cohesive answer."
        )
        final_solution = await self.ensemble(instruction=synthesis_instruction, contexts=refined_solutions)

        # Step 5: Final Answer Extraction
        summary_instruction = (
            "Extract the final answer from the synthesized solution. Ensure the answer is concise, clear, "
            "and directly addresses the problem."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=final_solution)

        return final_answer