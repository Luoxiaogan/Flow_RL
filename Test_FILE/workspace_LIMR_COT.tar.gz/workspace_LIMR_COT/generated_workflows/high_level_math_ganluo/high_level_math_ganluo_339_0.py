# Workflow ID: high_level_math_ganluo_339_0
# Benchmark: high_level_math_ganluo
# Data Indices: [359, 231]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information and decompose the problem
        decomposition_instruction = (
            "Analyze the problem thoroughly. Identify the mathematical domain (e.g., algebra, geometry), "
            "key variables, constraints, and what is being asked. Provide a structured breakdown."
        )
        problem_decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Formulate multiple solution strategies
        strategy_instruction = (
            f"Based on the following problem breakdown:\n{problem_decomposition}\n"
            "Propose multiple solution strategies. Consider algebraic, geometric, combinatorial, and number-theoretic approaches. "
            "For each strategy, outline the steps required and justify its applicability."
        )
        strategies = await self.generate(instruction=strategy_instruction, context=self.problem_text)

        # Step 3: Explore strategies in parallel
        strategy_list = strategies.split("\n\n")  # Assume strategies are separated by double newlines
        parallel_tasks = [
            self.generate(
                instruction=f"Execute the following strategy step-by-step:\n{strategy}",
                context=self.problem_text
            )
            for strategy in strategy_list
        ]
        candidate_solutions = await asyncio.gather(*parallel_tasks)

        # Step 4: Evaluate and select the best solution
        evaluation_instruction = (
            "Compare the following candidate solutions and select the most rigorous, feasible, and complete one. "
            "Provide justification for your choice."
        )
        best_solution = await self.ensemble(instruction=evaluation_instruction, contexts=candidate_solutions)

        # Step 5: Refine the selected solution
        refinement_instruction = (
            "Review the following solution for clarity, correctness, and completeness. "
            "Make improvements if necessary, ensuring all problem constraints are satisfied."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 6: Summarize the final solution
        summary_instruction = (
            "Condense the following solution into a clear and concise format. "
            "Include only the essential reasoning and final answer."
        )
        final_output = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_output