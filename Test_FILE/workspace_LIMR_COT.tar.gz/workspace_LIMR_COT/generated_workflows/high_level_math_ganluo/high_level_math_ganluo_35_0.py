# Workflow ID: high_level_math_ganluo_35_0
# Benchmark: high_level_math_ganluo
# Data Indices: [17, 689]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key components and identify solution paths
        extraction_instruction = (
            "Analyze the problem to extract all key components, including variables, constants, constraints, "
            "and the goal. Identify potential solution paths (e.g., algebraic, geometric, combinatorial) based "
            "on the problem's structure."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Explore multiple solution paths in parallel
        algebraic_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem algebraically. "
            "Include step-by-step reasoning and intermediate results."
        )
        geometric_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem geometrically. "
            "Include visual reasoning and any necessary calculations."
        )
        number_theory_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using number theory. "
            "Focus on modular arithmetic, divisibility, or other relevant techniques."
        )

        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=number_theory_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and synthesize the best solution
        ensemble_instruction = (
            "Compare the following candidate solutions and select the most accurate and complete one. "
            "If multiple approaches are valid, synthesize them into a unified solution. "
            "Ensure the final result satisfies all constraints and aligns with the problem's goal."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 4: Refine and validate the solution
        refinement_instruction = (
            "Critically review the solution for correctness, clarity, and completeness. "
            "Address any gaps, inconsistencies, or ambiguities. Ensure the solution adheres to the problem's requirements."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the final answer
        summary_instruction = (
            "Condense the solution into a concise, verifiable form. Include only the final answer and key steps. "
            "Ensure the result is presented in a format that directly addresses the problem's question."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer