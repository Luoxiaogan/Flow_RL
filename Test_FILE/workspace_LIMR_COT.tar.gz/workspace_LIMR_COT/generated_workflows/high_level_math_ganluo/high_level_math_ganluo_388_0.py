# Workflow ID: high_level_math_ganluo_388_0
# Benchmark: high_level_math_ganluo
# Data Indices: [361, 736]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Problem Understanding and Decomposition
        problem_analysis = await self.generate(
            instruction="Thoroughly analyze the problem. Identify all variables, constraints, and objectives. "
                        "Break the problem into smaller sub-problems if possible. Provide a structured summary.",
            context=self.problem_text
        )

        # Step 2: Parallel Exploration of Multiple Approaches
        algebraic_approach = self.generate(
            instruction=f"Using an algebraic approach, solve the problem step by step. "
                        f"Ensure all constraints are satisfied. Problem analysis: {problem_analysis}",
            context=self.problem_text
        )
        geometric_approach = self.generate(
            instruction=f"Using a geometric approach, solve the problem step by step. "
                        f"Ensure all constraints are satisfied. Problem analysis: {problem_analysis}",
            context=self.problem_text
        )
        combinatorial_approach = self.generate(
            instruction=f"Using a combinatorial approach, solve the problem step by step. "
                        f"Ensure all constraints are satisfied. Problem analysis: {problem_analysis}",
            context=self.problem_text
        )

        # Execute approaches in parallel
        results = await asyncio.gather(algebraic_approach, geometric_approach, combinatorial_approach)

        # Step 3: Refinement and Critique
        refined_results = await asyncio.gather(
            *[self.revise(
                instruction=f"Critically evaluate and refine this solution. Ensure it is mathematically sound, "
                            f"addresses all constraints, and is expressed in its simplest form. "
                            f"Check for edge cases and verify correctness.",
                context=result
            ) for result in results]
        )

        # Step 4: Ensemble Decision-Making
        final_solution = await self.ensemble(
            instruction="Evaluate the provided solutions. Select the most robust, elegant, and correct solution. "
                        "If multiple solutions are valid, synthesize a final answer that combines their strengths.",
            contexts=refined_results
        )

        # Step 5: Final Answer Extraction
        final_answer = await self.summarize(
            instruction="Extract the final answer from the solution. Ensure it is concise, clear, and in the required format.",
            context=final_solution
        )

        return final_answer