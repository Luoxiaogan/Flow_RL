# Workflow ID: high_level_math_ganluo_304_0
# Benchmark: high_level_math_ganluo
# Data Indices: [128, 921]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract all relevant information from the problem text
        extraction_instruction = (
            "Extract all numerical values, relationships, constraints, and key mathematical concepts "
            "from the problem statement. Organize them clearly for use in subsequent steps."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple candidate solutions in parallel
        algebraic_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Solve the problem using algebraic methods. Include all steps and reasoning."
        )
        geometric_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Solve the problem using geometric reasoning. Include all steps and reasoning."
        )
        combinatorial_instruction = (
            f"Using the extracted information: {extracted_info}\n"
            "Solve the problem using combinatorial or probabilistic methods. Include all steps and reasoning."
        )

        # Execute solution generation in parallel
        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Refine each candidate solution
        refined_results = await asyncio.gather(
            self.revise(instruction="Critique and refine this solution for accuracy, completeness, and clarity.", context=results[0]),
            self.revise(instruction="Critique and refine this solution for accuracy, completeness, and clarity.", context=results[1]),
            self.revise(instruction="Critique and refine this solution for accuracy, completeness, and clarity.", context=results[2])
        )

        # Step 4: Summarize each refined solution
        summarized_results = await asyncio.gather(
            self.summarize(instruction="Condense this solution into a concise summary while preserving key reasoning and results.", context=refined_results[0]),
            self.summarize(instruction="Condense this solution into a concise summary while preserving key reasoning and results.", context=refined_results[1]),
            self.summarize(instruction="Condense this solution into a concise summary while preserving key reasoning and results.", context=refined_results[2])
        )

        # Step 5: Synthesize the best solution using Ensemble
        ensemble_instruction = (
            "Evaluate these candidate solutions based on correctness, completeness, and adherence to problem constraints. "
            "Select the best solution or synthesize a new one if necessary."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=summarized_results)

        # Step 6: Format the final output
        formatting_instruction = (
            "Ensure the final solution is presented in the required format (e.g., decimal to the nearest tenth). "
            "Include all necessary units and explanations."
        )
        final_output = await self.revise(instruction=formatting_instruction, context=final_solution)

        return final_output