# Workflow ID: high_level_math_ganluo_403_0
# Benchmark: high_level_math_ganluo
# Data Indices: [155, 142]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Understand and decompose the problem
        extraction_instruction = (
            "Carefully analyze the problem and extract all key components, including numerical values, variables, "
            "constraints, relationships, and any specific conditions. Organize this information clearly."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Explore multiple solution approaches in parallel
        algebraic_instruction = (
            f"Based on the extracted information: {extracted_info}, solve the problem using algebraic techniques. "
            "Include all steps, transformations, and reasoning explicitly."
        )
        geometric_instruction = (
            f"Based on the extracted information: {extracted_info}, solve the problem using geometric reasoning. "
            "Include diagrams (if applicable), relationships, and step-by-step calculations."
        )
        combinatorial_instruction = (
            f"Based on the extracted information: {extracted_info}, solve the problem using combinatorial methods. "
            "Include counting principles, recursive structures, or generating functions as needed."
        )
        number_theory_instruction = (
            f"Based on the extracted information: {extracted_info}, solve the problem using number-theoretic techniques. "
            "Include divisibility, modular arithmetic, or prime factorization as appropriate."
        )

        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text),
            self.generate(instruction=number_theory_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and select the best approach
        ensemble_instruction = (
            "Evaluate the provided candidate solutions and select the most effective and elegant approach. "
            "Consider correctness, simplicity, and adherence to problem constraints."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=results)

        # Step 4: Refine the selected solution
        refinement_instruction = (
            "Critically review and refine the provided solution. Ensure all steps are clear, logical, and correct. "
            "Address any gaps or ambiguities, and verify that the solution satisfies all problem constraints."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the solution into a concise and clear format. Include only the essential steps and final answer."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_summary