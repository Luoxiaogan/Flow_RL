# Workflow ID: high_level_math_ganluo_56_0
# Benchmark: high_level_math_ganluo
# Data Indices: [747, 900]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key components and problem type
        extract_instruction = (
            "Analyze the problem and extract key components such as numerical values, variables, and relationships. "
            "Identify the mathematical domain (e.g., combinatorics, number theory, geometry) and any specific techniques "
            "that might be relevant (e.g., modular arithmetic, symmetry exploitation)."
        )
        key_components = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        generate_instruction = (
            f"Based on the extracted components: {key_components}, generate multiple distinct approaches to solve the problem. "
            "Consider different mathematical techniques and perspectives. For each approach, provide a detailed step-by-step plan."
        )
        approaches = await asyncio.gather(
            self.generate(instruction=generate_instruction, context=self.problem_text),
            self.generate(instruction=generate_instruction, context=self.problem_text),
            self.generate(instruction=generate_instruction, context=self.problem_text)
        )

        # Step 3: Refine and validate each approach
        refine_instruction = (
            "Critique and refine the provided solution approach. Ensure it is mathematically rigorous, satisfies all constraints, "
            "and handles edge cases. Provide detailed feedback and improvements where necessary."
        )
        refined_approaches = await asyncio.gather(
            *[self.revise(instruction=refine_instruction, context=approach) for approach in approaches]
        )

        # Step 4: Ensemble decision-making
        ensemble_instruction = (
            "Evaluate the refined solution approaches and select the best one. Consider factors such as simplicity, correctness, "
            "and alignment with the problem's requirements. Provide a justification for your choice."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_approaches)

        # Step 5: Summarize the final solution
        summarize_instruction = (
            "Condense the chosen solution into a concise, well-structured format. Include all critical steps and insights "
            "while ensuring clarity and readability."
        )
        final_solution = await self.summarize(instruction=summarize_instruction, context=best_solution)

        return final_solution