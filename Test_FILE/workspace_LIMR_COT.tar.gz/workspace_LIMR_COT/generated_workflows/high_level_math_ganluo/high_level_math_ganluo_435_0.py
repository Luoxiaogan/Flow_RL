# Workflow ID: high_level_math_ganluo_435_0
# Benchmark: high_level_math_ganluo
# Data Indices: [154, 2]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information and decompose the problem
        extraction_instruction = (
            "Carefully analyze the problem statement to identify all key components, including variables, "
            "constraints, and the type of mathematical domain (e.g., combinatorics, algebra, geometry). "
            "Provide a structured breakdown of the problem."
        )
        problem_breakdown = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        algebraic_instruction = (
            f"Based on the problem breakdown: {problem_breakdown}\n"
            "Solve the problem using algebraic techniques. Include all steps and verify intermediate results."
        )
        combinatorial_instruction = (
            f"Based on the problem breakdown: {problem_breakdown}\n"
            "Solve the problem using combinatorial or probabilistic reasoning. Include all steps and verify intermediate results."
        )
        algebraic_solution, combinatorial_solution = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Validate and refine each solution
        refine_instruction = (
            "Critically evaluate the provided solution. Identify any errors, omissions, or areas for improvement. "
            "Refine the solution to ensure it is mathematically sound and satisfies all problem constraints."
        )
        refined_algebraic = await self.revise(instruction=refine_instruction, context=algebraic_solution)
        refined_combinatorial = await self.revise(instruction=refine_instruction, context=combinatorial_solution)

        # Step 4: Compare and select the best solution
        ensemble_instruction = (
            "Compare the following two solutions and select the most accurate, elegant, or efficient one. "
            "If both have merit, synthesize them into a hybrid solution.\n\n"
            f"Solution 1 (Algebraic): {refined_algebraic}\n\n"
            f"Solution 2 (Combinatorial): {refined_combinatorial}"
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=[refined_algebraic, refined_combinatorial])

        # Step 5: Summarize the final answer
        summarize_instruction = (
            "Condense the solution into a clear and concise final answer. Ensure the answer explicitly "
            "addresses the problem question and verifies it against all constraints."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=best_solution)

        return final_answer