# Workflow ID: high_level_math_ganluo_69_0
# Benchmark: high_level_math_ganluo
# Data Indices: [404, 595]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract and Understand the Problem
        extraction_instruction = (
            "Thoroughly analyze the problem statement. Identify all numerical values, variables, "
            "constraints, and relationships. Highlight any special conditions or edge cases. "
            "Provide a structured summary of the problem's key components."
        )
        problem_summary = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Explore Multiple Solution Paths in Parallel
        algebraic_instruction = (
            f"Using the following problem summary: {problem_summary}\n"
            "Solve the problem using algebraic methods. Clearly show all steps, transformations, "
            "and reasoning. Ensure the solution satisfies all constraints and conditions."
        )
        geometric_instruction = (
            f"Using the following problem summary: {problem_summary}\n"
            "Solve the problem using geometric methods. Clearly show all constructions, theorems, "
            "and reasoning. Ensure the solution satisfies all constraints and conditions."
        )
        combinatorial_instruction = (
            f"Using the following problem summary: {problem_summary}\n"
            "Solve the problem using combinatorial methods. Clearly show all counting principles, "
            "cases, and reasoning. Ensure the solution satisfies all constraints and conditions."
        )

        # Execute three independent solution paths in parallel
        algebraic_solution, geometric_solution, combinatorial_solution = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Refine Each Solution
        refinement_instruction = (
            "Critique and refine the provided solution. Check for mathematical correctness, "
            "logical consistency, and adherence to the problem's constraints. Improve clarity "
            "and rigor where necessary."
        )
        refined_algebraic = await self.revise(instruction=refinement_instruction, context=algebraic_solution)
        refined_geometric = await self.revise(instruction=refinement_instruction, context=geometric_solution)
        refined_combinatorial = await self.revise(instruction=refinement_instruction, context=combinatorial_solution)

        # Step 4: Ensemble Decision-Making
        ensemble_instruction = (
            "Evaluate the following solutions: Algebraic, Geometric, and Combinatorial. "
            "Compare their correctness, elegance, and adherence to the problem's constraints. "
            "Select the best solution or synthesize them into a unified answer if appropriate."
        )
        final_solution = await self.ensemble(
            instruction=ensemble_instruction,
            contexts=[refined_algebraic, refined_geometric, refined_combinatorial]
        )

        # Step 5: Summarize the Final Answer
        summarization_instruction = (
            "Condense the final solution into a clear and concise format. Include only the key "
            "steps, results, and final answer. Ensure it is easy to understand and verify."
        )
        summary = await self.summarize(instruction=summarization_instruction, context=final_solution)

        return summary