# Workflow ID: high_level_math_ganluo_22_0
# Benchmark: high_level_math_ganluo
# Data Indices: [801, 283]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extract_instruction = (
            "Extract all key information from the problem, including variables, equations, constraints, "
            "and relationships. Organize the information clearly and concisely."
        )
        extracted_info = await self.generate(instruction=extract_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        algebra_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using algebraic manipulation. "
            "Provide step-by-step reasoning and calculations."
        )
        geometry_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using geometric reasoning. "
            "Provide step-by-step reasoning and calculations."
        )
        number_theory_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using number-theoretic techniques. "
            "Provide step-by-step reasoning and calculations."
        )

        approaches = await asyncio.gather(
            self.generate(instruction=algebra_instruction, context=self.problem_text),
            self.generate(instruction=geometry_instruction, context=self.problem_text),
            self.generate(instruction=number_theory_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and select the best solution path
        ensemble_instruction = (
            "Evaluate the following solution approaches and select the most promising one. "
            "Consider correctness, clarity, and alignment with the problem constraints."
        )
        best_approach = await self.ensemble(instruction=ensemble_instruction, contexts=approaches)

        # Step 4: Refine the selected solution path
        refine_instruction = (
            f"Refine the following solution: {best_approach}. Ensure all steps are accurate, complete, "
            "and satisfy all problem constraints."
        )
        refined_solution = await self.revise(instruction=refine_instruction, context=best_approach)

        # Step 5: Verify the final solution
        verify_instruction = (
            f"Verify that the solution: {refined_solution} satisfies all constraints and conditions "
            "specified in the problem text. Provide a detailed verification process."
        )
        final_verification = await self.generate(instruction=verify_instruction, context=self.problem_text)

        return final_verification