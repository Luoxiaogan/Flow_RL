# Workflow ID: high_level_math_ganluo_422_0
# Benchmark: high_level_math_ganluo
# Data Indices: [928, 89]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract problem components (variables, constraints, question)
        extraction_instruction = (
            "Extract all key components of the problem, including variables, constraints, "
            "and the specific question being asked. Format the output clearly with headings "
            "for each component."
        )
        problem_components = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        approach_instruction = (
            f"Based on the following extracted problem components:\n{problem_components}\n"
            "Generate at least three distinct solution approaches. Each approach should be "
            "detailed, specifying the mathematical techniques or strategies to be used. "
            "Include any assumptions or simplifications explicitly."
        )
        approaches = await self.generate(instruction=approach_instruction, context=self.problem_text)

        # Step 3: Execute approaches in parallel
        approach_list = approaches.split("\n\n")  # Split into individual approaches
        tasks = [
            self.generate(
                instruction=f"Execute the following solution approach step by step:\n{approach}",
                context=self.problem_text
            )
            for approach in approach_list
        ]
        candidate_solutions = await asyncio.gather(*tasks)

        # Step 4: Evaluate and select the best solution
        evaluation_instruction = (
            "Evaluate the following candidate solutions and select the best one. "
            "Consider mathematical correctness, adherence to problem constraints, "
            "and clarity of reasoning. Provide a justification for your choice."
        )
        best_solution = await self.ensemble(instruction=evaluation_instruction, contexts=candidate_solutions)

        # Step 5: Refine the selected solution
        refinement_instruction = (
            "Critique and refine the following solution to ensure correctness, clarity, "
            "and completeness. Address any gaps in reasoning or calculations."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 6: Summarize the final answer
        summary_instruction = (
            "Condense the following solution into a concise, well-formatted answer. "
            "Ensure it directly addresses the problem's question and includes all necessary details."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer