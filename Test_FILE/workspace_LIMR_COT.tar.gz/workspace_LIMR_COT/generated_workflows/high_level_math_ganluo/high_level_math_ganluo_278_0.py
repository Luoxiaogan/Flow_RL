# Workflow ID: high_level_math_ganluo_278_0
# Benchmark: high_level_math_ganluo
# Data Indices: [191, 365]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all critical information from the problem, including variables, equations, constraints, "
            "and the specific question being asked. Present this information in a structured format."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        algebraic_approach_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using algebraic methods. "
            "Focus on equations, substitutions, and simplifications. Provide a step-by-step solution."
        )
        combinatorial_approach_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using combinatorial reasoning. "
            "Consider counting principles, permutations, combinations, and recursive structures. Provide a step-by-step solution."
        )
        geometric_approach_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using geometric reasoning. "
            "Consider coordinate geometry, area/volume calculations, and trigonometric relationships. Provide a step-by-step solution."
        )

        approaches = await asyncio.gather(
            self.generate(instruction=algebraic_approach_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_approach_instruction, context=self.problem_text),
            self.generate(instruction=geometric_approach_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and select the best approach
        ensemble_instruction = (
            "Evaluate the following candidate solutions and select the most robust, mathematically sound, "
            "and efficient approach. Ensure the chosen solution satisfies all constraints and aligns with the problem's requirements."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=approaches)

        # Step 4: Verify and refine the selected solution
        revise_instruction = (
            "Verify the correctness of the solution by checking for logical consistency, computational accuracy, "
            "and adherence to all constraints. Refine the solution if necessary, ensuring it is rigorous and complete."
        )
        refined_solution = await self.revise(instruction=revise_instruction, context=best_solution)

        # Step 5: Summarize the final solution
        summarize_instruction = (
            "Summarize the solution in a concise and clear format. Include all essential steps and results. "
            "Ensure the summary is easy to understand while preserving mathematical rigor."
        )
        final_summary = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_summary