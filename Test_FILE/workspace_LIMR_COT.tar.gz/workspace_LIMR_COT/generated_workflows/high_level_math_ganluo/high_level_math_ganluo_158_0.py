# Workflow ID: high_level_math_ganluo_158_0
# Benchmark: high_level_math_ganluo
# Data Indices: [463, 302]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all numerical values, variables, constraints, and relationships from the problem. "
            "Identify the mathematical domain (e.g., algebra, geometry, combinatorics) and any special techniques required. "
            "Format the extracted information clearly for further analysis."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Explore multiple solution paths in parallel
        algebraic_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "solve the problem using algebraic techniques. "
            "Include step-by-step reasoning, equations, and calculations. "
            "If applicable, consider substitutions, transformations, or simplifications."
        )
        geometric_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "solve the problem using geometric techniques. "
            "Include coordinate geometry, synthetic geometry, or trigonometric methods as appropriate. "
            "Provide clear diagrams or descriptions if needed."
        )
        combinatorial_instruction = (
            f"Using the extracted information: {extracted_info}, "
            "solve the problem using combinatorial or probabilistic techniques. "
            "Consider counting principles, recursive formulas, or generating functions. "
            "Explain your reasoning thoroughly."
        )

        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Refine each solution path
        refined_results = await asyncio.gather(
            self.revise(instruction="Critique and refine this algebraic solution. Address any logical gaps or calculation errors.", context=results[0]),
            self.revise(instruction="Critique and refine this geometric solution. Ensure all steps are clear and accurate.", context=results[1]),
            self.revise(instruction="Critique and refine this combinatorial solution. Verify all reasoning and calculations.", context=results[2])
        )

        # Step 4: Synthesize and select the best solution
        ensemble_instruction = (
            "Compare the following solutions: algebraic, geometric, and combinatorial. "
            "Select the most accurate, efficient, and elegant solution. "
            "Ensure the chosen solution satisfies all constraints and is mathematically sound."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_results)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the final solution into a concise, well-structured format. "
            "Include all key steps, final answers, and any necessary explanations. "
            "Ensure the output adheres to the problem's requirements."
        )
        summarized_solution = await self.summarize(instruction=summary_instruction, context=final_solution)

        return summarized_solution