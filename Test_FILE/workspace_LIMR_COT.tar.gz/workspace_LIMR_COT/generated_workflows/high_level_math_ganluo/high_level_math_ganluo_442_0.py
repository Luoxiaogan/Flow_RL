# Workflow ID: high_level_math_ganluo_442_0
# Benchmark: high_level_math_ganluo
# Data Indices: [206, 200]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all key information from the problem, including numerical values, variables, "
            "constraints, and the mathematical domain (e.g., algebra, geometry, combinatorics). "
            "Organize the information clearly for further analysis."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        approach_1_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using an algebraic approach. "
            "Include all steps, assumptions, and calculations."
        )
        approach_2_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using a combinatorial approach. "
            "Include all steps, assumptions, and calculations."
        )
        approach_3_instruction = (
            f"Using the extracted information: {extracted_info}, solve the problem using a geometric or visual approach. "
            "Include all steps, assumptions, and calculations."
        )

        results = await asyncio.gather(
            self.generate(instruction=approach_1_instruction, context=self.problem_text),
            self.generate(instruction=approach_2_instruction, context=self.problem_text),
            self.generate(instruction=approach_3_instruction, context=self.problem_text)
        )

        # Step 3: Refine the generated solutions
        refine_instruction = (
            "Critique and improve the provided solution. Ensure all constraints are satisfied, "
            "edge cases are considered, and calculations are correct. Provide a revised version."
        )
        refined_results = await asyncio.gather(
            self.revise(instruction=refine_instruction, context=results[0]),
            self.revise(instruction=refine_instruction, context=results[1]),
            self.revise(instruction=refine_instruction, context=results[2])
        )

        # Step 4: Select the best solution using ensemble
        ensemble_instruction = (
            "Evaluate the provided solutions. Select the most accurate, complete, and robust solution. "
            "If possible, synthesize the best elements from multiple solutions into a final answer."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_results)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Summarize the solution into a concise, well-structured answer. Include only the essential steps "
            "and the final result. Ensure clarity and correctness."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=final_solution)

        return final_answer