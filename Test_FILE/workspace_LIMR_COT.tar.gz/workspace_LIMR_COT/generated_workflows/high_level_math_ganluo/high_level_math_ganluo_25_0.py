# Workflow ID: high_level_math_ganluo_25_0
# Benchmark: high_level_math_ganluo
# Data Indices: [513, 88]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract critical information from the problem
        extraction_instruction = (
            "Carefully analyze the problem statement and extract all relevant information, "
            "including variables, equations, constraints, and objectives. "
            "Format the output as a structured summary."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        algebraic_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Develop an algebraic solution approach, focusing on equations, inequalities, and transformations. "
            "Provide step-by-step reasoning."
        )
        geometric_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Develop a geometric solution approach, focusing on visual representations, symmetries, and spatial relationships. "
            "Provide step-by-step reasoning."
        )
        combinatorial_instruction = (
            f"Based on the extracted information: {extracted_info}\n"
            "Develop a combinatorial solution approach, focusing on counting principles, recursion, and patterns. "
            "Provide step-by-step reasoning."
        )

        approaches = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Refine each approach
        refine_instructions = [
            "Critique and refine the following solution approach. Ensure all steps are logically sound, "
            "simplify expressions where possible, and verify adherence to problem constraints."
        ] * len(approaches)

        refined_approaches = await asyncio.gather(
            *[self.revise(instruction=refine_instructions[i], context=approaches[i]) for i in range(len(approaches))]
        )

        # Step 4: Ensemble decision to select or synthesize the best approach
        ensemble_instruction = (
            "Evaluate the following refined solution approaches and select the most robust and efficient one. "
            "If multiple approaches complement each other, synthesize them into a unified solution."
        )
        final_approach = await self.ensemble(instruction=ensemble_instruction, contexts=refined_approaches)

        # Step 5: Compute the final solution
        solution_instruction = (
            f"Using the selected approach: {final_approach}\n"
            "Compute the final solution step by step, ensuring all calculations are accurate and consistent with the problem constraints. "
            "Format the final answer clearly."
        )
        final_solution = await self.generate(instruction=solution_instruction, context=self.problem_text)

        # Optional: Summarize the solution
        summary_instruction = (
            "Condense the final solution into a concise format suitable for submission. "
            "Include only the essential steps and the final answer."
        )
        summarized_solution = await self.summarize(instruction=summary_instruction, context=final_solution)

        return summarized_solution