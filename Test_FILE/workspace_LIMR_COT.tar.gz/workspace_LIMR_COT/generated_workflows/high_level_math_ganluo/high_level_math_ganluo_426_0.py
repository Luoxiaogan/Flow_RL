# Workflow ID: high_level_math_ganluo_426_0
# Benchmark: high_level_math_ganluo
# Data Indices: [103, 929]

```python
class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        import asyncio

        # Step 1: Extract key information and decompose the problem
        decomposition_instruction = """
        Analyze the problem thoroughly. Identify all numerical values, variables, constraints, 
        and relationships. Break the problem into smaller sub-problems and outline potential 
        solution strategies. Include any relevant mathematical domains (e.g., algebra, geometry).
        """
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Generate multiple candidate solutions in parallel
        algebraic_instruction = f"""
        Using the decomposition: {decomposition}
        Solve the problem using algebraic techniques. Simplify expressions, solve equations, 
        and verify all constraints are satisfied. Provide a step-by-step solution.
        """
        geometric_instruction = f"""
        Using the decomposition: {decomposition}
        Solve the problem using geometric reasoning. Apply principles of geometry, trigonometry, 
        or coordinate geometry. Provide a step-by-step solution.
        """
        combinatorial_instruction = f"""
        Using the decomposition: {decomposition}
        Solve the problem using combinatorial or probabilistic methods. Count arrangements, 
        calculate probabilities, or use recursive formulas. Provide a step-by-step solution.
        """
        number_theory_instruction = f"""
        Using the decomposition: {decomposition}
        Solve the problem using number theory techniques. Apply modular arithmetic, prime factorization, 
        or divisibility rules. Provide a step-by-step solution.
        """

        # Execute multiple approaches in parallel
        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text),
            self.generate(instruction=number_theory_instruction, context=self.problem_text)
        )

        # Step 3: Refine each candidate solution
        refined_results = []
        for result in results:
            refinement_instruction = f"""
            Review the following solution: {result}
            Ensure it is mathematically rigorous, satisfies all constraints, and is presented 
            clearly. Correct any errors and improve the explanation where necessary.
            """
            refined_result = await self.revise(instruction=refinement_instruction, context=result)
            refined_results.append(refined_result)

        # Step 4: Select the best solution or synthesize a hybrid approach
        ensemble_instruction = """
        Evaluate the following candidate solutions. Select the most accurate, efficient, 
        and elegant solution. If multiple solutions are valid, synthesize a hybrid approach 
        that combines their strengths.
        """
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_results)

        # Step 5: Extract the final answer in the required format
        summarization_instruction = """
        Condense the following solution into a concise and precise answer. Ensure the answer 
        is in the required format (e.g., simplified radical form, integer coefficient, etc.).
        """
        final_answer = await self.summarize(instruction=summarization_instruction, context=best_solution)

        return final_answer
```