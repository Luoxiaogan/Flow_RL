# Workflow ID: high_level_math_ganluo_204_0
# Benchmark: high_level_math_ganluo
# Data Indices: [140, 861]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Problem Analysis - Extract key components and identify mathematical domains
        analysis_instruction = """
        Analyze the problem thoroughly. Identify the key mathematical domains involved (e.g., algebra, geometry, number theory). 
        Extract all numerical values, variables, sequences, equations, and constraints. 
        Provide a structured breakdown of the problem components.
        """
        problem_analysis = await self.generate(instruction=analysis_instruction, context=self.problem_text)

        # Step 2: Parallel Solution Exploration - Generate multiple approaches
        algebraic_instruction = f"""
        Based on the problem analysis: {problem_analysis}
        Solve the problem using algebraic techniques. Focus on equations, sequences, and functional relationships. 
        Provide step-by-step reasoning and ensure all constraints are satisfied.
        """
        geometric_instruction = f"""
        Based on the problem analysis: {problem_analysis}
        Solve the problem using geometric techniques. Consider coordinate geometry, synthetic geometry, and trigonometric relationships. 
        Provide step-by-step reasoning and ensure all constraints are satisfied.
        """
        combinatorial_instruction = f"""
        Based on the problem analysis: {problem_analysis}
        Solve the problem using combinatorial techniques. Focus on counting principles, recursive relationships, and probabilistic methods. 
        Provide step-by-step reasoning and ensure all constraints are satisfied.
        """

        # Execute approaches in parallel
        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Synthesis and Selection - Choose the best approach
        synthesis_instruction = """
        Evaluate the provided solutions. Select the most rigorous, complete, and elegant approach. 
        Ensure the chosen solution satisfies all constraints and is mathematically sound.
        """
        best_solution = await self.ensemble(instruction=synthesis_instruction, contexts=results)

        # Step 4: Refinement and Verification - Critique and refine the solution
        refinement_instruction = """
        Critique the provided solution. Check for mathematical correctness, clarity, and completeness. 
        Simplify expressions if possible and verify that all constraints are satisfied.
        """
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the Final Answer
        summary_instruction = """
        Condense the solution into a concise and clear final answer. 
        Include only the essential steps and the final result.
        """
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer