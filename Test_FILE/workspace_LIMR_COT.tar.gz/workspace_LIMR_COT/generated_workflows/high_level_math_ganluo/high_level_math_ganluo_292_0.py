# Workflow ID: high_level_math_ganluo_292_0
# Benchmark: high_level_math_ganluo
# Data Indices: [995, 456]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Problem Analysis
        analysis_instruction = (
            "Analyze the problem thoroughly. Identify the mathematical domain (e.g., combinatorics, geometry, algebra), "
            "key variables, constraints, and relationships. Extract all numerical values, equations, or geometric properties. "
            "Determine potential solution strategies."
        )
        analysis = await self.generate(instruction=analysis_instruction, context=self.problem_text)

        # Step 2: Solution Exploration
        # Explore multiple solution approaches in parallel
        algebraic_instruction = f"Using {analysis}, solve the problem algebraically. Provide step-by-step reasoning."
        geometric_instruction = f"Using {analysis}, solve the problem geometrically. Provide step-by-step reasoning."
        combinatorial_instruction = f"Using {analysis}, solve the problem combinatorially. Provide step-by-step reasoning."

        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Solution Refinement
        refined_results = await asyncio.gather(
            self.revise(instruction="Critique and refine this solution. Ensure it satisfies all constraints.", context=results[0]),
            self.revise(instruction="Critique and refine this solution. Ensure it satisfies all constraints.", context=results[1]),
            self.revise(instruction="Critique and refine this solution. Ensure it satisfies all constraints.", context=results[2])
        )

        # Step 4: Final Decision
        ensemble_instruction = (
            "Compare these solutions and select the best one. Consider mathematical rigor, elegance, and adherence to constraints. "
            "If multiple solutions are valid, synthesize them into a single coherent answer."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_results)

        # Step 5: Output Preparation
        summary_instruction = (
            "Summarize the final solution in a clear and concise format. Include key steps, reasoning, and the final answer."
        )
        final_output = await self.summarize(instruction=summary_instruction, context=final_solution)

        return final_output