# Workflow ID: high_level_math_ganluo_298_0
# Benchmark: high_level_math_ganluo
# Data Indices: [676, 589]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract problem components
        extraction_instruction = (
            "Extract all key components of the problem, including variables, equations, constraints, and objectives. "
            "Provide a detailed breakdown of the problem's structure, highlighting numerical values, relationships, and goals."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        approach_instructions = [
            f"Using algebraic manipulation, solve the problem based on the following extracted information: {extracted_info}",
            f"Using geometric reasoning, solve the problem based on the following extracted information: {extracted_info}",
            f"Using combinatorial analysis, solve the problem based on the following extracted information: {extracted_info}",
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Refine each approach
        refinement_instruction_template = (
            "Critique and refine the following solution approach. Ensure it adheres to the problem's constraints, "
            "is logically consistent, and includes simplified expressions where possible. Highlight any errors or ambiguities."
        )
        refined_approaches = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction_template, context=approach) for approach in approaches]
        )

        # Step 4: Ensemble decision to select or synthesize the best solution
        ensemble_instruction = (
            "Compare the following refined solutions and select the most robust and efficient one. "
            "If possible, synthesize insights from multiple approaches to form a superior solution. "
            "Ensure the final solution satisfies all problem constraints and is mathematically sound."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_approaches)

        # Step 5: Summarize the final solution
        summarization_instruction = (
            "Condense the final solution into a concise and clear format. Include all essential details, "
            "such as the final answer, key steps, and any assumptions made during the solution process."
        )
        summarized_solution = await self.summarize(instruction=summarization_instruction, context=final_solution)

        return summarized_solution