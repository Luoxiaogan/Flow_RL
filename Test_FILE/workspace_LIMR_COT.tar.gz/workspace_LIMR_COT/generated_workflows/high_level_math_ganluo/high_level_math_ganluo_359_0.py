# Workflow ID: high_level_math_ganluo_359_0
# Benchmark: high_level_math_ganluo
# Data Indices: [953, 908]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Problem Understanding and Decomposition
        problem_analysis = await self.generate(
            instruction="Extract all key information from the problem, including numerical values, variables, constraints, and the goal. Organize this information into a structured format.",
            context=self.problem_text
        )

        # Step 2: Generate Multiple Solution Approaches
        approaches = await asyncio.gather(
            self.generate(
                instruction=f"Using the following problem analysis: {problem_analysis}\n"
                            "Develop an algebraic approach to solve the problem, focusing on equations, inequalities, and transformations.",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"Using the following problem analysis: {problem_analysis}\n"
                            "Develop a combinatorial approach to solve the problem, focusing on counting principles, permutations, and combinations.",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"Using the following problem analysis: {problem_analysis}\n"
                            "Develop a number-theoretic approach to solve the problem, focusing on divisibility, modular arithmetic, and prime factorization.",
                context=self.problem_text
            )
        )

        # Step 3: Refine Each Approach
        refined_approaches = await asyncio.gather(
            *[self.revise(
                instruction="Critique and improve the following solution approach. Ensure it is mathematically rigorous, clear, and adheres to the problem's constraints.",
                context=approach
            ) for approach in approaches]
        )

        # Step 4: Ensemble Decision-Making
        final_solution = await self.ensemble(
            instruction="Evaluate the following refined approaches and select the most promising solution. Consider mathematical rigor, simplicity, and alignment with the problem's requirements.",
            contexts=refined_approaches
        )

        # Step 5: Final Verification
        verified_solution = await self.summarize(
            instruction="Condense the final solution into a concise and verifiable form. Ensure it includes all necessary steps and satisfies the problem's constraints.",
            context=final_solution
        )

        return verified_solution