# Workflow ID: high_level_math_ganluo_121_0
# Benchmark: high_level_math_ganluo
# Data Indices: [297, 963]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio
        
        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all numerical values, constraints, and key mathematical relationships from the problem. "
            "Identify the type of problem (e.g., combinatorics, geometry, algebra) and note any special structures or symmetries."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)
        
        # Step 2: Generate multiple solution approaches in parallel
        algebraic_instruction = f"Using algebraic methods, solve the problem step by step. Consider the following extracted information: {extracted_info}."
        geometric_instruction = f"Using geometric reasoning, solve the problem step by step. Consider the following extracted information: {extracted_info}."
        combinatorial_instruction = f"Using combinatorial or probabilistic methods, solve the problem step by step. Consider the following extracted information: {extracted_info}."
        
        results = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )
        algebraic_solution, geometric_solution, combinatorial_solution = results
        
        # Step 3: Revise and refine each solution
        revise_instruction_template = (
            "Critique and refine the following solution. Ensure it is mathematically rigorous, logically consistent, "
            "and satisfies all constraints of the problem. Identify and correct any errors or ambiguities."
        )
        revised_algebraic = await self.revise(instruction=revise_instruction_template, context=algebraic_solution)
        revised_geometric = await self.revise(instruction=revise_instruction_template, context=geometric_solution)
        revised_combinatorial = await self.revise(instruction=revise_instruction_template, context=combinatorial_solution)
        
        # Step 4: Ensemble selection of the best solution
        ensemble_instruction = (
            "Evaluate the following solutions and select the most accurate and robust one. "
            "Ensure the chosen solution satisfies all constraints and provides a clear, correct answer."
        )
        final_solution = await self.ensemble(
            instruction=ensemble_instruction,
            contexts=[revised_algebraic, revised_geometric, revised_combinatorial]
        )
        
        # Step 5: Summarize the final solution (optional)
        summarize_instruction = (
            "Condense the following solution into a concise final answer. Ensure all key steps and the final result are clearly stated."
        )
        summarized_final = await self.summarize(instruction=summarize_instruction, context=final_solution)
        
        return summarized_final