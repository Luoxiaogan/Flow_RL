# Workflow ID: high_level_math_ganluo_133_0
# Benchmark: high_level_math_ganluo
# Data Indices: [332, 430]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Carefully analyze the problem statement and extract all key information, including "
            "known values, relationships, constraints, and what is being asked. Organize this "
            "information into a structured format for further processing."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution strategies
        strategy_instruction_template = (
            "Based on the extracted information: {info}, propose a detailed solution strategy. "
            "Consider multiple approaches, such as algebraic manipulation, geometric reasoning, "
            "combinatorial analysis, or number theory techniques. Ensure each strategy is "
            "mathematically sound and feasible."
        )
        strategies = await asyncio.gather(
            self.generate(instruction=strategy_instruction_template.format(info=extracted_info), context=self.problem_text),
            self.generate(instruction=strategy_instruction_template.format(info=extracted_info), context=self.problem_text),
            self.generate(instruction=strategy_instruction_template.format(info=extracted_info), context=self.problem_text)
        )

        # Step 3: Evaluate and select the best strategy
        evaluation_instruction = (
            "Compare the following solution strategies and select the most promising one. "
            "Consider clarity, feasibility, and alignment with the problem's requirements. "
            "Provide a justification for your choice."
        )
        best_strategy = await self.ensemble(instruction=evaluation_instruction, contexts=strategies)

        # Step 4: Execute the selected strategy step-by-step
        execution_instruction = (
            "Using the selected strategy: {strategy}, solve the problem step-by-step. "
            "Break the solution into smaller sub-problems, solve them sequentially, and combine "
            "results. Ensure all steps are mathematically rigorous and clearly explained."
        )
        detailed_solution = await self.generate(instruction=execution_instruction.format(strategy=best_strategy), context=self.problem_text)

        # Step 5: Refine intermediate steps if necessary
        refinement_instruction = (
            "Review the detailed solution and refine any unclear or incorrect steps. "
            "Ensure all calculations are accurate and reasoning is logically sound."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=detailed_solution)

        # Step 6: Extract and format the final answer
        summarization_instruction = (
            "From the refined solution, extract the final answer in the required format. "
            "Ensure the answer satisfies all constraints specified in the problem."
        )
        final_answer = await self.summarize(instruction=summarization_instruction, context=refined_solution)

        return final_answer