# Workflow ID: high_level_math_ganluo_90_0
# Benchmark: high_level_math_ganluo
# Data Indices: [806, 329]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Understand and decompose the problem
        problem_understanding = await self.generate(
            instruction="Carefully analyze the problem statement. "
                        "Identify all variables, constraints, and relationships. "
                        "Break the problem into smaller sub-problems if possible. "
                        "Provide a detailed breakdown of the problem structure.",
            context=self.problem_text
        )

        # Step 2: Generate multiple candidate solutions
        algebraic_solution = self.generate(
            instruction=f"Using algebraic methods, solve the problem step by step. "
                        f"Ensure all steps are mathematically rigorous. Problem details: {problem_understanding}",
            context=self.problem_text
        )
        geometric_solution = self.generate(
            instruction=f"Using geometric reasoning, solve the problem step by step. "
                        f"Include diagrams or visual representations if applicable. Problem details: {problem_understanding}",
            context=self.problem_text
        )
        combinatorial_solution = self.generate(
            instruction=f"Using combinatorial or probabilistic methods, solve the problem step by step. "
                        f"Consider casework or recursive structures if necessary. Problem details: {problem_understanding}",
            context=self.problem_text
        )

        # Execute candidate solutions in parallel
        candidate_solutions = await asyncio.gather(algebraic_solution, geometric_solution, combinatorial_solution)

        # Step 3: Evaluate and synthesize the best solution
        best_solution = await self.ensemble(
            instruction="Compare the provided solutions. "
                        "Select the most correct, efficient, and elegant approach. "
                        "If no solution is fully correct, identify the closest valid solution and note its shortcomings.",
            contexts=candidate_solutions
        )

        # Step 4: Refine the chosen solution
        refined_solution = await self.revise(
            instruction="Review the selected solution for mathematical accuracy and clarity. "
                        "Correct any errors, fill gaps in reasoning, and ensure all constraints are satisfied.",
            context=best_solution
        )

        # Step 5: Summarize the final solution
        final_output = await self.summarize(
            instruction="Condense the solution into a concise and structured format. "
                        "Ensure the answer satisfies the problem requirements and is presented clearly.",
            context=refined_solution
        )

        return final_output