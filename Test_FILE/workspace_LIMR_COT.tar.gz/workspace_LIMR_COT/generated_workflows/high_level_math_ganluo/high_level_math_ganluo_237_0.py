# Workflow ID: high_level_math_ganluo_237_0
# Benchmark: high_level_math_ganluo
# Data Indices: [397, 299]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key components from the problem text
        extraction_instruction = (
            "Extract all numerical values, constraints, and relationships explicitly stated or implied in the problem. "
            "Provide them in a structured format for further analysis."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        algebraic_instruction = (
            f"Given the extracted information: {extracted_info} "
            "Solve the problem using algebraic methods. Include step-by-step reasoning, transformations, and calculations. "
            "Ensure all constraints are satisfied and the solution is mathematically rigorous."
        )
        combinatorial_instruction = (
            f"Given the extracted information: {extracted_info} "
            "Solve the problem using combinatorial or probabilistic methods. Consider casework, recursive structures, or generating functions if applicable. "
            "Ensure the solution aligns with the problem's requirements."
        )
        number_theory_instruction = (
            f"Given the extracted information: {extracted_info} "
            "Solve the problem using number theory techniques such as divisibility, modular arithmetic, or prime factorization. "
            "Provide a clear justification for each step."
        )

        approaches = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text),
            self.generate(instruction=number_theory_instruction, context=self.problem_text)
        )

        # Step 3: Evaluate and select the best approach
        evaluation_instruction = (
            "Compare the provided solution approaches. Select the one that is most rigorous, efficient, and aligned with the problem's constraints. "
            "Provide a justification for your choice."
        )
        best_solution = await self.ensemble(instruction=evaluation_instruction, contexts=approaches)

        # Step 4: Verify and refine the selected solution
        refinement_instruction = (
            "Critically analyze the selected solution. Check for mathematical correctness, constraint satisfaction, and logical consistency. "
            "Refine the solution if necessary, ensuring it is complete and well-structured."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the final solution
        summary_instruction = (
            "Condense the refined solution into a concise summary. Highlight the key steps, results, and reasoning. "
            "Ensure the output is clear and directly addresses the problem."
        )
        final_summary = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_summary