# Workflow ID: high_level_math_ganluo_40_0
# Benchmark: high_level_math_ganluo
# Data Indices: [964, 910]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Problem Decomposition
        decomposition = await self.generate(
            instruction="Analyze the problem thoroughly. Identify all numerical values, variables, constraints, and relationships. Determine the primary mathematical domain (e.g., algebra, geometry, combinatorics) and any sub-problems.",
            context=self.problem_text
        )

        # Step 2: Approach Generation
        approaches = await asyncio.gather(
            self.generate(
                instruction=f"Based on the following analysis: {decomposition}\nDevelop an algebraic approach to solve the problem. Include all steps and reasoning.",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"Based on the following analysis: {decomposition}\nDevelop a geometric approach to solve the problem. Include all steps and reasoning.",
                context=self.problem_text
            ),
            self.generate(
                instruction=f"Based on the following analysis: {decomposition}\nDevelop a combinatorial or probabilistic approach to solve the problem. Include all steps and reasoning.",
                context=self.problem_text
            )
        )

        # Step 3: Evaluation and Selection
        selected_approach = await self.ensemble(
            instruction="Evaluate the following approaches based on correctness, simplicity, and computational feasibility. Select the most promising approach or synthesize insights from multiple approaches if necessary.",
            contexts=approaches
        )

        # Step 4: Solution Execution
        solution_steps = await self.generate(
            instruction=f"Execute the selected approach step-by-step. Ensure each step is clearly explained and logically follows from the previous one. Approach: {selected_approach}",
            context=self.problem_text
        )

        # Step 5: Refinement
        refined_solution = await self.revise(
            instruction="Review the following solution steps. Correct any errors, clarify ambiguities, and ensure all constraints are satisfied.",
            context=solution_steps
        )

        # Step 6: Verification and Finalization
        final_solution = await self.summarize(
            instruction="Condense the following refined solution into a clear, concise, and well-structured final answer. Ensure it satisfies all problem constraints.",
            context=refined_solution
        )

        return final_solution