# Workflow ID: high_level_math_ganluo_175_0
# Benchmark: high_level_math_ganluo
# Data Indices: [766, 105]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information from the problem
        extraction_instruction = (
            "Extract all numerical values, constraints, relationships, and the specific question being asked. "
            "Organize the information into structured categories such as 'Given Data', 'Constraints', and 'Question'."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches
        generate_instructions = [
            f"Using {approach}, solve the problem step by step. Ensure all constraints are satisfied and provide detailed reasoning.",
            f"Apply {approach} creatively to uncover hidden structures or symmetries. Verify intermediate results."
        ]
        approaches = ["algebraic manipulation", "geometric reasoning", "combinatorial analysis", "number theory"]
        tasks = [
            self.generate(instruction=instruction.format(approach=approach), context=extracted_info)
            for approach, instruction in zip(approaches, generate_instructions * len(approaches))
        ]
        raw_solutions = await asyncio.gather(*tasks)

        # Step 3: Refine each solution
        refine_instruction = (
            "Critique this solution for logical consistency, mathematical correctness, and adherence to constraints. "
            "Improve any flawed reasoning or incomplete calculations. Ensure the solution is robust and elegant."
        )
        refinement_tasks = [
            self.revise(instruction=refine_instruction, context=solution)
            for solution in raw_solutions
        ]
        refined_solutions = await asyncio.gather(*refinement_tasks)

        # Step 4: Synthesize the best solution
        ensemble_instruction = (
            "Compare these solutions and select the most robust, elegant, and mathematically sound approach. "
            "If multiple solutions are valid, combine their insights to form a unified solution."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_solutions)

        # Step 5: Summarize the final solution
        summarize_instruction = (
            "Condense the solution into a concise and clear format. Include all key steps, reasoning, and the final answer. "
            "Ensure the summary is self-contained and easy to understand."
        )
        final_summary = await self.summarize(instruction=summarize_instruction, context=final_solution)

        return final_summary