# Workflow ID: high_level_math_ganluo_51_0
# Benchmark: high_level_math_ganluo
# Data Indices: [453, 280]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Problem Decomposition
        decomposition_instruction = (
            "Analyze the problem statement thoroughly. Identify all variables, constraints, "
            "and relationships. Extract any numerical values, equations, or conditions explicitly stated. "
            "Break the problem into smaller sub-problems or cases if applicable."
        )
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Generate Multiple Approaches
        approach_instructions = [
            "Using an algebraic approach, solve the problem step by step. Focus on equations, inequalities, "
            "and functional relationships. Ensure all constraints are satisfied.",
            "Using a combinatorial or probabilistic approach, count possibilities, calculate probabilities, "
            "or use recursive formulas. Highlight symmetry or patterns that simplify the problem.",
            "Using a geometric approach, interpret the problem visually. Apply coordinate geometry, synthetic "
            "geometry, or trigonometric techniques. Calculate areas, volumes, or angles as needed.",
            "Using number theory, analyze divisibility, modular arithmetic, or prime factorization. Solve "
            "Diophantine equations or explore properties of integers."
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=decomposition) for instr in approach_instructions]
        )

        # Step 3: Refine Approaches
        refine_instruction_template = (
            "Critique and improve the following approach. Check for logical consistency, mathematical rigor, "
            "and adherence to the problem's constraints. Suggest corrections or enhancements where necessary."
        )
        refined_approaches = await asyncio.gather(
            *[self.revise(instruction=refine_instruction_template, context=approach) for approach in approaches]
        )

        # Step 4: Synthesize Best Solution
        ensemble_instruction = (
            "Evaluate the following approaches. Select the most rigorous, clear, and correct solution. "
            "If multiple approaches are valid, synthesize them into a unified solution. Ensure the final "
            "solution satisfies all constraints and is mathematically sound."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_approaches)

        # Step 5: Verify and Simplify Final Solution
        verification_instruction = (
            "Verify the final solution against all constraints in the problem statement. Simplify the "
            "solution if possible, ensuring it is concise and elegant. Confirm that it addresses all parts "
            "of the problem and is free of errors."
        )
        final_solution = await self.revise(instruction=verification_instruction, context=best_solution)

        return final_solution