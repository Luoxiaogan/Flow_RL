# Workflow ID: high_level_math_ganluo_67_0
# Benchmark: high_level_math_ganluo
# Data Indices: [842, 48]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract critical information from the problem
        extraction_instruction = (
            "Extract all given numerical values, vectors, and mathematical relationships from the problem. "
            "Identify what is being asked and any constraints provided. "
            "Ensure the output is structured and includes all relevant details."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Derive mathematical relationships or formulas
        analysis_instruction = (
            f"Based on the extracted information: {extracted_info}, "
            "derive the mathematical relationships or formulas needed to solve the problem. "
            "Include step-by-step reasoning and ensure all derivations are rigorous and complete."
        )
        mathematical_analysis = await self.generate(instruction=analysis_instruction, context=self.problem_text)

        # Step 3: Generate multiple solution approaches in parallel
        approach1_instruction = (
            f"Using the derived relationships: {mathematical_analysis}, "
            "solve the problem using an algebraic approach. "
            "Provide detailed calculations and intermediate steps."
        )
        approach2_instruction = (
            f"Using the derived relationships: {mathematical_analysis}, "
            "solve the problem using a geometric or visual reasoning approach. "
            "Include diagrams or visual descriptions if applicable."
        )
        approaches = await asyncio.gather(
            self.generate(instruction=approach1_instruction, context=self.problem_text),
            self.generate(instruction=approach2_instruction, context=self.problem_text)
        )

        # Step 4: Revise and refine each solution
        revise_instruction_template = (
            "Critique and refine the following solution: {{solution}}. "
            "Ensure all steps are mathematically correct, clearly explained, and aligned with the problem requirements. "
            "Simplify where possible and highlight any assumptions made."
        )
        refined_solutions = await asyncio.gather(
            self.revise(instruction=revise_instruction_template.format(solution=approaches[0]), context=approaches[0]),
            self.revise(instruction=revise_instruction_template.format(solution=approaches[1]), context=approaches[1])
        )

        # Step 5: Select the best solution using Ensemble
        ensemble_instruction = (
            "Compare the following solutions and select the most accurate, elegant, and rigorous one. "
            "Ensure the chosen solution satisfies all problem constraints and is mathematically sound. "
            "Provide a justification for your choice."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=refined_solutions)

        # Step 6: Summarize the final solution
        summary_instruction = (
            "Condense the following solution into a concise, well-structured format suitable for presentation. "
            "Include only the essential steps and final answer."
        )
        final_output = await self.summarize(instruction=summary_instruction, context=best_solution)

        return final_output