# Workflow ID: high_level_math_ganluo_410_0
# Benchmark: high_level_math_ganluo
# Data Indices: [66, 44]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        """
        import asyncio

        # Step 1: Extract key information and decompose the problem
        extraction_instruction = (
            "Carefully analyze the problem and extract all key information, including numerical values, "
            "variables, relationships, and constraints. Identify the type of problem (e.g., combinatorics, "
            "geometry, algebra) and any specific techniques that might be required."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        approach_instructions = [
            f"Using algebraic methods, solve the problem based on the following extracted information: {extracted_info}",
            f"Using geometric reasoning, solve the problem based on the following extracted information: {extracted_info}",
            f"Using combinatorial analysis, solve the problem based on the following extracted information: {extracted_info}"
        ]
        approaches = await asyncio.gather(
            *[self.generate(instruction=instr, context=self.problem_text) for instr in approach_instructions]
        )

        # Step 3: Evaluate and select the best approach
        ensemble_instruction = (
            "Compare the provided solutions and select the most promising one. Consider factors such as "
            "correctness, simplicity, and alignment with the problem's constraints. If none of the solutions "
            "are satisfactory, suggest a new approach."
        )
        best_solution = await self.ensemble(instruction=ensemble_instruction, contexts=approaches)

        # Step 4: Refine and verify the selected solution
        revise_instruction = (
            "Critique and improve the given solution. Ensure it satisfies all constraints and is mathematically "
            "sound. Provide detailed reasoning for any changes made."
        )
        refined_solution = await self.revise(instruction=revise_instruction, context=best_solution)

        # Step 5: Summarize the final solution (optional)
        summarize_instruction = (
            "Condense the solution into a concise, well-structured format. Include only the essential steps "
            "and the final answer."
        )
        final_solution = await self.summarize(instruction=summarize_instruction, context=refined_solution)

        return final_solution