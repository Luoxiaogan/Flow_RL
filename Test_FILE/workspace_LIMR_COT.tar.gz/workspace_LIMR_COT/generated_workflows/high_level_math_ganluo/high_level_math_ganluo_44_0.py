# Workflow ID: high_level_math_ganluo_44_0
# Benchmark: high_level_math_ganluo
# Data Indices: [230, 79]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Understand the problem and extract key components
        understanding_instruction = (
            "Carefully analyze the problem statement. Identify all variables, constraints, "
            "and relationships. Categorize the problem into one or more mathematical domains "
            "(e.g., algebra, geometry, combinatorics). Highlight any special conditions or edge cases."
        )
        problem_analysis = await self.generate(instruction=understanding_instruction, context=self.problem_text)

        # Step 2: Generate multiple solution approaches in parallel
        algebraic_instruction = (
            f"Based on the following analysis: {problem_analysis}\n"
            "Develop an algebraic solution approach. Focus on equations, inequalities, and functional relationships. "
            "Ensure all constraints are incorporated."
        )
        combinatorial_instruction = (
            f"Based on the following analysis: {problem_analysis}\n"
            "Develop a combinatorial solution approach. Focus on counting techniques, recursive structures, "
            "and probabilistic methods if applicable."
        )
        geometric_instruction = (
            f"Based on the following analysis: {problem_analysis}\n"
            "Develop a geometric solution approach. Focus on coordinate geometry, synthetic geometry, "
            "and trigonometric relationships."
        )

        algebraic_solution, combinatorial_solution, geometric_solution = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=problem_analysis),
            self.generate(instruction=combinatorial_instruction, context=problem_analysis),
            self.generate(instruction=geometric_instruction, context=problem_analysis)
        )

        # Step 3: Evaluate and select the best solution path
        evaluation_instruction = (
            "Compare the following solution approaches and select the most promising one. "
            "Consider correctness, clarity, and computational feasibility. Provide a justification for your choice."
        )
        best_solution = await self.ensemble(
            instruction=evaluation_instruction,
            contexts=[algebraic_solution, combinatorial_solution, geometric_solution]
        )

        # Step 4: Refine the selected solution
        refinement_instruction = (
            f"Refine the following solution: {best_solution}\n"
            "Ensure all steps are mathematically rigorous. Verify that all constraints are satisfied. "
            "Simplify expressions where possible and clarify reasoning."
        )
        refined_solution = await self.revise(instruction=refinement_instruction, context=best_solution)

        # Step 5: Summarize the final solution
        summary_instruction = (
            f"Summarize the following solution: {refined_solution}\n"
            "Provide a concise, clear explanation of the final answer. Include all key steps and results."
        )
        final_answer = await self.summarize(instruction=summary_instruction, context=refined_solution)

        return final_answer