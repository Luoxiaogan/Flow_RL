# Workflow ID: high_level_math_ganluo_297_0
# Benchmark: high_level_math_ganluo
# Data Indices: [259, 898]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Extract and Understand the Problem
        extraction_instruction = (
            "Extract all key mathematical elements from the problem, including variables, constants, "
            "relationships, and constraints. Organize this information clearly and concisely."
        )
        extracted_info = await self.generate(instruction=extraction_instruction, context=self.problem_text)

        # Step 2: Generate Multiple Solution Approaches
        approach_instruction_template = (
            "Given the following extracted information: {info}\n"
            "Develop a step-by-step solution strategy for solving the problem using {approach}. "
            "Ensure the reasoning is rigorous and accounts for all constraints and edge cases. "
            "Provide intermediate steps and justifications."
        )

        algebraic_instruction = approach_instruction_template.format(info=extracted_info, approach="algebraic methods")
        geometric_instruction = approach_instruction_template.format(info=extracted_info, approach="geometric reasoning")
        combinatorial_instruction = approach_instruction_template.format(info=extracted_info, approach="combinatorial techniques")

        # Generate candidate solutions in parallel
        candidate_solutions = await asyncio.gather(
            self.generate(instruction=algebraic_instruction, context=self.problem_text),
            self.generate(instruction=geometric_instruction, context=self.problem_text),
            self.generate(instruction=combinatorial_instruction, context=self.problem_text)
        )

        # Step 3: Refine Each Candidate Solution
        refinement_instruction_template = (
            "Critically analyze the following solution: {solution}\n"
            "Check for mathematical correctness, logical consistency, and adherence to all problem constraints. "
            "Refine the solution as needed, providing clear justifications for any changes."
        )

        refined_solutions = await asyncio.gather(
            *[self.revise(instruction=refinement_instruction_template.format(solution=sol), context=self.problem_text)
              for sol in candidate_solutions]
        )

        # Step 4: Select the Best Solution
        selection_instruction = (
            "Evaluate the following candidate solutions and select the best one:\n"
            "{solutions}\n"
            "Criteria for selection: correctness, clarity, efficiency, and adherence to problem constraints. "
            "Provide a justification for your choice."
        ).format(solutions="\n---\n".join(refined_solutions))

        final_solution = await self.ensemble(instruction=selection_instruction, contexts=refined_solutions)

        # Step 5: Format and Return the Final Answer
        return final_solution