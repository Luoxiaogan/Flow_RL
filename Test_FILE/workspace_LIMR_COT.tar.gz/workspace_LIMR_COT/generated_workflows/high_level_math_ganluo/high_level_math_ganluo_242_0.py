# Workflow ID: high_level_math_ganluo_242_0
# Benchmark: high_level_math_ganluo
# Data Indices: [449, 64]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - Use detailed, comprehensive instructions
        - Dynamic instruction construction is powerful
        - All operators expect (instruction: str, context: str) except Ensemble which takes contexts: List[str]
        """
        import asyncio

        # Step 1: Understand and decompose the problem
        decomposition_instruction = (
            "Analyze the problem thoroughly. Identify all variables, constraints, and objectives. "
            "Break down the problem into manageable sub-problems. Highlight any mathematical structures, "
            "patterns, or symmetries that can simplify the solution."
        )
        decomposition = await self.generate(instruction=decomposition_instruction, context=self.problem_text)

        # Step 2: Explore multiple solution approaches in parallel
        approach1_instruction = (
            f"Based on the problem decomposition: {decomposition}, solve the problem using an algebraic approach. "
            "Focus on equations, formulas, and symbolic manipulation. Ensure all steps are logically justified."
        )
        approach2_instruction = (
            f"Based on the problem decomposition: {decomposition}, solve the problem using a geometric or combinatorial approach. "
            "Visualize the problem if possible, and use spatial reasoning or counting techniques as needed."
        )
        results = await asyncio.gather(
            self.generate(instruction=approach1_instruction, context=self.problem_text),
            self.generate(instruction=approach2_instruction, context=self.problem_text)
        )
        solution1, solution2 = results

        # Step 3: Refine the solutions
        refine_instruction = (
            "Critique and improve the given solution. Check for logical consistency, mathematical correctness, "
            "and alignment with the problem's requirements. Suggest improvements if necessary."
        )
        refined1 = await self.revise(instruction=refine_instruction, context=solution1)
        refined2 = await self.revise(instruction=refine_instruction, context=solution2)

        # Step 4: Compare and synthesize the solutions
        ensemble_instruction = (
            "Evaluate the two refined solutions. Select the most robust and elegant solution, or synthesize a new solution "
            "that combines the strengths of both. Ensure the final solution satisfies all constraints and is mathematically sound."
        )
        final_solution = await self.ensemble(instruction=ensemble_instruction, contexts=[refined1, refined2])

        # Step 5: Extract and format the final answer
        summarize_instruction = (
            "Extract the final answer from the solution. Format it clearly and concisely. Ensure it satisfies all problem constraints "
            "and is presented in the required form."
        )
        final_answer = await self.summarize(instruction=summarize_instruction, context=final_solution)

        return final_answer