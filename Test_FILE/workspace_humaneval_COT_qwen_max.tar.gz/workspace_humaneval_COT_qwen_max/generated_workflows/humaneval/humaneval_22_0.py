# Workflow ID: humaneval_22_0
# Benchmark: humaneval
# Data Indices: [91, 47]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        import json  # For parsing structured data if needed
        import re    # For regex operations if needed
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract ONLY the function name from the def statement. "
                        "Return just the name, nothing else.",
            context=""
        )
        
        # Step 2: Analyze the docstring for patterns, edge cases, and return type
        docstring_analysis = await self.generate(
            instruction=f"""
            Analyze the docstring for the function '{func_name}':
            1. What pattern do the examples show?
            2. What are the edge cases mentioned or implied?
            3. What is the expected return type (int, float, list, etc.)?
            Return a brief analysis in 2-3 sentences.
            """,
            context=""
        )
        
        # Step 3: Generate the solution based on the analysis
        solution = await self.generate(
            instruction=f"""
            Implement the function '{func_name}' based on the docstring specification.
            Analysis: {docstring_analysis}
            
            Requirements:
            1. Follow the EXACT function signature provided in the problem text.
            2. Implement the logic that satisfies ALL examples in the docstring.
            3. Handle edge cases shown in examples.
            4. Return the correct type (int, float, list, etc.) as shown in examples.
            5. Include any necessary imports at the top.
            6. Return ONLY the Python code, no explanations.
            """,
            context=""
        )
        
        # Step 4 (Optional): Refine the solution if needed
        refined_solution = await self.revise(
            instruction=f"""
            Review the following implementation for the function '{func_name}':
            - Ensure it adheres to the docstring specification.
            - Check for edge cases and logical correctness.
            - Verify the return type matches the examples.
            Return the refined implementation if improvements are needed; otherwise, return the original solution.
            """,
            context=solution
        )
        
        # Step 5: Return the final solution
        final_solution = refined_solution if refined_solution != solution else solution
        return final_solution