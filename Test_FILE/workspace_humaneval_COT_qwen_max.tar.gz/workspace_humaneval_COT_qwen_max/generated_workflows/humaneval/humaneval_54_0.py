# Workflow ID: humaneval_54_0
# Benchmark: humaneval
# Data Indices: [127]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio

        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract ONLY the function name from the def statement. Return just the name, nothing else.",
            context=""
        )

        # Step 2: Analyze the docstring examples and requirements
        analysis = await self.generate(
            instruction="""
            Analyze the docstring and examples carefully:
            1. What is the task? (e.g., interval intersection, prime number check)
            2. What are the edge cases? (e.g., non-overlapping intervals, negative numbers)
            3. What is the expected return type? ("YES" or "NO")
            Return a brief analysis in 2-3 sentences.
            """,
            context=""
        )

        # Step 3: Generate the initial solution
        solution = await self.generate(
            instruction=f"""
            Implement the function '{func_name}' based on the docstring specification.
            Analysis: {analysis}
            
            Requirements:
            1. Follow the EXACT function signature provided
            2. Implement the logic that satisfies ALL examples in the docstring
            3. Handle edge cases shown in examples
            4. Return the correct type ("YES" or "NO") as shown in examples
            5. Include any necessary imports at the top
            6. Return ONLY the Python code, no explanations
            """,
            context=""
        )

        # Step 4: Revise the solution for correctness and completeness
        revised_solution = await self.revise(
            instruction="""
            Review the following code for correctness:
            1. Does it handle all examples in the docstring?
            2. Are edge cases properly addressed?
            3. Is the return type consistent with the specification?
            If there are issues, fix them and return the corrected code.
            """,
            context=solution
        )

        # Step 5: Return the final solution
        return revised_solution