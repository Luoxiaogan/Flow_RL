# Workflow ID: humaneval_23_0
# Benchmark: humaneval
# Data Indices: [103]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio

        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract ONLY the function name from the def statement. Return just the name, nothing else.",
            context=""
        )
        
        # Step 2: Analyze the docstring requirements
        analysis = await self.generate(
            instruction="""
            Analyze the docstring and examples carefully:
            1. What is the task? Describe the logic or formula.
            2. Identify edge cases (e.g., invalid inputs).
            3. Determine the expected return type(s).
            Return a brief analysis in 2-3 sentences.
            """,
            context=""
        )
        
        # Step 3: Generate the solution code
        solution = await self.generate(
            instruction=f"""
            Implement the function '{func_name}' based on the docstring specification.
            Analysis: {analysis}
            
            Requirements:
            1. Follow the EXACT function signature provided.
            2. Compute the average of integers from n to m (inclusive).
            3. Round the average to the nearest integer.
            4. Convert the rounded integer to binary using Python's bin() function.
            5. If n > m, return -1.
            6. Include any necessary imports at the top.
            7. Return ONLY the Python code, no explanations.
            """,
            context=""
        )
        
        # Step 4: Revise the solution for robustness
        revised_solution = await self.revise(
            instruction="""
            Critique and refine the following code:
            1. Ensure it satisfies ALL examples in the docstring.
            2. Verify proper handling of edge cases.
            3. Confirm correct return types (binary string or -1).
            Return the improved code.
            """,
            context=solution
        )
        
        return revised_solution