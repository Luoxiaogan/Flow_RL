# Workflow ID: humaneval_10_0
# Benchmark: humaneval
# Data Indices: [152, 106]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        """
        import asyncio
        
        # Step 1: Extract function name
        func_name = await self.generate(
            instruction="Extract ONLY the function name from the def statement. "
                        "Return just the name, nothing else.",
            context=""
        )
        
        # Step 2: Analyze the docstring examples
        analysis = await self.generate(
            instruction="""
            Analyze the docstring and examples carefully:
            1. What pattern do the examples show?
            2. What are the edge cases?
            3. What is the expected return type?
            Return a brief analysis in 2-3 sentences.
            """,
            context=""
        )
        
        # Step 3: Generate initial solution
        solution = await self.generate(
            instruction=f"""
            Implement the function '{func_name}' based on the docstring specification.
            Analysis: {analysis}
            
            Requirements:
            1. Follow the EXACT function signature provided
            2. Implement the logic that satisfies ALL examples in the docstring
            3. Handle edge cases shown in examples
            4. Return the correct type (int, float, list, etc.) as shown in examples
            5. Include any necessary imports at the top
            6. Return ONLY the Python code, no explanations
            """,
            context=""
        )
        
        # Step 4: Revise solution (optional refinement)
        revised_solution = await self.revise(
            instruction="Review the following code for correctness, edge case handling, "
                        "and adherence to the docstring specification. Make improvements if needed.",
            context=solution
        )
        
        # Step 5: Ensemble multiple solutions (optional)
        # Generate an alternative solution for comparison
        alternative_solution = await self.generate(
            instruction=f"""
            Provide an alternative implementation for the function '{func_name}'.
            Follow the same requirements as before:
            1. Match the function signature exactly
            2. Satisfy all docstring examples
            3. Handle edge cases
            4. Return the correct type
            5. Include necessary imports
            6. Return ONLY the Python code
            """,
            context=""
        )
        
        # Select the best solution between the revised and alternative versions
        final_solution = await self.ensemble(
            instruction="Compare the following two implementations and select the one "
                        "that best satisfies the problem requirements. Consider correctness, "
                        "edge case handling, and code quality.",
            contexts=[revised_solution, alternative_solution]
        )
        
        return final_solution