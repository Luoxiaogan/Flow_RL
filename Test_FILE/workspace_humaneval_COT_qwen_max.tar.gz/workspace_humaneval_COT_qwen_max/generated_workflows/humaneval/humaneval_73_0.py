# Workflow ID: humaneval_73_0
# Benchmark: humaneval
# Data Indices: [111, 90]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract ONLY the function name from the def statement. "
                        "Return just the name, nothing else.",
            context=""
        )
        
        # Step 2: Analyze the docstring examples and requirements
        analysis = await self.generate(
            instruction="""
            Analyze the docstring and examples carefully:
            1. What pattern do the examples show?
            2. What are the edge cases?
            3. What is the expected return type?
            Return a brief analysis in 2-3 sentences.
            """,
            context=""
        )
        
        # Step 3: Generate the initial solution
        initial_solution = await self.generate(
            instruction=f"""
            Implement the function '{func_name}' based on the docstring specification.
            Analysis: {analysis}
            
            Requirements:
            1. Follow the EXACT function signature provided
            2. Implement the logic that satisfies ALL examples in the docstring
            3. Handle edge cases shown in examples
            4. Return the correct type (int, float, list, dict, etc.) as shown in examples
            5. Include any necessary imports at the top
            6. Return ONLY the Python code, no explanations
            """,
            context=""
        )
        
        # Step 4: Revise the solution for correctness and efficiency
        revised_solution = await self.revise(
            instruction=f"""
            Review the following implementation of '{func_name}' and improve it:
            1. Ensure it passes all examples in the docstring
            2. Optimize for readability and efficiency
            3. Handle any edge cases missed in the initial version
            Return ONLY the improved Python code, no explanations.
            """,
            context=initial_solution
        )
        
        # Step 5: Summarize the final solution
        summary = await self.summarize(
            instruction=f"""
            Summarize the final implementation of '{func_name}':
            1. Briefly describe what the function does
            2. Highlight how it handles edge cases
            3. Confirm the return type matches the docstring
            Return a concise summary in 1-2 sentences.
            """,
            context=revised_solution
        )
        
        # Debugging/Logging Summary (Optional)
        print(f"Summary of Final Solution: {summary}")
        
        # Step 6: Return the final code
        return revised_solution