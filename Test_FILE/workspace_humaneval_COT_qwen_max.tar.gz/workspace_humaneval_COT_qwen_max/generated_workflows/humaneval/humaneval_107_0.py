# Workflow ID: humaneval_107_0
# Benchmark: humaneval
# Data Indices: [113, 55]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract function name
        func_name = await self.generate(
            instruction="Extract ONLY the function name from the given function signature. "
                        "Return just the name as a plain string, nothing else.",
            context=""
        )
        
        # Step 2: Analyze the docstring
        analysis = await self.generate(
            instruction="""
            Analyze the docstring carefully:
            1. What pattern do the examples show?
            2. What are the edge cases?
            3. What is the expected return type?
            Return a brief analysis in 2-3 sentences.
            """,
            context=""
        )
        
        # Step 3: Generate initial solution
        initial_solution = await self.generate(
            instruction=f"""
            Implement the function '{func_name}' based on the docstring specification.
            Analysis: {analysis}
            
            Requirements:
            1. Follow the EXACT function signature provided
            2. Implement the logic that satisfies ALL examples in the docstring
            3. Handle edge cases shown in examples
            4. Return the correct type (int, float, list, etc.) as shown in examples
            5. Include any necessary imports at the top
            6. Return ONLY the Python code, no explanations
            """,
            context=""
        )
        
        # Step 4: Revise the solution for accuracy
        final_solution = await self.revise(
            instruction=f"""
            Review and refine the following implementation of '{func_name}':
            - Ensure it satisfies ALL examples in the docstring
            - Handle edge cases properly
            - Match the expected return type exactly
            - Optimize for clarity and correctness
            
            Return the revised Python code ONLY, no explanations.
            """,
            context=initial_solution
        )
        
        # Optional Step 5: Ensemble decision (if generating multiple candidates)
        # Uncomment this section if you want to compare multiple solutions
        """
        candidates = await asyncio.gather(
            self.generate(instruction="Generate alternative solution 1...", context=""),
            self.generate(instruction="Generate alternative solution 2...", context="")
        )
        final_solution = await self.ensemble(
            instruction="Select the best solution that satisfies all requirements.",
            contexts=candidates
        )
        """
        
        return final_solution