# Workflow ID: humaneval_24_0
# Benchmark: humaneval
# Data Indices: [16, 129]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract ONLY the function name from the provided function signature. "
                        "Return just the name, nothing else.",
            context=""
        )
        
        # Step 2: Analyze the docstring
        analysis = await self.generate(
            instruction="""
            Carefully analyze the docstring and examples provided in the problem specification:
            1. Identify the pattern or logic described in the examples.
            2. List any edge cases mentioned or implied in the examples.
            3. Determine the expected return type (e.g., int, float, list, etc.).
            Return a concise analysis in 2-3 sentences.
            """,
            context=""
        )
        
        # Step 3: Generate the solution
        solution = await self.generate(
            instruction=f"""
            Implement the function '{func_name}' based on the docstring specification.
            Analysis: {analysis}
            
            Requirements:
            1. Follow the EXACT function signature provided in the problem.
            2. Implement the logic that satisfies ALL examples in the docstring.
            3. Handle edge cases shown in the examples.
            4. Return the correct type (int, float, list, etc.) as shown in examples.
            5. Include any necessary imports at the top of the function.
            6. Return ONLY the Python code, no explanations.
            """,
            context=""
        )
        
        # Optional Step 4: Refine the solution
        refined_solution = await self.revise(
            instruction="""
            Review the generated solution and make improvements if necessary:
            1. Ensure all edge cases are handled.
            2. Verify the return type matches the examples.
            3. Optimize the code for clarity and efficiency.
            Return the revised Python code.
            """,
            context=solution
        )
        
        # Final Step: Return the refined solution
        return refined_solution