# Workflow ID: humaneval_36_0
# Benchmark: humaneval
# Data Indices: [11, 147]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract ONLY the function name from the def statement. Return just the name, nothing else.",
            context=""
        )
        
        # Step 2: Analyze the docstring
        analysis = await self.generate(
            instruction="""
            Analyze the docstring and examples carefully:
            1. What pattern do the examples show?
            2. What are the edge cases?
            3. What is the expected return type?
            Return a brief analysis in 2-3 sentences.
            """,
            context=""
        )
        
        # Step 3: Generate initial solution
        initial_solution = await self.generate(
            instruction=f"""
            Implement the function '{func_name}' based on the docstring specification.
            Analysis: {analysis}
            
            Requirements:
            1. Follow the EXACT function signature provided
            2. Implement the logic that satisfies ALL examples in the docstring
            3. Handle edge cases shown in examples
            4. Return the correct type (int, float, list, etc.) as shown in examples
            5. Include any necessary imports at the top
            6. Return ONLY the Python code, no explanations
            """,
            context=""
        )
        
        # Step 4: Refine the solution
        refined_solution = await self.revise(
            instruction="""
            Review and improve the following code:
            - Ensure it adheres to the docstring specification
            - Fix any logical errors or inefficiencies
            - Correct type mismatches or inconsistencies
            - Return ONLY the improved Python code, no explanations
            """,
            context=initial_solution
        )
        
        # Step 5: Summarize the solution for final validation
        summary = await self.summarize(
            instruction="""
            Summarize the key aspects of the following solution:
            - Does it follow the docstring specification?
            - Are edge cases handled correctly?
            - Is the return type consistent with examples?
            Return a brief 1-2 sentence summary.
            """,
            context=refined_solution
        )
        
        # Debugging output (optional, for internal checks)
        print(f"Summary of Solution: {summary}")
        
        # Step 6: Return the final code
        return refined_solution