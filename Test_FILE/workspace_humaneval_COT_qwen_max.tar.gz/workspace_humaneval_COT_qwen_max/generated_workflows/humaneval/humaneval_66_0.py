# Workflow ID: humaneval_66_0
# Benchmark: humaneval
# Data Indices: [124, 75]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        import json  # For parsing structured data if needed
        import re    # For regex operations if needed
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract ONLY the function name from the def statement. "
                        "Return just the name, nothing else.",
            context=""
        )
        
        # Step 2: Analyze the docstring for patterns and edge cases
        analysis = await self.generate(
            instruction=f"""
            Analyze the docstring for the function '{func_name}':
            1. What is the logical pattern or algorithm described?
            2. What are the edge cases mentioned or implied in the examples?
            3. What is the expected return type (e.g., bool, int, float, list)?
            Return a concise analysis in 2-3 sentences.
            """,
            context=""
        )
        
        # Step 3: Generate the initial solution
        initial_solution = await self.generate(
            instruction=f"""
            Implement the function '{func_name}' based on the following analysis:
            {analysis}
            
            Requirements:
            1. Follow the EXACT function signature provided in the problem text.
            2. Implement the logic that satisfies ALL examples in the docstring.
            3. Handle edge cases shown in examples.
            4. Return the correct type as shown in examples.
            5. Include any necessary imports at the top.
            6. Return ONLY the Python code, no explanations.
            """,
            context=""
        )
        
        # Step 4: Revise the solution for accuracy and completeness
        revised_solution = await self.revise(
            instruction=f"""
            Critique and refine the following implementation of '{func_name}':
            - Ensure it complies with ALL examples in the docstring.
            - Verify edge case handling.
            - Check for Python syntax and convention adherence.
            Return the improved Python code ONLY.
            """,
            context=initial_solution
        )
        
        # Step 5: Final validation (optional ensemble if multiple candidates exist)
        # For now, assume the revised solution is final
        final_solution = revised_solution
        
        return final_solution