# Workflow ID: humaneval_109_0
# Benchmark: humaneval
# Data Indices: [36]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="""
            Extract ONLY the function name from the provided function signature.
            Return just the name, nothing else. For example, if the signature is 'def fizz_buzz(n: int):',
            return 'fizz_buzz'.
            """,
            context=""
        )
        
        # Step 2: Analyze the docstring examples
        analysis = await self.generate(
            instruction=f"""
            Analyze the docstring and examples carefully for the function '{func_name}':
            1. What pattern do the examples show? Describe the mathematical or logical relationship.
            2. What are the edge cases? List them explicitly.
            3. What is the expected return type (int, float, list, etc.) based on the examples?
            Return a brief analysis in 2-3 sentences, focusing on the key insights needed to implement the function.
            """,
            context=""
        )
        
        # Step 3: Generate the solution code
        solution = await self.generate(
            instruction=f"""
            Implement the function '{func_name}' based on the following analysis:
            Analysis: {analysis}
            
            Requirements:
            1. Follow the EXACT function signature provided in the problem text.
            2. Implement the logic that satisfies ALL examples in the docstring.
            3. Handle edge cases shown in examples.
            4. Return the correct type (int, float, list, etc.) as shown in examples.
            5. Include any necessary imports at the top of the function.
            6. Return ONLY the Python code, no explanations.
            """,
            context=""
        )
        
        # Return the final solution
        return solution