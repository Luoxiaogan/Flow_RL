# Workflow ID: humaneval_55_0
# Benchmark: humaneval
# Data Indices: [74, 66]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract ONLY the function name from the def statement. "
                        "Return just the name, nothing else.",
            context=""
        )
        
        # Step 2: Analyze the docstring examples
        analysis = await self.generate(
            instruction="Analyze the docstring and examples carefully:\n"
                        "1. What pattern do the examples show?\n"
                        "2. What are the edge cases?\n"
                        "3. What is the expected return type?\n"
                        "Return a brief analysis in 2-3 sentences.",
            context=""
        )
        
        # Step 3: Generate the solution code
        solution = await self.generate(
            instruction=f"Implement the function '{func_name}' based on the docstring specification.\n"
                        f"Analysis: {analysis}\n\n"
                        "Requirements:\n"
                        "1. Follow the EXACT function signature provided.\n"
                        "2. Implement the logic that satisfies ALL examples in the docstring.\n"
                        "3. Handle edge cases shown in examples.\n"
                        "4. Return the correct type (int, float, list, etc.) as shown in examples.\n"
                        "5. Include any necessary imports at the top.\n"
                        "6. Return ONLY the Python code, no explanations.",
            context=""
        )
        
        # Step 4: Revise the solution for accuracy
        revised_solution = await self.revise(
            instruction="Review the solution and ensure it meets the following criteria:\n"
                        "1. Matches the function signature exactly.\n"
                        "2. Implements the logic correctly based on the docstring examples.\n"
                        "3. Handles all edge cases.\n"
                        "4. Returns the correct type.\n"
                        "If any issues are found, revise the code accordingly.",
            context=solution
        )
        
        return revised_solution