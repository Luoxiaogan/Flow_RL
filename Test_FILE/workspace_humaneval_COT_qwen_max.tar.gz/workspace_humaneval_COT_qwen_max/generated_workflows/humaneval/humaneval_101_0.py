# Workflow ID: humaneval_101_0
# Benchmark: humaneval
# Data Indices: [98, 117]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        import json  # For parsing JSON if needed
        import re    # For regex operations if needed
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract ONLY the function name from the def statement in the problem text. Return just the name, nothing else.",
            context=""
        )
        
        # Step 2: Analyze the docstring examples
        analysis = await self.generate(
            instruction="""
            Analyze the docstring and examples carefully:
            1. What pattern do the examples show?
            2. What are the edge cases?
            3. What is the expected return type?
            Return a brief analysis in 2-3 sentences.
            """,
            context=""
        )
        
        # Step 3: Generate the initial solution
        initial_solution = await self.generate(
            instruction=f"""
            Implement the function '{func_name}' based on the docstring specification.
            Analysis: {analysis}
            
            Requirements:
            1. Follow the EXACT function signature provided
            2. Implement the logic that satisfies ALL examples in the docstring
            3. Handle edge cases shown in examples
            4. Return the correct type (int, float, list, etc.) as shown in examples
            5. Include any necessary imports at the top
            6. Return ONLY the Python code, no explanations
            """,
            context=""
        )
        
        # Step 4: Revise the solution for correctness
        revised_solution = await self.revise(
            instruction="""
            Review the provided solution for correctness:
            1. Does it match the function signature exactly?
            2. Does it handle all examples and edge cases from the docstring?
            3. Is the return type consistent with the examples?
            4. Are there any syntax or logical errors?
            Return the corrected Python code ONLY.
            """,
            context=initial_solution
        )
        
        # Step 5: Ensemble for final decision (optional, if multiple solutions are generated)
        final_solution = await self.ensemble(
            instruction="""
            Evaluate the provided solutions and select the best one:
            1. Which solution adheres most closely to the docstring specification?
            2. Which solution handles edge cases most effectively?
            3. Which solution is the most efficient and readable?
            Return the selected Python code ONLY.
            """,
            contexts=[revised_solution]  # Add more solutions here if applicable
        )
        
        return final_solution