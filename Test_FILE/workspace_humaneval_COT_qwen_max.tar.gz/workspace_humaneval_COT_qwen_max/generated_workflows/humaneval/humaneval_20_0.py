# Workflow ID: humaneval_20_0
# Benchmark: humaneval
# Data Indices: [24, 94]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        import json  # For parsing structured data if needed

        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract ONLY the function name from the def statement. Return just the name, nothing else.",
            context=""
        )
        func_name = func_name.strip()  # Remove any extra whitespace

        # Step 2: Analyze the docstring examples
        analysis = await self.generate(
            instruction="""
            Analyze the docstring and examples carefully:
            1. What pattern do the examples show?
            2. What are the edge cases?
            3. What is the expected return type?
            Return a brief analysis in 2-3 sentences.
            """,
            context=""
        )

        # Step 3: Generate the initial solution
        solution = await self.generate(
            instruction=f"""
            Implement the function '{func_name}' based on the docstring specification.
            Analysis: {analysis}
            
            Requirements:
            1. Follow the EXACT function signature provided
            2. Implement the logic that satisfies ALL examples in the docstring
            3. Handle edge cases shown in examples
            4. Return the correct type (int, float, list, etc.) as shown in examples
            5. Include any necessary imports at the top
            6. Return ONLY the Python code, no explanations
            """,
            context=""
        )

        # Step 4: Revise the solution
        revised_solution = await self.revise(
            instruction="""
            Critique and refine the provided solution:
            1. Ensure all examples in the docstring are satisfied
            2. Handle edge cases correctly
            3. Match the expected return type
            Return the improved Python code.
            """,
            context=solution
        )

        # Optional Step 5: Ensemble multiple approaches (if needed)
        # Uncomment the following block for complex problems
        """
        results = await asyncio.gather(
            self.generate(instruction="Alternative approach 1...", context=""),
            self.generate(instruction="Alternative approach 2...", context="")
        )
        final_solution = await self.ensemble(
            instruction="Select the best solution that satisfies all requirements.",
            contexts=results
        )
        """

        # Step 6: Return the final solution
        return revised_solution.strip()