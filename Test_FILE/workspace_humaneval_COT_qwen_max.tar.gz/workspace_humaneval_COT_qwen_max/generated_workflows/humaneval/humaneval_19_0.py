# Workflow ID: humaneval_19_0
# Benchmark: humaneval
# Data Indices: [149, 126]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="""
            Extract ONLY the function name from the provided function signature.
            Return just the name, nothing else. For example, if the signature is
            'def sorted_list_sum(lst):', return 'sorted_list_sum'.
            """,
            context=""
        )
        
        # Step 2: Analyze the docstring examples and requirements
        analysis = await self.generate(
            instruction="""
            Analyze the docstring carefully:
            1. What is the main task or pattern described?
            2. What are the edge cases or special conditions?
            3. What is the expected return type and format?
            Return a concise analysis in 2-3 sentences.
            """,
            context=""
        )
        
        # Step 3: Generate the initial solution code
        solution = await self.generate(
            instruction=f"""
            Implement the function '{func_name}' based on the following analysis:
            {analysis}
            
            Requirements:
            1. Follow the EXACT function signature provided in the problem text.
            2. Implement the logic that satisfies ALL examples in the docstring.
            3. Handle edge cases shown in examples.
            4. Return the correct type (int, float, list, etc.) as shown in examples.
            5. Include any necessary imports at the top.
            6. Return ONLY the Python code, no explanations.
            """,
            context=""
        )
        
        # Step 4: Revise the solution for correctness and completeness
        revised_solution = await self.revise(
            instruction=f"""
            Critique and refine the following implementation of '{func_name}':
            {solution}
            
            Focus on:
            1. Ensuring compliance with the docstring specification.
            2. Handling edge cases explicitly mentioned or implied in examples.
            3. Matching the expected return type (e.g., int, float, list).
            Return the revised Python code ONLY, no explanations.
            """,
            context=solution
        )
        
        return revised_solution