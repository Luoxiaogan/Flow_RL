# Workflow ID: humaneval_52_0
# Benchmark: humaneval
# Data Indices: [142]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract ONLY the function name from the def statement. "
                        "Return just the name, nothing else.",
            context=""
        )
        
        # Step 2: Analyze the docstring for logic and edge cases
        analysis = await self.generate(
            instruction="""
            Analyze the docstring carefully:
            1. What is the main logic or pattern described in the examples?
            2. What are the edge cases mentioned or implied?
            3. What is the expected return type (int, float, list, etc.)?
            Return a brief analysis in 2-3 sentences.
            """,
            context=""
        )
        
        # Step 3: Generate the initial solution
        initial_solution = await self.generate(
            instruction=f"""
            Implement the function '{func_name}' based on the docstring specification.
            Analysis: {analysis}
            
            Requirements:
            1. Follow the EXACT function signature provided in the problem text.
            2. Implement the logic that satisfies ALL examples in the docstring.
            3. Handle edge cases shown in examples.
            4. Return the correct type (int, float, list, etc.) as shown in examples.
            5. Include any necessary imports at the top.
            6. Return ONLY the Python code, no explanations.
            """,
            context=""
        )
        
        # Step 4: Revise the solution for accuracy and completeness
        revised_solution = await self.revise(
            instruction="""
            Critique and improve the provided implementation:
            1. Ensure it matches the docstring specification exactly.
            2. Verify all edge cases are handled correctly.
            3. Check for any logical or syntax errors.
            4. Return the revised Python code ONLY, no explanations.
            """,
            context=initial_solution
        )
        
        # Step 5: Return the final solution
        return revised_solution