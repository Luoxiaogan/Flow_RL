# Workflow ID: humaneval_85_0
# Benchmark: humaneval
# Data Indices: [136]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract ONLY the function name from the provided function signature. "
                        "Return just the name, nothing else.",
            context=""
        )
        
        # Step 2: Analyze the docstring examples
        analysis = await self.generate(
            instruction="""
            Analyze the docstring and examples carefully:
            1. What pattern do the examples show?
            2. What are the edge cases?
            3. What is the expected return type?
            Return a brief analysis in 2-3 sentences.
            """,
            context=""
        )
        
        # Step 3: Generate the solution code
        solution = await self.generate(
            instruction=f"""
            Implement the function '{func_name}' based on the docstring specification.
            Analysis: {analysis}
            
            Requirements:
            1. Follow the EXACT function signature provided in the problem text.
            2. Implement the logic that satisfies ALL examples in the docstring.
            3. Handle edge cases shown in examples (e.g., empty input, no matching elements).
            4. Return the correct type (tuple, list, int, float, etc.) as shown in examples.
            5. Include any necessary imports at the top of the function.
            6. Return ONLY the Python code, no explanations.
            """,
            context=""
        )
        
        # Step 4 (Optional): Revise the solution for correctness
        revised_solution = await self.revise(
            instruction="""
            Review the generated code for correctness:
            1. Does it handle all edge cases mentioned in the docstring?
            2. Does it follow the exact function signature?
            3. Does it return the correct types as shown in examples?
            Make any necessary corrections and return the revised code.
            """,
            context=solution
        )
        
        # Final Output: Return the revised solution (or original if revision is skipped)
        return revised_solution