# Workflow ID: humaneval_61_0
# Benchmark: humaneval
# Data Indices: [67]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        import re  # For parsing numeric values from the docstring examples

        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract ONLY the function name from the def statement. "
                        "Return just the name, nothing else.",
            context=""
        )
        func_name = func_name.strip()  # Remove any leading/trailing whitespace

        # Step 2: Analyze the docstring examples
        analysis = await self.generate(
            instruction="""
            Analyze the docstring and examples carefully:
            1. What pattern do the examples show? (e.g., mathematical operations, transformations)
            2. What are the edge cases? (e.g., zero values, large numbers)
            3. What is the expected return type? (int, float, list, etc.)
            Return a brief analysis in 2-3 sentences.
            """,
            context=""
        )
        analysis = analysis.strip()

        # Step 3: Generate the initial solution
        solution = await self.generate(
            instruction=f"""
            Implement the function '{func_name}' based on the docstring specification.
            Analysis: {analysis}
            
            Requirements:
            1. Follow the EXACT function signature provided
            2. Implement the logic that satisfies ALL examples in the docstring
            3. Handle edge cases shown in examples (e.g., zero values, large numbers)
            4. Return the correct type (int, float, list, etc.) as shown in examples
            5. Include any necessary imports at the top
            6. Return ONLY the Python code, no explanations
            """,
            context=""
        )

        # Step 4: Revise the solution for correctness
        revised_solution = await self.revise(
            instruction=f"""
            Review and improve the following implementation of '{func_name}':
            - Ensure it follows the docstring specification exactly
            - Verify that all examples in the docstring are handled correctly
            - Check for edge cases and ensure they are addressed
            - Optimize for clarity and correctness
            
            Original Implementation:
            {solution}
            
            Return the revised implementation as Python code. Do not include explanations.
            """,
            context=""
        )

        # Step 5: Return the final solution
        return revised_solution.strip()