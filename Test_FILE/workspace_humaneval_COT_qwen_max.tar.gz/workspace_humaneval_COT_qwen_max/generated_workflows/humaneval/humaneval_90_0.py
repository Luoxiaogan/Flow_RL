# Workflow ID: humaneval_90_0
# Benchmark: humaneval
# Data Indices: [10]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        import json  # For parsing structured data if needed

        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract ONLY the function name from the provided function signature. "
                        "Return just the name, nothing else.",
            context=""
        ).strip()

        # Step 2: Analyze the docstring and examples
        analysis = await self.generate(
            instruction=f"""
            Analyze the docstring and examples carefully for the function '{func_name}':
            1. What pattern or algorithm do the examples show?
            2. What are the edge cases?
            3. What is the expected return type (e.g., bool, str, int)?
            Return a brief analysis in 2-3 sentences.
            """,
            context=""
        ).strip()

        # Step 3: Generate the initial solution
        initial_solution = await self.generate(
            instruction=f"""
            Implement the function '{func_name}' based on the docstring specification.
            Analysis: {analysis}
            
            Requirements:
            1. Follow the EXACT function signature provided in the problem.
            2. Implement the logic that satisfies ALL examples in the docstring.
            3. Handle edge cases shown in examples.
            4. Return the correct type (int, float, list, etc.) as shown in examples.
            5. Include any necessary imports at the top.
            6. Return ONLY the Python code, no explanations.
            """,
            context=""
        ).strip()

        # Step 4: Refine the solution
        refined_solution = await self.revise(
            instruction=f"""
            Critique and improve the following implementation of '{func_name}':
            - Ensure correctness based on the docstring examples.
            - Handle implicit edge cases not explicitly mentioned.
            - Optimize performance if necessary.
            Return the improved Python code ONLY.
            """,
            context=initial_solution
        ).strip()

        # Step 5: Validate and finalize the solution
        final_solution = await self.ensemble(
            instruction=f"""
            Evaluate the following candidate solutions for '{func_name}':
            1. Initial Solution: {initial_solution}
            2. Refined Solution: {refined_solution}
            Select the best solution that satisfies ALL requirements in the docstring.
            Return the selected Python code ONLY.
            """,
            contexts=[initial_solution, refined_solution]
        ).strip()

        return final_solution