# Workflow ID: humaneval_69_0
# Benchmark: humaneval
# Data Indices: [34, 58]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract function name and signature
        func_name_and_signature = await self.generate(
            instruction="""
            Extract ONLY the function name and signature from the provided problem text.
            Return the result in the format:
            "def function_name(parameters):"
            """,
            context=""
        )
        
        # Step 2: Analyze the docstring
        analysis = await self.generate(
            instruction="""
            Analyze the docstring and examples carefully:
            1. What pattern do the examples show?
            2. What are the edge cases?
            3. What is the expected return type?
            Return a brief analysis in 2-3 sentences.
            """,
            context=""
        )
        
        # Step 3: Generate initial solution
        initial_solution = await self.generate(
            instruction=f"""
            Implement the function '{func_name_and_signature}' based on the docstring specification.
            Analysis: {analysis}
            
            Requirements:
            1. Follow the EXACT function signature provided
            2. Implement the logic that satisfies ALL examples in the docstring
            3. Handle edge cases shown in examples
            4. Return the correct type (int, float, list, etc.) as shown in examples
            5. Include any necessary imports at the top
            6. Return ONLY the Python code, no explanations
            """,
            context=""
        )
        
        # Step 4: Revise the solution
        revised_solution = await self.revise(
            instruction="""
            Critique and refine the provided solution:
            1. Ensure all examples in the docstring are satisfied
            2. Handle edge cases explicitly
            3. Match the exact format of the return type
            Return the improved Python code ONLY, no explanations.
            """,
            context=initial_solution
        )
        
        # Step 5: Return the final solution
        return revised_solution