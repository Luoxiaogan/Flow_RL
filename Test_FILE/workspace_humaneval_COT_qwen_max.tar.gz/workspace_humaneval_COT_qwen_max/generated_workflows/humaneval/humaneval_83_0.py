# Workflow ID: humaneval_83_0
# Benchmark: humaneval
# Data Indices: [14, 78]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        import json  # For parsing structured data if necessary
        import re    # For regex operations if needed
        
        # Step 1: Extract function name
        func_name = await self.generate(
            instruction="Extract ONLY the function name from the def statement. Return just the name, nothing else.",
            context=""
        )
        func_name = func_name.strip()  # Remove any leading/trailing whitespace

        # Step 2: Analyze the docstring examples
        analysis = await self.generate(
            instruction="""
            Analyze the docstring and examples carefully:
            1. What pattern do the examples show?
            2. What are the edge cases?
            3. What is the expected return type?
            Return a brief analysis in 2-3 sentences.
            """,
            context=""
        )
        analysis = analysis.strip()

        # Step 3: Generate initial solution
        initial_solution = await self.generate(
            instruction=f"""
            Implement the function '{func_name}' based on the docstring specification.
            Analysis: {analysis}
            
            Requirements:
            1. Follow the EXACT function signature provided
            2. Implement the logic that satisfies ALL examples in the docstring
            3. Handle edge cases shown in examples
            4. Return the correct type (int, float, list, etc.) as shown in examples
            5. Include any necessary imports at the top
            6. Return ONLY the Python code, no explanations
            """,
            context=""
        )

        # Step 4: Revise the solution
        revised_solution = await self.revise(
            instruction="""
            Critique and improve the following implementation:
            1. Ensure it matches the docstring specification exactly
            2. Fix any logical errors or missing edge cases
            3. Optimize for clarity and correctness
            Return the revised implementation as Python code.
            """,
            context=initial_solution
        )

        # Step 5: Summarize key insights
        summary = await self.summarize(
            instruction="Summarize the key insights from the analysis and revision steps.",
            context=revised_solution
        )

        # Step 6: Finalize the solution
        final_solution = await self.generate(
            instruction=f"""
            Based on the revised implementation and summary, finalize the solution.
            Summary: {summary}
            Revised Implementation: {revised_solution}
            
            Return ONLY the final Python code, ensuring it is complete and executable.
            """,
            context=""
        )

        return final_solution