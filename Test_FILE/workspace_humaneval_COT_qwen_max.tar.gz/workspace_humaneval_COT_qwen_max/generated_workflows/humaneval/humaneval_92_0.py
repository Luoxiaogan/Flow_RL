# Workflow ID: humaneval_92_0
# Benchmark: humaneval
# Data Indices: [115, 104]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        """
        import asyncio
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract ONLY the function name from the def statement. Return just the name, nothing else.",
            context=""
        )
        
        # Step 2: Analyze the docstring examples
        analysis = await self.generate(
            instruction="""
            Analyze the docstring and examples carefully:
            1. What pattern do the examples show?
            2. What are the edge cases?
            3. What is the expected return type?
            Return a brief analysis in 2-3 sentences.
            """,
            context=""
        )
        
        # Step 3: Generate the initial solution
        initial_solution = await self.generate(
            instruction=f"""
            Implement the function '{func_name}' based on the docstring specification.
            Analysis: {analysis}
            
            Requirements:
            1. Follow the EXACT function signature provided
            2. Implement the logic that satisfies ALL examples in the docstring
            3. Handle edge cases shown in examples
            4. Return the correct type (int, float, list, etc.) as shown in examples
            5. Include any necessary imports at the top
            6. Return ONLY the Python code, no explanations
            """,
            context=""
        )
        
        # Step 4: Revise the solution
        final_solution = await self.revise(
            instruction=f"""
            Critique and refine the following implementation of '{func_name}':
            - Ensure correctness against all examples in the docstring
            - Improve clarity and efficiency
            - Fix any type mismatches or logical flaws
            
            Return the revised implementation as Python code ONLY.
            """,
            context=initial_solution
        )
        
        return final_solution