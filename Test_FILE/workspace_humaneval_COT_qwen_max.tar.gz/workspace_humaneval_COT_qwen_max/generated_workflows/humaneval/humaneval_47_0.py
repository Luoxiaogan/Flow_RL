# Workflow ID: humaneval_47_0
# Benchmark: humaneval
# Data Indices: [20]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract function name
        func_name = await self.generate(
            instruction="Extract ONLY the function name from the def statement. Return just the name, nothing else.",
            context=""
        )
        
        # Step 2: Analyze the docstring examples
        analysis = await self.generate(
            instruction="""
            Analyze the docstring and examples carefully:
            1. What pattern do the examples show?
            2. What are the edge cases?
            3. What is the expected return type?
            Return a brief analysis in 2-3 sentences.
            """,
            context=""
        )
        
        # Step 3: Generate initial solution
        initial_solution = await self.generate(
            instruction=f"""
            Implement the function '{func_name}' based on the docstring specification.
            Analysis: {analysis}
            
            Requirements:
            1. Follow the EXACT function signature provided
            2. Implement the logic that satisfies ALL examples in the docstring
            3. Handle edge cases shown in examples
            4. Return the correct type (int, float, list, etc.) as shown in examples
            5. Include any necessary imports at the top
            6. Return ONLY the Python code, no explanations
            """,
            context=""
        )
        
        # Step 4: Revise for robustness
        revised_solution = await self.revise(
            instruction=f"""
            Critique and improve the following implementation:
            {initial_solution}
            
            Focus on:
            1. Correctness of logic
            2. Handling of edge cases
            3. Alignment with docstring examples
            4. Return type consistency
            Return the revised code ONLY.
            """,
            context=initial_solution
        )
        
        # Step 5: Ensemble for final validation
        final_solution = await self.ensemble(
            instruction=f"""
            Evaluate and select the best implementation from the candidates below:
            Candidate 1: {initial_solution}
            Candidate 2: {revised_solution}
            
            Criteria:
            1. Adherence to docstring specification
            2. Correctness of logic
            3. Handling of edge cases
            4. Return type consistency
            Return the final code ONLY.
            """,
            contexts=[initial_solution, revised_solution]
        )
        
        return final_solution