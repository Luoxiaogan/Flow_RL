# Workflow ID: humaneval_12_0
# Benchmark: humaneval
# Data Indices: [41]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implements the core problem-solving logic for HumanEval problems.
        """
        import asyncio
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract ONLY the function name from the def statement in the problem text. "
                        "Return just the name, nothing else.",
            context=""
        )
        func_name = func_name.strip()  # Clean up whitespace

        # Step 2: Analyze the docstring examples
        analysis = await self.generate(
            instruction=f"""
            Analyze the docstring of the function '{func_name}' in the problem text:
            1. What pattern or mathematical relationship do the examples show?
            2. What are the edge cases mentioned or implied?
            3. What is the expected return type (int, float, list, etc.)?
            Return a brief analysis in 2-3 sentences.
            """,
            context=""
        )

        # Step 3: Generate the solution code
        solution = await self.generate(
            instruction=f"""
            Implement the function '{func_name}' based on the docstring specification.
            Analysis: {analysis}
            
            Requirements:
            1. Follow the EXACT function signature provided in the problem text.
            2. Implement the logic that satisfies ALL examples in the docstring.
            3. Handle edge cases shown in examples.
            4. Return the correct type (int, float, list, etc.) as shown in examples.
            5. Include any necessary imports at the top.
            6. Return ONLY the Python code, no explanations.
            """,
            context=""
        )

        # Step 4: Revise the solution for robustness
        revised_solution = await self.revise(
            instruction=f"""
            Critique and improve the following implementation of '{func_name}':
            - Ensure it follows the docstring specification exactly.
            - Verify that all edge cases are handled.
            - Optimize for clarity and correctness.
            Return the improved Python code. Do not include explanations.
            """,
            context=solution
        )

        # Step 5: Return the final solution
        return revised_solution.strip()