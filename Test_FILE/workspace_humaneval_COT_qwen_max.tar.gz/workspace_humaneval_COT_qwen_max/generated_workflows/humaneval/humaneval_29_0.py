# Workflow ID: humaneval_29_0
# Benchmark: humaneval
# Data Indices: [81]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio

        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="Extract ONLY the function name from the def statement. Return just the name, nothing else.",
            context=""
        )

        # Step 2: Analyze the docstring to understand the problem
        analysis = await self.generate(
            instruction="""
            Analyze the docstring carefully:
            1. What is the mapping between inputs and outputs?
            2. What are the edge cases (e.g., boundary values)?
            3. What is the expected return type?
            Return a brief analysis in 2-3 sentences.
            """,
            context=""
        )

        # Step 3: Generate the initial solution
        solution = await self.generate(
            instruction=f"""
            Implement the function '{func_name}' based on the docstring specification.
            Analysis: {analysis}
            
            Requirements:
            1. Follow the EXACT function signature provided
            2. Implement the logic that satisfies ALL examples in the docstring
            3. Handle edge cases shown in examples
            4. Return the correct type (list of strings in this case)
            5. Include any necessary imports at the top
            6. Return ONLY the Python code, no explanations
            """,
            context=""
        )

        # Step 4: Revise the solution to ensure correctness
        revised_solution = await self.revise(
            instruction="""
            Critique and refine the following code:
            - Ensure it matches the docstring specification
            - Handle all edge cases
            - Optimize for clarity and correctness
            Return the improved code ONLY.
            """,
            context=solution
        )

        # Step 5: Return the final solution
        return revised_solution