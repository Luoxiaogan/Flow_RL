# Workflow ID: humaneval_82_0
# Benchmark: humaneval
# Data Indices: [83]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio
        
        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="""
            Extract ONLY the function name from the provided function signature.
            Return just the name as a plain string, without any additional text or quotes.
            """,
            context=""
        )
        
        # Step 2: Analyze the docstring and examples
        analysis = await self.generate(
            instruction="""
            Analyze the docstring and examples carefully:
            1. What pattern or logic do the examples demonstrate?
            2. What are the edge cases mentioned or implied?
            3. What is the expected return type (e.g., int, float, list)?
            Return a brief analysis in 2-3 sentences.
            """,
            context=""
        )
        
        # Step 3: Generate the solution code
        solution = await self.generate(
            instruction=f"""
            Implement the function '{func_name}' based on the following analysis:
            {analysis}
            
            Requirements:
            1. Follow the EXACT function signature provided in the problem.
            2. Implement the logic that satisfies ALL examples in the docstring.
            3. Handle edge cases shown in examples.
            4. Return the correct type (int, float, list, etc.) as shown in examples.
            5. Include any necessary imports at the top of the function.
            6. Return ONLY the Python code, without any explanations or additional text.
            """,
            context=""
        )
        
        # Optional Step 4: Revise the solution for clarity or performance
        revised_solution = await self.revise(
            instruction="""
            Review the provided solution and make improvements if necessary:
            1. Ensure the logic is clear and efficient.
            2. Verify adherence to the docstring specification.
            3. Optimize performance if possible.
            Return the revised solution as Python code.
            """,
            context=solution
        )
        
        # Step 5: Return the final solution
        final_solution = revised_solution.strip() if revised_solution else solution.strip()
        return final_solution