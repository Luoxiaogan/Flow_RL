# Workflow ID: humaneval_7_0
# Benchmark: humaneval
# Data Indices: [26, 51]

class Workflow:
    def __init__(self, config, problem) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem
        self.llm = create(config)
        
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        Implement the core problem-solving logic here.
        Remember: 
        - ALL operators return STRINGS
        - Import modules (json, re, etc.) at the beginning
        - Use detailed, comprehensive instructions
        - Parse JSON with json.loads() if needed
        """
        import asyncio

        # Step 1: Extract the function name
        func_name = await self.generate(
            instruction="""
            Extract ONLY the function name from the provided function signature.
            Return just the name as a plain string, without any additional text or quotes.
            """,
            context=""
        )

        # Step 2: Analyze the docstring examples
        analysis = await self.generate(
            instruction="""
            Analyze the docstring and examples carefully:
            1. Identify the pattern or logic described in the examples.
            2. List any edge cases mentioned or implied in the examples.
            3. Determine the expected return type (e.g., int, float, list, string).
            Return a brief analysis in 2-3 sentences.
            """,
            context=""
        )

        # Step 3: Generate the solution code
        solution = await self.generate(
            instruction=f"""
            Implement the function '{func_name}' based on the docstring specification.
            Analysis: {analysis}
            
            Requirements:
            1. Follow the EXACT function signature provided in the problem.
            2. Implement the logic that satisfies ALL examples in the docstring.
            3. Handle edge cases shown in examples.
            4. Return the correct type (int, float, list, etc.) as shown in examples.
            5. Include any necessary imports at the top of the code.
            6. Return ONLY the Python code, without any explanations or additional text.
            """,
            context=""
        )

        # Step 4: Revise the solution for correctness and robustness
        revised_solution = await self.revise(
            instruction="""
            Review and improve the provided solution:
            1. Ensure it adheres to the docstring specification.
            2. Verify that all examples in the docstring are handled correctly.
            3. Check for edge cases and ensure they are addressed.
            4. Confirm the return type matches the expected format.
            Return the revised Python code as a plain string.
            """,
            context=solution
        )

        # Step 5: Return the final solution
        return revised_solution