# Workflow ID: drop_79_0
# Benchmark: drop
# Data Indices: [66, 354]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Initial breakdown of the problem
        initial_thought = await self.custom(instruction="Identify what needs to be extracted from the passage and what kind of reasoning (counting, arithmetic, comparison) is required.")

        # Step 2: Use flexible custom to guide structured reasoning based on problem type
        reasoning_pattern = "Extract relevant numbers → Determine operation → Compute result"
        steps = [
            {"name": "extract", "instruction": "Find all numeric values or counts mentioned in the passage relevant to the question."},
            {"name": "reason", "instruction": "Determine whether this is a counting, arithmetic, or comparison task."},
            {"name": "compute", "instruction": "Perform the necessary calculation using the extracted values."}
        ]
        structured_solution = await self.flexible_custom(
            reasoning_pattern=reasoning_pattern,
            steps=steps,
            custom_instruction="Solve the problem step-by-step by extracting, reasoning, and computing."
        )

        # Step 3: Review the solution for correctness and clarity
        refined_solution = await self.review(pre_solution=structured_solution)

        # Step 4: Final output — return the best answer
        return refined_solution