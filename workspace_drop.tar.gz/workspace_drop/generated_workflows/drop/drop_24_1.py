# Workflow ID: drop_24_1
# Benchmark: drop
# Data Indices: [344, 172]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Strategy: Use parallel reasoning paths — generate multiple distinct solutions first,
        # then review each one individually, and finally use ensemble voting to select the most consistent answer.
        
        # Step 1: Generate three different reasoning paths using diverse instructions
        solution1 = await self.custom(instruction="First approach: Extract all relevant numbers from the passage and identify what operation (count, sum, difference) must be performed.")
        solution2 = await self.custom(instruction="Second approach: Identify key phrases like 'how many', 'increase', or 'more than' to determine the type of reasoning needed, then solve accordingly.")
        solution3 = await self.flexible_custom(
            steps=[
                {"name": "parse_passage", "instruction": "Identify all numeric values and their context in the passage."},
                {"name": "determine_task", "instruction": "Based on the question, decide whether it's a counting, arithmetic, or comparison task."},
                {"name": "solve", "instruction": "Use the appropriate expert operator to compute the result."}
            ],
            reasoning_pattern="sequential",
            custom_instruction="Now execute the structured plan to produce a final answer."
        )

        # Step 2: Review each solution independently to improve quality
        reviewed_solution1 = await self.review(pre_solution=solution1)
        reviewed_solution2 = await self.review(pre_solution=solution2)
        reviewed_solution3 = await self.review(pre_solution=solution3)

        # Step 3: Use ScEnsemble to choose the most consistent answer across all reviewed solutions
        final_answer = await self.sc_ensemble(solutions=[reviewed_solution1, reviewed_solution2, reviewed_solution3])
        
        return final_answer