# Workflow ID: drop_173_1
# Benchmark: drop
# Data Indices: [225, 240]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Strategy: First, extract all scoring events using a flexible custom step to identify key numbers
        extraction_step = await self.flexible_custom(
            reasoning_pattern="extract_and_label",
            steps=[
                "Identify every scoring event in the passage (e.g., touchdowns, field goals, extra points).",
                "For each, extract the point value and the time or context it occurred.",
                "List all scores as structured data like: [ {'type': 'field_goal', 'points': 3, 'quarter': '1st'}, ... ]"
            ],
            custom_instruction="Extract all scoring events from the passage with their point values."
        )

        # Then, use ArithmeticReasoning to sum up the total points — this is more direct than reviewing later
        arithmetic_result = await self.arithmetic_reasoning()

        # Now, instead of just reviewing, we perform an ensemble by generating a second solution via counting
        # This introduces parallel reasoning paths: one arithmetic, one counting-based verification
        counting_result = await self.counting_reasoning()

        # Use ScEnsemble to resolve discrepancies between the two strategies
        final_answer = await self.sc_ensemble(solutions=[arithmetic_result, counting_result])

        return final_answer