# Workflow ID: drop_111_0
# Benchmark: drop
# Data Indices: [239, 398]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify required reasoning type
        initial_thought = await self.custom(instruction="First, analyze the question to determine what kind of reasoning is needed: counting, arithmetic, comparison, or span extraction.")
        
        # Step 2: Extract relevant information from the passage based on the question
        extraction = await self.custom(instruction=f"Based on the question and initial thought: {initial_thought}, extract all relevant entities, events, or numerical data from the passage that pertain to the task.")

        # Step 3: Apply specialized reasoning based on the identified task type
        if "which player scored first" in initial_thought.lower():
            # For questions about first-scoring player → need to find the earliest event
            result = await self.comparison_reasoning()
        elif "how many field goals" in initial_thought.lower() or "more field goals" in initial_thought.lower():
            # For counting or comparing field goals → use counting + comparison
            count_saints = await self.counting_reasoning()
            count_eagles = await self.counting_reasoning()
            result = await self.comparison_reasoning()
        elif "sum", "difference", "total", "how much more" in initial_thought.lower():
            # For arithmetic tasks like totals, differences
            result = await self.arithmetic_reasoning()
        else:
            # General case: fallback to custom reasoning for complex spans or logic
            result = await self.custom(instruction="Use step-by-step reasoning to derive the final answer based on extracted information.")

        # Step 4: Refine solution with review
        refined_result = await self.review(pre_solution=result)

        # Step 5: Use ensemble if multiple solutions were generated during process (optional but robust)
        # In this template, we assume one primary path — but future enhancements could involve SC Ensemble
        return refined_result