# Workflow ID: drop_126_1
# Benchmark: drop
# Data Indices: [356, 146]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom with a parallel reasoning pattern to explore multiple strategies simultaneously
        parallel_solutions = await self.flexible_custom(
            reasoning_pattern="parallel",
            steps=[
                "Apply counting reasoning to extract numerical quantities relevant to the question.",
                "Apply arithmetic reasoning to compute totals, differences, or averages as needed.",
                "Apply comparison reasoning to evaluate relative magnitudes or orderings."
            ],
            custom_instruction="Generate three potential solutions using different reasoning types in parallel."
        )

        # Step 2: Evaluate all generated solutions via ensemble — this is the key difference from the original
        # Instead of fixing one solution first, we immediately vote on all candidates
        final_result = await self.sc_ensemble(solutions=[parallel_solutions])

        # Step 3: Optional refinement — review the best-consensus answer to ensure clarity and correctness
        refined_final = await self.review(pre_solution=final_result)

        return refined_final