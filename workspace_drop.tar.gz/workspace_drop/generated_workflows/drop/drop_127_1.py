# Workflow ID: drop_127_1
# Benchmark: drop
# Data Indices: [125, 128]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to define a multi-step reasoning pattern
        # This step uses structured logic without explicit Python control flow — a fundamentally different approach
        flexible_solution = await self.flexible_custom(
            reasoning_pattern="Extract relevant numbers → Compare them → Select the best answer",
            steps=[
                {"name": "extract", "instruction": "Identify all numerical values mentioned in the passage that could be relevant to the question."},
                {"name": "compare", "instruction": "Rank or sort these numbers based on their relevance and magnitude. If multiple match the question's criteria, select the most appropriate one."},
                {"name": "finalize", "instruction": "Based on the comparison, return the final answer as a number, date, or span of text."}
            ],
            custom_instruction="Use this structured plan to solve the problem step-by-step."
        )

        # Step 2: Generate a second solution using a different strategy — directly call ComparisonReasoning
        comparison_solution = await self.comparison_reasoning()

        # Step 3: Review the flexible solution to improve clarity and correctness before ensemble
        reviewed_solution = await self.review(pre_solution=flexible_solution)

        # Step 4: Use ScEnsemble to choose between the two distinct approaches:
        # - One uses structured logic via FlexibleCustom (no explicit loops or conditionals)
        # - The other uses a specialized expert (ComparisonReasoning) designed for sorting/comparison tasks
        final_answer = await self.sc_ensemble(solutions=[reviewed_solution, comparison_solution])

        return final_answer