# Workflow ID: drop_120_1
# Benchmark: drop
# Data Indices: [347, 168]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to define a multi-step reasoning plan
        # This strategy uses structured logic to first extract relevant events,
        # then count them based on explicit indicators (e.g., "missed", "made")
        reasoning_plan = [
            {"step": "Identify all mentions of field goals in the passage"},
            {"step": "Classify each as attempted or successful"},
            {"step": "Count those that were missed"},
        ]
        
        # Execute the plan using flexible_custom with clear reasoning pattern
        structured_response = await self.flexible_custom(
            steps=reasoning_plan,
            reasoning_pattern="chain_of_thought",
            custom_instruction="Extract and classify all field goal events in the text."
        )

        # Step 2: Use ComparisonReasoning to identify and isolate "missed" field goals
        comparison_result = await self.comparison_reasoning()

        # Step 3: Use CountingReasoning to count the number of missed field goals
        counting_result = await self.counting_reasoning()

        # Step 4: Combine insights into a single solution via Custom
        final_solution = await self.custom(
            instruction=f"Based on the structured analysis: {structured_response}, "
                        f"comparison result: {comparison_result}, and counting result: {counting_result}, "
                        f"generate the final answer to the question."
        )

        # Step 5: Use ScEnsemble to validate against an alternative approach
        # Generate a second solution using direct extraction + arithmetic
        direct_extraction = await self.custom(instruction="Extract all field goal attempts and misses directly from the passage.")
        arithmetic_check = await self.arithmetic_reasoning()
        
        # Ensemble both solutions to improve robustness
        final_answer = await self.sc_ensemble(solutions=[final_solution, direct_extraction, arithmetic_check])

        return final_answer