# Workflow ID: drop_19_1
# Benchmark: drop
# Data Indices: [375, 189]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to define a multi-step reasoning pattern that first identifies the task type
        # and then selects the appropriate expert operator dynamically — this replaces the conditional branching
        reasoning_pattern = [
            {"step": "Identify whether the question involves counting, arithmetic, or comparison."},
            {"step": "If counting, invoke CountingReasoning; if arithmetic, invoke ArithmeticReasoning; if comparison, invoke ComparisonReasoning."},
            {"step": "Return the result directly without intermediate review or ensemble."}
        ]
        
        # Execute the structured plan using FlexibleCustom with no hardcoded logic
        initial_plan = await self.flexible_custom(
            reasoning_pattern=reasoning_pattern,
            steps=["Identify", "Select", "Execute"],
            custom_instruction="Analyze the question and execute the correct reasoning path based on its type."
        )

        # Step 2: Since the FlexibleCustom already executes the correct operator internally, we now use Review
        # to refine the output — but crucially, we do this *after* the flexible logic has run, not before
        final_answer = await self.review(pre_solution=initial_plan)

        # Step 3: Finally, apply ScEnsemble as a robustness check — even though only one solution was generated,
        # this ensures consistency across potential variations in how the model interprets the same prompt
        final_result = await self.sc_ensemble(solutions=[final_answer])

        return final_result