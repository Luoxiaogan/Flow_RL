# Workflow ID: drop_20_0
# Benchmark: drop
# Data Indices: [315, 31]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and extract relevant information
        initial_thought = await self.custom(instruction="First, read the passage carefully and identify what is being asked. Extract all relevant numerical or textual data related to the question.")
        
        # Step 2: Determine the type of reasoning needed based on the question
        reasoning_type = await self.custom(instruction="Based on the question, determine whether it requires counting, arithmetic, comparison, or a combination of these. Also identify key entities or events in the passage that relate to the answer.")
        
        # Step 3: Use specialized reasoning operators based on the identified task
        if "count" in reasoning_type.lower() or "how many" in reasoning_type.lower():
            count_result = await self.counting_reasoning()
            final_answer = count_result['count']
        elif "sum" in reasoning_type.lower() or "total" in reasoning_type.lower() or "difference" in reasoning_type.lower():
            arithmetic_result = await self.arithmetic_reasoning()
            final_answer = arithmetic_result['result']
        elif "which" in reasoning_type.lower() or "last" in reasoning_type.lower() or "earliest" in reasoning_type.lower() or "latest" in reasoning_type.lower():
            comparison_result = await self.comparison_reasoning()
            final_answer = comparison_result['result']
        else:
            # Fallback: use flexible custom for complex multi-step logic
            final_answer = await self.flexible_custom(
                steps=[
                    {"name": "extract", "instruction": "Extract all key facts from the passage relevant to the question."},
                    {"name": "reason", "instruction": "Apply logical reasoning using the extracted facts to derive the answer."}
                ],
                reasoning_pattern="chain_of_thought",
                custom_instruction="Now synthesize the results into a clear and concise final answer."
            )

        # Step 4: Final review to ensure correctness
        reviewed_answer = await self.review(pre_solution=str(final_answer))
        
        # Step 5: Ensemble voting (if multiple solutions exist, though not needed here)
        # For now, just return the reviewed answer as it's already robust
        return reviewed_answer