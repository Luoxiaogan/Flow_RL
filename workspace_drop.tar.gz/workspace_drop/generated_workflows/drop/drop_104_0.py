# Workflow ID: drop_104_0
# Benchmark: drop
# Data Indices: [277, 295]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify required information extraction
        initial_thought = await self.custom(instruction="First, analyze the question to determine what needs to be extracted from the passage. Identify key entities (e.g., players, events) relevant to the answer.")
        
        # Step 2: Extract field goal data for both kickers using Custom (generic extraction)
        extraction_prompt = "Extract all instances of field goals made by each kicker mentioned in the passage. List them clearly by name."
        extracted_kickers = await self.custom(instruction=extraction_prompt)
        
        # Step 3: Use CountingReasoning to count field goals per kicker
        counting_instruction = "Count how many field goals each kicker made based on the extracted list. Output a structured count for each."
        counts = await self.counting_reasoning()
        
        # Step 4: Use ArithmeticReasoning to compute difference between Scobee and Lindell
        arithmetic_instruction = "Calculate the difference between the number of field goals made by Scobee and Lindell."
        result = await self.arithmetic_reasoning()
        
        # Step 5: Final answer formatting via Custom
        final_answer = await self.custom(instruction=f"Based on the calculation: {result}, provide the final answer as a single number or phrase that directly answers the original question.")
        
        return final_answer