# Workflow ID: drop_121_0
# Benchmark: drop
# Data Indices: [391, 282]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify what needs to be extracted or reasoned about
        initial_thought = await self.custom(instruction="First, analyze the question to determine whether it requires counting, arithmetic, comparison, or text span extraction.")

        # Step 2: Based on the nature of the question, choose an appropriate reasoning path
        if "how many points" in self.problem_text.lower() or "scored" in self.problem_text.lower():
            # Use arithmetic reasoning for point totals
            arith_result = await self.arithmetic_reasoning()
            final_answer = arith_result["result"]
        elif "which players" in self.problem_text.lower() or "kicked field goals" in self.problem_text.lower():
            # Use custom reasoning to extract relevant spans (e.g., names)
            answer_span = await self.custom(instruction="Identify all players who kicked field goals in the first quarter based on the passage.")
            final_answer = answer_span.strip()
        elif "count" in self.problem_text.lower() or "number of" in self.problem_text.lower():
            # Use counting reasoning for item counts
            count_result = await self.counting_reasoning()
            final_answer = count_result["count"]
        elif "compare" in self.problem_text.lower() or "more than" in self.problem_text.lower() or "least" in self.problem_text.lower():
            # Use comparison reasoning for ordering or selecting items
            comp_result = await self.comparison_reasoning()
            final_answer = comp_result["result"]
        else:
            # Fallback: general step-by-step thinking
            general_solution = await self.custom(instruction="Think step-by-step and solve the problem by extracting key facts from the passage and applying logical reasoning.")
            final_answer = general_solution

        # Step 3: Review the solution to improve clarity and correctness
        reviewed_solution = await self.review(pre_solution=final_answer)

        # Step 4: Final output using ensemble to ensure robustness (if multiple solutions were generated)
        # In this case, since we only have one solution, sc_ensemble acts as a consistency check
        final_output = await self.sc_ensemble(solutions=[reviewed_solution])

        return final_output