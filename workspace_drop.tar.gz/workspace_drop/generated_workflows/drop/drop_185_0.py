# Workflow ID: drop_185_0
# Benchmark: drop
# Data Indices: [349, 328]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question type and identify required reasoning (information extraction + discrete reasoning).
        initial_thought = await self.custom(instruction="Identify the key task: Is this a counting, arithmetic, comparison, or information-extraction problem? What needs to be extracted first?")
        
        # Step 2: Use FlexibleCustom with sequential reasoning to break down the problem into steps.
        # This pattern ensures structured thinking: extract → reason → answer.
        solution_plan = await self.flexible_custom(
            reasoning_pattern="sequential",
            steps=[
                "Extract relevant facts from the passage related to the question.",
                "Determine what kind of reasoning is needed (e.g., count items, compute difference, compare values).",
                "Apply the appropriate specialized operator (counting/arithmetic/comparison).",
                "Return the final answer based on the result."
            ],
            custom_instruction="Based on the initial thought: {initial_thought}, now execute the plan step-by-step."
        )

        # Step 3: If the solution seems incomplete or unclear, refine it using Review.
        refined_solution = await self.review(pre_solution=solution_plan)

        # Step 4: To improve robustness, run multiple attempts via ScEnsemble if needed.
        # For simplicity, we simulate two different approaches — one direct, one through flexible custom.
        direct_answer = await self.custom(instruction="Answer the question directly based on the passage.")
        ensemble_solutions = [refined_solution, direct_answer]
        final_answer = await self.sc_ensemble(solutions=ensemble_solutions)

        return final_answer