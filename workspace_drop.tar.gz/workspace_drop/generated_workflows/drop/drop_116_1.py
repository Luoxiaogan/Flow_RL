# Workflow ID: drop_116_1
# Benchmark: drop
# Data Indices: [140, 54]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use Custom to understand the question type and extract key elements
        initial_analysis = await self.custom(instruction="Identify what kind of reasoning is needed (counting, arithmetic, comparison, or span). Also extract all relevant entities or numbers mentioned in the question.")

        # Step 2: Parallel execution of multiple reasoning strategies — one per operator type
        counting_attempt = self.counting_reasoning()
        arithmetic_attempt = self.arithmetic_reasoning()
        comparison_attempt = self.comparison_reasoning()

        # Step 3: Combine results using ScEnsemble to select the most consistent answer
        solutions = [
            await counting_attempt,
            await arithmetic_attempt,
            await comparison_attempt
        ]
        final_answer = await self.sc_ensemble(solutions=solutions)

        # Step 4: Review the ensemble result to refine clarity and correctness
        reviewed_final = await self.review(pre_solution=final_answer)

        return reviewed_final