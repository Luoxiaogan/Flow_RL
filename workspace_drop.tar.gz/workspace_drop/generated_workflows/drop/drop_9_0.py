# Workflow ID: drop_9_0
# Benchmark: drop
# Data Indices: [46, 90]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question type — determine if it's counting, arithmetic, or comparison
        initial_thought = await self.custom(instruction="Analyze the question to determine whether it requires counting, arithmetic, or comparison reasoning.")
        
        # Step 2: Route to the appropriate specialized operator based on the question type
        if "count" in initial_thought.lower() or "how many" in initial_thought.lower():
            result = await self.counting_reasoning()
            final_answer = result["count"]
        elif "sum" in initial_thought.lower() or "difference" in initial_thought.lower() or "total" in initial_thought.lower():
            result = await self.arithmetic_reasoning()
            final_answer = result["result"]
        elif "which" in initial_thought.lower() or "more than" in initial_thought.lower() or "less than" in initial_thought.lower() or "first" in initial_thought.lower():
            result = await self.comparison_reasoning()
            final_answer = result["result"]
        else:
            # Fallback: Use flexible custom for complex multi-step reasoning
            final_answer = await self.flexible_custom(
                reasoning_pattern="multi_step",
                steps=[
                    {"task": "extract relevant information", "instruction": "Identify key entities and values from the passage."},
                    {"task": "reason about relationships", "instruction": "Determine how these values relate to the question asked."},
                    {"task": "generate answer", "instruction": "Provide a concise final answer based on the analysis."}
                ],
                custom_instruction="Think step-by-step and solve the problem."
            )

        # Optional: Improve robustness via ensemble or review (only if needed)
        # For now, return the direct result as per the principle of efficiency
        return final_answer