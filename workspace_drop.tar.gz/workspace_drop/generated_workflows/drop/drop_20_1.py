# Workflow ID: drop_20_1
# Benchmark: drop
# Data Indices: [315, 31]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Generate a preliminary answer using flexible custom to handle diverse question types
        initial_answer = await self.flexible_custom(
            steps=[
                {"name": "analyze", "instruction": "Read the passage and identify what is being asked. Extract all relevant entities, numbers, and events."},
                {"name": "reason", "instruction": "Apply logical reasoning based on the extracted information to produce an initial answer."}
            ],
            reasoning_pattern="chain_of_thought",
            custom_instruction="Now synthesize the final answer clearly and concisely."
        )

        # Step 2: Use Review to critique and refine the initial solution — this is now the primary improvement step
        refined_answer = await self.review(pre_solution=initial_answer)

        # Step 3: Instead of just returning the reviewed answer, we now attempt to validate it by generating alternative solutions in parallel
        # We simulate parallel thinking via two distinct strategies: one focused on counting/arithmetic (if applicable), another on comparison
        count_attempt = self.counting_reasoning() if "how many" in self.problem_text.lower() or "count" in self.problem_text.lower() else None
        arith_attempt = self.arithmetic_reasoning() if any(keyword in self.problem_text.lower() for keyword in ["sum", "total", "difference", "more than"]) else None
        comp_attempt = self.comparison_reasoning() if any(keyword in self.problem_text.lower() for keyword in ["last", "first", "earliest", "latest", "which"]) else None

        # Collect all valid attempts into a list for ensemble voting
        solutions = [refined_answer]
        if count_attempt:
            solutions.append(await count_attempt)
        if arith_attempt:
            solutions.append(await arith_attempt)
        if comp_attempt:
            solutions.append(await comp_attempt)

        # Step 4: Final robustness check via ScEnsemble — select the most consistent answer across multiple reasoning paths
        final_result = await self.sc_ensemble(solutions=solutions)

        return final_result