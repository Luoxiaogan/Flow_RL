# Workflow ID: drop_185_1
# Benchmark: drop
# Data Indices: [349, 328]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to explore multiple reasoning paths in parallel
        # This introduces a fundamentally different strategy: instead of sequential plan execution,
        # we generate diverse solution strategies upfront using structured logic configuration.
        multi_strategy_plan = await self.flexible_custom(
            reasoning_pattern="parallel",
            steps=[
                "Identify what needs to be extracted from the passage.",
                "Apply counting reasoning if items must be counted.",
                "Apply arithmetic reasoning if numerical operations are required.",
                "Apply comparison reasoning if ordering or selection is needed.",
                "Return each possible answer path as a separate candidate."
            ],
            custom_instruction="Generate multiple potential solutions using different reasoning types (counting, arithmetic, comparison)."
        )

        # Step 2: Extract individual candidate answers from the multi-strategy output
        # We assume the flexible_custom returns a structured list-like response with distinct paths
        candidates = multi_strategy_plan.split("###")  # Assume separator used by flexible_custom

        # Step 3: Run Review on each candidate to refine them individually — this adds depth before ensemble
        refined_candidates = []
        for candidate in candidates:
            if candidate.strip():
                refined = await self.review(pre_solution=candidate.strip())
                refined_candidates.append(refined)

        # Step 4: Use ScEnsemble to select the most consistent answer across all refined candidates
        final_answer = await self.sc_ensemble(solutions=refined_candidates)

        return final_answer