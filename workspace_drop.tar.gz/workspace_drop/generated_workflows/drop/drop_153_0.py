# Workflow ID: drop_153_0
# Benchmark: drop
# Data Indices: [135, 19]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Initial reasoning — identify what needs to be extracted or computed
        initial_thought = await self.custom(instruction="First, read the passage carefully and determine what specific information is being asked in the question. Identify key entities (like players, scores, events) relevant to the query.")

        # Step 2: Use a specialized operator based on the nature of the question
        # For example, if the question asks about counts, use CountingReasoning
        # If it's arithmetic (e.g., total yards), use ArithmeticReasoning
        # If it compares values or sorts items, use ComparisonReasoning
        # Otherwise, fall back to Custom for general extraction

        # Since we don't know the exact type upfront, start with a generic extract-and-analyze step
        analysis = await self.custom(instruction=f"Based on the initial thought: {initial_thought}, now analyze the passage to extract all relevant numerical data and relationships that could answer the question.")

        # Now, attempt an initial solution using the most appropriate operator
        # We'll try a flexible approach: detect whether the task is counting, arithmetic, or comparison
        detection = await self.custom(instruction="Determine whether the question requires counting, arithmetic computation, or comparison. Respond only with 'count', 'arithmetic', or 'comparison'.")

        if "count" in detection.lower():
            count_result = await self.counting_reasoning()
            final_answer = count_result["count"]
        elif "arithmetic" in detection.lower():
            arith_result = await self.arithmetic_reasoning()
            final_answer = arith_result["result"]
        elif "comparison" in detection.lower():
            comp_result = await self.comparison_reasoning()
            final_answer = comp_result["result"]
        else:
            # Fallback: General reasoning via Custom
            final_answer = await self.custom(instruction=f"Using the analysis: {analysis}, generate a precise answer to the question based on the passage.")

        # Step 3: Review the result for correctness and clarity
        refined_answer = await self.review(pre_solution=final_answer)

        # Step 4: Optional ensemble voting (if multiple solutions were generated earlier, but here we have one)
        # Since we only have one path, skip ensemble unless more than one candidate exists
        # But we can simulate robustness by generating a second opinion via FlexibleCustom
        alternative_solution = await self.flexible_custom(
            reasoning_pattern="chain_of_thought",
            steps=[
                "Identify the key event or entity mentioned in the question.",
                "Extract all related mentions from the passage.",
                "Compute the required value based on those mentions."
            ],
            custom_instruction="Now solve the problem again using the structured plan above."
        )

        # Final step: Use ScEnsemble to pick the best answer between original and alternative
        final_output = await self.sc_ensemble(solutions=[refined_answer, alternative_solution])

        return final_output