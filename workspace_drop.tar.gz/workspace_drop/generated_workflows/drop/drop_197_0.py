# Workflow ID: drop_197_0
# Benchmark: drop
# Data Indices: [95, 231]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question type — extract key entities and task
        initial_thought = await self.custom(instruction="Identify what needs to be extracted or reasoned about. Is it a count, arithmetic, comparison, or span?")

        # Step 2: Use appropriate reasoning operator based on the task
        if "count" in initial_thought.lower() or "how many" in initial_thought.lower():
            result = await self.counting_reasoning()
        elif "sum" in initial_thought.lower() or "total" in initial_thought.lower() or "+" in initial_thought or "-" in initial_thought:
            result = await self.arithmetic_reasoning()
        elif "compare" in initial_thought.lower() or "which" in initial_thought.lower() or "more than" in initial_thought.lower():
            result = await self.comparison_reasoning()
        else:
            # Fallback: use custom for general extraction and reasoning
            result = await self.custom(instruction="Extract relevant information from the passage that answers the question directly.")

        # Step 3: If needed, refine solution using review
        refined_result = await self.review(pre_solution=result)

        # Step 4: Optional ensemble for robustness (if multiple solutions possible)
        # For now, just return the refined result as final answer
        return refined_result