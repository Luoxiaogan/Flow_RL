# Workflow ID: drop_100_1
# Benchmark: drop
# Data Indices: [132, 78]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to execute a multi-step reasoning plan
        # We define a "sequential" pattern with two distinct phases:
        # 1. Identify the question type and relevant entities (using Custom)
        # 2. Apply specialized reasoning based on that type (via branching logic inside FlexibleCustom)
        steps = [
            {
                "task": "Identify the main task: Is this a counting, arithmetic, comparison, or span-based question?",
                "instruction": "Analyze the question and determine whether it requires counting, arithmetic, comparison, or text extraction."
            },
            {
                "task": "Based on the identified task type, choose and apply the appropriate reasoning operator.",
                "instruction": "If the task involves counting, use CountingReasoning. If it involves math, use ArithmeticReasoning. If it's about ordering or comparison, use ComparisonReasoning. Otherwise, extract the answer as a text span."
            }
        ]
        
        reasoning_pattern = "sequential"
        result = await self.flexible_custom(
            steps=steps,
            reasoning_pattern=reasoning_pattern,
            custom_instruction="Use structured thinking to solve this DROP-style problem step-by-step."
        )

        # Step 2: Review the solution for clarity and correctness
        reviewed_result = await self.review(pre_solution=result)

        # Step 3: Instead of ensemble over multiple attempts, we now try one alternative approach
        # Using a parallel-like strategy: attempt solving via a different reasoning path
        alternate_approach = await self.custom(instruction="Try solving this using a completely different method — e.g., first extract all key events, then reason about them in isolation.")

        # Step 4: Now select the best solution between the original and alternate
        # This is a strategic choice: instead of voting, we pick the most coherent one
        solutions = [reviewed_result, alternate_approach]
        final_result = await self.sc_ensemble(solutions=solutions)

        return final_result