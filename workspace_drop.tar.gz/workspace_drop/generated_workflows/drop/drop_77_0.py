# Workflow ID: drop_77_0
# Benchmark: drop
# Data Indices: [184, 384]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify required reasoning type
        initial_thought = await self.custom(instruction="Identify whether this problem requires counting, arithmetic, or comparison. Also extract key entities like players, events, and numerical values.")
        
        # Step 2: Use FlexibleCustom to structure a multi-step plan based on the question type
        steps = [
            {"name": "extract_numbers", "instruction": "Extract all relevant numbers mentioned in the passage related to the question."},
            {"name": "determine_operation", "instruction": "Determine the mathematical operation needed (e.g., subtraction, addition, comparison)."},
            {"name": "compute_result", "instruction": "Perform the calculation using the extracted numbers and determined operation."}
        ]
        
        reasoning_pattern = "sequential"  # Sequential reasoning ensures clarity and correctness

        structured_plan = await self.flexible_custom(
            steps=steps,
            reasoning_pattern=reasoning_pattern,
            custom_instruction="Based on the initial thought: {initial_thought}, now execute the plan to solve the problem."
        )

        # Step 3: If the plan leads to a numeric result, validate it with ArithmeticReasoning
        if "result" in structured_plan.lower():
            final_result = await self.arithmetic_reasoning()
        else:
            # Otherwise, try ComparisonReasoning if comparing items
            final_result = await self.comparison_reasoning()

        # Step 4: Optional refinement via review for consistency
        refined_solution = await self.review(pre_solution=final_result)

        # Step 5: Final ensemble check to ensure robustness across multiple strategies
        ensemble_solution = await self.sc_ensemble(solutions=[refined_solution])

        return ensemble_solution