# Workflow ID: drop_147_0
# Benchmark: drop
# Data Indices: [210, 12]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Extract relevant information from the passage
        extraction = await self.custom(instruction="Identify all numbers and key entities mentioned in the passage that relate to the question. Focus on percentages, counts, or values needed for arithmetic or comparison.")

        # Step 2: Determine the type of reasoning required
        reasoning_type = await self.custom(instruction="Based on the question, determine whether this requires counting, arithmetic, or comparison reasoning. If it's arithmetic, identify the operation (e.g., subtraction, addition).")

        # Step 3: Perform specialized reasoning based on the identified type
        if "arithmetic" in reasoning_type.lower():
            result = await self.arithmetic_reasoning()
        elif "counting" in reasoning_type.lower():
            result = await self.counting_reasoning()
        elif "comparison" in reasoning_type.lower():
            result = await self.comparison_reasoning()
        else:
            # Fallback to custom for complex reasoning not covered by experts
            result = await self.custom(instruction="Use step-by-step reasoning to solve the problem based on extracted facts.")

        # Step 4: Finalize answer format — ensure it matches expected output (number, date, span)
        final_answer = await self.custom(instruction=f"Format the final answer clearly from the reasoning result: {result}. If the answer is a number, return just the number. If it's a text span, return the exact phrase from the passage. Otherwise, return the most concise and accurate answer.")

        # Optional: Use ensemble or review for robustness if needed
        # For now, we assume the reasoning is sufficient; could be enhanced later
        return final_answer