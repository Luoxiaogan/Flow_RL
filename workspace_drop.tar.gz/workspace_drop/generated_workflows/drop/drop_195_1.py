# Workflow ID: drop_195_1
# Benchmark: drop
# Data Indices: [137, 245]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Extract key information first — crucial for all downstream reasoning
        extraction = await self.custom(instruction="Extract all relevant facts from the passage that could help answer the question. Focus on numbers, named entities, and events.")

        # Step 2: Use ComparisonReasoning to identify which team lost or how many countries had higher rates — this directly targets the core task
        comparison_result = await self.comparison_reasoning()

        # Step 3: If the comparison result is ambiguous or incomplete, fall back to ArithmeticReasoning (e.g., for "how many more" or "difference")
        if "not enough" in comparison_result.lower() or "ambiguous" in comparison_result.lower():
            arithmetic_result = await self.arithmetic_reasoning()
            final_answer = await self.custom(instruction=f"Based on the comparison result: {comparison_result}, and fallback arithmetic result: {arithmetic_result}, determine the correct answer.")
        else:
            # Step 4: Use CountingReasoning if the problem involves counting items mentioned in the passage (like touchdowns, deaths, etc.)
            count_result = await self.counting_reasoning()
            final_answer = await self.custom(instruction=f"Based on the comparison result: {comparison_result}, and count result: {count_result}, determine the correct answer.")

        # Step 5: Apply ensemble voting across multiple strategies — now we generate 3 different solutions using distinct approaches
        solution1 = await self.custom(instruction="First approach: Solve using only direct extraction and simple logic.")
        solution2 = await self.custom(instruction="Second approach: Solve by identifying the most critical sentence and reasoning from it.")
        solution3 = await self.custom(instruction="Third approach: Solve by rephrasing the question into a mathematical or comparative query.")

        # Step 6: Vote on the best answer using ScEnsemble — robustness through diversity
        final_answer = await self.sc_ensemble(solutions=[solution1, solution2, solution3])

        # Step 7: Final review to refine and ensure clarity
        reviewed_answer = await self.review(pre_solution=final_answer)
        
        return reviewed_answer