# Workflow ID: drop_42_1
# Benchmark: drop
# Data Indices: [208, 364]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use flexible_custom to perform a structured extraction and reasoning in one go
        # This approach combines parsing and initial reasoning into a single multi-step custom instruction
        structured_analysis = await self.flexible_custom(
            steps=[
                {"name": "parse_passage", "instruction": "Identify all numerical values and their associated entities (e.g., players, plays, scores)."},
                {"name": "map_to_question", "instruction": "Link each number to how it relates to the question. For example, if the question asks about receivers, focus on yardage stats."}
            ],
            reasoning_pattern="Parse → Map",
            custom_instruction="Extract relevant numbers and map them directly to the question context."
        )

        # Step 2: Use ComparisonReasoning to sort or compare the mapped values — this is now more targeted
        comparison_result = await self.comparison_reasoning()

        # Step 3: Generate an answer based on the comparison result using ArithmeticReasoning only when needed
        # This avoids unnecessary arithmetic unless we know there's a difference to compute
        if "difference" in structured_analysis.lower() or "separated" in structured_analysis.lower():
            arithmetic_result = await self.arithmetic_reasoning()
            final_answer = arithmetic_result["result"]
        else:
            # If no arithmetic needed (e.g., just identifying the top value), return the direct comparison result
            final_answer = comparison_result["result"]

        # Step 4: Instead of ensemble, use Review first to refine the answer before finalizing
        reviewed_answer = await self.review(pre_solution=final_answer)

        # Step 5: Only then, if needed, apply ScEnsemble with a minimal set of alternative strategies
        # This ensures that we don't overuse ensembling — instead, we fix once and verify
        solution_alternative = await self.custom(instruction="Generate an alternate interpretation of the passage focusing on the key metric from the question.")
        final_final_answer = await self.sc_ensemble(solutions=[reviewed_answer, solution_alternative])

        return final_final_answer