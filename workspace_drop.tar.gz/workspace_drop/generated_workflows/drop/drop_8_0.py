# Workflow ID: drop_8_0
# Benchmark: drop
# Data Indices: [102, 116]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify what type of reasoning is needed
        initial_thought = await self.custom(instruction="First, analyze the question to determine whether it requires counting, arithmetic, comparison, or a combination. Identify key entities and values mentioned in the passage relevant to the question.")

        # Step 2: Extract relevant information using Custom (if needed)
        extraction_step = await self.custom(instruction="Based on the question, extract all relevant numerical or textual data from the passage that could be used to answer it. Focus only on items directly tied to the question.")

        # Step 3: Determine the appropriate reasoning operator based on the problem type
        reasoning_type = await self.custom(instruction="Given the extracted information, decide which reasoning type is most suitable: counting, arithmetic, or comparison. Explain why this choice fits the problem.")

        # Step 4: Execute the chosen reasoning step
        if "count" in reasoning_type.lower() or "how many" in reasoning_type.lower():
            result = await self.counting_reasoning()
        elif "sum" in reasoning_type.lower() or "difference" in reasoning_type.lower() or "total" in reasoning_type.lower():
            result = await self.arithmetic_reasoning()
        elif "compare" in reasoning_type.lower() or "who threw the shortest" in reasoning_type.lower() or "which is greater" in reasoning_type.lower():
            result = await self.comparison_reasoning()
        else:
            # Fallback to flexible custom if no clear match
            result = await self.flexible_custom(
                steps=[
                    {"name": "identify_key_data", "instruction": "Extract all numbers and related entities from the passage relevant to the question."},
                    {"name": "reason", "instruction": "Apply logical reasoning to derive the final answer based on the extracted data."}
                ],
                reasoning_pattern="chain_of_thought",
                custom_instruction="Now synthesize the information and provide the final answer."
            )

        # Step 5: Finalize the solution with a review for correctness
        final_answer = await self.review(pre_solution=result)

        # Optional: Use ensemble if multiple solutions exist or for robustness
        # For now, we assume one strong path — but if more were generated, use sc_ensemble
        return final_answer