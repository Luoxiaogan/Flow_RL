# Workflow ID: drop_23_0
# Benchmark: drop
# Data Indices: [355, 226]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question type and extract key elements
        initial_thought = await self.custom(instruction="Identify whether the question requires counting, arithmetic, comparison, or a mix. Also, locate relevant entities or events in the passage.")

        # Step 2: Use FlexibleCustom with a sequential reasoning pattern to break down the task
        reasoning_steps = [
            "First, extract all relevant temporal or categorical information needed to answer the question.",
            "Second, determine which reasoning type (counting, arithmetic, comparison) applies based on the question.",
            "Third, apply the appropriate specialized operator to compute the result."
        ]
        
        structured_reasoning = await self.flexible_custom(
            steps=reasoning_steps,
            reasoning_pattern="sequential",
            custom_instruction="Based on the initial thought, now perform step-by-step analysis using the passage context."
        )

        # Step 3: Identify the correct reasoning operator based on the nature of the question
        # For example, if it's about ordering events → use ComparisonReasoning
        # If it's about quantities → use CountingReasoning
        # If it's about math operations → use ArithmeticReasoning
        comparison_check = await self.custom(instruction="Determine if the question asks for a comparison between two items or an order of events.")
        
        if "compare" in comparison_check.lower() or "which came first" in comparison_check.lower():
            comparison_result = await self.comparison_reasoning()
            final_answer = comparison_result
        elif "how many" in comparison_check.lower() or "count" in comparison_check.lower():
            count_result = await self.counting_reasoning()
            final_answer = count_result
        elif "sum" in comparison_check.lower() or "difference" in comparison_check.lower() or "total" in comparison_check.lower():
            arithmetic_result = await self.arithmetic_reasoning()
            final_answer = arithmetic_result
        else:
            # Fallback: General reasoning via Custom
            final_answer = await self.custom(instruction="Use general reasoning to synthesize the answer from the extracted facts and logical deductions.")

        # Step 4: Optional refinement via Review for correctness
        refined_answer = await self.review(pre_solution=final_answer)

        # Step 5: Ensemble voting if multiple approaches were tried (not used here but could be added for robustness)
        # In this case, we rely on single best path, so no need for sc_ensemble

        return refined_answer