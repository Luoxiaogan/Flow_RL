# Workflow ID: drop_97_1
# Benchmark: drop
# Data Indices: [366, 68]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Strategy: Use FlexibleCustom with a parallel reasoning pattern to explore multiple approaches simultaneously
        # Then apply ensemble voting to select the most consistent answer — fundamentally different from step-by-step logic

        # Step 1: Define multiple strategies using FlexibleCustom in parallel
        parallel_solutions = await self.flexible_custom(
            reasoning_pattern="parallel",
            steps=[
                {
                    "name": "extract_and_count",
                    "instruction": "Identify all numerical values related to the question and count how many match the criteria (e.g., field goals over 45 yards)."
                },
                {
                    "name": "arithmetic_sum",
                    "instruction": "Find all relevant numbers in the passage that need to be added together based on the question’s requirement."
                },
                {
                    "name": "compare_and_select",
                    "instruction": "Determine which items in the passage meet the condition (e.g., longer than 45 yards), then sort them or compare their values."
                }
            ],
            custom_instruction="Generate three distinct solution paths for this problem, each focusing on a different type of reasoning: counting, arithmetic, and comparison."
        )

        # Step 2: Use ScEnsemble to evaluate and vote on the solutions — robustness through consensus
        final_answer = await self.sc_ensemble(solutions=parallel_solutions)

        return final_answer