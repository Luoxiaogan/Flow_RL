# Workflow ID: drop_176_1
# Benchmark: drop
# Data Indices: [10, 119]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use comparison reasoning to extract all field goals and their distances
        comparison_result = await self.comparison_reasoning()
        
        # Step 2: Use flexible_custom to filter and count only those over threshold (e.g., 40 yards)
        filtered_count = await self.flexible_custom(
            steps=[
                {"name": "Parse Field Goals", "instruction": "From the comparison result, extract each field goal with its distance."},
                {"name": "Filter by Threshold", "instruction": "Select only field goals with distance > 40 yards."},
                {"name": "Count", "instruction": "Count the number of filtered field goals."}
            ],
            reasoning_pattern="sequential",
            custom_instruction="Execute a multi-step filtering process to find how many field goals exceed 40 yards."
        )
        
        # Step 3: Generate an alternative solution using counting reasoning on raw text
        alt_solution = await self.counting_reasoning()
        
        # Step 4: Review both solutions to detect inconsistencies or errors
        reviewed_filtered = await self.review(pre_solution=filtered_count)
        reviewed_alt = await self.review(pre_solution=alt_solution)
        
        # Step 5: Use ScEnsemble to select the most consistent answer between the two approaches
        final_answer = await self.sc_ensemble(solutions=[reviewed_filtered, reviewed_alt])
        
        return final_answer