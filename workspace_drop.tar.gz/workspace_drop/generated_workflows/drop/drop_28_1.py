# Workflow ID: drop_28_1
# Benchmark: drop
# Data Indices: [250, 342]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to define a multi-step reasoning pattern based on question type
        reasoning_pattern = "Identify the key entities and quantities relevant to the question. Then apply the appropriate reasoning strategy (counting, arithmetic, comparison). Finally, synthesize the answer."
        
        steps = [
            {"task": "extract_relevant_info", "instruction": "Extract all numbers, named entities, and relationships mentioned in the passage that relate to the question."},
            {"task": "classify_reasoning", "instruction": "Based on the extracted information, determine whether this requires counting, arithmetic, or comparison."},
            {"task": "execute_reasoning", "instruction": "Apply the specialized operator corresponding to the identified reasoning type."}
        ]
        
        intermediate_solution = await self.flexible_custom(
            reasoning_pattern=reasoning_pattern,
            steps=steps,
            custom_instruction="Use step-by-step logic to solve the problem based on the passage and question."
        )

        # Step 2: Review the solution for clarity and correctness
        reviewed_solution = await self.review(pre_solution=intermediate_solution)

        # Step 3: Generate an alternative solution using Custom for cross-validation
        fallback_solution = await self.custom(instruction="Re-solve the problem by focusing directly on the question without prior classification. Justify each step clearly.")

        # Step 4: Use ScEnsemble to select the most consistent answer between the two approaches
        final_answer = await self.sc_ensemble(solutions=[reviewed_solution, fallback_solution])

        return final_answer