# Workflow ID: drop_81_0
# Benchmark: drop
# Data Indices: [133, 296]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify the required reasoning type
        initial_thought = await self.custom(instruction="First, analyze the question to determine whether it requires counting, arithmetic, comparison, or information extraction.")
        
        # Step 2: If the question asks for a specific entity (e.g., who caught a pass), extract directly
        if "who" in initial_thought.lower() or "which" in initial_thought.lower():
            answer = await self.custom(instruction="Extract the exact entity mentioned in the passage that answers the question. Focus only on the relevant sentence(s).")
            return answer
        
        # Step 3: If the question involves counting items (e.g., how many touchdowns), use CountingReasoning
        elif "count" in initial_thought.lower() or "how many" in initial_thought.lower():
            count_response = await self.counting_reasoning()
            return count_response["count"]
        
        # Step 4: If the question involves math (e.g., sum, difference, average), use ArithmeticReasoning
        elif "sum" in initial_thought.lower() or "difference" in initial_thought.lower() or "total" in initial_thought.lower():
            arith_response = await self.arithmetic_reasoning()
            return arith_response["result"]
        
        # Step 5: If the question compares two values (e.g., which group is smaller), use ComparisonReasoning
        elif "which is smaller" in initial_thought.lower() or "greater than" in initial_thought.lower() or "more than" in initial_thought.lower():
            comp_response = await self.comparison_reasoning()
            return comp_response["result"]
        
        # Step 6: Fallback for complex multi-step problems using FlexibleCustom
        else:
            # Define a generic step-by-step strategy tailored to DROP-style reasoning
            steps = [
                "Identify key entities or numbers in the passage relevant to the question.",
                "Determine the type of reasoning needed (counting, arithmetic, comparison, etc.).",
                "Apply the appropriate specialized operator based on the reasoning type.",
                "Format the final answer clearly as a number, date, or text span."
            ]
            
            reasoning_pattern = "Chain-of-Thought with Operator Selection"
            flexible_solution = await self.flexible_custom(
                steps=steps,
                reasoning_pattern=reasoning_pattern,
                custom_instruction="Solve the problem by following the defined steps and selecting the correct reasoning operator."
            )
            
            # Review and refine the solution for correctness
            reviewed_solution = await self.review(pre_solution=flexible_solution)
            
            # Use ensemble voting if multiple solutions exist (optional enhancement)
            # For now, we assume one solution suffices; this could be extended
            return reviewed_solution