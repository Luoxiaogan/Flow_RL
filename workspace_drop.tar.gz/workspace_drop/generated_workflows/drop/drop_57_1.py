# Workflow ID: drop_57_1
# Benchmark: drop
# Data Indices: [370, 234]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """

        # Step 1: Use FlexibleCustom to define a multi-step reasoning plan
        # This avoids hardcoding steps and allows dynamic strategy selection based on question type
        reasoning_pattern = "Identify key facts → Extract relevant values → Perform required operation → Validate result"
        steps = [
            {"name": "identify", "instruction": "Break down the question into what needs to be extracted or computed."},
            {"name": "extract", "instruction": "Locate all necessary numerical or textual information in the passage."},
            {"name": "compute", "instruction": "Apply arithmetic, counting, or comparison logic as needed."},
            {"name": "validate", "instruction": "Check consistency between extracted data and final answer."}
        ]
        structured_plan = await self.flexible_custom(
            reasoning_pattern=reasoning_pattern,
            steps=steps,
            custom_instruction="Use this structured plan to solve the DROP-style problem."
        )

        # Step 2: Use Review to refine the structured plan before execution
        refined_plan = await self.review(pre_solution=structured_plan)

        # Step 3: Execute the refined plan using specialized operators per step
        # This ensures we follow a logical flow rather than generating many parallel solutions
        first_step = await self.custom(instruction="Based on the refined plan: " + refined_plan + ", now execute the first step: identify key facts.")
        second_step = await self.custom(instruction="Next, extract relevant values from the passage based on the identified facts: " + first_step)
        
        # Determine which operator to use next based on the nature of the question (heuristic-driven)
        if "count" in first_step.lower() or "how many" in first_step.lower():
            third_step = await self.counting_reasoning()
        elif "sum" in first_step.lower() or "total" in first_step.lower() or "difference" in first_step.lower():
            third_step = await self.arithmetic_reasoning()
        elif "which" in first_step.lower() or "order" in first_step.lower() or "compare" in first_step.lower():
            third_step = await self.comparison_reasoning()
        else:
            third_step = await self.custom(instruction="Perform the required reasoning step based on the extracted values: " + second_step)

        # Step 4: Final review to ensure correctness
        final_answer = await self.review(pre_solution=third_step)

        return final_answer