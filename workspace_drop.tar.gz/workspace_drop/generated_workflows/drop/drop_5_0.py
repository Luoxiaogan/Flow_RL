# Workflow ID: drop_5_0
# Benchmark: drop
# Data Indices: [2, 63]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question type — extract key task (e.g., count, compare, arithmetic, or span answer)
        understanding = await self.custom(instruction="Analyze the question and determine what kind of reasoning is needed: counting, comparison, arithmetic, or span extraction.")

        # Step 2: If it's a counting task, use CountingReasoning
        if "count" in understanding.lower():
            count_result = await self.counting_reasoning()
            return count_result["count"]

        # Step 3: If it's an arithmetic task, use ArithmeticReasoning
        elif "sum" in understanding.lower() or "difference" in understanding.lower() or "total" in understanding.lower():
            arithmetic_result = await self.arithmetic_reasoning()
            return arithmetic_result["result"]

        # Step 4: If it's a comparison or sorting task, use ComparisonReasoning
        elif "which" in understanding.lower() or "more" in understanding.lower() or "less" in understanding.lower() or "highest" in understanding.lower() or "lowest" in understanding.lower():
            comparison_result = await self.comparison_reasoning()
            return comparison_result["result"]

        # Step 5: Otherwise, treat as a span-extraction task using Custom
        else:
            final_answer = await self.custom(instruction="Extract the exact answer from the passage based on the question. Be precise and concise.")
            return final_answer