# Workflow ID: drop_124_1
# Benchmark: drop
# Data Indices: [272, 79]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to define a multi-step reasoning plan that explicitly
        # identifies the relevant group and computes its complement using arithmetic
        reasoning_plan = [
            "First, locate the percentage value for the specified group in the passage.",
            "Second, subtract this value from 100% to get the percentage not in that group.",
            "Third, return the result as a number."
        ]
        
        flexible_solution = await self.flexible_custom(
            steps=reasoning_plan,
            reasoning_pattern="sequential",
            custom_instruction="Solve the problem step-by-step based on the provided plan."
        )

        # Step 2: Generate an alternative solution using comparison reasoning — 
        # treat it as a "find the group" task and then compute complement via subtraction
        comparison_result = await self.comparison_reasoning()
        
        # Step 3: Use Review to refine one of the solutions before ensemble
        refined_solution = await self.review(pre_solution=flexible_solution)

        # Step 4: Now collect multiple distinct approaches:
        # - One from FlexibleCustom (structured reasoning)
        # - One from ComparisonReasoning (group-based extraction + implicit arithmetic)
        # - One from Review (refined version of flexible solution)
        solutions = [flexible_solution, comparison_result, refined_solution]

        # Step 5: Apply ScEnsemble to select the most consistent answer across these different strategies
        final_answer = await self.sc_ensemble(solutions=solutions)

        return final_answer