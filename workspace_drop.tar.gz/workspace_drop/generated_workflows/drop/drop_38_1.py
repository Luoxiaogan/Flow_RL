# Workflow ID: drop_38_1
# Benchmark: drop
# Data Indices: [20, 248]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to define a multi-step reasoning pattern
        # This avoids serial execution and instead uses structured logic via steps
        solution = await self.flexible_custom(
            reasoning_pattern="Identify relevant items → Filter by condition → Count valid ones",
            steps=[
                "Extract all infrastructure project types and their counts from the passage.",
                "Filter those with counts less than 100.",
                "Count the filtered list to get the final answer."
            ],
            custom_instruction="Apply the above steps to solve the problem directly."
        )

        # Step 2: Review the solution for clarity and correctness
        reviewed_solution = await self.review(pre_solution=solution)

        # Step 3: Return the reviewed result — no ensemble needed because we used structured logic
        return reviewed_solution