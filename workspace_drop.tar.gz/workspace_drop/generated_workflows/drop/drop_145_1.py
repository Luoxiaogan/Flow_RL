# Workflow ID: drop_145_1
# Benchmark: drop
# Data Indices: [214, 293]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom with a parallel reasoning pattern to generate multiple solution paths
        parallel_solutions = await self.flexible_custom(
            reasoning_pattern="parallel",
            steps=[
                {"name": "counting", "instruction": "Identify and count all relevant entities mentioned in the passage that relate to the question."},
                {"name": "arithmetic", "instruction": "Extract numerical values from the passage and compute the required arithmetic operation (e.g., sum, difference)."},
                {"name": "comparison", "instruction": "Compare items or groups described in the passage to determine which one satisfies the condition in the question."}
            ],
            custom_instruction="Generate three distinct solutions using different reasoning strategies. Do not combine them."
        )

        # Step 2: Evaluate each solution individually using Review
        reviewed_solutions = []
        for sol in parallel_solutions:
            reviewed = await self.review(pre_solution=sol)
            reviewed_solutions.append(reviewed)

        # Step 3: Use ScEnsemble to select the most consistent answer across the three approaches
        final_output = await self.sc_ensemble(solutions=reviewed_solutions)

        return final_output