# Workflow ID: drop_148_0
# Benchmark: drop
# Data Indices: [300, 13]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Initial breakdown using Custom to identify key elements and reasoning type
        initial_thought = await self.custom(instruction="First, read the passage carefully and identify the key facts relevant to the question. Determine whether the task involves counting, arithmetic, comparison, or another form of discrete reasoning.")

        # Step 2: Generate multiple solutions using different strategies (Parallel Ensemble)
        solution_a = await self.custom(instruction="Based on the initial thought: {initial_thought}, solve the problem by focusing on extracting the relevant entities mentioned in the passage first, then applying logical reasoning to answer the question.")
        
        solution_b = await self.comparison_reasoning()
        
        solution_c = await self.arithmetic_reasoning()

        # Step 3: Use ScEnsemble to select the most consistent answer across multiple approaches
        ensemble_result = await self.sc_ensemble(solutions=[solution_a, solution_b, solution_c])

        # Step 4: Final review to refine the selected answer
        final_answer = await self.review(pre_solution=ensemble_result)

        return final_answer