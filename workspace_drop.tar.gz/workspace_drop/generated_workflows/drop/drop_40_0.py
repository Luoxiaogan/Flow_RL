# Workflow ID: drop_40_0
# Benchmark: drop
# Data Indices: [98, 308]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify required information
        initial_thought = await self.custom(instruction="First, read the passage carefully and determine what specific information must be extracted to answer the question.")

        # Step 2: Extract relevant data — e.g., player names, scores, yardages
        extraction_step = await self.custom(instruction="Identify all relevant numerical values mentioned in the passage related to the question. For example, find all touchdown runs, field goals, or scoring plays with their yardages.")

        # Step 3: Use specialized reasoning based on the type of problem
        if "how many more yards" in self.problem_text.lower() or "difference" in self.problem_text.lower():
            # This is an arithmetic reasoning problem
            arith_result = await self.arithmetic_reasoning()
            return arith_result

        elif "how many" in self.problem_text.lower() or "count" in self.problem_text.lower():
            # This is a counting problem
            count_result = await self.counting_reasoning()
            return count_result

        elif "which" in self.problem_text.lower() or "most" in self.problem_text.lower() or "least" in self.problem_text.lower():
            # This is a comparison or sorting task
            comp_result = await self.comparison_reasoning()
            return comp_result

        else:
            # General case: fallback to flexible custom for multi-step logic
            final_answer = await self.flexible_custom(
                reasoning_pattern="Step-by-step reasoning",
                steps=[
                    "Extract all relevant numbers and items from the passage.",
                    "Determine the mathematical relationship needed (e.g., sum, difference, ratio).",
                    "Perform the calculation using the appropriate operator."
                ],
                custom_instruction="Solve the problem by first extracting key facts, then applying the correct reasoning type (arithmetic, counting, or comparison)."
            )
            return final_answer