# Workflow ID: drop_22_1
# Benchmark: drop
# Data Indices: [246, 177]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to define a multi-step reasoning pattern
        # This avoids rigid conditionals and instead lets the LLM structure its own solution path
        reasoning_plan = await self.flexible_custom(
            reasoning_pattern="Extract relevant facts, then apply appropriate reasoning (counting/arithmetic/comparison).",
            steps=[
                "Identify key entities or numbers mentioned in the passage related to the question.",
                "Determine whether the required answer involves counting items, performing arithmetic, or comparing values.",
                "Execute the appropriate specialized reasoning step based on the determination."
            ],
            custom_instruction="Based on the problem, generate a structured plan to solve it using the most suitable operator."
        )

        # Step 2: Extract the final answer directly from the flexible custom output
        # This skips branching logic — we let the LLM decide which operator to invoke internally
        final_answer = reasoning_plan

        # Step 3: Review the solution for clarity and correctness
        reviewed_solution = await self.review(pre_solution=final_answer)

        # Step 4: Final robustness check via ensemble — even with one solution, this ensures consistency
        # If more solutions were generated later (e.g., by trying different prompts), ScEnsemble would help
        # For now, we just validate the single solution
        final_result = await self.sc_ensemble(solutions=[reviewed_solution])

        return final_result