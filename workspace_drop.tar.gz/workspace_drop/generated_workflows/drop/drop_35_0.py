# Workflow ID: drop_35_0
# Benchmark: drop
# Data Indices: [48, 174]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify key entities/quantities
        initial_thought = await self.custom(instruction="Read the passage carefully and identify all instances of touchdown passes by the relevant quarterback. Note any conditions (e.g., yardage thresholds).")

        # Step 2: Use specialized reasoning to count or compare based on the question type
        # For example, if it asks "How many touchdown passes did Garrard throw?" → use CountingReasoning
        # If it asks "How many over 15 yards?" → use ComparisonReasoning to filter first, then CountingReasoning
        count_or_compare_instruction = await self.custom(instruction="Based on the initial thought, determine whether this is a simple counting task or requires filtering (e.g., by yardage). Then decide which reasoning operator to use next.")
        
        # Determine if we need to filter by yardage (e.g., >15 yards)
        if "over" in count_or_compare_instruction.lower() or "more than" in count_or_compare_instruction.lower():
            filtered_passes = await self.comparison_reasoning()
            final_count = await self.counting_reasoning()
            final_answer = f"{final_count}"
        else:
            # Simple counting case
            final_count = await self.counting_reasoning()
            final_answer = f"{final_count}"

        # Final step: Ensure the answer is clean and formatted correctly
        final_response = await self.custom(instruction=f"Return only the final numerical answer based on the reasoning: {final_answer}. Do not add explanations.")

        return final_response.strip()