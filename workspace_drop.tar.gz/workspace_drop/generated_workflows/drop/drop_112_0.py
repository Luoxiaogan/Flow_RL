# Workflow ID: drop_112_0
# Benchmark: drop
# Data Indices: [340, 263]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the problem and identify what needs to be extracted or reasoned about
        initial_thought = await self.custom(instruction="First, read the passage carefully and determine what specific information must be extracted or calculated to answer the question.")
        
        # Step 2: Extract relevant entities (e.g., field goals, subordinates, etc.) using a flexible custom step
        extraction_step = await self.flexible_custom(
            reasoning_pattern="Extract all relevant numerical or categorical data from the passage that relates directly to the question.",
            steps=[
                "Identify key nouns and quantities mentioned in the passage related to the question.",
                "List each occurrence with its context (e.g., who, when, how many)."
            ],
            custom_instruction="Extract all relevant numerical or categorical data from the passage that relates directly to the question."
        )
        
        # Step 3: If the question involves counting, use CountingReasoning
        if "how many" in self.problem.lower() or "count" in self.problem.lower():
            count_result = await self.counting_reasoning()
            final_answer = count_result
            
        # Step 4: If the question involves arithmetic (e.g., difference, sum), use ArithmeticReasoning
        elif "more", "less", "difference", "sum", "total" in self.problem.lower().split():
            arith_result = await self.arithmetic_reasoning()
            final_answer = arith_result
            
        # Step 5: If the question involves comparison (e.g., who scored more, which one is earlier), use ComparisonReasoning
        elif "compare", "which", "more than", "less than", "earlier", "later" in self.problem.lower():
            comp_result = await self.comparison_reasoning()
            final_answer = comp_result
            
        # Step 6: General fallback — use Custom to synthesize a solution based on prior steps
        else:
            final_answer = await self.custom(instruction=f"Based on the initial thought: {initial_thought}, and the extracted information: {extraction_step}, now solve the problem.")

        # Step 7: Refine the answer using Review to ensure correctness
        refined_answer = await self.review(pre_solution=final_answer)
        
        # Step 8: Final ensemble check — generate multiple solutions and vote for consistency
        solution_pool = [final_answer, refined_answer]
        final_output = await self.sc_ensemble(solutions=solution_pool)
        
        return final_output