# Workflow ID: drop_75_1
# Benchmark: drop
# Data Indices: [202, 373]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom with a parallel reasoning pattern to explore multiple solution paths simultaneously
        reasoning_pattern = "parallel"
        steps = [
            {"name": "count", "instruction": "Identify all instances of counting tasks in the passage (e.g., number of touchdowns, field goals, etc.) and solve them using CountingReasoning."},
            {"name": "arithmetic", "instruction": "Extract numerical values related to scores, distances, or time and compute necessary arithmetic operations using ArithmeticReasoning."},
            {"name": "compare", "instruction": "Find items that need comparison (e.g., highest scoring play, longest pass) and determine order or difference using ComparisonReasoning."}
        ]
        parallel_solutions = await self.flexible_custom(
            reasoning_pattern=reasoning_pattern,
            steps=steps,
            custom_instruction="Apply each reasoning type independently to generate candidate solutions."
        )

        # Step 2: Use ScEnsemble to evaluate the outputs from parallel reasoning paths and select the most consistent answer
        final_answer = await self.sc_ensemble(solutions=[parallel_solutions])

        # Step 3: If the ensemble result is ambiguous or lacks clarity, refine it via Review
        refined_final = await self.review(pre_solution=final_answer)

        return refined_final