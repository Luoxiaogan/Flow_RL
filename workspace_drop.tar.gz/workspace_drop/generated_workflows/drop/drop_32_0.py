# Workflow ID: drop_32_0
# Benchmark: drop
# Data Indices: [291, 73]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question type — extract key reasoning task
        initial_thought = await self.custom(instruction="Analyze the question to determine whether it requires counting, arithmetic, comparison, or multi-step extraction.")

        # Step 2: Based on the question type, apply appropriate reasoning strategy
        reasoning_pattern = "sequential" if "how many" in self.problem_text.lower() or "count" in self.problem_text.lower() else (
            "comparison" if "which happened first" in self.problem_text.lower() or "earlier" in self.problem_text.lower() else "arithmetic"
        )

        # Step 3: Use FlexibleCustom to orchestrate a structured reasoning process
        final_solution = await self.flexible_custom(
            steps=[
                "Identify relevant information in the passage related to the question.",
                "Extract numerical values or time-based events as needed.",
                "Apply the correct reasoning type (counting, arithmetic, comparison).",
                "Generate a clear and concise answer based on the extracted facts."
            ],
            reasoning_pattern=reasoning_pattern,
            custom_instruction="Now solve the problem using the identified reasoning pattern."
        )

        # Step 4: Optionally refine with review for robustness
        refined_solution = await self.review(pre_solution=final_solution)

        # Step 5: Use ensemble to improve consistency across multiple runs (if needed)
        # Note: Since we're solving one problem at a time, sc_ensemble is used only if multiple solutions exist
        # For now, return the reviewed solution directly.
        return refined_solution