# Workflow ID: drop_43_1
# Benchmark: drop
# Data Indices: [216, 367]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to define a multi-step reasoning plan based on question type
        reasoning_plan = await self.flexible_custom(
            reasoning_pattern="Extract → Reason → Finalize",
            steps=[
                "Identify what needs to be extracted from the passage.",
                "Determine whether this requires counting, arithmetic, or comparison.",
                "Apply the appropriate specialized reasoning operator."
            ],
            custom_instruction="Generate a step-by-step plan for solving the problem using the three phases: extraction, reasoning, and finalization."
        )

        # Step 2: Extract relevant information using Custom (guided by the plan)
        extraction_result = await self.custom(instruction=f"Based on the reasoning plan: {reasoning_plan}, extract only the necessary data from the passage that directly relates to answering the question.")

        # Step 3: Apply specialized reasoning in parallel — generate multiple solution paths
        count_solution = self.counting_reasoning()
        arith_solution = self.arithmetic_reasoning()
        comp_solution = self.comparison_reasoning()

        # Wait for all to complete concurrently
        solutions = await asyncio.gather(count_solution, arith_solution, comp_solution)

        # Step 4: Use ScEnsemble to select the most consistent answer across all three reasoning types
        final_answer = await self.sc_ensemble(solutions=solutions)

        # Step 5: Review the ensemble result for clarity and correctness
        reviewed_answer = await self.review(pre_solution=final_answer)

        return reviewed_answer