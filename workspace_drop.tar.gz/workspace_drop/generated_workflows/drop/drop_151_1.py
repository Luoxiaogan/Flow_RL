# Workflow ID: drop_151_1
# Benchmark: drop
# Data Indices: [153, 309]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to guide a multi-step reasoning process
        # This time, we use a "branching" pattern — explore multiple potential strategies first
        initial_plan = await self.flexible_custom(
            reasoning_pattern="branching",
            steps=[
                "Identify whether the question requires counting, arithmetic, comparison, or direct extraction.",
                "Generate one solution using Custom for each possible type of reasoning (counting, math, comparison, extract).",
                "Evaluate which strategy seems most appropriate based on the question's phrasing and context."
            ],
            custom_instruction="Now synthesize a plan that includes multiple candidate solutions for different reasoning types."
        )

        # Step 2: Generate candidate solutions in parallel via branching logic
        count_sol = await self.counting_reasoning()
        arith_sol = await self.arithmetic_reasoning()
        comp_sol = await self.comparison_reasoning()
        extract_sol = await self.custom(instruction="Extract the exact answer directly from the passage based on the question.")

        # Step 3: Use ScEnsemble to vote among all four candidates — this ensures robustness without relying on heuristics
        ensemble_result = await self.sc_ensemble(solutions=[
            str(count_sol['count']) if 'count' in count_sol else "",
            str(arith_sol['result']) if 'result' in arith_sol else "",
            str(comp_sol['result']) if 'result' in comp_sol else "",
            extract_sol
        ])

        # Step 4: Final refinement using Review — apply critique only once at the end
        final_answer = await self.review(pre_solution=ensemble_result)

        return final_answer