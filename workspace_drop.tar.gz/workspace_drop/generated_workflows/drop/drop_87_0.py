# Workflow ID: drop_87_0
# Benchmark: drop
# Data Indices: [96, 301]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question type — it's a comparison task over spans (longest/shortest/different length TD passes).
        initial_thought = await self.custom(instruction="Identify the key elements in the question: what needs to be compared? In this case, it's about finding the player who caught the longest touchdown pass.")
        
        # Step 2: Use ComparisonReasoning to extract and compare all relevant touchdown pass information.
        comparison_result = await self.comparison_reasoning()
        
        # Step 3: Extract the answer from the structured comparison result.
        final_answer = comparison_result.strip()  # Assuming output format includes the answer directly
        
        # Optional: Review step for refinement (especially important for complex comparisons)
        reviewed_solution = await self.review(pre_solution=final_answer)
        
        # Final ensemble step to improve robustness — even though single-step reasoning might suffice, this ensures consistency
        final_output = await self.sc_ensemble(solutions=[final_answer, reviewed_solution])
        
        return final_output