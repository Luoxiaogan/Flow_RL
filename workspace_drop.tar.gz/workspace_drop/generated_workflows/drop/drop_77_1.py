# Workflow ID: drop_77_1
# Benchmark: drop
# Data Indices: [184, 384]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use Custom to analyze the question and identify key entities and reasoning type
        initial_analysis = await self.custom(instruction="Analyze the question and determine what kind of reasoning is needed (e.g., counting, arithmetic, comparison). Identify all relevant numerical values or items mentioned in the passage that relate to the question.")

        # Step 2: Use FlexibleCustom with a PARALLEL reasoning pattern to explore multiple solution paths simultaneously
        steps = [
            {"name": "count_approach", "instruction": "Identify all instances of the relevant entity (e.g., field goals, touchdowns) and count them separately."},
            {"name": "arithmetic_approach", "instruction": "Extract the two numbers involved in the required operation (e.g., difference between two counts or values) and compute the result."},
            {"name": "comparison_approach", "instruction": "If the question involves comparing quantities, list the relevant values and determine which one is greater or by how much."}
        ]
        
        reasoning_pattern = "parallel"  # Execute all three approaches at once for robustness

        parallel_solutions = await self.flexible_custom(
            steps=steps,
            reasoning_pattern=reasoning_pattern,
            custom_instruction=f"Based on the analysis: {initial_analysis}, now solve using parallel strategies."
        )

        # Step 3: Extract individual solutions from the structured output
        solutions = [s.strip() for s in parallel_solutions.split("###") if s.strip()]

        # Step 4: Apply ScEnsemble to select the most consistent answer across the parallel paths
        final_answer = await self.sc_ensemble(solutions=solutions)

        # Step 5: Optional refinement via Review to improve clarity or correctness
        refined_answer = await self.review(pre_solution=final_answer)

        return refined_answer