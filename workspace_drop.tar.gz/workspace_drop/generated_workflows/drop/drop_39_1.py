# Workflow ID: drop_39_1
# Benchmark: drop
# Data Indices: [64, 55]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Generate multiple independent solutions using different reasoning strategies
        # Strategy 1: Direct extraction + custom reasoning (for span-based or simple questions)
        solution_a = await self.custom(instruction="Extract the answer directly from the passage based on the question. Focus only on the relevant part of the text.")

        # Strategy 2: Use comparison reasoning for questions involving ordering or ranking (e.g., longest pass, which quarter had no points)
        solution_b = await self.comparison_reasoning()

        # Strategy 3: Use counting reasoning for "how many" type questions
        solution_c = await self.counting_reasoning()

        # Step 2: Use ScEnsemble to select the most consistent answer across all strategies
        ensemble_solution = await self.sc_ensemble(solutions=[solution_a, solution_b, solution_c])

        # Step 3: Optional refinement via review to improve clarity and correctness
        final_answer = await self.review(pre_solution=ensemble_solution)

        return final_answer