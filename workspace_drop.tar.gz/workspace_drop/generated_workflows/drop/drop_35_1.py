# Workflow ID: drop_35_1
# Benchmark: drop
# Data Indices: [48, 174]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Strategy: Use FlexibleCustom to define a multi-step reasoning plan
        # This avoids branching logic and instead uses structured step-by-step planning
        steps = [
            "Identify all touchdown passes made by the relevant quarterback in the passage.",
            "If the question includes a yardage condition (e.g., 'over 15 yards'), filter the list accordingly.",
            "Count the resulting set of qualified touchdown passes."
        ]
        
        reasoning_pattern = "Sequential Reasoning"
        
        # Execute the entire workflow as a single coherent plan using FlexibleCustom
        solution = await self.flexible_custom(
            steps=steps,
            reasoning_pattern=reasoning_pattern,
            custom_instruction="Based on the passage and question, follow the steps to determine the final count."
        )
        
        # Final refinement via Review to ensure clarity and correctness
        refined_solution = await self.review(pre_solution=solution)
        
        # Return only the numerical answer — no extra text
        return refined_solution.strip()