# Workflow ID: drop_76_1
# Benchmark: drop
# Data Indices: [382, 203]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Strategy: Use FlexibleCustom to define a multi-step reasoning plan that combines
        # both extraction and comparison in parallel, then validate with ensemble.
        
        # Step 1: Define a flexible custom workflow using "parallel" reasoning pattern
        # This allows us to extract relevant entities/events first, then compare them
        steps = [
            {"name": "extract_entities", "instruction": "Identify all key entities or values mentioned in the passage that are relevant to answering the question."},
            {"name": "compare_entities", "instruction": "Compare the extracted entities based on the question's requirements (e.g., find the longest field goal, earliest event)."},
        ]
        
        # Use flexible_custom with parallel execution to run extraction and comparison in one logical flow
        parallel_solution = await self.flexible_custom(
            reasoning_pattern="parallel",
            steps=steps,
            custom_instruction="Solve the problem by first extracting relevant information, then comparing it to determine the final answer."
        )

        # Step 2: Run a separate arithmetic or counting check if needed — but only if the main solution lacks confidence
        # We'll use a simple heuristic: if the answer seems vague or not numeric, try an auxiliary check
        if "not clearly stated" in parallel_solution.lower() or "no clear winner" in parallel_solution.lower():
            # Try a dedicated comparison operator as fallback
            comparison_check = await self.comparison_reasoning()
            # Now combine both results via ScEnsemble for robustness
            solutions = [parallel_solution, comparison_check]
            final_answer = await self.sc_ensemble(solutions=solutions)
        else:
            # Otherwise, directly review the parallel solution
            final_answer = await self.review(pre_solution=parallel_solution)

        return final_answer