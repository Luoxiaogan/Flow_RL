# Workflow ID: drop_52_1
# Benchmark: drop
# Data Indices: [280, 374]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom with a parallel reasoning pattern to explore multiple strategies simultaneously
        parallel_solutions = await self.flexible_custom(
            reasoning_pattern="parallel",
            steps=[
                "Generate a solution using counting reasoning.",
                "Generate a solution using arithmetic reasoning.",
                "Generate a solution using comparison reasoning."
            ],
            custom_instruction="Apply each reasoning type independently to the passage and question. Return all three solutions as separate responses."
        )

        # Step 2: Use ScEnsemble to evaluate and select the most consistent answer across the three approaches
        final_answer = await self.sc_ensemble(solutions=parallel_solutions.split("\n\n"))

        # Step 3: Review the final ensemble result for clarity and correctness before returning
        reviewed_answer = await self.review(pre_solution=final_answer)
        
        return reviewed_answer