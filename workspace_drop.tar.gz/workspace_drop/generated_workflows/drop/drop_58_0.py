# Workflow ID: drop_58_0
# Benchmark: drop
# Data Indices: [253, 117]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify what needs to be extracted or reasoned about
        initial_thought = await self.custom(instruction="First, parse the question to determine what type of reasoning is needed: counting, arithmetic, comparison, or a combination. Identify key entities (e.g., numbers, events, spans).")

        # Step 2: Use FlexibleCustom with a sequential reasoning pattern to break down the problem step-by-step
        structured_reasoning = await self.flexible_custom(
            reasoning_pattern="sequential",
            steps=[
                "Extract all relevant numerical or event-based data from the passage that relates to the question.",
                "Determine which of these meet the criteria specified in the question (e.g., passing touchdowns > 20 yards).",
                "Count the items that satisfy the condition using the CountingReasoning expert.",
                "If arithmetic is required (e.g., summing years), use ArithmeticReasoning.",
                "If comparisons are needed (e.g., longest touchdown), use ComparisonReasoning."
            ],
            custom_instruction="Based on the initial thought, apply structured reasoning to solve the problem step by step."
        )

        # Step 3: Review the solution to refine clarity and correctness
        reviewed_solution = await self.review(pre_solution=structured_reasoning)

        # Step 4: Use ScEnsemble to improve robustness by combining multiple solutions if possible
        # For now, we assume one strong path; later, we could generate alternative interpretations via flexible_custom
        final_result = await self.sc_ensemble(solutions=[reviewed_solution])

        return final_result