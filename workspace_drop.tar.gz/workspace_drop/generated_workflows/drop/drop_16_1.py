# Workflow ID: drop_16_1
# Benchmark: drop
# Data Indices: [201, 82]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Extract relevant information using a flexible custom step that guides structured thinking
        extraction_step = await self.flexible_custom(
            reasoning_pattern="Extract and list all entities or events mentioned in the passage that are directly related to answering the question.",
            steps=[
                "Identify key nouns, numbers, and dates tied to the question.",
                "List them in a clear format such as 'Date: X, Event: Y' or 'Item: Z'.",
                "Do not include irrelevant details."
            ],
            custom_instruction="Analyze the passage thoroughly and extract only the parts relevant to solving the question."
        )

        # Step 2: Use counting reasoning if the task involves counting items (e.g., territories, touchdowns)
        if "how many" in self.problem.lower() or "count" in self.problem.lower():
            count_result = await self.counting_reasoning()
            final_answer = count_result
        # Step 3: If it's arithmetic (e.g., totals, differences), use arithmetic reasoning
        elif "sum", "total", "difference", "more than", "less than" in self.problem.lower():
            arithmetic_result = await self.arithmetic_reasoning()
            final_answer = arithmetic_result
        # Step 4: For comparison tasks (e.g., which is largest, who scored first), use comparison reasoning
        elif "which", "who", "first", "last", "greater", "lesser" in self.problem.lower():
            comparison_result = await self.comparison_reasoning()
            final_answer = comparison_result
        # Step 5: If none of the above apply, fall back to general custom reasoning with structured thought process
        else:
            general_thought = await self.custom(instruction="Break down the question into logical sub-tasks. Then synthesize an answer based on the extracted information.")
            final_answer = general_thought

        # Step 6: Review the final solution to refine clarity and correctness
        refined_answer = await self.review(pre_solution=final_answer)

        return refined_answer