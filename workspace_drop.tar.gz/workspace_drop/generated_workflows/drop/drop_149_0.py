# Workflow ID: drop_149_0
# Benchmark: drop
# Data Indices: [289, 314]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question type and extract key entities
        initial_thought = await self.custom(instruction="Identify the type of reasoning required (counting, arithmetic, comparison, or span extraction) and highlight relevant entities in the passage.")

        # Step 2: Use FlexibleCustom to apply a strategic template based on reasoning pattern
        reasoning_pattern = "sequential"  # General strategy for most DROP problems
        steps = [
            {"name": "extract_entities", "instruction": "Extract all numbers, dates, and named entities relevant to the question."},
            {"name": "determine_reasoning_type", "instruction": "Based on the question, determine whether it requires counting, arithmetic, comparison, or text span selection."},
            {"name": "execute_specialized_reasoning", "instruction": "Use the appropriate specialized operator (Counting, Arithmetic, Comparison) based on the determined reasoning type."}
        ]
        
        intermediate_result = await self.flexible_custom(
            reasoning_pattern=reasoning_pattern,
            steps=steps,
            custom_instruction="Apply the structured reasoning steps to solve this DROP-style problem."
        )

        # Step 3: If needed, refine with review for quality assurance
        refined_solution = await self.review(pre_solution=intermediate_result)

        # Step 4: Use SC Ensemble to improve robustness by combining multiple approaches
        solution_pool = [intermediate_result, refined_solution]
        final_answer = await self.sc_ensemble(solutions=solution_pool)

        return final_answer