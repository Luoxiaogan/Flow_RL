# Workflow ID: drop_64_0
# Benchmark: drop
# Data Indices: [312, 279]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and extract relevant information
        initial_thought = await self.custom(instruction="Read the passage carefully and identify what needs to be calculated or compared. Extract all relevant numerical data and key facts.")
        
        # Step 2: Determine the type of reasoning required (arithmetic, counting, comparison)
        reasoning_type = await self.custom(instruction="Based on the question, determine whether this requires arithmetic, counting, or comparison reasoning. For example, if it asks 'how many more', it's likely arithmetic; if it asks 'how many', it's counting; if it compares values, it's comparison.")
        
        # Step 3: Apply the appropriate specialized reasoning operator
        if "arithmetic" in reasoning_type.lower():
            result = await self.arithmetic_reasoning()
        elif "counting" in reasoning_type.lower():
            result = await self.counting_reasoning()
        elif "comparison" in reasoning_type.lower():
            result = await self.comparison_reasoning()
        else:
            # Fallback: Use flexible custom for complex multi-step reasoning
            result = await self.flexible_custom(
                reasoning_pattern="multi_step",
                steps=[
                    {"task": "Extract key numbers from the passage", "instruction": "Identify all numbers mentioned in the passage that might be relevant to the question."},
                    {"task": "Determine the operation needed", "instruction": "Based on the question, decide whether to add, subtract, compare, or count."}
                ],
                custom_instruction="Now synthesize the extracted information and solve the problem step-by-step."
            )

        # Step 4: Finalize the answer by reviewing and potentially ensembling multiple attempts
        final_answer = await self.review(pre_solution=result)
        return final_answer