# Workflow ID: drop_56_1
# Benchmark: drop
# Data Indices: [30, 69]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """

        # Step 1: Use Custom to extract key facts and identify the type of reasoning needed
        initial_analysis = await self.custom(
            instruction="Analyze the question and passage. Identify whether this requires counting, arithmetic, or comparison. Also extract all relevant numbers and entities."
        )

        # Step 2: Based on the analysis, choose a specialized reasoning path (arithmetic, counting, or comparison)
        if "count" in initial_analysis.lower() or "how many" in initial_analysis.lower():
            solution = await self.counting_reasoning()
        elif "sum" in initial_analysis.lower() or "total" in initial_analysis.lower() or "add" in initial_analysis.lower():
            solution = await self.arithmetic_reasoning()
        elif "compare" in initial_analysis.lower() or "more than" in initial_analysis.lower() or "less than" in initial_analysis.lower():
            solution = await self.comparison_reasoning()
        else:
            # Fallback: use flexible custom to guide structured reasoning
            solution = await self.flexible_custom(
                reasoning_pattern="Extract → Reason → Resolve",
                steps=[
                    {"name": "extract", "instruction": "Identify all numerical values and their context in the passage."},
                    {"name": "reason", "instruction": "Determine the correct operation based on the question's intent."},
                    {"name": "resolve", "instruction": "Compute the final answer using the extracted data."}
                ],
                custom_instruction="Solve the DROP-style problem by following a three-step plan: extract, reason, resolve."
            )

        # Step 3: Review the result for clarity and correctness
        reviewed_solution = await self.review(pre_solution=solution)

        # Step 4: Use ScEnsemble with only one solution — but this is valid when we have confidence in our step-by-step logic
        # This ensures robustness even if the single path fails — we still have a fallback via review
        final_answer = await self.sc_ensemble(solutions=[reviewed_solution])

        return final_answer