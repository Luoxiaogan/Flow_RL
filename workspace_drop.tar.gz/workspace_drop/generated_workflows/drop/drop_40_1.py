# Workflow ID: drop_40_1
# Benchmark: drop
# Data Indices: [98, 308]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom with parallel reasoning to explore multiple strategies simultaneously
        parallel_solutions = await self.flexible_custom(
            reasoning_pattern="Parallel reasoning",
            steps=[
                "Strategy A: Identify all relevant numerical values and perform arithmetic operations.",
                "Strategy B: Extract all instances of specific events (e.g., touchdowns, field goals), count them, and compute totals.",
                "Strategy C: Compare key elements (like player scores or yardages) to determine relationships."
            ],
            custom_instruction="Generate three distinct solutions using different reasoning patterns: arithmetic, counting, and comparison. Then select the most consistent one via ensemble voting."
        )

        # Step 2: Evaluate the parallel solutions using ScEnsemble for robustness
        final_answer = await self.sc_ensemble(solutions=[parallel_solutions])

        # Step 3: Review the final answer to ensure clarity and correctness
        reviewed_answer = await self.review(pre_solution=final_answer)

        return reviewed_answer