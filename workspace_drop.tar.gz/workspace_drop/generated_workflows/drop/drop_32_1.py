# Workflow ID: drop_32_1
# Benchmark: drop
# Data Indices: [291, 73]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use Custom to extract key task type from question (e.g., count, compare, compute)
        task_type_analysis = await self.custom(instruction="Determine whether the question requires counting, arithmetic, or comparison reasoning based on keywords like 'how many', 'difference', 'first', etc.")

        # Step 2: Based on the analysis, invoke the most appropriate specialized operator directly
        if "count" in task_type_analysis.lower() or "how many" in task_type_analysis.lower():
            solution = await self.counting_reasoning()
            final_answer = solution['count']
        elif "difference" in task_type_analysis.lower() or "sum" in task_type_analysis.lower() or "total" in task_type_analysis.lower():
            solution = await self.arithmetic_reasoning()
            final_answer = solution['result']
        elif "which happened first" in task_type_analysis.lower() or "earlier" in task_type_analysis.lower() or "earliest" in task_type_analysis.lower():
            solution = await self.comparison_reasoning()
            final_answer = solution['result']
        else:
            # Fallback: use FlexibleCustom for complex multi-step reasoning not covered above
            final_answer = await self.flexible_custom(
                steps=[
                    "Identify all relevant facts from the passage.",
                    "Determine the required operation (count, add, subtract, compare).",
                    "Execute the operation using extracted data.",
                    "Return only the final answer as a number, date, or span."
                ],
                reasoning_pattern="sequential",
                custom_instruction="Now solve the problem by applying the correct reasoning type."
            )

        # Step 3: Review the direct solution for clarity and correctness before returning
        reviewed_answer = await self.review(pre_solution=final_answer)

        # Step 4: Apply ensemble strategy — generate two alternative solutions via flexible_custom and vote
        alt_solution_1 = await self.flexible_custom(
            steps=["Extract key facts.", "Apply reasoning.", "Generate answer."],
            reasoning_pattern="sequential",
            custom_instruction="Solve the problem again with a slightly different approach."
        )
        alt_solution_2 = await self.flexible_custom(
            steps=["Re-read the passage carefully.", "Identify critical numbers or events.", "Answer the question directly."],
            reasoning_pattern="sequential",
            custom_instruction="Solve the problem once more using an alternative interpretation."
        )
        
        # Vote among three solutions: original, alt1, alt2
        ensemble_result = await self.sc_ensemble(solutions=[reviewed_answer, alt_solution_1, alt_solution_2])

        return ensemble_result