# Workflow ID: drop_57_0
# Benchmark: drop
# Data Indices: [370, 234]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """

        # Step 1: Initial breakdown of the problem to identify required reasoning type
        initial_thought = await self.custom(instruction="First, analyze the question and determine whether it requires counting, arithmetic, comparison, or text span extraction.")

        # Step 2: Generate multiple distinct solutions using different strategies
        # Strategy A: Direct extraction + arithmetic (if numeric answer expected)
        solution_a = await self.custom(instruction="Extract relevant numbers from the passage and perform arithmetic to compute the final answer based on the question.")

        # Strategy B: Use dedicated arithmetic reasoning for numerical tasks
        solution_b = await self.arithmetic_reasoning()

        # Strategy C: Use comparison reasoning if the question involves ordering or selection
        solution_c = await self.comparison_reasoning()

        # Strategy D: Counting-based approach if the question asks about quantities
        solution_d = await self.counting_reasoning()

        # Step 3: Ensemble voting to select the most consistent answer
        solutions = [solution_a, solution_b, solution_c, solution_d]
        final_answer = await self.sc_ensemble(solutions=solutions)

        # Optional: Review the final ensemble result for refinement
        refined_answer = await self.review(pre_solution=final_answer)

        return refined_answer