# Workflow ID: drop_165_0
# Benchmark: drop
# Data Indices: [149, 171]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Initial reasoning — understand the question and identify required task type
        initial_thought = await self.custom(instruction="Analyze the question and determine whether it requires counting, arithmetic, comparison, or direct extraction.")

        # Step 2: Based on the task type, apply the appropriate specialized operator
        if "count" in initial_thought.lower() or "how many" in initial_thought.lower():
            solution = await self.counting_reasoning()
        elif "sum" in initial_thought.lower() or "difference" in initial_thought.lower() or "total" in initial_thought.lower():
            solution = await self.arithmetic_reasoning()
        elif "compare" in initial_thought.lower() or "which is more" in initial_thought.lower() or "sort" in initial_thought.lower():
            solution = await self.comparison_reasoning()
        else:
            # Default fallback: use custom to extract directly from passage
            solution = await self.custom(instruction="Extract the answer directly from the passage based on the question.")

        # Step 3: Review the initial solution for clarity, correctness, and logical consistency
        refined_solution = await self.review(pre_solution=solution)

        # Step 4: Final check using ensemble voting (if multiple solutions exist, but we only have one so far)
        # For now, just return the reviewed solution — this can be extended later with multi-solution generation
        return refined_solution