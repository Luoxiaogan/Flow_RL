# Workflow ID: drop_36_0
# Benchmark: drop
# Data Indices: [286, 107]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use flexible_custom to define a multi-step reasoning strategy
        # that first identifies relevant numerical data (years, counts, etc.)
        # then applies arithmetic or comparison reasoning based on question type.
        steps = [
            "Identify all relevant numbers in the passage related to dates or quantities.",
            "Determine what the question is asking: a difference, a count, or a comparison?",
            "Apply appropriate reasoning: arithmetic for differences, comparison for ordering, counting for item totals."
        ]
        reasoning_pattern = "chain_of_thought"
        
        initial_analysis = await self.flexible_custom(
            steps=steps,
            reasoning_pattern=reasoning_pattern,
            custom_instruction="Analyze the passage and extract key numerical information for solving the question."
        )

        # Step 2: Generate multiple solutions using different strategies
        # Strategy A: Direct arithmetic reasoning if the question involves a time difference
        arith_solution = await self.arithmetic_reasoning()

        # Strategy B: Comparison reasoning if the question asks which year had higher population
        comp_solution = await self.comparison_reasoning()

        # Strategy C: Custom step-by-step breakdown to ensure clarity
        custom_solution = await self.custom(instruction="Break down the problem into clear logical steps and solve it carefully.")

        # Step 3: Use sc_ensemble to select the most consistent answer across all solutions
        solutions = [arith_solution, comp_solution, custom_solution]
        final_answer = await self.sc_ensemble(solutions=solutions)

        return final_answer