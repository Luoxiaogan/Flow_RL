# Workflow ID: drop_119_1
# Benchmark: drop
# Data Indices: [142, 187]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to generate multiple distinct solution strategies in parallel
        # This creates different reasoning paths based on the same input — a key divergence from the original
        strategy_prompt = (
            "Generate three different high-level solution strategies for this DROP-style question. "
            "Each should start with a unique initial instruction and apply a different combination of operators."
        )
        strategies = await self.flexible_custom(
            reasoning_pattern="Generate 3 diverse solution plans",
            steps=[
                "Plan A: First extract info via Custom, then apply CountingReasoning.",
                "Plan B: First use ComparisonReasoning directly, then refine with Review.",
                "Plan C: Use ArithmeticReasoning first, then validate with ScEnsemble."
            ],
            custom_instruction=strategy_prompt
        )

        # Step 2: Execute each plan independently — parallel execution of distinct strategies
        solutions = []
        for i, plan in enumerate(strategies.split("||")):
            if "count" in plan.lower():
                sol = await self.counting_reasoning()
                solutions.append(str(sol["count"]))
            elif "compare" in plan.lower():
                sol = await self.comparison_reasoning()
                solutions.append(str(sol["result"]))
            elif "arithmetic" in plan.lower():
                sol = await self.arithmetic_reasoning()
                solutions.append(str(sol["result"]))
            else:
                # Fallback: General extraction + custom reasoning
                extracted = await self.custom(instruction="Extract all relevant facts.")
                final = await self.custom(instruction=f"Based on extracted facts: {extracted}, solve the problem directly.")
                solutions.append(final)

        # Step 3: Use ScEnsemble to select the most consistent answer across all strategies
        final_answer = await self.sc_ensemble(solutions=solutions)
        return final_answer