# Workflow ID: drop_156_1
# Benchmark: drop
# Data Indices: [36, 332]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to define a multi-step reasoning pattern
        # This avoids relying on serial execution of basic operators — instead, it defines a structured plan
        flexible_plan = await self.flexible_custom(
            reasoning_pattern="Extract relevant facts → Apply arithmetic/counting/comparison → Synthesize final answer",
            steps=[
                {"name": "extract", "instruction": "Identify all key numerical or categorical data points in the passage relevant to the question."},
                {"name": "reason", "instruction": "Use appropriate reasoning (arithmetic, counting, comparison) based on the nature of the extracted facts."},
                {"name": "synthesize", "instruction": "Combine insights into a coherent answer that directly addresses the question."}
            ],
            custom_instruction="Execute the full workflow using the defined steps."
        )

        # Step 2: Generate an alternative solution using a different strategy — extract and reason with Custom
        alternate_solution = await self.custom(instruction="First, locate all numbers mentioned in the passage. Then, determine which ones are relevant to the question by comparing them against the query.")

        # Step 3: Use ScEnsemble not just on diverse outputs, but also to resolve conflicts between different logical approaches
        ensemble_result = await self.sc_ensemble(solutions=[flexible_plan, alternate_solution])

        # Step 4: Final review to ensure clarity and correctness before returning
        final_answer = await self.review(pre_solution=ensemble_result)

        return final_answer