# Workflow ID: drop_99_0
# Benchmark: drop
# Data Indices: [233, 336]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use flexible_custom to define a multi-step reasoning plan based on the question type
        reasoning_pattern = "Extract key facts → Identify relevant entities → Compare or count → Synthesize answer"
        steps = [
            "First, identify the main question being asked in the passage.",
            "Next, extract all relevant information needed to answer it.",
            "Then, determine whether the task requires counting, arithmetic, or comparison.",
            "Finally, produce a clear and concise answer based on logical inference."
        ]
        initial_analysis = await self.flexible_custom(
            reasoning_pattern=reasoning_pattern,
            steps=steps,
            custom_instruction="Analyze the question and generate a structured plan to solve it."
        )

        # Step 2: Generate multiple solutions using different strategies
        solution1 = await self.custom(instruction="Use direct extraction: Find the exact answer by scanning the passage for keywords.")
        solution2 = await self.comparison_reasoning()
        solution3 = await self.arithmetic_reasoning()

        # Step 3: Apply ensemble voting to improve robustness
        solutions = [solution1, solution2, solution3]
        final_answer = await self.sc_ensemble(solutions=solutions)

        # Step 4: Review the final answer for clarity and correctness
        reviewed_answer = await self.review(pre_solution=final_answer)

        return reviewed_answer