# Workflow ID: drop_189_0
# Benchmark: drop
# Data Indices: [101, 256]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify what needs to be extracted or reasoned about
        initial_thought = await self.custom(instruction="First, read the passage carefully and determine what information is needed to answer the question. Identify whether this requires counting, arithmetic, comparison, or a combination.")

        # Step 2: Use a flexible custom step to guide structured reasoning — e.g., extract relevant spans, then apply domain-specific logic
        reasoning_plan = await self.flexible_custom(
            steps=[
                "Identify all numerical values mentioned in the passage related to the question.",
                "Determine which value(s) directly answer the question based on context.",
                "If multiple values exist, use comparison or arithmetic to derive the final answer."
            ],
            reasoning_pattern="chain_of_thought",
            custom_instruction="Based on the initial thought, now execute the structured plan to solve the problem."
        )

        # Step 3: Generate an initial solution using the structured reasoning
        answer_generate = await self.custom(instruction=f"Using the structured plan: {reasoning_plan}, generate a direct answer to the question.")

        # Step 4: Review the generated answer for logical consistency and correctness
        refined_answer = await self.review(pre_solution=answer_generate)

        # Step 5: If the problem involves numbers (counting, arithmetic, comparisons), validate with ensemble voting
        # We assume that problems requiring discrete reasoning often benefit from robustness checks
        ensemble_result = await self.sc_ensemble(solutions=[answer_generate, refined_answer])

        return ensemble_result