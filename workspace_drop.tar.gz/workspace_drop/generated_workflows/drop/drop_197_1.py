# Workflow ID: drop_197_1
# Benchmark: drop
# Data Indices: [95, 231]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Strategy: Use FlexibleCustom to define a multi-step reasoning plan with structured steps
        # and then apply ScEnsemble to robustly select the best answer across diverse approaches.

        # Step 1: Define a high-level reasoning pattern that covers multiple possible strategies
        reasoning_pattern = {
            "steps": [
                {"task": "Identify the key question and extract relevant entities from the passage"},
                {"task": "Determine whether the task involves counting, arithmetic, or comparison"},
                {"task": "Generate a solution using the most appropriate specialized operator"},
                {"task": "Refine the solution through review to eliminate hallucinations or errors"}
            ],
            "custom_instruction": "Think step-by-step and solve the problem using the following strategy: first identify what needs to be found, then choose the right tool (counting/arithmetic/comparison), then generate an answer, and finally refine it."
        }

        # Step 2: Execute the flexible custom workflow — this runs a multi-step internal plan
        flexible_solution = await self.flexible_custom(
            reasoning_pattern=reasoning_pattern,
            steps=reasoning_pattern["steps"],
            custom_instruction=reasoning_pattern["custom_instruction"]
        )

        # Step 3: Generate alternative solutions using different reasoning paths
        # This is the core difference: instead of one path, we now try 3 distinct approaches
        # each using a different operator sequence or instruction focus

        # Alternative 1: Direct extraction via Custom
        alt1 = await self.custom(instruction="Extract the exact answer from the passage without additional reasoning.")

        # Alternative 2: Arithmetic reasoning (even if not arithmetic, let the model decide)
        alt2 = await self.arithmetic_reasoning()

        # Alternative 3: Comparison reasoning (e.g., to find who scored more, or which item is larger)
        alt3 = await self.comparison_reasoning()

        # Step 4: Use ScEnsemble to vote on the most consistent answer among alternatives
        final_answer = await self.sc_ensemble(solutions=[flexible_solution, alt1, alt2, alt3])

        return final_answer