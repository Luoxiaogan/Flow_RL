# Workflow ID: drop_190_0
# Benchmark: drop
# Data Indices: [376, 258]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify required reasoning type
        initial_thought = await self.custom(instruction="Read the passage carefully and determine what kind of reasoning is needed (e.g., counting, arithmetic, comparison, or span extraction).")

        # Step 2: Use FlexibleCustom to apply a structured multi-step strategy based on the identified reasoning type
        reasoning_pattern = "sequential"  # We'll use step-by-step reasoning as it's most general
        steps = [
            "Identify the key information in the passage relevant to the question.",
            "Determine whether the answer requires counting items, performing arithmetic, comparing values, or extracting a text span.",
            "Apply the appropriate specialized operator (Counting, Arithmetic, Comparison, or Custom) to solve the subtask.",
            "Synthesize the result into a final answer that directly addresses the question."
        ]
        custom_instruction = "Based on the initial thought, now execute the following steps: " + "; ".join(steps)

        solution = await self.flexible_custom(
            reasoning_pattern=reasoning_pattern,
            steps=steps,
            custom_instruction=custom_instruction
        )

        # Step 3: Optionally refine the solution using review for correctness
        refined_solution = await self.review(pre_solution=solution)

        # Step 4: Final ensemble step — only one solution so far, but this allows future expansion
        final_answer = await self.sc_ensemble(solutions=[refined_solution])

        return final_answer