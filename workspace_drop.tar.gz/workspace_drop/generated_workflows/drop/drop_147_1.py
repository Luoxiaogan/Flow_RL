# Workflow ID: drop_147_1
# Benchmark: drop
# Data Indices: [210, 12]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to define a structured multi-step plan
        # This avoids sequential single-operator calls and instead defines a reasoning pattern upfront
        steps = [
            "Extract relevant numerical data from the passage.",
            "Determine the type of reasoning needed (counting, arithmetic, comparison).",
            "Apply the appropriate specialized reasoning operator.",
            "Format the final answer based on the result."
        ]
        reasoning_pattern = "Sequential reasoning with explicit step decomposition"
        
        plan = await self.flexible_custom(
            steps=steps,
            reasoning_pattern=reasoning_pattern,
            custom_instruction="Follow the plan exactly to solve the problem."
        )

        # Step 2: Execute each step in parallel using multiple Custom calls
        # Instead of serial execution, we generate all intermediate answers concurrently
        extraction = await self.custom(instruction="Identify key numbers and entities related to the question.")
        reasoning_type = await self.custom(instruction="Classify the required reasoning type: counting, arithmetic, or comparison.")
        solution_attempt = await self.custom(instruction=f"Based on extracted facts: {extraction}, and reasoning type: {reasoning_type}, now solve the problem directly.")

        # Step 3: Use ScEnsemble to evaluate multiple solutions — one direct attempt + one review-based fix
        # This introduces a different ensemble strategy: compare raw solution vs refined one
        reviewed_solution = await self.review(pre_solution=solution_attempt)
        solutions = [solution_attempt, reviewed_solution]
        final_answer = await self.sc_ensemble(solutions=solutions)

        # Step 4: Final formatting — ensure output matches expected type (number, span, etc.)
        formatted_answer = await self.custom(instruction=f"Return only the final answer. If it's a number, return just the number. If it's text, return the exact phrase from the passage. Input: {final_answer}")
        
        return formatted_answer