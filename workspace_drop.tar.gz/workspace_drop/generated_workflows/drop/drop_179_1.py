# Workflow ID: drop_179_1
# Benchmark: drop
# Data Indices: [238, 74]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Generate an initial solution using Custom with a structured prompt
        initial_solution = await self.custom(instruction="First, identify all relevant numbers in the passage and determine what operation (e.g., average, difference, count) must be applied to answer the question. Then compute the result directly.")

        # Step 2: Use ComparisonReasoning *first* to detect if the question involves ordering or extremes (like longest/shortest), which may require sorting or selection
        comparison_result = await self.comparison_reasoning()
        has_extreme_query = "longest" in self.problem_text.lower() or "shortest" in self.problem_text.lower()

        # Step 3: If it's about extremes, use that result directly; otherwise, fall back to arithmetic reasoning
        if has_extreme_query:
            final_answer = comparison_result
        else:
            # Step 4: Try arithmetic reasoning as fallback — this is a different control flow than the original
            arithmetic_result = await self.arithmetic_reasoning()
            final_answer = arithmetic_result

        # Step 5: Now apply Review *before* ensemble — this is a new sequence compared to the existing workflow
        reviewed_solution = await self.review(pre_solution=final_answer)

        # Step 6: Instead of running multiple solutions in parallel via ScEnsemble, we now use FlexibleCustom to re-solve using a completely different strategy — e.g., step-by-step breakdown vs direct calculation
        alternative_solution = await self.flexible_custom(
            reasoning_pattern="sequential",
            steps=[
                {"step": "Read the question and extract the exact numerical values needed."},
                {"step": "Recompute the required math manually based on those values."},
                {"step": "Output only the final number without explanation."}
            ],
            custom_instruction="Solve the problem again using a step-by-step approach."
        )

        # Step 7: Final ensemble — but now we don't just vote; we select the best one by comparing their structure and clarity
        ensemble_result = await self.sc_ensemble(solutions=[reviewed_solution, alternative_solution])

        return ensemble_result