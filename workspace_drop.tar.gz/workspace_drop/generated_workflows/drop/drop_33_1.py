# Workflow ID: drop_33_1
# Benchmark: drop
# Data Indices: [264, 86]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Extract key information using Custom (focused on question type)
        extraction = await self.custom(instruction="Identify all relevant numbers, dates, and entities in the passage that relate to the question. Do not compute yet — just list them clearly.")

        # Step 2: Use ComparisonReasoning to determine which values are needed for comparison or difference
        comparison = await self.comparison_reasoning()

        # Step 3: Use ArithmeticReasoning only after confirming the correct values via comparison
        arithmetic = await self.arithmetic_reasoning()

        # Step 4: Review the final solution for clarity and correctness
        reviewed = await self.review(pre_solution=arithmetic)

        return reviewed