# Workflow ID: drop_179_0
# Benchmark: drop
# Data Indices: [238, 74]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify relevant numerical data
        initial_thought = await self.custom(instruction="First, read the question carefully and extract all relevant numerical values mentioned in the passage that relate to the query.")
        
        # Step 2: Use FlexibleCustom with a sequential reasoning pattern to guide structured extraction and calculation
        reasoning_pattern = "sequential"
        steps = [
            {"step": "Identify the key numbers needed to answer the question (e.g., field goals, punt returns, touchdowns)."},
            {"step": "Extract each number from the passage using precise language."},
            {"step": "Apply arithmetic reasoning to compute the required result (e.g., average, difference, sum)."}
        ]
        intermediate_solution = await self.flexible_custom(
            reasoning_pattern=reasoning_pattern,
            steps=steps,
            custom_instruction=f"Based on the initial thought: {initial_thought}, now execute the steps to solve the problem."
        )

        # Step 3: If the solution involves comparisons or sorting (like longest vs shortest), use ComparisonReasoning
        if "longest" in self.problem_text.lower() or "shortest" in self.problem_text.lower():
            comparison_result = await self.comparison_reasoning()
            final_answer = comparison_result
        # Step 4: If it's about counting items (e.g., how many touchdowns), use CountingReasoning
        elif "how many" in self.problem_text.lower() or "count" in self.problem_text.lower():
            count_result = await self.counting_reasoning()
            final_answer = count_result
        # Step 5: Otherwise, assume it's an arithmetic task (e.g., averages, differences, sums)
        else:
            arithmetic_result = await self.arithmetic_reasoning()
            final_answer = arithmetic_result

        # Step 6: Review the solution for correctness and clarity
        reviewed_solution = await self.review(pre_solution=final_answer)

        # Step 7: Use SC Ensemble to improve robustness by combining multiple solutions if possible
        # Since we only have one path, we simulate ensemble by re-running with a different strategy
        alternative_solution = await self.custom(instruction="Re-solve the problem using a completely different reasoning approach.")
        ensemble_result = await self.sc_ensemble(solutions=[reviewed_solution, alternative_solution])

        return ensemble_result