# Workflow ID: drop_155_0
# Benchmark: drop
# Data Indices: [105, 92]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Initial reasoning — identify the task type (counting, arithmetic, comparison)
        initial_thought = await self.custom(instruction="First, analyze the question and determine what kind of reasoning is needed: counting, arithmetic, or comparison.")
        
        # Step 2: Based on the task type, invoke the appropriate expert
        if "count" in initial_thought.lower() or "how many" in initial_thought.lower():
            reasoning_result = await self.counting_reasoning()
            answer = reasoning_result["count"]
        elif "sum" in initial_thought.lower() or "difference" in initial_thought.lower() or "total" in initial_thought.lower():
            reasoning_result = await self.arithmetic_reasoning()
            answer = reasoning_result["result"]
        elif "compare" in initial_thought.lower() or "which is more" in initial_thought.lower() or "sort" in initial_thought.lower():
            reasoning_result = await self.comparison_reasoning()
            answer = reasoning_result["result"]
        else:
            # Fallback: use flexible custom for complex multi-step tasks
            answer = await self.flexible_custom(
                steps=[
                    {"name": "identify_task", "instruction": "Identify whether this requires counting, arithmetic, or comparison."},
                    {"name": "execute_reasoning", "instruction": "Based on the identified task, perform the necessary reasoning step."}
                ],
                reasoning_pattern="sequential",
                custom_instruction="Now synthesize the results into a final answer."
            )

        # Step 3: Review the solution to improve clarity and correctness
        reviewed_answer = await self.review(pre_solution=answer)

        # Step 4: Use ensemble voting if multiple solutions are possible (e.g., for ambiguous cases)
        # Since we only have one answer so far, simulate ensemble with review result
        final_answer = await self.sc_ensemble(solutions=[reviewed_answer])

        return final_answer