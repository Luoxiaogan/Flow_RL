# Workflow ID: drop_0_1
# Benchmark: drop
# Data Indices: [5, 166]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to define a multi-step reasoning plan based on question type
        reasoning_pattern = "Identify the key task (counting/arithmetic/comparison/span), extract relevant data, then solve step-by-step."
        steps = [
            "First, analyze the question to determine whether it requires counting, arithmetic, comparison, or span extraction.",
            "Next, locate all relevant events or values in the passage that relate to the task.",
            "Then, apply the appropriate reasoning strategy using dedicated operators like ArithmeticReasoning, CountingReasoning, etc.",
            "Finally, synthesize the answer and validate consistency with the passage."
        ]
        initial_plan = await self.flexible_custom(
            reasoning_pattern=reasoning_pattern,
            steps=steps,
            custom_instruction="Generate a structured plan to solve this DROP-style problem."
        )

        # Step 2: Execute the plan by calling specialized operators in sequence
        # This avoids generating multiple solutions first — instead, we follow one clear path
        if "count" in initial_plan.lower():
            count_result = await self.counting_reasoning()
            final_answer = count_result
        elif "arithmetic" in initial_plan.lower() or "sum" in initial_plan.lower() or "difference" in initial_plan.lower():
            arith_result = await self.arithmetic_reasoning()
            final_answer = arith_result
        elif "compare" in initial_plan.lower() or "sort" in initial_plan.lower():
            comp_result = await self.comparison_reasoning()
            final_answer = comp_result
        else:
            # Fallback: General extraction via Custom
            final_answer = await self.custom(instruction="Extract the required information directly from the passage based on the question.")

        # Step 3: Review the solution to improve clarity and correctness
        reviewed_answer = await self.review(pre_solution=final_answer)

        # Step 4: Use ScEnsemble only as a final safeguard — not for primary generation
        # This ensures robustness without overcomplicating the main logic flow
        ensemble_final = await self.sc_ensemble(solutions=[reviewed_answer])

        return ensemble_final