# Workflow ID: drop_135_0
# Benchmark: drop
# Data Indices: [65, 359]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question type and extract relevant information
        initial_thought = await self.custom(instruction="Identify what needs to be extracted from the passage and determine the reasoning type (counting, arithmetic, comparison).")

        # Step 2: If the question involves counting items (e.g., "how many field goals"), use CountingReasoning
        if "how many" in initial_thought.lower() or "count" in initial_thought.lower():
            count_result = await self.counting_reasoning()
            return count_result["count"]

        # Step 3: If the question involves sums, differences, or mathematical operations, use ArithmeticReasoning
        elif "total points" in initial_thought.lower() or "sum" in initial_thought.lower() or "difference" in initial_thought.lower():
            arithmetic_result = await self.arithmetic_reasoning()
            return arithmetic_result["result"]

        # Step 4: If the question compares values (e.g., shortest, longest, highest), use ComparisonReasoning
        elif "which" in initial_thought.lower() and ("shortest" in initial_thought.lower() or "longest" in initial_thought.lower()):
            comparison_result = await self.comparison_reasoning()
            return comparison_result["result"]

        # Step 5: General reasoning step — use Custom for complex multi-step problems
        else:
            final_answer = await self.custom(instruction="Based on the analysis, solve the problem step-by-step using the appropriate operators.")
            return final_answer