# Workflow ID: drop_150_1
# Benchmark: drop
# Data Indices: [91, 283]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to define a multi-step reasoning pattern that first identifies relevant field goals,
        # then filters them by distance range (25–50 yards), and finally counts them — all in one structured workflow.
        steps = [
            "Identify all field goals mentioned in the passage with their distances.",
            "Filter those with distances between 25 and 50 yards (inclusive).",
            "Count the filtered field goals."
        ]
        reasoning_pattern = "Sequential filtering and counting"
        
        final_result = await self.flexible_custom(
            steps=steps,
            reasoning_pattern=reasoning_pattern,
            custom_instruction="Extract field goal data, filter by range [25,50], and count the results."
        )

        # Step 2: Review the result for clarity and correctness using the Review operator.
        reviewed_result = await self.review(pre_solution=final_result)

        # Step 3: Return the reviewed result as the final answer.
        return reviewed_result