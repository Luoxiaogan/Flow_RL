# Workflow ID: drop_14_1
# Benchmark: drop
# Data Indices: [24, 290]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom with a parallel reasoning pattern to generate multiple candidate answers
        # This leverages the ability to run different strategies in parallel within one call
        parallel_solution = await self.flexible_custom(
            steps=[
                "Identify all possible interpretations or relevant spans in the passage.",
                "Apply counting, arithmetic, and comparison reasoning independently to each interpretation.",
                "Generate a distinct answer for each type of reasoning (e.g., count events, compute time differences, compare sequences)."
            ],
            reasoning_pattern="parallel",
            custom_instruction="Now execute this multi-path reasoning to produce several candidate answers."
        )

        # Step 2: Extract individual candidate solutions from the structured output of FlexibleCustom
        candidates = await self.custom(instruction=f"From the following solution, extract each distinct candidate answer: {parallel_solution}. Return them as a list of strings.")

        # Step 3: Use Review to refine each candidate before ensemble voting
        refined_candidates = []
        for candidate in candidates:
            refined = await self.review(pre_solution=candidate)
            refined_candidates.append(refined)

        # Step 4: Apply ScEnsemble to select the most consistent answer across refined candidates
        final_answer = await self.sc_ensemble(solutions=refined_candidates)

        return final_answer