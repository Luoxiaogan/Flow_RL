# Workflow ID: drop_17_0
# Benchmark: drop
# Data Indices: [298, 83]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify what needs to be extracted or reasoned
        initial_thought = await self.custom(instruction="Read the passage carefully and identify the key information needed to answer the question. Determine whether this is a counting, arithmetic, comparison, or span-extraction task.")
        
        # Step 2: Use specialized reasoning based on the type of question
        if "count" in initial_thought.lower() or "how many" in initial_thought.lower():
            count_result = await self.counting_reasoning()
            return count_result['count']
            
        elif "sum" in initial_thought.lower() or "difference" in initial_thought.lower() or "total" in initial_thought.lower():
            arithmetic_result = await self.arithmetic_reasoning()
            return arithmetic_result['result']
            
        elif "compare" in initial_thought.lower() or "which is more" in initial_thought.lower() or "order" in initial_thought.lower():
            comparison_result = await self.comparison_reasoning()
            return comparison_result['result']
            
        else:
            # For span extraction or other tasks, use custom with precise instruction
            final_answer = await self.custom(instruction="Extract the exact answer from the passage based on the question. Do not paraphrase — return the original text that directly answers the question.")
            return final_answer