# Workflow ID: drop_98_0
# Benchmark: drop
# Data Indices: [76, 313]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the task by breaking it down
        initial_thought = await self.custom(instruction="First, identify what type of reasoning is needed: counting, arithmetic, comparison, or text span extraction. Then determine the key information to extract from the passage.")

        # Step 2: Based on the question type, choose appropriate reasoning path
        # For DROP-like problems, we often need to first extract relevant info and then reason over it
        extraction_step = await self.custom(instruction="Extract all relevant events from the passage that relate to the question. Focus only on numbers, scores, and timelines.")

        # Step 3: If the question involves counting (e.g., how many touchdowns), use CountingReasoning
        if "how many" in self.problem.lower() or "count" in self.problem.lower():
            count_result = await self.counting_reasoning()
            final_answer = count_result.strip()
        # Step 4: If the question involves math (e.g., difference between two scores), use ArithmeticReasoning
        elif "difference" in self.problem.lower() or "sum" in self.problem.lower() or "total" in self.problem.lower():
            arithmetic_result = await self.arithmetic_reasoning()
            final_answer = arithmetic_result.strip()
        # Step 5: If the question asks about order or comparison (e.g., which team scored last), use ComparisonReasoning
        elif "which team" in self.problem.lower() or "last score" in self.problem.lower() or "earliest" in self.problem.lower() or "latest" in self.problem.lower():
            comparison_result = await self.comparison_reasoning()
            final_answer = comparison_result.strip()
        # Step 6: Otherwise, fallback to a general custom instruction for complex reasoning
        else:
            final_answer = await self.custom(instruction="Solve the problem based on the extracted information. Think step-by-step and provide the final answer clearly.")

        # Step 7: Review the solution for correctness and clarity
        reviewed_solution = await self.review(pre_solution=final_answer)

        # Step 8: Use ensemble voting if multiple solutions exist (for robustness)
        # In this case, we generate one solution so sc_ensemble isn't strictly necessary,
        # but it's included as a strategic safeguard for future extensibility
        final_output = await self.sc_ensemble(solutions=[reviewed_solution])

        return final_output