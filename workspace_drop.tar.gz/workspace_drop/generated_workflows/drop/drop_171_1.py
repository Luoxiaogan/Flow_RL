# Workflow ID: drop_171_1
# Benchmark: drop
# Data Indices: [38, 249]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to define a structured multi-step plan
        steps = [
            {"task": "Identify what kind of reasoning is required (counting, arithmetic, comparison).", "type": "classification"},
            {"task": "Extract all relevant numerical or categorical data from the passage.", "type": "extraction"},
            {"task": "Apply the appropriate specialized operator based on classification.", "type": "execution"}
        ]
        initial_plan = await self.flexible_custom(
            steps=steps,
            reasoning_pattern="classify-extract-execute",
            custom_instruction="Now generate a precise answer based on the structured plan."
        )

        # Step 2: Review the plan before execution to improve clarity and correctness
        refined_plan = await self.review(pre_solution=initial_plan)

        # Step 3: Execute using the most suitable operator directly — no ensemble needed yet
        # This is the key difference: we now decide *which* operator to call based on the refined plan
        if "count" in refined_plan.lower() or "how many" in refined_plan.lower():
            final_answer = await self.counting_reasoning()
        elif "sum" in refined_plan.lower() or "total" in refined_plan.lower() or "+" in refined_plan:
            final_answer = await self.arithmetic_reasoning()
        elif "compare" in refined_plan.lower() or "shortest" in refined_plan.lower() or "longest" in refined_plan.lower():
            final_answer = await self.comparison_reasoning()
        else:
            # Fallback: use Custom for general reasoning if nothing else fits
            final_answer = await self.custom(instruction="Use step-by-step reasoning to solve the problem based on the refined plan.")

        # Step 4: Final review to polish the output — not just fix, but enhance clarity
        polished_answer = await self.review(pre_solution=final_answer)

        return polished_answer