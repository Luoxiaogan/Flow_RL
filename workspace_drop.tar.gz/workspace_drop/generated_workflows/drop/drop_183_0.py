# Workflow ID: drop_183_0
# Benchmark: drop
# Data Indices: [267, 254]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and extract relevant information
        initial_thought = await self.custom(instruction="First, read the question carefully and identify what needs to be found. Then, locate all relevant information in the passage that pertains to this question.")
        
        # Step 2: Determine the type of reasoning required (counting, arithmetic, comparison)
        reasoning_type = await self.custom(instruction="Based on the question, determine whether it requires counting, arithmetic, or comparison reasoning. Only one type should be used.")
        
        # Step 3: Perform the appropriate reasoning task
        if "count" in reasoning_type.lower() or "how many" in reasoning_type.lower():
            result = await self.counting_reasoning()
        elif "sum" in reasoning_type.lower() or "total" in reasoning_type.lower() or "difference" in reasoning_type.lower() or "add" in reasoning_type.lower() or "subtract" in reasoning_type.lower():
            result = await self.arithmetic_reasoning()
        elif "compare" in reasoning_type.lower() or "which is more" in reasoning_type.lower() or "order" in reasoning_type.lower():
            result = await self.comparison_reasoning()
        else:
            # Fallback: Use custom reasoning for complex or ambiguous cases
            result = await self.custom(instruction="Use step-by-step reasoning to solve the problem based on the passage and question.")
        
        # Step 4: Finalize answer by extracting the correct value or span
        final_answer = await self.custom(instruction=f"From the reasoning result: {result}, extract the final answer as a number or text span. Ensure it directly answers the original question without adding extra explanation.")
        
        return final_answer