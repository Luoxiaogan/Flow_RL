# Workflow ID: drop_71_1
# Benchmark: drop
# Data Indices: [306, 152]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Strategy: First, extract key information using Custom (not just classification)
        extraction = await self.custom(instruction="Extract all relevant facts and numerical data from the passage that could be used to answer the question.")

        # Then, generate multiple candidate solutions in parallel using different reasoning paths
        counting_solution = self.counting_reasoning()
        arithmetic_solution = self.arithmetic_reasoning()
        comparison_solution = self.comparison_reasoning()

        # Wait for all three to complete before proceeding — this is a parallel execution strategy
        solutions = await asyncio.gather(counting_solution, arithmetic_solution, comparison_solution)

        # Now, apply ensemble voting to select the most consistent answer across all strategies
        final_answer = await self.sc_ensemble(solutions=solutions)

        # Finally, review the final ensemble result to ensure clarity and correctness
        refined_answer = await self.review(pre_solution=final_answer)

        return refined_answer