# Workflow ID: drop_15_1
# Benchmark: drop
# Data Indices: [50, 265]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom with a sequential reasoning pattern to extract and process key facts
        extraction_step = await self.flexible_custom(
            steps=[
                {"name": "identify_relevant_entities", "instruction": "Identify all field goals mentioned in the passage along with their distances."},
                {"name": "filter_by_team", "instruction": "If the question asks about a specific team, filter only field goals made by that team."},
                {"name": "extract_numerical_values", "instruction": "Extract numerical values (like yardages) from the filtered list for further processing."}
            ],
            reasoning_pattern="sequential",
            custom_instruction="Process the passage step-by-step to isolate relevant field goal data."
        )

        # Step 2: Use ComparisonReasoning to directly find the minimum value among extracted numbers
        comparison_result = await self.comparison_reasoning()
        
        # Step 3: Use Review to refine the comparison result into a clear, concise answer
        final_answer = await self.review(pre_solution=comparison_result)

        return final_answer