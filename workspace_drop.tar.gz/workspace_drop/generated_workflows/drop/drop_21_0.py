# Workflow ID: drop_21_0
# Benchmark: drop
# Data Indices: [59, 297]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify what type of reasoning is needed
        initial_thought = await self.custom(instruction="First, analyze the question to determine whether it requires counting, arithmetic, comparison, or a combination. Identify key entities and numerical references in the passage.")

        # Step 2: Generate an initial answer using the most appropriate reasoning expert
        if "count" in self.problem.lower() or "how many" in self.problem.lower():
            answer = await self.counting_reasoning()
        elif "sum" in self.problem.lower() or "difference" in self.problem.lower() or "total" in self.problem.lower():
            answer = await self.arithmetic_reasoning()
        elif "compare" in self.problem.lower() or "which is more" in self.problem.lower() or "highest" in self.problem.lower() or "lowest" in self.problem.lower():
            answer = await self.comparison_reasoning()
        else:
            # Fallback: Use flexible custom for complex multi-step reasoning
            answer = await self.flexible_custom(
                steps=[
                    {"instruction": "Identify all relevant information in the passage related to the question."},
                    {"instruction": "Determine the logical operations required to derive the answer (e.g., addition, subtraction, sorting)."},
                    {"instruction": "Execute the necessary operations step-by-step."}
                ],
                reasoning_pattern="chain_of_thought",
                custom_instruction="Solve the problem based on the structured plan above."
            )

        # Step 3: Review the solution for correctness and clarity
        refined_answer = await self.review(pre_solution=answer)

        # Step 4: Use ensemble voting to improve robustness if multiple solutions exist
        # For now, we assume one solution; this can be extended with multiple runs
        final_result = refined_answer

        return final_result