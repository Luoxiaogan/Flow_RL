# Workflow ID: drop_30_0
# Benchmark: drop
# Data Indices: [217, 40]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Initial breakdown and identification of required reasoning type
        initial_thought = await self.custom(instruction="Identify whether the problem requires counting, arithmetic, or comparison. Also, extract key numbers and entities from the passage relevant to the question.")
        
        # Step 2: Use flexible_custom to define a multi-step strategy based on the identified task
        reasoning_pattern = "Determine the needed operation (e.g., count, add, subtract, compare), then compute step-by-step."
        steps = [
            "Extract relevant numerical values from the text",
            "Apply the correct reasoning type (arithmetic, counting, or comparison)",
            "Compute final result using structured reasoning"
        ]
        solution_attempt = await self.flexible_custom(
            reasoning_pattern=reasoning_pattern,
            steps=steps,
            custom_instruction=f"Based on the initial thought: {initial_thought}, solve the problem using the defined steps."
        )
        
        # Step 3: Review the solution to improve clarity and correctness
        refined_solution = await self.review(pre_solution=solution_attempt)
        
        # Step 4: Final output — return the refined answer directly
        return refined_solution