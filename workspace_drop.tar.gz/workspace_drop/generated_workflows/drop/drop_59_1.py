# Workflow ID: drop_59_1
# Benchmark: drop
# Data Indices: [97, 87]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to define a multi-step reasoning plan based on the question type
        reasoning_pattern = "Identify the key task from the question, then apply the most appropriate reasoning strategy (counting, arithmetic, comparison, or extraction)."
        steps = [
            "Read the question carefully and determine what needs to be found.",
            "Decide whether this requires counting, arithmetic, comparison, or simple text extraction.",
            "Apply the corresponding specialized operator to solve it.",
            "Review the result for clarity and correctness."
        ]
        custom_instruction = "Based on the passage and question, execute the following steps: {steps}."

        # Execute the structured plan using FlexibleCustom
        initial_solution = await self.flexible_custom(
            reasoning_pattern=reasoning_pattern,
            steps=steps,
            custom_instruction=custom_instruction
        )

        # Step 2: Immediately review the solution — early refinement prevents cascading errors
        refined_solution = await self.review(pre_solution=initial_solution)

        # Step 3: Generate an alternative solution using a different path — e.g., direct extraction via Custom
        fallback_solution = await self.custom(instruction="Extract the answer directly from the passage without intermediate reasoning.")

        # Step 4: Use ensemble voting between the two distinct solutions
        final_answer = await self.sc_ensemble(solutions=[refined_solution, fallback_solution])

        return final_answer