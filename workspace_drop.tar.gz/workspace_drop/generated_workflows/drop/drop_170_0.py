# Workflow ID: drop_170_0
# Benchmark: drop
# Data Indices: [32, 154]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify required reasoning type
        initial_thought = await self.custom(instruction="First, analyze the question to determine whether it requires counting, arithmetic, or comparison reasoning.")
        
        # Step 2: Extract relevant information from the passage
        extraction = await self.custom(instruction="Now, extract all key numerical or item-based data mentioned in the passage that relates to the question.")
        
        # Step 3: Determine which specialized reasoning operator to use
        reasoning_type = await self.custom(instruction=f"Based on the question and extracted data: {extraction}, decide whether the task involves counting, arithmetic, or comparison. Respond with one word: 'counting', 'arithmetic', or 'comparison'.")
        
        # Step 4: Perform the appropriate reasoning step
        if "counting" in reasoning_type.lower():
            result = await self.counting_reasoning()
        elif "arithmetic" in reasoning_type.lower():
            result = await self.arithmetic_reasoning()
        elif "comparison" in reasoning_type.lower():
            result = await self.comparison_reasoning()
        else:
            # Fallback to general custom instruction if no clear match
            result = await self.custom(instruction="Use logical reasoning based on the extracted data to solve the problem.")
        
        # Step 5: Final answer formatting and refinement
        final_answer = await self.custom(instruction=f"Using the reasoning result: {result}, format the final answer clearly and concisely as per the original question.")
        
        # Optional: Use ensemble or review for robustness (if needed)
        # Uncomment below lines for added reliability:
        # refined_answer = await self.review(pre_solution=final_answer)
        # final_answer = await self.sc_ensemble(solutions=[final_answer, refined_answer])
        
        return final_answer