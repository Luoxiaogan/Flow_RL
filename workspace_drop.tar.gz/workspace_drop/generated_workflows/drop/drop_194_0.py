# Workflow ID: drop_194_0
# Benchmark: drop
# Data Indices: [131, 89]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify what needs to be extracted or reasoned about
        initial_thought = await self.custom(instruction="First, analyze the question to determine whether it requires counting, arithmetic, comparison, or span extraction. Identify key entities mentioned in the question.")

        # Step 2: Use FlexibleCustom with a sequential reasoning pattern to break down the problem into steps
        # This allows us to define multi-step logic without writing Python control flow
        reasoning_steps = [
            {"step": "Identify all relevant events in the passage that relate to the question."},
            {"step": "Extract numerical values (e.g., yard lines) or textual spans involved in these events."},
            {"step": "Apply appropriate reasoning (counting, arithmetic, comparison) based on the question type."},
            {"step": "Determine the final answer by synthesizing the results of the previous steps."}
        ]
        
        structured_solution = await self.flexible_custom(
            reasoning_pattern="sequential",
            steps=reasoning_steps,
            custom_instruction="Based on the initial analysis, execute each step logically to solve the problem."
        )

        # Step 3: Review the solution for clarity, correctness, and alignment with the question
        refined_solution = await self.review(pre_solution=structured_solution)

        # Step 4: If multiple solutions exist (e.g., from different interpretations), use ensemble voting for robustness
        # For now, we assume one solution exists; this structure enables future expansion
        final_answer = await self.sc_ensemble(solutions=[refined_solution])

        return final_answer