# Workflow ID: drop_152_1
# Benchmark: drop
# Data Indices: [182, 198]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: First, determine what kind of reasoning is required by analyzing the question
        reasoning_type = await self.custom(instruction="Determine whether the question requires counting, arithmetic, comparison, or text span extraction. Respond with exactly one word: 'counting', 'arithmetic', 'comparison', or 'span'.")
        
        # Step 2: Based on the reasoning type, invoke the specialized expert directly
        if "counting" in reasoning_type.lower():
            result = await self.counting_reasoning()
            final_answer = result["count"]
        elif "arithmetic" in reasoning_type.lower():
            result = await self.arithmetic_reasoning()
            final_answer = result["result"]
        elif "comparison" in reasoning_type.lower():
            result = await self.comparison_reasoning()
            final_answer = result["result"]
        else:
            # If it's a span-based answer (e.g., who scored the longest TD), use custom to extract
            final_answer = await self.custom(instruction="Extract the exact span of text that answers the question. Do not paraphrase or summarize.")
        
        # Step 3: Use ensemble to validate against potential hallucinations — this is a key difference!
        # Instead of reviewing first, we now use ScEnsemble as a primary safeguard *after* initial solving
        # This ensures robustness without relying solely on post-hoc refinement
        final_answer = await self.sc_ensemble(solutions=[final_answer])
        
        return final_answer