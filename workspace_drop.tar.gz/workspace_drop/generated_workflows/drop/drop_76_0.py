# Workflow ID: drop_76_0
# Benchmark: drop
# Data Indices: [382, 203]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Initial reasoning — break down the problem and identify what type of task it is
        initial_thought = await self.custom(instruction="First, analyze the question to determine whether it requires counting, arithmetic, comparison, or information extraction.")

        # Step 2: Based on the initial thought, choose the appropriate reasoning path
        if "count" in initial_thought.lower() or "how many" in initial_thought.lower():
            count_result = await self.counting_reasoning()
            final_answer = count_result.strip()
        elif "sum" in initial_thought.lower() or "difference" in initial_thought.lower() or "total" in initial_thought.lower():
            arith_result = await self.arithmetic_reasoning()
            final_answer = arith_result.strip()
        elif "compare" in initial_thought.lower() or "which came first" in initial_thought.lower() or "earlier" in initial_thought.lower():
            comp_result = await self.comparison_reasoning()
            final_answer = comp_result.strip()
        else:
            # General fallback: extract relevant info via custom step-by-step thinking
            general_solution = await self.custom(instruction="Think step-by-step: Identify key entities, events, or values mentioned in the passage relevant to the question. Then synthesize a concise answer.")
            final_answer = general_solution.strip()

        # Step 3: Refine the solution using Review to improve clarity and correctness
        refined_answer = await self.review(pre_solution=final_answer)

        # Step 4: Use ensemble voting to enhance robustness (if multiple solutions exist)
        # For now, just return the refined single answer — we don't have multiple candidates yet
        return refined_answer