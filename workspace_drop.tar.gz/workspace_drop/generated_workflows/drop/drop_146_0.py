# Workflow ID: drop_146_0
# Benchmark: drop
# Data Indices: [75, 244]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Initial reasoning — understand the question and extract relevant info
        initial_thought = await self.custom(instruction="First, read the passage carefully and identify what information is needed to answer the question.")
        
        # Step 2: Determine type of reasoning required based on the question
        reasoning_type = await self.custom(instruction="Based on the question, determine whether it requires counting, arithmetic, comparison, or simple extraction.")
        
        # Step 3: Apply appropriate reasoning operator
        if "count" in reasoning_type.lower():
            result = await self.counting_reasoning()
        elif "arithmetic" in reasoning_type.lower() or "sum" in reasoning_type.lower() or "difference" in reasoning_type.lower():
            result = await self.arithmetic_reasoning()
        elif "compare" in reasoning_type.lower() or "which group" in reasoning_type.lower() or "more than" in reasoning_type.lower():
            result = await self.comparison_reasoning()
        else:
            # Fallback: use flexible custom for general reasoning (e.g., extracting a span or name)
            result = await self.custom(instruction="Extract the exact answer directly from the passage based on the question.")

        # Step 4: Review the solution for clarity, correctness, and alignment with the question
        refined_result = await self.review(pre_solution=result)

        # Step 5: Use ensemble voting if multiple solutions were generated earlier (optional enhancement)
        # For now, we assume single solution; but this structure allows future expansion
        final_answer = refined_result

        return final_answer