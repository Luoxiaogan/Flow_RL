# Workflow ID: drop_86_1
# Benchmark: drop
# Data Indices: [18, 53]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Strategy: Use parallel reasoning paths — generate 3 distinct solutions using different approaches
        # Then use sc_ensemble to pick the most consistent answer (robustness via voting)
        
        # Path 1: Direct extraction using flexible custom (for text spans or simple facts)
        solution1 = await self.flexible_custom(
            reasoning_pattern="Extract the answer directly from the passage based on the question.",
            steps=[
                "Read the question carefully to determine what needs to be extracted.",
                "Scan the passage for the specific information that matches the query.",
                "Return only the exact phrase or value that answers the question."
            ],
            custom_instruction="Extract the answer directly from the passage using step-by-step reasoning."
        )

        # Path 2: Use counting reasoning if it's a count-type question
        if "how many" in self.problem.lower() or "count" in self.problem.lower():
            solution2 = await self.counting_reasoning()
        else:
            solution2 = await self.custom(instruction="Use counting logic to solve this problem by identifying relevant items in the passage.")

        # Path 3: Use arithmetic reasoning if there’s math involved
        if any(keyword in self.problem.lower() for keyword in ["sum", "difference", "total", "more than", "less than"]):
            solution3 = await self.arithmetic_reasoning()
        else:
            solution3 = await self.custom(instruction="Apply arithmetic reasoning by forming an equation from the passage and solving it step-by-step.")

        # Now collect all three solutions into a list for ensemble voting
        solutions = [solution1.strip(), solution2.strip(), solution3.strip()]

        # Final step: Use ScEnsemble to select the most consistent answer across multiple strategies
        final_answer = await self.sc_ensemble(solutions=solutions)

        return final_answer