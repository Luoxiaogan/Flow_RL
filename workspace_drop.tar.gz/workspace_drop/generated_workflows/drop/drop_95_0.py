# Workflow ID: drop_95_0
# Benchmark: drop
# Data Indices: [221, 100]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify required reasoning type
        initial_thought = await self.custom(instruction="First, analyze the question to determine whether it requires counting, arithmetic, comparison, or a combination of these. Identify key entities and relationships in the passage relevant to the question.")

        # Step 2: Use FlexibleCustom with a sequential reasoning pattern to break down the task
        reasoning_steps = [
            "Identify all instances of the target event (e.g., rebellions, touchdowns, etc.) mentioned in the passage.",
            "Extract numerical values (like years, counts, distances) associated with those events.",
            "Determine the type of final computation needed — e.g., summing years, counting occurrences, comparing values."
        ]
        
        structured_analysis = await self.flexible_custom(
            steps=reasoning_steps,
            reasoning_pattern="sequential",
            custom_instruction="Based on the initial thought, perform a step-by-step breakdown of the passage to locate and extract relevant information."
        )

        # Step 3: If the task involves counting, use CountingReasoning
        if "count" in initial_thought.lower() or "how many" in initial_thought.lower():
            count_result = await self.counting_reasoning()
            return count_result['count']

        # Step 4: If the task involves arithmetic operations (sums, differences), use ArithmeticReasoning
        elif "total" in initial_thought.lower() or "sum" in initial_thought.lower() or "difference" in initial_thought.lower():
            arithmetic_result = await self.arithmetic_reasoning()
            return arithmetic_result['result']

        # Step 5: If the task involves comparisons or sorting, use ComparisonReasoning
        elif "compare" in initial_thought.lower() or "which is more" in initial_thought.lower() or "highest" in initial_thought.lower():
            comparison_result = await self.comparison_reasoning()
            return comparison_result['result']

        # Step 6: For complex problems requiring multi-step logic not covered by specialized operators, fall back to Custom
        else:
            final_answer = await self.custom(instruction=f"Based on the structured analysis: {structured_analysis}, now solve the problem directly using discrete reasoning over the extracted facts.")
            return final_answer