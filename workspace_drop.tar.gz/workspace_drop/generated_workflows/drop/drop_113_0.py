# Workflow ID: drop_113_0
# Benchmark: drop
# Data Indices: [284, 80]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify required reasoning type
        initial_thought = await self.custom(instruction="Read the passage carefully and determine what kind of reasoning is needed to answer the question: counting, arithmetic, comparison, or extraction.")
        
        # Step 2: If the task involves counting (e.g., how many touchdowns, goals, etc.)
        if "count" in initial_thought.lower() or "how many" in initial_thought.lower():
            count_result = await self.counting_reasoning()
            final_answer = count_result.strip()
            
        # Step 3: If the task involves arithmetic (sums, differences, averages)
        elif "add" in initial_thought.lower() or "subtract" in initial_thought.lower() or "total" in initial_thought.lower() or "difference" in initial_thought.lower():
            arith_result = await self.arithmetic_reasoning()
            final_answer = arith_result.strip()
            
        # Step 4: If the task involves comparing or sorting items
        elif "which" in initial_thought.lower() or "more than" in initial_thought.lower() or "less than" in initial_thought.lower() or "highest" in initial_thought.lower() or "lowest" in initial_thought.lower():
            compare_result = await self.comparison_reasoning()
            final_answer = compare_result.strip()
            
        # Step 5: General extraction or complex multi-step reasoning
        else:
            general_thinking = await self.custom(instruction="Break down the problem step-by-step. First, extract relevant facts from the passage. Then, apply appropriate reasoning (counting, arithmetic, or comparison). Finally, formulate the answer.")
            final_answer = await self.custom(instruction=f"Based on the following thought process: {general_thinking}, now provide the final answer directly.")

        # Optional: Improve robustness using ensemble or review
        if self.config.get("use_ensemble", False):
            solution = await self.sc_ensemble([final_answer])
            return solution
        elif self.config.get("use_review", False):
            reviewed = await self.review(final_answer)
            return reviewed
        else:
            return final_answer