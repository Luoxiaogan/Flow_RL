# Workflow ID: drop_113_1
# Benchmark: drop
# Data Indices: [284, 80]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to define a multi-step reasoning pattern
        # This avoids branching logic and instead uses structured, guided steps
        reasoning_pattern = {
            "step_1": "Identify the key question and determine whether it requires counting, arithmetic, comparison, or text extraction.",
            "step_2": "If counting is needed, invoke CountingReasoning. If arithmetic, invoke ArithmeticReasoning. If comparison, invoke ComparisonReasoning. Otherwise, proceed with general reasoning.",
            "step_3": "After getting the result from the specialized expert, validate the logic by reviewing it using the Review operator.",
            "step_4": "Finally, use ScEnsemble to evaluate this solution against potential alternatives (even if just one), ensuring robustness through consistency."
        }

        solution = await self.flexible_custom(
            reasoning_pattern=reasoning_pattern,
            steps=[
                "Read the passage and identify the exact question being asked.",
                "Determine which type of reasoning is required based on keywords like 'how many', 'total', 'which', etc.",
                "Execute the appropriate reasoning step using the relevant operator.",
                "Review the output for logical coherence and correctness.",
                "Ensure final answer is consistent and precise."
            ],
            custom_instruction="Begin solving the problem using a structured, multi-step approach."
        )

        # Optional: Apply ensemble only if enabled — but now done as part of the flexible_custom flow
        if self.config.get("use_ensemble", False):
            return await self.sc_ensemble([solution])
        elif self.config.get("use_review", False):
            return await self.review(solution)
        else:
            return solution