# Workflow ID: drop_92_0
# Benchmark: drop
# Data Indices: [123, 199]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question type — is it counting, arithmetic, or comparison?
        initial_thought = await self.custom(instruction="Analyze the question to determine whether it requires counting, arithmetic, or comparison reasoning.")

        # Step 2: Based on the question type, apply the appropriate specialized operator
        if "how many total yards" in initial_thought.lower() or "total yards" in initial_thought.lower():
            result = await self.arithmetic_reasoning()
        elif "count" in initial_thought.lower() or "how many" in initial_thought.lower():
            result = await self.counting_reasoning()
        elif "which" in initial_thought.lower() and ("best" in initial_thought.lower() or "greater" in initial_thought.lower()):
            result = await self.comparison_reasoning()
        else:
            # Fallback: use flexible custom to guide step-by-step thinking
            result = await self.flexible_custom(
                reasoning_pattern="step_by_step",
                steps=[
                    "Identify what needs to be extracted from the passage.",
                    "Determine the type of reasoning required (counting, arithmetic, comparison).",
                    "Apply the correct specialized operator based on the reasoning type."
                ],
                custom_instruction="Now solve the problem using the structured plan above."
            )

        # Step 3: Review the solution for correctness and clarity
        final_solution = await self.review(pre_solution=result)

        # Step 4: Use ensemble voting to improve robustness (if multiple solutions exist)
        # For now, we only have one solution, so return directly
        return final_solution