# Workflow ID: drop_86_0
# Benchmark: drop
# Data Indices: [18, 53]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question type — extract key task from the question
        initial_thought = await self.custom(instruction="Identify whether the question requires counting, arithmetic, comparison, or text span extraction.")
        
        # Step 2: Based on the question type, choose appropriate reasoning operator
        if "how many" in self.problem.lower() or "count" in self.problem.lower():
            count_result = await self.counting_reasoning()
            final_answer = count_result.strip()
        elif "sum" in self.problem.lower() or "difference" in self.problem.lower() or "total" in self.problem.lower():
            arith_result = await self.arithmetic_reasoning()
            final_answer = arith_result.strip()
        elif "which" in self.problem.lower() or "compare" in self.problem.lower() or "order" in self.problem.lower():
            comp_result = await self.comparison_reasoning()
            final_answer = comp_result.strip()
        else:
            # For questions requiring text span answers (e.g., names, dates), use flexible custom
            final_answer = await self.flexible_custom(
                reasoning_pattern="Extract the relevant answer directly from the passage based on the question.",
                steps=[
                    "Read the question carefully to determine what needs to be extracted.",
                    "Scan the passage for the specific information that matches the query.",
                    "Return only the exact phrase or value that answers the question."
                ],
                custom_instruction="Extract the answer directly from the passage using step-by-step reasoning."
            )

        # Step 3: Review and refine solution for correctness
        reviewed_solution = await self.review(pre_solution=final_answer)

        # Step 4: Use ensemble voting if multiple solutions were generated (optional enhancement)
        # In this case, we generate a single solution so sc_ensemble is not needed unless more than one path exists
        # But to ensure robustness, we can simulate a simple vote by returning the reviewed result directly
        return reviewed_solution