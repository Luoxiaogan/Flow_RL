# Workflow ID: drop_45_1
# Benchmark: drop
# Data Indices: [260, 57]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to run multiple reasoning strategies in parallel
        solutions = await self.flexible_custom(
            reasoning_pattern="parallel",
            steps=[
                {"name": "counting", "instruction": "Identify all numerical or countable elements in the passage relevant to the question."},
                {"name": "arithmetic", "instruction": "Extract numbers and operations needed for arithmetic reasoning based on the question."},
                {"name": "comparison", "instruction": "Compare key entities or timepoints mentioned in the passage as per the question."}
            ],
            custom_instruction="Generate distinct answers using each strategy. Return them as a list."
        )

        # Step 2: Use ScEnsemble to select the most consistent answer across strategies
        final_answer = await self.sc_ensemble(solutions=solutions)

        # Step 3: Review the ensemble result for clarity and correctness
        reviewed_final = await self.review(pre_solution=final_answer)

        return reviewed_final