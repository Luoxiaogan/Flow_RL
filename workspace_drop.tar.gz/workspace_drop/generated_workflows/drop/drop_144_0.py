# Workflow ID: drop_144_0
# Benchmark: drop
# Data Indices: [212, 29]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify required reasoning type
        initial_thought = await self.custom(instruction="Analyze the question to determine if it requires counting, arithmetic, or comparison reasoning.")
        
        # Step 2: Extract relevant information based on the reasoning type
        if "count" in initial_thought.lower() or "how many" in initial_thought.lower():
            extraction = await self.custom(instruction="Extract all relevant items mentioned in the passage that need to be counted.")
            count_result = await self.counting_reasoning()
            final_answer = count_result['count']
            
        elif "more" in initial_thought.lower() or "difference" in initial_thought.lower() or "how much more" in initial_thought.lower():
            extraction = await self.custom(instruction="Identify the two numerical values involved in the comparison from the passage.")
            arithmetic_result = await self.arithmetic_reasoning()
            final_answer = arithmetic_result['result']
            
        elif "which team" in initial_thought.lower() or "who scored" in initial_thought.lower():
            extraction = await self.custom(instruction="Find all teams or individuals who scored in the specified context (e.g., first quarter).")
            comparison_result = await self.comparison_reasoning()
            final_answer = comparison_result['result']
            
        else:
            # Generic fallback: Use custom to think step-by-step
            final_answer = await self.custom(instruction="Think step-by-step and solve the problem based on the extracted information.")

        # Optional: Improve robustness via ensemble or review
        if self.config.get("use_ensemble", False):
            solution = [final_answer]
            final_answer = await self.sc_ensemble(solutions=solution)
        elif self.config.get("use_review", False):
            final_answer = await self.review(pre_solution=final_answer)

        return final_answer