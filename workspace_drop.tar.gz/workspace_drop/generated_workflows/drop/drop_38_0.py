# Workflow ID: drop_38_0
# Benchmark: drop
# Data Indices: [20, 248]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify required operations
        initial_thought = await self.custom(instruction="First, determine what type of reasoning is needed: counting, arithmetic, or comparison. Identify the relevant numbers or spans in the passage.")

        # Step 2: Generate multiple solutions using different strategies
        solution_a = await self.custom(instruction="Use direct extraction from the passage to find items that meet the condition (e.g., count how many have less than 100).")
        solution_b = await self.arithmetic_reasoning()
        solution_c = await self.counting_reasoning()

        # Step 3: Use sc_ensemble to select the most consistent answer across all approaches
        final_answer = await self.sc_ensemble(solutions=[solution_a, solution_b, solution_c])

        return final_answer