# Workflow ID: drop_193_1
# Benchmark: drop
# Data Indices: [213, 236]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to define a multi-step reasoning pattern
        # This avoids serial execution of generic Custom calls and instead uses structured logic
        reasoning_pattern = "Extract relevant events → Identify numerical values → Compute difference"
        steps = [
            {"name": "extract_events", "instruction": "Identify all instances of the key event mentioned in the question (e.g., touchdown passes or field goals)."},
            {"name": "isolate_values", "instruction": "From each identified event, extract the numeric value (e.g., yardage of a pass)."},
            {"name": "compute_difference", "instruction": "Calculate the absolute difference between the two specified values."}
        ]
        
        raw_answer = await self.flexible_custom(
            reasoning_pattern=reasoning_pattern,
            steps=steps,
            custom_instruction="Solve the DROP benchmark-style question using structured multi-step extraction and arithmetic."
        )

        # Step 2: Validate with ComparisonReasoning — this ensures the answer makes sense relative to context
        comparison_result = await self.comparison_reasoning()
        
        # Step 3: Use Review to refine based on both raw answer and comparison logic
        refined_answer = await self.review(pre_solution=f"Raw solution: {raw_answer}. Comparison insight: {comparison_result}")

        # Step 4: Final ensemble with only two solutions — original + review result — to boost confidence
        final_answer = await self.sc_ensemble(solutions=[raw_answer, refined_answer])

        return final_answer