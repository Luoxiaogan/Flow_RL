# Workflow ID: drop_167_1
# Benchmark: drop
# Data Indices: [130, 51]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use flexible_custom to define a structured multi-step reasoning pattern
        # This allows us to control the logic flow without writing explicit Python loops or conditionals
        reasoning_steps = [
            "First, extract relevant facts from the passage that relate to the question.",
            "Second, determine whether the required reasoning is counting, arithmetic, or comparison.",
            "Third, apply the appropriate specialized operator based on the reasoning type.",
            "Fourth, synthesize the final answer using step-by-step logic."
        ]
        
        # Use FlexibleCustom to execute the entire workflow in one coherent reasoning chain
        solution = await self.flexible_custom(
            steps=reasoning_steps,
            reasoning_pattern="sequential",
            custom_instruction="Now solve the problem following these steps."
        )

        # Step 2: Validate and refine the result using review
        reviewed_solution = await self.review(pre_solution=solution)

        # Step 3: Finalize by running ensemble only if there's ambiguity (e.g., if review flagged uncertainty)
        # This differs from existing logic which always uses ScEnsemble regardless
        if "uncertain" in reviewed_solution.lower() or "not sure" in reviewed_solution.lower():
            # Only then do we fall back to ensemble — this is a smarter, conditional use
            final_answer = await self.sc_ensemble(solutions=[solution, reviewed_solution])
        else:
            final_answer = reviewed_solution

        return final_answer