# Workflow ID: drop_114_0
# Benchmark: drop
# Data Indices: [331, 111]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and extract relevant information
        initial_thought = await self.custom(instruction="First, identify what needs to be calculated or counted based on the question. Extract all relevant dates, numbers, or events from the passage that relate to the question.")
        
        # Step 2: Use specialized reasoning based on the type of query
        if "how many months" in str(self.problem).lower():
            # For month-based arithmetic (e.g., time between two dates)
            result = await self.arithmetic_reasoning()
            return result

        elif "how many years" in str(self.problem).lower():
            # For year-based arithmetic (e.g., duration of independence)
            result = await self.arithmetic_reasoning()
            return result

        elif "count" in str(self.problem).lower() or "number of" in str(self.problem).lower():
            # For counting tasks (e.g., number of soldiers, attacks, etc.)
            result = await self.counting_reasoning()
            return result

        elif "which" in str(self.problem).lower() or "compare" in str(self.problem).lower():
            # For comparison or sorting tasks (e.g., who had more, which event came first)
            result = await self.comparison_reasoning()
            return result

        else:
            # Fallback: general step-by-step thinking
            final_answer = await self.custom(instruction=f"Based on the initial thought: {initial_thought}, now solve the problem by applying appropriate reasoning — arithmetic, counting, or comparison — as needed.")
            return final_answer