# Workflow ID: drop_114_1
# Benchmark: drop
# Data Indices: [331, 111]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Strategy: Generate multiple distinct solutions using different reasoning paths,
        # then select the most consistent one via ensemble — a fundamentally different approach
        # than the existing workflow's conditional routing.

        # Step 1: Use FlexibleCustom to define two divergent reasoning strategies in parallel
        solution1 = await self.flexible_custom(
            reasoning_pattern="Extract key dates/events and apply arithmetic reasoning",
            steps=[
                "Identify all relevant dates mentioned in the passage.",
                "Determine the start and end points based on the question.",
                "Compute the difference using arithmetic reasoning."
            ],
            custom_instruction="Apply arithmetic reasoning to compute the time interval between the two events."
        )

        solution2 = await self.flexible_custom(
            reasoning_pattern="First extract the timeline, then compare with known historical context",
            steps=[
                "List all chronological events in the passage.",
                "Identify which event corresponds to the 'start' and 'end' of the period asked about.",
                "Use comparison reasoning to verify the correct order and duration."
            ],
            custom_instruction="Compare events chronologically and determine how many months/years separate them."
        )

        solution3 = await self.flexible_custom(
            reasoning_pattern="Count relevant intervals or occurrences that imply the answer",
            steps=[
                "Look for phrases like 'after X days/months/years' or similar temporal markers.",
                "If no direct date exists, infer the elapsed time through narrative clues.",
                "Use counting reasoning to tally units (e.g., months passed)."
            ],
            custom_instruction="Count the number of months or years implied by the passage structure."
        )

        # Step 2: Apply review to each solution to improve quality before voting
        reviewed_solutions = [
            await self.review(solution1),
            await self.review(solution2),
            await self.review(solution3)
        ]

        # Step 3: Use ScEnsemble to pick the most consistent answer across all three strategies
        final_answer = await self.sc_ensemble(reviewed_solutions)
        
        return final_answer