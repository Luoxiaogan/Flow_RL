# Workflow ID: drop_191_1
# Benchmark: drop
# Data Indices: [379, 127]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use flexible custom to define a multi-step reasoning plan based on question type
        plan_instruction = "Based on the question, generate a step-by-step plan that includes identifying key entities, extracting numbers, and applying appropriate reasoning (counting/arithmetic/comparison)."
        reasoning_plan = await self.flexible_custom(
            steps=["Identify key entities", "Extract relevant numerical values", "Determine required reasoning type", "Apply expert operator"],
            reasoning_pattern="chain_of_thought",
            custom_instruction=plan_instruction
        )

        # Step 2: Execute the plan using specialized operators directly — no intermediate text extraction
        # Instead of relying on generic extraction, we guide the experts with precise instructions
        if "compare" in reasoning_plan.lower() or "smallest" in reasoning_plan.lower() or "largest" in reasoning_plan.lower():
            result = await self.comparison_reasoning()
        elif "how many" in reasoning_plan.lower() or "count" in reasoning_plan.lower():
            result = await self.counting_reasoning()
        else:
            result = await self.arithmetic_reasoning()

        # Step 3: Apply ensemble strategy — generate two alternative solutions via different prompts
        # This introduces parallel reasoning paths, which is fundamentally different from the original's single path
        alt_solution_1 = await self.custom(instruction="Use direct arithmetic reasoning to solve this problem.")
        alt_solution_2 = await self.custom(instruction="First, identify all numbers mentioned in the passage. Then compute the answer logically.")

        # Step 4: Use ScEnsemble to select the most consistent solution across both original and alternatives
        solutions = [result, alt_solution_1, alt_solution_2]
        final_answer = await self.sc_ensemble(solutions=solutions)

        # Step 5: Final review to refine clarity and correctness
        reviewed_answer = await self.review(pre_solution=final_answer)

        return reviewed_answer