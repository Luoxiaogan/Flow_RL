# Workflow ID: drop_158_1
# Benchmark: drop
# Data Indices: [190, 204]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use flexible_custom to generate multiple distinct reasoning paths in parallel
        # Each path uses a different strategy (e.g., one focuses on extraction first, another on direct comparison)
        reasoning_pattern = "parallel_paths"
        steps = [
            "Path A: Extract all numbers mentioned in the passage and identify which ones relate to the question.",
            "Path B: Identify key entities (like players, events, times) and determine how they map to numerical values.",
            "Path C: Apply arithmetic or counting reasoning based on the extracted data from Path A or B."
        ]
        multi_path_plan = await self.flexible_custom(
            reasoning_pattern=reasoning_pattern,
            steps=steps,
            custom_instruction="Generate three distinct reasoning strategies for solving this DROP-style problem."
        )

        # Step 2: Execute each path independently using different operators — this introduces parallel logic
        solution_a = await self.custom(instruction="Based on Path A: Extract all numbers and find the relevant one for the question.")
        solution_b = await self.custom(instruction="Based on Path B: Focus on identifying key entities and their numeric associations.")
        solution_c = await self.custom(instruction="Based on Path C: Now apply the correct reasoning type (counting/arithmetic/comparison).")

        # Step 3: Combine solutions via ensemble — now we select the most consistent answer across diverse approaches
        ensemble_result = await self.sc_ensemble(solutions=[solution_a, solution_b, solution_c])

        # Step 4: Final review to ensure clarity and correctness — only now do we refine
        final_answer = await self.review(pre_solution=ensemble_result)

        return final_answer