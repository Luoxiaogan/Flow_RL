# Workflow ID: drop_6_0
# Benchmark: drop
# Data Indices: [339, 99]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question type — determine if it's counting, arithmetic, or comparison
        initial_thought = await self.custom(instruction="Analyze the question to determine whether it requires counting, arithmetic, or comparison reasoning.")
        
        # Step 2: Use the appropriate specialized operator based on the question type
        if "how many" in initial_thought.lower() or "count" in initial_thought.lower():
            result = await self.counting_reasoning()
            return result["count"]
        elif "sum", "difference", "total", "more than", "less than" in initial_thought.lower():
            result = await self.arithmetic_reasoning()
            return result["result"]
        elif "who", "which", "order", "sort", "most", "least" in initial_thought.lower():
            result = await self.comparison_reasoning()
            return result["result"]
        else:
            # Fallback: Use flexible custom for complex or ambiguous cases
            final_result = await self.flexible_custom(
                reasoning_pattern="step_by_step",
                steps=[
                    "Identify key entities and quantities mentioned in the passage relevant to the question.",
                    "Extract all necessary information from the text using precise instructions.",
                    "Apply logical reasoning (counting/arithmetic/comparison) as needed."
                ],
                custom_instruction="Solve the problem by extracting relevant facts and applying appropriate reasoning."
            )
            return final_result