# Workflow ID: drop_138_1
# Benchmark: drop
# Data Indices: [247, 387]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Strategy: Use parallel reasoning paths with different operators to generate multiple solutions,
        # then apply ensemble voting to select the most consistent one — this is fundamentally different
        # from the existing workflow which uses a single path based on keyword detection.

        # Step 1: Generate three distinct solutions using different strategies
        solution1 = await self.custom(instruction="Extract relevant numerical data from the passage and compute the answer directly.")
        solution2 = await self.arithmetic_reasoning()
        solution3 = await self.comparison_reasoning()

        # Step 2: Apply review to each solution independently to improve clarity and correctness
        reviewed1 = await self.review(pre_solution=solution1)
        reviewed2 = await self.review(pre_solution=solution2)
        reviewed3 = await self.review(pre_solution=solution3)

        # Step 3: Use ScEnsemble to pick the most consistent answer across all three
        final_answer = await self.sc_ensemble(solutions=[reviewed1, reviewed2, reviewed3])

        return final_answer