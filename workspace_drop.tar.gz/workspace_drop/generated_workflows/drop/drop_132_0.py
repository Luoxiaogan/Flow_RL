# Workflow ID: drop_132_0
# Benchmark: drop
# Data Indices: [365, 188]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the task and identify key information to extract
        initial_thought = await self.custom(instruction="Read the passage carefully and determine what type of reasoning is needed — counting, arithmetic, comparison, or span extraction.")
        
        # Step 2: Extract relevant data based on the question type
        if "how many" in self.problem.lower() or "count" in self.problem.lower():
            count_result = await self.counting_reasoning()
            final_answer = count_result["count"]
        elif "longest" in self.problem.lower() or "shortest" in self.problem.lower() or "difference" in self.problem.lower():
            comparison_result = await self.comparison_reasoning()
            final_answer = comparison_result["result"]
        elif "sum", "total", "average", "more than", "less than" in self.problem.lower():
            arithmetic_result = await self.arithmetic_reasoning()
            final_answer = arithmetic_result["result"]
        else:
            # Fallback: Use general custom reasoning for span-based answers
            final_answer = await self.custom(instruction="Extract the exact answer from the passage using step-by-step reasoning.")

        # Step 3: Review the solution for correctness and clarity
        reviewed_solution = await self.review(pre_solution=final_answer)

        # Step 4: If multiple solutions exist (e.g., from ensemble), pick the most consistent one
        # For now, assume we have only one solution; this can be expanded later with ScEnsemble
        return reviewed_solution