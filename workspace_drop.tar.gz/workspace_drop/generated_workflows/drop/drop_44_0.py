# Workflow ID: drop_44_0
# Benchmark: drop
# Data Indices: [275, 320]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question type — determine whether it's counting, arithmetic, or comparison
        initial_thought = await self.custom(instruction="Analyze the question to determine if it requires counting, arithmetic, or comparison reasoning.")

        # Step 2: Based on the nature of the question, route to the appropriate specialized operator
        if "count" in initial_thought.lower() or "how many" in initial_thought.lower():
            result = await self.counting_reasoning()
            return result["count"]
        
        elif "sum" in initial_thought.lower() or "total" in initial_thought.lower() or "difference" in initial_thought.lower():
            result = await self.arithmetic_reasoning()
            return result["result"]
        
        elif "which was most/least" in initial_thought.lower() or "order" in initial_thought.lower() or "compare" in initial_thought.lower():
            result = await self.comparison_reasoning()
            return result["result"]
        
        else:
            # Fallback: Use flexible custom to guide multi-step reasoning
            final_answer = await self.flexible_custom(
                reasoning_pattern="multi_step",
                steps=[
                    "Identify key entities and numerical data in the passage.",
                    "Determine what operation (count, sum, compare) is needed based on the question.",
                    "Execute the correct reasoning step using the appropriate operator."
                ],
                custom_instruction="Solve the problem by first identifying the required reasoning type and then applying the correct operator."
            )
            return final_answer