# Workflow ID: drop_137_1
# Benchmark: drop
# Data Indices: [310, 399]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Strategy: Use FlexibleCustom to define a multi-step reasoning plan that
        # explicitly tries multiple reasoning paths in parallel (via steps),
        # then uses ScEnsemble to pick the most consistent answer — no conditionals!
        
        reasoning_plan = {
            "reasoning_pattern": "parallel",
            "steps": [
                {
                    "instruction": "Identify whether this is a counting task. If yes, extract all relevant mentions and count them.",
                    "operator": "counting_reasoning"
                },
                {
                    "instruction": "If it's an arithmetic question, parse the numbers and compute the required operation (sum, difference, etc.).",
                    "operator": "arithmetic_reasoning"
                },
                {
                    "instruction": "For comparison questions, determine which item or value is greater/lesser based on passage context.",
                    "operator": "comparison_reasoning"
                }
            ]
        }

        # Execute all three reasoning paths simultaneously using FlexibleCustom
        parallel_solutions = await self.flexible_custom(
            reasoning_pattern=reasoning_plan["reasoning_pattern"],
            steps=reasoning_plan["steps"],
            custom_instruction="Solve the problem using all possible reasoning types in parallel."
        )

        # Now we have 3 potential solutions — one per step — so pass them to ensemble
        final_answer = await self.sc_ensemble(solutions=parallel_solutions)

        return final_answer