# Workflow ID: drop_180_1
# Benchmark: drop
# Data Indices: [369, 85]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to generate multiple candidate solutions in parallel via structured reasoning
        multi_solution_plan = await self.flexible_custom(
            reasoning_pattern="parallel",
            steps=[
                "Generate one solution using counting reasoning.",
                "Generate a second solution using arithmetic reasoning.",
                "Generate a third solution using comparison reasoning.",
                "Summarize each approach briefly and compare them."
            ],
            custom_instruction="Create three distinct solutions using different reasoning types (counting, arithmetic, comparison)."
        )

        # Step 2: Extract individual solutions from the multi-solution plan
        # Assume the output format includes clear separation of each solution (e.g., labeled by type)
        raw_solutions = multi_solution_plan.split("###")
        solutions = [sol.strip() for sol in raw_solutions if sol.strip()]

        # Step 3: Apply ScEnsemble to select the most consistent answer across all strategies
        final_answer = await self.sc_ensemble(solutions=solutions)

        # Step 4: If ensemble fails to resolve or returns ambiguous result, apply Review as final refinement
        if "ambiguous" in final_answer.lower() or "uncertain" in final_answer.lower():
            final_answer = await self.review(pre_solution=final_answer)

        return final_answer