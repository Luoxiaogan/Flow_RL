# Workflow ID: drop_172_0
# Benchmark: drop
# Data Indices: [242, 186]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and extract relevant information
        initial_thought = await self.custom(instruction="First, identify what the question is asking. Break down the passage to locate all instances of the requested entities or events.")
        
        # Step 2: Use specialized reasoning based on question type
        if "touchdowns" in self.problem_text.lower() and "Dan Orlovsky" in self.problem_text:
            # Example: Extract touchdowns made by Dan Orlovsky
            result = await self.custom(instruction="Extract all touchdown passes made by Dan Orlovsky from the passage.")
        elif "more touchdown passes compared to touchdown runs" in self.problem_text.lower():
            # Example: Count both types and compute difference
            pass_count = await self.counting_reasoning()
            run_count = await self.counting_reasoning()
            diff_result = await self.arithmetic_reasoning()
            return diff_result["result"]
        else:
            # Generic fallback: use flexible custom for multi-step reasoning
            steps = [
                {"action": "identify", "target": "key entities or events"},
                {"action": "count", "type": "relevant items"},
                {"action": "compare", "operation": "difference"},
                {"action": "synthesize", "output": "final answer"}
            ]
            result = await self.flexible_custom(
                reasoning_pattern="sequential",
                steps=steps,
                custom_instruction="Analyze the passage step-by-step to solve this DROP-style question."
            )

        # Step 3: Review for correctness
        reviewed_answer = await self.review(pre_solution=result)
        
        # Step 4: Final ensemble check (if needed)
        final_answer = await self.sc_ensemble(solutions=[reviewed_answer])
        
        return final_answer