# Workflow ID: drop_108_0
# Benchmark: drop
# Data Indices: [259, 106]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Initial breakdown and identification of required reasoning type
        initial_thought = await self.custom(instruction="First, analyze the question to determine whether it requires counting, arithmetic, comparison, or span extraction.")
        
        # Step 2: Based on the question type, apply appropriate reasoning
        if "count" in initial_thought.lower() or "how many" in initial_thought.lower():
            count_result = await self.counting_reasoning()
            final_answer = count_result['count']
        elif "sum" in initial_thought.lower() or "total" in initial_thought.lower() or "difference" in initial_thought.lower():
            arithmetic_result = await self.arithmetic_reasoning()
            final_answer = arithmetic_result['result']
        elif "more than" in initial_thought.lower() or "less than" in initial_thought.lower() or "compare" in initial_thought.lower():
            comparison_result = await self.comparison_reasoning()
            final_answer = comparison_result['result']
        else:
            # Default fallback: extract answer using custom instruction based on question
            final_answer = await self.custom(instruction=f"Extract the exact answer to this question: {self.problem}. Use only the information in the passage.")

        # Step 3: Review the solution for correctness and clarity
        reviewed_answer = await self.review(pre_solution=final_answer)

        # Step 4: Final ensemble check to improve robustness (if multiple solutions were generated earlier)
        # Since we only have one solution here, sc_ensemble is used as a safeguard against rare errors
        final_output = await self.sc_ensemble(solutions=[reviewed_answer])

        return final_output