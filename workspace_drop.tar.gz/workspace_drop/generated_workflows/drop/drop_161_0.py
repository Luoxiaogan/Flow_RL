# Workflow ID: drop_161_0
# Benchmark: drop
# Data Indices: [49, 43]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question type and extract key entities
        initial_thought = await self.custom(instruction="Identify what kind of reasoning is required (counting, arithmetic, comparison, or span extraction) and locate relevant information in the passage.")

        # Step 2: Use FlexibleCustom to apply a strategic template based on the question type
        reasoning_pattern = "sequential"  # Default strategy for structured reasoning
        steps = [
            {"task": "extract_relevant_info", "instruction": "Extract all sentences or phrases that directly relate to the question."},
            {"task": "determine_reasoning_type", "instruction": "Based on the extracted info, determine whether this is a counting, arithmetic, comparison, or span-based question."},
            {"task": "apply_specialized_operator", "instruction": "Use the appropriate specialized operator (Counting, Arithmetic, Comparison, or Custom) to solve the problem."}
        ]
        
        solution = await self.flexible_custom(
            reasoning_pattern=reasoning_pattern,
            steps=steps,
            custom_instruction="Execute the multi-step reasoning workflow to solve the DROP-style problem."
        )

        # Step 3: If needed, refine with review or ensemble for robustness
        final_answer = await self.review(pre_solution=solution)
        final_answer = await self.sc_ensemble(solutions=[final_answer])

        return final_answer