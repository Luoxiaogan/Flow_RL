# Workflow ID: drop_78_1
# Benchmark: drop
# Data Indices: [318, 377]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use Custom to guide a high-level plan based on question type
        initial_plan = await self.custom(instruction="Identify what needs to be computed: e.g., difference between two values, count, or comparison. Then extract relevant numbers from the passage.")

        # Step 2: Use ArithmeticReasoning directly — this is the key differentiator!
        # Instead of using FlexibleCustom with multiple steps, we rely on a single expert call
        # that leverages the LLM's ability to understand context and compute differences in one go
        arithmetic_result = await self.arithmetic_reasoning()

        # Step 3: Review the result for clarity and correctness (improves robustness without adding complexity)
        reviewed_result = await self.review(arithmetic_result)

        # Step 4: Use ScEnsemble not to combine multiple strategies, but to validate against a fallback
        # This introduces a different ensemble strategy: one main solution + one simple baseline (e.g., direct extraction via Custom)
        fallback_solution = await self.custom(instruction="Extract only the yardages of Peyton Hillis' touchdowns and compute the difference.")
        final_answer = await self.sc_ensemble([reviewed_result, fallback_solution])

        return final_answer