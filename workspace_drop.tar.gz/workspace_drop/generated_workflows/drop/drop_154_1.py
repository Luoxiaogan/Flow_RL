# Workflow ID: drop_154_1
# Benchmark: drop
# Data Indices: [380, 361]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use Custom to extract relevant information directly from the passage
        extraction = await self.custom(instruction="Extract all numerical facts and key entities related to the question. List them clearly.")

        # Step 2: Determine the type of reasoning needed (counting, arithmetic, comparison) via a custom instruction
        reasoning_type = await self.custom(instruction="Based on the extracted facts, determine whether the task requires counting, arithmetic, or comparison reasoning.")

        # Step 3: Apply the appropriate specialized reasoning operator based on the determined type
        if "count" in reasoning_type.lower():
            result = await self.counting_reasoning()
        elif "arithmetic" in reasoning_type.lower() or "sum" in reasoning_type.lower() or "difference" in reasoning_type.lower():
            result = await self.arithmetic_reasoning()
        elif "compare" in reasoning_type.lower() or "sort" in reasoning_type.lower():
            result = await self.comparison_reasoning()
        else:
            # Fallback: if we can't determine the type, ask for clarification
            result = await self.custom(instruction="The required reasoning type is unclear. Based on the extracted facts, suggest the correct reasoning type and solve accordingly.")

        # Step 4: Review the solution to improve clarity and correctness
        reviewed_result = await self.review(pre_solution=result)

        # Step 5: Generate an alternative solution using a different approach (e.g., re-extract + re-reason) for robustness
        alt_extraction = await self.custom(instruction="Re-read the passage and extract only what's necessary to answer the question — focus on precision.")
        alt_reasoning_type = await self.custom(instruction="Given the precise extraction, what kind of reasoning is required now?")
        
        if "count" in alt_reasoning_type.lower():
            alt_result = await self.counting_reasoning()
        elif "arithmetic" in alt_reasoning_type.lower():
            alt_result = await self.arithmetic_reasoning()
        elif "compare" in alt_reasoning_type.lower():
            alt_result = await self.comparison_reasoning()
        else:
            alt_result = await self.custom(instruction="Use the best available method to solve this based on the precise extraction.")

        # Step 6: Ensemble both solutions — this ensures robustness by combining two distinct strategies
        final_answer = await self.sc_ensemble(solutions=[reviewed_result, alt_result])

        return final_answer