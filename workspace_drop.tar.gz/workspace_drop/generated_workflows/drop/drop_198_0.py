# Workflow ID: drop_198_0
# Benchmark: drop
# Data Indices: [192, 26]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify required operations (e.g., extraction + arithmetic/comparison/counting)
        initial_thought = await self.custom(instruction="First, analyze the question to determine what needs to be extracted and reasoned about. Identify whether it requires counting, arithmetic, or comparison.")

        # Step 2: Use FlexibleCustom with a sequential reasoning pattern to break down the task into steps
        reasoning_steps = [
            "Extract relevant percentages or values from the passage related to family households.",
            "Identify which categories of family households are mentioned (husband-wife, female householder, etc.).",
            "Calculate the percentage of family households that are neither husband-wife nor female householder by subtracting those two from total family households."
        ]
        
        final_result = await self.flexible_custom(
            reasoning_pattern="sequential",
            steps=reasoning_steps,
            custom_instruction="Now execute the steps above to solve the problem."
        )

        # Step 3: If needed, refine the solution using review
        refined_result = await self.review(pre_solution=final_result)

        # Step 4: Final ensemble check if multiple solutions were generated (though here we only have one)
        # In this case, since we're generating one strong chain, we return directly
        return refined_result