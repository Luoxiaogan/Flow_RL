# Workflow ID: drop_88_1
# Benchmark: drop
# Data Indices: [383, 397]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to define a multi-step reasoning plan
        # This step avoids the need for branching logic and instead pre-defines a strategy
        reasoning_plan = await self.flexible_custom(
            steps=[
                "Identify the key entities or quantities relevant to the question.",
                "Determine whether the task involves counting, arithmetic, or comparison.",
                "Execute the appropriate specialized reasoning step based on that type."
            ],
            reasoning_pattern="chain_of_thought",
            custom_instruction="Based on the passage and question, execute the following steps: 1. Extract relevant info; 2. Classify reasoning type; 3. Apply correct operator."
        )

        # Step 2: Use Custom to extract structured information first — this is a different starting point
        # Instead of guessing the reasoning type upfront, we explicitly extract candidates first
        extracted_candidates = await self.custom(instruction="List all potential answers or values related to the question. For example, list all players who kicked field goals, or all places attacked by rebels.")

        # Step 3: Now determine which operator to use based on the structure of the extracted candidates
        # This introduces a new control flow: analyze output format rather than using string keywords
        analysis = await self.custom(instruction=f"Analyze these candidates: {extracted_candidates}. Determine if the answer requires counting, comparing, or computing a sum/difference.")
        
        if "count" in analysis.lower():
            result = await self.counting_reasoning()
        elif "compare" in analysis.lower() or "longest" in analysis.lower():
            result = await self.comparison_reasoning()
        elif "arithmetic" in analysis.lower() or "sum" in analysis.lower() or "difference" in analysis.lower():
            result = await self.arithmetic_reasoning()
        else:
            # If classification fails, fall back to a general reasoning approach with review
            result = await self.custom(instruction="Use detailed step-by-step reasoning to solve the problem directly from the passage and question.")
            result = await self.review(pre_solution=result)

        # Step 4: Final refinement via ensemble — but only after ensuring one strong solution exists
        final_answer = await self.sc_ensemble(solutions=[result])
        
        return final_answer