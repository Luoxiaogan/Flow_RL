# Workflow ID: drop_61_1
# Benchmark: drop
# Data Indices: [151, 129]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use a high-level custom instruction to extract key facts and identify reasoning type
        initial_analysis = await self.custom(instruction="Identify what needs to be counted, compared, or calculated. Extract all relevant numerical events or entities from the passage that relate directly to the question.")
        
        # Step 2: Generate two distinct solutions using different specialized operators — parallel approach!
        solution_by_counting = await self.counting_reasoning()
        solution_by_comparison = await self.comparison_reasoning()

        # Step 3: Review both solutions independently to improve quality before ensemble
        reviewed_counting = await self.review(pre_solution=solution_by_counting)
        reviewed_comparison = await self.review(pre_solution=solution_by_comparison)

        # Step 4: Use ScEnsemble to select the most consistent answer across multiple reasoning paths
        final_answer = await self.sc_ensemble(solutions=[reviewed_counting, reviewed_comparison])

        return final_answer