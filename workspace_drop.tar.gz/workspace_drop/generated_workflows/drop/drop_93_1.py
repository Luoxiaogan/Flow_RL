# Workflow ID: drop_93_1
# Benchmark: drop
# Data Indices: [200, 222]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Strategy: Use FlexibleCustom with a parallel reasoning pattern to explore multiple paths simultaneously
        # Then apply review and ensemble only after gathering diverse perspectives
        
        # Step 1: Use FlexibleCustom to run three distinct reasoning strategies in parallel
        # Each step focuses on a different type of reasoning (counting, arithmetic, comparison)
        solutions = await self.flexible_custom(
            steps=[
                {"name": "counting", "instruction": "Identify all numeric counts or item frequencies mentioned in the passage relevant to the question."},
                {"name": "arithmetic", "instruction": "Extract numerical values and operations needed to compute the answer based on the question."},
                {"name": "comparison", "instruction": "Compare relevant quantities or entities in the passage to determine the correct answer."}
            ],
            reasoning_pattern="parallel",
            custom_instruction="Generate a solution using each strategy independently. Do not combine them."
        )

        # Step 2: Refine each solution individually using Review — this enhances quality before final selection
        refined_solutions = []
        for sol in solutions.split("\n\n"):
            if sol.strip():
                refined = await self.review(pre_solution=sol.strip())
                refined_solutions.append(refined)

        # Step 3: Use ScEnsemble to select the most consistent answer across the refined solutions
        final_answer = await self.sc_ensemble(solutions=refined_solutions)

        return final_answer