# Workflow ID: drop_131_0
# Benchmark: drop
# Data Indices: [218, 274]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use flexible_custom to generate multiple reasoning paths
        # Strategy: First, extract key information using custom instruction
        initial_analysis = await self.custom(instruction="Identify what needs to be counted or calculated in this question. Break down the passage into relevant facts.")

        # Step 2: Generate two distinct solutions using different approaches
        solution_a = await self.custom(instruction="First approach: Extract all relevant numerical data or items mentioned in the passage that relate to the question. Then count them explicitly.")
        solution_b = await self.custom(instruction="Second approach: Use a structured counting strategy by identifying the specific category mentioned in the question (e.g., 'minerals', 'yards', etc.) and find all instances in the passage.")

        # Step 3: Run ensemble voting to select most consistent answer
        final_answer = await self.sc_ensemble(solutions=[solution_a, solution_b])

        return final_answer