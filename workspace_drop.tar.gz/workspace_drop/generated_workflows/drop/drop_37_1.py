# Workflow ID: drop_37_1
# Benchmark: drop
# Data Indices: [7, 392]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Generate multiple candidate solutions using different strategies in parallel
        # Strategy A: Use FlexibleCustom with structured extraction for span questions
        span_solution = await self.flexible_custom(
            reasoning_pattern="extract_answer",
            steps=[
                "Identify the key entity or event mentioned in the question.",
                "Locate the exact sentence or phrase in the passage that answers the question.",
                "Return only the full text span that directly answers the question."
            ],
            custom_instruction="Extract the precise answer span without paraphrasing or adding context."
        )

        # Strategy B: Use Custom to guide step-by-step thinking for arithmetic/counting
        general_thought = await self.custom(instruction="Break down the problem into logical steps. Identify what needs to be counted, calculated, or compared.")
        
        # Based on the thought, determine the type of task — but now do it via flexible logic instead of branching
        task_type = await self.custom(instruction=f"Based on this thought: '{general_thought}', classify the problem as counting, arithmetic, comparison, or span-based.")
        
        # Strategy C: Use specialized operators based on classification (but now we generate one solution per type and compare them)
        if "count" in task_type.lower() or "how many" in task_type.lower():
            count_result = await self.counting_reasoning()
            count_solution = str(count_result['count'])
        elif "sum" in task_type.lower() or "difference" in task_type.lower() or "total" in task_type.lower():
            arith_result = await self.arithmetic_reasoning()
            count_solution = str(arith_result['result'])
        elif "compare" in task_type.lower() or "who scored more" in task_type.lower() or "which is greater" in task_type.lower():
            comp_result = await self.comparison_reasoning()
            count_solution = str(comp_result['result'])
        else:
            count_solution = ""  # Will be ignored since we have a span solution

        # Step 2: Ensemble all solutions together — no review first, just vote
        all_solutions = [span_solution]
        if count_solution:
            all_solutions.append(count_solution)

        # If only one solution exists, return it directly
        if len(all_solutions) == 1:
            final_result = all_solutions[0]
        else:
            # Otherwise, use ScEnsemble to pick the most consistent answer
            final_result = await self.sc_ensemble(solutions=all_solutions)

        # Step 3: Final Review — ensure clarity and correctness at the end
        reviewed_final = await self.review(pre_solution=final_result)

        return reviewed_final