# Workflow ID: drop_89_1
# Benchmark: drop
# Data Indices: [268, 330]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom with a sequential reasoning pattern to extract and process all relevant numbers
        extraction_result = await self.flexible_custom(
            steps=[
                "First, identify all touchdown pass yardages mentioned in the passage.",
                "Second, collect these values into a list for further processing."
            ],
            reasoning_pattern="sequential",
            custom_instruction="Extract all touchdown pass yardages from the text. Ignore non-pass touchdowns or other events."
        )

        # Step 2: Use ComparisonReasoning to sort the extracted values and find the two shortest
        sorted_result = await self.comparison_reasoning()
        # Note: We pass the extracted list as context via the instruction; this is how we inject intermediate results
        comparison_response = await self.custom(instruction=f"Based on the extracted yardages: {extraction_result}, now sort them and identify the two smallest values.")
        
        # Step 3: Use ArithmeticReasoning to compute the sum of the two shortest
        arithmetic_result = await self.arithmetic_reasoning()
        # Inject the comparison result into the instruction to guide the equation construction
        final_equation = await self.custom(instruction=f"Using the two smallest yardages from: {comparison_response}, compute their sum using arithmetic reasoning.")

        # Step 4: Review the final solution to ensure correctness before returning
        final_answer = await self.review(pre_solution=final_equation)

        return final_answer