# Workflow ID: drop_106_0
# Benchmark: drop
# Data Indices: [305, 94]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question type — extract key temporal or numerical elements
        initial_thought = await self.custom(instruction="Identify what needs to be computed: e.g., time difference, count, or specific value from text.")

        # Step 2: Use FlexibleCustom with a sequential reasoning pattern to break down the task
        # This allows structured, step-by-step thinking without explicit Python control flow
        solution_plan = await self.flexible_custom(
            reasoning_pattern="sequential",
            steps=[
                "Extract relevant dates mentioned in the passage.",
                "Determine which dates are relevant to the question.",
                "Perform arithmetic reasoning (e.g., subtraction) to compute the difference between those dates.",
                "Return the final numerical result."
            ],
            custom_instruction="Based on the question, follow these steps to solve it logically and accurately."
        )

        # Step 3: If the task involves counting items, use CountingReasoning
        # If it's about comparing values or sorting, use ComparisonReasoning
        # Otherwise, proceed directly to ArithmeticReasoning for numeric computation
        if "count" in initial_thought.lower() or "how many" in initial_thought.lower():
            count_result = await self.counting_reasoning()
            return count_result['count']

        elif "compare" in initial_thought.lower() or "which is greater" in initial_thought.lower():
            comparison_result = await self.comparison_reasoning()
            return comparison_result['result']

        else:
            # Assume arithmetic task (like time difference)
            arithmetic_result = await self.arithmetic_reasoning()
            return arithmetic_result['result']