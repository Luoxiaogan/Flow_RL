# Workflow ID: drop_155_1
# Benchmark: drop
# Data Indices: [105, 92]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Strategy: Use parallel reasoning paths with FlexibleCustom to explore multiple approaches
        # Then select the best one via ScEnsemble — this differs from the original's sequential single-path logic
        
        # Step 1: Generate three different solution strategies in parallel using FlexibleCustom
        # Each strategy focuses on a different reasoning type (counting, arithmetic, comparison)
        counting_attempt = await self.flexible_custom(
            steps=[
                {"name": "extract_relevant_info", "instruction": "Identify all relevant numeric or item-based information needed for counting."},
                {"name": "perform_counting", "instruction": "Count the items or events that match the question's criteria."}
            ],
            reasoning_pattern="sequential",
            custom_instruction="Now return the final count as an integer."
        )

        arithmetic_attempt = await self.flexible_custom(
            steps=[
                {"name": "identify_numbers", "instruction": "Extract all numbers mentioned in the passage related to quantities, dates, or values."},
                {"name": "form_equation", "instruction": "Construct an equation based on the relationships between these numbers (e.g., sum, difference, ratio)."},
                {"name": "compute_result", "instruction": "Solve the equation and provide the numerical result."}
            ],
            reasoning_pattern="sequential",
            custom_instruction="Provide only the final number as the answer."
        )

        comparison_attempt = await self.flexible_custom(
            steps=[
                {"name": "list_candidates", "instruction": "Find all possible candidates (people, events, dates) that could be compared or sorted."},
                {"name": "apply_comparison", "instruction": "Compare them based on the question’s requirement (e.g., most, least, earliest, latest)."}
            ],
            reasoning_pattern="sequential",
            custom_instruction="Return the selected candidate or ordered list as the final answer."
        )

        # Step 2: Use ScEnsemble to choose the most consistent solution among the three
        ensemble_result = await self.sc_ensemble(solutions=[counting_attempt, arithmetic_attempt, comparison_attempt])

        # Step 3: Final review to refine clarity and correctness
        final_answer = await self.review(pre_solution=ensemble_result)

        return final_answer