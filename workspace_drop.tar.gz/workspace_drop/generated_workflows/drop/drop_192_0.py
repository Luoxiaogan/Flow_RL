# Workflow ID: drop_192_0
# Benchmark: drop
# Data Indices: [194, 120]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question type — extract key entities and reasoning needed
        initial_thought = await self.custom(instruction="Identify what needs to be extracted and reasoned about. Is it counting, arithmetic, comparison, or span extraction?")
        
        # Step 2: Use FlexibleCustom with a sequential reasoning pattern to structure multi-step logic
        reasoning_pattern = "sequential"
        steps = [
            {"name": "extract_entities", "instruction": "Extract all relevant numerical values, names, and events from the passage related to the question."},
            {"name": "determine_reasoning_type", "instruction": "Based on the extracted information, determine whether this requires counting, arithmetic, comparison, or text span matching."},
            {"name": "execute_reasoning", "instruction": "Use the appropriate specialized operator (counting, arithmetic, comparison) to compute the answer."},
            {"name": "verify_answer", "instruction": "Review the solution for logical consistency and correctness using step-by-step verification."}
        ]
        
        final_solution = await self.flexible_custom(
            reasoning_pattern=reasoning_pattern,
            steps=steps,
            custom_instruction="Solve the DROP-style problem by following these structured steps."
        )
        
        # Step 3: Optional ensemble refinement for robustness
        # If multiple solutions exist or confidence is low, apply voting mechanism
        refined_solution = await self.sc_ensemble(solutions=[final_solution])
        
        return refined_solution