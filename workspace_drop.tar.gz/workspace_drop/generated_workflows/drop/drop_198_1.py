# Workflow ID: drop_198_1
# Benchmark: drop
# Data Indices: [192, 26]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use ArithmeticReasoning to directly compute the answer based on extracted values
        arithmetic_result = await self.arithmetic_reasoning()

        # Step 2: Use ComparisonReasoning to verify which categories are relevant and ensure correct subtraction logic
        comparison_result = await self.comparison_reasoning()

        # Step 3: Generate a second solution using FlexibleCustom with a different reasoning pattern (e.g., "extract then calculate")
        flexible_result = await self.flexible_custom(
            reasoning_pattern="extract_then_calculate",
            steps=[
                "Identify all percentages related to family households.",
                "Determine which ones should be excluded (husband-wife and female householder).",
                "Subtract those from total family households to get the remaining percentage."
            ],
            custom_instruction="Now solve step-by-step using extraction-first logic."
        )

        # Step 4: Use ScEnsemble to combine both solutions — this ensures robustness via parallel reasoning paths
        final_solution = await self.sc_ensemble(solutions=[arithmetic_result, comparison_result, flexible_result])

        # Step 5: Review the ensemble result to improve clarity and correctness
        reviewed_solution = await self.review(pre_solution=final_solution)

        return reviewed_solution