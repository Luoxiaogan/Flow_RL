# Workflow ID: drop_84_0
# Benchmark: drop
# Data Indices: [148, 3]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Initial reasoning — understand what is being asked and identify relevant information
        initial_thought = await self.custom(instruction="First, read the passage carefully and determine what specific information is needed to answer the question. Identify key entities, dates, or quantities mentioned in the text.")
        
        # Step 2: Extract or reason based on type — use specialized operators for arithmetic, counting, comparison, or custom extraction
        if "how many" in self.problem.lower() or "count" in self.problem.lower():
            result = await self.counting_reasoning()
        elif "sum", "difference", "total", "more than", "less than" in self.problem.lower():
            result = await self.arithmetic_reasoning()
        elif "which", "what is the highest", "order", "compare" in self.problem.lower():
            result = await self.comparison_reasoning()
        else:
            result = await self.custom(instruction=f"Based on the initial thought: {initial_thought}, now extract the exact answer directly from the passage using clear reasoning. Do not guess or assume; only use explicit facts stated in the text.")

        # Step 3: Review for correctness — refine the solution by checking logic and clarity
        refined_solution = await self.review(pre_solution=result)

        # Step 4: Final ensemble check (optional but recommended for robustness) — run once more to ensure consistency
        final_answer = await self.sc_ensemble(solutions=[refined_solution])

        return final_answer