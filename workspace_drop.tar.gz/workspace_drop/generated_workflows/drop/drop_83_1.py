# Workflow ID: drop_83_1
# Benchmark: drop
# Data Indices: [56, 321]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to define a multi-step reasoning pattern that dynamically selects the right operator based on question type
        reasoning_pattern = "Identify task type (counting, arithmetic, comparison), then apply appropriate reasoning step."
        steps = [
            {"task": "extract_question_type", "instruction": "Determine whether the question asks about quantity, math operation, or ranking."},
            {"task": "select_operator", "instruction": "Based on the extracted type, choose the best reasoning operator: CountingReasoning, ArithmeticReasoning, or ComparisonReasoning."},
            {"task": "execute_reasoning", "instruction": "Apply the selected operator to solve the problem."}
        ]
        
        flexible_result = await self.flexible_custom(
            reasoning_pattern=reasoning_pattern,
            steps=steps,
            custom_instruction="Analyze the passage and question together to determine the required reasoning type."
        )

        # Step 2: Use Review to refine the result from FlexibleCustom — this ensures high-quality internal logic
        reviewed_result = await self.review(pre_solution=flexible_result)

        # Step 3: Use ScEnsemble not just with two solutions, but by generating an alternative path using Custom directly for cross-validation
        alternative_solution = await self.custom(instruction="Solve the problem using general step-by-step reasoning without specialized operators.")
        final_output = await self.sc_ensemble(solutions=[flexible_result, reviewed_result, alternative_solution])

        return final_output