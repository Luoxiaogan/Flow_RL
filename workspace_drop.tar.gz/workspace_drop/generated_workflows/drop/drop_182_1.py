# Workflow ID: drop_182_1
# Benchmark: drop
# Data Indices: [144, 223]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Strategy: Use parallel reasoning paths with different initial prompts
        # Then combine via ensemble — this ensures robustness through diverse approaches

        # Step 1: Generate multiple distinct solutions using different high-level strategies
        # Each path uses a unique instruction to guide the LLM toward a different reasoning style
        
        solution_a = await self.custom(instruction="Approach this as an information extraction task. Identify all relevant spans in the passage that directly answer the question.")
        solution_b = await self.custom(instruction="Think like a mathematician: break down the question into numerical components and identify what arithmetic operations might be needed.")
        solution_c = await self.custom(instruction="Treat this as a comparison task: find all items mentioned in the passage related to the question and determine which one satisfies the criteria.")

        # Step 2: Review each independently to improve clarity and correctness
        reviewed_a = await self.review(pre_solution=solution_a)
        reviewed_b = await self.review(pre_solution=solution_b)
        reviewed_c = await self.review(pre_solution=solution_c)

        # Step 3: Use ScEnsemble to select the most consistent answer across all three diverse strategies
        final_answer = await self.sc_ensemble(solutions=[reviewed_a, reviewed_b, reviewed_c])

        return final_answer