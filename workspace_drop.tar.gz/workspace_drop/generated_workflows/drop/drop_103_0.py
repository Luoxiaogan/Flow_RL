# Workflow ID: drop_103_0
# Benchmark: drop
# Data Indices: [209, 358]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question type by analyzing the query
        initial_thought = await self.custom(instruction="Analyze the question to determine whether it requires counting, arithmetic, or comparison reasoning.")
        
        # Step 2: Based on the question type, invoke the appropriate specialized operator
        if "how many" in initial_thought.lower() or "count" in initial_thought.lower():
            result = await self.counting_reasoning()
            return result["count"]
        
        elif "sum" in initial_thought.lower() or "total" in initial_thought.lower() or "difference" in initial_thought.lower():
            result = await self.arithmetic_reasoning()
            return result["result"]
        
        elif "shortest" in initial_thought.lower() or "longest" in initial_thought.lower() or "most" in initial_thought.lower() or "least" in initial_thought.lower():
            result = await self.comparison_reasoning()
            return result["result"]
        
        else:
            # Fallback: Use flexible custom for complex or ambiguous cases
            final_answer = await self.flexible_custom(
                steps=[
                    {"name": "understand_question", "instruction": "Identify the core task and required reasoning type."},
                    {"name": "choose_operator", "instruction": "Select the most suitable reasoning operator based on the task."},
                    {"name": "execute", "instruction": "Perform the selected reasoning step."}
                ],
                reasoning_pattern="chain_of_thought",
                custom_instruction="Solve the problem using a structured reasoning approach."
            )
            return final_answer