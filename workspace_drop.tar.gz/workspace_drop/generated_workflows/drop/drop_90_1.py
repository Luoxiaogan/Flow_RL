# Workflow ID: drop_90_1
# Benchmark: drop
# Data Indices: [227, 255]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom with a sequential reasoning pattern to guide step-by-step extraction and calculation
        reasoning_steps = [
            "Identify key numerical values in the passage relevant to the question.",
            "Determine the type of reasoning required (arithmetic, counting, or comparison).",
            "Perform the necessary computation using the identified values.",
            "Validate the result by checking consistency with the passage context."
        ]
        
        structured_analysis = await self.flexible_custom(
            reasoning_pattern="sequential",
            steps=reasoning_steps,
            custom_instruction="Break down the problem into clear logical steps based on the passage and question."
        )

        # Step 2: Extract the final answer directly from the structured analysis
        final_result = await self.custom(instruction=f"From this structured analysis: {structured_analysis}, extract the final answer as a number or span of text.")

        # Step 3: Use Review to refine the solution if needed
        refined_solution = await self.review(pre_solution=final_result)

        # Step 4: Return the refined solution — no ensemble needed since we used structured reasoning first
        return refined_solution