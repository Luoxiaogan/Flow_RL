# Workflow ID: drop_106_1
# Benchmark: drop
# Data Indices: [305, 94]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Generate a raw solution using Custom — this is our baseline attempt
        initial_answer = await self.custom(instruction="Solve the question directly based on the passage. Be concise and precise.")

        # Step 2: Use Review to critique and refine the initial answer — not just fix errors, but deepen reasoning
        refined_answer = await self.review(pre_solution=initial_answer)

        # Step 3: Run multiple independent solutions in parallel using FlexibleCustom with different strategies
        # Strategy 1: Extract numbers first, then compute
        strategy1 = await self.flexible_custom(
            reasoning_pattern="sequential",
            steps=[
                "Identify all numerical values or dates mentioned in the passage.",
                "Determine which ones are relevant to the question.",
                "Apply arithmetic logic to derive the final result."
            ],
            custom_instruction="Use structured reasoning to solve the problem by extracting and computing from numbers in the text."
        )

        # Strategy 2: Focus on temporal context (e.g., events in order) — good for time-based questions
        strategy2 = await self.flexible_custom(
            reasoning_pattern="sequential",
            steps=[
                "List key events from the passage in chronological order.",
                "Find the two events relevant to the question.",
                "Calculate the difference between their years or positions."
            ],
            custom_instruction="Analyze the timeline of events in the passage to determine the correct answer."
        )

        # Step 4: Ensemble these three solutions — initial, reviewed, and two strategies — to get the most robust answer
        all_solutions = [initial_answer, refined_answer, strategy1, strategy2]
        final_answer = await self.sc_ensemble(solutions=all_solutions)

        return final_answer