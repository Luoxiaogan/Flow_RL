# Workflow ID: drop_12_0
# Benchmark: drop
# Data Indices: [389, 343]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify what needs to be extracted
        initial_thought = await self.custom(instruction="First, analyze the question to determine whether it requires counting, arithmetic, comparison, or a combination. Identify key entities like field goals, players, scores, time periods, etc.")
        
        # Step 2: Extract relevant information based on the type of reasoning required
        if "how many more" in self.problem_text.lower() or "difference" in self.problem_text.lower():
            # This is an arithmetic/counting problem
            count_first_half = await self.counting_reasoning(instruction="Count all field goals in the first half of the game.")
            count_second_half = await self.counting_reasoning(instruction="Count all field goals in the second half of the game.")
            
            # Perform arithmetic to find the difference
            diff_result = await self.arithmetic_reasoning(instruction=f"Subtract the number of field goals in the second half ({count_second_half}) from those in the first half ({count_first_half}).")
            
            return diff_result["result"]
        
        elif "which kicker scored the longest field goal" in self.problem_text.lower():
            # This is a comparison problem
            comparison_result = await self.comparison_reasoning(instruction="Identify all field goals mentioned in the passage and compare their distances to find the longest one.")
            
            # Final step: extract the kicker's name from the result
            final_answer = await self.custom(instruction=f"Based on the comparison result: {comparison_result}, determine the kicker who made the longest field goal.")
            
            return final_answer.strip()
        
        else:
            # Generic fallback: use flexible custom for complex multi-step reasoning
            return await self.flexible_custom(
                reasoning_pattern="extract_and_reason",
                steps=[
                    {"name": "understand_question", "instruction": "Break down the question into its core components: what must be found, and how it relates to the passage."},
                    {"name": "extract_info", "instruction": "Identify all relevant numerical or textual data that answers the question."},
                    {"name": "reason", "instruction": "Apply appropriate reasoning (counting, arithmetic, comparison) based on the extracted data."},
                    {"name": "format_answer", "instruction": "Return only the final answer as a number, date, or span of text."}
                ],
                custom_instruction="Execute the full workflow using the above steps."
            )