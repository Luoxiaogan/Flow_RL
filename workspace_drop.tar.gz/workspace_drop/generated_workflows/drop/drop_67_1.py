# Workflow ID: drop_67_1
# Benchmark: drop
# Data Indices: [136, 232]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom with a parallel reasoning pattern to explore multiple strategies simultaneously
        parallel_solutions = await self.flexible_custom(
            reasoning_pattern="parallel",
            steps=[
                {"name": "arithmetic", "instruction": "Identify numerical values and perform arithmetic operations based on the question."},
                {"name": "counting", "instruction": "Extract all relevant quantities that may need counting (e.g., events, items)."},
                {"name": "comparison", "instruction": "Compare key elements in the passage to determine relationships like 'more than', 'less than', or 'equal to'."}
            ]
        )

        # Step 2: Extract individual solutions from the flexible custom output
        solution_parts = parallel_solutions.split("\n\n")  # Assume structured format from flexible_custom
        solutions = [part.strip() for part in solution_parts if part.strip()]

        # Step 3: Use Review to refine each solution individually before ensemble voting
        reviewed_solutions = []
        for sol in solutions:
            refined = await self.review(pre_solution=sol)
            reviewed_solutions.append(refined)

        # Step 4: Apply ScEnsemble to select the most consistent answer across all reviewed solutions
        final_answer = await self.sc_ensemble(solutions=reviewed_solutions)

        return final_answer