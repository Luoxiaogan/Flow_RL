# Workflow ID: drop_125_1
# Benchmark: drop
# Data Indices: [155, 121]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use flexible_custom to extract key information and infer task type
        initial_analysis = await self.flexible_custom(
            reasoning_pattern="infer_task_type",
            steps=[
                "Identify the question being asked.",
                "Determine whether it requires counting, arithmetic, comparison, or span extraction.",
                "Return a concise label: 'count', 'arithmetic', 'comparison', or 'span'"
            ],
            custom_instruction="Based on the passage and question, determine the required reasoning type. Do not solve yet."
        )

        # Step 2: Based on inferred task type, apply specialized expert directly
        if "count" in initial_analysis.lower():
            result = await self.counting_reasoning()
            answer = result["count"]
        elif "arithmetic" in initial_analysis.lower():
            result = await self.arithmetic_reasoning()
            answer = result["result"]
        elif "comparison" in initial_analysis.lower():
            result = await self.comparison_reasoning()
            answer = result["result"]
        else:
            # For span extraction (e.g., who won, what was retired), use flexible_custom with exact extraction
            answer = await self.flexible_custom(
                reasoning_pattern="extract_span",
                steps=[
                    "Locate the exact phrase or entity that answers the question.",
                    "Return only the text span without additional explanation."
                ],
                custom_instruction="Extract the exact answer as a string from the passage. No reasoning needed."
            )

        # Step 3: Skip review and ensemble — instead, generate two alternative solutions using different strategies
        # This introduces parallel exploration rather than serial refinement
        solution1 = answer
        solution2 = await self.flexible_custom(
            reasoning_pattern="rethink_and_rephrase",
            steps=[
                "Rephrase the question in your own words.",
                "Find the same answer using a different part of the passage.",
                "Return only the final answer."
            ],
            custom_instruction="Solve the question again by rephrasing and searching differently. Return just the answer."
        )

        # Step 4: Select best solution via voting—this is more efficient than full ensemble
        final_answer = await self.sc_ensemble(solutions=[solution1, solution2])

        return final_answer