# Workflow ID: drop_122_1
# Benchmark: drop
# Data Indices: [109, 368]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Strategy: Use parallel exploration with a single initial custom prompt to guide multiple reasoning paths
        # Then select the best result using ensemble — this differs from the existing workflow's sequential type detection
        
        # Step 1: Get a general understanding of the question and task
        base_instruction = await self.custom(instruction="What is the main goal of this question? Identify whether it involves counting, arithmetic, or comparison.")
        
        # Step 2: Run all three specialized experts in parallel (or as close as possible via one call each)
        # We do not conditionally choose based on keywords — instead, we gather all three responses first
        counting_result = await self.counting_reasoning()
        arithmetic_result = await self.arithmetic_reasoning()
        comparison_result = await self.comparison_reasoning()

        # Step 3: Combine all results into a list for ensemble voting
        solutions = [
            {"type": "counting", "answer": counting_result["count"]},
            {"type": "arithmetic", "answer": arithmetic_result["result"]},
            {"type": "comparison", "answer": comparison_result["result"]}
        ]

        # Step 4: Use ScEnsemble to pick the most consistent answer across the three approaches
        final_answer = await self.sc_ensemble(solutions=[str(sol) for sol in solutions])
        
        # Step 5: Optional review step — only if the ensemble result seems ambiguous
        if "multiple" in final_answer.lower() or "uncertain" in final_answer.lower():
            final_answer = await self.review(pre_solution=final_answer)
            
        return final_answer