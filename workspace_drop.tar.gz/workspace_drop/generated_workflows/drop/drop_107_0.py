# Workflow ID: drop_107_0
# Benchmark: drop
# Data Indices: [311, 395]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Initial reasoning - understand the question and identify required operations
        initial_thought = await self.custom(instruction="First, read the passage carefully and determine what type of reasoning is needed: counting, arithmetic, comparison, or span extraction.")

        # Step 2: Based on the nature of the question, apply the appropriate expert
        if "count" in initial_thought.lower() or "how many" in initial_thought.lower():
            count_result = await self.counting_reasoning()
            final_answer = count_result["count"]
        elif "sum" in initial_thought.lower() or "difference" in initial_thought.lower() or "total" in initial_thought.lower():
            arithmetic_result = await self.arithmetic_reasoning()
            final_answer = arithmetic_result["result"]
        elif "compare" in initial_thought.lower() or "which is more" in initial_thought.lower() or "order" in initial_thought.lower():
            comparison_result = await self.comparison_reasoning()
            final_answer = comparison_result["result"]
        else:
            # For span-based questions (e.g., "Who was Charles II's brother?")
            span_extraction = await self.custom(instruction="Extract the relevant entity or phrase directly from the text that answers the question.")
            final_answer = span_extraction

        # Step 3: Review to improve correctness
        reviewed_answer = await self.review(pre_solution=final_answer)

        # Step 4: Use ensemble if multiple solutions were generated (optional but robust)
        # Since we only have one answer so far, we simulate a simple check by re-running with same logic
        # In practice, this would be used when multiple strategies are tried
        ensemble_solutions = [final_answer, reviewed_answer]
        final_output = await self.sc_ensemble(solutions=ensemble_solutions)

        return final_output