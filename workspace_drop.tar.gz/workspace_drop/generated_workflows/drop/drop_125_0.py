# Workflow ID: drop_125_0
# Benchmark: drop
# Data Indices: [155, 121]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Initial breakdown and identification of task type
        initial_thought = await self.custom(instruction="First, read the passage carefully and determine what kind of reasoning is required: counting, arithmetic, comparison, or span extraction.")

        # Step 2: Based on the identified task type, apply appropriate expert
        if "count" in initial_thought.lower() or "how many" in initial_thought.lower():
            count_result = await self.counting_reasoning()
            final_answer = count_result["count"]
        elif "sum" in initial_thought.lower() or "difference" in initial_thought.lower() or "total" in initial_thought.lower():
            arith_result = await self.arithmetic_reasoning()
            final_answer = arith_result["result"]
        elif "compare" in initial_thought.lower() or "who scored more" in initial_thought.lower() or "order" in initial_thought.lower():
            comp_result = await self.comparison_reasoning()
            final_answer = comp_result["result"]
        else:
            # Default fallback: use flexible custom to extract answer directly
            final_answer = await self.flexible_custom(
                reasoning_pattern="extract_answer",
                steps=[
                    "Identify the key question being asked.",
                    "Locate the relevant information in the passage.",
                    "Extract the exact answer as a string."
                ],
                custom_instruction="Based on the passage, extract the exact answer to the question without additional interpretation."
            )

        # Step 3: Review for refinement
        reviewed_solution = await self.review(pre_solution=str(final_answer))

        # Step 4: Ensemble for robustness (if needed)
        ensemble_result = await self.sc_ensemble(solutions=[str(final_answer), reviewed_solution])

        return ensemble_result