# Workflow ID: drop_74_1
# Benchmark: drop
# Data Indices: [278, 17]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to define a multi-step reasoning pattern that first identifies task type
        task_identification = await self.flexible_custom(
            reasoning_pattern="sequential",
            steps=[
                "Identify whether the question requires counting, arithmetic, comparison, or text extraction.",
                "If it involves numbers and operations (e.g., sum, difference), proceed with arithmetic reasoning.",
                "If it asks 'how many', use dedicated counting reasoning.",
                "Otherwise, extract relevant spans and reason step-by-step using custom instructions."
            ],
            custom_instruction="Analyze the question and classify the required reasoning type."
        )

        # Step 2: Based on classification, generate targeted solutions in parallel
        # Parallel strategy: Run all three specialized operators at once
        solution_arithmetic = self.arithmetic_reasoning() if "sum" in task_identification.lower() or "total" in task_identification.lower() else self.custom(instruction="Perform arithmetic reasoning based on extracted values.")
        solution_counting = self.counting_reasoning() if "how many" in task_identification.lower() or "count" in task_identification.lower() else self.custom(instruction="Count the relevant items mentioned in the passage.")
        solution_custom = self.custom(instruction=f"Extract key facts from the passage relevant to this question: {task_identification}. Then solve accordingly.")

        # Step 3: Use ScEnsemble to resolve inconsistencies by selecting the most consistent answer across all approaches
        ensemble_result = await self.sc_ensemble(solutions=[solution_arithmetic, solution_counting, solution_custom])

        # Step 4: Final review to refine the ensemble result — ensures quality and correctness
        final_answer = await self.review(pre_solution=ensemble_result)

        return final_answer