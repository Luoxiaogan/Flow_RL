# Workflow ID: drop_23_1
# Benchmark: drop
# Data Indices: [355, 226]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom with a parallel reasoning pattern to explore multiple strategies simultaneously
        parallel_steps = [
            "First, extract all relevant facts from the passage that could relate to the question.",
            "Second, apply counting reasoning to identify numerical quantities or frequencies in the text.",
            "Third, apply comparison reasoning to determine orderings or relative values between entities.",
            "Fourth, apply arithmetic reasoning to compute sums, differences, or derived values."
        ]
        
        parallel_analysis = await self.flexible_custom(
            steps=parallel_steps,
            reasoning_pattern="parallel",
            custom_instruction="Analyze the passage using all four reasoning types concurrently to generate diverse candidate solutions."
        )

        # Step 2: Collect results from each reasoning type — this is the key difference from existing workflow
        # Instead of branching conditionally, we gather all possible interpretations and let ensemble decide
        count_result = await self.counting_reasoning()
        compare_result = await self.comparison_reasoning()
        arithmetic_result = await self.arithmetic_reasoning()

        # Step 3: Use ScEnsemble to evaluate the consistency of all generated solutions
        # This is a different strategy: rather than choosing one path based on question type,
        # we generate multiple paths and vote on the most robust answer
        solutions = [
            str(count_result),
            str(compare_result),
            str(arithmetic_result),
            str(parallel_analysis)
        ]
        
        final_answer = await self.sc_ensemble(solutions=solutions)

        # Step 4: Optional refinement via Review for final polish (e.g., formatting, clarity)
        refined_answer = await self.review(pre_solution=final_answer)

        return refined_answer