# Workflow ID: drop_39_0
# Benchmark: drop
# Data Indices: [64, 55]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify what needs to be extracted or reasoned about
        initial_thought = await self.custom(instruction="First, analyze the question to determine whether it requires counting, arithmetic, comparison, or a combination. Identify key entities (players, times, scores, etc.) mentioned in the passage relevant to the query.")

        # Step 2: Use FlexibleCustom with a sequential reasoning pattern to guide step-by-step extraction and reasoning
        structured_reasoning = await self.flexible_custom(
            reasoning_pattern="sequential",
            steps=[
                "Extract all relevant numerical or textual data points from the passage that relate to the question.",
                "Determine the type of reasoning needed: count, compare, or compute.",
                "Apply the appropriate specialized operator based on the reasoning type."
            ],
            custom_instruction="Based on the initial thought, now execute the multi-step reasoning process to solve the problem."
        )

        # Step 3: If the task involves comparisons (e.g., longest pass, which quarter had no points), use ComparisonReasoning
        if "longest" in self.problem or "shortest" in self.problem or "which quarter" in self.problem.lower():
            comparison_result = await self.comparison_reasoning()
            final_answer = comparison_result

        # Step 4: If the task involves counting (e.g., how many touchdowns), use CountingReasoning
        elif "how many" in self.problem.lower() or "count" in self.problem.lower():
            count_result = await self.counting_reasoning()
            final_answer = count_result["count"]

        # Step 5: If the task involves arithmetic (e.g., total yards, difference between scores), use ArithmeticReasoning
        elif "sum" in self.problem.lower() or "difference" in self.problem.lower() or "total" in self.problem.lower():
            arithmetic_result = await self.arithmetic_reasoning()
            final_answer = arithmetic_result["result"]

        # Step 6: For other cases (like identifying a specific span), fall back to Custom reasoning
        else:
            final_answer = await self.custom(instruction=f"Based on the structured reasoning: {structured_reasoning}, provide the final answer to the question directly.")

        # Step 7: Optional refinement via review for improved accuracy
        refined_answer = await self.review(pre_solution=final_answer)

        # Step 8: Final ensemble voting across multiple solutions (if needed) — this improves robustness
        solution_pool = [final_answer, refined_answer]
        final_output = await self.sc_ensemble(solutions=solution_pool)

        return final_output