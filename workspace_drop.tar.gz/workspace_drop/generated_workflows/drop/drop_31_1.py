# Workflow ID: drop_31_1
# Benchmark: drop
# Data Indices: [270, 224]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Generate multiple candidate solutions in parallel using different strategies
        # Strategy A: Direct custom reasoning (step-by-step thinking)
        solution_a = await self.custom(instruction="Think step-by-step and solve the problem directly.")

        # Strategy B: Use flexible custom to structure a plan — this forces a multi-step approach
        solution_b = await self.flexible_custom(
            steps=[
                {"name": "identify_task", "instruction": "What type of reasoning is needed? Count, compute, or compare?"},
                {"name": "extract_info", "instruction": "Find all relevant numbers or items from the passage."},
                {"name": "apply_logic", "instruction": "Apply the correct reasoning method based on task type."}
            ],
            reasoning_pattern="sequential",
            custom_instruction="Now solve the problem using the structured plan above."
        )

        # Step 2: Review both solutions independently to improve quality
        reviewed_a = await self.review(pre_solution=solution_a)
        reviewed_b = await self.review(pre_solution=solution_b)

        # Step 3: Use ScEnsemble to select the most consistent answer across two improved solutions
        final_answer = await self.sc_ensemble(solutions=[reviewed_a, reviewed_b])

        return final_answer