# Workflow ID: drop_4_0
# Benchmark: drop
# Data Indices: [390, 45]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify the type of reasoning needed
        initial_thought = await self.custom(instruction="First, analyze the question to determine whether it requires counting, arithmetic, comparison, or a combination. Identify key entities or numbers mentioned in the passage relevant to the query.")

        # Step 2: Generate multiple independent solutions using different strategies
        solution1 = await self.custom(instruction="Use direct extraction: Read the passage carefully and find all instances that match the query directly.")
        solution2 = await self.counting_reasoning()
        solution3 = await self.comparison_reasoning()
        solution4 = await self.arithmetic_reasoning()

        # Step 3: Use ensemble voting to select the most consistent answer
        final_answer = await self.sc_ensemble(solutions=[solution1, solution2, solution3, solution4])

        # Step 4: Optional refinement step — review the final answer for clarity and correctness
        refined_answer = await self.review(pre_solution=final_answer)

        return refined_answer