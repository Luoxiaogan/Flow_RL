# Workflow ID: drop_28_0
# Benchmark: drop
# Data Indices: [250, 342]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify the type of reasoning needed
        initial_thought = await self.custom(instruction="Analyze the question to determine whether it requires counting, arithmetic, or comparison. Identify key entities and quantities in the passage relevant to the question.")

        # Step 2: Use the appropriate specialized operator based on the identified task
        if "count" in initial_thought.lower() or "how many" in initial_thought.lower():
            answer = await self.counting_reasoning()
        elif "sum", "difference", "total", "more than", "less than" in initial_thought.lower():
            answer = await self.arithmetic_reasoning()
        elif "who completed longer", "compare", "which one is greater" in initial_thought.lower():
            answer = await self.comparison_reasoning()
        else:
            # Fallback: use custom reasoning for complex or mixed tasks
            answer = await self.custom(instruction="Use step-by-step reasoning to extract relevant information and compute the final answer based on the passage and question.")

        # Step 3: Review the solution for correctness and clarity
        reviewed_answer = await self.review(pre_solution=answer)

        # Step 4: If multiple solutions exist (e.g., via ensemble), select the most consistent one
        final_answer = await self.sc_ensemble(solutions=[reviewed_answer])

        return final_answer