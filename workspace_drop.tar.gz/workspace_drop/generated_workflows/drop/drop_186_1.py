# Workflow ID: drop_186_1
# Benchmark: drop
# Data Indices: [150, 115]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to execute a multi-step reasoning plan
        # This approach uses structured, parallel-style reasoning by defining steps explicitly
        # and leveraging a "reasoning_pattern" that instructs the model to handle different types
        # of problems with specialized strategies in sequence — not conditionally branching.
        
        steps = [
            "Step 1: Identify the key question and extract relevant entities or numbers from the passage.",
            "Step 2: Determine the type of reasoning required (counting, arithmetic, comparison).",
            "Step 3: Apply the appropriate expert operator based on the determined type.",
            "Step 4: Review the solution for clarity and correctness."
        ]
        
        reasoning_pattern = "sequential"
        
        initial_analysis = await self.flexible_custom(
            steps=steps,
            reasoning_pattern=reasoning_pattern,
            custom_instruction="Analyze the problem using step-by-step logical decomposition."
        )
        
        # Step 2: Extract the final answer from the flexible custom result
        # Since FlexibleCustom already handles the full chain, we now validate it via review
        reviewed_answer = await self.review(pre_solution=initial_analysis)
        
        # Step 3: Use ensemble to ensure robustness — even though there's only one solution,
        # this enforces consistency across potential variations in interpretation
        final_result = await self.sc_ensemble(solutions=[reviewed_answer])
        
        return final_result.strip()