# Workflow ID: drop_66_0
# Benchmark: drop
# Data Indices: [8, 156]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify required reasoning type
        initial_thought = await self.custom(instruction="Analyze the question to determine whether it requires counting, arithmetic, or comparison. Identify key entities or numbers in the passage relevant to the query.")
        
        # Step 2: Use domain-specific expert for structured reasoning
        if "how many more" in initial_thought.lower() or "difference" in initial_thought.lower():
            result = await self.arithmetic_reasoning()
        elif "how many" in initial_thought.lower() or "count" in initial_thought.lower():
            result = await self.counting_reasoning()
        elif "which is more" in initial_thought.lower() or "compare" in initial_thought.lower():
            result = await self.comparison_reasoning()
        else:
            # Fallback to flexible custom for complex or mixed tasks
            result = await self.flexible_custom(
                reasoning_pattern="step-by-step",
                steps=[
                    "Identify all numerical values mentioned in the passage related to the question.",
                    "Extract relevant counts, sums, or comparisons based on the question's intent.",
                    "Perform necessary arithmetic or logical operations to derive the final answer."
                ],
                custom_instruction="Solve the problem by breaking it into clear steps based on the passage and question."
            )

        # Step 3: Refine solution using Review for quality assurance
        refined_solution = await self.review(pre_solution=result)

        # Step 4: Finalize with ensemble voting if multiple solutions exist (optional robustness)
        final_answer = await self.sc_ensemble(solutions=[refined_solution])

        return final_answer