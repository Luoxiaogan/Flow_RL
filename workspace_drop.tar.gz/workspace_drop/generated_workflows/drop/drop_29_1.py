# Workflow ID: drop_29_1
# Benchmark: drop
# Data Indices: [58, 11]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Extract relevant information from the passage using a flexible custom step
        extraction_step = await self.flexible_custom(
            reasoning_pattern="extract",
            steps=[
                "Identify all numerical values mentioned in the passage.",
                "Note the context (e.g., yards, scores, time, counts) associated with each number."
            ],
            custom_instruction="Extract all numbers and their contexts from the passage to support later reasoning."
        )

        # Step 2: Use comparison reasoning to identify candidates for the final answer
        comparison_result = await self.comparison_reasoning()
        
        # Step 3: Generate multiple candidate solutions using different strategies
        # Strategy A: Use counting reasoning if question implies enumeration
        count_attempt = await self.counting_reasoning() if "how many" in self.problem_text.lower() else None

        # Strategy B: Use arithmetic reasoning if question involves sums/differences
        arithmetic_attempt = await self.arithmetic_reasoning() if any(kw in self.problem_text.lower() for kw in ["sum", "difference", "total", "average"]) else None

        # Strategy C: Use comparison reasoning — already done above
        comparison_attempt = comparison_result

        # Step 4: Ensemble vote on all valid attempts
        solutions = []
        if count_attempt:
            solutions.append(str(count_attempt['count']))
        if arithmetic_attempt:
            solutions.append(str(arithmetic_attempt['result']))
        if comparison_attempt:
            result = comparison_attempt['result']
            solutions.append(str(result) if isinstance(result, (int, float)) else result)

        # If no specialized operator was triggered, fall back to general custom reasoning
        if not solutions:
            fallback_solution = await self.custom(instruction="Solve the problem based on the extracted information.")
            return fallback_solution

        # Final ensemble to resolve discrepancies
        final_answer = await self.sc_ensemble(solutions=solutions)
        return final_answer