# Workflow ID: drop_12_1
# Benchmark: drop
# Data Indices: [389, 343]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to extract key elements and reason in one go — no early branching!
        initial_analysis = await self.flexible_custom(
            reasoning_pattern="multi_step_extraction_and_reasoning",
            steps=[
                {"name": "parse_question", "instruction": "Identify whether the question requires counting, arithmetic, or comparison. Also extract key phrases like 'first half', 'longest field goal', etc."},
                {"name": "extract_relevant_data", "instruction": "From the passage, identify all relevant events (e.g., field goals, touchdowns) that relate to the question."},
                {"name": "apply_reasoning", "instruction": "Apply the correct reasoning type based on the parsed question: count, compute difference, or compare values."},
                {"name": "generate_answer", "instruction": "Return only the final answer as a number, date, or span of text."}
            ],
            custom_instruction="Execute the full workflow using the above structured steps."
        )

        # Step 2: Run a review to improve clarity and correctness
        reviewed_solution = await self.review(pre_solution=initial_analysis)

        # Step 3: Use ScEnsemble to validate against multiple independent attempts
        # Generate two alternative solutions with slightly different prompts to ensure robustness
        solution1 = await self.custom(instruction="First, interpret the question step-by-step and solve it directly.")
        solution2 = await self.custom(instruction="Now, think about this as a multi-part problem: break it into subtasks and solve each logically.")

        # Ensemble vote — select most consistent answer across all three
        ensemble_result = await self.sc_ensemble(solutions=[initial_analysis, reviewed_solution, solution1, solution2])

        return ensemble_result.strip()