# Workflow ID: drop_80_1
# Benchmark: drop
# Data Indices: [159, 143]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use flexible custom to extract and structure key numerical facts from passage
        structured_facts = await self.flexible_custom(
            reasoning_pattern="Extract all relevant numerical values mentioned in the passage related to the question.",
            steps=[
                "Identify all numbers explicitly tied to events or entities in the passage",
                "Group them by relevance to the question (e.g., distances, years, counts)",
                "Format as a list of {key: value} pairs"
            ]
        )

        # Step 2: Use comparison reasoning to identify which values are needed for the answer
        comparison_result = await self.comparison_reasoning()

        # Step 3: Generate two distinct solutions using different strategies — one based on structured facts, one based on direct arithmetic
        solution_from_facts = await self.custom(instruction=f"Using the following structured facts: {structured_facts}, compute the final answer step-by-step.")
        solution_from_arithmetic = await self.arithmetic_reasoning()

        # Step 4: Review each solution individually to improve quality before ensemble
        reviewed_solution1 = await self.review(pre_solution=solution_from_facts)
        reviewed_solution2 = await self.review(pre_solution=solution_from_arithmetic)

        # Step 5: Use ScEnsemble to select the most consistent answer between the two reviewed solutions
        final_answer = await self.sc_ensemble(solutions=[reviewed_solution1, reviewed_solution2])

        return final_answer