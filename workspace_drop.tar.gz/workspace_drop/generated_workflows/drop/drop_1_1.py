# Workflow ID: drop_1_1
# Benchmark: drop
# Data Indices: [158, 303]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Strategy: Generate multiple independent solutions using different reasoning paths
        # Then, use ensemble to select the most consistent answer — robustness through diversity

        # Step 1: Get a general understanding of the problem (shared across all approaches)
        high_level_thought = await self.custom(instruction="Understand the question and identify what needs to be computed or compared.")

        # Step 2: Run three distinct reasoning strategies in parallel (different logic paths)
        solution1 = await self.flexible_custom(
            reasoning_pattern="step_by_step",
            steps=[
                "Extract all relevant numerical facts from the passage.",
                "Identify which values are needed for the final calculation.",
                "Perform arithmetic operations step-by-step."
            ],
            custom_instruction="Solve the problem using structured arithmetic reasoning."
        )

        solution2 = await self.flexible_custom(
            reasoning_pattern="chain_of_thought",
            steps=[
                "List all events involving scores (touchdowns, field goals, etc.).",
                "Categorize each event as passing or running based on context.",
                "Count total yards for each category and compute difference."
            ],
            custom_instruction="Solve by categorizing touchdowns and computing yard differences."
        )

        solution3 = await self.comparison_reasoning()

        # Step 3: Use ScEnsemble to vote on the best answer — improves robustness via consensus
        final_answer = await self.sc_ensemble(solutions=[solution1, solution2, solution3])

        return final_answer