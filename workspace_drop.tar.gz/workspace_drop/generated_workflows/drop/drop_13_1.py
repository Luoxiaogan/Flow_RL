# Workflow ID: drop_13_1
# Benchmark: drop
# Data Indices: [145, 269]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Strategy: Generate multiple independent solutions using different reasoning paths
        # Then use ensemble voting to pick the most consistent answer — this ensures robustness
        # Unlike the existing workflow which uses a single path, this one explores diverse strategies first.

        # Step 1: Use FlexibleCustom with different reasoning patterns to generate distinct solution paths
        solution1 = await self.flexible_custom(
            reasoning_pattern="step-by-step",
            steps=[
                "Extract all numerical values and their contexts from the passage.",
                "Identify which ones are relevant to answering the question.",
                "Apply arithmetic or comparison logic based on the question type."
            ],
            custom_instruction="Solve the problem by extracting relevant numbers and applying appropriate operations."
        )

        solution2 = await self.flexible_custom(
            reasoning_pattern="chain-of-thought",
            steps=[
                "First, determine what kind of reasoning is needed (counting, arithmetic, comparison).",
                "Next, locate every event in the passage that relates to the question.",
                "Finally, compute the result based on those events."
            ],
            custom_instruction="Use chain-of-thought reasoning to solve the problem step-by-step."
        )

        solution3 = await self.flexible_custom(
            reasoning_pattern="reason-and-verify",
            steps=[
                "Generate an initial hypothesis about the answer.",
                "Verify it against the passage by identifying supporting evidence.",
                "If verification fails, refine the hypothesis until it fits."
            ],
            custom_instruction="Solve the problem by forming a hypothesis and verifying it with evidence from the text."
        )

        # Step 2: Ensemble vote across the three independently generated solutions
        final_answer = await self.sc_ensemble(solutions=[solution1, solution2, solution3])

        # Step 3: Final review to improve clarity and correctness
        refined_answer = await self.review(pre_solution=final_answer)

        return refined_answer