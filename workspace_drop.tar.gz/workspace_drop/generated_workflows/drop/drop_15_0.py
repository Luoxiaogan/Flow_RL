# Workflow ID: drop_15_0
# Benchmark: drop
# Data Indices: [50, 265]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use Custom to analyze the question and determine what needs to be extracted
        initial_analysis = await self.custom(instruction="Analyze the question. Identify whether it requires counting, arithmetic, comparison, or a span of text. Determine the relevant entities in the passage that relate to the question.")

        # Step 2: Generate multiple solutions using different strategies
        solution1 = await self.custom(instruction="First approach: Extract all field goals mentioned in the passage and identify which one is the shortest.")
        solution2 = await self.custom(instruction="Second approach: Use counting reasoning to find how many field goals were made by each team, then compare distances to find the shortest for the target team.")
        solution3 = await self.custom(instruction="Third approach: Use comparison reasoning to list all field goal distances and return the minimum value.")

        # Step 3: Use sc_ensemble to vote on the most consistent answer across the three approaches
        final_answer = await self.sc_ensemble(solutions=[solution1, solution2, solution3])

        # Step 4: Optionally review the final answer for clarity and correctness
        refined_answer = await self.review(pre_solution=final_answer)

        return refined_answer