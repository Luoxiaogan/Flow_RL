# Workflow ID: drop_69_1
# Benchmark: drop
# Data Indices: [33, 181]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Extract key elements from the passage using Custom to guide reasoning
        extraction = await self.custom(instruction="Identify all relevant numerical data and entities in the passage that could be used to answer the question. Focus on numbers, counts, and comparisons.")

        # Step 2: Use FlexibleCustom with a "decision-tree" pattern to dynamically choose the correct reasoning path
        reasoning_path = await self.flexible_custom(
            reasoning_pattern="decision_tree",
            steps=[
                "Based on the extracted information, determine whether the question asks for a count, an arithmetic result, or a comparison.",
                "If it's a count, call CountingReasoning.",
                "If it's arithmetic, call ArithmeticReasoning.",
                "If it's a comparison or sorting, call ComparisonReasoning.",
                "Then, generate a final answer based on the chosen operator’s output."
            ],
            custom_instruction=f"Using the following extracted info: '{extraction}', now decide the appropriate reasoning type and solve accordingly."
        )

        # Step 3: Immediately review the structured solution before ensemble — this ensures early refinement
        reviewed_solution = await self.review(pre_solution=reasoning_path)

        # Step 4: Run a single specialized operator based on the most likely task (determined by FlexibleCustom)
        # Instead of running all three operators blindly, we now only run one — the one selected via decision tree
        # This reduces redundancy and increases efficiency while maintaining correctness

        # Step 5: Final ensemble — but only with the reviewed solution and a fallback from Custom if needed
        final_answer = await self.sc_ensemble([
            reviewed_solution,
            await self.custom(instruction="Generate a simple, direct answer based solely on the passage and question.")
        ])

        return final_answer