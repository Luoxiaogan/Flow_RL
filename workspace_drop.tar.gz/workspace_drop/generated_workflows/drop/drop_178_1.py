# Workflow ID: drop_178_1
# Benchmark: drop
# Data Indices: [287, 126]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use flexible custom to define a multi-step reasoning plan based on question type
        reasoning_plan = await self.flexible_custom(
            steps=[
                "Identify whether the question requires counting, arithmetic, comparison, or span extraction.",
                "Extract relevant information from the passage that directly answers the question.",
                "Apply the appropriate specialized reasoning operator (Counting, Arithmetic, Comparison).",
                "Format the final answer as a number, date, or exact text span."
            ],
            reasoning_pattern="chain_of_thought",
            custom_instruction="Generate a detailed solution plan based on the question and passage."
        )

        # Step 2: Run multiple candidate solutions in parallel using different strategies
        candidates = []

        # Candidate 1: Direct extraction + review
        extract_step = await self.custom(instruction="Extract key facts related to the question.")
        direct_answer = await self.custom(instruction=f"Using the extracted facts: '{extract_step}', generate an answer directly.")
        reviewed_direct = await self.review(pre_solution=direct_answer)
        candidates.append(reviewed_direct)

        # Candidate 2: Specialized reasoning operator
        if "how many more" in reasoning_plan.lower() or "difference" in reasoning_plan.lower():
            arith_result = await self.arithmetic_reasoning()
            candidates.append(arith_result.get('result', arith_result))
        elif "count" in reasoning_plan.lower() or "number of" in reasoning_plan.lower():
            count_result = await self.counting_reasoning()
            candidates.append(count_result.get('count', count_result))
        elif "compare" in reasoning_plan.lower() or "more than" in reasoning_plan.lower():
            comp_result = await self.comparison_reasoning()
            candidates.append(comp_result.get('result', comp_result))
        else:
            # Fallback to flexible custom for unknown types
            fallback = await self.flexible_custom(
                steps=["Understand the question", "Find relevant info", "Answer clearly"],
                reasoning_pattern="chain_of_thought",
                custom_instruction="Solve the problem step-by-step."
            )
            candidates.append(fallback)

        # Step 3: Use ensemble to select the most consistent answer across candidates
        final_answer = await self.sc_ensemble(solutions=candidates)

        # Step 4: Final review to polish the answer before returning
        polished_answer = await self.review(pre_solution=final_answer)

        return polished_answer