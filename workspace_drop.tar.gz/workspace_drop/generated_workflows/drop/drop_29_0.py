# Workflow ID: drop_29_0
# Benchmark: drop
# Data Indices: [58, 11]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Identify the type of reasoning required based on the question
        initial_thought = await self.custom(instruction="Analyze the question to determine whether it requires counting, arithmetic, or comparison reasoning.")
        
        # Step 2: Use the appropriate specialized operator based on the identified task type
        if "how many" in initial_thought.lower() or "count" in initial_thought.lower():
            result = await self.counting_reasoning()
            return result['count']
        elif "sum", "difference", "total", "average" in initial_thought.lower():
            result = await self.arithmetic_reasoning()
            return result['result']
        elif "which", "who", "what team", "longest", "shortest", "most", "least" in initial_thought.lower():
            result = await self.comparison_reasoning()
            return result['result']
        else:
            # Fallback: General reasoning via custom step-by-step instruction
            final_answer = await self.custom(instruction="Think step-by-step and solve the problem based on the passage and question.")
            return final_answer