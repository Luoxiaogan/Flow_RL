# Workflow ID: drop_188_0
# Benchmark: drop
# Data Indices: [25, 70]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question type (counting, arithmetic, comparison)
        initial_thought = await self.custom(instruction="Identify whether the question requires counting, arithmetic, or comparison reasoning based on keywords like 'how many', 'sum', 'difference', 'which group is smaller', etc.")

        # Step 2: Route to the appropriate specialized operator
        if "how many" in initial_thought.lower() or "count" in initial_thought.lower():
            result = await self.counting_reasoning()
        elif "sum" in initial_thought.lower() or "difference" in initial_thought.lower() or "total" in initial_thought.lower():
            result = await self.arithmetic_reasoning()
        elif "which group" in initial_thought.lower() or "smaller than" in initial_thought.lower() or "greater than" in initial_thought.lower():
            result = await self.comparison_reasoning()
        else:
            # Fallback: use custom for general reasoning
            result = await self.custom(instruction="Based on the initial thought, solve the problem step-by-step using logical deduction and information extraction from the passage.")

        # Step 3: Optionally refine with review or ensemble for robustness
        refined_result = await self.review(pre_solution=result)
        final_result = await self.sc_ensemble(solutions=[result, refined_result])

        return final_result