# Workflow ID: drop_60_0
# Benchmark: drop
# Data Indices: [4, 88]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Initial reasoning — understand what needs to be extracted or computed
        initial_thought = await self.custom(instruction="First, identify the key information needed to answer the question. Focus on extracting relevant facts or identifying the type of reasoning required (e.g., counting, arithmetic, comparison).")

        # Step 2: Determine the appropriate reasoning type based on the question
        reasoning_type = await self.custom(instruction=f"Based on the question and passage, determine whether this requires counting, arithmetic, or comparison reasoning. Respond with exactly one word: 'counting', 'arithmetic', or 'comparison'. The question is: {self.problem.get('question', '')}")

        # Step 3: Execute the chosen reasoning step
        if "counting" in reasoning_type.lower():
            result = await self.counting_reasoning()
        elif "arithmetic" in reasoning_type.lower():
            result = await self.arithmetic_reasoning()
        elif "comparison" in reasoning_type.lower():
            result = await self.comparison_reasoning()
        else:
            # Fallback: use flexible custom to handle unknown types
            result = await self.flexible_custom(
                steps=["Identify relevant items", "Count or compute as needed"],
                reasoning_pattern="stepwise",
                custom_instruction="Solve the problem using a structured approach."
            )

        # Step 4: Review the solution for correctness and clarity
        reviewed_solution = await self.review(pre_solution=result)

        # Step 5: Use ensemble to improve robustness by comparing multiple solutions if needed
        final_answer = await self.sc_ensemble(solutions=[reviewed_solution])

        return final_answer