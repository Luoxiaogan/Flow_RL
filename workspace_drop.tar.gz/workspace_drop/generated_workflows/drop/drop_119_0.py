# Workflow ID: drop_119_0
# Benchmark: drop
# Data Indices: [142, 187]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question type — extract key elements
        initial_thought = await self.custom(instruction="First, read the question carefully and identify what kind of reasoning is needed (e.g., counting, arithmetic, comparison, or extraction).")
        
        # Step 2: Use flexible_custom to structure a multi-step plan based on the problem type
        reasoning_pattern = "Identify relevant entities in the passage, then apply appropriate reasoning (counting/arithmetic/comparison) to derive the answer."
        steps = [
            "Extract all relevant information from the passage that relates to the question.",
            "Determine whether the required answer involves counting items, performing arithmetic operations, or comparing values.",
            "Apply the corresponding specialized operator (CountingReasoning, ArithmeticReasoning, ComparisonReasoning) to compute the result.",
            "Format the final answer clearly based on the output of the chosen reasoning step."
        ]
        structured_plan = await self.flexible_custom(
            reasoning_pattern=reasoning_pattern,
            steps=steps,
            custom_instruction="Based on the initial thought, generate a step-by-step solution plan using the passage and question."
        )

        # Step 3: Perform the actual reasoning — this will be determined by the nature of the problem
        # For DROP-style problems, we often need to first extract info via Custom, then reason
        extracted_info = await self.custom(instruction="Extract all relevant facts from the passage that pertain to the question.")
        
        # Now determine which reasoning task fits best — this is done dynamically based on the question
        # We assume the system can infer from the question context which operator to call next
        inference = await self.custom(instruction="Based on the extracted facts and the original question, decide whether the next step should involve counting, arithmetic, or comparison.")

        # If it's a count-related question (e.g., how many touchdowns?), use CountingReasoning
        if "count" in inference.lower() or "how many" in inference.lower():
            count_result = await self.counting_reasoning()
            return count_result["count"]

        # If it's an arithmetic question (e.g., total score, difference), use ArithmeticReasoning
        elif "sum" in inference.lower() or "difference" in inference.lower() or "total" in inference.lower():
            arithmetic_result = await self.arithmetic_reasoning()
            return arithmetic_result["result"]

        # If it's a comparison question (e.g., who scored more?), use ComparisonReasoning
        elif "compare" in inference.lower() or "who scored more" in inference.lower() or "highest" in inference.lower():
            comparison_result = await self.comparison_reasoning()
            return comparison_result["result"]

        # Otherwise, fall back to general reasoning with Custom
        else:
            final_answer = await self.custom(instruction=f"Using the extracted information: {extracted_info}, solve the problem directly based on the question.")
            return final_answer