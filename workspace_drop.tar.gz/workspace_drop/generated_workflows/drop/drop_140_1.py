# Workflow ID: drop_140_1
# Benchmark: drop
# Data Indices: [61, 385]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Strategy: Generate multiple solutions using different reasoning paths in parallel,
        # then use ensemble to select the most consistent answer — no single-step classification.

        # Step 1: Generate three distinct solutions using different strategies
        solution1 = await self.counting_reasoning()
        solution2 = await self.arithmetic_reasoning()
        solution3 = await self.flexible_custom(
            reasoning_pattern="step-by-step",
            steps=[
                "Identify key numerical values in the passage.",
                "Determine what operation (addition, subtraction, etc.) is needed based on the question.",
                "Compute the result using arithmetic reasoning."
            ],
            custom_instruction="Solve the problem by identifying numbers and applying the correct arithmetic operation."
        )

        # Step 2: Use ScEnsemble to evaluate all three and return the most consistent answer
        final_answer = await self.sc_ensemble(solutions=[str(solution1), str(solution2), str(solution3)])

        return final_answer