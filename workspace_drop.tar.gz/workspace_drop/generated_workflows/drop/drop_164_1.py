# Workflow ID: drop_164_1
# Benchmark: drop
# Data Indices: [345, 118]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use a flexible custom workflow to first extract relevant facts
        extraction_result = await self.flexible_custom(
            reasoning_pattern="Extract key entities and temporal information",
            steps=[
                "Identify all named events or time periods mentioned in the passage.",
                "List each event with its start and end dates (if available)."
            ],
            custom_instruction="Based on the passage, extract all events with their associated dates."
        )

        # Step 2: Use ArithmeticReasoning to compute durations or differences when applicable
        arithmetic_result = await self.arithmetic_reasoning()

        # Step 3: If the question involves counting or sorting, use specialized operators
        if "how many" in self.problem.lower() or "count" in self.problem.lower():
            count_result = await self.counting_reasoning()
            final_answer = count_result
        elif "which" in self.problem.lower() or "who" in self.problem.lower():
            comparison_result = await self.comparison_reasoning()
            final_answer = comparison_result
        else:
            # For other types (e.g., dates), fall back to reviewing the best solution
            review_result = await self.review(pre_solution=arithmetic_result)
            final_answer = review_result

        # Step 4: Use ScEnsemble only as a final refinement step — not for initial solutions
        final_answer = await self.sc_ensemble(solutions=[final_answer])

        return final_answer