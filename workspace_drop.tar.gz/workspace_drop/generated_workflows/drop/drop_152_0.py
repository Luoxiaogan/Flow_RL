# Workflow ID: drop_152_0
# Benchmark: drop
# Data Indices: [182, 198]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify what type of reasoning is needed
        initial_thought = await self.custom(instruction="Analyze the question to determine whether it requires counting, arithmetic, comparison, or text span extraction.")
        
        # Step 2: Use FlexibleCustom with a sequential reasoning pattern to break down the problem into steps
        reasoning_steps = [
            "Identify relevant information in the passage related to the question.",
            "Extract numerical data, dates, or named entities as needed.",
            "Apply appropriate reasoning (counting, arithmetic, comparison) based on the question type.",
            "Determine the final answer by synthesizing all prior steps."
        ]
        
        solution = await self.flexible_custom(
            reasoning_pattern="sequential",
            steps=reasoning_steps,
            custom_instruction="Now solve the problem using the structured plan above."
        )
        
        # Step 3: Review the solution for clarity and correctness
        refined_solution = await self.review(pre_solution=solution)
        
        # Step 4: If multiple solutions were generated (e.g., via ensemble), select the most consistent one
        # Note: In this single-solution case, sc_ensemble acts as a safeguard against hallucination
        final_answer = await self.sc_ensemble(solutions=[refined_solution])
        
        return final_answer