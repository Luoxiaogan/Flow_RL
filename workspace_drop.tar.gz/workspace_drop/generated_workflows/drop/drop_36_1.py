# Workflow ID: drop_36_1
# Benchmark: drop
# Data Indices: [286, 107]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use flexible_custom to first identify key numerical entities (dates, counts, values)
        steps = [
            "Extract all numeric values and their context from the passage.",
            "Identify which ones are relevant to answering the question.",
            "Determine whether the task requires counting, arithmetic, or comparison."
        ]
        reasoning_pattern = "chain_of_thought"
        
        extracted_info = await self.flexible_custom(
            steps=steps,
            reasoning_pattern=reasoning_pattern,
            custom_instruction="Analyze the passage and extract all relevant numbers with their context."
        )

        # Step 2: Based on the extracted info, choose one specialized operator directly
        # This avoids generating multiple solutions in parallel — instead, we make a strategic choice
        # based on the question type inferred from the initial analysis
        decision_prompt = f"Based on the following extracted information:\n{extracted_info}\n\nWhat kind of reasoning is needed? (arithmetic, comparison, counting)"
        reasoning_type = await self.custom(instruction=decision_prompt)

        if "arithmetic" in reasoning_type.lower():
            final_result = await self.arithmetic_reasoning()
        elif "comparison" in reasoning_type.lower():
            final_result = await self.comparison_reasoning()
        elif "counting" in reasoning_type.lower():
            final_result = await self.counting_reasoning()
        else:
            # Fallback: use custom to reason step-by-step if classification fails
            final_result = await self.custom(instruction=f"Given the extracted info: {extracted_info}, solve the problem using step-by-step reasoning.")

        # Step 3: Review the solution before returning
        reviewed_answer = await self.review(pre_solution=final_result)

        return reviewed_answer