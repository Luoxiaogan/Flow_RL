# Workflow ID: drop_95_1
# Benchmark: drop
# Data Indices: [221, 100]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to extract relevant facts and define reasoning plan
        extraction_plan = await self.flexible_custom(
            steps=[
                "Identify all key numerical or categorical entities mentioned in the passage related to the question.",
                "Determine whether the final answer requires counting, arithmetic computation, or comparison.",
                "Formulate a high-level strategy for solving the problem using one or more specialized operators."
            ],
            reasoning_pattern="sequential",
            custom_instruction="Extract and organize the relevant information from the passage to guide subsequent reasoning steps."
        )

        # Step 2: Generate multiple candidate solutions using different reasoning paths
        candidates = []

        # Candidate 1: Direct counting (if question asks "how many")
        if "how many" in extraction_plan.lower():
            count_result = await self.counting_reasoning()
            candidates.append(count_result['count'])

        # Candidate 2: Arithmetic reasoning (for totals, differences, etc.)
        if "total" in extraction_plan.lower() or "sum" in extraction_plan.lower():
            arithmetic_result = await self.arithmetic_reasoning()
            candidates.append(arithmetic_result['result'])

        # Candidate 3: Comparison reasoning (for rankings, comparisons)
        if "compare" in extraction_plan.lower() or "which is more" in extraction_plan.lower():
            comparison_result = await self.comparison_reasoning()
            candidates.append(comparison_result['result'])

        # Candidate 4: General solution via Custom with structured analysis
        general_solution = await self.custom(instruction=f"Based on the structured extraction plan: {extraction_plan}, solve the problem step-by-step using discrete reasoning over the extracted facts.")
        candidates.append(general_solution)

        # Step 3: Apply ScEnsemble to select the most consistent answer across all candidates
        final_answer = await self.sc_ensemble(solutions=candidates)

        # Step 4: Review the final answer for clarity and correctness
        reviewed_answer = await self.review(pre_solution=final_answer)

        return reviewed_answer