# Workflow ID: drop_143_0
# Benchmark: drop
# Data Indices: [47, 396]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify required reasoning type
        initial_thought = await self.custom(instruction="Analyze the question to determine whether it requires counting, arithmetic, or comparison reasoning.")
        
        # Step 2: Extract relevant information from the passage based on the question type
        extraction = await self.custom(instruction=f"Based on the question and initial thought: {initial_thought}, extract all relevant numerical or textual data needed to solve the problem.")

        # Step 3: Apply the appropriate specialized reasoning operator
        if "count" in initial_thought.lower() or "how many" in initial_thought.lower():
            reasoning_result = await self.counting_reasoning()
        elif "sum" in initial_thought.lower() or "total" in initial_thought.lower() or "difference" in initial_thought.lower() or "arithmetic" in initial_thought.lower():
            reasoning_result = await self.arithmetic_reasoning()
        elif "longest" in initial_thought.lower() or "shortest" in initial_thought.lower() or "most" in initial_thought.lower() or "least" in initial_thought.lower() or "compare" in initial_thought.lower():
            reasoning_result = await self.comparison_reasoning()
        else:
            # Fallback to custom reasoning if no clear pattern
            reasoning_result = await self.custom(instruction="Apply general reasoning to solve the problem using extracted data.")

        # Step 4: Format final answer clearly
        final_answer = await self.custom(instruction=f"Using the reasoning result: {reasoning_result}, format the final answer concisely. Do not include extra explanation unless necessary.")

        # Optional: Use review or ensemble for robustness (if needed)
        # Uncomment below lines for higher confidence solutions:
        # reviewed = await self.review(pre_solution=final_answer)
        # final_answer = await self.sc_ensemble(solutions=[final_answer, reviewed])

        return final_answer