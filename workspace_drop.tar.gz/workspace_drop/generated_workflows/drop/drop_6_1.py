# Workflow ID: drop_6_1
# Benchmark: drop
# Data Indices: [339, 99]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to extract key information and structure the reasoning plan
        extraction_plan = await self.flexible_custom(
            reasoning_pattern="step_by_step",
            steps=[
                "Identify all relevant entities, quantities, or events in the passage that relate to the question.",
                "Determine the type of reasoning needed (counting, arithmetic, comparison).",
                "Formulate a precise instruction for the next step based on this analysis."
            ],
            custom_instruction="Extract and organize information from the passage to guide further reasoning."
        )

        # Step 2: Based on the structured plan, apply the most appropriate specialized operator directly
        if "count" in extraction_plan.lower() or "how many" in extraction_plan.lower():
            count_result = await self.counting_reasoning()
            return count_result["count"]
        elif any(keyword in extraction_plan.lower() for keyword in ["sum", "difference", "total", "more than", "less than"]):
            arith_result = await self.arithmetic_reasoning()
            return arith_result["result"]
        elif any(keyword in extraction_plan.lower() for keyword in ["who", "which", "order", "sort", "most", "least"]):
            comp_result = await self.comparison_reasoning()
            return comp_result["result"]
        else:
            # If no clear type is identified, generate multiple candidate solutions in parallel
            solution1 = await self.custom(instruction="First, interpret the question and identify what needs to be found.")
            solution2 = await self.custom(instruction="Now, extract numerical values and relationships from the passage.")
            solution3 = await self.custom(instruction="Finally, synthesize the extracted facts into a coherent answer.")

            # Step 3: Use ScEnsemble to select the best solution among the three
            final_answer = await self.sc_ensemble(solutions=[solution1, solution2, solution3])
            return final_answer