# Workflow ID: drop_105_1
# Benchmark: drop
# Data Indices: [273, 104]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to define a structured reasoning pattern
        # This avoids step-by-step branching and instead uses a unified multi-step plan
        reasoning_plan = await self.flexible_custom(
            reasoning_pattern="Extract → Classify → Solve",
            steps=[
                "Identify key entities mentioned in the passage relevant to the question.",
                "Determine the type of reasoning required (counting, arithmetic, comparison).",
                "Apply the appropriate specialized operator based on classification."
            ],
            custom_instruction="Execute the above reasoning steps using the passage and question."
        )

        # Step 2: Extract and classify in one go — no separate extraction step
        # The flexible_custom already does this implicitly via its steps
        final_result = await self.custom(instruction=f"Based on the structured plan: {reasoning_plan}, now solve the problem directly by applying the correct reasoning operator.")
        
        # Step 3: Apply ensemble immediately after initial solution — not as a fallback
        # This ensures robustness from the start, rather than trying to fix later
        solutions = [
            final_result,
            await self.custom(instruction="Re-solve using a fresh perspective: focus only on what the question explicitly asks for."),
            await self.custom(instruction="Solve again with emphasis on identifying all named entities first before reasoning.")
        ]
        
        # Select best answer through voting — early and decisive
        final_answer = await self.sc_ensemble(solutions=solutions)

        return final_answer