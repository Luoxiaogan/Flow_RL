# Workflow ID: drop_91_0
# Benchmark: drop
# Data Indices: [220, 372]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question type — determine if it's counting, arithmetic, or comparison
        initial_thought = await self.custom(instruction="Analyze the question to determine whether it requires counting, arithmetic, or comparison reasoning.")
        
        # Step 2: Based on the question type, choose the appropriate specialized operator
        if "count" in initial_thought.lower() or "how many" in initial_thought.lower():
            count_result = await self.counting_reasoning()
            return count_result['count']
        elif "percent" in initial_thought.lower() or "percentage" in initial_thought.lower():
            # For percentage questions like "How many percent of people were not Asian?"
            arithmetic_result = await self.arithmetic_reasoning()
            return arithmetic_result['result']
        elif "compare" in initial_thought.lower() or "greater than" in initial_thought.lower() or "less than" in initial_thought.lower():
            comparison_result = await self.comparison_reasoning()
            return comparison_result['result']
        else:
            # Fallback: Use a general custom instruction to solve step-by-step
            final_answer = await self.custom(instruction="Based on the analysis, solve the problem using step-by-step reasoning.")
            return final_answer