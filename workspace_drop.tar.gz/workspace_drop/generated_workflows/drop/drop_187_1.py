# Workflow ID: drop_187_1
# Benchmark: drop
# Data Indices: [335, 271]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Get a high-level understanding of the question type via Custom
        initial_analysis = await self.custom(instruction="Identify whether this question requires counting, arithmetic, or comparison reasoning. Do not solve yet — just classify the task.")

        # Step 2: Generate multiple candidate solutions in parallel using different strategies
        # Strategy A: Direct specialized operator based on classification
        strategy_a = await self.flexible_custom(
            reasoning_pattern="sequential",
            steps=[
                "Based on the classification in step 1, select one appropriate reasoning operator.",
                "Execute that operator directly to get an answer."
            ],
            custom_instruction=f"Choose and execute the best-suited reasoning operator based on this classification: {initial_analysis}"
        )

        # Strategy B: Use Review to refine a general solution
        strategy_b = await self.custom(instruction="First, generate a full step-by-step solution manually without using specialized operators. Then, review it thoroughly for correctness.")
        strategy_b_reviewed = await self.review(pre_solution=strategy_b)

        # Strategy C: Use ScEnsemble on two raw answers (one from each strategy)
        ensemble_input = [strategy_a, strategy_b_reviewed]

        # Step 3: Finalize by selecting the most consistent result through voting
        final_answer = await self.sc_ensemble(solutions=ensemble_input)

        return final_answer