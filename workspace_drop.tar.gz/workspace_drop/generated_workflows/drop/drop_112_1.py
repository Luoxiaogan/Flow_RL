# Workflow ID: drop_112_1
# Benchmark: drop
# Data Indices: [340, 263]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # --- NEW STRATEGIC TEMPLATE: Parallel Reasoning + Selective Ensemble ---
        
        # Step 1: Generate multiple distinct solutions using different reasoning paths
        # Strategy: Use FlexibleCustom to define two parallel thought processes — one focused on extraction, another on direct interpretation
        
        solution1 = await self.flexible_custom(
            reasoning_pattern="Extract all relevant numerical data first, then apply arithmetic reasoning.",
            steps=[
                "Identify all named entities and quantities related to the question.",
                "Use counting or arithmetic reasoning based on extracted values."
            ],
            custom_instruction="First extract key numerical facts from the passage, then reason about them."
        )
        
        solution2 = await self.flexible_custom(
            reasoning_pattern="Interpret the question directly and generate a solution without explicit extraction steps.",
            steps=[
                "Read the question carefully to determine what must be computed or compared.",
                "Generate an answer in one step using internal knowledge of the passage context."
            ],
            custom_instruction="Solve the problem directly by interpreting the passage and question together."
        )

        # Step 2: Refine each solution independently with Review
        refined_solution1 = await self.review(pre_solution=solution1)
        refined_solution2 = await self.review(pre_solution=solution2)

        # Step 3: Use ScEnsemble to vote between the two refined solutions
        final_answer = await self.sc_ensemble(solutions=[refined_solution1, refined_solution2])
        
        return final_answer