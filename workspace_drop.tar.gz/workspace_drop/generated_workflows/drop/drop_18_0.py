# Workflow ID: drop_18_0
# Benchmark: drop
# Data Indices: [352, 228]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify required reasoning type
        initial_thought = await self.custom(instruction="Analyze the question to determine if it requires counting, arithmetic, comparison, or a combination. Identify key entities and values in the passage relevant to the query.")

        # Step 2: Extract necessary information using flexible custom logic (e.g., find numbers, categories, or spans)
        extraction_step = {
            "step": "Extract all relevant numerical data and contextual facts from the passage",
            "reasoning_pattern": "sequential",
            "custom_instruction": "Identify and list all numeric values, percentages, years, and named entities that might be relevant to answering the question."
        }
        extracted_info = await self.flexible_custom(steps=[extraction_step])

        # Step 3: Determine the appropriate reasoning path based on the question type
        reasoning_type_analysis = await self.custom(
            instruction=f"Based on the question and extracted info: {extracted_info}, classify the reasoning needed: counting, arithmetic, or comparison."
        )

        # Step 4: Execute specialized reasoning
        if "count" in reasoning_type_analysis.lower():
            result = await self.counting_reasoning()
        elif "arithmetic" in reasoning_type_analysis.lower():
            result = await self.arithmetic_reasoning()
        elif "compare" in reasoning_type_analysis.lower() or "sort" in reasoning_type_analysis.lower():
            result = await self.comparison_reasoning()
        else:
            # Fallback to general step-by-step thinking
            result = await self.custom(instruction="Use logical deduction to solve the problem by combining extracted facts with basic reasoning steps.")

        # Step 5: Refine the solution via review
        refined_solution = await self.review(pre_solution=result)

        # Step 6: Use ensemble to improve robustness if multiple solutions exist (simulate with 3 attempts)
        solutions = [result, refined_solution]
        final_answer = await self.sc_ensemble(solutions=solutions)

        return final_answer