# Workflow ID: drop_191_0
# Benchmark: drop
# Data Indices: [379, 127]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify required reasoning type
        initial_thought = await self.custom(instruction="First, read the passage carefully and determine what kind of reasoning is needed — counting, arithmetic, or comparison?")
        
        # Step 2: Extract relevant information based on the reasoning type
        extraction_instruction = "Now, extract all necessary numerical or categorical data from the passage that relates to the question."
        extracted_info = await self.custom(instruction=extraction_instruction)
        
        # Step 3: Apply the appropriate specialized reasoning operator
        if "count" in initial_thought.lower() or "how many" in initial_thought.lower():
            reasoning_result = await self.counting_reasoning()
        elif "sum" in initial_thought.lower() or "total" in initial_thought.lower() or "add" in initial_thought.lower():
            reasoning_result = await self.arithmetic_reasoning()
        elif "compare" in initial_thought.lower() or "which is more" in initial_thought.lower() or "smallest" in initial_thought.lower():
            reasoning_result = await self.comparison_reasoning()
        else:
            # Fallback: Use flexible custom to guide multi-step reasoning
            reasoning_result = await self.flexible_custom(
                steps=["Identify key entities", "Extract numbers", "Apply logic"],
                reasoning_pattern="chain_of_thought",
                custom_instruction="Use step-by-step logical deduction to solve this problem."
            )
        
        # Step 4: Finalize answer by interpreting the structured reasoning result
        final_answer = await self.custom(instruction=f"Based on the reasoning: {reasoning_result}, provide a clear and concise final answer to the original question.")
        
        # Optional: Review for correctness
        reviewed_answer = await self.review(pre_solution=final_answer)
        
        # Optional: Ensemble voting (if multiple solutions exist — but here we have one)
        # Since we only have one solution path, skip sc_ensemble unless we generate alternatives
        return reviewed_answer