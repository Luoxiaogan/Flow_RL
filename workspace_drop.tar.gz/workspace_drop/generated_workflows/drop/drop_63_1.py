# Workflow ID: drop_63_1
# Benchmark: drop
# Data Indices: [147, 350]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to define a multi-step reasoning pattern that first identifies the task type,
        # then applies a tailored strategy based on whether it's arithmetic, counting, or comparison.
        reasoning_pattern = "Identify the required reasoning type (arithmetic, counting, comparison), then solve accordingly."
        steps = [
            {"name": "task_identification", "instruction": "Determine if this problem requires counting, arithmetic, or comparison."},
            {"name": "strategy_selection", "instruction": "Based on the identified task type, choose an appropriate operator: arithmetic for math, counting for enumerations, comparison for ordering or selection."},
            {"name": "execution", "instruction": "Execute the chosen reasoning step using the selected operator."}
        ]
        
        initial_solution = await self.flexible_custom(
            reasoning_pattern=reasoning_pattern,
            steps=steps,
            custom_instruction="Use the passage and question to determine the best reasoning path."
        )

        # Step 2: Generate a second solution using a completely different approach — direct review of the first solution
        refined_solution = await self.review(pre_solution=initial_solution)

        # Step 3: Now run a parallel ensemble with both the original and refined solution to ensure robustness
        final_answer = await self.sc_ensemble(solutions=[initial_solution, refined_solution])

        return final_answer