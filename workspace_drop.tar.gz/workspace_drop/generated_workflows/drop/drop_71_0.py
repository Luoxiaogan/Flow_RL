# Workflow ID: drop_71_0
# Benchmark: drop
# Data Indices: [306, 152]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question type — extract key task
        initial_thought = await self.custom(instruction="Identify whether the question requires counting, arithmetic, or comparison reasoning.")
        
        # Step 2: Based on the task type, invoke the appropriate specialized operator
        if "count" in initial_thought.lower() or "how many" in initial_thought.lower():
            result = await self.counting_reasoning()
        elif "sum", "difference", "longer", "shorter", "more", "less" in initial_thought.lower():
            result = await self.arithmetic_reasoning()
        elif "compare", "rank", "order", "longest", "shortest", "earliest", "latest" in initial_thought.lower():
            result = await self.comparison_reasoning()
        else:
            # Fallback to flexible custom for complex or ambiguous tasks
            result = await self.flexible_custom(
                reasoning_pattern="step-by-step",
                steps=["Understand the question", "Extract relevant facts", "Apply logical reasoning"],
                custom_instruction="Solve the problem using step-by-step reasoning."
            )

        # Step 3: Final review to refine the solution
        final_solution = await self.review(pre_solution=result)
        
        # Step 4: Ensemble voting if multiple solutions were generated (e.g., via sc_ensemble)
        # Note: In this simple case, we only have one solution; but the pattern allows future expansion
        return final_solution