# Workflow ID: drop_199_1
# Benchmark: drop
# Data Indices: [323, 167]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom with a parallel reasoning pattern to explore multiple strategies at once
        solutions = await self.flexible_custom(
            reasoning_pattern="parallel",
            steps=[
                {"name": "counting", "instruction": "Identify all numerical counts mentioned in the passage relevant to the question."},
                {"name": "arithmetic", "instruction": "Extract values needed for arithmetic operations (e.g., sums, differences)."},
                {"name": "comparison", "instruction": "Find items that must be compared or sorted to answer the question."}
            ],
            custom_instruction="Generate candidate solutions using different reasoning types in parallel."
        )

        # Step 2: Enforce robustness by selecting the most consistent solution via ScEnsemble
        final_result = await self.sc_ensemble(solutions=solutions.split("\n\n"))  # Split into individual candidate responses

        # Step 3: Review the selected solution to refine clarity and correctness
        refined_result = await self.review(pre_solution=final_result)

        return refined_result