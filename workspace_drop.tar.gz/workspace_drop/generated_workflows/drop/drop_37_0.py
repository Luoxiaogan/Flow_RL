# Workflow ID: drop_37_0
# Benchmark: drop
# Data Indices: [7, 392]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the task — identify whether it's counting, arithmetic, comparison, or text span extraction
        initial_thought = await self.custom(instruction="Analyze the question and determine the type of reasoning required: counting, arithmetic, comparison, or span extraction.")

        # Step 2: Based on the type, apply the appropriate specialized operator
        if "count" in initial_thought.lower() or "how many" in initial_thought.lower():
            count_result = await self.counting_reasoning()
            final_answer = count_result['count']
        elif "sum" in initial_thought.lower() or "difference" in initial_thought.lower() or "total" in initial_thought.lower():
            arith_result = await self.arithmetic_reasoning()
            final_answer = arith_result['result']
        elif "compare" in initial_thought.lower() or "who scored more" in initial_thought.lower() or "which is greater" in initial_thought.lower():
            comp_result = await self.comparison_reasoning()
            final_answer = comp_result['result']
        else:
            # For span-based questions (e.g., "Who fumbled..."), use flexible custom to extract directly
            answer_span = await self.flexible_custom(
                reasoning_pattern="extract_answer",
                steps=[
                    "Identify the key event or entity mentioned in the question.",
                    "Search the passage for the exact mention of that event or entity.",
                    "Return only the full span of text that answers the question."
                ],
                custom_instruction="Extract the exact span of text that answers the question without paraphrasing."
            )
            final_answer = answer_span

        # Step 3: Review the solution for correctness and clarity
        reviewed_solution = await self.review(pre_solution=str(final_answer))

        # Step 4: Use ensemble voting if multiple solutions were generated earlier (optional enhancement)
        # Since we only have one path here, this step ensures robustness by re-evaluating the single result
        final_result = await self.sc_ensemble(solutions=[reviewed_solution])

        return final_result