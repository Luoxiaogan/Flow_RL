# Workflow ID: drop_117_1
# Benchmark: drop
# Data Indices: [353, 103]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # --- STRATEGIC TEMPLATE: Parallel Ensemble with Different Reasoning Paths ---
        
        # Step 1: Generate multiple solutions using different reasoning strategies
        # Strategy A: Use arithmetic reasoning directly (good for numerical comparisons or sums)
        solution_arithmetic = await self.arithmetic_reasoning()
        
        # Strategy B: Use comparison reasoning to identify relevant entities and order them
        solution_comparison = await self.comparison_reasoning()
        
        # Strategy C: Use custom reasoning to break down the question step-by-step
        solution_custom = await self.custom(instruction="Break down the question into sub-tasks: first extract key numbers, then determine how they relate. Solve each sub-task sequentially.")
        
        # Step 2: Use ensemble to select the most consistent answer across all three approaches
        ensemble_result = await self.sc_ensemble([
            solution_arithmetic,
            solution_comparison,
            solution_custom
        ])
        
        # Step 3: Final review to refine the ensemble result
        final_answer = await self.review(pre_solution=ensemble_result)
        
        return final_answer