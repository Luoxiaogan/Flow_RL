# Workflow ID: drop_139_1
# Benchmark: drop
# Data Indices: [27, 21]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Extract all relevant numerical data (e.g., field goal distances, player names)
        extraction = await self.custom(instruction="Extract all scoring plays with their distances and the associated players. Focus only on field goals and touchdowns as they may be relevant to the question.")

        # Step 2: Use ComparisonReasoning to find the longest field goal directly
        comparison_result = await self.comparison_reasoning()
        
        # Step 3: If comparison yields a clear answer, return it immediately
        if "longest" in comparison_result.lower() or "maximum" in comparison_result.lower():
            final_answer = comparison_result
        else:
            # Step 4: Fallback — generate alternative reasoning paths using FlexibleCustom
            steps = [
                {"task": "Identify all field goals mentioned", "reasoning_pattern": "chain_of_thought"},
                {"task": "Compare each field goal distance", "reasoning_pattern": "multi_step_comparison"}
            ]
            fallback_solution = await self.flexible_custom(
                steps=steps,
                reasoning_pattern="sequential",
                custom_instruction="Find the longest field goal based on the passage."
            )
            
            # Step 5: Review the fallback solution for consistency
            reviewed_solution = await self.review(pre_solution=fallback_solution)
            
            # Step 6: Final ensemble with original comparison result and reviewed fallback
            final_answer = await self.sc_ensemble(solutions=[comparison_result, reviewed_solution])

        return final_answer