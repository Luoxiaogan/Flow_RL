# Workflow ID: drop_165_1
# Benchmark: drop
# Data Indices: [149, 171]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to execute a multi-step reasoning plan in parallel
        # This avoids sequential dependency and allows independent exploration of different strategies
        steps = [
            {"name": "extract_relevant_info", "instruction": "Identify key entities, numbers, or events relevant to answering the question."},
            {"name": "classify_task", "instruction": "Determine whether this is a counting, arithmetic, comparison, or direct extraction task."},
            {"name": "solve_with_specialized_operator", "instruction": "Based on classification, choose and apply the correct specialized operator (counting/arithmetic/comparison)."}
        ]
        
        reasoning_pattern = "sequential"  # Execute steps one after another within the same call
        multi_step_solution = await self.flexible_custom(
            steps=steps,
            reasoning_pattern=reasoning_pattern,
            custom_instruction="Solve the problem by first extracting info, then classifying, then solving using appropriate tools."
        )

        # Step 2: Generate an alternative solution using a completely different strategy — parallel path via ScEnsemble
        # Instead of reviewing the single solution, we now generate multiple candidate solutions via distinct paths
        solution_a = await self.custom(instruction="First, extract the answer directly from the passage without additional reasoning.")
        solution_b = await self.arithmetic_reasoning() if "sum" in str(self.problem).lower() or "total" in str(self.problem).lower() else None
        solution_c = await self.counting_reasoning() if "how many" in str(self.problem).lower() else None
        solution_d = await self.comparison_reasoning() if "which is more" in str(self.problem).lower() or "sort" in str(self.problem).lower() else None

        # Collect all valid solutions into a list for ensemble voting
        candidates = [solution_a]
        if solution_b:
            candidates.append(solution_b)
        if solution_c:
            candidates.append(solution_c)
        if solution_d:
            candidates.append(solution_d)

        # Step 3: Use ScEnsemble to select the most consistent answer across multiple approaches
        final_answer = await self.sc_ensemble(solutions=candidates)

        # Step 4: Final review to ensure clarity and correctness — only applied to the ensemble result
        refined_final_answer = await self.review(pre_solution=final_answer)

        return refined_final_answer