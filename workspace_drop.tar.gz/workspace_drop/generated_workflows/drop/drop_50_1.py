# Workflow ID: drop_50_1
# Benchmark: drop
# Data Indices: [157, 338]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to define a multi-step plan based on question type
        plan = await self.flexible_custom(
            reasoning_pattern="step-by-step",
            steps=[
                "Identify whether the question requires counting, arithmetic, or comparison.",
                "Extract relevant spans and numbers from the passage using precise instructions.",
                "Apply the appropriate reasoning operator (counting/arithmetic/comparison)."
            ],
            custom_instruction="Generate a structured solution plan tailored to this DROP-style problem."
        )

        # Step 2: Execute the plan in parallel — try multiple reasoning approaches simultaneously
        count_result = self.counting_reasoning()
        arithmetic_result = self.arithmetic_reasoning()
        comparison_result = self.comparison_reasoning()

        # Step 3: Combine all results into an ensemble vote
        solutions = [await count_result, await arithmetic_result, await comparison_result]
        final_answer = await self.sc_ensemble(solutions=solutions)

        # Step 4: Review the ensemble result to ensure clarity and correctness
        reviewed_answer = await self.review(pre_solution=final_answer)

        return reviewed_answer