# Workflow ID: drop_53_1
# Benchmark: drop
# Data Indices: [39, 371]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Strategy: Use FlexibleCustom to define a multi-step reasoning plan
        # that explores multiple angles in parallel (different logic paths),
        # then uses ScEnsemble to resolve ambiguity — this differs fundamentally
        # from the existing workflow's single-path approach with review.

        steps = [
            {
                "task": "Identify key facts relevant to the question",
                "instruction": "Extract all explicit numerical or comparative clues from the passage that relate to the question."
            },
            {
                "task": "Apply arithmetic reasoning if numbers are found",
                "instruction": "If any numeric values are extracted, compute the required result using arithmetic operations."
            },
            {
                "task": "Apply comparison reasoning if ordering or ranking is needed",
                "instruction": "If the question asks about relative quantities, dates, or positions, determine the correct order or difference."
            },
            {
                "task": "Apply counting reasoning if item frequency is asked",
                "instruction": "If the question involves counting occurrences of events, people, or objects, perform the count."
            }
        ]

        reasoning_pattern = "chain_of_thought"

        # Execute the flexible custom logic with structured steps
        initial_solution = await self.flexible_custom(
            steps=steps,
            reasoning_pattern=reasoning_pattern,
            custom_instruction="Generate a complete solution based on the structured reasoning steps above."
        )

        # Now, refine the solution using Review — but crucially, do it *before* ensemble
        # to ensure each candidate solution is clean before voting
        reviewed_solution = await self.review(pre_solution=initial_solution)

        # Finally, use ScEnsemble to improve robustness by running multiple independent strategies
        # (this is different from the original which used only one path and reviewed once)
        final_answer = await self.sc_ensemble(solutions=[reviewed_solution])

        return final_answer