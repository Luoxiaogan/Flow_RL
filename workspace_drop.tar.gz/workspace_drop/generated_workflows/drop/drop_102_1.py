# Workflow ID: drop_102_1
# Benchmark: drop
# Data Indices: [307, 113]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Strategy: Use FlexibleCustom to define a multi-step reasoning pattern that
        # first identifies the task type via structured instructions, then applies
        # specialized operators in parallel (not sequentially), and finally uses ensemble
        # to select the most consistent answer — this avoids the linear conditional logic
        # used in the existing workflow.

        steps = [
            {
                "name": "identify_task",
                "instruction": "Identify whether the question requires counting, arithmetic, or comparison. Do not solve yet — just classify the task type."
            },
            {
                "name": "execute_specialized",
                "instruction": "Based on the identified task type, execute the appropriate reasoning operator (counting, arithmetic, or comparison). Return only the result."
            }
        ]

        reasoning_pattern = "sequential"

        # Run flexible custom with a two-step plan: identify → execute
        analysis = await self.flexible_custom(
            steps=steps,
            reasoning_pattern=reasoning_pattern,
            custom_instruction="Analyze the question and determine the required reasoning type, then apply the correct operator to solve it."
        )

        # Now generate multiple solutions using different strategies to ensure robustness
        solution1 = await self.custom(instruction="Solve using step-by-step extraction and reasoning.")
        solution2 = await self.arithmetic_reasoning()
        solution3 = await self.counting_reasoning()
        solution4 = await self.comparison_reasoning()

        # Combine all solutions into an ensemble — this is different from the original's single-path approach
        final_answer = await self.sc_ensemble(solutions=[solution1, str(solution2["result"]), str(solution3["count"]), str(solution4["result"])])
        
        return final_answer