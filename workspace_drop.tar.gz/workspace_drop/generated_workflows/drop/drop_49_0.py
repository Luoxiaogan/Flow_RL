# Workflow ID: drop_49_0
# Benchmark: drop
# Data Indices: [363, 108]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question type by analyzing the instruction
        initial_analysis = await self.custom(instruction="Analyze the question to determine if it requires counting, arithmetic, or comparison reasoning.")

        # Step 2: Based on the analysis, choose the appropriate specialized operator
        if "count" in initial_analysis.lower() or "how many" in initial_analysis.lower():
            result = await self.counting_reasoning()
            return result["count"]
        
        elif "sum" in initial_analysis.lower() or "difference" in initial_analysis.lower() or "how many years" in initial_analysis.lower():
            result = await self.arithmetic_reasoning()
            return result["result"]
        
        elif "more" in initial_analysis.lower() or "less" in initial_analysis.lower() or "compare" in initial_analysis.lower():
            result = await self.comparison_reasoning()
            return result["result"]
        
        else:
            # Fallback: Use flexible custom to handle unknown patterns with structured reasoning
            final_answer = await self.flexible_custom(
                steps=[
                    {"step": "Understand the question", "instruction": "What is being asked? Identify key entities and operations."},
                    {"step": "Determine required reasoning type", "instruction": "Is this a count, math, or comparison task?"},
                    {"step": "Execute reasoning", "instruction": "Apply the correct operator based on the type."}
                ],
                reasoning_pattern="chain_of_thought",
                custom_instruction="Now solve the problem using the determined strategy."
            )
            return final_answer