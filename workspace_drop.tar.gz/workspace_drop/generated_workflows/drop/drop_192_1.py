# Workflow ID: drop_192_1
# Benchmark: drop
# Data Indices: [194, 120]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use Custom to understand the question and determine reasoning type directly
        initial_analysis = await self.custom(instruction="Analyze the question: identify whether it requires counting, arithmetic, comparison, or span extraction. Do not solve yet — just classify.")

        # Step 2: Based on classification, invoke the appropriate specialized operator directly
        if "count" in initial_analysis.lower() or "how many" in initial_analysis.lower():
            reasoning_result = await self.counting_reasoning()
            answer = reasoning_result["count"]
        elif "sum" in initial_analysis.lower() or "difference" in initial_analysis.lower() or "more than" in initial_analysis.lower():
            reasoning_result = await self.arithmetic_reasoning()
            answer = reasoning_result["result"]
        elif "who" in initial_analysis.lower() or "longest" in initial_analysis.lower() or "most" in initial_analysis.lower() or "highest" in initial_analysis.lower():
            reasoning_result = await self.comparison_reasoning()
            answer = reasoning_result["result"]
        else:
            # Fallback: use FlexibleCustom with a simple structured plan
            answer = await self.flexible_custom(
                reasoning_pattern="sequential",
                steps=[
                    {"name": "parse_question", "instruction": "Extract key entities and what needs to be computed."},
                    {"name": "select_operator", "instruction": "Based on parsed intent, choose the right reasoning operator (counting/arithmetic/comparison)."},
                    {"name": "execute", "instruction": "Run the selected operator to get the final answer."}
                ],
                custom_instruction="Solve DROP-style problem using direct operator selection based on question semantics."
            )

        # Step 3: Optional review step to improve confidence — but only if we have a clear answer
        if isinstance(answer, (int, float)) or isinstance(answer, str) and len(answer.strip()) > 0:
            reviewed_answer = await self.review(pre_solution=str(answer))
            return reviewed_answer
        else:
            # If no valid answer, fall back to ensemble of multiple strategies
            solutions = [
                await self.custom(instruction="First try: solve the problem directly without complex structure."),
                await self.flexible_custom(
                    reasoning_pattern="parallel",
                    steps=[
                        {"name": "step1", "instruction": "Identify numbers mentioned in the passage."},
                        {"name": "step2", "instruction": "Determine which ones relate to the question."},
                        {"name": "step3", "instruction": "Apply arithmetic/counting/comparison as needed."}
                    ],
                    custom_instruction="Use parallel reasoning to explore multiple paths simultaneously."
                )
            ]
            final_answer = await self.sc_ensemble(solutions=solutions)
            return final_answer