# Workflow ID: drop_84_1
# Benchmark: drop
# Data Indices: [148, 3]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Strategy: Use FlexibleCustom to define a multi-step reasoning pattern upfront,
        # then apply it once — this changes control flow from conditionals to structured planning.
        
        # Step 1: Define a high-level reasoning plan based on question type
        reasoning_pattern = "Identify key information → Apply appropriate reasoning (count/arithmetic/comparison) → Finalize answer"
        
        # Step 2: Execute with flexible custom using predefined steps and pattern
        solution = await self.flexible_custom(
            reasoning_pattern=reasoning_pattern,
            steps=[
                {"name": "understand", "instruction": "Read the passage carefully and determine what specific information is needed to answer the question."},
                {"name": "reason", "instruction": "Based on the question type, choose the right reasoning method: counting for 'how many', arithmetic for math, comparison for ordering or ranking."},
                {"name": "answer", "instruction": "Extract or compute the final answer directly from the passage using clear, step-by-step logic."}
            ],
            custom_instruction="Execute the reasoning steps above to solve the problem."
        )

        # Step 3: Review the generated solution to improve clarity and correctness
        reviewed_solution = await self.review(pre_solution=solution)

        # Step 4: Use ScEnsemble as a final consistency check — but only after one strong pass
        final_answer = await self.sc_ensemble(solutions=[reviewed_solution])

        return final_answer