# Workflow ID: drop_11_1
# Benchmark: drop
# Data Indices: [243, 304]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """

        # Step 1: Use FlexibleCustom with a sequential reasoning pattern to break down the problem
        breakdown = await self.flexible_custom(
            reasoning_pattern="sequential",
            steps=[
                "Identify the key numerical values in the passage relevant to the question.",
                "Determine whether the required operation is arithmetic, counting, or comparison.",
                "Apply the appropriate specialized operator based on the identified task type."
            ],
            custom_instruction="Break down the problem step-by-step and execute each step using the correct operator."
        )

        # Step 2: Extract the final answer directly from the structured breakdown
        final_answer = breakdown.strip()

        # Step 3: Validate the solution by reviewing it with a meta-critique
        reviewed_answer = await self.review(pre_solution=final_answer)

        # Step 4: Return the reviewed result as the final output
        return reviewed_answer