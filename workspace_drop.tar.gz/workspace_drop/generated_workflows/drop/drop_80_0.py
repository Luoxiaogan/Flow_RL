# Workflow ID: drop_80_0
# Benchmark: drop
# Data Indices: [159, 143]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify what needs to be extracted or computed
        initial_thought = await self.custom(instruction="First, read the passage carefully and identify the key entities and numerical values relevant to the question. Determine whether this is a counting, arithmetic, or comparison task.")

        # Step 2: Generate multiple solutions using different reasoning strategies
        solution1 = await self.arithmetic_reasoning()
        solution2 = await self.custom(instruction="Use step-by-step reasoning to extract all relevant numbers from the passage and compute the required difference.")
        solution3 = await self.flexible_custom(
            reasoning_pattern="Extract the two touchdown distances mentioned in the passage, then compute their difference.",
            steps=[
                "Identify the first touchdown run distance",
                "Identify the second touchdown run distance",
                "Compute the difference between the two"
            ]
        )

        # Step 3: Use ensemble voting to select the most consistent answer
        final_answer = await self.sc_ensemble(solutions=[solution1, solution2, solution3])

        return final_answer