# Workflow ID: drop_189_1
# Benchmark: drop
# Data Indices: [101, 256]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Initial understanding — determine the nature of the question
        initial_analysis = await self.custom(instruction="Analyze the question and classify it as counting, arithmetic, or comparison-based reasoning.")

        # Step 2: Use specialized operator based on classification (this is the key difference!)
        if "count" in initial_analysis.lower() or "how many" in initial_analysis.lower():
            solution = await self.counting_reasoning()
            final_answer = solution["count"]
        elif "sum" in initial_analysis.lower() or "total" in initial_analysis.lower() or "add" in initial_analysis.lower():
            solution = await self.arithmetic_reasoning()
            final_answer = solution["result"]
        elif "compare" in initial_analysis.lower() or "shortest" in initial_analysis.lower() or "longest" in initial_analysis.lower():
            solution = await self.comparison_reasoning()
            final_answer = solution["result"]
        else:
            # Fallback: use flexible custom to handle ambiguous or complex cases
            final_answer = await self.flexible_custom(
                steps=[
                    "Extract all relevant numerical values from the passage.",
                    "Apply logical reasoning to derive the answer based on the question type."
                ],
                reasoning_pattern="chain_of_thought",
                custom_instruction="Solve the problem using structured extraction and reasoning."
            )

        # Step 3: Review the result for clarity and correctness
        reviewed_answer = await self.review(pre_solution=final_answer)

        # Step 4: Final validation via ensemble — only one additional attempt to ensure robustness
        ensemble_result = await self.sc_ensemble(solutions=[final_answer, reviewed_answer])

        return ensemble_result