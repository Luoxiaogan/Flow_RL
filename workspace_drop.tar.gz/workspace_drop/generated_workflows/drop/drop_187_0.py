# Workflow ID: drop_187_0
# Benchmark: drop
# Data Indices: [335, 271]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify required reasoning type
        initial_thought = await self.custom(instruction="Analyze the question to determine whether it requires counting, arithmetic, comparison, or text span extraction.")

        # Step 2: Use FlexibleCustom with a sequential reasoning pattern to break down the problem step-by-step
        reasoning_steps = [
            "Identify all relevant entities mentioned in the passage related to the question.",
            "Extract numerical values or spans that pertain to the query (e.g., yardage, counts, team names).",
            "Apply the appropriate reasoning type: arithmetic for sums/differences, counting for totals, comparison for ordering/selection."
        ]
        structured_analysis = await self.flexible_custom(
            reasoning_pattern="sequential",
            steps=reasoning_steps,
            custom_instruction="Based on the initial thought, now perform detailed analysis of the passage using the steps above."
        )

        # Step 3: Determine which specialized operator fits best based on the question's nature
        # For example, if it asks about total yards → ArithmeticReasoning
        # If it asks how many touchdowns → CountingReasoning
        # If it asks which team scored more → ComparisonReasoning
        # We'll let the flexible custom guide us dynamically
        final_reasoning_step = await self.flexible_custom(
            reasoning_pattern="parallel",
            steps=[
                "Check if the question involves summing up numbers — use ArithmeticReasoning.",
                "Check if the question asks for a count — use CountingReasoning.",
                "Check if the question compares teams, items, or events — use ComparisonReasoning.",
                "If none apply, fall back to Custom for general reasoning."
            ],
            custom_instruction="Now choose the correct reasoning path based on the structured analysis and execute it."
        )

        # Step 4: Execute the selected reasoning path
        if "arithmetic" in final_reasoning_step.lower():
            result = await self.arithmetic_reasoning()
            return result['result']
        elif "counting" in final_reasoning_step.lower():
            result = await self.counting_reasoning()
            return result['count']
        elif "comparison" in final_reasoning_step.lower():
            result = await self.comparison_reasoning()
            return result['result']
        else:
            # Fallback to general custom reasoning if no clear pattern
            final_answer = await self.custom(instruction=f"Use step-by-step reasoning to solve the problem based on this analysis: {structured_analysis}")
            return final_answer