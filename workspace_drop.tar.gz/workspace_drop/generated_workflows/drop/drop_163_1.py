# Workflow ID: drop_163_1
# Benchmark: drop
# Data Indices: [41, 381]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to define a structured multi-step reasoning plan
        # This avoids relying solely on CountingReasoning and instead uses custom instruction-based logic
        reasoning_plan = await self.flexible_custom(
            reasoning_pattern="step-by-step",
            steps=[
                "Identify all relevant entities mentioned in the passage that match the question's criteria.",
                "List these entities explicitly, ensuring no duplicates or omissions.",
                "Count the total number of such entities."
            ],
            custom_instruction="Based on the passage, extract and count only the items that directly answer the question. Do not guess or infer beyond what is stated."
        )

        # Step 2: Review the structured plan to ensure clarity and correctness
        reviewed_plan = await self.review(pre_solution=reasoning_plan)

        # Step 3: Execute the refined plan using the specialized counting expert
        final_count = await self.counting_reasoning()

        # Step 4: Use ensemble voting to improve robustness — now we have two solutions:
        # one from our structured plan (reviewed_plan), and one from direct counting
        solutions = [reviewed_plan, final_count]
        final_answer = await self.sc_ensemble(solutions=solutions)

        return final_answer