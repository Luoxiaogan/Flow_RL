# Workflow ID: drop_66_1
# Benchmark: drop
# Data Indices: [8, 156]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Extract key information from the passage using Custom
        extraction = await self.custom(instruction="Identify all numerical values and events in the passage relevant to the question. List them clearly with their context.")
        
        # Step 2: Use FlexibleCustom to structure a multi-step reasoning plan based on extraction
        reasoning_plan = await self.flexible_custom(
            reasoning_pattern="step-by-step",
            steps=[
                "Parse the extracted information to determine what needs to be counted, added, subtracted, or compared.",
                "Determine whether the question requires arithmetic (e.g., difference), counting, or comparison.",
                "Execute the appropriate operation using the specialized reasoning tools."
            ],
            custom_instruction=f"Based on this extraction: {extraction}, solve the problem by following the structured plan above."
        )

        # Step 3: Evaluate multiple possible interpretations using ScEnsemble
        # Generate two alternative solutions via different reasoning paths
        solution_a = await self.custom(instruction="First, interpret the question as an arithmetic task and solve it directly.")
        solution_b = await self.custom(instruction="Now, interpret the question as a counting task and solve it directly.")

        # Use ScEnsemble to choose the most consistent answer across both approaches
        final_answer = await self.sc_ensemble(solutions=[reasoning_plan, solution_a, solution_b])

        return final_answer