# Workflow ID: drop_190_1
# Benchmark: drop
# Data Indices: [376, 258]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom with a parallel reasoning pattern to explore multiple strategies simultaneously
        reasoning_pattern = "parallel"
        steps = [
            "Identify key facts relevant to the question.",
            "Apply counting reasoning if the task involves enumerating items.",
            "Apply arithmetic reasoning if the task involves numerical operations.",
            "Apply comparison reasoning if the task involves ranking or selecting from options.",
            "Use custom reasoning to extract spans or interpret ambiguous parts."
        ]
        custom_instruction = "Solve the problem using all possible reasoning types in parallel: " + "; ".join(steps)

        parallel_solutions = await self.flexible_custom(
            reasoning_pattern=reasoning_pattern,
            steps=steps,
            custom_instruction=custom_instruction
        )

        # Step 2: Review each solution independently to improve quality before ensemble
        reviewed_solutions = []
        for sol in parallel_solutions.split("||"):
            reviewed = await self.review(pre_solution=sol.strip())
            reviewed_solutions.append(reviewed)

        # Step 3: Use ScEnsemble to select the most consistent answer across all reviewed solutions
        final_answer = await self.sc_ensemble(solutions=reviewed_solutions)

        return final_answer