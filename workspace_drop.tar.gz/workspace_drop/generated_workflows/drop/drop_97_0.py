# Workflow ID: drop_97_0
# Benchmark: drop
# Data Indices: [366, 68]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify what needs to be extracted or reasoned about
        initial_thought = await self.custom(instruction="First, read the question carefully and determine whether it requires counting, arithmetic, comparison, or a combination. Identify the key entities or values mentioned in the passage that relate to the question.")

        # Step 2: Extract relevant information from the passage based on the question type
        extraction = await self.custom(instruction=f"Based on the initial thought: {initial_thought}, now extract all relevant numerical or categorical data from the passage that may help answer the question.")

        # Step 3: Determine the appropriate reasoning step (counting, arithmetic, comparison)
        reasoning_type = await self.custom(instruction=f"Analyze the extracted data: {extraction}. Decide whether the next step should involve counting, arithmetic, or comparison reasoning.")

        # Step 4: Apply specialized reasoning operator based on type
        if "counting" in reasoning_type.lower():
            result = await self.counting_reasoning()
        elif "arithmetic" in reasoning_type.lower():
            result = await self.arithmetic_reasoning()
        elif "comparison" in reasoning_type.lower():
            result = await self.comparison_reasoning()
        else:
            # Fallback: use custom for general reasoning
            result = await self.custom(instruction=f"Use step-by-step reasoning to solve this problem using the extracted data: {extraction}.")

        # Step 5: Finalize the answer by formatting or reviewing if needed
        final_answer = await self.custom(instruction=f"Using the reasoning result: {result}, provide a clear and concise final answer to the original question without including extra explanation.")

        return final_answer