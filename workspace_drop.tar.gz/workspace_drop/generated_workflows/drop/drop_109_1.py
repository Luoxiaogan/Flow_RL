# Workflow ID: drop_109_1
# Benchmark: drop
# Data Indices: [386, 341]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to first extract and interpret all numeric quantities in the passage
        extraction_step = await self.flexible_custom(
            steps=[
                {"task": "Identify all numbers mentioned in the passage"},
                {"task": "Classify each number by its context (e.g., touchdowns, field goals, percentages)"},
                {"task": "Build a structured summary of relevant numerical data"}
            ],
            reasoning_pattern="sequential",
            custom_instruction="Extract and categorize all numerical values from the passage."
        )

        # Step 2: Use ComparisonReasoning to compare or sort these extracted values if needed
        comparison_result = await self.comparison_reasoning()

        # Step 3: Generate two distinct solutions using different operators — one with counting, one with arithmetic
        solution_counting = await self.counting_reasoning()
        solution_arithmetic = await self.arithmetic_reasoning()

        # Step 4: Review both solutions individually before ensemble
        reviewed_counting = await self.review(pre_solution=solution_counting)
        reviewed_arithmetic = await self.review(pre_solution=solution_arithmetic)

        # Step 5: Use ScEnsemble on the two refined solutions — this ensures robustness via voting
        final_answer = await self.sc_ensemble(solutions=[reviewed_counting, reviewed_arithmetic])

        return final_answer