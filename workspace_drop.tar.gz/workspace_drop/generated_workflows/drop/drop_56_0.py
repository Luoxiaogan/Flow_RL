# Workflow ID: drop_56_0
# Benchmark: drop
# Data Indices: [30, 69]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """

        # Step 1: Use flexible custom to define a multi-step reasoning pattern
        # Strategy: First extract relevant facts, then perform arithmetic or counting
        step1_instruction = "Identify all numerical data and key entities in the passage that relate to the question."
        step2_instruction = "Determine what arithmetic operation (addition, subtraction, comparison) is needed based on the question."
        
        # Run flexible custom with structured steps
        reasoning_plan = await self.flexible_custom(
            reasoning_pattern="Extract → Reason → Resolve",
            steps=[
                {"name": "extract", "instruction": step1_instruction},
                {"name": "reason", "instruction": step2_instruction},
                {"name": "resolve", "instruction": "Now compute the final answer using the extracted information."}
            ],
            custom_instruction="Solve the DROP-style problem by following the three-step plan: extract, reason, resolve."
        )

        # Step 2: Generate multiple solutions via different strategies
        solution1 = await self.custom(instruction="Use direct extraction and arithmetic reasoning to solve.")
        solution2 = await self.arithmetic_reasoning()
        solution3 = await self.counting_reasoning()

        # Step 3: Use ScEnsemble to vote on the most consistent answer
        ensemble_result = await self.sc_ensemble(solutions=[solution1, solution2, solution3])

        # Step 4: Optionally review the final result for clarity and correctness
        final_answer = await self.review(pre_solution=ensemble_result)

        return final_answer