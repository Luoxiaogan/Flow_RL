# Workflow ID: drop_17_1
# Benchmark: drop
# Data Indices: [298, 83]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use flexible custom to define a multi-step reasoning plan based on the question type
        reasoning_plan = await self.flexible_custom(
            reasoning_pattern="classify_and_execute",
            steps=[
                "Identify whether the task requires counting, arithmetic, comparison, or span extraction.",
                "If it's counting, call counting_reasoning.",
                "If it's arithmetic, call arithmetic_reasoning.",
                "If it's comparison, call comparison_reasoning.",
                "Otherwise, extract the answer directly using custom with precise instruction."
            ],
            custom_instruction="Analyze the question and generate a structured plan to solve it step-by-step."
        )

        # Step 2: Execute the plan in parallel — simulate branching logic by calling all relevant operators once
        count_result = self.counting_reasoning() if "count" in reasoning_plan.lower() else None
        arithmetic_result = self.arithmetic_reasoning() if "arithmetic" in reasoning_plan.lower() else None
        comparison_result = self.comparison_reasoning() if "compare" in reasoning_plan.lower() else None
        span_answer = self.custom(instruction="Extract the exact answer from the passage based on the question. Do not paraphrase — return the original text that directly answers the question.") if not any(k in reasoning_plan.lower() for k in ["count", "arithmetic", "compare"]) else None

        # Step 3: Collect results into a list for ensemble voting
        solutions = []
        if count_result:
            solutions.append(count_result['count'])
        if arithmetic_result:
            solutions.append(arithmetic_result['result'])
        if comparison_result:
            solutions.append(comparison_result['result'])
        if span_answer:
            solutions.append(span_answer)

        # Step 4: Use ScEnsemble to resolve discrepancies between outputs (e.g., if multiple valid interpretations exist)
        final_solution = await self.sc_ensemble(solutions=solutions)

        # Step 5: Review the final solution to ensure clarity and correctness before returning
        reviewed_solution = await self.review(pre_solution=final_solution)
        
        return reviewed_solution