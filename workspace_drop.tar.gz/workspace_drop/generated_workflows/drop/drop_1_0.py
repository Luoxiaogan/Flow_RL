# Workflow ID: drop_1_0
# Benchmark: drop
# Data Indices: [158, 303]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question type — determine whether it's arithmetic, counting, or comparison
        initial_thought = await self.custom(instruction="Analyze the question to identify if it requires arithmetic reasoning, counting, or comparison.")
        
        # Step 2: Based on the question type, choose the appropriate specialized operator
        if "how many more" in initial_thought.lower() or "difference" in initial_thought.lower():
            # Arithmetic reasoning needed (e.g., difference between passing and running yards)
            arith_result = await self.arithmetic_reasoning()
            return arith_result["result"]
        
        elif "count" in initial_thought.lower() or "how many" in initial_thought.lower():
            # Counting reasoning needed (e.g., number of touchdowns by a player)
            count_result = await self.counting_reasoning()
            return count_result["count"]
        
        elif "which player" in initial_thought.lower() or "who scored" in initial_thought.lower():
            # Comparison reasoning needed (e.g., who scored in both halves)
            comp_result = await self.comparison_reasoning()
            return comp_result["result"]
        
        else:
            # Fallback: Use flexible custom to guide step-by-step thinking
            final_answer = await self.flexible_custom(
                reasoning_pattern="step_by_step",
                steps=[
                    "Break down the problem into clear subtasks.",
                    "Identify relevant facts from the passage.",
                    "Apply the correct reasoning type (arithmetic, counting, or comparison).",
                    "Generate a final answer based on structured analysis."
                ],
                custom_instruction="Solve the problem using step-by-step reasoning."
            )
            return final_answer