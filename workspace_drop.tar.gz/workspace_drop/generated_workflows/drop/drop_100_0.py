# Workflow ID: drop_100_0
# Benchmark: drop
# Data Indices: [132, 78]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use Custom to break down the problem and identify the main task
        initial_thought = await self.custom(instruction="First, analyze the question type: Is it counting, arithmetic, comparison, or span extraction? Identify key entities in the passage relevant to the question.")

        # Step 2: Based on the question type, choose an appropriate reasoning path
        if "how many" in self.problem_text.lower() or "count" in self.problem_text.lower():
            count_result = await self.counting_reasoning()
            final_answer = count_result
        elif "sum", "difference", "total", "more than", "less than" in self.problem_text.lower():
            arith_result = await self.arithmetic_reasoning()
            final_answer = arith_result
        elif "which came first", "earlier", "first", "later", "compare" in self.problem_text.lower():
            comp_result = await self.comparison_reasoning()
            final_answer = comp_result
        else:
            # For span-based questions or when no clear pattern exists
            answer = await self.custom(instruction="Extract the exact answer as a text span from the passage based on the question.")
            final_answer = answer

        # Step 3: Review the solution for clarity, correctness, and completeness
        reviewed_answer = await self.review(pre_solution=final_answer)

        # Step 4: Use ensemble to improve robustness by running the same logic again
        # (This simulates multi-step thinking and consistency checking)
        second_attempt = await self.custom(instruction="Re-solve the problem using the same approach as before, but with fresh attention to detail.")
        ensemble_results = [reviewed_answer, second_attempt]
        final_result = await self.sc_ensemble(solutions=ensemble_results)

        return final_result