# Workflow ID: drop_98_1
# Benchmark: drop
# Data Indices: [76, 313]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to define a structured reasoning path based on question type
        reasoning_pattern = "Identify key elements in passage → Apply domain-specific reasoning → Output final answer"
        steps = [
            {"name": "extract", "instruction": "Extract all relevant events, scores, and timelines from the passage."},
            {"name": "reason", "instruction": "Determine whether the task requires counting, arithmetic, or comparison reasoning."},
            {"name": "solve", "instruction": "Apply the correct specialized operator based on the identified reasoning type."}
        ]
        plan = await self.flexible_custom(
            reasoning_pattern=reasoning_pattern,
            steps=steps,
            custom_instruction="Generate a step-by-step solution using the defined logic."
        )

        # Step 2: Based on the plan, extract high-level intent and choose appropriate reasoning path
        if "count" in plan.lower() or "how many" in self.problem.lower():
            result = await self.counting_reasoning()
        elif "difference" in plan.lower() or "sum" in plan.lower() or "total" in plan.lower():
            result = await self.arithmetic_reasoning()
        elif "which team" in plan.lower() or "last score" in plan.lower() or "earliest" in plan.lower():
            result = await self.comparison_reasoning()
        else:
            result = await self.custom(instruction="Solve the problem directly using the extracted information.")

        # Step 3: Instead of reviewing first, apply ensemble immediately — prioritize robustness over refinement
        # This changes the order: Ensemble before Review (vs. Review before Ensemble in original)
        final_answer = await self.sc_ensemble(solutions=[result])

        # Step 4: Only after ensemble, do a final review to polish clarity and correctness
        reviewed_solution = await self.review(pre_solution=final_answer)

        return reviewed_solution