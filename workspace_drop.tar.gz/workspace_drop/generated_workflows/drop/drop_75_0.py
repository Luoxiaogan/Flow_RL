# Workflow ID: drop_75_0
# Benchmark: drop
# Data Indices: [202, 373]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify required reasoning type
        initial_thought = await self.custom(instruction="Analyze the question to determine whether it requires counting, arithmetic, comparison, or a combination of these. Identify key entities and quantities mentioned in the passage relevant to the question.")

        # Step 2: Use FlexibleCustom to apply a structured reasoning pattern based on the problem type
        reasoning_pattern = "sequential"  # Can also be "parallel" depending on complexity
        steps = [
            {"name": "extract", "instruction": "Extract all numerical values and related context (e.g., distances, scores, counts) from the passage that may be relevant to answering the question."},
            {"name": "reason", "instruction": "Apply appropriate reasoning (arithmetic, counting, or comparison) using specialized operators based on the extracted data."}
        ]
        intermediate_solution = await self.flexible_custom(
            reasoning_pattern=reasoning_pattern,
            steps=steps,
            custom_instruction=f"Based on the initial thought: {initial_thought}, now execute the multi-step plan to solve the DROP-style problem."
        )

        # Step 3: If needed, refine the solution using Review for quality assurance
        refined_solution = await self.review(pre_solution=intermediate_solution)

        # Step 4: Final check using ScEnsemble to improve robustness by comparing multiple solutions (if applicable)
        # Since we're building a generic template, we simulate an ensemble with one solution + potential variants
        ensemble_input = [refined_solution]
        final_answer = await self.sc_ensemble(solutions=ensemble_input)

        return final_answer