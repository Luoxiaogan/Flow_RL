# Workflow ID: drop_160_1
# Benchmark: drop
# Data Indices: [122, 360]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom with a parallel reasoning pattern to explore multiple strategies simultaneously
        reasoning_pattern = "parallel"
        steps = [
            {"name": "count_strategy", "instruction": "Apply counting reasoning to identify how many items match the criteria in the question."},
            {"name": "arithmetic_strategy", "instruction": "Apply arithmetic reasoning to compute sums, differences, or other numerical operations based on extracted values."},
            {"name": "comparison_strategy", "instruction": "Apply comparison reasoning to sort or rank entities relevant to the question."}
        ]
        
        # Generate multiple solutions in parallel — this is fundamentally different from the existing sequential approach
        parallel_solutions = await self.flexible_custom(
            reasoning_pattern=reasoning_pattern,
            steps=steps,
            custom_instruction="Explore all three major reasoning types (counting, arithmetic, comparison) in parallel to generate diverse candidate answers."
        )

        # Step 2: Use ScEnsemble to evaluate and select the most consistent answer across all parallel strategies
        # This is a different ensemble strategy: instead of generating one solution then reviewing it, we now start with multiple hypotheses
        final_answer = await self.sc_ensemble(solutions=[parallel_solutions])

        # Step 3: Review the final ensemble result to improve clarity and correctness
        reviewed_final = await self.review(pre_solution=final_answer)

        return reviewed_final