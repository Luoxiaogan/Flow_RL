# Workflow ID: drop_175_1
# Benchmark: drop
# Data Indices: [180, 84]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Strategy: Use FlexibleCustom to define a multi-step reasoning pattern that explores different approaches in parallel
        # Then apply ensemble voting to select the most consistent answer — this ensures robustness without relying on early classification.

        # Step 1: Define a flexible workflow with multiple distinct strategies
        steps = [
            {
                "task": "Identify key entities and numerical values relevant to the question.",
                "reasoning_pattern": "Extract all numbers and named items from the passage that might be involved in the final calculation or comparison."
            },
            {
                "task": "Use arithmetic reasoning to compute differences between specified values (e.g., most expensive item vs. sum of two others).",
                "reasoning_pattern": "Apply arithmetic reasoning to calculate the difference between the highest value and the combined total of two other values."
            },
            {
                "task": "Use comparison reasoning to determine who lost the civil war based on historical outcomes described.",
                "reasoning_pattern": "Compare the outcomes of the opposing sides using evidence from the passage to identify the loser."
            },
            {
                "task": "Use counting reasoning to enumerate specific items mentioned in the passage if the question involves quantity.",
                "reasoning_pattern": "Count instances of a particular category (e.g., rings, caps, wars) as required by the question."
            }
        ]

        # Run the same flexible custom logic but with different instructions per step — simulating parallel exploration
        solution1 = await self.flexible_custom(
            steps=steps[:2],  # First two steps: extract + arithmetic
            reasoning_pattern="multi-step extraction and computation"
        )

        solution2 = await self.flexible_custom(
            steps=steps[2:],  # Next two steps: comparison + counting
            reasoning_pattern="multi-step comparison and enumeration"
        )

        # Step 2: Generate an additional solution via direct custom instruction — introduces variation
        solution3 = await self.custom(instruction="Solve the problem directly by thinking step-by-step and justifying each step clearly.")

        # Step 3: Use ScEnsemble to evaluate all three solutions and return the most consistent one
        ensemble_result = await self.sc_ensemble(solutions=[solution1, solution2, solution3])

        return ensemble_result