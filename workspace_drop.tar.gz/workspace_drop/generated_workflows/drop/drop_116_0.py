# Workflow ID: drop_116_0
# Benchmark: drop
# Data Indices: [140, 54]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question type and identify required reasoning
        initial_thought = await self.custom(instruction="Analyze the question to determine whether it requires counting, arithmetic, comparison, or span extraction.")

        # Step 2: Use FlexibleCustom to define a structured reasoning plan based on question type
        reasoning_pattern = "sequential"  # General strategy for step-by-step breakdown
        steps = [
            {"name": "identify_relevant_info", "instruction": "Extract all relevant information from the passage that pertains to the question."},
            {"name": "determine_reasoning_type", "instruction": "Based on the extracted info, decide if the task involves counting, arithmetic, comparison, or text span selection."},
            {"name": "apply_specialized_operator", "instruction": "Use the appropriate specialized operator (counting, arithmetic, comparison) or custom reasoning as needed."}
        ]
        structured_solution = await self.flexible_custom(
            reasoning_pattern=reasoning_pattern,
            steps=steps,
            custom_instruction="Follow the steps to solve the problem systematically."
        )

        # Step 3: If solution seems incomplete or ambiguous, apply review
        reviewed_solution = await self.review(pre_solution=structured_solution)

        # Step 4: If multiple solutions exist (e.g., from ensemble), select most consistent one
        # For now, just return the reviewed solution; in future, we could call sc_ensemble with alternatives
        final_answer = reviewed_solution

        return final_answer