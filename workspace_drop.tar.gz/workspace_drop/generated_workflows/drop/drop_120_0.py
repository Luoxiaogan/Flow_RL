# Workflow ID: drop_120_0
# Benchmark: drop
# Data Indices: [347, 168]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Initial breakdown of the problem
        initial_thought = await self.custom(instruction="First, identify what needs to be counted or calculated based on the question. Focus on key phrases like 'field goals', 'missed', 'attempted', etc.")

        # Step 2: Generate multiple reasoning paths using different strategies
        solution1 = await self.custom(instruction="Strategy 1: Extract all field goal mentions from the passage and count those explicitly labeled as made or missed.")
        solution2 = await self.custom(instruction="Strategy 2: Use a counting expert to identify and count all instances of field goals mentioned in the text, then filter by whether they were successful or not.")
        solution3 = await self.custom(instruction="Strategy 3: Identify relevant sentences containing field goal events, then determine which ones were attempted but missed.")

        # Step 3: Use ensemble voting to select the most consistent answer
        final_answer = await self.sc_ensemble(solutions=[solution1, solution2, solution3])

        return final_answer