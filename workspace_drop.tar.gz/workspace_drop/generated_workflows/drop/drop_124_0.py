# Workflow ID: drop_124_0
# Benchmark: drop
# Data Indices: [272, 79]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify what needs to be computed
        initial_thought = await self.custom(instruction="Understand the question: Identify the target percentage and the relevant data in the passage.")
        
        # Step 2: Extract the relevant percentage (e.g., "2.85% from two or more races")
        extraction_step = await self.custom(instruction="Extract the percentage value mentioned in the passage that corresponds to the group in question.")
        
        # Step 3: Use ArithmeticReasoning to compute the complement (100% - extracted value)
        arithmetic_result = await self.arithmetic_reasoning()
        
        # Step 4: Generate an alternative solution using a different reasoning path — e.g., rephrase the question as "what percent was not Pacific Islander"
        alt_solution = await self.custom(instruction="Rephrase the question as: 'What percent of people were not from the specified group?' and solve directly using the passage.")
        
        # Step 5: Use Ensemble Voting to select the most consistent answer across multiple approaches
        solutions = [arithmetic_result, alt_solution]
        final_answer = await self.sc_ensemble(solutions=solutions)
        
        return final_answer