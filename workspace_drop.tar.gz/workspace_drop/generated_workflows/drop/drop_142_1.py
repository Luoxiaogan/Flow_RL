# Workflow ID: drop_142_1
# Benchmark: drop
# Data Indices: [362, 185]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Strategy: Use FlexibleCustom to define a multi-step reasoning plan that
        # first identifies the task type, then selects and executes the appropriate operator
        # in a single logical flow — avoiding sequential conditionals entirely.

        reasoning_plan = [
            {
                "step": "Identify the type of reasoning required (counting, arithmetic, comparison)",
                "instruction": "Determine whether the question involves counting items, performing arithmetic, or comparing values. Return only one word: 'counting', 'arithmetic', or 'comparison'."
            },
            {
                "step": "Execute the selected reasoning operator based on the identified type",
                "instruction": "Based on the reasoning type determined above, execute the correct operator: CountingReasoning for counting, ArithmeticReasoning for math, ComparisonReasoning for sorting or comparisons."
            }
        ]

        result = await self.flexible_custom(
            steps=reasoning_plan,
            reasoning_pattern="Sequential Reasoning",
            custom_instruction="Solve the DROP benchmark problem by first identifying the reasoning type and then executing the corresponding specialized operator."
        )

        # Final review to refine output clarity and correctness
        final_answer = await self.review(pre_solution=result)

        return final_answer