# Workflow ID: drop_21_1
# Benchmark: drop
# Data Indices: [59, 297]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to generate a structured multi-step plan based on question type
        plan = await self.flexible_custom(
            steps=[
                {"instruction": "Identify the key question and what kind of reasoning it requires (counting, arithmetic, comparison)."},
                {"instruction": "Extract all relevant numerical or categorical data from the passage that relates to the question."},
                {"instruction": "Define a precise sequence of operations needed to derive the final answer."}
            ],
            reasoning_pattern="chain_of_thought",
            custom_instruction="Generate a step-by-step solution plan using the extracted information."
        )

        # Step 2: Run multiple independent attempts with different reasoning experts
        attempts = []
        if "count" in self.problem.lower() or "how many" in self.problem.lower():
            attempts.append(await self.counting_reasoning())
        elif "sum" in self.problem.lower() or "difference" in self.problem.lower() or "total" in self.problem.lower():
            attempts.append(await self.arithmetic_reasoning())
        elif "compare" in self.problem.lower() or "which is more" in self.problem.lower() or "highest" in self.problem.lower() or "lowest" in self.problem.lower():
            attempts.append(await self.comparison_reasoning())
        else:
            attempts.append(await self.flexible_custom(
                steps=[
                    {"instruction": "Break down the question into smaller subtasks."},
                    {"instruction": "Solve each subtask individually using appropriate reasoning."},
                    {"instruction": "Combine results logically to form the final answer."}
                ],
                reasoning_pattern="chain_of_thought",
                custom_instruction="Solve the problem using a structured multi-step approach."
            ))

        # Step 3: Use ScEnsemble to select the most consistent answer across attempts
        ensemble_result = await self.sc_ensemble(solutions=attempts)

        # Step 4: Final review to ensure clarity and correctness — this is the critical difference!
        final_answer = await self.review(pre_solution=ensemble_result)

        return final_answer