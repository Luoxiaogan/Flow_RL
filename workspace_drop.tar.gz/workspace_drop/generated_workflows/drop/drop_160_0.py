# Workflow ID: drop_160_0
# Benchmark: drop
# Data Indices: [122, 360]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify what needs to be extracted or reasoned
        initial_thought = await self.custom(instruction="First, read the passage carefully and determine what specific information is needed to answer the question. Identify key entities, numbers, and relationships.")
        
        # Step 2: Use FlexibleCustom to structure a multi-step reasoning plan
        # This allows us to break down complex problems into logical steps without hardcoding
        reasoning_pattern = "sequential"
        steps = [
            {"name": "extract_entities", "instruction": "Identify all relevant entities (people, places, numbers) mentioned in the passage that relate to the question."},
            {"name": "isolate_context", "instruction": "From the extracted entities, isolate the context directly related to the question being asked."},
            {"name": "reason", "instruction": "Apply appropriate reasoning type (counting, arithmetic, comparison) based on the nature of the question."}
        ]
        
        structured_reasoning = await self.flexible_custom(
            reasoning_pattern=reasoning_pattern,
            steps=steps,
            custom_instruction="Use this step-by-step approach to solve the problem logically."
        )
        
        # Step 3: Determine the type of reasoning required
        reasoning_type = await self.custom(instruction="Based on the isolated context, decide whether the task requires counting, arithmetic, or comparison reasoning.")
        
        # Step 4: Execute the appropriate specialized operator
        if "count" in reasoning_type.lower():
            result = await self.counting_reasoning()
        elif "arithmetic" in reasoning_type.lower():
            result = await self.arithmetic_reasoning()
        elif "compare" in reasoning_type.lower() or "sort" in reasoning_type.lower():
            result = await self.comparison_reasoning()
        else:
            # Fallback: use general custom reasoning if no clear pattern
            result = await self.custom(instruction="Now, synthesize the information and provide the final answer based on all prior steps.")
        
        # Step 5: Review the solution for correctness and clarity
        reviewed_solution = await self.review(pre_solution=result)
        
        # Step 6: Ensemble to improve robustness by combining multiple solutions if possible
        # For now, we only have one solution; later, we could generate more via different strategies
        final_answer = await self.sc_ensemble(solutions=[reviewed_solution])
        
        return final_answer