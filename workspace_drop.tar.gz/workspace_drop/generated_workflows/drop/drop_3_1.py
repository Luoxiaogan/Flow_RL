# Workflow ID: drop_3_1
# Benchmark: drop
# Data Indices: [205, 9]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom with a parallel reasoning pattern to explore multiple solution paths
        reasoning_pattern = "Parallel exploration: generate two distinct strategies (e.g., direct extraction vs structured breakdown), then resolve conflict via comparison"
        steps = [
            {"name": "strategy_a", "instruction": "Solve the problem using a direct, step-by-step approach focused on extracting and applying relevant facts."},
            {"name": "strategy_b", "instruction": "Solve the problem by first identifying all entities and events, then determining which ones are relevant to the question through filtering."}
        ]
        solution_a = await self.flexible_custom(
            reasoning_pattern=reasoning_pattern,
            steps=steps,
            custom_instruction="Generate two alternative solutions in parallel based on different logical structures."
        )

        # Step 2: Use ComparisonReasoning to evaluate both solutions and determine the most consistent one
        comparison_result = await self.comparison_reasoning()
        
        # Step 3: Select the best solution based on comparison outcome — this is a key difference from existing workflow
        final_answer = comparison_result  # The result already contains the best answer or a resolved consensus

        return final_answer