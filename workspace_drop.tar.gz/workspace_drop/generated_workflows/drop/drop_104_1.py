# Workflow ID: drop_104_1
# Benchmark: drop
# Data Indices: [277, 295]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom with a parallel reasoning pattern to generate multiple candidate solutions
        steps = [
            {"name": "extract_field_goals", "instruction": "Identify all field goals made by each kicker in the passage."},
            {"name": "count_kickers", "instruction": "Count how many field goals each kicker made."}
        ]
        reasoning_pattern = "parallel"
        parallel_solution = await self.flexible_custom(
            steps=steps,
            reasoning_pattern=reasoning_pattern,
            custom_instruction="Generate two distinct interpretations of the field goal counts based on different reading strategies."
        )

        # Step 2: Use ScEnsemble to evaluate both generated solutions and select the most consistent one
        ensemble_result = await self.sc_ensemble(solutions=[parallel_solution])

        # Step 3: Use Review to refine the selected solution if needed
        refined_solution = await self.review(pre_solution=ensemble_result)

        # Step 4: Final answer extraction using Custom with a targeted instruction
        final_answer = await self.custom(instruction=f"Based on the refined solution: {refined_solution}, output only the final numerical answer that directly answers the question.")

        return final_answer