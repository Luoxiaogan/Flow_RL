# Workflow ID: drop_5_1
# Benchmark: drop
# Data Indices: [2, 63]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Strategy: Use FlexibleCustom to define a multi-step reasoning pattern
        # that first identifies the task type and then delegates to the correct specialized operator.
        # This avoids branching logic and instead uses structured prompt-based routing.

        steps = [
            {
                "task": "Identify the type of reasoning required",
                "instruction": "Based on the question, determine whether it requires counting, arithmetic, comparison, or span extraction."
            },
            {
                "task": "Apply appropriate reasoning expert",
                "instruction": "Use the identified reasoning type to select the correct operator. If it's counting, use CountingReasoning; if arithmetic, use ArithmeticReasoning; if comparison, use ComparisonReasoning; otherwise, treat as span extraction."
            },
            {
                "task": "Finalize answer",
                "instruction": "Extract the final answer clearly and concisely based on the previous step."
            }
        ]

        reasoning_pattern = "chain_of_thought"
        
        result = await self.flexible_custom(
            steps=steps,
            reasoning_pattern=reasoning_pattern,
            custom_instruction="Solve the DROP-style question using a structured, step-by-step reasoning plan."
        )

        return result