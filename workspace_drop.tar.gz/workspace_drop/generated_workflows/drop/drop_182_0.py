# Workflow ID: drop_182_0
# Benchmark: drop
# Data Indices: [144, 223]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify what type of reasoning is needed
        initial_thought = await self.custom(instruction="First, determine whether the question requires counting, arithmetic, comparison, or information extraction. Identify key entities and numerical values in the passage relevant to the question.")
        
        # Step 2: Use FlexibleCustom with a sequential reasoning pattern to guide step-by-step processing
        solution_plan = await self.flexible_custom(
            reasoning_pattern="sequential",
            steps=[
                "Extract all relevant facts from the passage that relate to the question.",
                "Determine the specific task (e.g., count occurrences, compute a difference, find a maximum/minimum).",
                "Apply the appropriate specialized operator based on the task type."
            ],
            custom_instruction="Based on the initial thought: {initial_thought}, now execute the plan step-by-step."
        )

        # Step 3: Based on the nature of the question, invoke the correct expert operator
        # This is where we detect the type of reasoning required — e.g., arithmetic for distances, counting for events, etc.
        detection = await self.custom(instruction="Analyze the question again: Is it asking for a number, a span of text, or a ranked item? What kind of reasoning does it require?")
        
        if "how many" in detection.lower() or "count" in detection.lower():
            result = await self.counting_reasoning()
        elif "sum", "difference", "total", "more than", "less than" in detection.lower():
            result = await self.arithmetic_reasoning()
        elif "who", "which", "what", "when" in detection.lower() and "most" not in detection.lower():
            result = await self.custom(instruction="Extract the answer directly from the passage using precise language matching the question.")
        elif "most", "least", "highest", "lowest", "order" in detection.lower():
            result = await self.comparison_reasoning()
        else:
            result = await self.custom(instruction="If none of the above apply, perform general reasoning to extract the exact answer from the passage.")

        # Step 4: Review the solution for clarity and correctness
        reviewed_solution = await self.review(pre_solution=result)

        # Step 5: If multiple solutions exist (e.g., via ensemble), select the most consistent one
        final_answer = await self.sc_ensemble(solutions=[reviewed_solution])

        return final_answer