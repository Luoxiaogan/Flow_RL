# Workflow ID: drop_180_0
# Benchmark: drop
# Data Indices: [369, 85]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify required reasoning type
        initial_thought = await self.custom(instruction="First, analyze the question to determine whether it requires counting, arithmetic, or comparison reasoning. Identify key entities and events in the passage relevant to the query.")
        
        # Step 2: Use FlexibleCustom to structure a multi-step plan based on reasoning pattern
        reasoning_plan = await self.flexible_custom(
            reasoning_pattern="sequential",
            steps=[
                "Extract all relevant information from the passage that relates to the question.",
                "Determine the specific task (e.g., count occurrences, compute difference, compare values).",
                "Apply the appropriate specialized operator (counting, arithmetic, or comparison).",
                "Verify the result using review if necessary."
            ],
            custom_instruction="Based on the initial thought: {initial_thought}, now execute the structured plan step-by-step."
        )
        
        # Step 3: Determine which specialized operator to use based on the nature of the question
        # This is a strategic template — we don't hardcode answers but infer the need dynamically
        analysis = await self.custom(instruction="Analyze the question again and decide if it's primarily about counting, comparing, or computing an arithmetic value.")
        
        if "count" in analysis.lower() or "how many" in analysis.lower():
            result = await self.counting_reasoning()
        elif "difference" in analysis.lower() or "how much" in analysis.lower() or "more than" in analysis.lower():
            result = await self.arithmetic_reasoning()
        elif "which" in analysis.lower() or "greater" in analysis.lower() or "lesser" in analysis.lower() or "order" in analysis.lower():
            result = await self.comparison_reasoning()
        else:
            # Fallback to general reasoning if classification fails
            result = await self.custom(instruction="Use general reasoning to solve the problem since no clear category was identified.")

        # Step 4: Review the solution for correctness and clarity
        reviewed_result = await self.review(pre_solution=result)

        # Step 5: If multiple solutions were generated during flexible_custom, use ensemble voting
        # Note: In this single-threaded case, sc_ensemble may not be needed unless explicitly called
        final_answer = reviewed_result

        return final_answer