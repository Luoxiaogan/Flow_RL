# Workflow ID: drop_168_1
# Benchmark: drop
# Data Indices: [193, 285]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Strategy: Use parallel reasoning paths with FlexibleCustom to explore multiple approaches
        # Then, apply ensemble voting to select the most consistent answer — this differs from the original's sequential routing.
        
        # Step 1: Generate multiple independent solutions using different reasoning strategies
        solution1 = await self.flexible_custom(
            steps=[
                {"name": "extract", "instruction": "Identify key entities and events in the passage relevant to the question."},
                {"name": "reason", "instruction": "Apply logical deduction based on extracted facts to solve the problem."},
                {"name": "answer", "instruction": "Output a concise final answer."}
            ],
            reasoning_pattern="chain_of_thought",
            custom_instruction="Solve the problem step-by-step using structured reasoning."
        )

        solution2 = await self.flexible_custom(
            steps=[
                {"name": "analyze", "instruction": "Determine whether the question requires counting, arithmetic, or comparison."},
                {"name": "apply", "instruction": "Use the appropriate expert (counting, arithmetic, comparison) based on analysis."},
                {"name": "output", "instruction": "Provide the final result as a number or span of text."}
            ],
            reasoning_pattern="sequential",
            custom_instruction="First analyze the question type, then apply specialized reasoning."
        )

        solution3 = await self.custom(instruction="Generate a direct, focused answer by synthesizing all relevant information from the passage.")

        # Step 2: Apply ensemble voting across the three diverse solutions
        final_answer = await self.sc_ensemble(solutions=[solution1, solution2, solution3])
        
        return final_answer