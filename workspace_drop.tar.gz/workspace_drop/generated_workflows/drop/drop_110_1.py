# Workflow ID: drop_110_1
# Benchmark: drop
# Data Indices: [160, 357]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # --- STRATEGIC TEMPLATE FOR DROP-BENCHMARK PROBLEMS ---
        # NEW LOGIC: Use parallel reasoning paths with different strategies, then vote via sc_ensemble
        # This avoids relying on a single branching condition (like 'if "count" in ...') which is fragile.

        # Step 1: Generate multiple solutions using different reasoning patterns
        solution1 = await self.custom(instruction="First, identify all numerical facts in the passage and extract them directly. Then, answer the question based solely on those facts.")
        solution2 = await self.counting_reasoning()  # If counting is involved, this will catch it
        solution3 = await self.arithmetic_reasoning()  # If arithmetic is needed, this will resolve it
        solution4 = await self.comparison_reasoning()  # If comparison is required, this will solve it

        # Step 2: Combine all candidate answers into an ensemble
        # Note: Even if some solutions aren't relevant (e.g., counting when not needed), they may still help surface correct logic
        final_answer = await self.sc_ensemble(solutions=[solution1, str(solution2), str(solution3), str(solution4)])

        # Step 3: Optional refinement — review the final ensemble result for clarity or consistency
        refined_answer = await self.review(pre_solution=final_answer)

        return refined_answer