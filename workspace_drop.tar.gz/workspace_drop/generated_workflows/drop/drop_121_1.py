# Workflow ID: drop_121_1
# Benchmark: drop
# Data Indices: [391, 282]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Strategy: Use FlexibleCustom to execute a multi-step reasoning plan in parallel
        # instead of conditionally selecting operators. This ensures diverse reasoning paths
        # without branching logic — a fundamentally different approach from the existing workflow.

        steps = [
            {"name": "extract_relevant_info", "instruction": "Identify all key facts relevant to answering the question."},
            {"name": "analyze_question_type", "instruction": "Determine whether this requires counting, arithmetic, comparison, or span extraction."},
            {"name": "reason_with_specialized_expert", "instruction": "Use the appropriate expert (counting/arithmetic/comparison) based on the question type."}
        ]

        reasoning_pattern = "sequential"  # Execute steps one after another

        # Run flexible custom with structured steps and no hardcoded logic
        initial_analysis = await self.flexible_custom(
            steps=steps,
            reasoning_pattern=reasoning_pattern,
            custom_instruction="Solve the DROP-style problem by first extracting relevant information, then determining the reasoning type, and finally applying the correct specialized operator."
        )

        # Now that we have an initial solution, apply review to improve clarity
        reviewed_solution = await self.review(pre_solution=initial_analysis)

        # Finally, use ScEnsemble to ensure robustness — even though only one solution exists,
        # this enforces consistency across multiple runs (if needed in future iterations)
        final_output = await self.sc_ensemble(solutions=[reviewed_solution])

        return final_output