# Workflow ID: drop_43_0
# Benchmark: drop
# Data Indices: [216, 367]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify what needs to be extracted
        initial_thought = await self.custom(instruction="First, read the question carefully and determine what information must be extracted from the passage.")
        
        # Step 2: Extract relevant data — e.g., numbers, spans, or items mentioned in the question
        extraction_step = await self.custom(instruction=f"Based on the question, extract all relevant numerical or categorical data from the passage that will help answer it. Focus only on what is necessary.")
        
        # Step 3: Determine reasoning type — counting, arithmetic, comparison?
        reasoning_type = await self.custom(instruction="Now, classify the required reasoning type: counting, arithmetic, or comparison based on the question and extracted data.")
        
        # Step 4: Apply specialized reasoning operator based on classification
        if "count" in reasoning_type.lower():
            reasoning_result = await self.counting_reasoning()
        elif "arithmetic" in reasoning_type.lower() or "sum" in reasoning_type.lower() or "difference" in reasoning_type.lower():
            reasoning_result = await self.arithmetic_reasoning()
        elif "compare" in reasoning_type.lower() or "sort" in reasoning_type.lower() or "greater than" in reasoning_type.lower():
            reasoning_result = await self.comparison_reasoning()
        else:
            # Fallback to custom if reasoning type unclear
            reasoning_result = await self.custom(instruction="Use general reasoning to solve the problem now.")
        
        # Step 5: Finalize answer by formatting the result appropriately
        final_answer = await self.custom(instruction=f"Using the reasoning result: {reasoning_result}, generate a concise and accurate final answer to the original question.")
        
        return final_answer