# Workflow ID: drop_30_1
# Benchmark: drop
# Data Indices: [217, 40]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use comparison reasoning first to identify which type of task this is
        initial_comparison = await self.comparison_reasoning()
        
        # Step 2: Based on the comparison result, branch into specialized reasoning paths
        # If it's a comparison question (e.g., "which year had more periodicals"), handle directly
        if "compare" in initial_comparison.lower() or "which" in initial_comparison.lower():
            comparison_result = await self.comparison_reasoning()
            return comparison_result
        
        # If it's arithmetic (e.g., difference between two numbers), use arithmetic reasoning
        elif "difference" in initial_comparison.lower() or "how many more" in initial_comparison.lower():
            arithmetic_result = await self.arithmetic_reasoning()
            return arithmetic_result
        
        # If it's counting (e.g., "how many touchdowns"), use counting reasoning
        elif "count" in initial_comparison.lower() or "how many" in initial_comparison.lower():
            count_result = await self.counting_reasoning()
            return count_result
        
        # Fallback: use flexible custom with structured steps for unknown cases
        else:
            steps = [
                "Extract all relevant numerical values from the passage",
                "Determine whether the question requires counting, arithmetic, or comparison",
                "Apply the appropriate reasoning operator based on the determination"
            ]
            reasoning_pattern = "Sequentially analyze and apply the correct reasoning type."
            final_attempt = await self.flexible_custom(
                reasoning_pattern=reasoning_pattern,
                steps=steps,
                custom_instruction="Solve the problem by following these steps."
            )
            
            # Step 3: Use ScEnsemble to evaluate multiple potential solutions if needed
            # Generate two alternative approaches using Custom
            alt_solution_1 = await self.custom(instruction="First approach: Extract key data and solve directly.")
            alt_solution_2 = await self.custom(instruction="Second approach: Break down the question step-by-step and reason through each part.")
            
            # Combine with original attempt for voting
            ensemble_solutions = [final_attempt, alt_solution_1, alt_solution_2]
            final_answer = await self.sc_ensemble(solutions=ensemble_solutions)
            
            # Final review to refine clarity and correctness
            reviewed_answer = await self.review(pre_solution=final_answer)
            
            return reviewed_answer