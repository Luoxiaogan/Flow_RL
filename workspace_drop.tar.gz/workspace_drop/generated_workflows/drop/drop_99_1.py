# Workflow ID: drop_99_1
# Benchmark: drop
# Data Indices: [233, 336]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom with a parallel reasoning pattern to explore multiple interpretations
        reasoning_pattern = "parallel"
        steps = [
            "Identify what kind of reasoning is needed (counting, arithmetic, comparison).",
            "Generate one solution per reasoning type using dedicated experts.",
            "Evaluate each solution independently before combining."
        ]
        parallel_analysis = await self.flexible_custom(
            reasoning_pattern=reasoning_pattern,
            steps=steps,
            custom_instruction="Analyze the question and generate three distinct solutions using different reasoning strategies."
        )

        # Step 2: Run each specialized operator in parallel (as implied by parallel reasoning)
        counting_result = await self.counting_reasoning()
        arithmetic_result = await self.arithmetic_reasoning()
        comparison_result = await self.comparison_reasoning()

        # Step 3: Select the best candidate based on internal confidence or consistency
        # Instead of ensemble voting, we pick the most coherent answer first
        candidates = [
            ("counting", counting_result),
            ("arithmetic", arithmetic_result),
            ("comparison", comparison_result)
        ]

        # Sort by 'confidence' if available — otherwise, use heuristic: more structured output = higher confidence
        def score_candidate(_, result_str):
            if "thought" in result_str and "result" in result_str:
                return 1  # Structured format indicates high quality
            elif "count" in result_str:
                return 0.8
            elif "equation" in result_str:
                return 0.8
            return 0.5

        best_candidate = max(candidates, key=lambda x: score_candidate(x[0], x[1]))
        selected_answer = best_candidate[1]

        # Step 4: Review the top candidate for clarity and correctness
        final_answer = await self.review(pre_solution=selected_answer)

        return final_answer