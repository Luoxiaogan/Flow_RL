# Workflow ID: drop_158_0
# Benchmark: drop
# Data Indices: [190, 204]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Initial reasoning to understand what's being asked
        initial_thought = await self.custom(instruction="First, identify the key question and determine whether it requires counting, arithmetic, or comparison. If it involves numbers in text, extract them first.")
        
        # Step 2: Use flexible_custom to define a structured plan based on the question type
        reasoning_pattern = "extract_and_solve"
        steps = [
            "Identify all relevant numerical values mentioned in the passage related to the question.",
            "Determine which operation (counting, arithmetic, comparison) is needed to answer the question.",
            "Apply the appropriate operator (e.g., CountingReasoning, ArithmeticReasoning, ComparisonReasoning).",
            "Return the final answer as a number, date, or span of text."
        ]
        custom_instruction = f"Based on the initial thought: {initial_thought}, now execute the following steps: {steps}."
        
        plan_output = await self.flexible_custom(
            reasoning_pattern=reasoning_pattern,
            steps=steps,
            custom_instruction=custom_instruction
        )

        # Step 3: Execute the actual reasoning using the correct specialized operator
        # This step dynamically selects the right tool based on the question type
        dynamic_solution = await self.custom(instruction=f"Using the plan: {plan_output}, now solve the problem directly by applying the most suitable reasoning operator. Consider if this is a counting, arithmetic, or comparison task.")

        # Step 4: Review the solution for correctness and clarity
        reviewed_solution = await self.review(pre_solution=dynamic_solution)

        # Step 5: Final ensemble check — if multiple solutions were generated, pick the most consistent one
        # In this case, we only have one, so sc_ensemble just confirms consistency
        final_answer = await self.sc_ensemble(solutions=[reviewed_solution])

        return final_answer