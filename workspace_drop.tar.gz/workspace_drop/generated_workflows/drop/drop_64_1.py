# Workflow ID: drop_64_1
# Benchmark: drop
# Data Indices: [312, 279]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Extract key facts and numbers using Custom — this is the foundation
        extraction = await self.custom(instruction="Extract all numerical values, dates, and relevant entities from the passage that may be needed to answer the question. List them clearly.")

        # Step 2: Use FlexibleCustom to run multiple reasoning strategies in parallel (parallel execution strategy)
        solutions = await self.flexible_custom(
            reasoning_pattern="multi_strategy_parallel",
            steps=[
                {"task": "Apply arithmetic reasoning", "instruction": "Based on the extracted data, perform arithmetic operations required by the question."},
                {"task": "Apply counting reasoning", "instruction": "If the question involves counting items or events mentioned in the passage, count them now."},
                {"task": "Apply comparison reasoning", "instruction": "If the question compares two or more quantities or timelines, compare them now."}
            ],
            custom_instruction="Now generate one solution per step above. Return all three as a list of strings."
        )

        # Step 3: Ensembling via ScEnsemble to pick the most consistent answer across strategies (different ensemble strategy)
        final_answer = await self.sc_ensemble(solutions=solutions)

        # Step 4: Final review to polish and ensure clarity (improves robustness without changing logic flow)
        polished_answer = await self.review(pre_solution=final_answer)

        return polished_answer