# Workflow ID: drop_103_1
# Benchmark: drop
# Data Indices: [209, 358]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Strategy: Generate multiple solutions in parallel using different reasoning approaches,
        # then use ensemble to pick the most consistent answer — this differs from the existing
        # sequential single-path approach.

        # Step 1: Generate three diverse initial answers using different strategies
        solution1 = await self.custom(instruction="First, extract all relevant facts from the passage and identify what needs to be computed.")
        solution2 = await self.flexible_custom(
            steps=[
                {"name": "parse", "instruction": "Identify key entities and numerical values in the text."},
                {"name": "reason", "instruction": "Apply arithmetic reasoning based on extracted numbers."}
            ],
            reasoning_pattern="chain_of_thought",
            custom_instruction="Solve the problem using structured extraction and calculation."
        )
        solution3 = await self.comparison_reasoning()

        # Step 2: Use ScEnsemble to select the most robust answer from the three
        final_answer = await self.sc_ensemble(solutions=[solution1, solution2, solution3])
        
        # Step 3: Review the final ensemble result to improve clarity or correctness
        refined_answer = await self.review(pre_solution=final_answer)
        
        return refined_answer