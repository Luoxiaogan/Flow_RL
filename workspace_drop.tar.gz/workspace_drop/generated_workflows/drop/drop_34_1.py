# Workflow ID: drop_34_1
# Benchmark: drop
# Data Indices: [35, 183]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to define a multi-step reasoning pattern
        # This strategy uses structured logic instead of branching on type
        reasoning_plan = [
            "Step 1: Identify key numbers in the passage relevant to the question.",
            "Step 2: Determine whether the task involves counting, arithmetic, or comparison.",
            "Step 3: Execute the appropriate specialized reasoning step based on the determined type.",
            "Step 4: Reflect on the solution and refine it using review."
        ]

        plan_result = await self.flexible_custom(
            reasoning_pattern="sequential",
            steps=reasoning_plan,
            custom_instruction="Execute each step logically and produce a final answer."
        )

        # Step 2: Extract high-level structure — determine what kind of reasoning is needed
        analysis = await self.custom(instruction="Based on the passage and question, identify if this is a counting, arithmetic, or comparison problem.")

        # Step 3: Apply the most suitable operator directly without branching logic
        if "count" in analysis.lower():
            result = await self.counting_reasoning()
        elif "difference" in analysis.lower() or "drop" in analysis.lower() or "increase" in analysis.lower():
            result = await self.arithmetic_reasoning()
        else:
            result = await self.comparison_reasoning()

        # Step 4: Instead of reviewing once, generate multiple solutions via ensemble
        # This introduces parallel exploration of different interpretations
        solution1 = result
        solution2 = await self.custom(instruction="Re-solve the same problem using a fresh perspective—focus only on numerical values mentioned explicitly.")
        solution3 = await self.custom(instruction="Solve again by focusing solely on context clues around the question phrase (e.g., 'more', 'less', 'how many').")

        # Step 5: Use ScEnsemble to select the most consistent answer across diverse strategies
        final_answer = await self.sc_ensemble(solutions=[solution1, solution2, solution3])

        return final_answer