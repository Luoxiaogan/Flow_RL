# Workflow ID: drop_62_1
# Benchmark: drop
# Data Indices: [195, 294]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to execute a multi-step reasoning pattern in parallel
        # This avoids sequential dependency and allows simultaneous exploration of different strategies
        steps = [
            {"name": "extract", "instruction": "Identify all numerical values and relevant entities mentioned in the passage related to the question."},
            {"name": "classify", "instruction": "Classify each piece of extracted information based on whether it supports counting, arithmetic, or comparison reasoning."},
            {"name": "reason", "instruction": "Apply the appropriate reasoning type (counting/arithmetic/comparison) to each classified segment independently."}
        ]
        
        reasoning_pattern = "parallel"  # Execute all steps concurrently using parallel reasoning
        initial_analysis = await self.flexible_custom(
            steps=steps,
            reasoning_pattern=reasoning_pattern,
            custom_instruction="Analyze the passage and extract key data points for reasoning."
        )

        # Step 2: Now that we have multiple partial solutions, apply ensemble voting directly
        # This skips intermediate review and uses collective intelligence upfront — a major logical shift
        final_answer = await self.sc_ensemble(solutions=[initial_analysis])

        # Step 3: Only after ensemble selection, perform a final refinement via Review
        # This ensures correctness without overfitting to one flawed path
        refined_answer = await self.review(pre_solution=final_answer)

        return refined_answer