# Workflow ID: drop_127_0
# Benchmark: drop
# Data Indices: [125, 128]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify required reasoning type
        initial_thought = await self.custom(instruction="Analyze the question to determine whether it requires counting, arithmetic, or comparison reasoning. Identify key entities and numerical values in the passage relevant to the question.")

        # Step 2: Generate multiple solutions using different strategies
        solution1 = await self.custom(instruction="First, extract all relevant numerical data from the passage that could be related to the question. Then, reason step-by-step based on this data to solve the problem.")
        solution2 = await self.custom(instruction="Think like an expert in information extraction: find every number mentioned in the passage, then apply logical filtering to isolate those directly relevant to the question.")
        solution3 = await self.custom(instruction="Use structured thinking: list all possible interpretations of the question, then eliminate incorrect ones by cross-referencing with the passage text.")

        # Step 3: Use ScEnsemble to select the most consistent answer across multiple approaches
        final_answer = await self.sc_ensemble(solutions=[solution1, solution2, solution3])

        return final_answer