# Workflow ID: drop_41_1
# Benchmark: drop
# Data Indices: [15, 22]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use flexible custom to extract key entities and numerical data in parallel
        extraction = await self.flexible_custom(
            steps=[
                {"name": "Extract Numbers", "instruction": "Identify all numbers mentioned in the passage."},
                {"name": "Link Values to Categories", "instruction": "Map each number to its associated group or category (e.g., '34.7%' → 'population below poverty line')."},
                {"name": "Summarize Context", "instruction": "Provide a concise summary linking numbers to their context."}
            ],
            reasoning_pattern="chain_of_thought",
            custom_instruction="First, list all relevant numeric values with their categories. Then summarize how they relate to the question."
        )

        # Step 2: Use comparison reasoning directly on the extracted data
        comparison_result = await self.comparison_reasoning()

        # Step 3: Generate a candidate answer using custom reasoning based on the structured output
        candidate_answer = await self.custom(instruction=f"Based on this structured data: {extraction}, now solve the question step-by-step.")

        # Step 4: Review the candidate answer to improve clarity and correctness
        reviewed_answer = await self.review(pre_solution=candidate_answer)

        # Step 5: Use ensemble voting — but only after one review pass; avoid redundant iterations
        final_answer = await self.sc_ensemble(solutions=[reviewed_answer])

        return final_answer