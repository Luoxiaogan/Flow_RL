# Workflow ID: drop_118_1
# Benchmark: drop
# Data Indices: [162, 139]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """

        # Step 1: Initial high-level reasoning to determine what kind of task this is
        initial_analysis = await self.custom(instruction="Analyze the question and classify it into one of: counting, arithmetic, comparison, or multi-step reasoning. Identify key entities (e.g., players, events, time periods).")

        # Step 2: Use FlexibleCustom to define a structured plan — this enforces step-by-step logic without Python control flow
        structured_plan = await self.flexible_custom(
            reasoning_pattern="Plan → Execute → Verify",
            steps=[
                "Step 1: Extract all relevant items from the passage based on the question.",
                "Step 2: Apply the appropriate reasoning type (counting, comparison, etc.) to those items.",
                "Step 3: Validate the result by cross-checking with another method."
            ],
            custom_instruction="Based on the analysis, generate a detailed plan to solve the problem using structured reasoning."
        )

        # Step 3: Generate first solution using direct extraction + counting
        first_solution = await self.custom(instruction="Extract all instances matching the query criteria directly from the text and count them.")

        # Step 4: Review the first solution critically — this is the new strategic pivot!
        reviewed_solution = await self.review(pre_solution=first_solution)

        # Step 5: Now, independently verify using a different approach — e.g., comparison-based filtering if it's about selection
        comparison_based_verification = await self.comparison_reasoning()

        # Step 6: Ensemble only between the reviewed solution and the comparison-based one — no need to involve raw counting or flexible custom again
        final_answer = await self.sc_ensemble(solutions=[reviewed_solution, comparison_based_verification])

        return final_answer