# Workflow ID: drop_41_0
# Benchmark: drop
# Data Indices: [15, 22]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Extract relevant information from the passage
        extraction = await self.custom(instruction="Identify all numerical values and categories mentioned in the passage that are relevant to answering the question.")

        # Step 2: Determine the type of reasoning required based on the question
        reasoning_type = await self.custom(instruction="Based on the question, determine whether this requires counting, arithmetic, or comparison reasoning. Output only one word: 'counting', 'arithmetic', or 'comparison'.")

        # Step 3: Apply the appropriate specialized reasoning operator
        if "counting" in reasoning_type.lower():
            result = await self.counting_reasoning()
        elif "arithmetic" in reasoning_type.lower():
            result = await self.arithmetic_reasoning()
        elif "comparison" in reasoning_type.lower():
            result = await self.comparison_reasoning()
        else:
            # Fallback: Use flexible custom for complex multi-step logic
            result = await self.flexible_custom(
                steps=[
                    {"name": "Extract", "instruction": "Find all numbers and their associated groups."},
                    {"name": "Reason", "instruction": "Determine which group meets the condition in the question."},
                    {"name": "Answer", "instruction": "Provide a clear final answer based on the reasoning."}
                ],
                reasoning_pattern="chain_of_thought",
                custom_instruction="Solve the problem step-by-step using the extracted data."
            )

        # Step 4: Final review to improve clarity and correctness
        final_answer = await self.review(pre_solution=result)

        # Step 5: Ensemble voting (optional but recommended for robustness)
        ensemble_result = await self.sc_ensemble(solutions=[final_answer])

        return ensemble_result