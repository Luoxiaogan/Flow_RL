# Workflow ID: drop_62_0
# Benchmark: drop
# Data Indices: [195, 294]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify required information extraction
        initial_thought = await self.custom(instruction="First, read the question carefully and determine what needs to be extracted from the passage. Identify key entities or quantities relevant to the answer.")

        # Step 2: Extract relevant text segments (e.g., numbers, named entities, events)
        extraction = await self.custom(instruction="Now, extract all relevant sentences or phrases that contain numerical data or items related to the question. Focus only on those directly tied to the query.")

        # Step 3: Determine the type of reasoning needed — counting, arithmetic, or comparison
        reasoning_type = await self.custom(instruction="Based on the extracted information, decide whether this problem requires counting, arithmetic, or comparison reasoning. For example, if asking 'how many', it's likely counting; if asking for a difference, arithmetic; if comparing two values, comparison.")

        # Step 4: Apply specialized reasoning operator based on type
        if "count" in reasoning_type.lower():
            result = await self.counting_reasoning()
        elif "arithmetic" in reasoning_type.lower() or "sum" in reasoning_type.lower() or "difference" in reasoning_type.lower():
            result = await self.arithmetic_reasoning()
        elif "compare" in reasoning_type.lower() or "sort" in reasoning_type.lower() or "most" in reasoning_type.lower() or "least" in reasoning_type.lower():
            result = await self.comparison_reasoning()
        else:
            # Fallback to custom if no clear reasoning type
            result = await self.custom(instruction="Use general reasoning to solve the problem based on the extracted information.")

        # Step 5: Finalize the answer using a review step to refine clarity and correctness
        final_answer = await self.review(pre_solution=result)

        # Step 6: Use ensemble voting if multiple solutions are possible (optional robustness boost)
        # Here we simulate a single solution, but in practice, this would collect several attempts
        final_output = await self.sc_ensemble(solutions=[final_answer])

        return final_output