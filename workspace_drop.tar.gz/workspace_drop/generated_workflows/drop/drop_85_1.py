# Workflow ID: drop_85_1
# Benchmark: drop
# Data Indices: [388, 325]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom with a parallel reasoning pattern to generate multiple solutions simultaneously
        multi_solution = await self.flexible_custom(
            steps=[
                {"step": "Identify key elements", "instruction": "Extract all relevant numerical facts and entities from the passage."},
                {"step": "Apply different reasoning types", "instruction": "Generate one solution using counting, one using arithmetic, and one using comparison — each independently."}
            ],
            reasoning_pattern="parallel",
            custom_instruction="Now solve the problem using the extracted information via three distinct reasoning paths."
        )

        # Step 2: Parse the multi-solution output into individual candidate answers
        candidates = multi_solution.split("\n\n")  # Assume each path outputs a separate block

        # Step 3: Apply ScEnsemble to select the most consistent answer across the three approaches
        final_answer = await self.sc_ensemble(solutions=candidates)

        return final_answer