# Workflow ID: drop_24_0
# Benchmark: drop
# Data Indices: [344, 172]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question type — extract key task (e.g., count, arithmetic, compare)
        initial_thought = await self.custom(instruction="Analyze the question to determine whether it requires counting, arithmetic, or comparison reasoning.")
        
        # Step 2: Route to appropriate specialized operator based on the nature of the task
        if "how many" in initial_thought.lower() and ("count" in initial_thought.lower() or "number of" in initial_thought.lower()):
            result = await self.counting_reasoning()
            return result['count']
        elif "increase", "decrease", "difference", "sum", "total" in initial_thought.lower():
            result = await self.arithmetic_reasoning()
            return result['result']
        elif "which", "more than", "less than", "highest", "lowest", "order", "sorted":
            result = await self.comparison_reasoning()
            return result['result']
        else:
            # Fallback: Use flexible custom for complex multi-step reasoning
            final_answer = await self.flexible_custom(
                steps=[
                    {"name": "analyze_question", "instruction": "Break down the question into its core components."},
                    {"name": "select_operator", "instruction": "Based on the breakdown, choose the correct reasoning type: counting, arithmetic, or comparison."},
                    {"name": "execute_reasoning", "instruction": "Execute the selected reasoning step using the corresponding expert operator."}
                ],
                reasoning_pattern="sequential",
                custom_instruction="Now solve the problem using the structured plan."
            )
            return final_answer