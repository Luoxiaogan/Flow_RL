# Workflow ID: drop_141_1
# Benchmark: drop
# Data Indices: [299, 6]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Strategy: First, extract key entities and facts using FlexibleCustom to guide reasoning
        extraction_step = await self.flexible_custom(
            reasoning_pattern="extract_and_structure",
            steps=[
                "Identify all relevant numerical or categorical data in the passage related to the question.",
                "List them clearly with context (e.g., 'Dave Rayner made 3 field goals' or 'Romanian army had 99 artillery batteries')."
            ],
            custom_instruction="Extract and structure all relevant information from the passage that could help answer the question."
        )

        # Step 2: Use ComparisonReasoning first — it's often most efficient for comparative questions
        comparison_result = await self.comparison_reasoning()
        
        # Step 3: If the question requires counting, use CountingReasoning as a direct subtask
        counting_result = await self.counting_reasoning()

        # Step 4: Now generate final answer via Custom using both structured extraction and specialized results
        final_answer = await self.custom(instruction=f"Based on the extracted facts: {extraction_step}, comparison result: {comparison_result['result']}, and count: {counting_result['count']}, provide the final answer to the original question.")
        
        # Step 5: Apply ensemble over multiple solutions — one from each reasoning type + final synthesis
        solutions = [
            comparison_result["result"],
            counting_result["count"],
            final_answer
        ]
        ensemble_result = await self.sc_ensemble(solutions=solutions)
        
        return ensemble_result