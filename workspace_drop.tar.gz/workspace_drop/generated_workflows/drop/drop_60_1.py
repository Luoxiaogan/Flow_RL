# Workflow ID: drop_60_1
# Benchmark: drop
# Data Indices: [4, 88]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to guide a multi-step reasoning process
        # This avoids the sequential "detect type → execute" pattern used in existing workflow
        # Instead, we define a structured plan that includes extraction and reasoning in one flow
        initial_plan = await self.flexible_custom(
            steps=[
                "Identify all relevant entities or quantities mentioned in the passage related to the question.",
                "Determine whether the task requires counting, arithmetic, or comparison based on the question.",
                "Execute the appropriate reasoning step using the specialized operator."
            ],
            reasoning_pattern="stepwise",
            custom_instruction="Solve the problem by following these steps: first extract key info, then choose reasoning type, then compute."
        )

        # Step 2: Review the structured solution — this ensures clarity before ensemble
        reviewed_solution = await self.review(pre_solution=initial_plan)

        # Step 3: Use ScEnsemble with multiple strategies (parallel exploration)
        # Unlike existing workflow which uses ensemble at end after one path, here we try different approaches
        # First, attempt direct counting if question implies it
        direct_count_attempt = await self.custom(instruction="Extract all items relevant to the question. Count them directly.")
        
        # Second, attempt comparison-based interpretation if applicable
        comparison_attempt = await self.custom(instruction="If the question involves comparing or ordering items, identify the correct order or ranking.")

        # Third, use flexible custom as a fallback for complex cases
        fallback_attempt = await self.flexible_custom(
            steps=["Parse context", "Extract relevant data", "Apply reasoning"],
            reasoning_pattern="stepwise",
            custom_instruction="Solve the problem using a structured approach tailored to its nature."
        )

        # Step 4: Final selection via ensemble — now we compare three diverse solutions
        final_answer = await self.sc_ensemble(solutions=[reviewed_solution, direct_count_attempt, comparison_attempt, fallback_attempt])

        return final_answer