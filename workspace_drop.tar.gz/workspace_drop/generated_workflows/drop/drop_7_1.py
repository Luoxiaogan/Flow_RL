# Workflow ID: drop_7_1
# Benchmark: drop
# Data Indices: [241, 42]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to first extract key entities and numbers from the passage
        extraction_step = await self.flexible_custom(
            steps=[
                "Identify all numerical values in the passage with their associated context (e.g., country, event, time).",
                "List these values clearly, noting what they represent (e.g., population, yardage, count)."
            ],
            reasoning_pattern="sequential",
            custom_instruction="Extract relevant numerical data from the passage for later use in solving the question."
        )

        # Step 2: Analyze the question to determine the required operation type
        task_analysis = await self.custom(instruction=f"Based on the extracted data: {extraction_step}, analyze the question to determine whether it requires counting, arithmetic, or comparison reasoning.")

        # Step 3: Apply the most appropriate specialized operator directly based on the analysis
        if "count" in task_analysis.lower():
            answer = await self.counting_reasoning()
        elif "sum" in task_analysis.lower() or "total" in task_analysis.lower() or "add" in task_analysis.lower():
            answer = await self.arithmetic_reasoning()
        elif "which" in task_analysis.lower() or "greater" in task_analysis.lower() or "lesser" in task_analysis.lower():
            answer = await self.comparison_reasoning()
        else:
            # If no clear match, fall back to a general custom solution using the extracted info
            answer = await self.custom(instruction=f"Use the extracted data: {extraction_step} to solve the question based on this analysis: {task_analysis}")

        # Step 4: Immediately review the answer — before any ensemble — to catch errors early
        reviewed_answer = await self.review(pre_solution=answer)

        # Step 5: Use ScEnsemble not as a final step but as a quality check — compare original vs reviewed
        ensemble_result = await self.sc_ensemble(solutions=[answer, reviewed_answer])

        # Step 6: Return the best result after review + ensemble — this ensures robustness without redundant steps
        return ensemble_result