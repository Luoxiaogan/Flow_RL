# Workflow ID: drop_150_0
# Benchmark: drop
# Data Indices: [91, 283]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the task by analyzing the question
        initial_thought = await self.custom(instruction="First, identify what type of reasoning is needed (counting, arithmetic, comparison) based on the question. Then determine which parts of the passage contain relevant information.")

        # Generate multiple solutions using different strategies
        solution1 = await self.custom(instruction="Approach 1: Extract all field goals mentioned in the passage and count those between 25 and 50 yards.")
        solution2 = await self.custom(instruction="Approach 2: Identify field goals with distances, filter those between 25 and 50 yards, then count them step-by-step.")
        solution3 = await self.counting_reasoning()

        # Use ScEnsemble to select the most consistent answer across multiple approaches
        final_answer = await self.sc_ensemble([solution1, solution2, solution3])

        return final_answer