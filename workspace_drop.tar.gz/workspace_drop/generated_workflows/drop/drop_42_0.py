# Workflow ID: drop_42_0
# Benchmark: drop
# Data Indices: [208, 364]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify what needs to be extracted
        initial_thought = await self.custom(instruction="Read the passage carefully and identify all numerical values related to the question. Focus on key metrics like yards, scores, or counts.")

        # Step 2: Use flexible_custom to extract relevant numbers (e.g., receiver stats, field goal lengths)
        extraction_step = [
            {"name": "extract_yards", "instruction": "Identify all yardage figures mentioned in the passage that could relate to the question."},
            {"name": "filter_relevant", "instruction": "From these, isolate only those directly tied to the specific query (e.g., receiver yards, field goal distances)."}
        ]
        extracted_values = await self.flexible_custom(
            steps=extraction_step,
            reasoning_pattern="Extract → Filter",
            custom_instruction="Process the passage to find all numeric values relevant to answering the question."
        )

        # Step 3: If we have a list of values, use comparison reasoning to determine max/min or differences
        comparison_result = await self.comparison_reasoning()

        # Step 4: For problems requiring arithmetic (like difference between two values), perform arithmetic reasoning
        arithmetic_result = await self.arithmetic_reasoning()

        # Step 5: Generate multiple solutions using different strategies (parallel ensemble)
        solution1 = await self.custom(instruction="First approach: Identify the leading receiver's yardage and second-leading receiver's yardage, then compute their difference.")
        solution2 = await self.custom(instruction="Second approach: List all receivers' yardages, sort them, and calculate the gap between top two.")
        solution3 = await self.custom(instruction="Third approach: Re-read the passage focusing solely on player statistics and derive the answer directly.")

        # Step 6: Use sc_ensemble to select the most consistent answer across the three approaches
        final_answer = await self.sc_ensemble(solutions=[solution1, solution2, solution3])

        # Optional: Review the final answer for clarity and correctness
        reviewed_answer = await self.review(pre_solution=final_answer)

        return reviewed_answer