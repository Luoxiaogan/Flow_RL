# Workflow ID: drop_26_1
# Benchmark: drop
# Data Indices: [317, 161]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You must use strategic templates and ensemble methods for robustness.
        """
        # Step 1: Use FlexibleCustom to define a multi-step reasoning pattern
        # This allows us to orchestrate complex logic without explicit Python control flow
        flexible_result = await self.flexible_custom(
            reasoning_pattern="extract_and_calculate",
            steps=[
                "Identify all relevant numerical or temporal data in the passage.",
                "Determine the relationship between these values based on the question.",
                "Perform the required arithmetic operation (e.g., difference, percentage)."
            ],
            custom_instruction="Solve the problem using structured extraction and calculation."
        )

        # Step 2: Generate an alternative solution using counting + comparison
        count_solution = await self.counting_reasoning()
        compare_solution = await self.comparison_reasoning()

        # Step 3: Review the flexible result first — this ensures we start with a strong baseline
        reviewed_flexible = await self.review(pre_solution=flexible_result)

        # Step 4: Now use ScEnsemble not just on raw solutions, but on a mix of:
        # - The reviewed flexible solution
        # - A direct arithmetic reasoning attempt
        # - The combination of count + compare
        final_answer = await self.sc_ensemble(solutions=[
            reviewed_flexible,
            await self.arithmetic_reasoning(),
            f"{count_solution} | {compare_solution}"
        ])

        return final_answer