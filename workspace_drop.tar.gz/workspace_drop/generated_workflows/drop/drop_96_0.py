# Workflow ID: drop_96_0
# Benchmark: drop
# Data Indices: [319, 207]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify required operations
        initial_thought = await self.custom(instruction="First, read the question carefully and determine what needs to be extracted or calculated. Identify whether it involves counting, arithmetic, comparison, or a combination.")
        
        # Step 2: Extract relevant numerical data from passage
        extraction = await self.custom(instruction="Extract all numbers and percentages mentioned in the passage that relate to the question. Focus only on those directly relevant to solving the problem.")

        # Step 3: Determine the type of reasoning needed
        reasoning_type = await self.custom(instruction="Based on the question and extracted data, decide whether this requires counting, arithmetic (like percentage calculation), or comparison. If it's arithmetic, state the equation.")

        # Step 4: Perform the appropriate reasoning step
        if "percentage" in reasoning_type.lower() or "percent" in reasoning_type.lower():
            result = await self.arithmetic_reasoning()
        elif "count" in reasoning_type.lower() or "how many" in reasoning_type.lower():
            result = await self.counting_reasoning()
        elif "compare" in reasoning_type.lower() or "which is more" in reasoning_type.lower():
            result = await self.comparison_reasoning()
        else:
            # Fallback to flexible custom for complex multi-step tasks
            result = await self.flexible_custom(
                steps=[
                    {"task": "Identify key numbers", "instruction": "Find the relevant values from the passage."},
                    {"task": "Apply math", "instruction": "Use arithmetic to compute the answer."},
                    {"task": "Finalize answer", "instruction": "Return only the final number or phrase as the answer."}
                ],
                reasoning_pattern="Chain-of-Thought",
                custom_instruction="Solve the problem step by step."
            )

        # Step 5: Review the solution for correctness
        reviewed_solution = await self.review(pre_solution=result)

        # Step 6: Use ensemble to improve robustness if multiple solutions were generated
        # For now, just return the reviewed one since we don't have multiple candidates
        final_answer = reviewed_solution

        return final_answer