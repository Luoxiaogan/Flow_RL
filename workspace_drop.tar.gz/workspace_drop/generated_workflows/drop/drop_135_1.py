# Workflow ID: drop_135_1
# Benchmark: drop
# Data Indices: [65, 359]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Strategy: Use FlexibleCustom to define a multi-step reasoning plan in parallel
        # First, generate multiple candidate solutions using different strategies
        # Then, apply ensemble voting to select the most consistent answer

        # Step 1: Define a flexible custom workflow that explores multiple reasoning paths
        steps = [
            {"name": "identify_task", "instruction": "Identify whether this is a counting, arithmetic, or comparison task."},
            {"name": "execute_specialized", "instruction": "Based on the task type, choose and execute the appropriate specialized operator (counting/arithmetic/comparison)."},
            {"name": "review_solution", "instruction": "Critique the solution for logical consistency and correctness."}
        ]

        reasoning_pattern = "sequential"

        # Execute the flexible custom workflow to get a structured, step-by-step solution
        initial_solution = await self.flexible_custom(
            steps=steps,
            reasoning_pattern=reasoning_pattern,
            custom_instruction="Solve the DROP-style question by first identifying the task type, then applying the correct reasoning method."
        )

        # Step 2: Generate alternative solutions using different strategies
        # One with direct arithmetic reasoning
        arith_sol = await self.arithmetic_reasoning()
        
        # One with comparison reasoning (if applicable)
        comp_sol = await self.comparison_reasoning()
        
        # One with counting reasoning (if applicable)
        count_sol = await self.counting_reasoning()

        # Step 3: Use ScEnsemble to combine all three solutions and pick the most consistent one
        solutions = [initial_solution, str(arith_sol["result"]), str(comp_sol["result"]), str(count_sol["count"])]
        final_answer = await self.sc_ensemble(solutions=solutions)

        return final_answer