# Workflow ID: drop_68_1
# Benchmark: drop
# Data Indices: [329, 251]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to define a multi-step reasoning pattern that first identifies relevant info,
        # then applies specialized reasoning (arithmetic/counting/comparison), and finally selects the best answer.
        steps = [
            {"name": "identify_relevant_info", "instruction": "Extract all events or entities mentioned in the passage that are directly related to the question."},
            {"name": "reason_and_solve", "instruction": "Apply the appropriate reasoning type (counting, arithmetic, comparison) based on the nature of the question."},
            {"name": "select_final_answer", "instruction": "From the structured output of the previous step, determine the final answer as a number, date, or span of text."}
        ]
        
        reasoning_pattern = "sequential"  # Execute steps one after another

        # Run the flexible custom workflow with structured steps
        intermediate_result = await self.flexible_custom(
            steps=steps,
            reasoning_pattern=reasoning_pattern,
            custom_instruction="Solve the DROP benchmark-style question by breaking it into three clear phases: identify, reason, and select."
        )

        # Step 2: Use ComparisonReasoning to validate the result against potential alternatives (e.g., if multiple candidates exist)
        comparison_result = await self.comparison_reasoning()

        # Step 3: Combine the two results using ensemble — not just voting, but also checking consistency between logical structure and factual alignment
        final_solution = await self.sc_ensemble(solutions=[intermediate_result, comparison_result])

        # Step 4: Final review to polish clarity and correctness
        final_answer = await self.review(pre_solution=final_solution)

        return final_answer