# Workflow ID: drop_159_1
# Benchmark: drop
# Data Indices: [211, 1]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to first generate multiple distinct reasoning paths in parallel
        solutions = await self.flexible_custom(
            reasoning_pattern="parallel reasoning",
            steps=[
                "Extract all relevant numerical and temporal data from the passage.",
                "Determine the required operation type (counting, arithmetic, comparison).",
                "Apply the corresponding specialized operator independently.",
                "Return each result as a separate solution."
            ],
            custom_instruction="Generate multiple independent solutions using different strategies. For example, one might focus on dates, another on counts, another on comparisons — all based on the same passage."
        )

        # Step 2: Instead of reviewing then ensembling, we now directly use ScEnsemble to select the most consistent answer
        final_result = await self.sc_ensemble(solutions=solutions.split("\n"))  # Assume multi-solution string output

        # Step 3: If ensemble returns an ambiguous or low-confidence result, fall back to a single high-quality review
        if "ambiguous" in final_result.lower() or "uncertain" in final_result.lower():
            reviewed_solution = await self.review(pre_solution=final_result)
            return reviewed_solution

        # Step 4: Final validation step — re-check with a dedicated custom instruction that forces precision
        precise_answer = await self.custom(instruction=f"Given the final answer '{final_result}', verify it by explicitly referencing the passage and confirming the logic used.")
        
        return precise_answer