# Workflow ID: drop_177_1
# Benchmark: drop
# Data Indices: [179, 71]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to generate multiple candidate solutions in parallel
        # by defining different reasoning strategies — one per step
        solution_candidates = await self.flexible_custom(
            steps=[
                "Generate a solution using direct extraction and counting.",
                "Generate a solution using arithmetic reasoning on numerical data.",
                "Generate a solution using comparison reasoning to rank or order events."
            ],
            reasoning_pattern="Chain-of-Thought",
            custom_instruction="Provide a distinct reasoning path for each step. Do not reuse logic."
        )

        # Step 2: Evaluate all candidates with ScEnsemble to select the most consistent answer
        final_answer = await self.sc_ensemble(solutions=[solution_candidates])

        # Step 3: Review the final ensemble result to refine clarity and correctness
        refined_answer = await self.review(pre_solution=final_answer)

        return refined_answer