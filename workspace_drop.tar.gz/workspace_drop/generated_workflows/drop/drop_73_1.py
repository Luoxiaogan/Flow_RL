# Workflow ID: drop_73_1
# Benchmark: drop
# Data Indices: [235, 114]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Extract key entities and facts using Custom (no reasoning yet)
        extraction = await self.custom(instruction="Extract all relevant numerical data and player names mentioned in the passage related to scoring events (e.g., field goals, touchdowns).")

        # Step 2: Use FlexibleCustom to define a multi-step plan based on the question type
        # This step uses structured reasoning without explicit Python control flow
        reasoning_plan = await self.flexible_custom(
            steps=[
                "Identify the specific query intent: count, compare, or calculate.",
                "Locate the relevant players or events in the extracted data.",
                "Apply the appropriate reasoning operator (counting, comparison, arithmetic).",
                "Format the final answer clearly as a number, name, or span."
            ],
            reasoning_pattern="chain_of_thought",
            custom_instruction="Based on the extracted facts and the question, execute the steps above."
        )

        # Step 3: Evaluate multiple solutions in parallel via ScEnsemble
        # Generate three independent attempts with slightly different prompts
        solution1 = await self.custom(instruction="Use the extracted facts to directly answer the question.")
        solution2 = await self.custom(instruction="First, identify who scored what. Then, determine the correct answer based on that.")
        solution3 = await self.custom(instruction="Break down the passage sentence by sentence to find the answer.")

        # Step 4: Use ScEnsemble to select the most consistent answer across the three attempts
        final_answer = await self.sc_ensemble(solutions=[solution1, solution2, solution3])

        # Step 5: Final review to ensure clarity and correctness
        final_result = await self.review(pre_solution=final_answer)

        return final_result