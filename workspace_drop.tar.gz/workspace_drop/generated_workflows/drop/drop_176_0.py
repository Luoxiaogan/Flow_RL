# Workflow ID: drop_176_0
# Benchmark: drop
# Data Indices: [10, 119]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify key elements (e.g., field goals over 40 yards)
        initial_instruction = "First, read the passage carefully and identify all field goals mentioned. Then determine which ones meet the condition in the question."
        step_one = await self.custom(instruction=initial_instruction)

        # Step 2: Generate multiple solutions using different reasoning strategies
        solution1 = await self.counting_reasoning()
        solution2 = await self.custom(instruction="List all field goals explicitly mentioned in the passage, then count those over 40 yards.")
        solution3 = await self.flexible_custom(
            steps=[
                {"name": "Extract Field Goals", "instruction": "Identify every field goal mentioned in the passage with its distance."},
                {"name": "Filter by Distance", "instruction": "From the list of field goals, select only those with a distance greater than 40 yards."},
                {"name": "Count", "instruction": "Count the filtered field goals to get the final answer."}
            ],
            reasoning_pattern="sequential",
            custom_instruction="Execute the multi-step filtering and counting process."
        )

        # Step 3: Use ensemble voting to pick the most consistent answer
        solutions = [solution1, solution2, solution3]
        final_answer = await self.sc_ensemble(solutions=solutions)

        return final_answer