# Workflow ID: drop_78_0
# Benchmark: drop
# Data Indices: [318, 377]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to define a multi-step reasoning pattern
        # that explores different strategies (e.g., direct extraction + arithmetic,
        # or using comparison to identify key values).
        solution_1 = await self.flexible_custom(
            reasoning_pattern="Extract relevant numbers and compute difference",
            steps=[
                "Identify all touchdown runs by Peyton Hillis.",
                "Extract yardage of first and second touchdown runs.",
                "Compute the difference between the two yardages."
            ],
            custom_instruction="Solve the problem using step-by-step extraction and arithmetic."
        )

        solution_2 = await self.flexible_custom(
            reasoning_pattern="First, find all scoring plays; then compare Hillis' runs",
            steps=[
                "List all scoring plays involving Peyton Hillis.",
                "Determine which were touchdowns and their respective yardages.",
                "Compare the two yardages to find the difference."
            ],
            custom_instruction="Use comparison reasoning to isolate Hillis’ runs and calculate the difference."
        )

        solution_3 = await self.arithmetic_reasoning()

        # Step 2: Use ScEnsemble to combine multiple solutions via voting
        ensemble_result = await self.sc_ensemble([
            solution_1,
            solution_2,
            solution_3
        ])

        # Step 3: Review the final result for clarity and correctness
        final_answer = await self.review(ensemble_result)

        return final_answer