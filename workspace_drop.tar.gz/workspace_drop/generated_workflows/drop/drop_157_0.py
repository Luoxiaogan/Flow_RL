# Workflow ID: drop_157_0
# Benchmark: drop
# Data Indices: [276, 170]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question type — extract key entities and reasoning needed
        initial_thought = await self.custom(instruction="Analyze the question to determine whether it requires counting, arithmetic, comparison, or span extraction.")
        
        # Step 2: If the question asks about a specific value (e.g., yards, number), try to locate it directly
        if "how many" in self.problem_text.lower() or "count" in self.problem_text.lower():
            count_result = await self.counting_reasoning()
            return count_result["count"]

        # Step 3: If it involves sums, differences, or numerical operations
        elif "sum", "difference", "total", "more than", "less than" in self.problem_text.lower():
            arith_result = await self.arithmetic_reasoning()
            return arith_result["result"]

        # Step 4: If it compares people, teams, or items (e.g., who made more field goals?)
        elif "who made the most", "who made the second most", "which team had more" in self.problem_text.lower():
            comp_result = await self.comparison_reasoning()
            return comp_result["result"]

        # Step 5: For questions requiring multi-step extraction (like "how many yards did keller kick?")
        else:
            # Use flexible_custom to guide step-by-step extraction + reasoning
            steps = [
                {"step": "Identify the entity mentioned in the question (e.g., Keller)."},
                {"step": "Find all relevant mentions of that entity in the passage."},
                {"step": "Extract the associated numerical value (e.g., yardage)."}
            ]
            reasoning_pattern = "sequential_extraction"
            custom_instruction = "Based on the question, first identify the key person/team, then find their action, and finally extract the numeric value."
            
            final_answer = await self.flexible_custom(
                steps=steps,
                reasoning_pattern=reasoning_pattern,
                custom_instruction=custom_instruction
            )
            
            # Optional: Review for clarity and correctness
            reviewed_answer = await self.review(pre_solution=final_answer)
            
            # Optional: Ensemble with another solution for robustness (if multiple valid interpretations exist)
            ensemble_solution = await self.sc_ensemble(solutions=[final_answer, reviewed_answer])
            
            return ensemble_solution