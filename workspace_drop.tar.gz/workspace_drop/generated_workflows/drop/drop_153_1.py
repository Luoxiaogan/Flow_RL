# Workflow ID: drop_153_1
# Benchmark: drop
# Data Indices: [135, 19]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Strategy: First extract key info using Custom, then apply specialized reasoning in parallel
        # Then use ScEnsemble to resolve discrepancies — a fundamentally different approach than the original

        # Step 1: Extract all relevant entities and numerical data from passage
        extraction = await self.custom(instruction="Extract all named entities (players, teams, events) and associated numbers mentioned in the passage. List them clearly.")

        # Step 2: Run multiple specialized reasoners in parallel — this is the key difference!
        # Instead of choosing one based on detection, we try all three and let ensemble decide
        count_result = await self.counting_reasoning()
        arithmetic_result = await self.arithmetic_reasoning()
        comparison_result = await self.comparison_reasoning()

        # Step 3: Generate a general solution via flexible custom as fallback
        fallback_solution = await self.flexible_custom(
            reasoning_pattern="chain_of_thought",
            steps=[
                "Identify what the question asks for.",
                "Locate the relevant part of the passage.",
                "Compute or retrieve the answer directly."
            ],
            custom_instruction="Now solve the question step-by-step using the extracted information."
        )

        # Step 4: Use ScEnsemble to select the most consistent answer across all four methods
        solutions = [
            str(count_result["count"]) if "count" in str(count_result).lower() else count_result,
            str(arithmetic_result["result"]) if "result" in str(arithmetic_result).lower() else arithmetic_result,
            str(comparison_result["result"]) if "result" in str(comparison_result).lower() else comparison_result,
            fallback_solution
        ]

        final_output = await self.sc_ensemble(solutions=solutions)

        return final_output