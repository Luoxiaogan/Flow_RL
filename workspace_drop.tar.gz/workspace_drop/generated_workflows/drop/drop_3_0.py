# Workflow ID: drop_3_0
# Benchmark: drop
# Data Indices: [205, 9]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Initial analysis and decomposition
        initial_thought = await self.custom(instruction="Break down the problem into key components: what needs to be extracted, what reasoning is required (counting, arithmetic, comparison), and what the final answer format should be.")

        # Step 2: Identify relevant information and perform necessary reasoning
        # Use flexible_custom to define a multi-step strategy based on problem type
        reasoning_pattern = "Extract key entities or numbers → Apply appropriate reasoning (counting/arithmetic/comparison) → Synthesize result"
        steps = [
            {"name": "extract", "instruction": "Identify all relevant numerical or textual data in the passage related to the question."},
            {"name": "reason", "instruction": "Apply counting, arithmetic, or comparison reasoning as needed based on the question."},
            {"name": "synthesize", "instruction": "Combine findings into a coherent answer that directly addresses the question."}
        ]
        solution_attempt = await self.flexible_custom(
            reasoning_pattern=reasoning_pattern,
            steps=steps,
            custom_instruction="Solve the problem step-by-step using the structured approach above."
        )

        # Step 3: Review the solution for clarity, correctness, and completeness
        refined_solution = await self.review(pre_solution=solution_attempt)

        # Step 4: If multiple solutions are available, use ensemble voting for robustness
        # For now, we only have one solution; in more complex cases, this could involve calling multiple strategies
        final_answer = refined_solution

        return final_answer