# Workflow ID: drop_123_1
# Benchmark: drop
# Data Indices: [77, 191]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: First, identify the type of reasoning required by analyzing the question
        reasoning_type = await self.custom(instruction="Determine whether this problem requires counting, arithmetic, or comparison reasoning. Output only one word: 'counting', 'arithmetic', or 'comparison'.")
        
        # Step 2: Based on the identified reasoning type, invoke the specialized expert directly
        if "counting" in reasoning_type.lower():
            result = await self.counting_reasoning()
        elif "arithmetic" in reasoning_type.lower():
            result = await self.arithmetic_reasoning()
        elif "comparison" in reasoning_type.lower():
            result = await self.comparison_reasoning()
        else:
            # Fallback to general reasoning if classification fails
            result = await self.custom(instruction="The problem requires reasoning but type was unclear. Solve it step-by-step.")
        
        # Step 3: Use FlexibleCustom to re-evaluate the solution with a structured thought process
        refined_result = await self.flexible_custom(
            steps=[
                "Re-express the answer using clear reasoning steps.",
                "Verify that the final output matches the format expected (number, date, or text span)."
            ],
            reasoning_pattern="Chain-of-Thought",
            custom_instruction="Refine the previous result using structured reasoning."
        )
        
        # Step 4: Final review to improve clarity and correctness
        final_answer = await self.review(pre_solution=refined_result)
        
        return final_answer