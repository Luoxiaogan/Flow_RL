# Workflow ID: drop_154_0
# Benchmark: drop
# Data Indices: [380, 361]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify required information extraction
        initial_thought = await self.custom(instruction="First, read the passage carefully and determine what specific information is needed to answer the question.")

        # Step 2: Use FlexibleCustom with a sequential reasoning pattern to break down the task
        # This step ensures structured, step-by-step reasoning without writing explicit Python control flow
        reasoning_plan = [
            {"step": "Extract relevant facts from the passage related to the question."},
            {"step": "Determine whether the task involves counting, arithmetic, or comparison."},
            {"step": "Apply the appropriate specialized operator (counting, arithmetic, comparison)."},
            {"step": "Review the solution for correctness and clarity."}
        ]
        
        final_solution = await self.flexible_custom(
            reasoning_pattern="sequential",
            steps=reasoning_plan,
            custom_instruction="Based on the plan, execute each step logically. Do not skip any steps."
        )

        # Step 3: If the solution seems ambiguous or incomplete, review it
        reviewed_solution = await self.review(pre_solution=final_solution)

        # Step 4: To ensure robustness, generate multiple solutions via ensemble if needed
        # For now, we assume one good solution exists — but this structure allows future expansion
        final_answer = await self.sc_ensemble(solutions=[reviewed_solution])

        return final_answer