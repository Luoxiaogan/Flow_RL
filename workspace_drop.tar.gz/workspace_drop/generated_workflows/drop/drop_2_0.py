# Workflow ID: drop_2_0
# Benchmark: drop
# Data Indices: [0, 334]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question type (counting, arithmetic, comparison)
        initial_thought = await self.custom(instruction="Analyze the question and determine whether it requires counting, arithmetic, or comparison reasoning.")

        # Step 2: Route to appropriate specialized operator based on the question type
        if "how many" in initial_thought.lower() or "count" in initial_thought.lower():
            result = await self.counting_reasoning()
            return result["count"]
        elif "sum", "difference", "total", "more than", "less than" in initial_thought.lower():
            result = await self.arithmetic_reasoning()
            return result["result"]
        elif "which players", "shortest", "longest", "most", "least", "compare" in initial_thought.lower():
            result = await self.comparison_reasoning()
            return result["result"]
        else:
            # Fallback: Use flexible custom for complex multi-step problems
            final_result = await self.flexible_custom(
                steps=[
                    {"name": "understand_question", "instruction": "First, clearly identify what needs to be found."},
                    {"name": "extract_info", "instruction": "Next, extract relevant information from the passage."},
                    {"name": "reason", "instruction": "Now, apply logical reasoning to derive the answer."}
                ],
                reasoning_pattern="sequential",
                custom_instruction="Generate a final answer based on the extracted facts and reasoning."
            )
            return final_result