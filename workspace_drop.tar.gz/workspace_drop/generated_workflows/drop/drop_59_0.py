# Workflow ID: drop_59_0
# Benchmark: drop
# Data Indices: [97, 87]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and extract relevant information
        initial_thought = await self.custom(instruction="First, read the question carefully and identify what needs to be extracted or computed from the passage.")
        
        # Step 2: Determine the type of reasoning needed (counting, arithmetic, comparison, or extraction)
        reasoning_type = await self.custom(instruction=f"Based on the question: '{initial_thought}', determine whether this requires counting, arithmetic, comparison, or simple text extraction.")

        # Step 3: Apply the appropriate specialized reasoning operator
        if "count" in reasoning_type.lower():
            result = await self.counting_reasoning()
        elif "arithmetic" in reasoning_type.lower() or "sum" in reasoning_type.lower() or "difference" in reasoning_type.lower():
            result = await self.arithmetic_reasoning()
        elif "compare" in reasoning_type.lower() or "sort" in reasoning_type.lower() or "which" in reasoning_type.lower():
            result = await self.comparison_reasoning()
        else:
            # Fallback to general custom reasoning if no clear pattern
            result = await self.custom(instruction="Extract the answer directly from the passage based on the question.")

        # Step 4: If needed, refine the solution using review
        refined_result = await self.review(pre_solution=result)

        # Step 5: Use ensemble voting if multiple solutions exist (optional but robust)
        final_answer = await self.sc_ensemble(solutions=[refined_result])

        return final_answer