# Workflow ID: drop_72_1
# Benchmark: drop
# Data Indices: [164, 351]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Get a general understanding of the question
        initial_thought = await self.custom(instruction="First, identify what type of reasoning is needed: counting, arithmetic, or comparison.")

        # Step 2: Generate multiple candidate solutions using different strategies
        # Strategy A: Use specialized operator directly based on instruction
        strategy_a = await self.flexible_custom(
            reasoning_pattern="step_by_step",
            steps=[
                "Identify key numerical values in the passage relevant to the question.",
                "Determine the required operation (e.g., subtraction for 'how many longer').",
                "Compute the answer using arithmetic reasoning."
            ],
            custom_instruction="Solve using structured arithmetic reasoning."
        )

        # Strategy B: Use comparison reasoning if it's about relative differences
        strategy_b = await self.comparison_reasoning()

        # Strategy C: Try flexible custom with explicit instruction
        strategy_c = await self.flexible_custom(
            reasoning_pattern="step_by_step",
            steps=[
                "Extract all relevant numbers from the passage.",
                "Apply logical operations step-by-step to compute the final result.",
                "Ensure the output matches the expected format (number, date, or span)."
            ],
            custom_instruction="Solve the problem by extracting and processing key numbers."
        )

        # Step 3: Use ensemble to select the most consistent solution
        solutions = [strategy_a, strategy_b, strategy_c]
        final_answer = await self.sc_ensemble(solutions=solutions)

        return final_answer