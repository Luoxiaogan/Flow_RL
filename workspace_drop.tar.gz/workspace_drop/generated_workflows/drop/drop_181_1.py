# Workflow ID: drop_181_1
# Benchmark: drop
# Data Indices: [14, 322]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Extract key facts using Custom — focus on identifying relevant numbers or events
        extraction = await self.custom(instruction="Identify all numerical values and temporal references in the passage that may be relevant to answering the question.")

        # Step 2: Use FlexibleCustom to define a multi-step reasoning plan based on the question type
        reasoning_pattern = "Determine whether the task requires counting, arithmetic, or comparison. Then apply the appropriate reasoning step-by-step."
        steps = [
            "Extract all relevant numbers and dates",
            "Classify the reasoning type (counting/arithmetic/comparison)",
            "Apply the corresponding specialized operator",
            "Return only the final answer"
        ]
        structured_solution = await self.flexible_custom(
            reasoning_pattern=reasoning_pattern,
            steps=steps,
            custom_instruction=f"Given the extracted facts: {extraction}, now solve the problem by following the defined steps."
        )

        # Step 3: Review the structured solution for clarity and correctness before finalizing
        reviewed_solution = await self.review(pre_solution=structured_solution)

        # Step 4: Final validation via ensemble — only include the structured solution and one fallback (e.g., raw arithmetic)
        fallback = await self.arithmetic_reasoning()
        final_answer = await self.sc_ensemble(solutions=[reviewed_solution, fallback])

        return final_answer