# Workflow ID: drop_48_0
# Benchmark: drop
# Data Indices: [62, 93]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the task by breaking it down
        initial_thought = await self.custom(instruction="First, identify what kind of reasoning is needed: counting, arithmetic, comparison, or a mix. Then determine the key entities in the passage relevant to the question.")

        # Step 2: Generate an initial solution based on the understanding
        initial_solution = await self.custom(instruction=f"Based on the initial thought: {initial_thought}, now generate a direct answer to the question using only information from the passage.")

        # Step 3: Review and refine the solution for correctness and clarity
        refined_solution = await self.review(pre_solution=initial_solution)

        # Step 4: If the problem involves multiple candidates (like comparing percentages), use comparison reasoning
        if "most common" in self.problem_text.lower() or "which was most" in self.problem_text.lower():
            comparison_result = await self.comparison_reasoning()
            final_answer = comparison_result["result"]
        elif "percent" in self.problem_text.lower() and "not" in self.problem_text.lower():
            # Handle questions like "How many percent were not from 18 to 24?"
            arithmetic_result = await self.arithmetic_reasoning()
            final_answer = arithmetic_result["result"]
        else:
            # For other cases, fall back to the refined solution
            final_answer = refined_solution

        # Step 5: Use ensemble voting if there's ambiguity or high confidence needed
        ensemble_result = await self.sc_ensemble(solutions=[initial_solution, refined_solution, final_answer])

        return ensemble_result