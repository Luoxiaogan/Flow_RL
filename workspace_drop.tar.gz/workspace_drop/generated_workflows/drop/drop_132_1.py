# Workflow ID: drop_132_1
# Benchmark: drop
# Data Indices: [365, 188]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to define a structured multi-step reasoning plan
        # This avoids hardcoded conditionals and instead uses pattern-driven logic
        reasoning_pattern = {
            "steps": [
                {"task": "identify_question_type", "instruction": "Determine whether this is a counting, arithmetic, or comparison question."},
                {"task": "extract_relevant_data", "instruction": "Based on the identified type, extract all relevant numerical or textual data from the passage."},
                {"task": "apply_specialized_reasoning", "instruction": "Apply the correct reasoning operator based on the question type: Counting for counts, Arithmetic for math, Comparison for sorting/longest/shortest."}
            ],
            "output_format": "final_answer"
        }

        # Execute flexible custom logic with defined steps
        intermediate_solution = await self.flexible_custom(
            reasoning_pattern=reasoning_pattern,
            steps=["identify_question_type", "extract_relevant_data", "apply_specialized_reasoning"],
            custom_instruction="Use the structured plan above to solve the problem step-by-step."
        )

        # Step 2: Review the solution to improve clarity and correctness
        reviewed_solution = await self.review(pre_solution=intermediate_solution)

        # Step 3: Use ScEnsemble to validate against alternative interpretations (if needed)
        # Even if only one path was taken, we simulate ensemble by generating a few variations
        # This enforces robustness through internal consistency checking
        ensemble_solutions = [intermediate_solution, reviewed_solution]
        final_answer = await self.sc_ensemble(solutions=ensemble_solutions)

        return final_answer