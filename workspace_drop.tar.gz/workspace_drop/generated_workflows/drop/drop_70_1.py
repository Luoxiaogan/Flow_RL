# Workflow ID: drop_70_1
# Benchmark: drop
# Data Indices: [138, 60]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to explore multiple reasoning paths in parallel
        # This introduces a fundamentally different logic structure — parallel exploration instead of sequential routing
        parallel_solutions = await self.flexible_custom(
            reasoning_pattern="parallel",
            steps=[
                {"name": "counting", "instruction": "Identify if the question requires counting items or events in the passage."},
                {"name": "arithmetic", "instruction": "Determine if the question involves sums, differences, or numerical operations on extracted values."},
                {"name": "comparison", "instruction": "Check whether the question asks for comparisons (e.g., which is more, earlier/later)."}
            ],
            custom_instruction="Generate independent solutions using each reasoning pattern. Return all three."
        )

        # Step 2: Use ScEnsemble to evaluate and select the most consistent answer across all strategies
        final_answer = await self.sc_ensemble(solutions=[parallel_solutions])

        # Step 3: Review the final ensemble result to enhance clarity and correctness
        reviewed_final = await self.review(pre_solution=final_answer)

        return reviewed_final