# Workflow ID: drop_151_0
# Benchmark: drop
# Data Indices: [153, 309]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question type and extract relevant information
        initial_thought = await self.custom(instruction="First, identify what kind of reasoning is needed: counting, arithmetic, comparison, or extraction. Then locate key entities in the passage related to the question.")
        
        # Step 2: Use FlexibleCustom with a sequential reasoning pattern to guide step-by-step processing
        solution = await self.flexible_custom(
            reasoning_pattern="sequential",
            steps=[
                "Identify the specific event or entity mentioned in the question.",
                "Extract all relevant information from the passage that pertains to this event or entity.",
                "Determine whether the answer requires counting, arithmetic, comparison, or direct extraction."
            ],
            custom_instruction="Based on the above steps, solve the problem now."
        )

        # Step 3: If the task involves counting, invoke specialized counting reasoning
        if "count" in solution.lower() or "how many" in solution.lower():
            count_result = await self.counting_reasoning()
            final_answer = count_result['count']
        # Step 4: If it involves math, use arithmetic reasoning
        elif any(op in solution.lower() for op in ["sum", "difference", "total", "increase", "decrease"]):
            arith_result = await self.arithmetic_reasoning()
            final_answer = arith_result['result']
        # Step 5: If it's about ordering or comparing, use comparison reasoning
        elif any(op in solution.lower() for op in ["earlier", "later", "oldest", "youngest", "most", "least"]):
            comp_result = await self.comparison_reasoning()
            final_answer = comp_result['result']
        # Step 6: Otherwise, assume it's a span-based or direct extraction task
        else:
            final_answer = solution

        # Step 7: Optional refinement using review for robustness
        reviewed_answer = await self.review(pre_solution=str(final_answer))
        
        # Step 8: Final ensemble check if multiple solutions were generated (e.g., via branching paths)
        # Since we have only one path here, skip sc_ensemble unless we explicitly generate alternatives
        return reviewed_answer