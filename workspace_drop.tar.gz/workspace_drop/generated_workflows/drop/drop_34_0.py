# Workflow ID: drop_34_0
# Benchmark: drop
# Data Indices: [35, 183]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question type and identify required reasoning
        initial_thought = await self.custom(instruction="First, analyze the question to determine whether it requires counting, arithmetic, or comparison reasoning.")

        # Step 2: Extract relevant numerical information from the passage
        extraction = await self.custom(instruction="Identify all numbers and their context in the passage that relate to the question. Focus only on what's needed for solving the problem.")

        # Step 3: Determine which reasoning operator is most appropriate based on the question
        reasoning_type = await self.custom(instruction="Based on the extracted information and the question, decide whether this problem requires counting, arithmetic, or comparison reasoning.")

        # Step 4: Apply the specialized reasoning operator
        if "count" in reasoning_type.lower():
            result = await self.counting_reasoning()
        elif "arithmetic" in reasoning_type.lower() or "difference" in reasoning_type.lower() or "increase" in reasoning_type.lower() or "drop" in reasoning_type.lower():
            result = await self.arithmetic_reasoning()
        elif "compare" in reasoning_type.lower() or "which is more" in reasoning_type.lower() or "greater than" in reasoning_type.lower():
            result = await self.comparison_reasoning()
        else:
            # Fallback to general custom reasoning
            result = await self.custom(instruction="Use step-by-step logical deduction to solve the problem based on the extracted facts.")

        # Step 5: Finalize answer by reviewing and ensuring clarity
        final_answer = await self.review(pre_solution=result)

        # Optional: Use ensemble for robustness if multiple solutions are possible (e.g., in ambiguous cases)
        # For now, we assume a single clear path — but this structure allows future expansion
        return final_answer