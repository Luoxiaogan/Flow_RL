# Workflow ID: drop_93_0
# Benchmark: drop
# Data Indices: [200, 222]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Initial breakdown of the problem — identify what kind of reasoning is needed
        initial_thought = await self.custom(instruction="Identify whether this is a counting, arithmetic, comparison, or span-extraction task based on the question and passage.")

        # Step 2: Based on the identified task type, invoke appropriate specialized operator
        if "count" in initial_thought.lower():
            solution = await self.counting_reasoning()
        elif "arithmetic" in initial_thought.lower() or "sum" in initial_thought.lower() or "difference" in initial_thought.lower():
            solution = await self.arithmetic_reasoning()
        elif "compare" in initial_thought.lower() or "smaller" in initial_thought.lower() or "larger" in initial_thought.lower():
            solution = await self.comparison_reasoning()
        else:
            # Default fallback: use custom to generate an answer directly
            solution = await self.custom(instruction="Generate a direct answer based on the passage and question.")

        # Step 3: Refine the solution using Review to improve accuracy
        refined_solution = await self.review(pre_solution=solution)

        # Step 4: Use ScEnsemble to enhance robustness by comparing multiple attempts (if applicable)
        # Since we only have one solution so far, simulate a second attempt with slightly different instruction
        alternate_solution = await self.custom(instruction="Solve the problem again, focusing on precise extraction from the passage.")
        final_solution = await self.sc_ensemble(solutions=[refined_solution, alternate_solution])

        return final_solution