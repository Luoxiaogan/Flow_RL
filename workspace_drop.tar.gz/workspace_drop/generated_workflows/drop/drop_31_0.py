# Workflow ID: drop_31_0
# Benchmark: drop
# Data Indices: [270, 224]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question type by analyzing the query
        instruction = "Determine whether this is a counting, arithmetic, or comparison task based on the question."
        initial_analysis = await self.custom(instruction=instruction)

        # Step 2: Based on the analysis, choose the appropriate reasoning operator
        if "count" in initial_analysis.lower():
            result = await self.counting_reasoning()
            return result["count"]
        elif "sum" in initial_analysis.lower() or "difference" in initial_analysis.lower() or "total" in initial_analysis.lower():
            result = await self.arithmetic_reasoning()
            return result["result"]
        elif "more" in initial_analysis.lower() or "less" in initial_analysis.lower() or "compare" in initial_analysis.lower():
            result = await self.comparison_reasoning()
            return result["result"]
        else:
            # Fallback to flexible custom for complex or ambiguous cases
            final_solution = await self.flexible_custom(
                steps=[
                    {"name": "analyze_question", "instruction": "Identify what needs to be found: count, compute, or compare?"},
                    {"name": "select_operator", "instruction": "Based on the analysis, decide which specialized operator to use."},
                    {"name": "execute", "instruction": "Execute the chosen reasoning step."}
                ],
                reasoning_pattern="sequential",
                custom_instruction="Solve the problem using the structured plan above."
            )
            return final_solution