# Workflow ID: drop_48_1
# Benchmark: drop
# Data Indices: [62, 93]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Strategy: Use FlexibleCustom to define a multi-step reasoning pattern that explores different approaches in parallel
        # Then apply ScEnsemble to resolve inconsistencies — this is fundamentally different from the existing workflow's linear flow

        # Step 1: Define a flexible reasoning plan that includes multiple strategies (e.g., arithmetic + comparison + counting)
        reasoning_pattern = [
            {"step": "identify_question_type", "instruction": "Determine whether the question requires counting, arithmetic, or comparison."},
            {"step": "extract_relevant_data", "instruction": "Extract all numerical data relevant to answering the question from the passage."},
            {"step": "apply_arithmetic_if_needed", "instruction": "If the question involves percentages or totals, compute using arithmetic reasoning."},
            {"step": "apply_comparison_if_needed", "instruction": "If comparing categories (e.g., most common), use comparison reasoning to rank them."},
            {"step": "generate_answer", "instruction": "Synthesize a final answer based on previous steps."}
        ]

        # Step 2: Execute the flexible custom workflow with structured steps
        flexible_solution = await self.flexible_custom(
            reasoning_pattern=reasoning_pattern,
            steps=reasoning_pattern,
            custom_instruction="Solve the problem by following the defined logical steps."
        )

        # Step 3: Generate an alternative solution using a completely different strategy — e.g., start with comparison first
        alt_solution = await self.custom(instruction="First, identify the top candidate(s) by comparing all listed values. Then verify against the question.")

        # Step 4: Review both solutions to improve clarity and correctness
        reviewed_flexible = await self.review(pre_solution=flexible_solution)
        reviewed_alt = await self.review(pre_solution=alt_solution)

        # Step 5: Use ScEnsemble to choose the most consistent answer across two distinct reasoning paths
        ensemble_result = await self.sc_ensemble(solutions=[reviewed_flexible, reviewed_alt])

        return ensemble_result