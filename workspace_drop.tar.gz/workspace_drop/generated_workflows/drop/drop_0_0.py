# Workflow ID: drop_0_0
# Benchmark: drop
# Data Indices: [5, 166]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the task type and extract relevant info
        initial_thought = await self.custom(instruction="First, identify whether the question requires counting, arithmetic, comparison, or span extraction. Then determine what entities or values need to be extracted from the passage.")
        
        # Step 2: Generate multiple solutions using different reasoning strategies
        solution1 = await self.custom(instruction="Use step-by-step extraction to find the answer. First locate all key events in the passage related to the question, then apply logical reasoning based on the context.")
        solution2 = await self.arithmetic_reasoning()
        solution3 = await self.comparison_reasoning()
        solution4 = await self.counting_reasoning()

        # Step 3: Use ScEnsemble to select the most consistent answer across multiple approaches
        final_solution = await self.sc_ensemble(solutions=[solution1, solution2, solution3, solution4])
        
        # Optional: Review for refinement (use only if ensemble doesn't yield confidence)
        # final_solution = await self.review(pre_solution=final_solution)

        return final_solution