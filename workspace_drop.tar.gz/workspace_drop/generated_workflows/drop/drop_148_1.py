# Workflow ID: drop_148_1
# Benchmark: drop
# Data Indices: [300, 13]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to define a multi-step reasoning pattern tailored to DROP-style problems
        # This step explicitly structures the workflow as "Extract → Reason → Validate", which is different from the existing approach
        structured_reasoning = await self.flexible_custom(
            reasoning_pattern="extract-reason-validate",
            steps=[
                {"name": "extract", "instruction": "Identify all relevant entities and numerical facts from the passage that relate to the question."},
                {"name": "reason", "instruction": "Apply appropriate discrete reasoning (counting, arithmetic, comparison) based on the extracted facts."},
                {"name": "validate", "instruction": "Check whether the final answer matches the expected type (number, date, or span) and make sure it logically follows from the reasoning."}
            ],
            custom_instruction="Begin by extracting key information from the passage. Then reason using counting, arithmetic, or comparison as needed. Finally, validate the answer format and correctness."
        )

        # Step 2: Use Review to refine the structured solution — this happens *after* the flexible custom step instead of after ensemble
        refined_solution = await self.review(pre_solution=structured_reasoning)

        # Step 3: Apply ScEnsemble not on multiple strategies but on multiple independent attempts — a different parallel strategy
        # We simulate multiple independent tries with slight prompt variation to capture diverse reasoning paths
        attempt_1 = await self.custom(instruction="Solve the problem directly without intermediate steps.")
        attempt_2 = await self.arithmetic_reasoning()
        attempt_3 = await self.comparison_reasoning()

        final_answer = await self.sc_ensemble(solutions=[refined_solution, attempt_1, attempt_2, attempt_3])

        return final_answer