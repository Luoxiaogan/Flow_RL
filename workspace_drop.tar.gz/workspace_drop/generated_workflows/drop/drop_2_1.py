# Workflow ID: drop_2_1
# Benchmark: drop
# Data Indices: [0, 334]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Strategy: First generate a solution using FlexibleCustom to capture diverse reasoning paths
        # Then evaluate multiple solutions via ScEnsemble to find consensus
        # Finally, review the best candidate for refinement
        
        # Step 1: Generate multiple initial hypotheses using flexible custom with different prompts
        solutions = []
        for i in range(3):
            prompt = f"Generate a solution to this question. Think step-by-step and explain your reasoning clearly."
            if i == 0:
                prompt += " Focus on identifying key numerical or comparative elements in the passage."
            elif i == 1:
                prompt += " Prioritize extracting exact spans or dates mentioned in the text."
            else:
                prompt += " Emphasize logical consistency between the question and the answer."
            
            solution = await self.flexible_custom(
                steps=[
                    {"name": "reason", "instruction": prompt}
                ],
                reasoning_pattern="sequential",
                custom_instruction="Provide a final answer based on your reasoning above."
            )
            solutions.append(solution)
        
        # Step 2: Use ensemble to select the most consistent answer across all generated solutions
        ensemble_result = await self.sc_ensemble(solutions)
        
        # Step 3: Review the ensemble result to refine it further if needed
        final_answer = await self.review(pre_solution=ensemble_result)
        
        return final_answer