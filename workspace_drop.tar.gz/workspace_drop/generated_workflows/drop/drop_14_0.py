# Workflow ID: drop_14_0
# Benchmark: drop
# Data Indices: [24, 290]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Get initial understanding of the problem
        initial_thought = await self.custom(instruction="First, identify what type of reasoning is required (e.g., counting, arithmetic, comparison, or span extraction). Then determine what information must be extracted from the passage to answer the question.")
        
        # Step 2: Generate multiple solutions using different strategies
        solution1 = await self.custom(instruction=f"Based on the initial thought: {initial_thought}, now solve the problem directly by extracting relevant facts and reasoning step-by-step.")
        
        solution2 = await self.custom(instruction=f"Think about the question again: What specific event or detail must be found in the passage? Use structured thinking to isolate the key part of the text that answers it.")
        
        solution3 = await self.flexible_custom(
            steps=[
                "Identify all named entities or time references in the passage.",
                "Determine which ones relate to the question asked.",
                "Extract the exact phrase or number that answers the question."
            ],
            reasoning_pattern="extract_and_select",
            custom_instruction="Now apply this pattern to extract the correct answer from the passage."
        )
        
        # Step 3: Use ScEnsemble to select the most consistent answer across the three approaches
        final_answer = await self.sc_ensemble(solutions=[solution1, solution2, solution3])
        
        return final_answer