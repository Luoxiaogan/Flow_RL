# Workflow ID: drop_109_0
# Benchmark: drop
# Data Indices: [386, 341]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Initial breakdown of the problem using Custom
        initial_thought = await self.custom(instruction="First, identify what needs to be counted or calculated. Is this a counting, arithmetic, or comparison task?")

        # Step 2: Generate multiple reasoning paths (parallel ensemble strategy)
        solution_a = await self.custom(instruction="Use counting reasoning to count touchdowns and field goals separately, then compute the difference.")
        solution_b = await self.arithmetic_reasoning()
        solution_c = await self.flexible_custom(
            steps=[
                {"task": "Extract all relevant numbers from the passage"},
                {"task": "Determine which operations (addition, subtraction, etc.) apply"},
                {"task": "Compute the final result"}
            ],
            reasoning_pattern="sequential",
            custom_instruction="Apply step-by-step numerical reasoning based on extracted values."
        )

        # Step 3: Use ScEnsemble to select the most consistent answer across solutions
        final_answer = await self.sc_ensemble(solutions=[solution_a, solution_b, solution_c])

        return final_answer