# Workflow ID: drop_129_0
# Benchmark: drop
# Data Indices: [324, 316]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify required reasoning type
        initial_thought = await self.custom(instruction="First, analyze the question to determine whether it requires counting, arithmetic, comparison, or a combination of these. Identify key entities and numerical values in the passage relevant to the question.")

        # Step 2: Extract relevant information from the passage
        extraction = await self.custom(instruction="Extract all numbers and related contextual phrases from the passage that could be relevant to answering the question. List them clearly.")

        # Step 3: Determine the appropriate reasoning operator based on the question type
        reasoning_type = await self.custom(instruction="Based on the question and extracted data, decide which reasoning step is needed next: counting, arithmetic, or comparison. If multiple steps are needed, outline the sequence.")

        # Step 4: Execute the identified reasoning step(s)
        if "count" in reasoning_type.lower():
            result = await self.counting_reasoning()
        elif "arithmetic" in reasoning_type.lower() or "sum" in reasoning_type.lower() or "difference" in reasoning_type.lower():
            result = await self.arithmetic_reasoning()
        elif "compare" in reasoning_type.lower() or "sort" in reasoning_type.lower():
            result = await self.comparison_reasoning()
        else:
            # Fallback: use custom for general reasoning
            result = await self.custom(instruction="Use general reasoning to solve the problem based on the context and extracted information.")

        # Step 5: Final answer formatting and validation
        final_answer = await self.custom(instruction=f"Using the reasoning result: {result}, format the final answer directly as a number, date, or text span. Do not add explanations unless explicitly asked.")
        
        return final_answer