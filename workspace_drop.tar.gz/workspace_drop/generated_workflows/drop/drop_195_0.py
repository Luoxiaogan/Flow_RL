# Workflow ID: drop_195_0
# Benchmark: drop
# Data Indices: [137, 245]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify required reasoning type
        initial_thought = await self.custom(instruction="First, analyze the question to determine what kind of reasoning is needed: counting, arithmetic, comparison, or span extraction.")

        # Step 2: Use FlexibleCustom with a strategic reasoning pattern to guide multi-step processing
        reasoning_pattern = "sequential"  # We'll break it down step-by-step
        steps = [
            {"name": "Identify key entities", "instruction": "Extract all relevant named entities (e.g., teams, people, dates, numbers) from the passage."},
            {"name": "Determine task type", "instruction": "Based on the question, decide whether this requires counting, arithmetic, comparison, or text span extraction."},
            {"name": "Apply specialized reasoning", "instruction": "Use the appropriate operator (counting, arithmetic, comparison) based on the identified task type."},
            {"name": "Verify final answer", "instruction": "Check if the result makes sense in context and aligns with the question."}
        ]
        
        structured_solution = await self.flexible_custom(
            reasoning_pattern=reasoning_pattern,
            steps=steps,
            custom_instruction="Execute the reasoning steps to solve the problem."
        )

        # Step 3: If multiple solutions exist, apply ensemble voting for robustness
        # For now, we assume one solution path — but we're ready to scale
        final_answer = await self.custom(instruction=f"Based on the structured solution: {structured_solution}, provide the final answer directly.")
        
        # Optional: Review for refinement
        reviewed_answer = await self.review(pre_solution=final_answer)
        
        return reviewed_answer