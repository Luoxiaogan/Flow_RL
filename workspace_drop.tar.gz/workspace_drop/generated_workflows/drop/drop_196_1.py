# Workflow ID: drop_196_1
# Benchmark: drop
# Data Indices: [112, 134]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to define a multi-step reasoning plan — this is the key differentiator!
        # Instead of branching on keywords, we use structured logic to first identify the task type,
        # then apply the appropriate specialized operator in sequence.
        reasoning_plan = await self.flexible_custom(
            reasoning_pattern="Identify the type of reasoning required (counting, arithmetic, or comparison), then execute accordingly.",
            steps=[
                {"name": "identify_task", "instruction": "Determine whether the question requires counting, arithmetic, or comparison."},
                {"name": "execute_task", "instruction": "Based on the identified task type, use the correct specialized operator."}
            ],
            custom_instruction="Analyze the question and decide which reasoning type it needs."
        )

        # Step 2: Parse the flexible custom output to determine what kind of reasoning was chosen
        # This step uses Custom again to interpret the outcome of the FlexibleCustom step
        interpretation = await self.custom(instruction=f"Interpret the following reasoning plan: {reasoning_plan}. Extract the task type (counting/arithmetic/comparison).")

        # Step 3: Now perform the actual reasoning based on the interpreted task type
        if "counting" in interpretation.lower():
            result = await self.counting_reasoning()
            final_answer = result["count"]
        elif "arithmetic" in interpretation.lower():
            result = await self.arithmetic_reasoning()
            final_answer = result["result"]
        elif "comparison" in interpretation.lower():
            result = await self.comparison_reasoning()
            final_answer = result["result"]
        else:
            # Fallback: general reasoning if no clear task type found
            final_answer = await self.custom(instruction="Think step-by-step and solve the problem.")

        # Step 4: Use ScEnsemble not at the end but as a mid-level check — this changes strategy!
        # Generate two alternative solutions using different instructions for robustness
        alt_solution_1 = await self.custom(instruction="Solve the problem using a direct extraction approach.")
        alt_solution_2 = await self.custom(instruction="Break down the problem into smaller parts and solve each part individually.")
        
        # Ensemble these with the original solution
        all_solutions = [str(final_answer), alt_solution_1, alt_solution_2]
        final_answer = await self.sc_ensemble(solutions=all_solutions)

        # Step 5: Final review to polish clarity and correctness
        reviewed_answer = await self.review(pre_solution=str(final_answer))
        
        return reviewed_answer