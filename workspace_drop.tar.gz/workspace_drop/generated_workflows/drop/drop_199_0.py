# Workflow ID: drop_199_0
# Benchmark: drop
# Data Indices: [323, 167]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify required information extraction
        initial_thought = await self.custom(instruction="First, read the question carefully and determine what specific quantities or items need to be extracted from the passage.")
        
        # Step 2: Extract relevant numerical data (e.g., counts, values)
        extraction_step = await self.custom(instruction=f"Based on the question: '{initial_thought}', extract all relevant numbers mentioned in the passage that relate to the query. Only list the raw numbers and their context.")
        
        # Step 3: Determine the type of reasoning needed (counting, arithmetic, comparison)
        reasoning_type = await self.custom(instruction=f"Analyze the extracted data: {extraction_step}. Decide whether this requires counting, arithmetic, or comparison reasoning.")
        
        # Step 4: Perform the appropriate reasoning step
        if "count" in reasoning_type.lower():
            result = await self.counting_reasoning()
        elif "arithmetic" in reasoning_type.lower():
            result = await self.arithmetic_reasoning()
        elif "compare" in reasoning_type.lower() or "sort" in reasoning_type.lower():
            result = await self.comparison_reasoning()
        else:
            # Fallback to custom reasoning if no clear pattern
            result = await self.custom(instruction=f"Use logical reasoning to solve based on the extracted info: {extraction_step}.")
        
        # Step 5: Format final answer clearly
        final_answer = await self.custom(instruction=f"Using the reasoning result: {result}, format the final answer clearly as a number, date, or span of text exactly as required by the question.")
        
        return final_answer