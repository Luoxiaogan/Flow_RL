# Workflow ID: drop_183_1
# Benchmark: drop
# Data Indices: [267, 254]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Generate multiple distinct reasoning paths using FlexibleCustom
        solutions = []
        
        # Path A: Direct counting (if question asks "how many")
        path_a = await self.flexible_custom(
            steps=[
                {"name": "identify", "instruction": "Identify all instances in the passage that match the key term from the question."},
                {"name": "count", "instruction": "Count these instances explicitly."}
            ],
            reasoning_pattern="Chain-of-Thought",
            custom_instruction="Solve the problem by first identifying relevant entities and then counting them."
        )
        
        # Path B: Arithmetic-based extraction (e.g., percentages or ratios)
        path_b = await self.flexible_custom(
            steps=[
                {"name": "extract", "instruction": "Extract numerical data related to the target metric from the passage."},
                {"name": "compute", "instruction": "Use arithmetic operations to derive the answer based on extracted numbers."}
            ],
            reasoning_pattern="Plan-and-Solve",
            custom_instruction="Solve this as an arithmetic problem by extracting relevant numbers and computing the result."
        )
        
        # Path C: Review-based refinement of initial custom solution
        initial_guess = await self.custom(instruction="First, provide a direct answer based on your understanding of the question.")
        refined_answer = await self.review(pre_solution=initial_guess)
        
        # Add all three approaches to ensemble pool
        solutions.extend([path_a, path_b, refined_answer])
        
        # Step 2: Use ScEnsemble to select the most consistent answer across diverse strategies
        final_result = await self.sc_ensemble(solutions=solutions)
        
        return final_result