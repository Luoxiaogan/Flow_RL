# Workflow ID: drop_110_0
# Benchmark: drop
# Data Indices: [160, 357]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question type and identify required reasoning
        initial_thought = await self.custom(instruction="Analyze the question to determine whether it requires counting, arithmetic, comparison, or a combination. Identify key entities and numerical relationships in the passage.")

        # Step 2: Use FlexibleCustom with a sequential reasoning pattern to break down the problem step-by-step
        structured_analysis = await self.flexible_custom(
            reasoning_pattern="sequential",
            steps=[
                "Identify all relevant events or mentions in the passage that relate directly to the question.",
                "Extract numbers, spans, or named entities that need to be counted, compared, or used in calculations.",
                "Determine which specialized operator (counting, arithmetic, comparison) best fits each sub-task."
            ],
            custom_instruction="Based on the initial thought, now perform structured analysis of the passage to prepare for reasoning steps."
        )

        # Step 3: If the question involves counting (e.g., number of 2-point conversions), use CountingReasoning
        if "count" in initial_thought.lower() or "how many" in initial_thought.lower():
            count_result = await self.counting_reasoning()
            final_answer = count_result['count']
        
        # Step 4: If the question involves arithmetic operations (e.g., totals, differences), use ArithmeticReasoning
        elif "sum" in initial_thought.lower() or "total" in initial_thought.lower() or "difference" in initial_thought.lower():
            arithmetic_result = await self.arithmetic_reasoning()
            final_answer = arithmetic_result['result']
        
        # Step 5: If the question involves comparisons (e.g., who had more, longest tenure), use ComparisonReasoning
        elif "which" in initial_thought.lower() and ("longest" in initial_thought.lower() or "more" in initial_thought.lower()):
            comparison_result = await self.comparison_reasoning()
            final_answer = comparison_result['result']
        
        # Step 6: For complex multi-step problems, fall back to Custom for general reasoning
        else:
            final_answer = await self.custom(instruction=f"Use general reasoning to solve the problem based on the structured analysis: {structured_analysis}")

        # Step 7: Optional refinement using Review for improved accuracy
        refined_answer = await self.review(pre_solution=final_answer)

        # Step 8: Optional ensemble voting if multiple solutions exist (e.g., after trying different approaches)
        # Since we don't have multiple independent solutions yet, skip sc_ensemble unless needed later

        return refined_answer