# Workflow ID: drop_7_0
# Benchmark: drop
# Data Indices: [241, 42]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question type and identify required reasoning
        initial_thought = await self.custom(instruction="Analyze the question to determine whether it requires counting, arithmetic, comparison, or a combination. Identify key entities and quantities in the passage.")

        # Step 2: Use FlexibleCustom with a sequential reasoning pattern to break down the task
        reasoning_steps = [
            "Extract all relevant numerical values and associated entities from the passage.",
            "Identify which part of the question needs to be answered (e.g., count, compare, compute).",
            "Apply the appropriate specialized operator based on the identified reasoning type."
        ]
        structured_analysis = await self.flexible_custom(
            steps=reasoning_steps,
            reasoning_pattern="sequential",
            custom_instruction="Based on the initial thought: {initial_thought}, now perform step-by-step analysis to solve the problem."
        )

        # Step 3: Determine the specific task — e.g., counting, comparing, or computing
        task_type = await self.custom(instruction="Determine if the problem involves counting, arithmetic, or comparison based on the structured analysis.")
        
        # Step 4: Apply the correct specialized operator
        if "count" in task_type.lower():
            result = await self.counting_reasoning()
        elif "arithmetic" in task_type.lower():
            result = await self.arithmetic_reasoning()
        elif "compare" in task_type.lower() or "which" in task_type.lower():
            result = await self.comparison_reasoning()
        else:
            # Fallback: use Custom for complex reasoning not covered by specialized operators
            result = await self.custom(instruction=f"Given the structured analysis: {structured_analysis}, solve the problem using general reasoning.")

        # Step 5: Review the solution for correctness and clarity
        reviewed_solution = await self.review(pre_solution=result)

        # Step 6: Use ScEnsemble to improve robustness by combining multiple solutions if needed
        ensemble_solutions = [result, reviewed_solution]
        final_answer = await self.sc_ensemble(solutions=ensemble_solutions)

        return final_answer