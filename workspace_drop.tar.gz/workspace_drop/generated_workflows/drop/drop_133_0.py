# Workflow ID: drop_133_0
# Benchmark: drop
# Data Indices: [292, 257]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question type by analyzing the query
        initial_thought = await self.custom(instruction="Analyze the question to determine if it requires counting, arithmetic, or comparison reasoning.")

        # Step 2: Based on the nature of the question, choose the appropriate specialized operator
        if "percent" in self.problem_text.lower() or "percentage" in self.problem_text.lower():
            # Likely requires arithmetic (e.g., computing percentage of non-white population)
            result = await self.arithmetic_reasoning()
            return result["result"]
        
        elif "how many" in self.problem_text.lower() or "count" in self.problem_text.lower():
            # Likely requires counting (e.g., number of people from India, types of dwellings)
            result = await self.counting_reasoning()
            return result["count"]
        
        elif "which" in self.problem_text.lower() or "most" in self.problem_text.lower() or "highest" in self.problem_text.lower():
            # Likely requires comparison/sorting (e.g., most multicultural area, highest income)
            result = await self.comparison_reasoning()
            return result["result"]
        
        else:
            # Fallback: Use flexible custom for general reasoning when pattern is unclear
            final_answer = await self.flexible_custom(
                steps=[
                    {"step": "Understand the question and identify key entities"},
                    {"step": "Extract relevant information from the passage"},
                    {"step": "Perform necessary reasoning (counting, arithmetic, or comparison)"},
                    {"step": "Return the final answer"}
                ],
                reasoning_pattern="chain_of_thought",
                custom_instruction="Solve the problem step-by-step based on the passage."
            )
            return final_answer