# Workflow ID: drop_92_1
# Benchmark: drop
# Data Indices: [123, 199]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Strategy: First, extract relevant information using a flexible custom step
        extraction_step = await self.flexible_custom(
            reasoning_pattern="step_by_step",
            steps=[
                "Identify all numerical data in the passage related to the question.",
                "List each piece of relevant data with its context (e.g., field goal distances, player stats)."
            ],
            custom_instruction="Extract all numbers and their meanings from the passage."
        )

        # Now, determine the type of reasoning needed based on the extracted info
        reasoning_type = await self.custom(instruction=f"Based on this extracted data: {extraction_step}, classify whether the task requires counting, arithmetic, or comparison reasoning.")

        # Use the specialized operator directly — no fallbacks or conditionals
        if "arithmetic" in reasoning_type.lower():
            solution = await self.arithmetic_reasoning()
        elif "counting" in reasoning_type.lower():
            solution = await self.counting_reasoning()
        elif "comparison" in reasoning_type.lower():
            solution = await self.comparison_reasoning()
        else:
            # If classification fails, try a multi-step flexible custom approach
            solution = await self.flexible_custom(
                reasoning_pattern="chain_of_thought",
                steps=[
                    "Break down the question into sub-tasks.",
                    "For each sub-task, decide what kind of reasoning applies.",
                    "Apply the appropriate operator sequentially."
                ],
                custom_instruction="Solve the problem by applying the correct reasoning step-by-step."
            )

        # Instead of reviewing first, we now apply ensemble voting immediately after generation
        # This ensures robustness early, even before refining
        final_result = await self.sc_ensemble(solutions=[solution])

        # Only then do we review the ensemble result to polish clarity and correctness
        polished_result = await self.review(pre_solution=final_result)

        return polished_result