# Workflow ID: drop_174_1
# Benchmark: drop
# Data Indices: [230, 281]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to execute a multi-step reasoning plan based on the question type
        # This avoids relying on conditionals — instead, we define a strategy directly in the reasoning pattern
        reasoning_pattern = {
            "count": "Identify all instances of the target entity and count them.",
            "arithmetic": "Extract numerical values from the passage and compute the required operation (sum/difference/etc).",
            "comparison": "Find relevant items and compare their values or properties to determine order or difference."
        }
        
        steps = [
            {"name": "analyze_question", "instruction": "Determine whether the question requires counting, arithmetic, or comparison."},
            {"name": "execute_reasoning", "instruction": "Based on the analysis, apply the appropriate expert operator."}
        ]
        
        flexible_result = await self.flexible_custom(
            steps=steps,
            reasoning_pattern=reasoning_pattern,
            custom_instruction="Given the question, generate a structured response that includes both the type of reasoning needed and the final answer."
        )

        # Step 2: Immediately review the solution to improve clarity and correctness
        reviewed_answer = await self.review(pre_solution=flexible_result)

        # Step 3: Generate an alternative solution using a different approach — e.g., direct text extraction via Custom
        alternative_solution = await self.custom(instruction="Extract only the relevant information from the passage that answers the question directly. Do not reason further.")

        # Step 4: Use ScEnsemble to compare both solutions and pick the most consistent one
        ensemble_result = await self.sc_ensemble(solutions=[reviewed_answer, alternative_solution])

        return ensemble_result