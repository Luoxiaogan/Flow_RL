# Workflow ID: drop_111_1
# Benchmark: drop
# Data Indices: [239, 398]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to define a multi-step reasoning plan based on question type
        reasoning_pattern = "Identify task → Extract relevant info → Apply specialized operator → Refine"
        steps = [
            {"step": "analyze_question", "instruction": "Determine whether the question requires counting, arithmetic, comparison, or span extraction."},
            {"step": "extract_info", "instruction": "From the passage, extract all entities and events relevant to the identified task."},
            {"step": "reason", "instruction": "Use the most appropriate specialized reasoning operator (Counting, Arithmetic, or Comparison) based on the task."},
            {"step": "refine", "instruction": "Review the solution to ensure clarity, correctness, and completeness."}
        ]
        initial_plan = await self.flexible_custom(
            reasoning_pattern=reasoning_pattern,
            steps=steps,
            custom_instruction="Generate a structured reasoning plan to solve this DROP-style question."
        )

        # Step 2: Execute the plan using the FlexibleCustom output as a guide — but do NOT call it again!
        # Instead, we now act on the high-level plan by directly invoking specialized operators in sequence
        # This is the key difference: we don't rely on one big `custom` step — instead, we break down the plan into explicit calls

        # Step 2a: Understand the question
        question_analysis = await self.custom(instruction="Analyze the question and classify the required reasoning type (e.g., counting, arithmetic, comparison, span).")

        # Step 2b: Based on classification, invoke appropriate expert
        if "first" in question_analysis.lower() or "who scored first" in question_analysis.lower():
            result = await self.comparison_reasoning()
        elif "how many" in question_analysis.lower() or "more field goals" in question_analysis.lower():
            count_result = await self.counting_reasoning()
            # For comparison between teams, we must also get second count — so do it in parallel with a separate call
            count_result2 = await self.counting_reasoning()
            result = await self.comparison_reasoning()
        elif any(keyword in question_analysis.lower() for keyword in ["sum", "difference", "total", "how much more"]):
            result = await self.arithmetic_reasoning()
        else:
            result = await self.custom(instruction="Solve the problem using step-by-step logical deduction.")

        # Step 3: Review the raw result before finalizing
        reviewed_result = await self.review(pre_solution=result)

        # Step 4: Final robustness via ensemble — not just one answer, but multiple attempts
        # We simulate multiple approaches by calling the same operator twice with slightly different instructions
        # This is a novel use of ScEnsemble: we generate two similar solutions and let the ensemble vote
        solution1 = await self.custom(instruction=f"Re-solve the problem focusing only on key facts from the passage. Use {question_analysis} as guidance.")
        solution2 = await self.custom(instruction=f"Re-solve the problem by summarizing the passage first, then applying logic. Based on: {question_analysis}.")
        final_answer = await self.sc_ensemble(solutions=[reviewed_result, solution1, solution2])

        return final_answer