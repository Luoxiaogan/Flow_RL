# Workflow ID: drop_143_1
# Benchmark: drop
# Data Indices: [47, 396]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom with a parallel reasoning pattern to explore multiple strategies simultaneously
        parallel_solutions = await self.flexible_custom(
            reasoning_pattern="parallel",
            steps=[
                {
                    "name": "counting_approach",
                    "instruction": "Identify all numerical entities in the passage and count relevant items based on the question."
                },
                {
                    "name": "arithmetic_approach",
                    "instruction": "Extract numbers related to the question and compute their sum, difference, or other arithmetic operation."
                },
                {
                    "name": "comparison_approach",
                    "instruction": "Find all candidates that could be the answer (e.g., yardages, years, counts) and compare them to determine the correct one."
                }
            ],
            custom_instruction="Generate solutions using three distinct reasoning strategies in parallel."
        )

        # Step 2: Evaluate and select the best solution using ensemble voting
        final_answer = await self.sc_ensemble(solutions=parallel_solutions)

        # Step 3: Optionally refine the selected solution using review for quality assurance
        reviewed_answer = await self.review(pre_solution=final_answer)

        return reviewed_answer