# Workflow ID: drop_18_1
# Benchmark: drop
# Data Indices: [352, 228]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Strategy: Use parallel reasoning paths with different starting points
        # Then select best result via ensemble — fundamentally different from sequential step-by-step

        # Step 1: Generate multiple solutions using distinct strategies (parallel execution)
        solution1 = await self.custom(instruction="First, solve by identifying key numbers in the passage and performing arithmetic directly.")
        solution2 = await self.custom(instruction="Second, solve by extracting all relevant percentages or values first, then comparing them to find the answer.")
        solution3 = await self.custom(instruction="Third, solve by rephrasing the question into a counting task—e.g., how many items meet a condition?")

        # Step 2: Use ScEnsemble to pick the most consistent answer across diverse reasoning paths
        final_answer = await self.sc_ensemble(solutions=[solution1, solution2, solution3])

        return final_answer