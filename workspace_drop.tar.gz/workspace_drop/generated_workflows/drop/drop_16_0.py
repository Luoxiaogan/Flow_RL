# Workflow ID: drop_16_0
# Benchmark: drop
# Data Indices: [201, 82]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify what needs to be extracted or reasoned about
        initial_thought = await self.custom(instruction="First, carefully read the passage and determine what information is needed to answer the question. Identify key entities, dates, or numerical values relevant to the query.")

        # Step 2: Generate multiple solutions using different reasoning strategies
        solution1 = await self.custom(instruction="Use step-by-step extraction: Identify all mentions related to the question, then count or calculate based on those.")
        solution2 = await self.counting_reasoning()
        solution3 = await self.arithmetic_reasoning()
        solution4 = await self.comparison_reasoning()

        # Step 3: Use ensemble voting to select the most consistent answer
        final_answer = await self.sc_ensemble(solutions=[solution1, solution2, solution3, solution4])

        return final_answer