# Workflow ID: drop_108_1
# Benchmark: drop
# Data Indices: [259, 106]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to define a multi-step reasoning plan based on question type
        reasoning_pattern = "Identify the required operation (counting, arithmetic, comparison) and execute it directly."
        steps = [
            {"name": "analyze_question", "instruction": "Determine whether the question requires counting, arithmetic, or comparison."},
            {"name": "execute_task", "instruction": "Based on the analysis, choose the correct specialized operator and solve."}
        ]
        plan_result = await self.flexible_custom(
            reasoning_pattern=reasoning_pattern,
            steps=steps,
            custom_instruction="Analyze this question: {question} and follow the defined steps.".format(question=self.problem)
        )

        # Step 2: Extract the result from the flexible custom output — likely a structured response
        # Assume the output contains the final answer in a key like 'final_answer'
        try:
            final_answer = plan_result.get('final_answer', plan_result)
        except AttributeError:
            final_answer = plan_result

        # Step 3: Instead of reviewing first, use ensemble as the primary quality gate
        # Generate multiple solutions using different strategies (e.g., one with each operator)
        solutions = []
        solutions.append(await self.custom(instruction="Solve the problem using general reasoning."))
        solutions.append(await self.counting_reasoning())
        solutions.append(await self.arithmetic_reasoning())
        solutions.append(await self.comparison_reasoning())

        # Step 4: Apply ScEnsemble to find the most consistent answer across all strategies
        final_output = await self.sc_ensemble(solutions=solutions)

        return final_output