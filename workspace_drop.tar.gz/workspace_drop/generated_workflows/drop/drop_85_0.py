# Workflow ID: drop_85_0
# Benchmark: drop
# Data Indices: [388, 325]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Initial reasoning — understand the question and identify what needs to be extracted or computed
        initial_thought = await self.custom(instruction="First, read the passage carefully and determine what type of reasoning is needed: counting, arithmetic, comparison, or text extraction.")
        
        # Step 2: Based on the initial thought, choose appropriate specialized operator
        if "count" in initial_thought.lower() or "how many" in initial_thought.lower():
            count_result = await self.counting_reasoning()
            return count_result['count']
        
        elif "sum" in initial_thought.lower() or "total" in initial_thought.lower() or "difference" in initial_thought.lower():
            arith_result = await self.arithmetic_reasoning()
            return arith_result['result']
        
        elif "which team lost" in initial_thought.lower() or "who won" in initial_thought.lower():
            # For questions about winning/losing teams, we must compare scores
            comparison_result = await self.comparison_reasoning()
            return comparison_result['result']
        
        elif "shortest field goal" in initial_thought.lower() or "longest field goal" in initial_thought.lower():
            # Extract and compare field goal distances
            comparison_result = await self.comparison_reasoning()
            return comparison_result['result']
        
        else:
            # Fallback: Use flexible custom for complex or ambiguous cases
            final_answer = await self.flexible_custom(
                steps=[
                    {"step": "Understand the question", "instruction": "What exactly is being asked?"},
                    {"step": "Extract relevant facts", "instruction": "Identify all key numbers, events, or entities mentioned in the passage."},
                    {"step": "Apply reasoning", "instruction": "Use the correct operator (counting, arithmetic, comparison) based on the nature of the question."}
                ],
                reasoning_pattern="chain_of_thought",
                custom_instruction="Now solve the problem using the extracted information."
            )
            return final_answer