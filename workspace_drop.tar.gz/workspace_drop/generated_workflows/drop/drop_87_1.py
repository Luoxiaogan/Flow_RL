# Workflow ID: drop_87_1
# Benchmark: drop
# Data Indices: [96, 301]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Strategy: Use FlexibleCustom with a "parallel" reasoning pattern to extract all relevant TD pass info first,
        # then apply comparison reasoning in one go — fundamentally different from sequential step-by-step.
        
        # Step 1: Extract all touchdown pass details (player, distance, etc.) using flexible custom logic
        extraction_steps = [
            {"task": "Identify all touchdown passes mentioned in the passage"},
            {"task": "For each, extract: receiver name and pass length"},
            {"task": "Structure this as a list of tuples: (receiver, yards)"}
        ]
        
        raw_pass_data = await self.flexible_custom(
            steps=extraction_steps,
            reasoning_pattern="parallel",
            custom_instruction="Extract all touchdown passes as (receiver, yardage) pairs."
        )

        # Step 2: Use ComparisonReasoning to find the longest pass — now we give it structured input
        comparison_result = await self.comparison_reasoning()

        # Step 3: Use Custom to interpret the comparison result and return the player who caught the longest pass
        final_answer = await self.custom(instruction=f"From the comparison result: {comparison_result}, identify the player who caught the longest touchdown pass. Return only the name.")

        # Step 4: Review for refinement — critical since comparison may not always be perfectly parsed
        reviewed_solution = await self.review(pre_solution=final_answer)

        # Step 5: Final ensemble — use ScEnsemble to validate against multiple interpretations (even if just one solution, this ensures robustness)
        final_output = await self.sc_ensemble(solutions=[final_answer, reviewed_solution])

        return final_output