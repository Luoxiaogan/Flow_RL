# Workflow ID: drop_159_0
# Benchmark: drop
# Data Indices: [211, 1]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify what needs to be extracted or computed
        initial_thought = await self.custom(instruction="First, read the passage carefully and determine what information is needed to answer the question. Identify whether it requires counting, arithmetic, comparison, or a span of text.")

        # Step 2: If the question involves numbers (e.g., time spans, counts), try solving with appropriate specialized operator
        if "how many" in self.problem.lower() or "years" in self.problem.lower():
            result = await self.arithmetic_reasoning()
            # For year-span problems like "How many years did the war span?", we expect a numeric answer
            final_answer = result["result"]
        elif "count" in self.problem.lower() or "number of" in self.problem.lower():
            result = await self.counting_reasoning()
            final_answer = result["count"]
        elif "compare" in self.problem.lower() or "more than" in self.problem.lower() or "less than" in self.problem.lower():
            result = await self.comparison_reasoning()
            final_answer = result["result"]
        else:
            # General case: Use flexible custom for complex reasoning
            final_answer = await self.flexible_custom(
                reasoning_pattern="step-by-step reasoning",
                steps=[
                    "Identify relevant facts from the passage.",
                    "Determine the type of reasoning required (counting, arithmetic, comparison).",
                    "Apply the correct operator based on the reasoning type.",
                    "Return the final answer as a number, date, or span of text."
                ],
                custom_instruction="Solve the problem by applying step-by-step logical reasoning using the passage and the question."
            )

        # Step 3: Review the solution for correctness and clarity
        reviewed_solution = await self.review(pre_solution=final_answer)

        # Step 4: Use ensemble voting to improve robustness — simulate multiple solutions via flexible custom
        solution1 = final_answer
        solution2 = await self.custom(instruction="Re-solve the problem focusing only on key numerical values in the passage.")
        solution3 = await self.custom(instruction="Break down the problem into smaller parts and solve each part separately before combining the result.")
        
        final_result = await self.sc_ensemble(solutions=[solution1, solution2, solution3])

        return final_result