# Workflow ID: drop_139_0
# Benchmark: drop
# Data Indices: [27, 21]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the task and identify relevant entities (e.g., field goals, players, scores)
        initial_thought = await self.custom(instruction="First, read the passage carefully and identify all numerical facts related to field goals, touchdowns, or other measurable quantities. Determine what the question is asking for.")
        
        # Step 2: Generate multiple solutions using different reasoning strategies
        solution1 = await self.custom(instruction="Strategy 1: Extract all field goal distances mentioned in the passage. Then compare them to find the longest one.")
        solution2 = await self.custom(instruction="Strategy 2: Use a structured approach to list each scoring play with its distance, then determine who made the longest kick based on the data.")
        solution3 = await self.custom(instruction="Strategy 3: Identify all kicks by name, extract their yardages, and apply comparison reasoning to find the maximum.")

        # Step 3: Use ensemble voting to select the most consistent answer
        final_answer = await self.sc_ensemble(solutions=[solution1, solution2, solution3])
        
        return final_answer