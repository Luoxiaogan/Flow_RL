# Workflow ID: drop_105_0
# Benchmark: drop
# Data Indices: [273, 104]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify required information
        initial_thought = await self.custom(instruction="Read the passage carefully and identify what type of reasoning is needed (e.g., extraction, counting, arithmetic, comparison). Also, determine which entities or values must be found.")
        
        # Step 2: Extract relevant information from the passage
        extraction_step = await self.custom(instruction="Based on the question, extract all relevant entities, events, or numerical data mentioned in the passage that could help answer it.")
        
        # Step 3: Determine the appropriate reasoning type based on the question
        reasoning_type = await self.custom(instruction="Analyze the question and decide whether it requires counting, arithmetic, comparison, or a combination. If multiple steps are involved, outline them.")
        
        # Step 4: Apply specialized reasoning operators as needed
        if "count" in reasoning_type.lower() or "how many" in reasoning_type.lower():
            result = await self.counting_reasoning()
        elif "sum" in reasoning_type.lower() or "difference" in reasoning_type.lower() or "total" in reasoning_type.lower():
            result = await self.arithmetic_reasoning()
        elif "compare" in reasoning_type.lower() or "longest" in reasoning_type.lower() or "shortest" in reasoning_type.lower() or "most" in reasoning_type.lower():
            result = await self.comparison_reasoning()
        else:
            # Fallback to general custom reasoning for complex cases
            result = await self.custom(instruction="Use step-by-step logical reasoning to solve the problem based on extracted information and the nature of the question.")
        
        # Step 5: Finalize the answer format — ensure it matches expected output type (number, date, span)
        final_answer = await self.custom(instruction=f"Given the reasoning result: {result}, now format the final answer clearly and concisely. Ensure it directly answers the original question without extra explanation.")
        
        # Optional: Use ensemble or review for robustness if needed
        # Uncomment below lines if additional confidence is desired
        # reviewed_answer = await self.review(final_answer)
        # final_answer = await self.sc_ensemble([final_answer, reviewed_answer])
        
        return final_answer