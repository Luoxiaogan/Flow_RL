# Workflow ID: drop_118_0
# Benchmark: drop
# Data Indices: [162, 139]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """

        # Step 1: Understand the question and identify required reasoning type
        initial_thought = await self.custom(instruction="First, analyze the question to determine whether it requires counting, arithmetic, comparison, or a combination. Identify key entities or values in the passage relevant to the question.")

        # Step 2: Generate multiple solutions using different strategies
        solution_1 = await self.custom(instruction="Use direct extraction: Find all instances in the text that match the criteria (e.g., touchdowns by pass). Count them directly.")
        solution_2 = await self.counting_reasoning()
        solution_3 = await self.flexible_custom(
            reasoning_pattern="Extract relevant spans and count",
            steps=[
                "Identify all plays that resulted in touchdowns.",
                "Filter only those that were passes (look for phrases like 'pass to', 'touchdown pass').",
                "Count the filtered items."
            ],
            custom_instruction="Based on the passage, extract and count all touchdown passes."
        )

        # Step 3: Use ScEnsemble to select the most consistent answer across multiple approaches
        final_answer = await self.sc_ensemble(solutions=[solution_1, solution_2, solution_3])

        return final_answer