# Workflow ID: drop_25_1
# Benchmark: drop
# Data Indices: [173, 266]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use flexible custom to define a multi-step reasoning pattern
        # This allows us to embed structured logic directly into the prompt
        steps = [
            "Identify the key numerical values or items in the passage relevant to the question.",
            "Determine the type of reasoning required: counting, arithmetic, or comparison.",
            "Apply the appropriate reasoning operator based on the task type.",
            "Return only the final answer as a number, date, or span of text."
        ]
        reasoning_pattern = "Chain-of-Thought with Explicit Operator Selection"
        
        initial_solution = await self.flexible_custom(
            steps=steps,
            reasoning_pattern=reasoning_pattern,
            custom_instruction="Based on the problem, execute the steps above using the correct specialized operator (counting/arithmetic/comparison)."
        )

        # Step 2: Review the solution for clarity and correctness
        refined_solution = await self.review(pre_solution=initial_solution)

        # Step 3: Use ensemble to validate against alternative interpretations
        final_answer = await self.sc_ensemble(solutions=[initial_solution, refined_solution])

        return final_answer