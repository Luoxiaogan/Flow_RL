# Workflow ID: drop_136_0
# Benchmark: drop
# Data Indices: [124, 165]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question type (counting, arithmetic, or comparison)
        initial_thought = await self.custom(instruction="First, determine whether the question requires counting, arithmetic, or comparison reasoning.")
        
        # Step 2: Route to appropriate specialized operator based on question type
        if "how many" in self.problem_text.lower() or "count" in self.problem_text.lower():
            result = await self.counting_reasoning()
        elif "sum", "difference", "total", "more than", "less than" in self.problem_text.lower():
            result = await self.arithmetic_reasoning()
        elif "who had more", "compare", "which is greater", "rank" in self.problem_text.lower():
            result = await self.comparison_reasoning()
        else:
            # Fallback: Use flexible custom for complex reasoning not covered by above
            result = await self.flexible_custom(
                steps=[
                    {"step": "Identify key entities and values from the passage."},
                    {"step": "Determine the logical relationship between them."},
                    {"step": "Apply the necessary reasoning step to derive the answer."}
                ],
                reasoning_pattern="chain_of_thought",
                custom_instruction="Based on the identified elements, solve the problem using structured reasoning."
            )
        
        # Step 3: Final review to improve clarity and correctness
        final_result = await self.review(pre_solution=result)
        
        # Step 4: Ensemble voting if multiple solutions exist (though here we have one)
        # For now, just return the refined result
        return final_result