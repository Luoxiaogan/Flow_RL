# Workflow ID: drop_123_0
# Benchmark: drop
# Data Indices: [77, 191]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify required reasoning type
        initial_thought = await self.custom(instruction="First, analyze the question to determine whether it requires counting, arithmetic, comparison, or span extraction.")
        
        # Step 2: Generate multiple solutions using different strategies (Parallel Ensemble Pattern)
        solution1 = await self.custom(instruction="Use direct reading: extract relevant numbers or spans from the passage based on the question.")
        solution2 = await self.arithmetic_reasoning()
        solution3 = await self.comparison_reasoning()
        solution4 = await self.counting_reasoning()

        # Step 3: Use sc_ensemble to select the most consistent answer across all approaches
        final_answer = await self.sc_ensemble(solutions=[solution1, solution2, solution3, solution4])
        
        # Step 4: Optional review for refinement (improves robustness further)
        refined_answer = await self.review(pre_solution=final_answer)
        
        return refined_answer