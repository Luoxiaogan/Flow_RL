# Workflow ID: drop_107_1
# Benchmark: drop
# Data Indices: [311, 395]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to define a multi-step reasoning pattern
        # This approach uses structured logic without explicit Python control flow
        reasoning_pattern = "Identify the type of question (counting, arithmetic, comparison, span). Then apply appropriate expert. Finally review and ensemble."
        steps = [
            {"name": "analyze_question", "instruction": "Determine whether this is a counting, arithmetic, comparison, or span-based question."},
            {"name": "apply_expert", "instruction": "Based on the analysis, use the correct reasoning operator: counting, arithmetic, or comparison."},
            {"name": "review_and_refine", "instruction": "Critique the solution for clarity, correctness, and completeness."},
            {"name": "ensemble_final", "instruction": "Compare multiple versions of the solution and select the most consistent one."}
        ]
        
        flexible_result = await self.flexible_custom(
            reasoning_pattern=reasoning_pattern,
            steps=steps,
            custom_instruction="Solve the DROP-style problem using structured reasoning steps."
        )

        # Step 2: Extract final answer from flexible result
        # The flexible_custom returns a structured response with all intermediate steps
        final_answer = flexible_result["final_answer"]

        # Step 3: Since flexible_custom already includes review and ensemble internally,
        # we do not need additional layers — but we still use ScEnsemble as a safety net
        # by generating a second independent solution via direct custom call
        fallback_solution = await self.custom(instruction="Generate an alternative solution based solely on the passage and question.")

        # Step 4: Ensemble both solutions to ensure robustness
        ensemble_solutions = [final_answer, fallback_solution]
        final_output = await self.sc_ensemble(solutions=ensemble_solutions)

        return final_output