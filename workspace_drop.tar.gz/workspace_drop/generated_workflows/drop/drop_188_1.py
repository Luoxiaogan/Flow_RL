# Workflow ID: drop_188_1
# Benchmark: drop
# Data Indices: [25, 70]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to define a multi-step reasoning plan based on question type
        reasoning_pattern = "Identify task type (counting/arithmetic/comparison), then apply appropriate expert operator."
        steps = [
            {"step": "Understand the question", "instruction": "What is being asked? Look for keywords like 'how many', 'sum', 'which group'."}, 
            {"step": "Select specialized operator", "instruction": "Choose CountingReasoning, ArithmeticReasoning, or ComparisonReasoning based on the identified task type."},
            {"step": "Execute solution", "instruction": "Run the selected operator and extract final answer."}
        ]
        plan_result = await self.flexible_custom(
            reasoning_pattern=reasoning_pattern,
            steps=steps,
            custom_instruction="Use the above plan to solve this DROP benchmark question."
        )

        # Step 2: Directly refine the result using Review — no ensemble needed
        refined_result = await self.review(pre_solution=plan_result)

        # Step 3: Return the refined solution as final output
        return refined_result