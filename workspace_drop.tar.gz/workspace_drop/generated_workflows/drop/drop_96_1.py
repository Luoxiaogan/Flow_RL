# Workflow ID: drop_96_1
# Benchmark: drop
# Data Indices: [319, 207]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # --- STRATEGIC TEMPLATE: Parallel Ensemble with Diverse Reasoning Paths ---
        
        # Step 1: Generate multiple independent solutions using different reasoning strategies
        solution1 = await self.arithmetic_reasoning()  # Direct arithmetic (e.g., percentage × total)
        solution2 = await self.counting_reasoning()   # If it's a count-based question
        solution3 = await self.comparison_reasoning() # For relative comparisons or sorting

        # Step 2: Use ScEnsemble to select the most consistent answer across all three
        final_answer = await self.sc_ensemble(solutions=[solution1, solution2, solution3])

        # Step 3: Review the ensemble result to refine clarity and correctness
        reviewed_final = await self.review(pre_solution=final_answer)

        return reviewed_final