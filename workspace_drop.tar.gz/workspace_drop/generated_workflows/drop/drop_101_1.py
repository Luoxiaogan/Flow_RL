# Workflow ID: drop_101_1
# Benchmark: drop
# Data Indices: [326, 37]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to define a multi-step reasoning plan that includes both counting and comparison
        reasoning_plan = {
            "steps": [
                "Identify all numerical values relevant to the question.",
                "Determine whether the task requires arithmetic, counting, or comparison.",
                "Execute the appropriate operator based on the identified task type."
            ],
            "reasoning_pattern": "chain_of_thought"
        }
        
        structured_analysis = await self.flexible_custom(
            steps=reasoning_plan["steps"],
            reasoning_pattern=reasoning_plan["reasoning_pattern"],
            custom_instruction="Analyze the passage and determine the correct reasoning path."
        )

        # Step 2: Generate two distinct solutions using different specialized operators (counting + arithmetic), then compare
        count_solution = await self.counting_reasoning()
        arithmetic_solution = await self.arithmetic_reasoning()

        # Step 3: Use Review to refine each solution individually before ensemble — this ensures quality at the individual level
        refined_count = await self.review(pre_solution=count_solution)
        refined_arithmetic = await self.review(pre_solution=arithmetic_solution)

        # Step 4: Use ScEnsemble to select the most consistent answer across multiple high-quality candidates
        final_result = await self.sc_ensemble(solutions=[refined_count, refined_arithmetic])

        return final_result