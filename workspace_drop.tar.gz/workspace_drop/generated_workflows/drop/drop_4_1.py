# Workflow ID: drop_4_1
# Benchmark: drop
# Data Indices: [390, 45]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to define a multi-step reasoning plan based on question type
        reasoning_pattern = "Identify key entities → Extract relevant data → Apply domain-specific reasoning (count/arithmetic/compare) → Final answer"
        steps = [
            "Understand the question and determine if it involves counting, arithmetic, or comparison.",
            "Extract all numbers or named items relevant to the query from the passage.",
            "Apply the appropriate specialized reasoning operator (Counting, Arithmetic, or Comparison).",
            "Format the final result clearly as a number, date, or span."
        ]
        initial_plan = await self.flexible_custom(
            reasoning_pattern=reasoning_pattern,
            steps=steps,
            custom_instruction="Generate a step-by-step plan to solve this DROP-style question."
        )

        # Step 2: Use Custom to extract structured information from the passage based on the plan
        extracted_data = await self.custom(instruction=f"Based on the plan: {initial_plan}, now extract all relevant numerical values, named entities, and counts mentioned in the passage that relate to the question.")

        # Step 3: Determine which reasoning task is needed — then apply only that one
        reasoning_type = await self.custom(instruction="Based on the extracted data, identify whether the required reasoning is counting, arithmetic, or comparison.")
        
        if "count" in reasoning_type.lower():
            final_result = await self.counting_reasoning()
        elif "arithmetic" in reasoning_type.lower():
            final_result = await self.arithmetic_reasoning()
        elif "compare" in reasoning_type.lower() or "sort" in reasoning_type.lower():
            final_result = await self.comparison_reasoning()
        else:
            # Fallback: If unsure, ask Custom to infer from the extracted data
            final_result = await self.custom(instruction=f"The question requires reasoning but type was unclear. Based on extracted data: {extracted_data}, provide the correct answer.")

        # Step 4: Optional refinement using Review for clarity and correctness
        refined_answer = await self.review(pre_solution=final_result)

        return refined_answer