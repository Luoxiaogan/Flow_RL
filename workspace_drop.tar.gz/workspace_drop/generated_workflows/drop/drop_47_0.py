# Workflow ID: drop_47_0
# Benchmark: drop
# Data Indices: [261, 178]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Understand the question and identify what needs to be extracted or reasoned about
        initial_thought = await self.custom(instruction="Read the passage carefully and determine what information is needed to answer the question. Identify key entities (e.g., players, scores, times, distances).")

        # Step 2: Use FlexibleCustom with a sequential reasoning pattern to guide step-by-step extraction and reasoning
        solution = await self.flexible_custom(
            reasoning_pattern="sequential",
            steps=[
                "Extract all relevant numerical values mentioned in the passage related to the question.",
                "Determine whether the task involves counting, arithmetic, comparison, or span extraction.",
                "Apply the appropriate specialized operator based on the nature of the task.",
                "Synthesize the final answer based on the results from the specialized operators."
            ],
            custom_instruction="Based on the initial thought and steps above, execute the full reasoning process."
        )

        # Step 3: Optionally refine using review for quality assurance
        refined_solution = await self.review(pre_solution=solution)

        # Step 4: Use ensemble voting if multiple solutions were generated during flexible_custom (if applicable)
        final_answer = await self.sc_ensemble(solutions=[refined_solution])

        return final_answer