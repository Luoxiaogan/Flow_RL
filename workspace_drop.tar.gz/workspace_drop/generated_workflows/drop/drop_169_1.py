# Workflow ID: drop_169_1
# Benchmark: drop
# Data Indices: [219, 394]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem = problem
        self.problem_text = str(problem) if isinstance(problem, dict) else problem
        
        # Create LLM instance from config
        self.llm = create(self.config)

        # All available operators are initialized here for your use.
        self.custom = operator.Custom(self.llm, self.problem)
        self.counting_reasoning = operator.CountingReasoning(self.llm, self.problem)
        self.arithmetic_reasoning = operator.ArithmeticReasoning(self.llm, self.problem)
        self.comparison_reasoning = operator.ComparisonReasoning(self.llm, self.problem)
        self.review = operator.Review(self.llm, self.problem)
        self.sc_ensemble = operator.ScEnsemble(self.llm, self.problem)
        self.flexible_custom = operator.FlexibleCustom(self.llm, self.problem)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        # Step 1: Use FlexibleCustom to define a multi-step reasoning pattern based on question type
        reasoning_pattern = "Identify key entities and values in the passage relevant to the question. Then determine whether the task requires counting, arithmetic, or comparison. Finally, execute the appropriate reasoning step."
        
        steps = [
            {"name": "analyze_question", "instruction": "Analyze the question to determine whether it requires counting, arithmetic, comparison, or span extraction."},
            {"name": "select_operator", "instruction": "Based on the analysis, choose the most suitable specialized operator (CountingReasoning, ArithmeticReasoning, or ComparisonReasoning)."},
            {"name": "execute_reasoning", "instruction": "Execute the selected operator to solve the problem."}
        ]
        
        # Step 2: Run the structured workflow using FlexibleCustom
        solution = await self.flexible_custom(
            reasoning_pattern=reasoning_pattern,
            steps=steps,
            custom_instruction="Use the above steps to solve the problem systematically."
        )

        # Step 3: Review the generated solution for clarity and correctness
        reviewed_solution = await self.review(pre_solution=solution)

        return reviewed_solution