# Workflow ID: high_level_math_ganluo_36_0
# Benchmark: high_level_math_ganluo
# Data Indices: [41]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis – Understand structure and constraints
        analysis = await self.generate(
            instruction="Analyze the problem to identify key mathematical components: grid size, path length, direction changes, and combinatorial implications."
        )

        # Step 2: Parallel Exploration – Try multiple valid solution strategies
        task1 = self.generate(
            instruction="Generate a solution using recursive decomposition based on number of direction changes.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Generate a solution using generating functions or combinatorics focused on sequences with exactly four switches between horizontal and vertical moves.",
            context=analysis
        )
        task3 = self.generate(
            instruction="Generate a solution using coordinate bashing: model each move as (x,y) increments and count valid paths with exactly four direction changes.",
            context=analysis
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble – Compare and synthesize best candidate
        final_answer = await self.ensemble(
            instruction="Evaluate the three proposed solutions for consistency, mathematical rigor, and correctness. Select the most robust answer that satisfies all constraints.",
            contexts_to_ensemble=solutions
        )

        # Step 4: Final Verification – Check against edge cases and logical consistency
        verification = await self.revise(
            instruction="Verify the selected answer by checking if it aligns with known small-case values (e.g., paths of length 4 with 0 or 1 direction change), and ensure it’s an integer between 0 and 999.",
            context_to_revise=final_answer
        )

        return verification