# Workflow ID: high_level_math_ganluo_5_0
# Benchmark: high_level_math_ganluo
# Data Indices: [42]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Analyze the problem to identify key mathematical structure
        analysis = await self.generate(
            instruction="Identify the type of problem (e.g., complex numbers, optimization under constraint) and key constraints like |z|=4."
        )

        # Step 2: Generate multiple solution paths using different mathematical lenses
        task1 = self.generate(
            instruction="Use coordinate geometry: let z = 4 * e^(iθ), then express the given expression in terms of θ.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Use algebraic manipulation: write z = x + yi with x² + y² = 16, then compute the real part directly.",
            context=analysis
        )
        task3 = self.generate(
            instruction="Apply the AM-GM inequality or calculus-based optimization to find the maximum real part.",
            context=analysis
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 3: Summarize each approach to extract key insights
        summaries = [await self.summarize(sol) for sol in solutions]

        # Step 4: Ensemble to select the most robust and consistent solution
        final_answer = await self.ensemble(
            instruction="Compare the three approaches. Which one provides the clearest path to the correct integer answer? Choose the best-supported value.",
            contexts_to_ensemble=summaries
        )

        # Step 5: Revise if necessary — test consistency with boundary conditions
        revised = await self.revise(
            instruction="Check that the selected answer satisfies |z| = 4 and makes sense as the largest possible real part.",
            context_to_revise=final_answer
        )

        return revised