# Workflow ID: high_level_math_ganluo_15_0
# Benchmark: high_level_math_ganluo
# Data Indices: [1]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify problem type and key elements
        analysis = await self.generate(
            instruction="Analyze the problem structure. Identify geometric objects, given lengths, and relationships between points (e.g., reflections, areas)."
        )

        # Step 2: Extract structured data from analysis for precise reasoning
        extracted_data = await self.generate(
            instruction="From the analysis, extract all numerical values, point labels, and area constraints in a clean format.",
            context=analysis
        )

        # Step 3: Parallel exploration of multiple solution paths
        task1 = self.generate(
            instruction="Use coordinate geometry: assign coordinates to points A, B, C based on segment divisions. Then compute coordinates of M and N via reflection formulas."
        )
        task2 = self.generate(
            instruction="Use synthetic geometry: exploit similar triangles or ratios from the given segment lengths. Consider how area of quadrilateral DEGF relates to the whole figure."
        )
        task3 = self.generate(
            instruction="Apply area decomposition: break heptagon AFNBCEM into simpler polygons whose areas can be calculated using known base/heights or relations to DEGF."
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble to select best-supported solution
        final_answer = await self.ensemble(
            instruction="Compare the three candidate solutions. Choose the one that most consistently satisfies all given constraints (especially area of DEGF = 288) and uses valid mathematical reasoning.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional refinement if needed — check consistency with original constraints
        refined_answer = await self.revise(
            instruction="Verify that the selected answer logically follows from the problem setup and correctly accounts for all given segments and reflections. If any step seems inconsistent, revise accordingly.",
            context_to_revise=final_answer
        )

        return refined_answer