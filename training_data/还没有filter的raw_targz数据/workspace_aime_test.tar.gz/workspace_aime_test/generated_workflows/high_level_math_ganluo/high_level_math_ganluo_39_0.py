# Workflow ID: high_level_math_ganluo_39_0
# Benchmark: high_level_math_ganluo
# Data Indices: [46]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify key elements and constraints
        analysis = await self.generate(
            instruction="Identify all given quantities, geometric relationships, and what needs to be found. Focus on identifying if this is a geometry problem involving triangle centers (circumcenter, incenter), perpendicularity conditions, and known radii."
        )

        # Step 2: Extract structured facts from analysis for clarity
        extracted = await self.generate(
            instruction="From the analysis, extract a concise list of known values and relationships, such as circumradius R=13, inradius r=6, and IA ⊥ OI.",
            context=analysis
        )

        # Step 3: Parallel exploration — generate multiple solution strategies
        task1 = self.generate(
            instruction="Generate an algebraic approach using coordinates or vector methods to model points A, B, C, I, O with the given perpendicular condition."
        )
        task2 = self.generate(
            instruction="Generate a synthetic geometry approach leveraging properties of the incenter, circumcenter, and right angles between vectors IA and OI."
        )
        task3 = self.generate(
            instruction="Generate a trigonometric approach using angle formulas and identities related to triangle centers and distances."
        )
        strategies = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble the top candidate solutions based on coherence and relevance
        ensemble_result = await self.ensemble(
            instruction="Evaluate the three proposed strategies and select the most promising one based on mathematical rigor, clarity, and alignment with the problem’s structure.",
            contexts_to_ensemble=strategies
        )

        # Step 5: Refine the selected strategy through iterative improvement
        refined_solution = await self.revise(
            instruction="Improve the selected solution by checking for logical consistency, ensuring all constraints are satisfied, and simplifying complex expressions where possible.",
            context_to_revise=ensemble_result
        )

        # Step 6: Final verification via bidirectional reasoning (forward solve → check inverse)
        final_answer = await self.generate(
            instruction="Based on the refined solution, compute AB·AC. Then, verify that this value satisfies all original conditions including IA ⊥ OI, R=13, and r=6.",
            context=refined_solution
        )

        return final_answer