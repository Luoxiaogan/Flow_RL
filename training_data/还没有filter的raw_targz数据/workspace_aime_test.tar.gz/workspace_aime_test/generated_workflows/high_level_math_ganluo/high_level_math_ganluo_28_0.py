# Workflow ID: high_level_math_ganluo_28_0
# Benchmark: high_level_math_ganluo
# Data Indices: [2]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Analyze the problem structure and extract key constraints
        analysis = await self.generate(
            instruction="Identify all mathematical constraints from the problem. Focus on counting, ordering, and distribution rules."
        )

        # Step 2: Generate multiple solution approaches (combinatorial + recursive + generating function)
        task1 = self.generate(
            instruction="Model this as a constrained integer partition problem: distribute 9 players into 3 ordered groups (chocolate > vanilla > strawberry), each at least 1.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Use casework based on possible values for strawberry count (must be ≤ 2 due to ordering and total players).",
            context=analysis
        )
        task3 = self.generate(
            instruction="Consider using generating functions or inclusion-exclusion to count valid assignments.",
            context=analysis
        )

        # Execute in parallel — explore diverse strategies
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 3: Summarize each approach to ensure clarity and correctness
        summaries = [
            await self.summarize(solutions[0]),
            await self.summarize(solutions[1]),
            await self.summarize(solutions[2])
        ]

        # Step 4: Ensemble to select the most consistent and mathematically sound solution
        final_answer = await self.ensemble(
            instruction="Compare the three generated solutions and choose the one that satisfies all constraints: exactly 9 players, strict ordering, minimum one per flavor, and correct modular arithmetic for remainder mod 1000.",
            contexts_to_ensemble=summaries
        )

        # Step 5: Revise if needed — check for logical consistency or edge cases
        refined_answer = await self.revise(
            instruction="Verify that the selected solution correctly computes N modulo 1000 by rechecking the casework bounds and ensuring no overcounting or undercounting occurred.",
            context_to_revise=final_answer
        )

        return refined_answer