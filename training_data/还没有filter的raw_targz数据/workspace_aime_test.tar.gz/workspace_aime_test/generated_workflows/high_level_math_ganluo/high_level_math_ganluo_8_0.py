# Workflow ID: high_level_math_ganluo_8_0
# Benchmark: high_level_math_ganluo
# Data Indices: [45]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify problem type and key elements
        analysis = await self.generate(
            instruction="Identify the mathematical domain (e.g., combinatorics, set theory) and extract all numerical values, including totals, counts, and constraints from the problem."
        )

        # Step 2: Extract structured data from analysis for systematic reasoning
        extracted_data = await self.generate(
            instruction="From the analysis, extract the following: total population, number of residents owning each item, number owning exactly two items, and number owning exactly three items. Present as a clear list or dictionary.",
            context=analysis
        )

        # Step 3: Parallel exploration of multiple solution paths
        task1 = self.generate(
            instruction="Use inclusion-exclusion principle to calculate how many own all four items based on given overlaps.",
            context=extracted_data
        )
        task2 = self.generate(
            instruction="Model this as a system of equations using variables for intersections of two, three, and four items.",
            context=extracted_data
        )
        task3 = self.generate(
            instruction="Apply the formula for counting in terms of exactly k-item owners: use known values to derive the count for all four items.",
            context=extracted_data
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble the candidate solutions to resolve discrepancies
        final_answer = await self.ensemble(
            instruction="Compare the three proposed solutions. Choose the one that satisfies all constraints and makes logical sense. If there's disagreement, explain why one is correct over others.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Final verification by reverse-checking the constraints
        verification = await self.revise(
            instruction="Using the final answer, verify that it satisfies all original conditions: total ownerships, exactly two, exactly three, and the total population. If any constraint fails, revise the answer accordingly.",
            context_to_revise=final_answer
        )

        return verification