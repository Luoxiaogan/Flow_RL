# Workflow ID: high_level_math_ganluo_23_0
# Benchmark: high_level_math_ganluo
# Data Indices: [35]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Analyze the problem structure and identify key mathematical domain
        analysis = await self.generate(
            instruction="Analyze the problem to determine its category (e.g., geometry, number theory, combinatorics) and highlight critical constraints or symmetries."
        )

        # Step 2: Generate multiple solution paths based on identified domains
        math_path = self.generate(
            instruction="Generate a solution using coordinate geometry or vector methods, assuming it's a geometric problem."
        )
        algebra_path = self.generate(
            instruction="Generate a solution focusing on algebraic manipulation of given distances and equations."
        )
        symmetry_path = self.generate(
            instruction="Generate a solution leveraging symmetry properties or known formulas for tetrahedrons with equal face distances."
        )

        # Step 3: Run parallel exploration and summarize each approach
        tasks = [math_path, algebra_path, symmetry_path]
        results = await asyncio.gather(*tasks)
        summaries = [await self.summarize(result) for result in results]

        # Step 4: Ensemble the three approaches to find the most consistent answer
        final_answer = await self.ensemble(
            instruction="Compare the three solutions. Identify which one aligns best with all constraints and mathematical principles. Return only the integer value m+n+p.",
            contexts_to_ensemble=summaries
        )

        # Step 5: Optional refinement if ensemble result seems ambiguous
        if "ambiguous" in final_answer.lower() or "not unique" in final_answer.lower():
            refined = await self.revise(
                instruction="Revise the ensemble result by checking consistency with the original distance conditions and ensuring the form matches the required expression: m√n/p.",
                context_to_revise=final_answer
            )
            return refined
        else:
            return final_answer