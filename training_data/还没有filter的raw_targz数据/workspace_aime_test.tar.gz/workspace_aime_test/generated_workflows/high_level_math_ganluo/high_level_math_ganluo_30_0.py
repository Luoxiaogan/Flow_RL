# Workflow ID: high_level_math_ganluo_30_0
# Benchmark: high_level_math_ganluo
# Data Indices: [19]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Analyze the problem structure and identify key mathematical domain
        analysis = await self.generate(
            instruction="Analyze the problem to determine its mathematical domain (e.g., geometry, combinatorics, number theory) and key constraints."
        )

        # Step 2: Extract critical geometric or algebraic facts from the problem
        extraction = await self.generate(
            instruction="Extract all measurable quantities, angles, points, and relationships from the problem statement. Focus on symmetry, midpoints, and circle intersections.",
            context=analysis
        )

        # Step 3: Generate multiple solution strategies in parallel — one synthetic geometry approach, one coordinate-based approach
        tasks = [
            self.generate(
                instruction="Generate a solution using synthetic geometry techniques, focusing on angle chasing and properties of midlines and circles.",
                context=extraction
            ),
            self.generate(
                instruction="Generate a solution by assigning coordinates to triangle ABC and computing coordinates of D, E, F, then finding arc measures via circle geometry.",
                context=extraction
            )
        ]
        solutions = await asyncio.gather(*tasks)

        # Step 4: Summarize each candidate solution to reduce noise and focus on core reasoning
        summaries = [
            await self.summarize(solutions[0]),
            await self.summarize(solutions[1])
        ]

        # Step 5: Ensemble to select the most consistent and mathematically sound answer
        final_answer = await self.ensemble(
            instruction="Compare both solutions. Identify the one that satisfies all constraints and matches expected integer format between 0–999. If there's disagreement, choose based on clarity and consistency with known geometric principles.",
            contexts_to_ensemble=summaries
        )

        return final_answer