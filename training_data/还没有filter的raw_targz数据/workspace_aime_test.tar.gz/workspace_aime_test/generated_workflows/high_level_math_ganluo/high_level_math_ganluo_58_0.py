# Workflow ID: high_level_math_ganluo_58_0
# Benchmark: high_level_math_ganluo
# Data Indices: [43]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify key mathematical structure
        analysis = await self.generate(
            instruction="Identify the core mathematical elements in this problem: geometry, circles, tangency, triangle inradius, and relationships between radii."
        )

        # Step 2: Generate multiple solution paths (parallel exploration)
        task1 = self.generate(
            instruction="Assume the triangle is equilateral. Calculate the inradius using circle packing and tangency conditions.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Model the configuration as a chain of tangent circles inside the triangle. Derive a formula for the inradius based on the number and size of circles.",
            context=analysis
        )
        task3 = self.generate(
            instruction="Use coordinate geometry: place triangle ABC with B at origin, AB and BC along axes. Compute inradius via area and semiperimeter.",
            context=analysis
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble to select best-supported solution
        final_answer = await self.ensemble(
            instruction="Choose the most mathematically consistent and well-supported solution from the three generated approaches.",
            contexts_to_ensemble=solutions
        )

        # Step 4: Revise for precision — check if answer fits constraints (integer between 0–999)
        revised_answer = await self.revise(
            instruction="Verify that the final answer is an integer between 0 and 999 inclusive. If not, refine it to satisfy all constraints.",
            context_to_revise=final_answer
        )

        return revised_answer