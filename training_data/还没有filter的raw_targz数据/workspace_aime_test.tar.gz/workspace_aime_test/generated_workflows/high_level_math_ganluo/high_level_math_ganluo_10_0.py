# Workflow ID: high_level_math_ganluo_10_0
# Benchmark: high_level_math_ganluo
# Data Indices: [32]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify problem type and structure
        analysis = await self.generate(
            instruction="Analyze the problem to determine its category (e.g., combinatorics, probability, symmetry) and key constraints."
        )

        # Step 2: Parallel exploration of multiple solution paths
        task1 = self.generate(
            instruction="Generate a solution using symmetry and group theory (Burnside's lemma or orbit-stabilizer).",
            context=analysis
        )
        task2 = self.generate(
            instruction="Generate a solution using casework based on rotation angles (0°, 45°, ..., 315°).",
            context=analysis
        )
        task3 = self.generate(
            instruction="Generate a solution by modeling vertex colorings as binary strings and applying rotational invariance.",
            context=analysis
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble to select the most robust solution
        final_solution = await self.ensemble(
            instruction="Compare the three candidate solutions and choose the one that best satisfies all mathematical constraints and uses the clearest reasoning.",
            contexts_to_ensemble=solutions
        )

        # Step 4: Revise for precision — test edge cases and verify answer format
        refined_solution = await self.revise(
            instruction="Review the selected solution for logical consistency, check for missing edge cases (like all red or all blue), and ensure the final answer is an integer between 0 and 999.",
            context_to_revise=final_solution
        )

        return refined_solution