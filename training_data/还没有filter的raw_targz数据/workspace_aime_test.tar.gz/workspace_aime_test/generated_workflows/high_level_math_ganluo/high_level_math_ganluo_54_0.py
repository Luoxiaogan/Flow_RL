# Workflow ID: high_level_math_ganluo_54_0
# Benchmark: high_level_math_ganluo
# Data Indices: [25]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify problem type and key constraints
        analysis = await self.generate(
            instruction="Identify the mathematical domain (e.g., combinatorics, geometry) and extract all critical constraints from the problem statement."
        )

        # Step 2: Generate multiple solution strategies in parallel — diverge
        task1 = self.generate(
            instruction="Propose a combinatorial approach using symmetry and group theory to count valid pairings."
        )
        task2 = self.generate(
            instruction="Propose a geometric interpretation: how do equal-length segments relate to rotational symmetries of the polygon?"
        )
        task3 = self.generate(
            instruction="Propose an algebraic method using permutations and fixed-point counting (e.g., Burnside's lemma)."
        )
        strategy_candidates = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble to select the most promising path based on coherence and relevance
        selected_strategy = await self.ensemble(
            instruction="Choose the most mathematically sound and relevant strategy among the three candidates.",
            contexts_to_ensemble=strategy_candidates
        )

        # Step 4: Generate full solution based on selected strategy
        solution_draft = await self.generate(
            instruction="Using the selected strategy, generate a detailed step-by-step solution with clear justification for each step.",
            context=selected_strategy
        )

        # Step 5: Revise iteratively to improve rigor and correctness
        revised_solution = await self.revise(
            instruction="Critically review the solution draft for logical gaps, incorrect assumptions, or missing edge cases. Improve clarity and precision.",
            context_to_revise=solution_draft
        )

        # Step 6: Final verification via bidirectional reasoning
        verification = await self.generate(
            instruction="Construct an inverse problem: if this answer were correct, what would be the expected properties? Verify consistency.",
            context=revised_solution
        )

        # Step 7: Ensemble final result with original solution and verification
        final_answer = await self.ensemble(
            instruction="Select the most accurate integer answer that satisfies both the solution and the verification check.",
            contexts_to_ensemble=[revised_solution, verification]
        )

        return final_answer