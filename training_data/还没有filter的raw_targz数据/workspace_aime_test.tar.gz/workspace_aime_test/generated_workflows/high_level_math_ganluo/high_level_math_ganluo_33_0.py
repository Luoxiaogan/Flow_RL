# Workflow ID: high_level_math_ganluo_33_0
# Benchmark: high_level_math_ganluo
# Data Indices: [53]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify structure and constraints
        analysis = await self.generate(
            instruction="Analyze the problem: identify variables, constraints, and relationships between rows and columns. Note that each cell must be a digit (0-9), and two sums must equal 999 and 99 respectively."
        )

        # Step 2: Generate multiple solution strategies in parallel
        task1 = self.generate(
            instruction="Propose an algebraic approach using variables for each cell and equations based on row/column sums."
        )
        task2 = self.generate(
            instruction="Suggest a combinatorial approach focusing on digit constraints and possible carries from column addition."
        )
        task3 = self.generate(
            instruction="Explore if symmetry or modular arithmetic simplifies the problem, especially given the target sums 999 and 99."
        )
        strategies = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble the best strategy based on clarity, feasibility, and alignment with constraints
        selected_strategy = await self.ensemble(
            instruction="Evaluate the three proposed strategies and select the one most likely to lead to a correct and efficient solution.",
            contexts_to_ensemble=strategies
        )

        # Step 4: Generate full solution using the selected strategy
        solution_draft = await self.generate(
            instruction="Using the selected strategy, derive the complete solution step-by-step, including all necessary cases and validations.",
            context=selected_strategy
        )

        # Step 5: Revise solution iteratively to fix potential errors or ambiguities
        revised_solution = await self.revise(
            instruction="Review the solution draft for logical consistency, mathematical rigor, and adherence to all constraints. Fix any issues found.",
            context_to_revise=solution_draft
        )

        # Step 6: Final verification via bidirectional check — generate inverse problem
        verification_check = await self.generate(
            instruction="Construct an inverse problem: Given the final answer, verify it satisfies both original conditions (row sum = 999, column sum = 99).",
            context=revised_solution
        )

        # Step 7: Ensemble final output — ensure robustness by combining the main solution and verification
        final_answer = await self.ensemble(
            instruction="Combine the revised solution and the verification result into a single, confident answer. Ensure the answer is an integer between 0 and 999.",
            contexts_to_ensemble=[revised_solution, verification_check]
        )

        return final_answer