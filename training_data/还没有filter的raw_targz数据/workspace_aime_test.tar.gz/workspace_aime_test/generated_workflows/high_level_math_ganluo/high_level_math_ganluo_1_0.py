# Workflow ID: high_level_math_ganluo_1_0
# Benchmark: high_level_math_ganluo
# Data Indices: [36]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Analyze the problem to identify structure and constraints
        analysis = await self.generate(
            instruction="Identify key mathematical concepts involved (e.g., geometry, optimization, algebra), constraints (surface area = 54, volume = 23), and what is being asked (r^2 in reduced fraction form)."
        )

        # Step 2: Generate multiple solution paths — algebraic vs geometric reasoning
        algebraic_path = self.generate(
            instruction="Derive equations relating length, width, height (l, w, h) using surface area = 54 and volume = 23. Express r^2 as a function of l, w, h."
        )
        geometric_path = self.generate(
            instruction="Consider how to minimize the radius of a sphere containing a box: this occurs when the box is inscribed in the sphere. Use the formula for diagonal of a rectangular prism to express r^2 in terms of l, w, h."
        )

        # Step 3: Parallel exploration with both approaches
        results = await asyncio.gather(algebraic_path, geometric_path)
        combined_approach = await self.ensemble(
            instruction="Compare both solutions. Identify which approach leads to an expression for r^2 that can be minimized under the given constraints. Synthesize a unified strategy.",
            contexts_to_ensemble=results
        )

        # Step 4: Refine solution by exploring symmetry or parameterization
        refined_solution = await self.revise(
            instruction="Now that we have a candidate expression for r^2, check if it can be simplified using substitution (e.g., set x=lw, y=lh, z=wh) or Lagrange multipliers. Also verify that the minimum exists under the given constraints.",
            context_to_revise=combined_approach
        )

        # Step 5: Extract final numerical value from symbolic solution
        extraction = await self.generate(
            instruction="From the refined solution, extract the exact value of r^2 as a reduced fraction p/q. Return only the numerator and denominator.",
            context=refined_solution
        )

        # Step 6: Final ensemble to resolve ambiguity or errors in calculation
        final_answer = await self.ensemble(
            instruction="Given possible interpretations of the extracted values, select the one that satisfies all original constraints and yields an integer answer between 0 and 999 when p + q is computed.",
            contexts_to_ensemble=[extraction]
        )

        return final_answer