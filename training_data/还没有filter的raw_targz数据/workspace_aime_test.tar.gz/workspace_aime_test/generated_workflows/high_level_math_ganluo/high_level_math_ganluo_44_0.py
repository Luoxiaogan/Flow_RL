# Workflow ID: high_level_math_ganluo_44_0
# Benchmark: high_level_math_ganluo
# Data Indices: [55]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify key structure and constraints
        analysis = await self.generate(
            instruction="Analyze the problem: Identify geometric properties, symmetries, and known relationships. Focus on what makes this hexagon special (equilateral, opposite sides parallel)."
        )

        # Step 2: Generate multiple solution paths using different reasoning modes
        task1 = self.generate(
            instruction="Approach 1: Use coordinate geometry — place the hexagon in the plane with symmetry assumptions and derive side length from triangle formed by extended sides."
        )
        task2 = self.generate(
            instruction="Approach 2: Use vector geometry or complex numbers — model the hexagon as a closed polygon with equal-length vectors and exploit parallelism condition."
        )
        task3 = self.generate(
            instruction="Approach 3: Use synthetic geometry — apply properties of equilateral hexagons with parallel opposite sides to find relations between triangle sides and hexagon side."
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble to select best-supported solution
        ensemble_result = await self.ensemble(
            instruction="Compare the three candidate solutions. Choose the one that most consistently satisfies all given conditions (triangle side lengths 200, 240, 300) and uses valid mathematical reasoning.",
            contexts_to_ensemble=solutions
        )

        # Step 4: Revise for precision — check if answer fits within [0,999] and matches expected format
        final_solution = await self.revise(
            instruction="Refine the selected solution. Ensure it's an integer between 0 and 999 inclusive. If not, re-evaluate based on why the value might be invalid.",
            context_to_revise=ensemble_result
        )

        return final_solution