# Workflow ID: high_level_math_ganluo_37_0
# Benchmark: high_level_math_ganluo
# Data Indices: [50]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Analyze the problem structure and identify key constraints
        analysis = await self.generate(
            instruction="Analyze the problem to identify the mathematical definition of 'b-eautiful', its constraints, and the goal (find smallest b with >10 such numbers)."
        )

        # Step 2: Generate multiple solution strategies — combinatorial counting vs direct enumeration
        strategy_1 = self.generate(
            instruction="Generate a plan based on enumerating all two-digit numbers in base b and checking if digit sum equals sqrt(n)."
        )
        strategy_2 = self.generate(
            instruction="Generate an alternative approach using algebraic reformulation: express n as ab + c where a,c are digits in base b, then set a + c = sqrt(ab + c)."
        )

        # Step 3: Parallel exploration of both strategies
        tasks = [strategy_1, strategy_2]
        results = await asyncio.gather(*tasks)
        
        # Step 4: Ensemble the best strategy based on clarity and feasibility
        chosen_strategy = await self.ensemble(
            instruction="Choose the most promising strategy that balances mathematical rigor and computational tractability.",
            contexts_to_ensemble=results
        )

        # Step 5: Solve using the chosen strategy — generate detailed steps
        solution_draft = await self.generate(
            instruction="Using the selected strategy, generate a step-by-step solution including how to systematically test values of b starting from 2.",
            context=chosen_strategy
        )

        # Step 6: Revise iteratively to improve correctness and handle edge cases
        revised_solution = await self.revise(
            instruction="Critique the draft solution for logical gaps, especially around handling square roots, digit constraints, and boundary cases (e.g., b=2, b=10).",
            context_to_revise=solution_draft
        )

        # Step 7: Final verification by summarizing the answer and validating against original constraints
        final_summary = await self.summarize(
            context_to_summarize=revised_solution
        )

        # Step 8: Ensemble one last time if needed — this ensures robustness
        final_answer = await self.ensemble(
            instruction="Based on the summarized reasoning, output only the integer answer (between 0 and 999) that satisfies the problem's condition.",
            contexts_to_ensemble=[final_summary]
        )

        return final_answer