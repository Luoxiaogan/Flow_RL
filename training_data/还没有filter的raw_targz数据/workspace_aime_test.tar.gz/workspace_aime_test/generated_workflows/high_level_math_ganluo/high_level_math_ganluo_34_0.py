# Workflow ID: high_level_math_ganluo_34_0
# Benchmark: high_level_math_ganluo
# Data Indices: [58]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify structure and key elements
        analysis = await self.generate(
            instruction="Identify the geometric configuration, constraints, and what is being asked (e.g., difference in radii of tangent circles)."
        )

        # Step 2: Extract critical parameters from analysis for clarity
        extracted = await self.generate(
            instruction="From the analysis, extract all numerical values and relationships (radii, distances, tangency conditions).",
            context=analysis
        )

        # Step 3: Parallel exploration of two solution paths — one for inner tangent, one for outer
        task_inner = self.generate(
            instruction="Using coordinate geometry or similar triangles, derive the radius of the circle of tangency when the torus is internally tangent to the sphere."
        )
        task_outer = self.generate(
            instruction="Similarly, derive the radius of the circle of tangency when the torus is externally tangent to the sphere."
        )
        inner_solution, outer_solution = await asyncio.gather(task_inner, task_outer)

        # Step 4: Summarize both solutions for comparison
        inner_summary = await self.summarize(inner_solution)
        outer_summary = await self.summarize(outer_solution)

        # Step 5: Ensemble the two results to compute the difference r_i - r_o
        difference = await self.ensemble(
            instruction="Based on the two summarized solutions, calculate the difference r_i - r_o as a reduced fraction m/n. Return only m + n.",
            contexts_to_ensemble=[inner_summary, outer_summary]
        )

        # Step 6: Final revision to ensure correctness and format
        final_answer = await self.revise(
            instruction="Verify that the computed value satisfies all constraints and is expressed as an integer between 0 and 999.",
            context_to_revise=difference
        )

        return final_answer