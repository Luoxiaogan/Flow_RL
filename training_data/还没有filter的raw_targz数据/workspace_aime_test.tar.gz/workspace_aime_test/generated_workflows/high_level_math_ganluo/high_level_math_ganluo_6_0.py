# Workflow ID: high_level_math_ganluo_6_0
# Benchmark: high_level_math_ganluo
# Data Indices: [47]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Analyze problem structure and identify key constraints
        analysis = await self.generate(
            instruction="Analyze the given equation and constraint. Identify whether this is a combinatorics, number theory, or algebraic problem. Note key symmetries, possible substitutions, or simplifications."
        )

        # Step 2: Generate multiple solution paths in parallel — diverge
        task1 = self.generate(
            instruction="Assume symmetry: try setting a = b = c to see if it satisfies both equations.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Try generating all integer solutions (a,b,c) such that a + b + c = 300 using stars and bars. Then check which satisfy the second equation.",
            context=analysis
        )
        task3 = self.generate(
            instruction="Factor the expression a²b + a²c + b²a + b²c + c²a + c²b. Look for symmetric groupings or known identities.",
            context=analysis
        )

        # Run parallel exploration
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble to select best candidate
        final_answer = await self.ensemble(
            instruction="Compare the three proposed approaches. Which one leads to a valid, computable solution? Select the most mathematically sound path and derive the final count.",
            contexts_to_ensemble=solutions
        )

        # Step 4: Verify via bidirectional reasoning (forward + inverse)
        verification = await self.generate(
            instruction="Now, verify the final answer by checking that it satisfies both original conditions: a + b + c = 300 and the quadratic expression equals 6,000,000.",
            context=final_answer
        )

        # Optional refinement loop based on verification quality
        if "does not satisfy" in verification.lower() or "invalid" in verification.lower():
            refined_answer = await self.revise(
                instruction="The initial solution seems incorrect. Re-analyze the factorization step and recompute the valid triples based on the correct identity.",
                context_to_revise=final_answer
            )
            return refined_answer
        else:
            return final_answer