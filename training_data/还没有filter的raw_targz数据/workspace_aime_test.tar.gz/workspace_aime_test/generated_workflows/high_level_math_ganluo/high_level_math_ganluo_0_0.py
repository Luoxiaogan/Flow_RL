# Workflow ID: high_level_math_ganluo_0_0
# Benchmark: high_level_math_ganluo
# Data Indices: [51]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify key structure and constraints
        analysis = await self.generate(
            instruction="Analyze the problem: Identify what type of mathematical structure is involved (e.g., combinatorics, geometry), and list all relevant constraints or patterns."
        )

        # Step 2: Parallel exploration of multiple solution strategies
        task1 = self.generate(
            instruction="Approach 1: Use casework based on rectangle orientation relative to the dodecagon's symmetry.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Approach 2: Count valid vertex pairs that can form sides of rectangles using modular arithmetic and symmetry.",
            context=analysis
        )
        task3 = self.generate(
            instruction="Approach 3: Model this as a graph problem—vertices are polygon vertices, edges represent possible rectangle sides—and count induced rectangles.",
            context=analysis
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble to select best-supported answer from multiple approaches
        final_answer = await self.ensemble(
            instruction="Evaluate the three candidate solutions. Choose the one that aligns with all constraints and is most mathematically consistent.",
            contexts_to_ensemble=solutions
        )

        # Step 4: Optional refinement if confidence is low
        if "likely" in final_answer.lower() or "uncertain" in final_answer.lower():
            refined = await self.revise(
                instruction="Revise the selected solution by checking edge cases such as degenerate rectangles or miscounted symmetries.",
                context_to_revise=final_answer
            )
            return refined

        return final_answer