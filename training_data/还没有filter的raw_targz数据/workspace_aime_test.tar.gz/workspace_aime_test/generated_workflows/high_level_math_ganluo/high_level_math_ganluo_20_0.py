# Workflow ID: high_level_math_ganluo_20_0
# Benchmark: high_level_math_ganluo
# Data Indices: [24]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand the structure and constraints
        analysis = await self.generate(
            instruction="Analyze the problem to identify key constraints: arrangement of chairs, selection rules (no person sits next to two others), and what needs to be counted."
        )

        # Step 2: Generate multiple solution strategies in parallel
        task1 = self.generate(
            instruction="Model this as a combinatorics problem with forbidden configurations: no three consecutive chairs occupied."
        )
        task2 = self.generate(
            instruction="Use recursion or dynamic programming to count valid subsets of 8 chairs from 16 under the given adjacency constraint."
        )
        task3 = self.generate(
            instruction="Explore generating functions or inclusion-exclusion to compute the number of valid selections."
        )
        strategy_candidates = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble the best approach based on clarity, feasibility, and alignment
        chosen_strategy = await self.ensemble(
            instruction="Select the most promising strategy based on mathematical soundness, simplicity, and applicability to the problem constraints.",
            contexts_to_ensemble=strategy_candidates
        )

        # Step 4: Generate detailed step-by-step solution using the chosen strategy
        solution_draft = await self.generate(
            instruction="Now write a complete, rigorous step-by-step solution using the selected strategy. Include all necessary definitions, recursive relations, base cases, and final computation steps.",
            context=chosen_strategy
        )

        # Step 5: Revise the solution for logical consistency, edge case handling, and clarity
        refined_solution = await self.revise(
            instruction="Critically review the solution for any logical gaps, incorrect assumptions, or missing edge cases (e.g., small n values, boundary conditions). Improve rigor and correctness.",
            context_to_revise=solution_draft
        )

        # Step 6: Final verification by summarizing the answer and checking against constraints
        summary = await self.summarize(
            context_to_summarize=refined_solution
        )
        
        # Step 7: Ensemble final answer from multiple perspectives if needed
        final_answer = await self.ensemble(
            instruction="Based on the summarized solution, extract the final integer answer (between 0 and 999) that satisfies all constraints. If there's ambiguity, resolve it using mathematical reasoning.",
            contexts_to_ensemble=[summary]
        )

        return final_answer