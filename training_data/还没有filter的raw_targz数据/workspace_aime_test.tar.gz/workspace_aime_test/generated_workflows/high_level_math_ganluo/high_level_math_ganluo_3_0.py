# Workflow ID: high_level_math_ganluo_3_0
# Benchmark: high_level_math_ganluo
# Data Indices: [7]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand structure and constraints
        analysis = await self.generate(
            instruction="Analyze the system of equations involving complex numbers. Identify geometric interpretations (e.g., circles, perpendicular bisectors). Note key constraints."
        )

        # Step 2: Generate Multiple Interpretations — Diverge into algebraic and geometric paths
        algebraic_path = self.generate(
            instruction="Translate the first equation |25+20i - z| = 5 into its geometric meaning: a circle centered at (25, 20) with radius 5. Then interpret the second equation as a locus condition.",
            context=analysis
        )
        geometric_path = self.generate(
            instruction="Interpret both equations geometrically: the first is a circle; the second is the set of points equidistant from two fixed points, i.e., a perpendicular bisector line. Determine when they intersect in exactly one point.",
            context=analysis
        )

        # Step 3: Parallel Exploration — Run both approaches independently
        tasks = [
            algebraic_path,
            geometric_path
        ]
        results = await asyncio.gather(*tasks)

        # Step 4: Ensemble — Synthesize the best solution from multiple perspectives
        synthesis = await self.ensemble(
            instruction="Compare the two solutions: one based on algebraic manipulation of complex numbers, the other using geometry. Choose the most mathematically consistent and complete approach.",
            contexts_to_ensemble=results
        )

        # Step 5: Refine — Apply iterative revision to eliminate errors or ambiguities
        refined_solution = await self.revise(
            instruction="Check if the final answer satisfies all original constraints and verify that it accounts for the uniqueness condition. If not, revise accordingly.",
            context_to_revise=synthesis
        )

        # Step 6: Final Summary — Compress to ensure clarity and correctness
        final_answer = await self.summarize(
            context_to_summarize=refined_solution
        )

        return final_answer