# Workflow ID: high_level_math_ganluo_13_0
# Benchmark: high_level_math_ganluo
# Data Indices: [37]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis — identify mathematical structure and constraints
        analysis = await self.generate(
            instruction="Analyze the given equation system. Identify variables, constraints, and potential transformations (e.g., logarithmic identities)."
        )

        # Step 2: Generate multiple solution paths — explore different approaches
        task1 = self.generate(
            instruction="Use logarithmic identities to simplify the first equation: log_x(y^x) = 10.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Similarly, simplify the second equation: log_y(x^{4y}) = 10.",
            context=analysis
        )
        task3 = self.generate(
            instruction="Now, derive a relationship between x and y from both simplified equations.",
            context=analysis
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble candidate solutions — resolve discrepancies or select best path
        ensemble_result = await self.ensemble(
            instruction="Compare the three derived relationships. Which one leads to a consistent solution for xy? If there's conflict, explain why.",
            contexts_to_ensemble=solutions
        )

        # Step 4: Refine using bidirectional verification — check if solution satisfies original conditions
        refined = await self.revise(
            instruction="Verify that the proposed value of xy satisfies both original logarithmic equations. If not, revise the approach based on what went wrong.",
            context_to_revise=ensemble_result
        )

        # Step 5: Final summary and extraction of answer
        final_answer = await self.summarize(
            context_to_summarize=refined
        )

        return final_answer