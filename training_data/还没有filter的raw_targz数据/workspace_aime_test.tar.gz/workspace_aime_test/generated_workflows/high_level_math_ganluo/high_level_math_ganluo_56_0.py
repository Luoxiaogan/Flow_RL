# Workflow ID: high_level_math_ganluo_56_0
# Benchmark: high_level_math_ganluo
# Data Indices: [16]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Analyze the problem structure and identify key mathematical domain
        analysis = await self.generate(
            instruction="Analyze the problem to determine its mathematical domain (e.g., number theory, algebra, combinatorics) and key constraints."
        )

        # Step 2: Generate multiple solution strategies in parallel — diverge
        strategy_tasks = [
            self.generate(
                instruction="Generate an algebraic approach focusing on divisibility conditions and polynomial manipulation.",
                context=analysis
            ),
            self.generate(
                instruction="Generate a number-theoretic approach using modular arithmetic and factorization techniques.",
                context=analysis
            ),
            self.generate(
                instruction="Generate a case-based approach by testing small values of n to detect patterns or constraints.",
                context=analysis
            )
        ]
        strategies = await asyncio.gather(*strategy_tasks)

        # Step 3: Summarize each strategy to extract core ideas
        summaries = [await self.summarize(strategy) for strategy in strategies]

        # Step 4: Ensemble the best candidate solution based on logical consistency and completeness
        final_solution = await self.ensemble(
            instruction="Select the most mathematically sound and complete solution from the three strategies, resolving contradictions if any.",
            contexts_to_ensemble=summaries
        )

        # Step 5: Revise the final solution to ensure correctness and address edge cases
        revised_solution = await self.revise(
            instruction="Review the solution carefully for logical gaps, computational errors, and boundary conditions (e.g., small n values).",
            context_to_revise=final_solution
        )

        return revised_solution