# Workflow ID: high_level_math_ganluo_50_0
# Benchmark: high_level_math_ganluo
# Data Indices: [5]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Analyze the problem structure and identify key elements
        analysis = await self.generate(
            instruction="Identify all mathematical objects, constraints, and what is being asked. Focus on geometry, area, and circle tangency."
        )

        # Step 2: Extract key facts into structured form for reasoning
        extracted = await self.generate(
            instruction="Extract numerical values, geometric relationships, and unknowns from the analysis. Format as bullet points.",
            context=analysis
        )

        # Step 3: Generate multiple solution paths — algebraic and geometric
        tasks = [
            self.generate(
                instruction="Solve using coordinate geometry: place trapezoid symmetrically on coordinate plane, derive equations from tangency and area.",
                context=extracted
            ),
            self.generate(
                instruction="Solve using properties of tangential quadrilaterals: use formula for area in terms of inradius and semiperimeter.",
                context=extracted
            )
        ]
        solutions = await asyncio.gather(*tasks)

        # Step 4: Summarize each approach to compare clarity and correctness
        summaries = [await self.summarize(s) for s in solutions]

        # Step 5: Ensemble to select the most robust and mathematically sound solution
        final_answer = await self.ensemble(
            instruction="Choose the best solution based on internal consistency, derivation completeness, and adherence to known geometric principles.",
            contexts_to_ensemble=summaries
        )

        # Step 6: Revise if necessary — test answer against original constraints
        revised = await self.revise(
            instruction="Verify that the derived value satisfies both the area condition (72) and the inradius condition (3). If not, revise the solution.",
            context_to_revise=final_answer
        )

        return revised