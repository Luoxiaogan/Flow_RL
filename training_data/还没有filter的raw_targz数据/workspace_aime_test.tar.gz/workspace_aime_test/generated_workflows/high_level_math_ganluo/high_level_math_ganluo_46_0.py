# Workflow ID: high_level_math_ganluo_46_0
# Benchmark: high_level_math_ganluo
# Data Indices: [15]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify problem type and key elements
        analysis = await self.generate(
            instruction="Analyze the problem structure: identify known distances, points, and what needs to be computed (e.g., area of triangle). Note geometric constraints and possible coordinate-based approaches."
        )

        # Step 2: Extract key data from the analysis for structured reasoning
        extracted_data = await self.generate(
            instruction="Extract all given lengths and relationships into a clean list of values with labels (e.g., 'AC=26', 'CG=40'). Focus only on measurable quantities relevant to computing triangle area.",
            context=analysis
        )

        # Step 3: Generate multiple solution paths in parallel — algebraic vs coordinate geometry
        task1 = self.generate(
            instruction="Propose an algebraic approach using vectors or coordinate geometry: assign coordinates to points A-F on x-axis, compute G's position using distance constraints, then find area of triangle BGE via determinant formula."
        )
        task2 = self.generate(
            instruction="Propose a synthetic geometry approach: look for similar triangles, right angles, or symmetry that might simplify area calculation without full coordinate setup."
        )
        task3 = self.generate(
            instruction="Propose a vector-based method: express vectors BG and EG, then use cross product to compute area directly from coordinates or relative positions."
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble the best solution based on consistency and clarity
        final_solution = await self.ensemble(
            instruction="Compare the three proposed solutions. Choose the one that is most mathematically rigorous, uses the given data effectively, and avoids unnecessary assumptions. Return only the final answer as an integer between 0 and 999.",
            contexts_to_ensemble=solutions
        )

        # Optional refinement step if ensemble output seems uncertain
        if "likely" in final_solution.lower() or "possible" in final_solution.lower():
            refined = await self.revise(
                instruction="Refine the solution by checking for hidden constraints or verifying against edge cases (e.g., collinearity, degenerate triangle). Ensure the final answer satisfies all original conditions.",
                context_to_revise=final_solution
            )
            return refined

        return final_solution