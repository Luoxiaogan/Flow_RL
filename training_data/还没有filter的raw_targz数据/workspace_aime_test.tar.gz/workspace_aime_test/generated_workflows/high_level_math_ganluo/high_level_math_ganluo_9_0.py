# Workflow ID: high_level_math_ganluo_9_0
# Benchmark: high_level_math_ganluo
# Data Indices: [49]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis — understand the structure and mathematical domain
        analysis = await self.generate(
            instruction="Analyze the problem to identify key mathematical concepts involved (e.g., roots of unity, polynomial evaluation, modular arithmetic)."
        )

        # Step 2: Generate multiple solution paths in parallel — exploit diverse strategies
        task1 = self.generate(
            instruction="Approach 1: Use properties of cyclotomic polynomials and evaluate the product using symmetry of roots of unity."
        )
        task2 = self.generate(
            instruction="Approach 2: Convert the expression into a polynomial in ω and simplify using known identities for powers of roots of unity."
        )
        task3 = self.generate(
            instruction="Approach 3: Consider the product as evaluating a specific polynomial at all 13th roots of unity and relate it to resultant or norm computation."
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble the competing solutions — select best-supported answer
        final_answer = await self.ensemble(
            instruction="Compare the three candidate solutions. Choose the one that is mathematically consistent, uses valid algebraic steps, and satisfies the modular constraint (remainder modulo 1000).",
            contexts_to_ensemble=solutions
        )

        # Step 4: Revise if necessary — verify against edge cases or hidden constraints
        revised_answer = await self.revise(
            instruction="Check whether the selected solution correctly handles the condition ω ≠ 1 and ensures the final result is an integer between 0 and 999.",
            context_to_revise=final_answer
        )

        return revised_answer