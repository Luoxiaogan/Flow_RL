# Workflow ID: high_level_math_ganluo_59_0
# Benchmark: high_level_math_ganluo
# Data Indices: [39]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis
        analysis = await self.generate(
            instruction="Analyze the problem structure: identify what is being asked (probability), the sample space, and the conditional nature of the event."
        )

        # Step 2: Extract Key Quantities
        key_info = await self.generate(
            instruction="From the analysis, extract the total number of ways to choose 4 numbers from S, the favorable outcomes for winning a prize, and for the grand prize.",
            context=analysis
        )

        # Step 3: Parallel Exploration of Two Paths
        # Path A: Direct probability calculation
        path_a = self.generate(
            instruction="Compute P(grand prize | prize) using Bayes' theorem or direct conditional probability: count favorable cases over total prize cases."
        )
        # Path B: Enumerate all possible outcomes systematically
        path_b = self.generate(
            instruction="Generate a step-by-step combinatorial argument to compute the same conditional probability by considering how many subsets of size 4 contain at least two matches and exactly four matches."
        )

        # Run both paths in parallel
        results = await asyncio.gather(path_a, path_b)

        # Step 4: Ensemble Final Answer
        final_answer = await self.ensemble(
            instruction="Compare the two approaches and select the most accurate solution. If they agree, output that. If not, explain discrepancies and choose the best-supported one.",
            contexts_to_ensemble=results
        )

        # Step 5: Revise for Clarity and Rigor
        revised_final = await self.revise(
            instruction="Ensure the final answer is an integer between 0 and 999, formatted as a single number with no extra text or explanation.",
            context_to_revise=final_answer
        )

        return revised_final