# Workflow ID: high_level_math_ganluo_18_0
# Benchmark: high_level_math_ganluo
# Data Indices: [13]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify key structure and constraints
        analysis = await self.generate(
            instruction="Analyze the problem to identify the geometric configuration, known lengths, angles, and what needs to be minimized (f(X) = sum of distances from X to each vertex)."
        )

        # Step 2: Generate multiple solution strategies using parallel exploration
        task1 = self.generate(
            instruction="Generate a geometric approach using Fermat-Torricelli point or similar optimization techniques for minimizing total distance to points."
        )
        task2 = self.generate(
            instruction="Generate an algebraic coordinate-based approach by placing the pentagon on the coordinate plane using given side lengths and angles."
        )
        task3 = self.generate(
            instruction="Generate a symmetry or transformation-based strategy considering that angle B and E are both 60 degrees."
        )
        strategies = await asyncio.gather(task1, task2, task3)

        # Step 3: Summarize each strategy to extract key ideas
        summaries = [await self.summarize(s) for s in strategies]

        # Step 4: Ensemble the best strategy based on coherence and mathematical plausibility
        best_strategy = await self.ensemble(
            instruction="Compare the three generated strategies and select the most promising one based on clarity, feasibility, and alignment with known mathematical principles.",
            contexts_to_ensemble=summaries
        )

        # Step 5: Generate a full solution using the selected strategy
        solution = await self.generate(
            instruction="Using the selected strategy, generate a complete step-by-step solution including all necessary calculations and reasoning.",
            context=best_strategy
        )

        # Step 6: Refine the solution through iterative revision
        revised_solution = await self.revise(
            instruction="Critically review the solution for logical consistency, correct application of geometry/optimization principles, and computational accuracy. Fix any errors or ambiguities.",
            context_to_revise=solution
        )

        # Step 7: Final verification via bidirectional check
        final_answer = await self.generate(
            instruction="Based on the refined solution, compute the final value of f(X) in the form m + n√p and return only the integer m+n+p.",
            context=revised_solution
        )

        return final_answer