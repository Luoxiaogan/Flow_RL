# Workflow ID: high_level_math_ganluo_17_0
# Benchmark: high_level_math_ganluo
# Data Indices: [18]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify structure and strategy
        analysis = await self.generate(
            instruction="Analyze the given product expression. Identify patterns in the logarithmic terms and potential simplifications using log identities."
        )

        # Step 2: Generate multiple solution paths via parallel exploration
        task1 = self.generate(
            instruction="Apply logarithmic identities (e.g., log_b(a^c) = c*log_b(a)) to simplify each term in the product.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Look for telescoping behavior by expressing each fraction as a ratio of logs with same base or related bases.",
            context=analysis
        )
        task3 = self.generate(
            instruction="Consider rewriting the entire product as a single logarithm using properties of exponents and logs.",
            context=analysis
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble to select best-supported solution
        final_solution = await self.ensemble(
            instruction="Compare the three candidate solutions. Choose the one that correctly simplifies the product into a reduced fraction m/n.",
            contexts_to_ensemble=solutions
        )

        # Step 4: Revise for precision — check if answer satisfies all constraints and is an integer between 0 and 999
        refined_solution = await self.revise(
            instruction="Verify that the proposed answer m+n is an integer between 0 and 999 and makes mathematical sense. If not, revise accordingly.",
            context_to_revise=final_solution
        )

        return refined_solution