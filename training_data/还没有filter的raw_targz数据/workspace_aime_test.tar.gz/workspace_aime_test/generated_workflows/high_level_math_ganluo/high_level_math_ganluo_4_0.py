# Workflow ID: high_level_math_ganluo_4_0
# Benchmark: high_level_math_ganluo
# Data Indices: [31]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand the problem structure and identify key elements
        analysis = await self.generate(
            instruction="Analyze the problem to identify geometric entities, known lengths, and relationships (e.g., tangents, cyclic quadrilateral, power of a point)."
        )

        # Step 2: Generate Multiple Solution Approaches — Use parallel exploration for geometry problems
        task1 = self.generate(
            instruction="Approach 1: Use coordinate geometry. Place triangle ABC on coordinate plane using given side lengths. Find coordinates of D and P, then compute AP."
        )
        task2 = self.generate(
            instruction="Approach 2: Use synthetic geometry and properties of tangents and circles. Apply Power of a Point theorem at A with respect to circle ω."
        )
        task3 = self.generate(
            instruction="Approach 3: Use trigonometry and Law of Cosines to find angles, then apply similar triangles or angle chasing to relate AP to other segments."
        )
        approaches = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble the best approach based on feasibility and clarity
        ensemble_result = await self.ensemble(
            instruction="Compare the three proposed solution paths. Select the most promising one based on mathematical elegance, computational tractability, and alignment with known techniques for this problem type.",
            contexts_to_ensemble=approaches
        )

        # Step 4: Generate Detailed Solution Based on Selected Approach
        detailed_solution = await self.generate(
            instruction="Now generate a step-by-step solution using the selected method. Include all necessary intermediate steps, such as calculations, geometric insights, and algebraic manipulations.",
            context=ensemble_result
        )

        # Step 5: Revise for Rigor — Check for logical gaps, missing constraints, or arithmetic errors
        revised_solution = await self.revise(
            instruction="Critically review the solution for internal consistency, correctness of assumptions, and adherence to all given conditions (AB=5, BC=9, AC=10). Fix any errors or ambiguities.",
            context_to_revise=detailed_solution
        )

        # Step 6: Final Verification — Ensure answer format is correct (integer between 0–999)
        verification = await self.generate(
            instruction="Extract the final answer from the revised solution. Confirm it matches the required form (fraction m/n in lowest terms) and that m + n is an integer between 0 and 999.",
            context=revised_solution
        )

        return verification