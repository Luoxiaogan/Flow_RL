# Workflow ID: high_level_math_ganluo_52_0
# Benchmark: high_level_math_ganluo
# Data Indices: [17]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify problem type and structure
        analysis = await self.generate(
            instruction="Analyze the problem to determine its category (e.g., combinatorics, geometry) and key constraints."
        )

        # Step 2: Extract structured elements — e.g., grid size, coloring rules
        extraction = await self.generate(
            instruction="From the analysis, extract all relevant numerical constraints, variables, and structural features.",
            context=analysis
        )

        # Step 3: Parallel exploration of multiple solution strategies
        task1 = self.generate(
            instruction="Use casework based on edge colorings in the 2x2 grid to count valid configurations."
        )
        task2 = self.generate(
            instruction="Model this as a constraint satisfaction problem using modular arithmetic or graph theory."
        )
        task3 = self.generate(
            instruction="Apply symmetry considerations to reduce overcounting and simplify enumeration."
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble to select best-supported solution
        final_answer = await self.ensemble(
            instruction="Evaluate the three candidate solutions and choose the most consistent one that satisfies all constraints.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Final verification via bidirectional reasoning
        verification = await self.revise(
            instruction="Check if the selected answer logically leads back to the original problem conditions. If not, revise it accordingly.",
            context_to_revise=final_answer
        )

        return verification