# Workflow ID: high_level_math_ganluo_25_0
# Benchmark: high_level_math_ganluo
# Data Indices: [59]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand constraints and structure
        analysis = await self.generate(
            instruction="Analyze the problem statement to identify key constraints: (1) each cell at most one chip, (2) same color per row/column, (3) maximal placement (no more chips can be added)."
        )

        # Step 2: Extract structural insights — what does "maximal" imply?
        extraction = await self.generate(
            instruction="Based on the analysis, extract the mathematical implications of the 'maximal' condition — specifically, how it relates to row/column coloring and chip placement.",
            context=analysis
        )

        # Step 3: Parallel exploration of possible configurations
        task1 = self.generate(
            instruction="Assume all rows are colored black — what is the maximum number of chips that can be placed under the constraints?",
            context=extraction
        )
        task2 = self.generate(
            instruction="Assume all columns are colored white — what is the maximum number of chips that can be placed under the constraints?",
            context=extraction
        )
        task3 = self.generate(
            instruction="Assume some rows are black and others white — derive a general formula for the total number of chips based on row and column colorings.",
            context=extraction
        )

        results = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble to select the correct configuration type
        ensemble_result = await self.ensemble(
            instruction="Compare the three candidate solutions: full-row-coloring, full-column-coloring, mixed-coloring. Determine which satisfies all constraints including maximality and uniqueness.",
            contexts_to_ensemble=results
        )

        # Step 5: Revise if needed — verify against edge cases like empty grid or single-cell
        final_solution = await self.revise(
            instruction="Verify the selected solution by checking whether adding any additional chip would violate the constraints. Also ensure the answer is an integer between 0 and 999.",
            context_to_revise=ensemble_result
        )

        return final_solution