# Workflow ID: high_level_math_ganluo_48_0
# Benchmark: high_level_math_ganluo
# Data Indices: [28]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand structure and constraints
        analysis = await self.generate(
            instruction="Analyze the geometric configuration: identify known lengths, equal segments, and symmetry. Note that triangle ABC is right-angled at A with hypotenuse BC=38, and points K,L satisfy AK=AL=BK=CL=KL=14."
        )

        # Step 2: Diverge — Explore multiple solution strategies (coordinate geometry vs synthetic geometry)
        coord_task = self.generate(
            instruction="Assume coordinates: place A at origin, B and C on axes. Derive coordinates of K and L using distance constraints. Then compute area of quadrilateral BKLC."
        )
        synth_task = self.generate(
            instruction="Use synthetic geometry: exploit symmetry from equal segments AK=AL=BK=CL=KL=14 to deduce angles or congruences. Use properties of equilateral triangles or rotations to find area of BKLC."
        )
        tasks = [coord_task, synth_task]
        results = await asyncio.gather(*tasks)

        # Step 3: Ensemble — Compare both approaches to select most reliable path
        ensemble_result = await self.ensemble(
            instruction="Compare the two solutions: coordinate-based and synthetic. Which one provides clearer reasoning, fewer assumptions, and matches expected form n√3? Choose the best-supported approach.",
            contexts_to_ensemble=results
        )

        # Step 4: Refine — Revise based on potential errors in assumption or calculation
        refined_solution = await self.revise(
            instruction="Critique the chosen solution for logical gaps, miscalculations, or missing edge cases (e.g., uniqueness of K,L). Improve clarity and correctness.",
            context_to_revise=ensemble_result
        )

        # Step 5: Final Verification — Check if answer satisfies all constraints and yields integer n
        verification = await self.generate(
            instruction="Verify that the final expression for the area of quadrilateral BKLC is indeed of the form n√3. Confirm that all given distances (AK=AL=BK=CL=KL=14) are satisfied in your solution.",
            context=refined_solution
        )

        return verification