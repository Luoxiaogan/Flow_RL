# Workflow ID: high_level_math_ganluo_49_0
# Benchmark: high_level_math_ganluo
# Data Indices: [22]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand the problem structure
        analysis = await self.generate(
            instruction="Analyze the problem to identify key mathematical components: coin denominations, greedy algorithm behavior, and what it means for the algorithm to succeed."
        )

        # Step 2: Generate multiple solution strategies (parallel exploration)
        strategy_tasks = [
            self.generate(instruction="Propose a brute-force approach: check each N from 1 to 1000 to see if greedy yields minimal coins."),
            self.generate(instruction="Propose a recursive or dynamic programming approach: define f(n) as minimum coins needed for n cents, then compare with greedy result."),
            self.generate(instruction="Propose an analytical approach: find patterns in when greedy fails—e.g., cases where using more small coins is better than one large coin.")
        ]
        strategies = await asyncio.gather(*strategy_tasks)

        # Step 3: Ensemble best strategy based on feasibility and insight
        best_strategy = await self.ensemble(
            instruction="Evaluate these three strategies and select the most promising one for solving this specific problem efficiently.",
            contexts_to_ensemble=strategies
        )

        # Step 4: Generate detailed plan based on chosen strategy
        plan = await self.generate(
            instruction="Based on the selected strategy, outline a step-by-step computational or mathematical plan to count how many values of N between 1 and 1000 make the greedy algorithm succeed.",
            context=best_strategy
        )

        # Step 5: Execute the plan — generate the actual solution
        solution = await self.generate(
            instruction="Now compute the exact number of integers N between 1 and 1000 for which the greedy algorithm succeeds, following the plan.",
            context=plan
        )

        # Step 6: Refine solution through iterative revision
        revised_solution = await self.revise(
            instruction="Check the solution for logical consistency: does it account for all edge cases? Are there any errors in counting or reasoning?",
            context_to_revise=solution
        )

        # Step 7: Final ensemble if needed — but only if we have uncertainty
        final_answer = await self.ensemble(
            instruction="If the solution seems ambiguous or incomplete, synthesize the best answer from the current version and any additional insights. Otherwise, return the current solution.",
            contexts_to_ensemble=[revised_solution]
        )

        return final_answer