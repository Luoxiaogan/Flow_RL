# Workflow ID: high_level_math_ganluo_27_0
# Benchmark: high_level_math_ganluo
# Data Indices: [44]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify mathematical domain and key constraints
        analysis = await self.generate(
            instruction="Analyze the problem statement to determine its mathematical domain (e.g., geometry, algebra) and extract all constraints, especially those involving symmetry, coordinates, or invariants."
        )

        # Step 2: Generate multiple solution paths — one geometric, one algebraic
        tasks = [
            self.generate(
                instruction="Generate a geometric approach focusing on properties of rhombi and hyperbolas, particularly how diagonals intersecting at the origin constrain point positions.",
                context=analysis
            ),
            self.generate(
                instruction="Generate an algebraic approach by parameterizing points on the hyperbola and using the condition that ABCD forms a rhombus with diagonals intersecting at the origin.",
                context=analysis
            )
        ]
        path_results = await asyncio.gather(*tasks)

        # Step 3: Summarize each path to clarify structure and assumptions
        summaries = await asyncio.gather(
            self.summarize(path_results[0]),
            self.summarize(path_results[1])
        )

        # Step 4: Ensemble to select the most promising approach based on clarity and feasibility
        chosen_approach = await self.ensemble(
            instruction="Compare both approaches and choose the one that seems more tractable given the problem's symmetry and constraints.",
            contexts_to_ensemble=summaries
        )

        # Step 5: Generate full solution using the chosen approach
        solution = await self.generate(
            instruction="Using the selected method, derive a complete step-by-step solution including all necessary calculations and justifications.",
            context=chosen_approach
        )

        # Step 6: Revise solution iteratively to improve rigor and correctness
        revised_solution = await self.revise(
            instruction="Review the solution for logical gaps, computational errors, or missed edge cases such as degenerate rhombi or boundary conditions.",
            context_to_revise=solution
        )

        # Step 7: Final ensemble if needed — only if multiple versions exist (e.g., from different sub-problems)
        final_answer = await self.ensemble(
            instruction="Based on the revised solution, output the final numerical answer satisfying all constraints. Ensure it is an integer between 0 and 999.",
            contexts_to_ensemble=[revised_solution]
        )

        return final_answer