# Workflow ID: high_level_math_ganluo_29_0
# Benchmark: high_level_math_ganluo
# Data Indices: [4]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Analyze the problem to identify key mathematical structure
        analysis = await self.generate(
            instruction="Identify the mathematical domain (e.g., combinatorics, number theory) and constraints in this problem."
        )

        # Step 2: Extract key facts from the analysis for structured reasoning
        extracted = await self.generate(
            instruction="From the analysis, extract all relevant numerical constraints, conditions, and required computations.",
            context=analysis
        )

        # Step 3: Parallel exploration of multiple solution paths (e.g., casework vs formula)
        task1 = self.generate(
            instruction="Generate a solution using casework based on divisibility rules for 22 (i.e., divisible by 2 and 11).",
            context=extracted
        )
        task2 = self.generate(
            instruction="Generate a solution using the formula for counting permutations with divisibility constraints.",
            context=extracted
        )
        task3 = self.generate(
            instruction="Generate a recursive or dynamic programming approach if applicable.",
            context=extracted
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble to select the most consistent and mathematically sound solution
        final_answer = await self.ensemble(
            instruction="Compare the three candidate solutions. Select the one that best satisfies all constraints and uses valid mathematical reasoning.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Verify consistency with known answer format (integer between 0–999)
        verification = await self.revise(
            instruction="Check if the final answer is an integer between 0 and 999 inclusive. If not, refine it until it is.",
            context_to_revise=final_answer
        )

        return verification