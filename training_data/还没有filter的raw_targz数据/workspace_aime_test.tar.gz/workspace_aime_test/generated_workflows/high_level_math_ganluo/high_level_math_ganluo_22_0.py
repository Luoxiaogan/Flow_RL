# Workflow ID: high_level_math_ganluo_22_0
# Benchmark: high_level_math_ganluo
# Data Indices: [29]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand structure and constraints
        analysis = await self.generate(
            instruction="Analyze the function f(x) = (x - 18)(x - 72)(x - 98)(x - k)/x. Identify critical points, behavior at boundaries, and conditions under which it achieves minimum at exactly two positive real numbers."
        )

        # Step 2: Parallel Exploration — Generate multiple solution strategies
        task1 = self.generate(
            instruction="Assume k is such that the derivative f'(x) has exactly two positive roots where minimum occurs. Derive necessary conditions using calculus.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Consider symmetry in the roots 18, 72, 98. Could there be values of k that make f(x) symmetric or allow double minima via algebraic identity?",
            context=analysis
        )
        task3 = self.generate(
            instruction="Explore cases where the function exhibits a repeated root in its derivative — this might correspond to two x-values achieving minimum simultaneously.",
            context=analysis
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble — Synthesize best candidate solutions
        ensemble_result = await self.ensemble(
            instruction="Compare the three proposed approaches. Which one provides the clearest path to finding k values that result in exactly two positive x-values where f(x) achieves minimum? Select the most mathematically sound approach.",
            contexts_to_ensemble=solutions
        )

        # Step 4: Refinement Loop — Iteratively improve based on internal consistency checks
        refined_solution = await self.revise(
            instruction="Check if the selected strategy correctly identifies all three values of k by verifying that each leads to exactly two positive x-values where f(x) reaches a minimum. If not, refine the logic to account for edge cases like multiplicity or boundary behavior.",
            context_to_revise=ensemble_result
        )

        # Step 5: Final Summary & Answer Extraction
        final_summary = await self.summarize(
            context_to_summarize=refined_solution
        )

        return final_summary