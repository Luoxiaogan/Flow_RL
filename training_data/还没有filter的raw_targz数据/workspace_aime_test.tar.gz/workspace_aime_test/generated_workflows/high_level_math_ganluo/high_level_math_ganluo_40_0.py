# Workflow ID: high_level_math_ganluo_40_0
# Benchmark: high_level_math_ganluo
# Data Indices: [0]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis
        analysis = await self.generate(
            instruction="Analyze the problem to identify key mathematical concepts: number bases, divisibility, and integer constraints."
        )

        # Step 2: Extract structured facts from analysis
        extracted_facts = await self.generate(
            instruction="From the analysis, extract all relevant mathematical relationships and constraints in structured form.",
            context=analysis
        )

        # Step 3: Parallel exploration of multiple solution paths
        task1 = self.generate(
            instruction="Generate an algebraic approach: express 17_b and 97_b in base 10, then set up the divisibility condition."
        )
        task2 = self.generate(
            instruction="Generate a modular arithmetic approach: analyze the divisibility condition modulo b."
        )
        task3 = self.generate(
            instruction="Generate a case-based approach: test small values of b > 9 to find patterns or constraints."
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble the competing solutions
        ensemble_result = await self.ensemble(
            instruction="Compare the three generated solutions. Identify which one(s) correctly handle the base constraint (b > 9) and provide a valid integer answer between 0 and 999.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Revise if needed — check internal consistency
        final_solution = await self.revise(
            instruction="Review the ensemble result for logical consistency, numerical correctness, and whether it satisfies the original divisibility condition in base b.",
            context_to_revise=ensemble_result
        )

        return final_solution