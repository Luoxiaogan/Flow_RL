# Workflow ID: high_level_math_ganluo_31_0
# Benchmark: high_level_math_ganluo
# Data Indices: [11]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis — understand structure and constraints
        analysis = await self.generate(
            instruction="Analyze the problem to identify key mathematical components: plane equation, inequalities, and what is being asked (area in form a√b)."
        )

        # Step 2: Extract critical elements — isolate equations, regions, and target
        extracted = await self.generate(
            instruction="From the analysis, extract all mathematical expressions, inequalities, and conditions that define the region(s) and the finite area requirement.",
            context=analysis
        )

        # Step 3: Parallel exploration — try multiple solution strategies
        task1 = self.generate(
            instruction="Approach using coordinate geometry: interpret the plane x+y+z=75 and analyze how the inequalities define convex regions."
        )
        task2 = self.generate(
            instruction="Approach using symmetry: look for invariant transformations or substitutions that simplify the inequalities."
        )
        task3 = self.generate(
            instruction="Approach using algebraic manipulation: rewrite the inequalities into a standard form for region classification."
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble — select best-supported solution based on consistency
        ensemble_result = await self.ensemble(
            instruction="Compare the three approaches above. Which one most clearly identifies the finite region and computes its area as a√b?",
            contexts_to_ensemble=solutions
        )

        # Step 5: Refinement — verify the selected solution rigorously
        final_solution = await self.revise(
            instruction="Critically review the ensemble result for logical consistency, mathematical correctness, and whether it matches the expected answer format (a√b). Fix any errors.",
            context_to_revise=ensemble_result
        )

        # Step 6: Final extraction — ensure the output is just the integer a+b
        final_answer = await self.generate(
            instruction="Extract only the integer value of a + b from the final solution. Do not include explanation or formatting.",
            context=final_solution
        )

        return final_answer