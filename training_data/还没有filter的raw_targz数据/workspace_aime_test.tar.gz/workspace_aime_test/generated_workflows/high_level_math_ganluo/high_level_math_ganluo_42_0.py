# Workflow ID: high_level_math_ganluo_42_0
# Benchmark: high_level_math_ganluo
# Data Indices: [40]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis — understand structure and constraints
        analysis = await self.generate(
            instruction="Analyze the geometric configuration: identify all given lengths, collinear points, and cyclic quadrilateral properties."
        )

        # Step 2: Extract key facts — focus on measurable quantities and relationships
        extracted = await self.generate(
            instruction="From the analysis, extract only the relevant numerical values and geometric conditions (e.g., side lengths, collinearity, circle constraint).",
            context=analysis
        )

        # Step 3: Parallel exploration — try multiple solution paths (algebraic, coordinate-based, synthetic geometry)
        task1 = self.generate(
            instruction="Assume coordinates for points A, B, C, D; then compute CE using vector or distance formulas based on given sides BC=16, AB=107, FG=17, EF=184.",
            context=extracted
        )
        task2 = self.generate(
            instruction="Use properties of cyclic quadrilaterals (A,D,H,G on a circle) to derive angle relations or power of a point equations that may help find CE.",
            context=extracted
        )
        task3 = self.generate(
            instruction="Apply similarity or congruence between triangles formed by collinear points D,E,C,F to express CE in terms of known segments.",
            context=extracted
        )

        # Execute parallel approaches
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble — compare and synthesize best candidate
        final_answer = await self.ensemble(
            instruction="Evaluate these three solutions: which one aligns with all given constraints? If inconsistent, revise the weakest one using additional reasoning.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Final verification — check if answer satisfies original conditions
        verification = await self.revise(
            instruction="Verify that the computed value of CE satisfies both the collinearity condition (D,E,C,F) and the cyclic quadrilateral condition (A,D,H,G lie on a circle).",
            context_to_revise=final_answer
        )

        return verification