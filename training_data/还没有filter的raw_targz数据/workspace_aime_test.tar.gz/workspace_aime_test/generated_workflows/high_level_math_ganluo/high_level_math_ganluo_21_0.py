# Workflow ID: high_level_math_ganluo_21_0
# Benchmark: high_level_math_ganluo
# Data Indices: [34]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify key mathematical structure
        analysis = await self.generate(
            instruction="Analyze the problem to determine the type (e.g., number theory, algebra), identify constraints, and note what needs to be found."
        )

        # Step 2: Extract relevant mathematical concepts from analysis
        extracted_concepts = await self.generate(
            instruction="From the analysis, extract key mathematical ideas such as divisibility, primes, modular arithmetic, or polynomial congruences.",
            context=analysis
        )

        # Step 3: Parallel exploration of multiple solution strategies
        task1 = self.generate(
            instruction="Approach using number theory: consider properties of primes dividing n^4 + 1, and look for minimal prime p where p^2 divides some n^4 + 1."
        )
        task2 = self.generate(
            instruction="Approach using algebra: explore whether n^4 + 1 can be factored modulo p^2, and find conditions on p."
        )
        task3 = self.generate(
            instruction="Approach using computational search: suggest bounds or patterns to test small values of n and p for which p^2 divides n^4 + 1."
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble to select best-supported approach
        ensemble_result = await self.ensemble(
            instruction="Compare the three approaches and select the one most likely to yield an exact answer based on mathematical rigor and feasibility.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Refine selected solution through iterative revision
        refined_solution = await self.revise(
            instruction="Refine the selected solution by checking logical consistency, ensuring all constraints are satisfied, and simplifying complex expressions if possible.",
            context_to_revise=ensemble_result
        )

        # Step 6: Final verification via bidirectional reasoning
        verification = await self.generate(
            instruction="Generate a reverse check: given the proposed answer m, verify that m^4 + 1 is divisible by p^2, and confirm this is the smallest such m.",
            context=refined_solution
        )

        # Step 7: Return final answer
        return verification