# Workflow ID: high_level_math_ganluo_7_0
# Benchmark: high_level_math_ganluo
# Data Indices: [54]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Analyze the problem structure and identify key mathematical components
        analysis = await self.generate(
            instruction="Identify the type of problem (e.g., logarithmic system), its constraints, and potential solution strategies."
        )

        # Step 2: Extract and summarize the equations for clarity
        extracted_eqs = await self.generate(
            instruction="Extract the three given logarithmic equations as simplified expressions in terms of log₂(x), log₂(y), log₂(z).",
            context=analysis
        )
        summarized_eqs = await self.summarize(extracted_eqs)

        # Step 3: Solve the system using substitution or linear algebra approach
        solution_attempt = await self.generate(
            instruction="Solve the system of equations to find values for log₂(x), log₂(y), log₂(z). Then compute |log₂(x⁴y³z²)| as a fraction m/n.",
            context=summarized_eqs
        )

        # Step 4: Refine the solution through multiple passes to catch errors
        refined_solution = await self.revise(
            instruction="Check the solution for consistency with original equations and ensure all steps are mathematically valid.",
            context_to_revise=solution_attempt
        )

        # Step 5: Generate alternative approaches (e.g., coordinate transformation, symmetry) to verify robustness
        alt_approach_1 = self.generate(
            instruction="Try solving by converting logs to exponents and analyzing the resulting multiplicative relationships.",
            context=summarized_eqs
        )
        alt_approach_2 = self.generate(
            instruction="Consider using properties of logarithms to simplify the expression directly before solving the system.",
            context=summarized_eqs
        )

        # Step 6: Ensemble the best solution from both primary and alternative paths
        final_answer = await self.ensemble(
            instruction="Choose the most consistent and well-supported answer from the main solution and two alternative approaches.",
            contexts_to_ensemble=[refined_solution, alt_approach_1, alt_approach_2]
        )

        return final_answer