# Workflow ID: high_level_math_ganluo_47_0
# Benchmark: high_level_math_ganluo
# Data Indices: [52]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Analyze the problem to identify key constraints and structure
        analysis = await self.generate(
            instruction="Identify all mathematical constraints and properties from the problem statement."
        )

        # Step 2: Extract structured facts for systematic reasoning
        extracted_facts = await self.generate(
            instruction="Extract all numerical constraints and conditions into a structured format.",
            context=analysis
        )

        # Step 3: Generate multiple solution strategies (parallel exploration)
        strategy1 = self.generate(
            instruction="Propose an algebraic approach using variables for unknowns in the list.",
            context=extracted_facts
        )
        strategy2 = self.generate(
            instruction="Propose a combinatorial approach focusing on mode and median constraints.",
            context=extracted_facts
        )
        strategy3 = self.generate(
            instruction="Propose a case-based method considering possible list lengths and values.",
            context=extracted_facts
        )

        # Step 4: Run parallel exploration with diverse methods
        strategies = await asyncio.gather(strategy1, strategy2, strategy3)

        # Step 5: Ensemble to select the most robust solution path
        selected_strategy = await self.ensemble(
            instruction="Evaluate and synthesize the three proposed strategies to determine the best approach.",
            contexts_to_ensemble=strategies
        )

        # Step 6: Generate full solution based on selected strategy
        full_solution = await self.generate(
            instruction="Using the selected strategy, provide a complete step-by-step solution including all necessary calculations.",
            context=selected_strategy
        )

        # Step 7: Revise for accuracy and completeness
        revised_solution = await self.revise(
            instruction="Critically review the solution for logical consistency, missing steps, or calculation errors.",
            context_to_revise=full_solution
        )

        # Step 8: Final verification via bidirectional check if needed
        verification = await self.generate(
            instruction="Generate an inverse problem based on the final answer and verify that it leads back to the original constraints.",
            context=revised_solution
        )

        # Step 9: Final ensemble to ensure confidence in the result
        final_answer = await self.ensemble(
            instruction="Compare the original solution and its verification to produce the most reliable integer answer.",
            contexts_to_ensemble=[revised_solution, verification]
        )

        return final_answer