# Workflow ID: high_level_math_ganluo_26_0
# Benchmark: high_level_math_ganluo
# Data Indices: [12]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis
        analysis = await self.generate(
            instruction="Analyze the problem to identify the mathematical domain (e.g., geometry, combinatorics, probability) and key constraints."
        )

        # Step 2: Parallel Exploration of Multiple Solution Paths
        task1 = self.generate(
            instruction="Generate a solution using geometric reasoning: consider how line segments intersect and divide regions in a disk."
        )
        task2 = self.generate(
            instruction="Generate a solution using combinatorial methods: count intersections and apply Euler's formula for planar graphs."
        )
        task3 = self.generate(
            instruction="Generate a solution using expected value techniques: compute expected number of new regions added by each segment."
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble to Select Best Solution
        final_solution = await self.ensemble(
            instruction="Compare the three candidate solutions and select the most mathematically sound and consistent one.",
            contexts_to_ensemble=solutions
        )

        # Step 4: Refinement via Iterative Revision
        revised_solution = await self.revise(
            instruction="Critically review the selected solution for logical consistency, mathematical rigor, and correctness in handling edge cases like parallel lines or overlapping segments.",
            context_to_revise=final_solution
        )

        # Step 5: Final Verification via Bidirectional Check
        verification_check = await self.generate(
            instruction="Create an inverse problem: if the answer is X, what would be the expected number of regions under simplified conditions? Verify that this matches the original setup.",
            context=revised_solution
        )

        # Step 6: Return Final Answer
        return await self.summarize(
            context_to_summarize=f"{revised_solution}\n\nVerification: {verification_check}"
        )