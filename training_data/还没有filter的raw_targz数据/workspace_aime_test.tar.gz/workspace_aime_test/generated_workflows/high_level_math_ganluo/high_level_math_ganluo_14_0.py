# Workflow ID: high_level_math_ganluo_14_0
# Benchmark: high_level_math_ganluo
# Data Indices: [26]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis
        analysis = await self.generate(
            instruction="Analyze the problem to identify key mathematical structures: polygon properties, area constraints, angle constraints, and perimeter condition."
        )

        # Step 2: Extract Core Mathematical Facts
        extracted_facts = await self.generate(
            instruction="From the analysis, extract all measurable quantities and relationships: areas, angles, side lengths, and their interdependencies.",
            context=analysis
        )

        # Step 3: Parallel Exploration of Multiple Approaches
        task1 = self.generate(
            instruction="Assume coordinate geometry: place A₁ at origin, use angle and area constraints to derive coordinates of adjacent vertices.",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Use vector algebra: express vectors A₁Aᵢ and A₁Aᵢ₊₁ in terms of magnitudes and angle, then apply area formula for triangle.",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Apply trigonometric identities: since cos(θ) = 12/13, find sin(θ), then compute area using (1/2)*ab*sin(θ).",
            context=extracted_facts
        )

        approaches = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Best Approach
        best_approach = await self.ensemble(
            instruction="Evaluate the three candidate solutions for clarity, consistency with given constraints, and feasibility of computing the required sum A₁A₂ + A₁A₁₁.",
            contexts_to_ensemble=approaches
        )

        # Step 5: Refinement Loop — Revise until consistent with perimeter constraint
        refined_solution = best_approach
        for _ in range(2):  # Limit iterations to avoid infinite loops
            revised = await self.revise(
                instruction="Check if the derived expression for A₁A₂ + A₁A₁₁ satisfies all conditions including the total perimeter being 20. If not, adjust reasoning accordingly.",
                context_to_revise=refined_solution
            )
            if revised == refined_solution:
                break
            refined_solution = revised

        # Step 6: Final Verification via Bidirectional Check
        verification = await self.generate(
            instruction="Construct an inverse problem: assume the answer is correct, then verify it leads back to the original area and perimeter constraints.",
            context=refined_solution
        )

        # Step 7: Final Answer Extraction
        final_answer = await self.summarize(
            context_to_summarize=f"{refined_solution}\n\n{verification}"
        )

        return final_answer