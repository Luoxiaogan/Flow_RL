# Workflow ID: high_level_math_ganluo_16_0
# Benchmark: high_level_math_ganluo
# Data Indices: [27]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand structure and key properties
        analysis = await self.generate(
            instruction="Analyze the recurrence relation: identify patterns, potential simplifications, or invariants. Look for periodicity, fixed points, or transformations that simplify the expression."
        )

        # Step 2: Parallel Exploration — Try multiple solution paths
        task1 = self.generate(
            instruction="Assume the sequence stabilizes to a fixed point. Solve for x such that x = (1/3)(x + 1/x - 1).",
            context=analysis
        )
        task2 = self.generate(
            instruction="Try computing first few terms manually to detect pattern or cycle.",
            context=analysis
        )
        task3 = self.generate(
            instruction="Explore substitution methods like y_k = f(x_k) to linearize or simplify the recurrence.",
            context=analysis
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble — Synthesize best approach from competing ideas
        ensemble_summary = await self.ensemble(
            instruction="Compare the three candidate approaches. Select the one with strongest mathematical foundation and clear path to compute x_2025 efficiently.",
            contexts_to_ensemble=solutions
        )

        # Step 4: Generate Final Solution — Build step-by-step derivation
        final_solution = await self.generate(
            instruction="Based on the selected strategy, derive x_2025 explicitly as m/n, then compute (m + n) mod 1000.",
            context=ensemble_summary
        )

        # Step 5: Refine via Bidirectional Verification — Check internal consistency
        verification = await self.revise(
            instruction="Verify that the derived value satisfies the original recurrence relation for at least one term (e.g., k=1 or k=2). Also check if the answer format matches expected integer between 0 and 999.",
            context_to_revise=final_solution
        )

        # Step 6: Final Ensemble — Ensure robustness by combining revised result
        final_answer = await self.ensemble(
            instruction="Return the final integer answer (between 0 and 999) based on the verified solution. If there's ambiguity, choose the most mathematically consistent one.",
            contexts_to_ensemble=[verification]
        )

        return final_answer