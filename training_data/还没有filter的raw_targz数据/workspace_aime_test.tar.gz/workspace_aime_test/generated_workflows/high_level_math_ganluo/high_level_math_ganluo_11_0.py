# Workflow ID: high_level_math_ganluo_11_0
# Benchmark: high_level_math_ganluo
# Data Indices: [20]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand structure and constraints
        analysis = await self.generate(
            instruction="Analyze the problem to identify key geometric elements, constraints, and relationships between points A, B, C, D, and rectangle EFGH."
        )

        # Step 2: Extract structured data from analysis for precise reasoning
        extracted = await self.generate(
            instruction="From the analysis, extract all relevant numerical values, perpendicularities, tangencies, and area conditions as bullet points.",
            context=analysis
        )

        # Step 3: Parallel exploration of multiple solution paths
        task1 = self.generate(
            instruction="Assume coordinate geometry: Place point A at origin, derive coordinates of B, C, D, and then determine coordinates of EFGH using symmetry and perpendicularity constraints.",
            context=extracted
        )
        task2 = self.generate(
            instruction="Use synthetic geometry: Leverage circle tangency, right angles, and equal triangle areas to deduce properties of rectangle EFGH without coordinates.",
            context=extracted
        )
        task3 = self.generate(
            instruction="Apply vector methods or complex numbers to model positions and compute area directly from given conditions.",
            context=extracted
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble to select best-supported solution based on consistency and clarity
        final_answer = await self.ensemble(
            instruction="Evaluate the three candidate solutions. Choose the one that best satisfies all constraints, uses correct mathematical reasoning, and produces an integer answer between 0 and 999.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional refinement if needed (e.g., if ensemble output is ambiguous)
        refined = await self.revise(
            instruction="If the ensemble result is not a clear integer answer in range [0,999], revise it by re-checking constraints and recalculating the area of rectangle EFGH.",
            context_to_revise=final_answer
        )

        return refined