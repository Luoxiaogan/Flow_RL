# Workflow ID: high_level_math_ganluo_32_0
# Benchmark: high_level_math_ganluo
# Data Indices: [8]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify problem type and key elements
        analysis = await self.generate(
            instruction="Analyze the problem structure: identify mathematical domain (e.g., geometry, algebra), key constraints, and what must be computed."
        )

        # Step 2: Extract structured information from analysis for clarity
        extracted = await self.generate(
            instruction="From the analysis, extract all relevant variables, equations, transformations, and conditions as bullet points.",
            context=analysis
        )

        # Step 3: Parallel exploration of multiple solution paths — geometric vs. algebraic
        task1 = self.generate(
            instruction="Generate a solution using coordinate geometry: apply rotation matrix to the parabola equation and find intersection points."
        )
        task2 = self.generate(
            instruction="Generate an alternative solution using synthetic geometry: consider symmetry, invariant properties under rotation, and possible fixed points."
        )
        solutions = await asyncio.gather(task1, task2)

        # Step 4: Ensemble to select best-supported approach based on consistency and clarity
        ensemble_result = await self.ensemble(
            instruction="Compare both solutions. Identify which one correctly identifies the fourth-quadrant intersection point and yields the expression in the required form.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Revise to refine final answer format and verify correctness
        final_answer = await self.revise(
            instruction="Refine the selected solution into a clear step-by-step derivation. Ensure it explicitly derives the y-coordinate in the form (a - sqrt(b)) / c, then compute a + b + c.",
            context_to_revise=ensemble_result
        )

        # Step 6: Final verification via bidirectional check — reverse-engineer from answer
        verification = await self.generate(
            instruction="Based on the derived value of a + b + c, generate the inverse problem: what would the original problem have been if this were the answer? Check that it matches the given setup.",
            context=final_answer
        )

        # Step 7: Ensemble final confidence — compare original solution with verification
        final_output = await self.ensemble(
            instruction="Choose the most consistent and mathematically sound answer between the primary derivation and the verification check.",
            contexts_to_ensemble=[final_answer, verification]
        )

        return final_output