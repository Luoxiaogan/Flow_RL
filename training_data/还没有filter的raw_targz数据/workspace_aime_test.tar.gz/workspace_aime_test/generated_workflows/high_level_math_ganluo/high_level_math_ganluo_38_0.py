# Workflow ID: high_level_math_ganluo_38_0
# Benchmark: high_level_math_ganluo
# Data Indices: [6]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Analyze problem structure and identify key components
        analysis = await self.generate(
            instruction="Identify the mathematical domain (e.g., combinatorics, probability), key constraints, and what must be computed. Focus on whether this is about counting arrangements, symmetry, or conditional probability."
        )

        # Step 2: Generate multiple solution paths in parallel — diverge
        tasks = [
            self.generate(
                instruction="Approach using casework: consider all possible pairings that include G and how they affect the final word's position.",
                context=analysis
            ),
            self.generate(
                instruction="Approach using symmetry: determine if each letter has equal chance to appear in the last word due to random pairing.",
                context=analysis
            ),
            self.generate(
                instruction="Approach using linearity of expectation: compute the probability that G appears in the last word by analyzing its expected position across all valid pairings.",
                context=analysis
            )
        ]
        solutions = await asyncio.gather(*tasks)

        # Step 3: Summarize each path to extract core reasoning
        summaries = []
        for sol in solutions:
            summary = await self.summarize(sol)
            summaries.append(summary)

        # Step 4: Ensemble the three approaches to select best-supported answer
        final_answer = await self.ensemble(
            instruction="Compare the three candidate solutions. Identify which one correctly models the probability space, respects the randomness of pairing, and yields an integer between 0 and 999 as required. Return only the final integer answer.",
            contexts_to_ensemble=summaries
        )

        return final_answer