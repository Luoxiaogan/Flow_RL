# Workflow ID: high_level_math_ganluo_41_0
# Benchmark: high_level_math_ganluo
# Data Indices: [3]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis
        analysis = await self.generate(
            instruction="Analyze the equation 12x² - xy - 6y² = 0. Identify what type of problem this is (e.g., Diophantine, factorable, symmetric) and suggest possible solution strategies."
        )

        # Step 2: Parallel Exploration — Try multiple solution paths
        task1 = self.generate(
            instruction="Treat this as a quadratic in x and solve for x in terms of y using the quadratic formula. Then find integer solutions by analyzing discriminant conditions.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Factor the equation 12x² - xy - 6y² = 0 algebraically. Look for linear factors with integer coefficients. If found, express constraints on x and y directly.",
            context=analysis
        )
        task3 = self.generate(
            instruction="Use modular arithmetic to reduce the search space. For example, consider modulo small primes like 2, 3, or 5 to narrow down possible values of x and y that satisfy the equation.",
            context=analysis
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble to select best solution path
        ensemble_result = await self.ensemble(
            instruction="Compare the three proposed approaches. Choose the one that provides the clearest, most computationally tractable method to count all valid integer pairs (x,y) within the given bounds [-100, 100].",
            contexts_to_ensemble=solutions
        )

        # Step 4: Refine the chosen solution through iterative revision
        refined_solution = await self.revise(
            instruction="Review the selected approach carefully. Check for edge cases such as when y=0, verify the logic step-by-step, and ensure no valid pair is missed or double-counted.",
            context_to_revise=ensemble_result
        )

        # Step 5: Final verification via bidirectional check
        verification = await self.generate(
            instruction="Generate an inverse problem: Given the final count of valid pairs, reconstruct a simple case (like small bounds) and verify that solving it gives the same result. This ensures internal consistency.",
            context=refined_solution
        )

        # Step 6: Return the final answer as an integer between 0 and 999
        final_answer = await self.summarize(
            context_to_summarize=f"{refined_solution}\n\n{verification}"
        )

        return final_answer