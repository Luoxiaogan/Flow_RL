# Workflow ID: high_level_math_ganluo_57_0
# Benchmark: high_level_math_ganluo
# Data Indices: [30]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Analyze problem structure and extract key variables
        analysis = await self.generate(
            instruction="Identify all given quantities, unknowns, and relationships in the problem. Focus on time, speed, distance, and coffee shop time."
        )

        # Step 2: Generate multiple solution paths — algebraic and time-based
        task1 = self.generate(
            instruction="Set up equations based on the relationship between speed, time, and distance for both scenarios. Solve for s and t.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Model this as a system of linear equations using the total time (walk + coffee) for each speed scenario. Solve for s and t explicitly.",
            context=analysis
        )
        
        solutions = await asyncio.gather(task1, task2)

        # Step 3: Ensemble to resolve discrepancies or select best approach
        ensemble_result = await self.ensemble(
            instruction="Compare the two generated solutions. If they agree, choose that. If not, identify which one better satisfies the original constraints.",
            contexts_to_ensemble=solutions
        )

        # Step 4: Refine final answer through revision using constraint checking
        refined_answer = await self.revise(
            instruction="Verify that the computed values for s and t satisfy both original conditions. Then calculate the total time when walking at s+0.5 km/h, including t minutes in the coffee shop.",
            context_to_revise=ensemble_result
        )

        # Step 5: Final summary and validation
        final_summary = await self.summarize(
            context_to_summarize=refined_answer
        )

        return final_summary