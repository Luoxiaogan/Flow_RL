# Workflow ID: drop_43_0
# Benchmark: drop
# Data Indices: [40, 91]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question type and key entities
        analysis = await self.generate(
            instruction="Analyze the passage and question. Identify if it requires counting, arithmetic, comparison, or span extraction. Also note all numerical values and their associated entities (e.g., field goals, players, scores)."
        )

        # Step 2: Extract structured facts in parallel — one for numbers, one for entities
        extract_num = self.generate(
            instruction="Extract all numerical values from the passage with context (e.g., '39-yard field goal', '52-yard field goal'). Include units like 'yards' or 'points'."
        )
        extract_entities = self.generate(
            instruction="Identify all named entities mentioned in the passage that might be relevant to the question (e.g., players, teams, events)."
        )
        num_contexts, entity_contexts = await asyncio.gather(extract_num, extract_entities)

        # Step 3: Summarize extracted data to reduce noise
        summarized_nums = await self.summarize(num_contexts)
        summarized_entities = await self.summarize(entity_contexts)

        # Step 4: Generate candidate solutions based on different interpretations
        solution_arithmetic = await self.generate(
            instruction="Based on the summarized numerical data, solve the question using arithmetic reasoning (e.g., subtraction, addition, comparison).",
            context=summarized_nums + "\n\n" + analysis
        )
        solution_counting = await self.generate(
            instruction="Based on the summarized numerical data, count instances satisfying criteria (e.g., field goals between 25 and 50 yards).",
            context=summarized_nums + "\n\n" + analysis
        )
        solution_span = await self.generate(
            instruction="Based on the summarized entities, identify the correct answer by selecting the appropriate entity or phrase related to the question.",
            context=summarized_entities + "\n\n" + analysis
        )

        # Step 5: Ensemble to resolve ambiguity or conflicting interpretations
        final_answer = await self.ensemble(
            instruction="Compare the three candidate solutions. Choose the most accurate one based on clarity, consistency with the passage, and relevance to the question.",
            contexts_to_ensemble=[solution_arithmetic, solution_counting, solution_span]
        )

        # Step 6: Final refinement via revision if needed
        refined_answer = await self.revise(
            instruction="Critically review the final answer. Check for logical consistency, proper entity-number association, and correctness of mathematical operations.",
            context_to_revise=final_answer
        )

        return refined_answer