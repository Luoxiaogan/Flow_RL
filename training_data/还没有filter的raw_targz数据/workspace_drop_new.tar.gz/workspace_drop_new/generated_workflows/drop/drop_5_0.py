# Workflow ID: drop_5_0
# Benchmark: drop
# Data Indices: [258, 27]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question intent and key entities
        analysis = await self.generate(
            instruction="Analyze the passage and question. Identify what type of reasoning is required (e.g., arithmetic, counting, comparison, span extraction). Also identify all relevant named entities and numerical values."
        )

        # Step 2: Extract structured facts using parallel exploration — multiple perspectives
        task1 = self.generate(
            instruction="Extract all named entities mentioned in the passage, especially those that could be related to the question (e.g., players, teams, scores, times)."
        )
        task2 = self.generate(
            instruction="List all numerical values in the passage with their associated context (e.g., field goals by distance, player stats)."
        )
        task3 = self.generate(
            instruction="Identify any implicit information or relationships between entities that may not be explicitly stated but are necessary for answering."
        )
        extracted_facts = await asyncio.gather(task1, task2, task3)

        # Step 3: Summarize the extracted facts to reduce noise and focus on relevance
        summary = await self.summarize(context_to_summarize="\n\n".join(extracted_facts))

        # Step 4: Generate candidate solutions based on different interpretations
        candidate1 = await self.generate(
            instruction="Based on the summarized facts, generate a solution assuming the question requires simple number extraction.",
            context=summary
        )
        candidate2 = await self.generate(
            instruction="Based on the summarized facts, generate a solution assuming the question involves multi-hop inference (e.g., comparing two values across time or events).",
            context=summary
        )
        candidate3 = await self.generate(
            instruction="Based on the summarized facts, generate a solution assuming the question requires identifying an entity from a list of candidates (span extraction).",
            context=summary
        )

        # Step 5: Ensemble the three candidate solutions to resolve ambiguity
        final_answer = await self.ensemble(
            instruction="Evaluate the three candidate answers. Choose the one most consistent with the passage and the question's intent. If there is disagreement, explain why one answer is preferred.",
            contexts_to_ensemble=[candidate1, candidate2, candidate3]
        )

        # Step 6: Optional refinement if the ensemble result seems uncertain
        if "uncertain" in final_answer.lower() or "not clear" in final_answer.lower():
            refined_answer = await self.revise(
                instruction="Revise the answer based on the original passage and the current answer. Focus on resolving any remaining ambiguity or missing connections.",
                context_to_revise=final_answer
            )
            return refined_answer

        return final_answer