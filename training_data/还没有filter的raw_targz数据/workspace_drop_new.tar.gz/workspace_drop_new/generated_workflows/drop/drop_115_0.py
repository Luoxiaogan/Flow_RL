# Workflow ID: drop_115_0
# Benchmark: drop
# Data Indices: [286, 21]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question intent and extract key entities
        analysis = await self.generate(
            instruction="Analyze the passage and question. Identify the type of reasoning required (e.g., arithmetic, counting, comparison, span extraction). Also identify all relevant numerical values, dates, or entities mentioned in the passage that may be needed to answer the question."
        )

        # Step 2: Extract structured data from the passage — crucial for multi-hop problems
        extraction = await self.generate(
            instruction="Based on the analysis, extract all relevant numerical facts, dates, and named entities from the passage. Format as a clear list with entity names and associated values.",
            context=analysis
        )

        # Step 3: Generate multiple solution paths based on different interpretations
        # Parallel exploration for ambiguous cases like "how many more" vs "total"
        task1 = self.generate(
            instruction="Generate a solution assuming this is a subtraction problem (e.g., 'difference' or 'more than'). Use only the extracted facts.",
            context=extraction
        )
        task2 = self.generate(
            instruction="Generate a solution assuming this is an addition problem (e.g., 'total' or 'combined'). Use only the extracted facts.",
            context=extraction
        )
        task3 = self.generate(
            instruction="Generate a solution assuming this requires identifying specific entities (e.g., 'which team won' or 'who had more'). Use only the extracted facts.",
            context=extraction
        )

        # Execute all in parallel
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble to select best candidate based on alignment with question intent
        final_answer = await self.ensemble(
            instruction="Evaluate the three proposed solutions. Choose the one that best matches the question's intent as identified in the initial analysis. If unsure, prioritize the most numerically precise option.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional refinement if the answer seems uncertain — critical for complex problems
        if "uncertain" in final_answer.lower() or "?" in final_answer:
            refined_answer = await self.revise(
                instruction="Revise the answer by double-checking the original passage for any missed details or misinterpreted numbers. Ensure each number is correctly tied to its entity.",
                context_to_revise=final_answer
            )
            return refined_answer

        return final_answer