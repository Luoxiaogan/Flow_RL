# Workflow ID: drop_75_0
# Benchmark: drop
# Data Indices: [279, 155]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis – Understand question type and key entities
        analysis = await self.generate(
            instruction="Analyze the passage and question to identify the core reasoning task (e.g., arithmetic, counting, comparison), key entities, and relevant numerical values."
        )

        # Step 2: Extract Relevant Facts – Isolate all numerically or logically relevant data
        extraction = await self.generate(
            instruction="Extract all numbers, dates, and named entities mentioned in the passage that could be relevant to answering the question.",
            context=analysis
        )

        # Step 3: Parallel Exploration – Generate multiple interpretations or solution paths
        task1 = self.generate(
            instruction="Generate a step-by-step mathematical approach based on the extracted facts to solve the question directly.",
            context=extraction
        )
        task2 = self.generate(
            instruction="Generate an alternative logical approach, focusing on chronological order or event sequence if applicable.",
            context=extraction
        )
        task3 = self.generate(
            instruction="Generate a hypothesis about possible ambiguities or references in the question (e.g., pronouns, similar entities) and how they affect interpretation.",
            context=extraction
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer – Synthesize competing approaches
        final_answer = await self.ensemble(
            instruction="Based on the three candidate solutions, select the most consistent and accurate answer. If there's disagreement, choose the one best supported by evidence from the passage.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Revise for Clarity & Precision – Refine output to ensure correctness
        refined_answer = await self.revise(
            instruction="Improve clarity and precision of the final answer. Ensure it directly addresses the original question without ambiguity.",
            context_to_revise=final_answer
        )

        return refined_answer