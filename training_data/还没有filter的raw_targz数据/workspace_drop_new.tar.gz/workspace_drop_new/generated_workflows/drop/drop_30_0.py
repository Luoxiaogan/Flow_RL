# Workflow ID: drop_30_0
# Benchmark: drop
# Data Indices: [292, 120]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis - Understand question type and key entities
        analysis = await self.generate(
            instruction="Analyze the question and passage to determine what type of reasoning is required (e.g., arithmetic, counting, span extraction, comparison). Also identify all relevant named entities, numbers, and their relationships."
        )

        # Step 2: Extract structured facts in parallel — crucial for multi-hop or ambiguous problems
        extract_tasks = [
            self.generate("Extract all numerical values mentioned in the passage with their associated context.", context=analysis),
            self.generate("Identify all named entities (people, teams, places, etc.) mentioned in the passage.", context=analysis),
            self.generate("List all explicit comparisons or relationships between entities (e.g., 'more than', 'less than', 'higher than').", context=analysis)
        ]
        extracted_facts, entity_list, comparisons = await asyncio.gather(*extract_tasks)

        # Step 3: Generate multiple candidate solutions based on different interpretations
        candidate_solutions = []
        if "how many" in analysis.lower() or "percent" in analysis.lower():
            # Arithmetic/Counting path
            arith_solution = await self.generate(
                instruction="Based on the extracted facts, compute the answer using appropriate arithmetic operations (sum, difference, ratio). Be precise about which entities the numbers refer to.",
                context=f"Extracted facts:\n{extracted_facts}\n\nEntities:\n{entity_list}"
            )
            candidate_solutions.append(arith_solution)

        if "who" in analysis.lower() or "which" in analysis.lower():
            # Span extraction / selection path
            span_solution = await self.generate(
                instruction="Identify the exact text span that answers the question based on the extracted entities and relationships.",
                context=f"Extracted facts:\n{extracted_facts}\n\nEntities:\n{entity_list}\n\nComparisons:\n{comparisons}"
            )
            candidate_solutions.append(span_solution)

        # Step 4: Ensemble to resolve ambiguity or improve accuracy
        final_answer = await self.ensemble(
            instruction="Evaluate the candidate solutions and select the most accurate one. If there is disagreement, choose the one best supported by evidence from the passage.",
            contexts_to_ensemble=candidate_solutions
        )

        # Step 5: Optional refinement if confidence is low
        if "uncertain" in final_answer.lower() or "not clear" in final_answer.lower():
            final_answer = await self.revise(
                instruction="Refine the answer based on the original passage and the reasoning used. Ensure it directly addresses the question without ambiguity.",
                context_to_revise=final_answer
            )

        return final_answer