# Workflow ID: drop_121_0
# Benchmark: drop
# Data Indices: [41, 1]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to detect question type and key entities
        analysis = await self.generate(
            instruction="Analyze the question and passage to identify the required reasoning type (e.g., counting, arithmetic, comparison) and all relevant entities or numbers mentioned."
        )

        # Step 2: Extract structured facts from passage using parallel exploration
        extract_tasks = [
            self.generate(instruction="Extract all named entities and associated numerical values from the passage.", context=analysis),
            self.generate(instruction="List all explicit numerical values in the passage with their context (e.g., '5 field goals by Team A').", context=analysis),
            self.generate(instruction="Identify all instances of repeated or similar entities (e.g., multiple players, events, or items) that may require careful association.", context=analysis)
        ]
        extracted_facts = await asyncio.gather(*extract_tasks)

        # Step 3: Generate candidate solutions based on different extraction perspectives
        solution_candidates = []
        for i, fact_set in enumerate(extracted_facts):
            candidate = await self.generate(
                instruction=f"Based on this set of extracted facts: {fact_set}, generate a step-by-step solution to the original question.",
                context=analysis
            )
            solution_candidates.append(candidate)

        # Step 4: Ensemble the candidates to resolve ambiguity and improve robustness
        final_solution = await self.ensemble(
            instruction="Compare the three candidate solutions. Identify common elements, resolve discrepancies, and select the most accurate answer based on consistency and logical coherence.",
            contexts_to_ensemble=solution_candidates
        )

        # Step 5: Optional refinement if the ensemble result seems uncertain
        if "uncertain" in final_solution.lower() or "multiple interpretations" in final_solution.lower():
            refined_solution = await self.revise(
                instruction="Critique the ensemble result for potential errors or missing steps. Improve clarity and precision based on the original passage and question.",
                context_to_revise=final_solution
            )
            return refined_solution

        return final_solution