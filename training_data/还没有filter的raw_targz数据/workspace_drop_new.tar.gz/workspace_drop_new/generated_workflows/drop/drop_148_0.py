# Workflow ID: drop_148_0
# Benchmark: drop
# Data Indices: [192, 163]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand question intent and extract key entities
        analysis = await self.generate(
            instruction="Analyze the question and passage to identify what type of reasoning is required (e.g., arithmetic, counting, comparison, entity extraction). Also list all relevant numerical values and their associated entities."
        )

        # Step 2: Extract Structured Facts — Convert dense text into structured data points
        facts = await self.generate(
            instruction="Extract all relevant numerical values and their corresponding entities from the passage. Format as a bullet list with clear associations.",
            context=analysis
        )

        # Step 3: Parallel Exploration — Generate multiple solution paths based on different interpretations
        task1 = self.generate(
            instruction="Generate a step-by-step solution assuming this is an arithmetic question requiring summing or subtracting specific values.",
            context=facts
        )
        task2 = self.generate(
            instruction="Generate a step-by-step solution assuming this is a selection or percentage-based question involving proportions.",
            context=facts
        )
        task3 = self.generate(
            instruction="Generate a step-by-step solution focusing on coreference resolution and entity tracking to ensure correct value association.",
            context=facts
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer — Synthesize best-supported answer across approaches
        final_answer = await self.ensemble(
            instruction="Choose the most consistent and logically supported answer among the three proposed solutions. If there's disagreement, explain why one is stronger than others.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional Refinement — Revise if uncertainty remains
        revised_answer = await self.revise(
            instruction="If the ensemble result contains ambiguity or lacks clarity in its justification, improve the explanation while preserving accuracy.",
            context_to_revise=final_answer
        )

        return revised_answer