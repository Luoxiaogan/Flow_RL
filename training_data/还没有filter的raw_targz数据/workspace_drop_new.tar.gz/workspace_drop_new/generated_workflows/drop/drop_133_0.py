# Workflow ID: drop_133_0
# Benchmark: drop
# Data Indices: [68, 129]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Analyze question type and extract key intent
        analysis = await self.generate(
            instruction="Identify the type of reasoning required (e.g., counting, arithmetic, comparison) and the relevant entities or values mentioned in the question."
        )

        # Step 2: Extract all relevant numerical facts from passage
        extraction = await self.generate(
            instruction="Extract all numerical values related to field goals, touchdowns, yardages, and counts from the passage. Include context for each value (e.g., 'field goal by Robbie Gould, 43 yards').",
            context=analysis
        )

        # Step 3: Summarize extracted data to reduce noise and focus on relevant info
        summarized_data = await self.summarize(extraction)

        # Step 4: Generate multiple candidate solutions using different strategies
        task1 = self.generate(
            instruction="Based on the summarized data, count how many field goals were longer than 45 yards.",
            context=summarized_data
        )
        task2 = self.generate(
            instruction="List all field goals and their yardages, then filter those exceeding 45 yards and sum them.",
            context=summarized_data
        )
        task3 = self.generate(
            instruction="Find every instance of a field goal over 45 yards, calculate total yards, and return only the final number.",
            context=summarized_data
        )

        # Execute parallel exploration
        candidates = await asyncio.gather(task1, task2, task3)

        # Step 5: Ensemble to resolve discrepancies and select best answer
        final_answer = await self.ensemble(
            instruction="Select the most accurate answer based on consistency across all three approaches. If there's disagreement, choose the one that aligns with explicit evidence from the passage.",
            contexts_to_ensemble=candidates
        )

        # Optional: Revise if output seems inconsistent or vague
        revised_answer = await self.revise(
            instruction="Ensure the final answer is precise, numeric, and directly addresses the original question without ambiguity.",
            context_to_revise=final_answer
        )

        return revised_answer