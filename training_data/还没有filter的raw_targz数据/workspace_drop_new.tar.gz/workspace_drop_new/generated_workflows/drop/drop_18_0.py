# Workflow ID: drop_18_0
# Benchmark: drop
# Data Indices: [59, 154]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand question intent and passage structure
        analysis = await self.generate(
            instruction="Analyze the question and passage to identify the type of reasoning required (e.g., arithmetic, counting, comparison, span extraction). Also note key entities, numbers, and relationships."
        )

        # Step 2: Extract Relevant Information — Identify all facts needed for solving
        extraction = await self.generate(
            instruction="Extract all relevant numerical values, named entities, and contextual clues from the passage that could be used to answer the question. List them clearly with their associated context.",
            context=analysis
        )

        # Step 3: Generate Multiple Reasoning Paths — Use parallel exploration for ambiguity
        task1 = self.generate(
            instruction="Generate a solution using direct number association and arithmetic reasoning based on extracted data.",
            context=extraction
        )
        task2 = self.generate(
            instruction="Generate a solution by focusing on entity tracking and resolving pronouns or ambiguous references in the passage.",
            context=extraction
        )
        task3 = self.generate(
            instruction="Generate a solution by summarizing the passage first, then reasoning step-by-step from the summary.",
            context=extraction
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble — Select best solution among competing approaches
        final_answer = await self.ensemble(
            instruction="Choose the most accurate and consistent answer based on the three candidate solutions. If they conflict, prioritize clarity, logical consistency, and alignment with the original question.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Revise — Improve final answer through critical feedback
        refined_answer = await self.revise(
            instruction="Critically review the final answer for correctness, completeness, and clarity. Fix any errors or ambiguities in reasoning or phrasing.",
            context_to_revise=final_answer
        )

        return refined_answer