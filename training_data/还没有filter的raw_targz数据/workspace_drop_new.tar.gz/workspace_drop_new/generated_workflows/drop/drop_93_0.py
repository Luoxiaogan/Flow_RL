# Workflow ID: drop_93_0
# Benchmark: drop
# Data Indices: [272, 141]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question intent and key entities
        analysis = await self.generate(
            instruction="Analyze the question and passage to identify what type of reasoning is required (e.g., arithmetic, counting, comparison, span extraction) and list all relevant numerical or named entities."
        )

        # Step 2: Extract structured facts from the passage using parallel exploration
        extract_tasks = [
            self.generate("Extract all numbers mentioned in the passage with their associated context."),
            self.generate("List all named entities (people, places, tribes, etc.) mentioned in the passage."),
            self.generate("Identify any explicit comparisons or relationships between entities.")
        ]
        extracted_facts_raw = await asyncio.gather(*extract_tasks)

        # Step 3: Summarize extracted facts for clarity and reduce noise
        summarized_facts = await self.summarize("\n\n".join(extracted_facts_raw))

        # Step 4: Generate multiple candidate solutions based on different interpretations
        candidates = []
        if "how many" in analysis.lower() or "percent" in analysis.lower():
            candidates.append(await self.generate(
                instruction="Based on the summarized facts, calculate the total or difference as required by the question.",
                context=summarized_facts
            ))
        if "which" in analysis.lower() or "who had more" in analysis.lower():
            candidates.append(await self.generate(
                instruction="Compare the values or attributes of entities mentioned to determine which is greater or most relevant.",
                context=summarized_facts
            ))
        if "what was the name of" in analysis.lower() or "who did" in analysis.lower():
            candidates.append(await self.generate(
                instruction="Identify the exact text span that answers the question based on the passage and extracted facts.",
                context=summarized_facts
            ))

        # Step 5: Ensemble the best solution from competing interpretations
        final_answer = await self.ensemble(
            instruction="Select the most accurate and coherent answer among the candidates based on relevance to the original question.",
            contexts_to_ensemble=candidates
        )

        # Step 6: Optional refinement loop — if the answer seems ambiguous or incomplete
        if "not clear" in final_answer.lower() or len(final_answer.split()) < 2:
            refined_answer = await self.revise(
                instruction="Revise the answer to ensure it directly addresses the question without ambiguity, and includes only necessary information.",
                context_to_revise=final_answer
            )
            return refined_answer

        return final_answer