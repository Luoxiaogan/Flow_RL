# Workflow ID: drop_36_0
# Benchmark: drop
# Data Indices: [257, 102]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question intent and passage structure
        analysis = await self.generate(
            instruction="Analyze the question and passage to identify key entities, numerical references, and required reasoning type (e.g., counting, comparison, span extraction)."
        )

        # Step 2: Extract relevant facts in parallel — focus on different aspects
        task1 = self.generate(
            instruction="Extract all named entities mentioned in the passage along with their associated values or descriptors."
        )
        task2 = self.generate(
            instruction="Identify all explicit numerical values and their associated entities or contexts."
        )
        task3 = self.generate(
            instruction="List all questions or sub-questions implied by the main query that need to be resolved to answer it."
        )
        extracted_facts, numerical_values, sub_questions = await asyncio.gather(task1, task2, task3)

        # Step 3: Summarize key information to reduce context length and highlight critical elements
        summary = await self.summarize(
            context_to_summarize=f"Analysis: {analysis}\nExtracted Facts: {extracted_facts}\nNumerical Values: {numerical_values}\nSub-Questions: {sub_questions}"
        )

        # Step 4: Generate multiple candidate solutions based on different interpretations
        solution1 = await self.generate(
            instruction="Based on the summary, generate a solution assuming the question requires direct entity-number association.",
            context=summary
        )
        solution2 = await self.generate(
            instruction="Generate an alternative solution assuming the question involves multi-hop inference between entities and numbers.",
            context=summary
        )
        solution3 = await self.generate(
            instruction="Propose a solution focusing on resolving ambiguous references using contextual clues from the passage.",
            context=summary
        )

        # Step 5: Ensemble the three candidate solutions to reach a robust final answer
        final_answer = await self.ensemble(
            instruction="Evaluate the three candidate solutions and select the one most supported by evidence in the passage. If conflicting, choose the one that best resolves ambiguity.",
            contexts_to_ensemble=[solution1, solution2, solution3]
        )

        # Optional: Revise once if confidence is low (detect via language cues)
        if "uncertain" in final_answer.lower() or "not clear" in final_answer.lower():
            final_answer = await self.revise(
                instruction="Revise the answer to improve clarity and ensure it directly addresses the original question using only the passage content.",
                context_to_revise=final_answer
            )

        return final_answer