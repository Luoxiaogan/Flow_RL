# Workflow ID: drop_37_0
# Benchmark: drop
# Data Indices: [287, 152]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Analyze the question to determine intent and required reasoning type
        analysis = await self.generate(
            instruction="Analyze the question to determine its type (e.g., span extraction, arithmetic, comparison). Also identify key entities and numbers mentioned."
        )

        # Step 2: Extract all relevant facts from the passage in parallel — this handles ambiguity and multiple entities
        extract_tasks = [
            self.generate(instruction="List all named entities involved in the passage with their associated actions or values."),
            self.generate(instruction="Identify all numerical values in the passage and associate them with the entities they describe.")
        ]
        extracted_facts, extracted_numbers = await asyncio.gather(*extract_tasks)

        # Step 3: Use the analysis to decide whether we need to perform arithmetic, counting, or span extraction
        if "how many" in analysis.lower() or "difference" in analysis.lower():
            # Arithmetic/Counting path
            arithmetic_plan = await self.generate(
                instruction="Based on the extracted facts and numbers, generate a step-by-step plan to compute the required quantity.",
                context=f"Analysis: {analysis}\nExtracted Facts: {extracted_facts}\nExtracted Numbers: {extracted_numbers}"
            )
            solution = await self.generate(
                instruction="Execute the arithmetic plan to calculate the final answer.",
                context=arithmetic_plan
            )
        elif "who caught" in analysis.lower() or "what was the name of" in analysis.lower():
            # Span extraction path
            span_plan = await self.generate(
                instruction="Identify which entity matches the description in the question based on the extracted facts.",
                context=f"Analysis: {analysis}\nExtracted Facts: {extracted_facts}"
            )
            solution = await self.generate(
                instruction="Return only the exact text span that answers the question.",
                context=span_plan
            )
        else:
            # General case: use ensemble to combine multiple interpretations
            diverse_solutions = [
                self.generate(instruction="Generate a solution assuming this is a count-based question.", context=analysis),
                self.generate(instruction="Generate a solution assuming this is a comparison-based question.", context=analysis),
                self.generate(instruction="Generate a solution assuming this is a span-extraction question.", context=analysis)
            ]
            solution = await self.ensemble(
                instruction="Choose the most consistent and well-supported answer from the three candidate solutions.",
                contexts_to_ensemble=diverse_solutions
            )

        # Step 4: Final refinement using revise to catch any logical errors or ambiguities
        final_answer = await self.revise(
            instruction="Critique the generated solution for clarity, correctness, and alignment with the original question. Improve if necessary.",
            context_to_revise=solution
        )

        return final_answer