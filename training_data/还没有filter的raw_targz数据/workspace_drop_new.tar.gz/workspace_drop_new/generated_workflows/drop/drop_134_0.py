# Workflow ID: drop_134_0
# Benchmark: drop
# Data Indices: [259, 38]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis - Understand question intent and extract key elements
        analysis = await self.generate(
            instruction="Analyze the question to determine what type of reasoning is required (e.g., span extraction, counting, comparison). Also identify all entities mentioned in the passage that may be relevant."
        )

        # Step 2: Parallel Exploration - Extract different types of information
        task_extract_entities = self.generate(
            instruction="List all named entities from the passage that could be relevant to answering the question."
        )
        task_extract_numbers = self.generate(
            instruction="Extract all numerical values from the passage along with their associated entities or contexts."
        )
        task_extract_relations = self.generate(
            instruction="Identify relationships between entities (e.g., 'X participates under name Y', 'Z was chief until date')."
        )

        extracted_data = await asyncio.gather(task_extract_entities, task_extract_numbers, task_extract_relations)

        # Step 3: Diverge-Converge Pattern - Generate multiple interpretations/solutions
        solution_1 = await self.generate(
            instruction="Based on entity extraction, generate a candidate answer by selecting the most relevant spans.",
            context=extracted_data[0]
        )
        solution_2 = await self.generate(
            instruction="Based on number-entity associations, generate a candidate answer focusing on numeric reasoning.",
            context=extracted_data[1]
        )
        solution_3 = await self.generate(
            instruction="Based on relational patterns, generate a candidate answer that uses contextual clues to resolve ambiguity.",
            context=extracted_data[2]
        )

        # Step 4: Ensemble - Synthesize best answer from diverse approaches
        final_answer = await self.ensemble(
            instruction="Choose the most accurate answer based on consistency across all three solutions. If there's disagreement, prioritize clarity and alignment with explicit text.",
            contexts_to_ensemble=[solution_1, solution_2, solution_3]
        )

        # Step 5: Optional Refinement - Revise if needed (based on confidence signal)
        revision_instruction = "If the final answer seems incomplete or ambiguous, refine it using the original passage as context."
        refined_answer = await self.revise(revision_instruction, final_answer)

        return refined_answer