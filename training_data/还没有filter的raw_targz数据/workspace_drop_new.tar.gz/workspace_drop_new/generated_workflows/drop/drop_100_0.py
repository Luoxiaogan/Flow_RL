# Workflow ID: drop_100_0
# Benchmark: drop
# Data Indices: [45, 298]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand the question type and passage structure
        analysis = await self.generate(
            instruction="Analyze the question and passage to determine the required reasoning type (e.g., extraction, counting, comparison, arithmetic). Also identify key entities and numbers mentioned."
        )

        # Step 2: Extract all relevant facts from the passage in parallel (for efficiency and completeness)
        extract_facts_tasks = [
            self.generate(instruction="Extract all named entities with their associated numerical values or descriptive attributes."),
            self.generate(instruction="List all dates, locations, and demographic details mentioned in the passage.")
        ]
        extracted_facts = await asyncio.gather(*extract_facts_tasks)

        # Step 3: Summarize the extracted information to reduce noise and focus on relevant parts
        summarized_facts = await self.summarize(context_to_summarize="\n".join(extracted_facts))

        # Step 4: Generate multiple solution approaches based on different interpretations of the question
        if "more than" in analysis.lower() or "greater than" in analysis.lower():
            approach_1 = await self.generate(
                instruction="Identify all values that meet the threshold condition (e.g., >50000).",
                context=summarized_facts
            )
            approach_2 = await self.generate(
                instruction="List all entries that match the criteria described in the question.",
                context=summarized_facts
            )
            solution_candidates = [approach_1, approach_2]
        elif "which play" in analysis.lower() or "second play" in analysis.lower():
            approach_1 = await self.generate(
                instruction="From the passage, identify the order of plays in the Wallenstein trilogy.",
                context=summarized_facts
            )
            approach_2 = await self.generate(
                instruction="Extract only the titles of the plays mentioned in the text.",
                context=summarized_facts
            )
            solution_candidates = [approach_1, approach_2]
        else:
            # Generic fallback: generate one solution based on structured understanding
            solution_candidates = [await self.generate(
                instruction="Based on the passage and analysis, provide a direct answer to the question.",
                context=summarized_facts
            )]

        # Step 5: Ensemble the candidate solutions to resolve ambiguity or disagreement
        final_answer = await self.ensemble(
            instruction="Select the most consistent and accurate answer from the candidates. If there's disagreement, choose the one best supported by evidence.",
            contexts_to_ensemble=solution_candidates
        )

        # Step 6: Optional refinement if the answer seems incomplete or vague
        if "not enough" in final_answer.lower() or "unclear" in final_answer.lower():
            refined_answer = await self.revise(
                instruction="Revise the answer to ensure it directly addresses the question and includes all necessary details.",
                context_to_revise=final_answer
            )
            return refined_answer

        return final_answer