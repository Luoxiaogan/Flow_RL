# Workflow ID: drop_102_0
# Benchmark: drop
# Data Indices: [4, 78]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question type and key entities
        analysis = await self.generate(
            instruction="Analyze the question and passage to determine what kind of reasoning is required (e.g., counting, comparison, span extraction, arithmetic). Identify all relevant entities, events, and numerical references."
        )

        # Step 2: Extract structured facts — focus on discrete occurrences and relations
        extraction = await self.generate(
            instruction="Extract all relevant facts from the passage that could be used to answer the question. Focus on named entities, dates, counts, and numerical values with their associated context.",
            context=analysis
        )

        # Step 3: Parallel exploration of multiple interpretations if ambiguous
        if "ambiguous" in analysis.lower() or "multiple" in analysis.lower():
            # Generate diverse candidate solutions based on different interpretations
            task1 = self.generate(
                instruction="Assume the question asks for total count across all instances of the entity mentioned.",
                context=extraction
            )
            task2 = self.generate(
                instruction="Assume the question refers to a specific instance (e.g., first/last occurrence) of the entity mentioned.",
                context=extraction
            )
            task3 = self.generate(
                instruction="Assume the question requires inference from implicit relationships (e.g., cause-effect, sequence).",
                context=extraction
            )
            candidates = await asyncio.gather(task1, task2, task3)
            final_answer = await self.ensemble(
                instruction="Select the most plausible answer based on consistency with the passage and clarity of reasoning.",
                contexts_to_ensemble=candidates
            )
        else:
            # Step 4: Direct reasoning path for non-ambiguous cases
            reason_step = await self.generate(
                instruction="Reason step-by-step using the extracted facts to arrive at the correct answer. Be precise about which numbers belong to which entities.",
                context=extraction
            )

            # Step 5: Revise for precision and correctness
            final_answer = await self.revise(
                instruction="Review the solution carefully. Check for misassociations between entities and values, missing instances, or logical errors in reasoning.",
                context_to_revise=reason_step
            )

        return final_answer