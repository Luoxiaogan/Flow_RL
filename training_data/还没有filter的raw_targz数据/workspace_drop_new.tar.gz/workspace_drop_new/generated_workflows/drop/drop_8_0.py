# Workflow ID: drop_8_0
# Benchmark: drop
# Data Indices: [228, 184]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand question intent and extract key entities/numbers
        analysis = await self.generate(
            instruction="Analyze the passage and question to identify the type of reasoning required (e.g., arithmetic, counting, comparison). Also, extract all relevant numerical values and their associated entities."
        )

        # Step 2: Parallel Exploration — Generate multiple candidate solutions using different strategies
        task1 = self.generate(
            instruction="Based on the analysis, generate a solution focusing on direct number extraction and arithmetic operations.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Generate an alternative solution by first summarizing the passage to reduce noise, then solving step-by-step.",
            context=analysis
        )
        task3 = self.generate(
            instruction="Create a hypothesis-based approach: list possible interpretations of ambiguous references, then test each against evidence.",
            context=analysis
        )

        results = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble — Combine the three candidate solutions into a robust final answer
        final_answer = await self.ensemble(
            instruction="Choose the most consistent and logically supported answer from the three candidates. If there's disagreement, explain why one stands out.",
            contexts_to_ensemble=results
        )

        # Step 4: Optional Refinement — Use revise if final answer seems uncertain or incomplete
        refined_answer = await self.revise(
            instruction="If the answer lacks clarity or precision, improve it by explicitly stating the reasoning steps used to arrive at the final value.",
            context_to_revise=final_answer
        )

        return refined_answer