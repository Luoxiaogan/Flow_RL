# Workflow ID: drop_2_0
# Benchmark: drop
# Data Indices: [125, 118]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand the question type and key entities
        analysis = await self.generate(
            instruction="Analyze the passage and question. Identify the type of reasoning required (e.g., arithmetic, counting, comparison, span extraction). Also extract all named entities and numerical values relevant to the question."
        )

        # Step 2: Extract structured facts — separate entities from numbers for clarity
        extracted_facts = await self.generate(
            instruction="From the analysis, extract all key facts as structured items: (entity, value, context). For example, 'Steve Slaton, 9-yard pass, second quarter'. Do not include irrelevant details.",
            context=analysis
        )

        # Step 3: Parallel exploration of possible interpretations or solutions
        task1 = self.generate(
            instruction="Based on the extracted facts, generate a candidate answer assuming the question requires summing specific values.",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Based on the extracted facts, generate a candidate answer assuming the question requires selecting the maximum/minimum value among similar entities.",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Based on the extracted facts, generate a candidate answer assuming the question requires identifying a specific entity based on contextual clues.",
            context=extracted_facts
        )

        # Run parallel tasks to explore different solution paths
        candidates = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble to select the best answer based on consistency and clarity
        final_answer = await self.ensemble(
            instruction="Evaluate the three candidate answers. Choose the one that most directly addresses the original question using clear reasoning. If multiple seem plausible, pick the one with strongest supporting evidence in the passage.",
            contexts_to_ensemble=candidates
        )

        # Step 5: Optional refinement if the ensemble result seems ambiguous
        if "uncertain" in final_answer.lower() or "not sure" in final_answer.lower():
            refined_answer = await self.revise(
                instruction="Revise the answer by focusing only on the clearest evidence from the passage. Ignore speculative or weakly supported claims.",
                context_to_revise=final_answer
            )
            return refined_answer

        return final_answer