# Workflow ID: drop_40_0
# Benchmark: drop
# Data Indices: [72, 117]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Analyze question type to guide strategy
        analysis = await self.generate(
            instruction="Identify the core reasoning type in this question: e.g., counting, arithmetic, comparison, span extraction, or multi-hop inference."
        )

        # Step 2: Extract all relevant facts from passage
        extraction = await self.generate(
            instruction="Extract all numerical values and their associated entities or contexts (e.g., 'field goal: 39 yards', 'year range: 1968-1976'). Be exhaustive.",
            context=analysis
        )

        # Step 3: Summarize extracted data for clarity
        summarized_data = await self.summarize(extraction)

        # Step 4: Generate multiple candidate solutions based on different interpretations
        candidate_solutions = []
        if "how many" in analysis.lower() or "count" in analysis.lower():
            task1 = self.generate("Generate solution by counting all instances matching the question.", context=summarized_data)
            task2 = self.generate("Generate solution by identifying only unique entities mentioned in the question.", context=summarized_data)
            candidates = await asyncio.gather(task1, task2)
            candidate_solutions.extend(candidates)
        elif "difference" in analysis.lower() or "more" in analysis.lower() or "less" in analysis.lower():
            task1 = self.generate("Calculate the difference between the two largest values mentioned.", context=summarized_data)
            task2 = self.generate("Identify which value is greater and return just that number.", context=summarized_data)
            candidates = await asyncio.gather(task1, task2)
            candidate_solutions.extend(candidates)
        elif "longest" in analysis.lower() or "greatest" in analysis.lower() or "most" in analysis.lower():
            task1 = self.generate("Find the maximum numeric value among all extracted facts.", context=summarized_data)
            task2 = self.generate("List all numeric values and identify the highest one.", context=summarized_data)
            candidates = await asyncio.gather(task1, task2)
            candidate_solutions.extend(candidates)
        else:
            task1 = self.generate("Extract the exact text span that answers the question directly.", context=summarized_data)
            task2 = self.generate("Generate a concise answer based on the most likely interpretation of the question.", context=summarized_data)
            candidates = await asyncio.gather(task1, task2)
            candidate_solutions.extend(candidates)

        # Step 5: Ensemble final decision from competing solutions
        final_answer = await self.ensemble(
            instruction="Choose the best answer from the following options based on consistency with the passage and logical coherence.",
            contexts_to_ensemble=candidate_solutions
        )

        # Step 6: Revise once more to catch errors or ambiguities
        final_solution = await self.revise(
            instruction="Review the final answer for correctness, clarity, and alignment with the original question. Fix any issues found.",
            context_to_revise=final_answer
        )

        return final_solution