# Workflow ID: drop_113_0
# Benchmark: drop
# Data Indices: [200, 216]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand question type and key entities
        analysis = await self.generate(
            instruction="Analyze the question and passage to determine the required reasoning type (e.g., comparison, counting, arithmetic, span extraction). Identify all relevant entities and numerical values."
        )

        # Step 2: Extract Key Facts — Pull structured information from passage
        extracted_facts = await self.generate(
            instruction="Extract all relevant facts, numbers, and entities that could be used to answer the question. Format as bullet points or key-value pairs.",
            context=analysis
        )

        # Step 3: Parallel Hypothesis Generation — Generate multiple candidate solutions based on different interpretations
        task1 = self.generate(
            instruction="Based on the extracted facts, generate a solution assuming the question requires simple span extraction.",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Based on the extracted facts, generate a solution assuming the question requires arithmetic reasoning (e.g., difference, sum).",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Based on the extracted facts, generate a solution assuming the question involves comparison between two entities.",
            context=extracted_facts
        )

        # Run parallel hypotheses
        candidates = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer — Select best-supported solution
        final_answer = await self.ensemble(
            instruction="Choose the most accurate and well-supported answer from the three generated candidates. Justify briefly if there's ambiguity.",
            contexts_to_ensemble=candidates
        )

        # Optional: Revise for clarity or correctness if needed
        refined_answer = await self.revise(
            instruction="Refine the final answer for clarity, precision, and completeness. Ensure it directly addresses the original question without unnecessary detail.",
            context_to_revise=final_answer
        )

        return refined_answer