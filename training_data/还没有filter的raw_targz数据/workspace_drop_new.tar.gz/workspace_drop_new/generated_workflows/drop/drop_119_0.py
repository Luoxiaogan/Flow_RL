# Workflow ID: drop_119_0
# Benchmark: drop
# Data Indices: [261, 109]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand question type and passage structure
        analysis = await self.generate(
            instruction="Analyze the question and passage to identify key entities, numerical values, and what type of reasoning is required (e.g., span extraction, arithmetic, comparison)."
        )

        # Step 2: Extract Structured Facts — Identify all relevant facts in parallel
        extract_tasks = [
            self.generate("List all named entities mentioned in the passage with their associated numerical values or timestamps."),
            self.generate("Identify all time markers (like Q1, Q2, etc.) and corresponding events."),
            self.generate("Extract all numeric values that could be relevant to answering the question.")
        ]
        extracted_facts_raw = await asyncio.gather(*extract_tasks)
        extracted_facts = "\n\n".join(extracted_facts_raw)

        # Step 3: Summarize & Focus — Condense into actionable context
        focused_context = await self.summarize(
            context_to_summarize=extracted_facts
        )

        # Step 4: Generate Candidate Solutions — Create multiple interpretations
        candidates = []
        candidate_instructions = [
            "Based on the focused context, generate a direct answer to the question.",
            "Generate an alternative interpretation of the question based on ambiguous references (e.g., pronouns, partial names).",
            "If the question involves comparison or selection, list possible candidates and their values."
        ]
        for inst in candidate_instructions:
            candidate = await self.generate(inst, context=focused_context)
            candidates.append(candidate)

        # Step 5: Ensemble Final Answer — Select best-supported solution
        final_answer = await self.ensemble(
            instruction="Choose the most accurate and directly supported answer from the following candidates. Resolve conflicts by selecting the one most consistent with the passage text.",
            contexts_to_ensemble=candidates
        )

        # Optional: Revise if confidence is low — check for uncertainty indicators
        if "uncertain" in final_answer.lower() or "not sure" in final_answer.lower():
            final_answer = await self.revise(
                instruction="Revise the answer using only clear evidence from the passage. Avoid speculation.",
                context_to_revise=final_answer
            )

        return final_answer