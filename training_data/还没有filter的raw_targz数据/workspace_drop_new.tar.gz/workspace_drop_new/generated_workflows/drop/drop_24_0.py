# Workflow ID: drop_24_0
# Benchmark: drop
# Data Indices: [44, 174]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question type and key entities
        analysis = await self.generate(
            instruction="Analyze the passage and question to determine the required reasoning type (e.g., span extraction, counting, arithmetic). Identify all relevant entities mentioned in the passage that could be answers."
        )

        # Step 2: Extract structured facts — focus on events, players, numbers, and relations
        extraction = await self.generate(
            instruction="Extract all relevant factual statements from the passage, focusing on named entities (people, teams), actions, scores, and numerical values. Format as bullet points with clear entity-number associations.",
            context=analysis
        )

        # Step 3: Parallel exploration — generate multiple candidate solutions based on different interpretations
        task1 = self.generate(
            instruction="Based on the extracted facts, directly answer the question by identifying the exact span or number that matches the query.",
            context=extraction
        )
        task2 = self.generate(
            instruction="Rephrase the question to focus on possible alternative interpretations (e.g., if it's about 'how many', consider whether it means total or per team). Then solve using the same facts.",
            context=extraction
        )
        task3 = self.generate(
            instruction="Generate a solution assuming the question requires multi-hop reasoning (i.e., combining two pieces of information from the passage).",
            context=extraction
        )
        results = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble to select the best solution among candidates
        final_answer = await self.ensemble(
            instruction="Compare the three candidate solutions. Choose the one that best aligns with the original question, considering clarity, correctness, and consistency with the passage.",
            contexts_to_ensemble=results
        )

        # Step 5: Optional refinement loop if uncertainty remains
        if "ambiguous" in analysis.lower() or "multiple" in analysis.lower():
            refined_answer = await self.revise(
                instruction="Review the final answer. If there's ambiguity or potential misassociation between entities and numbers, revise to clarify which entity corresponds to which value.",
                context_to_revise=final_answer
            )
            return refined_answer

        return final_answer