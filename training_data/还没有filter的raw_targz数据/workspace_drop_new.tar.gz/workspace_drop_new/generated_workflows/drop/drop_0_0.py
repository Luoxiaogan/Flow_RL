# Workflow ID: drop_0_0
# Benchmark: drop
# Data Indices: [71, 0]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question intent and passage structure
        analysis = await self.generate(
            instruction="Analyze the question and passage to determine the type of reasoning required (e.g., extraction, counting, comparison, arithmetic). Identify key entities, events, and numbers."
        )

        # Step 2: Extract all relevant factual information in parallel for robustness
        extract_tasks = [
            self.generate(instruction="List all named entities mentioned in the passage with their associated numerical values or attributes."),
            self.generate(instruction="Extract all explicit numerical facts (dates, counts, distances, scores) from the passage.")
        ]
        extracted_facts, numerical_facts = await asyncio.gather(*extract_tasks)

        # Step 3: Summarize key elements to reduce context length and focus on relevant info
        summary = await self.summarize(context_to_summarize=analysis + "\n\n" + extracted_facts + "\n\n" + numerical_facts)

        # Step 4: Generate multiple candidate solutions based on different interpretations
        solution_candidates = []
        if "how many" in analysis.lower() or "count" in analysis.lower():
            candidate = await self.generate(
                instruction="Based on the summary, count all instances of the entity mentioned in the question. Be exhaustive.",
                context=summary
            )
            solution_candidates.append(candidate)

        if "difference" in analysis.lower() or "more than" in analysis.lower() or "greater" in analysis.lower():
            candidate = await self.generate(
                instruction="Identify the two values referenced in the question and compute their difference. Ensure correct pairing of values with entities.",
                context=summary
            )
            solution_candidates.append(candidate)

        if "who threw" in analysis.lower() or "which team won" in analysis.lower():
            candidate = await self.generate(
                instruction="Determine which entity performed the action described in the question by matching pronouns and event sequences.",
                context=summary
            )
            solution_candidates.append(candidate)

        # Step 5: Ensemble final answer using diverse perspectives
        final_answer = await self.ensemble(
            instruction="Choose the most consistent and well-supported answer among the candidates. If there's ambiguity, select the one best aligned with the passage's structure and explicit statements.",
            contexts_to_ensemble=solution_candidates
        )

        # Step 6: Revise once for precision — check for logical consistency and clarity
        refined_answer = await self.revise(
            instruction="Review the final answer. Does it directly address the question? Is it supported by evidence in the passage? Remove any ambiguous or unsupported claims.",
            context_to_revise=final_answer
        )

        return refined_answer