# Workflow ID: drop_71_0
# Benchmark: drop
# Data Indices: [37, 290]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis - Understand question intent and key entities
        analysis = await self.generate(
            instruction="Analyze the question and passage to identify required reasoning type (e.g., counting, comparison, span extraction, arithmetic), key entities, and whether multiple instances exist."
        )

        # Step 2: Extract all relevant information using parallel exploration
        extract_tasks = [
            self.generate("Extract all numerical values from the passage with their associated entities or contexts."),
            self.generate("Identify all named entities (people, teams, locations) mentioned in the passage."),
            self.generate("List all temporal references (dates, time periods, sequences)."),
            self.generate("Identify any implicit relationships or causal chains in the text.")
        ]
        extracted_data = await asyncio.gather(*extract_tasks)

        # Step 3: Summarize extracted data for clarity and focus
        summarized_data = await self.summarize("\n\n".join(extracted_data))

        # Step 4: Generate candidate solutions based on different reasoning strategies
        candidates = []
        if "how many" in analysis.lower() or "count" in analysis.lower():
            candidates.append(await self.generate(
                instruction="Generate a solution focused on counting specific occurrences based on the summarized data.",
                context=summarized_data
            ))
        elif "difference" in analysis.lower() or "more" in analysis.lower():
            candidates.append(await self.generate(
                instruction="Generate a solution focused on calculating differences between two numeric values from the summarized data.",
                context=summarized_data
            ))
        elif "which" in analysis.lower() and ("greater" in analysis.lower() or "more" in analysis.lower()):
            candidates.append(await self.generate(
                instruction="Generate a solution focused on comparing two entities' values from the summarized data.",
                context=summarized_data
            ))
        else:
            candidates.append(await self.generate(
                instruction="Generate a solution focused on extracting the correct span or entity based on the summarized data.",
                context=summarized_data
            ))

        # Step 5: Ensemble to select best answer among diverse approaches
        final_answer = await self.ensemble(
            instruction="Select the most accurate and coherent answer from the following candidate solutions, considering consistency with the original question and passage.",
            contexts_to_ensemble=candidates
        )

        # Step 6: Optional refinement loop for high-stakes accuracy
        if "ambiguous" in analysis.lower() or "multiple" in analysis.lower():
            refined_answer = await self.revise(
                instruction="Critique the final answer for potential errors in entity-number association or missing instances. If found, revise accordingly.",
                context_to_revise=final_answer
            )
            return refined_answer

        return final_answer