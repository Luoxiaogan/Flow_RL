# Workflow ID: drop_110_0
# Benchmark: drop
# Data Indices: [79, 116]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question intent and passage structure
        analysis = await self.generate(
            instruction="Analyze the question and passage to identify required reasoning type (e.g., arithmetic, counting, comparison) and key entities."
        )

        # Step 2: Extract all relevant numerical and categorical facts from the passage
        extraction_prompt = (
            "Extract all numerically quantifiable data points (percentages, counts, dates, values) "
            "with their associated entities or contexts from the passage. Format as a structured list."
        )
        raw_extracted_data = await self.generate(instruction=extraction_prompt)

        # Step 3: Summarize extracted data for clarity and context management
        summarized_data = await self.summarize(context_to_summarize=raw_extracted_data)

        # Step 4: Generate multiple candidate solutions based on different interpretations
        candidate_1 = await self.generate(
            instruction="Generate a solution assuming the question requires simple subtraction of a percentage from 100.",
            context=summarized_data
        )
        candidate_2 = await self.generate(
            instruction="Generate a solution assuming the question requires identifying a specific category and subtracting it from total.",
            context=summarized_data
        )
        candidate_3 = await self.generate(
            instruction="Generate a solution assuming the question involves multi-step reasoning like finding an implicit value first.",
            context=summarized_data
        )

        # Step 5: Ensemble the three candidates to select the most consistent answer
        final_answer = await self.ensemble(
            instruction="Select the best answer by comparing the three generated solutions. If there's disagreement, choose the one that aligns with the passage's explicit percentages.",
            contexts_to_ensemble=[candidate_1, candidate_2, candidate_3]
        )

        # Step 6: Revise if needed — check for logical consistency with original passage
        revision_instruction = (
            "Review the final answer against the passage. If the answer contradicts known values or lacks justification, revise it accordingly."
        )
        refined_answer = await self.revise(
            instruction=revision_instruction,
            context_to_revise=final_answer
        )

        return refined_answer