# Workflow ID: drop_95_0
# Benchmark: drop
# Data Indices: [29, 178]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand the question type and extract key entities
        analysis = await self.generate(
            instruction="Analyze the question to determine what kind of reasoning is needed (e.g., arithmetic, counting, comparison, span extraction). Identify all relevant entities mentioned in both passage and question."
        )

        # Step 2: Extract Relevant Facts — Use parallel extraction to gather structured data
        task1 = self.generate(instruction="Extract all numerical values related to the entities mentioned in the question.")
        task2 = self.generate(instruction="Extract all named entities (people, teams, positions) that may be involved in the answer.")
        task3 = self.generate(instruction="Extract any comparative or relational statements (e.g., 'more than', 'greater than') from the passage.")

        extracted_facts, extracted_entities, extracted_relations = await asyncio.gather(task1, task2, task3)

        # Step 3: Reasoning — Generate solution paths based on different interpretations
        math_path = await self.generate(
            instruction="Based on the extracted facts, compute the required arithmetic operation (sum, difference, ratio, etc.) if applicable.",
            context=extracted_facts
        )
        
        count_path = await self.generate(
            instruction="If the question involves counting, identify all instances of the target entity and count them.",
            context=extracted_facts
        )

        selection_path = await self.generate(
            instruction="If the question asks for selection (e.g., who had more), compare the relevant values using extracted relations.",
            context=f"{extracted_entities}\n{extracted_relations}"
        )

        # Step 4: Ensemble — Synthesize multiple perspectives into one robust answer
        final_answer = await self.ensemble(
            instruction="Choose the most consistent and logically sound answer among the three paths above. Consider which path aligns best with the question intent.",
            contexts_to_ensemble=[math_path, count_path, selection_path]
        )

        # Step 5: Revise — Refine the final answer by checking for logical consistency and ambiguity
        revised_answer = await self.revise(
            instruction="Review the final answer for clarity, correctness, and whether it fully addresses the original question. If unsure, generate an alternative interpretation and re-ensemble.",
            context_to_revise=final_answer
        )

        return revised_answer