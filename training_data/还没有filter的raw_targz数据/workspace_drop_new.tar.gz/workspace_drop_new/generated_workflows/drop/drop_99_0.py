# Workflow ID: drop_99_0
# Benchmark: drop
# Data Indices: [17, 172]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to detect question type and key entities
        analysis = await self.generate(
            instruction="Analyze the passage and question to determine the required reasoning type (e.g., arithmetic, counting, comparison) and identify all relevant numerical values with their associated entities."
        )

        # Step 2: Extract structured facts — critical for multi-hop and entity tracking
        extraction = await self.generate(
            instruction="Extract all relevant numerical data points from the passage along with their associated entities and context. Format as: 'Entity: [value] yards/points/etc.'",
            context=analysis
        )

        # Step 3: Generate multiple solution strategies in parallel
        task1 = self.generate(
            instruction="Generate a step-by-step plan to solve this using only explicit numerical values.",
            context=extraction
        )
        task2 = self.generate(
            instruction="Generate a plan that considers implicit associations between entities and numbers (e.g., who threw what pass).",
            context=extraction
        )
        task3 = self.generate(
            instruction="Generate a plan focused on identifying the exact subset of values needed based on the question's intent (e.g., total vs. individual).",
            context=extraction
        )
        plans = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble the competing solutions to find consensus
        ensemble_result = await self.ensemble(
            instruction="Compare the three solution plans and select the most accurate approach based on clarity, completeness, and alignment with the question.",
            contexts_to_ensemble=plans
        )

        # Step 5: Execute the chosen strategy
        final_solution = await self.generate(
            instruction="Using the selected plan, compute the final answer by applying the correct operations (addition, subtraction, etc.) on the extracted values.",
            context=ensemble_result
        )

        # Step 6: Revise for accuracy — check if the answer makes sense in context
        revised_answer = await self.revise(
            instruction="Review the final answer for correctness: does it match the question? Are all relevant values accounted for? If not, fix the mistake.",
            context_to_revise=final_solution
        )

        return revised_answer