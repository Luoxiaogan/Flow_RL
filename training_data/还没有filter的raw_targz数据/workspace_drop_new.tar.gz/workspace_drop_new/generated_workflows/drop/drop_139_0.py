# Workflow ID: drop_139_0
# Benchmark: drop
# Data Indices: [99, 157]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question intent and passage structure
        analysis = await self.generate(
            instruction="Analyze the question and passage to identify key entities, numerical values, and reasoning type (e.g., counting, comparison, arithmetic)."
        )

        # Step 2: Extract structured facts — critical for multi-hop and ambiguous references
        extraction = await self.generate(
            instruction="Extract all relevant named entities and associated numerical or categorical data from the passage. Format as bullet points with clear entity-number pairs.",
            context=analysis
        )

        # Step 3: Parallel exploration of different solution paths based on question type
        tasks = [
            self.generate(
                instruction="If the question asks for a count, list all instances of the target entity and provide the total count.",
                context=extraction
            ),
            self.generate(
                instruction="If the question involves comparison, identify the two entities being compared and their respective values.",
                context=extraction
            ),
            self.generate(
                instruction="If the question requires calculation (sum, difference, etc.), extract the numbers involved and describe how they should be combined.",
                context=extraction
            )
        ]
        parallel_solutions = await asyncio.gather(*tasks)

        # Step 4: Ensemble to select the best solution path based on relevance to the original question
        final_solution = await self.ensemble(
            instruction="Based on the original question, evaluate the three candidate solutions and select the one that most directly addresses it. If multiple are valid, choose the most precise one.",
            contexts_to_ensemble=parallel_solutions
        )

        # Step 5: Revise for precision — check if the answer matches expected format (number, text span, etc.)
        revised_answer = await self.revise(
            instruction="Check if the answer is in the correct format (e.g., numeric for counts, full name for spans). If not, refine it accordingly.",
            context_to_revise=final_solution
        )

        return revised_answer