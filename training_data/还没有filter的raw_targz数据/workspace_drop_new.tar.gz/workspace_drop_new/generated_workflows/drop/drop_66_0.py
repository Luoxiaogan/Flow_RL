# Workflow ID: drop_66_0
# Benchmark: drop
# Data Indices: [197, 282]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to detect question type and key entities
        analysis = await self.generate(
            instruction="Analyze the passage and question to determine the type of reasoning required (e.g., temporal, numerical, comparative) and identify all relevant entities, events, or values."
        )

        # Step 2: Extract structured facts from the passage using parallel exploration
        extraction_tasks = [
            self.generate("Extract all named events with timestamps or sequences from the passage."),
            self.generate("Extract all numerical values mentioned in the passage along with their associated entities."),
            self.generate("Extract all comparative or selection-based references (e.g., 'which came first', 'how many more').")
        ]
        extracted_facts = await asyncio.gather(*extraction_tasks)

        # Step 3: Summarize extracted facts to reduce noise and focus on relevance
        summarized_facts = await self.summarize("\n\n".join(extracted_facts))

        # Step 4: Generate multiple candidate solutions based on different interpretations
        solution_candidates = []
        for i, candidate_prompt in enumerate([
            "Based on the summarized facts, generate a solution assuming the question requires chronological ordering.",
            "Based on the summarized facts, generate a solution assuming the question involves counting or summing values.",
            "Based on the summarized facts, generate a solution assuming the question requires selecting an entity based on context clues."
        ]):
            candidate = await self.generate(candidate_prompt, context=summarized_facts)
            solution_candidates.append(candidate)

        # Step 5: Ensemble the candidates to resolve ambiguity or conflict
        final_answer = await self.ensemble(
            instruction="Select the most consistent and logically supported answer from the following candidate responses. Resolve conflicts by prioritizing explicit evidence over inference.",
            contexts_to_ensemble=solution_candidates
        )

        # Step 6: Revise the final answer if it lacks clarity or precision
        revised_answer = await self.revise(
            instruction="Improve the clarity and precision of the final answer. Ensure it directly addresses the original question without unnecessary elaboration.",
            context_to_revise=final_answer
        )

        return revised_answer