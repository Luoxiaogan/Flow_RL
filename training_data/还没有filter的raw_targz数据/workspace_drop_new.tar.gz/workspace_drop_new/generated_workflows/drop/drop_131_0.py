# Workflow ID: drop_131_0
# Benchmark: drop
# Data Indices: [13, 233]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question type and key entities
        analysis = await self.generate(
            instruction="Analyze the passage and question to identify the type of reasoning required (e.g., chronological, comparative, numerical) and extract all relevant events or entities mentioned."
        )

        # Step 2: Extract structured timeline/event data from passage
        extraction = await self.generate(
            instruction="From the passage, extract all discrete events with timestamps or relative order indicators (e.g., 'first', 'then', 'next'). Format as a numbered list: [Event 1: description], [Event 2: description], etc.",
            context=analysis
        )

        # Step 3: Generate multiple interpretations if ambiguity exists
        try:
            # Use parallel exploration to generate alternative timelines or interpretations
            task1 = self.generate("Generate one possible interpretation of event order based on the passage.")
            task2 = self.generate("Generate another possible interpretation of event order, focusing on potential ambiguities in pronouns or references.")
            task3 = self.generate("Generate a third interpretation that emphasizes temporal markers like 'after' or 'before'.")
            
            interpretations = await asyncio.gather(task1, task2, task3)
            
            # Step 4: Ensemble the interpretations to resolve contradictions
            consolidated = await self.ensemble(
                instruction="Synthesize the three interpretations into a single coherent timeline, resolving conflicts by prioritizing explicit temporal markers over implicit ones.",
                contexts_to_ensemble=interpretations
            )
        except Exception:
            # Fallback if parallel processing fails
            consolidated = await self.generate(
                instruction="Based on the initial extraction, construct a clear chronological order of events using only explicit time markers from the passage.",
                context=extraction
            )

        # Step 5: Revise solution to ensure alignment with question intent
        final_solution = await self.revise(
            instruction="Review the consolidated timeline and ensure it directly answers the question. If not, refine it to focus solely on the elements needed to answer the question correctly.",
            context_to_revise=consolidated
        )

        return final_solution