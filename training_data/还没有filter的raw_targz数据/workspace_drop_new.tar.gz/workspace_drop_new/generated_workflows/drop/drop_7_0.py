# Workflow ID: drop_7_0
# Benchmark: drop
# Data Indices: [166, 253]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Analyze the question to determine required reasoning type
        analysis = await self.generate(
            instruction="Analyze the question to identify key elements: what needs to be counted, calculated, or compared? "
                       "Look for keywords like 'how many', 'difference', 'longer than', 'total', etc."
        )

        # Step 2: Extract all relevant numerical facts from passage (e.g., field goals, touchdowns, distances)
        extraction = await self.generate(
            instruction="Extract all numeric values and their associated entities from the passage. "
                       "Include context such as who performed it, when, and how much (e.g., 'Mare: 30-yard FG', 'Jacobs: 3-yard TD').",
            context=analysis
        )

        # Step 3: Summarize extracted facts for clarity and focus
        summary = await self.summarize(extraction)

        # Step 4: Generate multiple solution strategies based on different interpretations
        strategy_1 = await self.generate(
            instruction="Generate a step-by-step solution assuming this is an arithmetic difference question.",
            context=summary
        )
        strategy_2 = await self.generate(
            instruction="Generate a step-by-step solution assuming this involves counting occurrences of events meeting a condition.",
            context=summary
        )
        strategy_3 = await self.generate(
            instruction="Generate a step-by-step solution assuming this requires identifying specific spans (like names) before calculation.",
            context=summary
        )

        # Step 5: Ensemble the three strategies to produce a robust answer
        final_answer = await self.ensemble(
            instruction="Choose the most accurate solution based on consistency with the passage and logical coherence.",
            contexts_to_ensemble=[strategy_1, strategy_2, strategy_3]
        )

        # Step 6: Revise if needed — check for missing steps or inconsistencies
        revised_answer = await self.revise(
            instruction="Review the final answer for completeness, correctness, and alignment with the original question.",
            context_to_revise=final_answer
        )

        return revised_answer