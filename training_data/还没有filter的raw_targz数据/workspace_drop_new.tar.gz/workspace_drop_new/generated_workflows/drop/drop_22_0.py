# Workflow ID: drop_22_0
# Benchmark: drop
# Data Indices: [242, 98]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis - Understand question type and key entities
        analysis = await self.generate(
            instruction="Analyze the question to determine the required reasoning type (e.g., count, sum, compare, extract) and identify all relevant entities mentioned in the passage that might be involved."
        )

        # Step 2: Extract structured facts - Identify all relevant events (touchdowns, field goals, etc.)
        extraction = await self.generate(
            instruction="Extract all instances of relevant events from the passage, including players, scores, yardages, and timestamps. Format each as: 'Player: [name], Type: [event type], Yardage: [number]'",
            context=analysis
        )

        # Step 3: Diverge-Converge Strategy - Generate multiple interpretations or solutions
        task1 = self.generate(
            instruction="Based on the extracted facts, generate a candidate answer assuming this is a simple span extraction question.",
            context=extraction
        )
        task2 = self.generate(
            instruction="Based on the extracted facts, generate a candidate answer assuming this requires numerical aggregation (e.g., summing yards).",
            context=extraction
        )
        task3 = self.generate(
            instruction="Based on the extracted facts, generate a candidate answer assuming this involves comparison between two entities.",
            context=extraction
        )
        results = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble final decision based on consistency across approaches
        ensemble_result = await self.ensemble(
            instruction="Evaluate the three candidate answers and select the one that best matches the intent of the original question. If there's ambiguity, choose the most grounded in explicit evidence.",
            contexts_to_ensemble=results
        )

        # Step 5: Revise if needed — check for logical coherence or missing context
        revised_answer = await self.revise(
            instruction="Review the final answer for clarity, correctness, and alignment with the question. If it lacks specificity or seems incomplete, improve it using the original passage and extracted facts.",
            context_to_revise=ensemble_result
        )

        return revised_answer