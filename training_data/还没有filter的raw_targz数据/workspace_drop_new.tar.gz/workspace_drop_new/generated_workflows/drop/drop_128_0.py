# Workflow ID: drop_128_0
# Benchmark: drop
# Data Indices: [238, 9]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to detect question type and key entities
        analysis = await self.generate(
            instruction="Analyze the passage and question to determine the required reasoning type (e.g., arithmetic, counting, comparison, span extraction) and identify all relevant entities and numerical values."
        )

        # Step 2: Extract structured facts from passage using parallel exploration
        extract_task1 = self.generate(
            instruction="Extract all named entities (people, teams, positions) and their associated numerical data (yards, touchdowns, counts, etc.) in a structured format like 'Entity: Value' pairs."
        )
        extract_task2 = self.generate(
            instruction="Identify all explicit and implicit numerical references in the passage, including totals, averages, differences, and comparisons."
        )
        extracted_facts, extracted_numbers = await asyncio.gather(extract_task1, extract_task2)

        # Step 3: Generate candidate solutions based on different interpretations
        solution1 = await self.generate(
            instruction="Based on the extracted facts, generate a solution assuming the question asks for a simple numeric value (e.g., total or average).",
            context=extracted_facts
        )
        solution2 = await self.generate(
            instruction="Generate an alternative solution assuming the question requires multi-hop inference (e.g., combining multiple facts or resolving ambiguous references).",
            context=extracted_facts
        )
        solution3 = await self.generate(
            instruction="Generate a third solution focusing on entity-number association and coreference resolution.",
            context=extracted_facts
        )

        # Step 4: Ensemble to select the most consistent answer across approaches
        final_answer = await self.ensemble(
            instruction="Evaluate the three candidate solutions and choose the one that best aligns with the original question intent and evidence from the passage.",
            contexts_to_ensemble=[solution1, solution2, solution3]
        )

        # Step 5: Revise if needed — check for logical consistency or missing steps
        revised_answer = await self.revise(
            instruction="Review the final answer for correctness, clarity, and completeness. If necessary, refine it to ensure it directly addresses the question without ambiguity.",
            context_to_revise=final_answer
        )

        return revised_answer