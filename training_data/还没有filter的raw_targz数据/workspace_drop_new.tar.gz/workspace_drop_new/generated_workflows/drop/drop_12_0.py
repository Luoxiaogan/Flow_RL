# Workflow ID: drop_12_0
# Benchmark: drop
# Data Indices: [245, 66]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to detect question type and key elements
        analysis = await self.generate(
            instruction="Analyze the passage and question to identify the required reasoning type (e.g., arithmetic, counting, comparison, span extraction) and all relevant entities or numbers."
        )

        # Step 2: Extract structured facts from the passage — crucial for multi-hop reasoning
        extracted_facts = await self.generate(
            instruction="Extract all relevant numerical values, named entities, and their relationships from the passage. Format as a bullet list for clarity.",
            context=analysis
        )

        # Step 3: Parallel exploration — generate multiple candidate solutions based on different interpretations
        task1 = self.generate(
            instruction="Based on the extracted facts, calculate the answer assuming this is an arithmetic question (sum, difference, etc.).",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Based on the extracted facts, determine if the answer requires comparing two entities or values.",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Based on the extracted facts, identify if the question asks for a specific entity or span from the text.",
            context=extracted_facts
        )
        results = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble to select the most coherent and accurate solution
        final_answer = await self.ensemble(
            instruction="Evaluate the three candidate solutions and choose the one that best matches the question intent and is most consistent with the passage.",
            contexts_to_ensemble=results
        )

        # Step 5: Optional refinement if uncertainty remains
        if "uncertain" in final_answer.lower() or "ambiguous" in final_answer.lower():
            refined_answer = await self.revise(
                instruction="Revise the selected answer by focusing on potential ambiguities or missing connections between entities and numbers in the passage.",
                context_to_revise=final_answer
            )
            return refined_answer

        return final_answer