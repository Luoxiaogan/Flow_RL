# Workflow ID: drop_136_0
# Benchmark: drop
# Data Indices: [14, 276]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question intent and passage structure
        analysis = await self.generate(
            instruction="Analyze the question and passage to determine the type of reasoning required (e.g., arithmetic, counting, comparison, span extraction). Identify key entities, numbers, and relationships."
        )

        # Step 2: Extract all relevant numerical and entity data from the passage
        extraction = await self.generate(
            instruction="Extract all named entities, associated numerical values, and their roles in the passage. Format as structured text with clear associations (e.g., 'Joe Montana: 279 completions, 3630 yards').",
            context=analysis
        )

        # Step 3: Generate multiple solution paths based on different interpretations or approaches
        task1 = self.generate(
            instruction="Generate a step-by-step plan to solve the question using only explicit information from the extracted facts.",
            context=extraction
        )
        task2 = self.generate(
            instruction="Generate an alternative plan that considers implicit or multi-hop reasoning steps necessary to answer the question.",
            context=extraction
        )
        task3 = self.generate(
            instruction="Generate a plan focused specifically on resolving ambiguous references (pronouns, partial names) in the question using contextual clues.",
            context=extraction
        )
        plans = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble the best approach by evaluating each plan's clarity and alignment with the question
        best_plan = await self.ensemble(
            instruction="Evaluate the three generated plans and select the one most likely to yield the correct answer based on completeness, logical consistency, and relevance to the question.",
            contexts_to_ensemble=plans
        )

        # Step 5: Execute the selected plan to produce a candidate solution
        candidate_solution = await self.generate(
            instruction="Using the selected plan, now generate the final answer to the question. Be precise and ensure it matches the expected format (number, date, span, etc.).",
            context=best_plan
        )

        # Step 6: Refine the solution through iterative self-correction
        refined_solution = await self.revise(
            instruction="Critically review the candidate solution for correctness, completeness, and potential errors such as misattribution of numbers to entities or missing steps in calculation.",
            context_to_revise=candidate_solution
        )

        # Step 7: Final ensemble if needed — but typically not necessary unless uncertainty remains
        final_answer = await self.ensemble(
            instruction="If the revised solution is still uncertain, compare it against the original candidate and choose the more confident option. Otherwise, return the revised solution as-is.",
            contexts_to_ensemble=[candidate_solution, refined_solution]
        )

        return final_answer