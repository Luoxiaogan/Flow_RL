# Workflow ID: drop_132_0
# Benchmark: drop
# Data Indices: [101, 167]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question type and passage structure
        analysis = await self.generate(
            instruction="Analyze the question and passage to identify key entities, numbers, and reasoning type (e.g., arithmetic, comparison, span extraction)."
        )

        # Step 2: Extract relevant numerical facts and entity references in parallel
        extract_facts_task = self.generate(
            instruction="List all numeric values and their associated entities or contexts from the passage."
        )
        extract_entities_task = self.generate(
            instruction="Identify all named entities (people, teams, events) mentioned in the passage that might be relevant to the question."
        )
        extract_contexts_task = self.generate(
            instruction="Extract all sentences containing potential answer-relevant information."
        )

        facts, entities, contexts = await asyncio.gather(extract_facts_task, extract_entities_task, extract_contexts_task)

        # Step 3: Generate candidate solutions based on different interpretations
        math_solution = await self.generate(
            instruction="If the question involves arithmetic (e.g., sum, difference), calculate it using the extracted facts.",
            context=facts + "\n\n" + analysis
        )

        span_solution = await self.generate(
            instruction="If the question asks for a specific name or phrase, extract it from the passage using the entity list.",
            context=entities + "\n\n" + analysis
        )

        comparison_solution = await self.generate(
            instruction="If the question compares two items, identify which one meets the criteria using the extracted facts.",
            context=facts + "\n\n" + analysis
        )

        # Step 4: Ensemble the three candidate solutions to resolve ambiguity
        final_answer = await self.ensemble(
            instruction="Choose the most accurate answer among the candidates by evaluating consistency with the original question and passage.",
            contexts_to_ensemble=[math_solution, span_solution, comparison_solution]
        )

        # Step 5: Optional refinement if the ensemble result seems vague or incomplete
        if "not clear" in final_answer.lower() or "ambiguous" in final_answer.lower():
            refined_answer = await self.revise(
                instruction="Improve clarity and precision of the answer by re-examining the original passage and extracted facts.",
                context_to_revise=final_answer
            )
            return refined_answer

        return final_answer