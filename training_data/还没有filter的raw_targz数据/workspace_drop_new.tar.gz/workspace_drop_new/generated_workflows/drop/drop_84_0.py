# Workflow ID: drop_84_0
# Benchmark: drop
# Data Indices: [86, 188]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question type and key elements
        analysis = await self.generate(
            instruction="Identify the type of reasoning required (e.g., arithmetic, counting, comparison, span extraction) and extract all relevant entities, dates, or values from the passage that may be needed to answer the question."
        )

        # Step 2: Extract structured facts in parallel — critical for handling ambiguous references and multiple similar entities
        task1 = self.generate(instruction="List all numerical values mentioned in the passage with their associated entities or contexts.")
        task2 = self.generate(instruction="List all named entities (people, places, organizations) mentioned in the passage.")
        task3 = self.generate(instruction="List all dates or time-related phrases mentioned in the passage.")

        extracted_facts = await asyncio.gather(task1, task2, task3)

        # Step 3: Summarize extracted data for clarity and focus
        summarized_facts = await self.summarize(context_to_summarize="\n\n".join(extracted_facts))

        # Step 4: Generate solution based on structured facts
        solution_draft = await self.generate(
            instruction="Using the structured facts, generate a step-by-step solution to the question. If the question involves math, show the calculation clearly. If it involves selection or comparison, explain why each candidate fits or doesn't fit.",
            context=summarized_facts
        )

        # Step 5: Iterate refinement using Revise — check for missing entities, incorrect associations, or logical gaps
        refined_solution = await self.revise(
            instruction="Review the solution draft. Identify any potential errors such as misassociating numbers with entities, missing steps in reasoning, or unclear explanations. Correct these issues and improve precision.",
            context_to_revise=solution_draft
        )

        # Step 6: Ensemble multiple solutions if needed — especially useful when ambiguity exists
        # Generate alternative interpretations in parallel
        alt_task1 = self.generate(instruction="Generate an alternative interpretation of the question, focusing on different possible meanings of ambiguous terms like 'more' or 'after'.")
        alt_task2 = self.generate(instruction="Generate another solution path based on a different reading of the passage's timeline or entity relationships.")
        
        alternatives = await asyncio.gather(alt_task1, alt_task2)
        final_answer = await self.ensemble(
            instruction="Choose the best answer among the provided solutions based on consistency with the passage, logical soundness, and completeness of reasoning.",
            contexts_to_ensemble=[refined_solution] + alternatives
        )

        return final_answer