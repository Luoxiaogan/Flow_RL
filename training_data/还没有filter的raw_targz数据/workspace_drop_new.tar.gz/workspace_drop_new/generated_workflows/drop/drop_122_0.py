# Workflow ID: drop_122_0
# Benchmark: drop
# Data Indices: [180, 165]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis – Understand question type and key entities
        analysis = await self.generate(
            instruction="Analyze the question to determine its type (e.g., arithmetic, comparison, counting) and identify all relevant entities and numerical values mentioned in the passage."
        )

        # Step 2: Extract structured data – Isolate numbers, names, and relations
        extraction = await self.generate(
            instruction="Extract all relevant numerical values and associated entities from the passage. Format as 'Entity: Value' pairs.",
            context=analysis
        )

        # Step 3: Parallel Hypothesis Generation – Generate multiple interpretations if ambiguous
        task1 = self.generate(
            instruction="If the question involves comparisons or differences, generate a plan to compute the required difference or comparison using the extracted values."
        )
        task2 = self.generate(
            instruction="If the question involves sums or totals, generate a plan to compute the total based on the extracted values."
        )
        task3 = self.generate(
            instruction="If the question asks for a specific entity, generate a plan to identify the correct entity from the list of candidates."
        )
        plans = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble the best plan based on question intent
        final_plan = await self.ensemble(
            instruction="Based on the original question and the three generated plans, select the most appropriate solution strategy.",
            contexts_to_ensemble=plans
        )

        # Step 5: Execute the chosen strategy
        solution = await self.generate(
            instruction="Using the selected plan and the extracted values, solve the problem step-by-step.",
            context=final_plan + "\n\n" + extraction
        )

        # Step 6: Refine the solution iteratively for accuracy
        refined_solution = await self.revise(
            instruction="Review the solution for logical consistency, numerical correctness, and proper entity association. Correct any errors found.",
            context_to_revise=solution
        )

        return refined_solution