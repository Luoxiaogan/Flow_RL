# Workflow ID: drop_9_0
# Benchmark: drop
# Data Indices: [16, 147]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis – Understand question intent and passage structure
        analysis = await self.generate(
            instruction="Analyze the question to determine its type (e.g., comparison, count, arithmetic, span extraction). Identify key entities and numerical values in the passage relevant to the question."
        )

        # Step 2: Extract Structured Facts – Prepare clean data for reasoning
        extracted_facts = await self.generate(
            instruction="Extract all relevant facts from the passage that could be used to answer the question. Format as bullet points with clear entity-number or entity-date associations.",
            context=analysis
        )

        # Step 3: Generate Multiple Reasoning Paths – Parallel exploration for robustness
        task1 = self.generate(
            instruction="Based on the extracted facts, generate a step-by-step solution assuming this is a comparison question.",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Based on the extracted facts, generate a step-by-step solution assuming this is a counting or numerical question.",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Based on the extracted facts, generate a step-by-step solution assuming this is a span extraction or selection question.",
            context=extracted_facts
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer – Synthesize best-supported solution
        final_answer = await self.ensemble(
            instruction="Compare the three candidate solutions. Select the one that best aligns with the question's intent and the evidence in the passage. If multiple are valid, choose the most precise.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Revise for Precision – Self-correct based on logical consistency
        revised_answer = await self.revise(
            instruction="Critique the final answer: Does it directly address the question? Is it supported by the passage? If not, refine it using only the extracted facts.",
            context_to_revise=final_answer
        )

        return revised_answer