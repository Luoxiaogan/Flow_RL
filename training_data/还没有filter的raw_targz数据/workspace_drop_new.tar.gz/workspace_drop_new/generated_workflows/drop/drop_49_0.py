# Workflow ID: drop_49_0
# Benchmark: drop
# Data Indices: [46, 249]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis - Understand question type and key entities
        analysis = await self.generate(
            instruction="Analyze the question to determine what kind of reasoning is required (e.g., counting, arithmetic, comparison, span extraction) and identify all relevant entities mentioned in the passage that may be involved."
        )

        # Step 2: Extract Relevant Information - Focus on structured data like numbers and names
        extraction = await self.generate(
            instruction="Extract all numerical values and associated entities from the passage. Format as 'Entity: Value' pairs for easy reference.",
            context=analysis
        )

        # Step 3: Parallel Exploration - Generate multiple candidate interpretations or solution paths
        task1 = self.generate(
            instruction="Based on the extracted facts, generate a direct answer using explicit matches only.",
            context=extraction
        )
        task2 = self.generate(
            instruction="Generate an alternative interpretation by identifying potential implicit connections between entities and values not directly stated.",
            context=extraction
        )
        task3 = self.generate(
            instruction="Generate a third approach focusing on multi-hop inference—linking two or more pieces of information to derive the answer.",
            context=extraction
        )
        candidates = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer - Synthesize best-supported solution
        final_answer = await self.ensemble(
            instruction="Select the most accurate answer based on consistency with the passage and logical soundness across all three approaches.",
            contexts_to_ensemble=candidates
        )

        # Step 5: Revise for Precision - Self-correct if needed based on ambiguity or error patterns
        revised_answer = await self.revise(
            instruction="Review the final answer for clarity, correctness, and completeness. If it's ambiguous or incomplete, improve it using insights from earlier steps.",
            context_to_revise=final_answer
        )

        return revised_answer