# Workflow ID: drop_61_0
# Benchmark: drop
# Data Indices: [144, 225]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand the question type and key entities
        analysis = await self.generate(
            instruction="Analyze the question and passage to determine the required reasoning type (e.g., arithmetic, counting, comparison, span extraction) and identify all relevant numerical values, entities, and relationships."
        )

        # Step 2: Extract structured facts from the passage using parallel exploration
        extract_tasks = [
            self.generate(instruction="List all numerical values mentioned in the passage with their associated context (e.g., player names, plays, scores).", context=analysis),
            self.generate(instruction="Identify all named entities that could be relevant to answering the question (e.g., teams, players, events).", context=analysis),
            self.generate(instruction="Extract all explicit answers or partial answers from the passage related to the question.", context=analysis)
        ]
        extracted_facts, entity_list, partial_answers = await asyncio.gather(*extract_tasks)

        # Step 3: Summarize the extracted information to reduce noise and focus on key elements
        summary = await self.summarize(
            context_to_summarize=f"Extracted Facts: {extracted_facts}\n\nEntities: {entity_list}\n\nPartial Answers: {partial_answers}"
        )

        # Step 4: Generate multiple candidate solutions based on different interpretations
        candidate_solutions = []
        if "how many" in analysis.lower() or "total" in analysis.lower():
            candidate_solutions.append(await self.generate(
                instruction="Generate a solution assuming this is a simple count or sum of values. Be precise about which numbers belong to which entities.",
                context=summary
            ))
            candidate_solutions.append(await self.generate(
                instruction="Generate a solution assuming this requires multi-hop inference — e.g., combining values across different parts of the text.",
                context=summary
            ))
        elif "difference" in analysis.lower() or "more" in analysis.lower():
            candidate_solutions.append(await self.generate(
                instruction="Generate a solution calculating the difference between two specific values identified in the passage.",
                context=summary
            ))
        elif "which" in analysis.lower():
            candidate_solutions.append(await self.generate(
                instruction="Generate a solution selecting the best answer based on comparative evidence in the passage.",
                context=summary
            ))
        else:
            candidate_solutions.append(await self.generate(
                instruction="Generate a solution focused on extracting the exact text span that answers the question.",
                context=summary
            ))

        # Step 5: Ensemble to select the most consistent and well-supported answer
        final_answer = await self.ensemble(
            instruction="Evaluate all candidate solutions and choose the one that best aligns with the question intent, passage evidence, and avoids contradictions.",
            contexts_to_ensemble=candidate_solutions
        )

        # Step 6: Optional refinement loop if confidence is low (based on internal analysis)
        if "uncertain" in final_answer.lower() or "multiple" in final_answer.lower():
            refined_answer = await self.revise(
                instruction="Refine the answer by resolving ambiguity, checking for missing associations, and ensuring the correct number is tied to the right entity.",
                context_to_revise=final_answer
            )
            return refined_answer

        return final_answer