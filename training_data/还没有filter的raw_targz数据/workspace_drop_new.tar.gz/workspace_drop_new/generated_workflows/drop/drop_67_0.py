# Workflow ID: drop_67_0
# Benchmark: drop
# Data Indices: [256, 213]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to detect question type and key entities
        analysis = await self.generate(
            instruction="Analyze the passage and question to determine the required reasoning type (e.g., arithmetic, counting, comparison, span extraction). Also identify all relevant named entities, numbers, and events."
        )

        # Step 2: Extract structured facts in parallel — spans, numbers, and event types
        extract_spans_task = self.generate(
            instruction="Extract all text spans that refer to players, teams, or locations mentioned in the passage."
        )
        extract_numbers_task = self.generate(
            instruction="Extract all numerical values from the passage along with their associated context (e.g., yardage, score, time)."
        )
        extract_events_task = self.generate(
            instruction="Identify all key events described in the passage (e.g., touchdowns, field goals, runs), noting who performed them and under what conditions."
        )

        spans, numbers, events = await asyncio.gather(extract_spans_task, extract_numbers_task, extract_events_task)

        # Step 3: Use the question to guide reasoning path
        question_intent = await self.generate(
            instruction="Based on the original question, determine whether it requires counting, arithmetic, comparison, or span-based extraction. Then generate a step-by-step plan using the extracted data.",
            context=analysis + "\n\n" + spans + "\n\n" + numbers + "\n\n" + events
        )

        # Step 4: Generate candidate solutions based on different interpretations
        if "how many" in question_intent.lower() or "count" in question_intent.lower():
            solution_1 = await self.generate(
                instruction="Generate a solution assuming the question asks for total occurrences of a specific entity (e.g., all field goals by Matt Stover).",
                context=numbers + "\n\n" + events
            )
            solution_2 = await self.generate(
                instruction="Generate a solution assuming the question asks for individual instances (e.g., list each field goal separately).",
                context=numbers + "\n\n" + events
            )
            final_solution = await self.ensemble(
                instruction="Choose the most accurate answer based on the question intent and evidence. If multiple valid answers exist, explain why.",
                contexts_to_ensemble=[solution_1, solution_2]
            )
        elif "which" in question_intent.lower() or "who" in question_intent.lower():
            solution_1 = await self.generate(
                instruction="Generate a solution focusing on identifying the correct entity based on explicit mention in the passage.",
                context=spans + "\n\n" + events
            )
            solution_2 = await self.generate(
                instruction="Generate a solution focusing on resolving ambiguous references using contextual clues.",
                context=analysis + "\n\n" + spans + "\n\n" + events
            )
            final_solution = await self.ensemble(
                instruction="Select the best-supported answer among the candidates, prioritizing clarity and alignment with the question.",
                contexts_to_ensemble=[solution_1, solution_2]
            )
        else:
            # Default case: general reasoning
            final_solution = await self.generate(
                instruction="Using all extracted information, generate a precise and concise answer to the question.",
                context=analysis + "\n\n" + spans + "\n\n" + numbers + "\n\n" + events
            )

        # Step 5: Revise for accuracy and completeness
        revised_answer = await self.revise(
            instruction="Review the final solution carefully. Check for missing entities, incorrect associations between numbers and events, and logical consistency with the passage.",
            context_to_revise=final_solution
        )

        return revised_answer