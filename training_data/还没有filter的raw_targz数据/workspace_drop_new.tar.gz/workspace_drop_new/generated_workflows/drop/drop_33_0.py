# Workflow ID: drop_33_0
# Benchmark: drop
# Data Indices: [31, 179]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question type and passage structure
        analysis = await self.generate(
            instruction="Analyze the passage and question to determine the required reasoning type (e.g., counting, arithmetic, comparison, span extraction). Also identify key entities and numerical values mentioned."
        )

        # Step 2: Extract structured data — focus on relevant entities and numbers
        extraction = await self.generate(
            instruction="Extract all relevant numerical values and their associated entities from the passage. Format as bullet points: 'Entity: Value' (e.g., 'Shaun Suisham: 27-yard field goal'). Only include items that could be relevant to the question.",
            context=analysis
        )

        # Step 3: Parallel exploration of multiple solution strategies
        task1 = self.generate(
            instruction="Based on the extracted data, generate a step-by-step plan to solve the question using explicit matching and filtering.",
            context=extraction
        )
        task2 = self.generate(
            instruction="Generate an alternative solution path that involves identifying implicit relationships or multi-hop inferences from the passage.",
            context=extraction
        )
        task3 = self.generate(
            instruction="Create a solution by first summarizing the passage into key events and then mapping each event to the question's requirements.",
            context=analysis
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble to select the most consistent answer across approaches
        final_answer = await self.ensemble(
            instruction="Evaluate the three candidate solutions. Choose the one that best aligns with the question intent and has the strongest evidence from the passage. If there is disagreement, pick the one supported by the clearest evidence.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional refinement if the answer seems ambiguous or incomplete
        if "multiple" in final_answer.lower() or "ambiguous" in final_answer.lower():
            refined_answer = await self.revise(
                instruction="Revise the answer to clarify ambiguity or ensure it fully addresses the question. Be precise about what was counted or compared.",
                context_to_revise=final_answer
            )
            return refined_answer

        return final_answer