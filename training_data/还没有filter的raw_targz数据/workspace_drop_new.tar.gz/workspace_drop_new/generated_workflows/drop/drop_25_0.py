# Workflow ID: drop_25_0
# Benchmark: drop
# Data Indices: [182, 95]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand question type and extract key entities
        analysis = await self.generate(
            instruction="Analyze the question to determine its type (e.g., span extraction, count, comparison). Also identify all named entities mentioned in the passage that could be relevant to the answer."
        )

        # Step 2: Extract Relevant Information — Build structured facts from passage
        extraction = await self.generate(
            instruction="Extract all relevant facts from the passage that relate to the identified entities and question type. Format as bullet points with clear entity-number or entity-event associations.",
            context=analysis
        )

        # Step 3: Parallel Hypothesis Generation — Generate multiple candidate answers based on different interpretations
        task1 = self.generate(
            instruction="Based on the extracted facts, generate one possible answer by focusing on explicit mentions only.",
            context=extraction
        )
        task2 = self.generate(
            instruction="Now generate an alternative candidate answer by considering implicit reasoning or multi-hop inference from the passage.",
            context=extraction
        )
        task3 = self.generate(
            instruction="Generate a third candidate answer using comparative or contextual clues (e.g., 'which was more...', 'who had the longest...').",
            context=extraction
        )

        # Execute in parallel for efficiency
        candidates = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Decision — Select best-supported answer
        final_answer = await self.ensemble(
            instruction="Compare the three candidate answers. Choose the one most directly supported by evidence in the passage. If there's ambiguity, select the one with strongest logical grounding.",
            contexts_to_ensemble=candidates
        )

        # Step 5: Optional Refinement — Revise if needed to improve clarity or correctness
        revised_answer = await self.revise(
            instruction="Critically evaluate the final answer. If it lacks specificity, missing key evidence, or contains ambiguity, revise it to be precise and grounded in the passage.",
            context_to_revise=final_answer
        )

        return revised_answer