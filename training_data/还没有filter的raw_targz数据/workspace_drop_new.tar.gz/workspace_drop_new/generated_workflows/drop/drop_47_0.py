# Workflow ID: drop_47_0
# Benchmark: drop
# Data Indices: [230, 229]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand question intent and passage structure
        analysis = await self.generate(
            instruction="Analyze the question to determine the type of reasoning required (e.g., arithmetic, counting, comparison, span extraction). Also identify key entities and numerical values in the passage."
        )

        # Step 2: Extract Relevant Facts — Isolate all numerically relevant data
        extracted_facts = await self.generate(
            instruction="Extract all explicit numerical values from the passage along with their associated entities or contexts (e.g., '35,853 CZK' → 'average salary in Prague', '120,000 commuters' → 'commuters in Prague').",
            context=analysis
        )

        # Step 3: Generate Multiple Solutions via Parallel Exploration
        task1 = self.generate(
            instruction="Generate a solution based on direct numerical extraction and basic arithmetic.",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Generate an alternative solution focusing on identifying implicit comparisons or differences between entities mentioned in the passage.",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Generate a third solution that considers potential ambiguities in references (e.g., pronouns, partial names) and resolves them using coreference resolution techniques.",
            context=extracted_facts
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer — Synthesize best-supported solution
        final_answer = await self.ensemble(
            instruction="Select the most accurate answer by comparing all three candidate solutions. If there's disagreement, choose the one supported by the clearest evidence from the passage.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional Refinement — Use revise if confidence is low
        refined_answer = await self.revise(
            instruction="Review the final answer for clarity, correctness, and alignment with the original question. If necessary, correct any misinterpretations or missing steps.",
            context_to_revise=final_answer
        )

        return refined_answer