# Workflow ID: drop_126_0
# Benchmark: drop
# Data Indices: [190, 270]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question intent and passage structure
        analysis = await self.generate(
            instruction="Analyze the question and passage to determine what type of reasoning is required (e.g., extraction, arithmetic, comparison). Identify key entities and numerical values relevant to the question."
        )

        # Step 2: Extract all candidate information (text spans, numbers, dates, etc.)
        extraction = await self.generate(
            instruction="Extract all potentially relevant facts from the passage that could answer the question. Focus on entities, quantities, and relationships mentioned.",
            context=analysis
        )

        # Step 3: Summarize extracted facts to reduce noise and highlight candidates
        summarized_facts = await self.summarize(extraction)

        # Step 4: Generate multiple solution paths in parallel — one per likely interpretation
        task1 = self.generate(
            instruction="Based on the summarized facts, generate a solution assuming the question asks for the longest field goal.",
            context=summarized_facts
        )
        task2 = self.generate(
            instruction="Generate an alternative solution based on the possibility that the question refers to the total number of field goals or their combined length.",
            context=summarized_facts
        )
        task3 = self.generate(
            instruction="Generate a third solution focusing on identifying any implicit or comparative reasoning needed (e.g., 'which was longer' implies comparison).",
            context=summarized_facts
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 5: Ensemble to select the best-supported answer among competing interpretations
        final_answer = await self.ensemble(
            instruction="Evaluate the three generated solutions and choose the one most strongly supported by the passage. If there's ambiguity, pick the most direct interpretation.",
            contexts_to_ensemble=solutions
        )

        # Step 6: Optional refinement if confidence is low — check for errors or missing info
        if "ambiguous" in final_answer.lower() or "not enough information" in final_answer.lower():
            refined = await self.revise(
                instruction="Review the original passage again and ensure no critical detail was missed. Refine the answer based on this re-check.",
                context_to_revise=final_answer
            )
            return refined

        return final_answer