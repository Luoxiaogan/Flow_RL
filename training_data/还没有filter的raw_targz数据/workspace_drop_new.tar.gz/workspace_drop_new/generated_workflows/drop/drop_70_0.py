# Workflow ID: drop_70_0
# Benchmark: drop
# Data Indices: [54, 284]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand question intent and key entities
        analysis = await self.generate(
            instruction="Analyze the question and passage to determine what type of reasoning is required (e.g., span extraction, counting, arithmetic). Also identify all named entities that might be relevant."
        )

        # Step 2: Extract Relevant Facts — Get structured information from passage
        facts = await self.generate(
            instruction="Extract all relevant factual statements from the passage that could help answer the question. Focus on events, scores, times, names, and quantities.",
            context=analysis
        )

        # Step 3: Parallel Exploration — Generate multiple candidate answers using different strategies
        task1 = self.generate(
            instruction="Based on the extracted facts, directly extract the answer if it's a simple span or count.",
            context=facts
        )
        task2 = self.generate(
            instruction="If the question involves comparison or calculation, compute the result step-by-step using the extracted facts.",
            context=facts
        )
        task3 = self.generate(
            instruction="If there are ambiguous references (pronouns, partial names), resolve them by mapping pronouns to full entity names based on context.",
            context=facts
        )

        candidates = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer — Synthesize the best solution from diverse approaches
        final_answer = await self.ensemble(
            instruction="Choose the most consistent and well-supported answer among the three candidates. If they differ, explain why one is preferred.",
            contexts_to_ensemble=candidates
        )

        # Step 5: Optional Refinement — Revise if uncertainty remains
        refined_answer = await self.revise(
            instruction="Review the final answer and ensure it correctly addresses the original question. Fix any logical flaws or missing steps.",
            context_to_revise=final_answer
        )

        return refined_answer