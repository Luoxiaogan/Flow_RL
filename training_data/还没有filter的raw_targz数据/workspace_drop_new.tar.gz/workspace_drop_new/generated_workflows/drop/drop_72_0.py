# Workflow ID: drop_72_0
# Benchmark: drop
# Data Indices: [260, 122]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question type and key entities
        analysis = await self.generate(
            instruction="Analyze the passage and question to determine the required reasoning type (e.g., comparison, counting, arithmetic) and identify all relevant named entities and numerical values."
        )

        # Step 2: Extract structured information from the passage
        extraction = await self.generate(
            instruction="Extract all explicit facts, dates, counts, and entity-value pairs relevant to answering the question. Format as bullet points.",
            context=analysis
        )

        # Step 3: Generate multiple candidate solutions using different strategies
        task1 = self.generate(
            instruction="Based on the extracted facts, generate a solution by directly applying the required operation (e.g., sum, difference, count).",
            context=extraction
        )
        task2 = self.generate(
            instruction="Generate an alternative solution by focusing on the comparative aspect of the question and identifying which entity has the higher value.",
            context=extraction
        )
        task3 = self.generate(
            instruction="Generate a solution that involves tracking entity references in the passage to resolve pronouns or ambiguous mentions.",
            context=extraction
        )

        # Step 4: Parallel exploration with diverse reasoning paths
        candidates = await asyncio.gather(task1, task2, task3)

        # Step 5: Ensemble to select the most consistent and well-supported answer
        final_answer = await self.ensemble(
            instruction="Select the best answer based on consistency across all candidate solutions and alignment with the original question's intent.",
            contexts_to_ensemble=candidates
        )

        # Step 6: Optional refinement if needed — check for clarity or ambiguity
        refined_answer = await self.revise(
            instruction="Review the final answer for clarity, correctness, and completeness. If uncertain, suggest improvements.",
            context_to_revise=final_answer
        )

        return refined_answer