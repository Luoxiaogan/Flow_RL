# Workflow ID: drop_81_0
# Benchmark: drop
# Data Indices: [92, 103]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand question intent and key entities
        analysis = await self.generate(
            instruction="Analyze the passage and question to identify the type of reasoning required (e.g., arithmetic, counting, comparison, span extraction) and locate all relevant numerical or temporal data."
        )

        # Step 2: Extract Key Facts — Identify all entities, numbers, and dates
        extraction = await self.generate(
            instruction="Extract all named entities, numerical values, and dates from the passage that could be relevant to answering the question. Present them in structured format: [Entity] - [Value].",
            context=analysis
        )

        # Step 3: Parallel Reasoning Paths — Generate multiple solution approaches
        task1 = self.generate(
            instruction="Generate a step-by-step solution assuming the question requires direct numerical computation (e.g., subtraction, addition).",
            context=extraction
        )
        task2 = self.generate(
            instruction="Generate a step-by-step solution focusing on entity-number association and resolving ambiguous references (pronouns, partial names).",
            context=extraction
        )
        task3 = self.generate(
            instruction="Generate a solution by identifying implicit information and logical connections between events in the passage.",
            context=extraction
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer — Compare and select best-supported answer
        final_answer = await self.ensemble(
            instruction="Evaluate the three candidate solutions. Choose the one that best aligns with the question intent, uses correct entity-number associations, and handles ambiguity appropriately.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional Refinement — Revise if uncertainty remains
        revised_answer = await self.revise(
            instruction="Critique the final answer for potential errors in calculation, misassociation of numbers, or missing contextual cues. Improve clarity and correctness if needed.",
            context_to_revise=final_answer
        )

        return revised_answer