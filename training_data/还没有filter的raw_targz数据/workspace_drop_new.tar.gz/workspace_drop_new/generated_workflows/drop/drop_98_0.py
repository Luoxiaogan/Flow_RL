# Workflow ID: drop_98_0
# Benchmark: drop
# Data Indices: [43, 262]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question type and key entities
        analysis = await self.generate(
            instruction="Analyze the question and passage to determine what kind of reasoning is required (e.g., span extraction, counting, arithmetic). Also identify all named entities that may be relevant to the answer."
        )

        # Step 2: Extract structured information from the passage
        extraction = await self.generate(
            instruction="Extract all relevant facts from the passage in structured format (e.g., 'Player: X scored a touchdown at time Y', 'Event: Z happened on date W'). Focus on entities mentioned in the question or implied by it.",
            context=analysis
        )

        # Step 3: Parallel exploration of possible interpretations
        task1 = self.generate(
            instruction="Based on the extracted facts, generate a candidate answer assuming the question asks for all instances of the target entity (e.g., all players who scored touchdowns).",
            context=extraction
        )
        task2 = self.generate(
            instruction="Now generate an alternative candidate answer focusing only on the first occurrence of the target entity mentioned in the passage.",
            context=extraction
        )
        task3 = self.generate(
            instruction="Generate another candidate answer assuming the question requires identifying unique entities (e.g., how many different players scored).",
            context=extraction
        )

        candidates = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble to select the most consistent and well-supported answer
        final_answer = await self.ensemble(
            instruction="Compare the three candidate answers and select the one that best aligns with the question intent, based on evidence from the passage. If there's ambiguity, choose the answer that covers all possible valid interpretations.",
            contexts_to_ensemble=candidates
        )

        # Step 5: Optional refinement if the answer seems incomplete or vague
        if "multiple" in final_answer.lower() or "all" in final_answer.lower():
            refined = await self.revise(
                instruction="The answer includes multiple items — ensure each item is explicitly named and correctly associated with its event in the passage.",
                context_to_revise=final_answer
            )
            return refined

        return final_answer