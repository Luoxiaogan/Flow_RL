# Workflow ID: drop_78_0
# Benchmark: drop
# Data Indices: [159, 244]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis - Understand the question type and key entities
        analysis = await self.generate(
            instruction="Analyze the question to determine if it requires counting, arithmetic, comparison, or span extraction. Identify all named entities and numerical references in the passage."
        )

        # Step 2: Extract Key Information - Isolate relevant facts from passage
        extraction = await self.generate(
            instruction="Extract all explicit numerical values and associated entities (e.g., dates, counts, names) that might be relevant to answering the question.",
            context=analysis
        )

        # Step 3: Parallel Exploration - Generate multiple candidate interpretations
        task1 = self.generate(
            instruction="Generate a step-by-step reasoning path assuming this is an arithmetic question (e.g., difference, sum).",
            context=extraction
        )
        task2 = self.generate(
            instruction="Generate a step-by-step reasoning path assuming this is a comparative question (e.g., which group is larger).",
            context=extraction
        )
        task3 = self.generate(
            instruction="Generate a step-by-step reasoning path assuming this is a counting or entity-tracking question.",
            context=extraction
        )
        candidates = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble - Select best solution based on coherence and evidence
        final_answer = await self.ensemble(
            instruction="Evaluate the three candidate solutions. Choose the one most consistent with the passage and directly addresses the question intent.",
            contexts_to_ensemble=candidates
        )

        # Step 5: Revise for Precision - Check for logical consistency and ambiguity resolution
        refined_answer = await self.revise(
            instruction="Review the final answer for clarity, correctness, and whether it resolves all ambiguities (like pronoun references or multiple similar entities). If unclear, revise to clarify.",
            context_to_revise=final_answer
        )

        return refined_answer