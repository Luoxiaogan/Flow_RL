# Workflow ID: drop_125_0
# Benchmark: drop
# Data Indices: [18, 224]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis – Understand the question type and key entities
        analysis = await self.generate(
            instruction="Analyze the question to determine the required reasoning type (e.g., counting, arithmetic, comparison, span extraction) and identify key entities or numbers mentioned."
        )

        # Step 2: Parallel Extraction – Extract all relevant facts from passage
        extract_tasks = [
            self.generate(instruction="List all numerical values mentioned in the passage with their associated context (e.g., player name, event)."),
            self.generate(instruction="Identify all named entities (people, teams, events) that may be relevant to answering the question."),
            self.generate(instruction="Extract all instances of the specific event or action referenced in the question (e.g., 'touchdown passes', 'speakers').")
        ]
        extracted_facts, entities, event_instances = await asyncio.gather(*extract_tasks)

        # Step 3: Contextual Reasoning – Generate candidate solutions based on different perspectives
        reasoning_tasks = [
            self.generate(
                instruction="Based on the extracted facts, generate a solution assuming the answer requires summing all instances of the target event.",
                context=extracted_facts + "\n" + event_instances
            ),
            self.generate(
                instruction="Based on the extracted facts, generate a solution assuming the answer requires identifying a single instance or comparing two values.",
                context=extracted_facts + "\n" + entities
            ),
            self.generate(
                instruction="Based on the extracted facts, generate a solution assuming the answer requires identifying a specific entity or phrase (span extraction).",
                context=extracted_facts + "\n" + event_instances
            )
        ]
        sol1, sol2, sol3 = await asyncio.gather(*reasoning_tasks)

        # Step 4: Ensemble – Synthesize multiple candidate solutions into a final answer
        final_answer = await self.ensemble(
            instruction="Choose the most consistent and accurate answer among the three candidates based on relevance to the original question and internal consistency.",
            contexts_to_ensemble=[sol1, sol2, sol3]
        )

        # Step 5: Refinement – Revise final answer if needed based on potential errors
        revised_answer = await self.revise(
            instruction="Check whether the final answer makes logical sense given the original question and passage. If not, revise it accordingly.",
            context_to_revise=final_answer
        )

        return revised_answer