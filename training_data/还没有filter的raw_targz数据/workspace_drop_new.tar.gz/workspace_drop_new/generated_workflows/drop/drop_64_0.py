# Workflow ID: drop_64_0
# Benchmark: drop
# Data Indices: [76, 221]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis – Understand the question type and passage structure
        analysis = await self.generate(
            instruction="Analyze the question and passage to identify the required reasoning type (e.g., comparison, counting, arithmetic, span extraction). Also identify key entities, numbers, and temporal markers."
        )

        # Step 2: Extract Structured Facts – Pull out all relevant numerical and entity data
        extracted_facts = await self.generate(
            instruction="Extract all named entities, associated values, and temporal sequences from the passage. Format as a list of key-value pairs or sentences for clarity.",
            context=analysis
        )

        # Step 3: Parallel Hypothesis Generation – Generate multiple candidate interpretations
        task1 = self.generate("Generate one possible interpretation of the question based on the extracted facts.")
        task2 = self.generate("Generate an alternative interpretation that might lead to a different answer.")
        task3 = self.generate("Generate a third interpretation considering implicit information in the passage.")

        hypotheses = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble – Synthesize best-supported interpretation
        ensemble_result = await self.ensemble(
            instruction="Evaluate the three interpretations against the extracted facts. Select the one that best explains the question and matches the evidence.",
            contexts_to_ensemble=hypotheses
        )

        # Step 5: Refine Solution – Use revise to improve clarity, correctness, and completeness
        refined_solution = await self.revise(
            instruction="Improve the solution by ensuring it clearly addresses the question, includes necessary reasoning steps, and avoids ambiguity or missing information.",
            context_to_revise=ensemble_result
        )

        # Step 6: Final Validation – Check if the solution aligns with both explicit and implicit context
        final_answer = await self.generate(
            instruction="Based on the refined solution, provide the final answer directly, without explanation. Only return the answer itself.",
            context=refined_solution
        )

        return final_answer