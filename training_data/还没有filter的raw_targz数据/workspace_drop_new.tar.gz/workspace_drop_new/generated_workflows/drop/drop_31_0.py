# Workflow ID: drop_31_0
# Benchmark: drop
# Data Indices: [28, 87]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand the problem type and key elements
        analysis = await self.generate(
            instruction="Analyze the question and passage to identify the required reasoning type (e.g., counting, comparison, span extraction) and relevant entities."
        )

        # Step 2: Extract structured facts from the passage using multiple parallel strategies
        task1 = self.generate(instruction="Extract all named entities mentioned in the passage with their associated values or attributes.")
        task2 = self.generate(instruction="Identify all numerical data points in the passage along with their context (e.g., dates, counts, scores).")
        task3 = self.generate(instruction="List all temporal references (dates, years, time periods) and their associated events.")

        extracted_facts = await asyncio.gather(task1, task2, task3)

        # Step 3: Summarize the extracted information for clarity and focus
        summarized_facts = await self.summarize(context_to_summarize="\n".join(extracted_facts))

        # Step 4: Generate candidate solutions based on different interpretations or approaches
        if "how many" in analysis.lower() or "count" in analysis.lower():
            solution1 = await self.generate(
                instruction="Based on the summarized facts, count all instances matching the criteria in the question.",
                context=summarized_facts
            )
            solution2 = await self.generate(
                instruction="Re-evaluate the same count by focusing only on explicit mentions and ignoring inferred ones.",
                context=summarized_facts
            )
            final_answer = await self.ensemble(
                instruction="Choose the most accurate count based on consistency with the passage and clarity of evidence.",
                contexts_to_ensemble=[solution1, solution2]
            )
        elif "which" in analysis.lower() and ("more" in analysis.lower() or "greater" in analysis.lower()):
            solution1 = await self.generate(
                instruction="Compare the two entities mentioned in the question using the summarized facts.",
                context=summarized_facts
            )
            solution2 = await self.generate(
                instruction="Identify which entity has more occurrences or higher value based on the structured facts.",
                context=summarized_facts
            )
            final_answer = await self.ensemble(
                instruction="Select the correct answer between the two candidates based on strongest supporting evidence.",
                contexts_to_ensemble=[solution1, solution2]
            )
        elif "who" in analysis.lower() or "what was the name of" in analysis.lower():
            solution1 = await self.generate(
                instruction="Extract the exact text span that answers the question about who/what.",
                context=summarized_facts
            )
            solution2 = await self.generate(
                instruction="Use coreference resolution to resolve pronouns or partial names and find the correct entity.",
                context=summarized_facts
            )
            final_answer = await self.ensemble(
                instruction="Determine the best match between the direct span and the resolved reference.",
                contexts_to_ensemble=[solution1, solution2]
            )
        else:
            # Default fallback: generate a general solution
            final_answer = await self.generate(
                instruction="Provide a concise answer based on the summarized facts and the original question.",
                context=summarized_facts
            )

        # Step 5: Optional refinement loop for high-confidence accuracy
        refined_answer = await self.revise(
            instruction="Check for logical consistency, completeness, and correctness of the final answer against the passage.",
            context_to_revise=final_answer
        )

        return refined_answer