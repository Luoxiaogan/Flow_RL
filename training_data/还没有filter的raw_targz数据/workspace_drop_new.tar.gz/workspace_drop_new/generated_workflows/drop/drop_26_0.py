# Workflow ID: drop_26_0
# Benchmark: drop
# Data Indices: [137, 84]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question intent and extract key entities
        analysis = await self.generate(
            instruction="Analyze the passage and question to determine the type of reasoning required (e.g., selection, comparison, counting) and identify all relevant entities mentioned."
        )

        # Step 2: Extract structured facts from the passage using multiple parallel approaches
        task1 = self.generate(
            instruction="Extract all named entities (teams, people, events) and their associated attributes (scores, actions, dates)."
        )
        task2 = self.generate(
            instruction="Identify all numerical values in the passage and map them to the entities they describe."
        )
        task3 = self.generate(
            instruction="List all key events or outcomes that could lead to determining the answer."
        )
        extracted_facts = await asyncio.gather(task1, task2, task3)

        # Step 3: Summarize the extracted facts to reduce noise and focus on relevant data
        summarized_facts = await self.summarize(context_to_summarize="\n\n".join(extracted_facts))

        # Step 4: Generate candidate solutions based on different reasoning paths
        solution1 = await self.generate(
            instruction="Based on the summarized facts, generate a direct answer by identifying the entity that matches the question's criteria.",
            context=summarized_facts
        )
        solution2 = await self.generate(
            instruction="Generate an alternative interpretation of the question — e.g., if it asks 'who lost', consider whether this means 'which side was defeated' or 'which team had fewer wins'.",
            context=summarized_facts
        )
        solution3 = await self.generate(
            instruction="Generate a hypothesis about the outcome by analyzing cause-effect chains in the passage (e.g., which team suffered losses, fumbles, or failed comebacks).",
            context=summarized_facts
        )

        # Step 5: Ensemble the three candidate answers to select the most consistent one
        final_answer = await self.ensemble(
            instruction="Evaluate the three candidate answers and select the one that best aligns with the passage evidence and question intent.",
            contexts_to_ensemble=[solution1, solution2, solution3]
        )

        # Step 6: Optional refinement loop for high-stakes accuracy
        # If the ensemble output seems uncertain or vague, revise once more
        if "likely" in final_answer.lower() or "possibly" in final_answer.lower():
            final_answer = await self.revise(
                instruction="Refine the answer to be more precise and grounded in explicit evidence from the passage.",
                context_to_revise=final_answer
            )

        return final_answer