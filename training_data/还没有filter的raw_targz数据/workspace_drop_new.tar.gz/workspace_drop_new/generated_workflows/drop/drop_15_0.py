# Workflow ID: drop_15_0
# Benchmark: drop
# Data Indices: [80, 23]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question type and passage structure
        analysis = await self.generate(
            instruction="Analyze the question and passage to determine the required reasoning type (e.g., comparison, counting, span extraction). Also identify key entities and numerical values."
        )

        # Step 2: Extract structured facts from the passage using parallel exploration
        extract_tasks = [
            self.generate(instruction="Extract all named entities mentioned in the passage."),
            self.generate(instruction="Extract all numerical values and their associated contexts (e.g., scores, dates, counts)."),
            self.generate(instruction="Extract all events or actions involving specific entities.")
        ]
        extracted_facts = await asyncio.gather(*extract_tasks)

        # Step 3: Summarize extracted facts for clarity and context management
        summarized_facts = await self.summarize(context_to_summarize="\n".join(extracted_facts))

        # Step 4: Generate candidate solutions based on different reasoning strategies
        if "which" in analysis.lower() and "more" not in analysis.lower():
            # Likely a selection or entity identification task
            candidates = [
                await self.generate(
                    instruction="Based on the passage, determine which entity matches the criteria in the question.",
                    context=summarized_facts
                )
            ]
        elif "how many" in analysis.lower() or "difference" in analysis.lower():
            # Likely arithmetic or counting
            candidates = [
                await self.generate(
                    instruction="Identify all relevant numbers and perform the required calculation (sum, difference, count) based on the question intent.",
                    context=summarized_facts
                ),
                await self.generate(
                    instruction="List all instances of the entity mentioned in the question and count them explicitly.",
                    context=summarized_facts
                )
            ]
        else:
            # General case — generate multiple plausible interpretations
            candidates = [
                await self.generate(
                    instruction="Generate one possible answer by focusing on explicit mentions in the passage.",
                    context=summarized_facts
                ),
                await self.generate(
                    instruction="Generate an alternative answer considering implicit references or comparisons in the passage.",
                    context=summarized_facts
                ),
                await self.generate(
                    instruction="Generate a third possible interpretation that might involve multi-hop inference.",
                    context=summarized_facts
                )
            ]

        # Step 5: Ensemble to select the most robust solution
        final_answer = await self.ensemble(
            instruction="Evaluate the three candidate answers and choose the one best supported by evidence from the passage.",
            contexts_to_ensemble=candidates
        )

        # Step 6: Optional refinement loop for high-stakes accuracy
        if "comparison" in analysis.lower() or "difference" in analysis.lower():
            refined_answer = await self.revise(
                instruction="Critique the final answer for logical consistency with the passage. If there's ambiguity, refine it.",
                context_to_revise=final_answer
            )
            return refined_answer

        return final_answer