# Workflow ID: drop_117_0
# Benchmark: drop
# Data Indices: [39, 206]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand question type and key entities
        analysis = await self.generate(
            instruction="Analyze the passage and question to determine the required reasoning type (e.g., arithmetic, comparison, span extraction) and identify all relevant named entities or numerical values."
        )

        # Step 2: Extract Structured Facts — Convert dense text into usable data
        extracted_facts = await self.generate(
            instruction="Extract all key facts from the passage in structured format (e.g., 'Date: X, Event: Y, Value: Z'). Focus on entities mentioned in the question and their associated values.",
            context=analysis
        )

        # Step 3: Parallel Exploration — Generate multiple solution paths based on different interpretations
        task1 = self.generate(
            instruction="Based on the extracted facts, generate a direct answer using explicit information only.",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Now, consider implicit relationships or multi-hop inference needed to resolve ambiguous references in the question.",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Generate an answer by focusing strictly on the exact wording of the question—what is being asked directly?",
            context=extracted_facts
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer — Synthesize competing perspectives
        final_answer = await self.ensemble(
            instruction="Select the most accurate and consistent answer from the three generated solutions. If there's disagreement, choose the one supported by the clearest evidence.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Revise for Precision — Self-correct if needed
        refined_answer = await self.revise(
            instruction="Critique the final answer for clarity, correctness, and alignment with the original question. Fix any ambiguity or error.",
            context_to_revise=final_answer
        )

        return refined_answer