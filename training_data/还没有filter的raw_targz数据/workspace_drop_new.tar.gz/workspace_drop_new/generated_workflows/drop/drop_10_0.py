# Workflow ID: drop_10_0
# Benchmark: drop
# Data Indices: [222, 232]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question intent and key entities
        analysis = await self.generate(
            instruction="Analyze the passage and question. Identify the type of reasoning required (e.g., arithmetic, comparison, extraction). Also identify all relevant numerical values and their associated entities."
        )

        # Step 2: Extract structured facts in parallel — this helps handle ambiguity and multiple similar entities
        extract_task_1 = self.generate(
            instruction="Extract all numerical values from the passage along with their context (e.g., '18.30% had children under 18', 'average household size was 2.13')."
        )
        extract_task_2 = self.generate(
            instruction="Identify all named entities or groups mentioned in the passage that may be relevant to answering the question (e.g., 'average family size', 'average household size')."
        )
        extract_results = await asyncio.gather(extract_task_1, extract_task_2)

        # Step 3: Use extracted data to generate candidate solutions
        candidates = []
        for i, extract in enumerate(extract_results):
            if "numerical" in extract.lower():
                candidate = await self.generate(
                    instruction="Based on the extracted numerical data, generate a solution to the question. Be explicit about which numbers you used and why.",
                    context=extract
                )
                candidates.append(candidate)
            elif "entity" in extract.lower():
                candidate = await self.generate(
                    instruction="Based on the extracted entity list, generate a solution to the question by identifying which group or value is being compared or asked about.",
                    context=extract
                )
                candidates.append(candidate)

        # Step 4: Ensemble the candidates to resolve ambiguity or inconsistency
        final_answer = await self.ensemble(
            instruction="Compare the following candidate solutions. Select the one that best answers the original question based on clarity, consistency with the passage, and correctness of reasoning.",
            contexts_to_ensemble=candidates
        )

        # Step 5: Revise for precision if needed — especially important for comparative or numeric answers
        revised_answer = await self.revise(
            instruction="Critique the final answer. If it's ambiguous, incomplete, or potentially incorrect, improve it. Focus on ensuring it directly addresses the question and uses only information from the passage.",
            context_to_revise=final_answer
        )

        return revised_answer