# Workflow ID: drop_11_0
# Benchmark: drop
# Data Indices: [139, 58]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis - Understand question intent and key entities
        analysis = await self.generate(
            instruction="Analyze the question and passage to identify the core task (e.g., count, calculate, compare, extract), relevant entities, and any implicit reasoning needed."
        )

        # Step 2: Extract Structured Facts - Pull all relevant numerical and entity data
        extraction = await self.generate(
            instruction="Extract all explicit numerical values and associated entities from the passage that might be relevant to answering the question. Format as structured list: [entity, value].",
            context=analysis
        )

        # Step 3: Parallel Hypothesis Generation - Generate multiple solution paths based on interpretation
        task1 = self.generate(
            instruction="Generate a solution assuming the question requires counting specific events.",
            context=extraction
        )
        task2 = self.generate(
            instruction="Generate a solution assuming the question involves arithmetic operations (sum, difference).",
            context=extraction
        )
        task3 = self.generate(
            instruction="Generate a solution assuming the question requires identifying the best or worst instance among candidates.",
            context=extraction
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer - Synthesize competing solutions using strategic instruction
        final_answer = await self.ensemble(
            instruction="Select the most consistent and accurate answer from the three candidate solutions. If there's disagreement, explain why one is more likely correct based on the passage.",
            contexts_to_ensemble=solutions
        )

        return final_answer