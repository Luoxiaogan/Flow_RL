# Workflow ID: drop_145_0
# Benchmark: drop
# Data Indices: [150, 277]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to detect question type and key entities
        analysis = await self.generate(
            instruction="Analyze the question and passage to determine the required reasoning type (e.g., arithmetic, counting, comparison, span extraction) and identify all relevant entities or numbers mentioned."
        )

        # Step 2: Extract structured data from passage using parallel exploration
        extract_task_1 = self.generate(
            instruction="Extract all numerical values and their associated entities from the passage, focusing on those likely relevant to the question."
        )
        extract_task_2 = self.generate(
            instruction="Identify all named entities (people, teams, dates, locations) that may be involved in answering the question."
        )
        extract_task_3 = self.generate(
            instruction="List all comparative phrases or keywords in the question (e.g., 'more than', 'difference', 'how many') to guide interpretation."
        )
        extracted_data = await asyncio.gather(extract_task_1, extract_task_2, extract_task_3)

        # Step 3: Summarize the extracted information to reduce noise
        summarized_data = await self.summarize(context_to_summarize="\n".join(extracted_data))

        # Step 4: Generate multiple candidate solutions based on different interpretations
        solution_1 = await self.generate(
            instruction="Based on the summarized data, generate a solution assuming the question asks for a simple count.",
            context=summarized_data
        )
        solution_2 = await self.generate(
            instruction="Generate an alternative solution assuming the question involves subtraction or difference calculation.",
            context=summarized_data
        )
        solution_3 = await self.generate(
            instruction="Generate another solution assuming the question requires identifying a specific entity (span extraction).",
            context=summarized_data
        )

        # Step 5: Ensemble the three candidates to select the most plausible answer
        final_answer = await self.ensemble(
            instruction="Compare the three proposed answers. Choose the one best supported by the passage and most aligned with the question's intent.",
            contexts_to_ensemble=[solution_1, solution_2, solution_3]
        )

        # Step 6: Optional refinement if the ensemble result seems ambiguous
        if "ambiguous" in final_answer.lower() or "uncertain" in final_answer.lower():
            refined_answer = await self.revise(
                instruction="Refine the answer by re-evaluating the original passage and ensuring correct association between numbers and entities.",
                context_to_revise=final_answer
            )
            return refined_answer

        return final_answer