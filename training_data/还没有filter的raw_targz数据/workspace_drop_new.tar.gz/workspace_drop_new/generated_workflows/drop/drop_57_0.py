# Workflow ID: drop_57_0
# Benchmark: drop
# Data Indices: [251, 235]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Analyze the question to determine required reasoning type
        analysis = await self.generate(
            instruction="Analyze the question and identify the type of reasoning needed (e.g., entity extraction, comparison, counting, arithmetic). Also note key entities and numbers mentioned."
        )

        # Step 2: Extract structured facts from passage relevant to the question
        extracted_facts = await self.generate(
            instruction="Extract all relevant facts from the passage that pertain to the question. Include numerical values, names, events, and relationships between entities.",
            context=analysis
        )

        # Step 3: Use parallel exploration to generate multiple solution paths
        task1 = self.generate(
            instruction="Generate a direct answer based on the extracted facts, focusing on exact matches or spans.",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Generate an answer by first summarizing the passage, then identifying the correct entity or value based on context clues and pronoun resolution.",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Generate an answer by analyzing the question's intent (e.g., count vs. select vs. compare) and applying that logic to the extracted facts.",
            context=extracted_facts
        )

        # Execute in parallel
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble the competing solutions to resolve ambiguity
        final_answer = await self.ensemble(
            instruction="Choose the best answer among the three candidates. If they conflict, prioritize clarity, consistency with the passage, and alignment with the question's intent.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional refinement if confidence is low — detect via analysis
        if "uncertain" in final_answer.lower() or "multiple" in final_answer.lower():
            refined_answer = await self.revise(
                instruction="Revise the answer to be more precise. Focus on resolving any ambiguity or missing link in the chain of reasoning.",
                context_to_revise=final_answer
            )
            return refined_answer

        return final_answer