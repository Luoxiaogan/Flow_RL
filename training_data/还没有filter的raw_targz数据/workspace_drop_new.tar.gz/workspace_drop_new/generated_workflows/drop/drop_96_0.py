# Workflow ID: drop_96_0
# Benchmark: drop
# Data Indices: [254, 294]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Analyze question type and extract key entities
        analysis = await self.generate(
            instruction="Identify the core question type (e.g., counting, arithmetic, comparison, span extraction) and list all relevant entities mentioned in the passage that might relate to the answer."
        )

        # Step 2: Extract structured facts from passage
        extraction = await self.generate(
            instruction="Extract all numerical values and their associated entities from the passage. Format as: 'Entity: Value' pairs.",
            context=analysis
        )

        # Step 3: Generate multiple candidate solutions based on different interpretations
        task1 = self.generate(
            instruction="Based on the extracted facts, generate a solution assuming the question requires summing all instances of a category (e.g., total units).",
            context=extraction
        )
        task2 = self.generate(
            instruction="Generate a solution assuming the question asks for a specific instance (e.g., only one occurrence matches the condition).",
            context=extraction
        )
        task3 = self.generate(
            instruction="Generate a solution assuming the question involves a comparison or difference between two values.",
            context=extraction
        )

        # Run parallel exploration
        candidates = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble to select best solution
        final_answer = await self.ensemble(
            instruction="Select the most accurate answer among the three candidates. Consider which interpretation best aligns with the original question's intent.",
            contexts_to_ensemble=candidates
        )

        # Step 5: Revise if needed — check for consistency with passage
        revised_answer = await self.revise(
            instruction="Review the final answer against the passage to ensure it logically follows from the data and resolves any ambiguous references.",
            context_to_revise=final_answer
        )

        return revised_answer