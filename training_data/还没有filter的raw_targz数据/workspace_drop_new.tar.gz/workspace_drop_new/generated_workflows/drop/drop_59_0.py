# Workflow ID: drop_59_0
# Benchmark: drop
# Data Indices: [273, 239]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand question type and key entities
        analysis = await self.generate(
            instruction="Analyze the question to determine what kind of answer is expected (e.g., list of people, number, date). Identify all named entities mentioned in the passage that might be relevant."
        )

        # Step 2: Extract Relevant Information — Pull out all potential candidates
        extraction = await self.generate(
            instruction="Extract all relevant events from the passage where players scored points (touchdowns, field goals, safeties). For each, record the player name and scoring type.",
            context=analysis
        )

        # Step 3: Parallel Exploration — Generate multiple interpretations or hypotheses
        task1 = self.generate(
            instruction="List all players who scored field goals based on the extracted data.",
            context=extraction
        )
        task2 = self.generate(
            instruction="List all players who scored touchdowns based on the extracted data.",
            context=extraction
        )
        task3 = self.generate(
            instruction="List all players who scored safeties based on the extracted data.",
            context=extraction
        )
        results = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble — Synthesize the different perspectives
        ensemble_result = await self.ensemble(
            instruction="Based on the three candidate answers, identify which one(s) directly match the question's intent. If the question asks for specific types (like 'field goals'), prioritize those.",
            contexts_to_ensemble=results
        )

        # Step 5: Refinement — Revise if needed to ensure correctness
        final_answer = await self.revise(
            instruction="Review the ensemble result carefully. Ensure it correctly answers the original question by checking against the passage context. Remove any ambiguous or incorrect references.",
            context_to_revise=ensemble_result
        )

        return final_answer