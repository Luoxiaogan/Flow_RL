# Workflow ID: drop_129_0
# Benchmark: drop
# Data Indices: [15, 193]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question type and passage structure
        analysis = await self.generate(
            instruction="Analyze the passage and question to determine required reasoning type (e.g., comparison, counting, extraction, arithmetic). Also identify key entities and numerical values relevant to the answer."
        )

        # Step 2: Extract structured information from the passage
        extraction = await self.generate(
            instruction="Extract all relevant facts from the passage in a structured format: list each entity with its associated value or attribute. Include both explicit and implicit information.",
            context=analysis
        )

        # Step 3: Generate multiple solution paths based on different interpretations
        path1 = self.generate(
            instruction="Generate a solution assuming the question requires direct extraction of the answer from the extracted facts.",
            context=extraction
        )
        path2 = self.generate(
            instruction="Generate a solution assuming the question requires multi-hop inference or combining multiple pieces of evidence from the extracted facts.",
            context=extraction
        )
        path3 = self.generate(
            instruction="Generate a solution assuming the question involves numerical operations like subtraction, comparison, or ratio between two values.",
            context=extraction
        )

        # Step 4: Parallel exploration → Ensemble the best candidate solutions
        candidates = [path1, path2, path3]
        ensemble_result = await self.ensemble(
            instruction="Select the most accurate and coherent solution among these three approaches based on consistency with the passage and logical soundness.",
            contexts_to_ensemble=candidates
        )

        # Step 5: Optional refinement if the ensemble result seems uncertain
        if "ambiguous" in ensemble_result.lower() or "not clear" in ensemble_result.lower():
            refined = await self.revise(
                instruction="Revise the solution to resolve ambiguity by re-examining the original passage and focusing only on the exact question asked.",
                context_to_revise=ensemble_result
            )
            return refined

        return ensemble_result