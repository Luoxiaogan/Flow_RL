# Workflow ID: drop_137_0
# Benchmark: drop
# Data Indices: [19, 97]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis - Understand question intent and extract key entities
        analysis = await self.generate(
            instruction="Analyze the passage and question to identify what type of reasoning is required (e.g., counting, arithmetic, comparison) and extract all relevant numerical values and entities mentioned."
        )

        # Step 2: Parallel Exploration - Generate multiple interpretations or solution paths
        task1 = self.generate(
            instruction="Extract all instances of numbers and their associated entities from the passage, focusing on those relevant to the question.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Identify any implicit information or multi-hop dependencies that may be necessary to answer the question correctly.",
            context=analysis
        )
        task3 = self.generate(
            instruction="Generate a candidate answer based on direct extraction of relevant facts from the passage.",
            context=analysis
        )

        results = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble - Synthesize diverse solutions into a robust final answer
        ensemble_result = await self.ensemble(
            instruction="Evaluate and synthesize the three candidate solutions above. Choose the one most consistent with the question's intent and evidence in the passage.",
            contexts_to_ensemble=results
        )

        # Step 4: Refinement Loop - Revise if needed based on clarity or ambiguity
        revised_answer = await self.revise(
            instruction="Critique the ensemble result for clarity, completeness, and correctness. If ambiguous or incomplete, revise it using the original passage as context.",
            context_to_revise=ensemble_result
        )

        return revised_answer