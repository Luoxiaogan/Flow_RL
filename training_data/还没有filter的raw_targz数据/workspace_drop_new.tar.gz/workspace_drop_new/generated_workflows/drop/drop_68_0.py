# Workflow ID: drop_68_0
# Benchmark: drop
# Data Indices: [121, 25]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis – Understand question type and passage structure
        analysis = await self.generate(
            instruction="Analyze the question and passage to determine the required reasoning type (e.g., entity extraction, arithmetic, comparison). Identify key entities, numbers, and relationships."
        )

        # Step 2: Extract all relevant facts using parallel exploration
        fact_extraction_tasks = [
            self.generate(instruction="Extract all named entities mentioned in the passage.", context=analysis),
            self.generate(instruction="Identify all numerical values and their associated entities or events.", context=analysis),
            self.generate(instruction="List all temporal references (dates, time periods) and their contexts.", context=analysis)
        ]
        extracted_facts = await asyncio.gather(*fact_extraction_tasks)

        # Step 3: Summarize extracted information to reduce noise and highlight key elements
        summarized_facts = await self.summarize(context_to_summarize="\n\n".join(extracted_facts))

        # Step 4: Generate multiple candidate solutions based on different interpretations
        solution_candidates = []
        for i, hint in enumerate([
            "Generate an answer assuming the question asks for a direct span from the text.",
            "Generate an answer assuming the question requires inference or multi-hop reasoning.",
            "Generate an answer assuming the question involves counting or comparing entities."
        ]):
            candidate = await self.generate(instruction=hint, context=summarized_facts)
            solution_candidates.append(candidate)

        # Step 5: Ensemble to select the most consistent and well-supported answer
        final_answer = await self.ensemble(
            instruction="Select the best answer by evaluating consistency, relevance, and support from the evidence.",
            contexts_to_ensemble=solution_candidates
        )

        # Step 6: Optional refinement loop if the answer seems ambiguous or incomplete
        if "uncertain" in final_answer.lower() or "not clear" in final_answer.lower():
            refined_answer = await self.revise(
                instruction="Refine the answer by focusing on resolving ambiguity, checking coreference, and ensuring it directly addresses the question.",
                context_to_revise=final_answer
            )
            return refined_answer

        return final_answer