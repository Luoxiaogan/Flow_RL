# Workflow ID: drop_51_0
# Benchmark: drop
# Data Indices: [77, 142]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question type and key entities
        analysis = await self.generate(
            instruction="Analyze the passage and question to identify the type of reasoning required (e.g., arithmetic, counting, comparison) and extract all relevant named entities or numerical values."
        )

        # Step 2: Extract structured facts in parallel — focus on numbers, names, relations
        task1 = self.generate(
            instruction="Extract all numeric values from the passage along with their associated entities or context (e.g., '60.9% white', '10.5% black or African American')."
        )
        task2 = self.generate(
            instruction="Identify all named entities mentioned in the passage that might be relevant to answering the question (e.g., teams, people, dates)."
        )
        task3 = self.generate(
            instruction="Determine whether the question involves comparison, calculation, selection, or span extraction based on keywords like 'more', 'difference', 'how many', 'who had more', etc."
        )
        extracted_facts, extracted_entities, question_type = await asyncio.gather(task1, task2, task3)

        # Step 3: Summarize key information for clarity and context management
        concise_context = await self.summarize(
            context_to_summarize=f"Analysis: {analysis}\nFacts: {extracted_facts}\nEntities: {extracted_entities}\nQuestion Type: {question_type}"
        )

        # Step 4: Generate multiple candidate solutions using different strategies
        if "comparison" in question_type.lower():
            sol1 = await self.generate(
                instruction="Generate a solution focusing on comparing two specific quantities mentioned in the passage.",
                context=concise_context
            )
            sol2 = await self.generate(
                instruction="Generate an alternative solution by first identifying all values related to the entities involved in the comparison.",
                context=concise_context
            )
            final_answer = await self.ensemble(
                instruction="Choose the best answer between the two candidates based on logical consistency and alignment with the original question.",
                contexts_to_ensemble=[sol1, sol2]
            )
        elif "arithmetic" in question_type.lower() or "difference" in question_type.lower():
            sol1 = await self.generate(
                instruction="Calculate the required arithmetic operation (e.g., sum, difference, ratio) using only the numbers and entities identified earlier.",
                context=concise_context
            )
            sol2 = await self.generate(
                instruction="Verify the arithmetic result by re-expressing the question as a step-by-step mathematical process.",
                context=concise_context
            )
            final_answer = await self.ensemble(
                instruction="Select the most accurate answer between the two calculated results, resolving any discrepancies.",
                contexts_to_ensemble=[sol1, sol2]
            )
        elif "counting" in question_type.lower():
            sol1 = await self.generate(
                instruction="Count the number of distinct instances of the entity specified in the question.",
                context=concise_context
            )
            sol2 = await self.generate(
                instruction="Recount the instances by grouping similar items and checking for overlaps or exclusions.",
                context=concise_context
            )
            final_answer = await self.ensemble(
                instruction="Resolve ambiguity between the two counts by selecting the one that aligns best with the passage's structure.",
                contexts_to_ensemble=[sol1, sol2]
            )
        else:
            # Generic fallback for span extraction or selection
            sol1 = await self.generate(
                instruction="Extract the exact text span that answers the question directly based on entity resolution.",
                context=concise_context
            )
            sol2 = await self.generate(
                instruction="Use coreference resolution to map pronouns or partial names to full entities and then extract the correct answer.",
                context=concise_context
            )
            final_answer = await self.ensemble(
                instruction="Select the most coherent and precise answer from the two candidates.",
                contexts_to_ensemble=[sol1, sol2]
            )

        # Step 5: Final refinement using iterative revision to eliminate errors
        refined_answer = await self.revise(
            instruction="Critique the final answer for correctness, clarity, and completeness. If necessary, revise to fix inconsistencies or missing steps.",
            context_to_revise=final_answer
        )

        return refined_answer