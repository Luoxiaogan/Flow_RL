# Workflow ID: drop_107_0
# Benchmark: drop
# Data Indices: [293, 250]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis – Understand question type and key entities
        analysis = await self.generate(
            instruction="Identify the core reasoning task (e.g., arithmetic, counting, comparison, span extraction) and list all relevant entities or numbers mentioned in the passage that may be needed to answer the question."
        )

        # Step 2: Extract structured facts – Prepare clean data for reasoning
        extraction = await self.generate(
            instruction="Extract all numeric values and associated entities from the passage. Format as bullet points like 'Entity: Value'. Be exhaustive and avoid missing any instance.",
            context=analysis
        )

        # Step 3: Parallel Exploration – Generate multiple candidate solutions based on different interpretations
        task1 = self.generate(
            instruction="Based on the extracted facts, solve the question using direct matching (if it's a span or count).",
            context=extraction
        )
        task2 = self.generate(
            instruction="Based on the extracted facts, solve the question by performing required arithmetic operations (addition, subtraction, etc.).",
            context=extraction
        )
        task3 = self.generate(
            instruction="Based on the extracted facts, generate a solution if this is a comparative or selection question.",
            context=extraction
        )

        # Execute in parallel to speed up exploration
        candidates = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble – Synthesize best solution from competing candidates
        final_answer = await self.ensemble(
            instruction="Choose the most accurate and coherent answer among the three candidates. If there is disagreement, prioritize based on clarity, completeness, and logical consistency with the passage.",
            contexts_to_ensemble=candidates
        )

        # Step 5: Optional Refinement – Revise for precision if needed
        refined_answer = await self.revise(
            instruction="Review the final answer carefully. Check for correctness, clarity, and whether it fully addresses the original question without ambiguity.",
            context_to_revise=final_answer
        )

        return refined_answer