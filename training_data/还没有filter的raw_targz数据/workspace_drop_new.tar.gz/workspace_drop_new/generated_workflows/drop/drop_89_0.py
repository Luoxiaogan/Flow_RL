# Workflow ID: drop_89_0
# Benchmark: drop
# Data Indices: [119, 24]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand question type and key entities
        analysis = await self.generate(
            instruction="Analyze the passage and question to identify the required reasoning type (e.g., counting, arithmetic, comparison, span extraction) and key entities involved."
        )

        # Step 2: Extract all relevant events or numerical data from the passage
        extraction = await self.generate(
            instruction="Extract all instances of relevant events mentioned in the passage that could be related to answering the question. Focus on numbers, actions, teams, players, and time markers.",
            context=analysis
        )

        # Step 3: Parallel Exploration — Generate multiple candidate solutions based on different interpretations
        task1 = self.generate(
            instruction="Based on the extracted facts, generate a solution assuming the question requires simple counting of field goals by the Cowboys in the first half.",
            context=extraction
        )
        task2 = self.generate(
            instruction="Based on the extracted facts, generate a solution assuming the question requires identifying which team scored first, using timeline clues.",
            context=extraction
        )
        task3 = self.generate(
            instruction="Based on the extracted facts, generate a solution assuming the question requires multi-hop reasoning about who had more total points or touchdowns.",
            context=extraction
        )

        # Execute all parallel paths
        candidates = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble — Synthesize the best answer based on consistency across interpretations
        final_answer = await self.ensemble(
            instruction="Choose the most consistent and well-supported answer among the three generated solutions. If there's disagreement, prioritize clarity and alignment with explicit evidence.",
            contexts_to_ensemble=candidates
        )

        # Step 5: Optional refinement — Revise if the answer seems ambiguous or incomplete
        refined_answer = await self.revise(
            instruction="If the answer lacks specificity or clarity, improve it by adding supporting details from the original passage. Otherwise, return as-is.",
            context_to_revise=final_answer
        )

        return refined_answer