# Workflow ID: drop_34_0
# Benchmark: drop
# Data Indices: [185, 49]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis – Understand the question type and domain
        analysis = await self.generate(
            instruction="Analyze the question to determine its reasoning type (e.g., arithmetic, counting, comparison, span extraction). Identify key entities and numerical references."
        )

        # Step 2: Extract Relevant Information – Pull out all candidate facts from passage
        extraction = await self.generate(
            instruction="Extract all relevant numerical values and associated entities from the passage that could be used to answer the question.",
            context=analysis
        )

        # Step 3: Parallel Exploration – Generate multiple solution paths based on different interpretations
        task1 = self.generate(
            instruction="Generate a step-by-step plan assuming this is a simple count or sum operation.",
            context=extraction
        )
        task2 = self.generate(
            instruction="Generate a step-by-step plan assuming this involves identifying specific entities or resolving pronouns.",
            context=extraction
        )
        task3 = self.generate(
            instruction="Generate a step-by-step plan assuming this requires multi-hop inference across several sentences.",
            context=extraction
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer – Synthesize best-supported solution
        final_answer = await self.ensemble(
            instruction="Select the most accurate and coherent solution based on the evidence in the passage. Reject inconsistent or unsupported claims.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Revise for Precision – Refine output using error-checking prompts
        revised_answer = await self.revise(
            instruction="Review the final answer carefully. Ensure it matches the exact intent of the question and uses only information explicitly supported by the passage.",
            context_to_revise=final_answer
        )

        return revised_answer