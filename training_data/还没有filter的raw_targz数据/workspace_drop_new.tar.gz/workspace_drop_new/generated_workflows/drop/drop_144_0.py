# Workflow ID: drop_144_0
# Benchmark: drop
# Data Indices: [275, 148]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis - Understand question type and extract key entities
        analysis = await self.generate(
            instruction="Analyze the passage and question to determine the required reasoning type (e.g., counting, comparison, span extraction) and identify all relevant entities or numerical values mentioned."
        )

        # Step 2: Parallel Exploration - Generate multiple interpretations
        task1 = self.generate(
            instruction="Extract all named entities, numerical facts, and relationships from the passage that might be relevant to answering the question.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Identify potential answer types based on the question (e.g., number, text span, comparison). Also, list any implicit inferences needed.",
            context=analysis
        )
        task3 = self.generate(
            instruction="List all possible interpretations of ambiguous phrases or pronouns in the question using context from the passage.",
            context=analysis
        )
        extracted_facts, answer_types, interpretations = await asyncio.gather(task1, task2, task3)

        # Step 3: Diverge-Converge Pattern - Synthesize diverse perspectives
        divergent_solutions = [
            await self.generate(
                instruction="Based on the extracted facts, generate a solution focusing only on explicit numerical data.",
                context=extracted_facts
            ),
            await self.generate(
                instruction="Generate a solution considering both explicit and implicit information, especially for comparisons or selections.",
                context=extracted_facts + "\n\n" + answer_types
            ),
            await self.generate(
                instruction="Generate a solution prioritizing entity resolution and coreference handling for ambiguous references.",
                context=interpretations + "\n\n" + extracted_facts
            )
        ]

        # Step 4: Ensemble Final Answer
        final_answer = await self.ensemble(
            instruction="Evaluate the three candidate solutions above. Choose the one that best addresses the original question, handles ambiguity correctly, and aligns with the evidence in the passage.",
            contexts_to_ensemble=divergent_solutions
        )

        # Step 5: Optional Refinement Based on Confidence
        if "uncertain" in final_answer.lower() or "not clear" in final_answer.lower():
            refined_answer = await self.revise(
                instruction="Revise the answer to improve clarity, ensure it fully resolves the question, and explicitly state how each part was derived from the passage.",
                context_to_revise=final_answer
            )
            return refined_answer

        return final_answer