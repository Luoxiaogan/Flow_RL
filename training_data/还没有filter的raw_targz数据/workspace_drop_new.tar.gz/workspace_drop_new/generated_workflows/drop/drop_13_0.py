# Workflow ID: drop_13_0
# Benchmark: drop
# Data Indices: [296, 236]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand question intent and extract key entities
        analysis = await self.generate(
            instruction="Analyze the passage and question to identify required reasoning type (e.g., arithmetic, comparison, span extraction), key entities, and numerical values relevant to the answer."
        )

        # Step 2: Extract structured data — Isolate all candidate numbers and their associated entities
        extraction_prompt = (
            "From the passage, list all numeric values along with the entity they refer to (e.g., '5-yard touchdown pass from Luck to Moncrief'). "
            "Include only those that might be relevant to answering the question. Format as bullet points."
        )
        raw_extractions = await self.generate(instruction=extraction_prompt, context=analysis)

        # Step 3: Parallel Exploration — Generate multiple interpretations or solution paths
        # One path: focus on exact matches for comparisons
        comp_path = await self.generate(
            instruction="Based on the extracted facts, generate a solution focused on comparing two specific entities mentioned in the question.",
            context=raw_extractions
        )

        # Another path: generate a full step-by-step arithmetic breakdown
        math_path = await self.generate(
            instruction="Generate a detailed arithmetic process for solving the question using the extracted facts. Assume this involves subtraction or calculation.",
            context=raw_extractions
        )

        # Step 4: Ensemble — Compare both solutions and select the most coherent one
        final_answer = await self.ensemble(
            instruction="Choose the best answer between the comparison-based and arithmetic-based solutions. If both agree, confirm it. If they conflict, explain why one is more likely correct based on the passage.",
            contexts_to_ensemble=[comp_path, math_path]
        )

        # Step 5: Revise — Refine the final answer by checking for logical consistency
        revised_answer = await self.revise(
            instruction="Review the final answer for clarity, correctness, and alignment with the original question. Correct any ambiguity or error.",
            context_to_revise=final_answer
        )

        return revised_answer