# Workflow ID: drop_87_0
# Benchmark: drop
# Data Indices: [57, 191]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand question intent and passage structure
        analysis = await self.generate(
            instruction="Analyze the question to determine its type (e.g., counting, arithmetic, comparison, span extraction). Also identify key entities and numerical values in the passage that may be relevant."
        )

        # Step 2: Extract Structured Facts — Turn dense text into usable data
        extraction = await self.generate(
            instruction="Extract all relevant facts from the passage in structured format (e.g., lists of entities with associated numbers or attributes). Focus on entities mentioned in the question and their values.",
            context=analysis
        )

        # Step 3: Generate Multiple Reasoning Paths — Use parallel exploration for ambiguity
        task1 = self.generate(
            instruction="Generate a solution based on direct extraction and simple computation (if applicable).",
            context=extraction
        )
        task2 = self.generate(
            instruction="Generate an alternative solution by focusing on entity-number associations and resolving potential ambiguities (e.g., pronouns, similar entities).",
            context=extraction
        )
        task3 = self.generate(
            instruction="Generate a solution assuming implicit reasoning is needed — infer missing connections between entities and values.",
            context=extraction
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble — Synthesize best answer from multiple perspectives
        final_answer = await self.ensemble(
            instruction="Select the most accurate answer based on consistency across all three solutions. If there's disagreement, prioritize the one supported by clear evidence from the passage.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Revise — Self-correct if necessary based on confidence
        revised_answer = await self.revise(
            instruction="Critique the final answer: does it match the question type? Are all relevant facts considered? If not, revise accordingly.",
            context_to_revise=final_answer
        )

        return revised_answer