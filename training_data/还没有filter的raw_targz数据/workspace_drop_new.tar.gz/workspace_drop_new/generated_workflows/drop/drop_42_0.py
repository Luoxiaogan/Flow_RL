# Workflow ID: drop_42_0
# Benchmark: drop
# Data Indices: [112, 60]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question type and structure
        analysis = await self.generate(
            instruction="Analyze the question and passage to determine the required reasoning type (e.g., arithmetic, counting, comparison, span extraction). Also identify key entities, numbers, and relationships."
        )

        # Step 2: Extract all relevant numerical and entity data from the passage
        extraction = await self.generate(
            instruction="Extract all numerical values, percentages, counts, and named entities from the passage that could be relevant to answering the question. Format as structured bullet points.",
            context=analysis
        )

        # Step 3: Generate multiple candidate solutions based on different interpretations
        task1 = self.generate(
            instruction="Generate a solution assuming the question asks for a simple difference between two percentages (e.g., Malay vs Indian population).",
            context=extraction
        )
        task2 = self.generate(
            instruction="Generate a solution assuming the question requires identifying the exact value mentioned in the text (e.g., field goal distance).",
            context=extraction
        )
        task3 = self.generate(
            instruction="Generate a solution assuming the question involves multi-hop inference or implicit calculation (e.g., total number of people based on percentages).",
            context=extraction
        )

        # Step 4: Run parallel exploration and ensemble final answer
        candidates = await asyncio.gather(task1, task2, task3)
        final_answer = await self.ensemble(
            instruction="Select the most accurate and contextually supported answer among the three candidates. If uncertain, choose the one with strongest textual grounding.",
            contexts_to_ensemble=candidates
        )

        # Step 5: Optional refinement if answer seems ambiguous
        if "ambiguous" in final_answer.lower() or "uncertain" in final_answer.lower():
            refined_answer = await self.revise(
                instruction="Refine the answer by focusing only on the clearest evidence in the passage that directly supports the correct interpretation.",
                context_to_revise=final_answer
            )
            return refined_answer

        return final_answer