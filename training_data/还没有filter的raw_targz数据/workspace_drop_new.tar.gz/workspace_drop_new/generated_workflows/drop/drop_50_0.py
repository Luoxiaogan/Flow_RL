# Workflow ID: drop_50_0
# Benchmark: drop
# Data Indices: [63, 269]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Analyze the question to determine required reasoning type
        analysis = await self.generate(
            instruction="Analyze the question to determine whether it requires entity extraction, numerical reasoning, comparison, or counting. Also identify if there are ambiguous references or multiple similar entities."
        )

        # Step 2: Extract all relevant facts from the passage
        extraction = await self.generate(
            instruction="Extract all named entities and associated numerical values from the passage that could be relevant to answering the question. Include full context for each item (e.g., 'Gostkowski kicked a 35-yard field goal').",
            context=analysis
        )

        # Step 3: If the question involves numbers, perform arithmetic reasoning
        if "how many" in analysis.lower() or "difference" in analysis.lower() or "more" in analysis.lower():
            numeric_reasoning = await self.generate(
                instruction="Based on the extracted facts, perform the necessary arithmetic operations (addition, subtraction, comparison) to answer the question. Be explicit about which numbers belong to which entities.",
                context=extraction
            )
            # Use ensemble to validate against alternative interpretations
            ensemble_candidate = await self.generate(
                instruction="Generate an alternative interpretation of the same question using different phrasing but same intent. Then compare both solutions.",
                context=numeric_reasoning
            )
            final_answer = await self.ensemble(
                instruction="Choose the most accurate answer between the original solution and the alternative interpretation based on consistency with the passage.",
                contexts_to_ensemble=[numeric_reasoning, ensemble_candidate]
            )
        else:
            # For non-numerical questions like "who was the kicker", do direct span extraction
            span_extraction = await self.generate(
                instruction="Identify the exact text span(s) in the passage that directly answer the question. Focus only on entities mentioned explicitly or through clear pronouns.",
                context=extraction
            )
            # Revise to fix potential ambiguity in reference resolution
            revised_span = await self.revise(
                instruction="If the extracted span refers to an entity by pronoun or partial name, rewrite it using the full entity name from the passage for clarity.",
                context_to_revise=span_extraction
            )
            # Ensemble with a second pass that uses summarization to reduce noise
            summary_based = await self.summarize(context_to_summarize=extraction)
            summary_span = await self.generate(
                instruction="From the summarized content, extract the answer again focusing only on what's clearly stated in the summary.",
                context=summary_based
            )
            final_answer = await self.ensemble(
                instruction="Select the best answer between the direct extraction and the summary-based extraction, prioritizing accuracy over length.",
                contexts_to_ensemble=[revised_span, summary_span]
            )

        return final_answer