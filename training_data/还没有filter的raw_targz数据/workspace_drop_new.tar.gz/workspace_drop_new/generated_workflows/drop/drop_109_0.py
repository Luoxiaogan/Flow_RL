# Workflow ID: drop_109_0
# Benchmark: drop
# Data Indices: [288, 74]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to detect question type and key entities
        analysis = await self.generate(
            instruction="Analyze the passage and question. Identify if this requires arithmetic (sum/difference), counting, comparison, or span extraction. Also extract all relevant numerical values with their associated entities (e.g., field goals, touchdowns, players)."
        )

        # Step 2: Parallel exploration of multiple candidate interpretations
        task1 = self.generate(
            instruction="Extract all numeric values from the passage along with their descriptive context (e.g., '40-yard field goal', '54-yard fumble return').",
            context=analysis
        )
        task2 = self.generate(
            instruction="Identify the specific entities mentioned in the question and map them to their corresponding values in the passage.",
            context=analysis
        )
        task3 = self.generate(
            instruction="Generate a step-by-step reasoning plan based on the identified question type (arithmetic, comparison, etc.).",
            context=analysis
        )

        # Run parallel tasks
        extracted_data, entity_mapping, reasoning_plan = await asyncio.gather(task1, task2, task3)

        # Step 3: Use the reasoning plan to generate solution candidates
        candidate_solutions = []
        for plan in [reasoning_plan]:
            candidate = await self.generate(
                instruction=f"Using the following extracted data: {extracted_data}, and the mapping: {entity_mapping}, apply the reasoning plan: {plan}. Generate a detailed step-by-step solution.",
                context=analysis
            )
            candidate_solutions.append(candidate)

        # Step 4: Ensemble to resolve ambiguity or inconsistency
        final_answer = await self.ensemble(
            instruction="Compare the following solutions and select the most accurate one based on consistency with the passage and logical soundness.",
            contexts_to_ensemble=candidate_solutions
        )

        # Step 5: Optional refinement if needed
        refined_answer = await self.revise(
            instruction="Review the final answer for clarity, precision, and correctness. If it's incomplete or ambiguous, revise accordingly.",
            context_to_revise=final_answer
        )

        return refined_answer