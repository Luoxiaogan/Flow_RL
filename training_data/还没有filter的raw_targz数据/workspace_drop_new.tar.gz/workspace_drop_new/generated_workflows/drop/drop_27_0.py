# Workflow ID: drop_27_0
# Benchmark: drop
# Data Indices: [61, 51]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis - Understand question type and key entities
        analysis = await self.generate(
            instruction="Analyze the question to determine its type (e.g., arithmetic, counting, comparison, selection, span extraction) and identify all relevant entities or numerical values in the passage."
        )

        # Step 2: Extract Structured Data - Pull out all relevant facts
        extraction = await self.generate(
            instruction="Extract all relevant numerical values, named entities, and temporal markers from the passage that might be needed to answer the question.",
            context=analysis
        )

        # Step 3: Parallel Hypothesis Generation - Generate multiple solution paths
        task1 = self.generate(
            instruction="Generate a step-by-step plan assuming this is an arithmetic question (sum, difference, etc.).",
            context=extraction
        )
        task2 = self.generate(
            instruction="Generate a step-by-step plan assuming this is a counting question (how many times, how many different).",
            context=extraction
        )
        task3 = self.generate(
            instruction="Generate a step-by-step plan assuming this is a comparative question (which is greater, who had more).",
            context=extraction
        )
        task4 = self.generate(
            instruction="Generate a step-by-step plan assuming this is a span extraction or selection question (who did what, what was the name).",
            context=extraction
        )

        solutions = await asyncio.gather(task1, task2, task3, task4)

        # Step 4: Ensemble - Choose the best solution based on coherence and alignment with question intent
        final_answer = await self.ensemble(
            instruction="Evaluate the four candidate solutions and select the one that most accurately answers the original question based on the passage content and reasoning quality.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional Refinement Loop - If the answer seems ambiguous or incomplete, revise once
        if "uncertain" in final_answer.lower() or "not clear" in final_answer.lower():
            final_answer = await self.revise(
                instruction="Refine the answer by focusing on resolving ambiguity, ensuring correct entity-number associations, and checking for implicit information not yet used.",
                context_to_revise=final_answer
            )

        return final_answer