# Workflow ID: drop_16_0
# Benchmark: drop
# Data Indices: [55, 70]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question intent and passage structure
        analysis = await self.generate(
            instruction="Analyze the question and passage to identify key entities, numerical data, and reasoning type (e.g., counting, comparison, span extraction)."
        )

        # Step 2: Extract all relevant factual elements from the passage
        extraction = await self.generate(
            instruction="Extract all discrete facts from the passage that could be relevant to answering the question. Include numbers, named entities, and time-related information.",
            context=analysis
        )

        # Step 3: Generate multiple candidate interpretations or solution paths based on the extracted facts
        candidates = [
            await self.generate("Generate one possible interpretation of how to solve this question using the extracted facts.", context=extraction),
            await self.generate("Generate an alternative approach to solving this question, focusing on different aspects of the extracted facts.", context=extraction)
        ]

        # Step 4: Ensemble the candidates to select the most coherent and accurate solution
        final_answer = await self.ensemble(
            instruction="Select the best answer based on consistency with the passage and logical soundness. If multiple valid answers exist, choose the most directly supported by evidence.",
            contexts_to_ensemble=candidates
        )

        # Step 5: Revise the final answer if it seems incomplete or ambiguous
        revised_answer = await self.revise(
            instruction="Critique the final answer: does it fully address the question? If not, improve clarity, completeness, or precision without introducing new unsupported claims.",
            context_to_revise=final_answer
        )

        return revised_answer