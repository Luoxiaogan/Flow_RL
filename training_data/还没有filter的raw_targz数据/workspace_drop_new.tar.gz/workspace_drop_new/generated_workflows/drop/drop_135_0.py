# Workflow ID: drop_135_0
# Benchmark: drop
# Data Indices: [135, 105]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question type and key entities
        analysis = await self.generate(
            instruction="Analyze the passage and question. Identify the type of reasoning required (e.g., counting, arithmetic, comparison) and the key entities mentioned in the question."
        )

        # Step 2: Extract all relevant events or mentions related to the question
        extraction_prompt = "Extract all instances of events, scores, or occurrences relevant to the question. Focus on numerical values and their associated entities."
        raw_extractions = await self.generate(instruction=extraction_prompt, context=analysis)

        # Step 3: Summarize extractions to reduce noise and highlight key facts
        summarized_extractions = await self.summarize(context_to_summarize=raw_extractions)

        # Step 4: Generate multiple solution hypotheses based on different interpretations
        hypothesis_prompt = "Generate at least three distinct possible solutions based on the summarized information. Each should reflect a different interpretation or approach to answering the question."
        hypotheses = await asyncio.gather(
            self.generate(instruction=hypothesis_prompt + " Hypothesis 1: Assume only direct mentions count.", context=summarized_extractions),
            self.generate(instruction=hypothesis_prompt + " Hypothesis 2: Include implicit or inferred counts.", context=summarized_extractions),
            self.generate(instruction=hypothesis_prompt + " Hypothesis 3: Consider only the most recent occurrence.", context=summarized_extractions)
        )

        # Step 5: Ensemble to select the best solution from competing hypotheses
        final_answer = await self.ensemble(
            instruction="Choose the most accurate answer by comparing the three hypotheses. Justify your choice based on evidence from the passage.",
            contexts_to_ensemble=hypotheses
        )

        # Step 6: Optional refinement if the answer seems ambiguous or incomplete
        if "uncertain" in final_answer.lower() or "multiple" in final_answer.lower():
            refined_answer = await self.revise(
                instruction="Revise the answer to be more precise. Clarify whether this is a count, a specific value, or a comparative result.",
                context_to_revise=final_answer
            )
            return refined_answer

        return final_answer