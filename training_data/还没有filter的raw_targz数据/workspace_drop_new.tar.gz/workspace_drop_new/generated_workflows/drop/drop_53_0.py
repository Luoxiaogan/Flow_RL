# Workflow ID: drop_53_0
# Benchmark: drop
# Data Indices: [138, 164]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand question intent and extract key entities
        analysis = await self.generate(
            instruction="Analyze the question and passage to identify the type of reasoning required (e.g., numerical comparison, count, span extraction). Also identify all relevant named entities and values mentioned in the passage."
        )

        # Step 2: Parallel Extraction — Extract multiple candidate data types independently
        task1 = self.generate(instruction="Extract all dates mentioned in the passage with their associated events.")
        task2 = self.generate(instruction="Extract all numerical values from the passage along with the entities they refer to (e.g., yardage, counts, scores).")
        task3 = self.generate(instruction="Extract all entity names and roles mentioned in the passage (e.g., teams, people, locations).")
        
        extracted_data = await asyncio.gather(task1, task2, task3)

        # Step 3: Summarize Extracted Data — Reduce noise and focus on relevant facts
        summarized_extracted = await self.summarize(context_to_summarize="\n\n".join(extracted_data))

        # Step 4: Generate Multiple Reasoning Paths — Create diverse solution strategies based on the summary
        math_path = await self.generate(
            instruction="Based on the summarized information, generate a step-by-step mathematical approach to solve the question if it involves arithmetic or comparisons.",
            context=summarized_extracted
        )
        logic_path = await self.generate(
            instruction="Generate a logical reasoning path that identifies the correct event or entity by following contextual clues and coreference resolution.",
            context=summarized_extracted
        )
        span_path = await self.generate(
            instruction="If the question requires extracting a text span (like a name or phrase), generate a focused strategy to locate it using context cues.",
            context=summarized_extracted
        )

        # Step 5: Ensemble Final Solutions — Combine the three paths to produce the most robust answer
        final_answer = await self.ensemble(
            instruction="Evaluate the three proposed solutions (mathematical, logical, and span-based) and select the one that best matches the question's requirements and evidence from the passage.",
            contexts_to_ensemble=[math_path, logic_path, span_path]
        )

        # Step 6: Optional Refinement — If the ensemble result seems ambiguous, refine it
        if "ambiguous" in final_answer.lower() or "uncertain" in final_answer.lower():
            refined_answer = await self.revise(
                instruction="Revise the previous answer to resolve ambiguity by focusing on the clearest supporting evidence in the passage.",
                context_to_revise=final_answer
            )
            return refined_answer

        return final_answer