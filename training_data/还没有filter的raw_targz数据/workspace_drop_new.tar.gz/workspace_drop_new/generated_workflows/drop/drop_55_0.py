# Workflow ID: drop_55_0
# Benchmark: drop
# Data Indices: [89, 201]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question type and key entities
        analysis = await self.generate(
            instruction="Analyze the passage and question to determine the required reasoning type (e.g., numerical, span extraction, comparison) and identify all relevant entities mentioned in the passage."
        )

        # Step 2: Extract structured facts — focus on events involving numbers and named entities
        extraction = await self.generate(
            instruction="Extract all factual statements from the passage that contain numerical values or entity references relevant to answering the question. Format each as 'Entity: [description] | Value: [number]' or 'Entity: [description] | Text: [phrase]'",
            context=analysis
        )

        # Step 3: Parallel exploration — generate multiple candidate solutions based on different interpretations
        task1 = self.generate(
            instruction="Based on the extracted facts, generate a solution assuming the question requires summing values associated with a specific entity.",
            context=extraction
        )
        task2 = self.generate(
            instruction="Based on the extracted facts, generate a solution assuming the question requires identifying the value tied to a specific event or time period.",
            context=extraction
        )
        task3 = self.generate(
            instruction="Based on the extracted facts, generate a solution assuming the question involves comparing two entities or values.",
            context=extraction
        )

        # Execute in parallel to explore diverse approaches
        candidates = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble to select best answer among competing interpretations
        final_answer = await self.ensemble(
            instruction="Select the most consistent and well-supported answer from the following three candidate responses. Justify briefly if there's ambiguity.",
            contexts_to_ensemble=candidates
        )

        # Step 5: Optional refinement if the ensemble result seems uncertain
        if "uncertain" in final_answer.lower() or "multiple" in final_answer.lower():
            refined = await self.revise(
                instruction="Revise the answer by focusing on the clearest evidence in the passage. Eliminate ambiguous interpretations and provide only the definitive answer.",
                context_to_revise=final_answer
            )
            return refined

        return final_answer