# Workflow ID: drop_54_0
# Benchmark: drop
# Data Indices: [143, 207]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis – Understand the question type and extract key entities
        analysis = await self.generate(
            instruction="Analyze the question to determine if it requires arithmetic, counting, comparison, or span extraction. Identify all relevant entities mentioned in the passage that could be involved in the answer."
        )

        # Step 2: Extract Relevant Information – Isolate numbers and their associated entities
        extraction = await self.generate(
            instruction="Extract all numerical values and their corresponding entities from the passage that are relevant to answering the question. Format as 'Entity: Value' pairs.",
            context=analysis
        )

        # Step 3: Generate Multiple Interpretations – Handle ambiguity (e.g., multiple instances of same entity)
        interpretations = [
            self.generate("Generate one possible interpretation of how to solve this based on the extracted data.", context=extraction),
            self.generate("Generate an alternative interpretation, focusing on potential coreference or implicit information.", context=extraction)
        ]
        interpretations = await asyncio.gather(*interpretations)

        # Step 4: Ensemble Final Candidate Solutions – Select best interpretation
        final_answer = await self.ensemble(
            instruction="Choose the most accurate solution based on consistency with the passage and clarity of reasoning. If both solutions agree, return that. Otherwise, select the one with stronger evidence.",
            contexts_to_ensemble=interpretations
        )

        # Step 5: Revise Based on Question Intent – Ensure alignment with what’s being asked
        revised_answer = await self.revise(
            instruction="Review the final answer to ensure it directly addresses the question's intent—e.g., is it a difference, sum, count, or selection? Adjust if necessary.",
            context_to_revise=final_answer
        )

        return revised_answer