# Workflow ID: drop_105_0
# Benchmark: drop
# Data Indices: [234, 94]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis – Understand question intent and key entities
        analysis = await self.generate(
            instruction="Analyze the question to determine what type of reasoning is required (e.g., date extraction, count, comparison, span). Also identify all named entities or numerical references in the passage that may be relevant."
        )

        # Step 2: Extract Relevant Facts – Use parallel exploration for robustness
        extract_task1 = self.generate(
            instruction="Extract all dates mentioned in the passage, including those related to events or auctions."
        )
        extract_task2 = self.generate(
            instruction="Extract all named entities that could be involved in the answer, such as people, places, or organizations."
        )
        extract_task3 = self.generate(
            instruction="Identify any explicit counts, numbers, or ranges mentioned in the passage."
        )

        facts_date, facts_entities, facts_numbers = await asyncio.gather(extract_task1, extract_task2, extract_task3)

        # Step 3: Refine Based on Question Intent – Branch based on analysis
        if "date" in analysis.lower() or "year" in analysis.lower():
            refined_context = await self.generate(
                instruction="Based on the extracted dates and the question, determine which event corresponds to 'the second event' or 'already held auctions'. Prioritize chronological order if multiple dates exist.",
                context=facts_date + "\n\n" + analysis
            )
        elif "how many" in analysis.lower() or "count" in analysis.lower():
            refined_context = await self.generate(
                instruction="From the extracted numbers and context, compute the total or specific count requested by the question.",
                context=facts_numbers + "\n\n" + analysis
            )
        else:
            refined_context = await self.generate(
                instruction="Use the extracted entities and the question to locate the correct entity or phrase that answers the query.",
                context=facts_entities + "\n\n" + analysis
            )

        # Step 4: Iterative Refinement – Self-correct using multiple angles
        revision1 = await self.revise(
            instruction="Check whether the current solution correctly identifies the exact event or value referenced in the question. If not, revise accordingly.",
            context_to_revise=refined_context
        )
        revision2 = await self.revise(
            instruction="Verify that no ambiguous references remain—especially pronouns or partial names—and resolve them using context from the passage.",
            context_to_revise=revision1
        )

        # Step 5: Ensemble Multiple Solutions – Handle uncertainty via voting
        candidate1 = await self.generate(
            instruction="Generate an alternative interpretation of the question and solve it independently.",
            context=analysis
        )
        candidate2 = await self.generate(
            instruction="Rephrase the question into a more structured format and solve again.",
            context=analysis
        )
        final_answer = await self.ensemble(
            instruction="Choose the most consistent and well-supported answer among the candidates, considering both clarity and alignment with the original question.",
            contexts_to_ensemble=[revision2, candidate1, candidate2]
        )

        return final_answer