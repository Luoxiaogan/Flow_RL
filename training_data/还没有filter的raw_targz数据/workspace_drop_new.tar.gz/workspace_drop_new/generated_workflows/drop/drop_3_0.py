# Workflow ID: drop_3_0
# Benchmark: drop
# Data Indices: [35, 132]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to detect question type and key elements
        analysis = await self.generate(
            instruction="Analyze the passage and question to determine the required reasoning type (e.g., arithmetic, counting, comparison, span extraction). Also identify all relevant entities and numerical values mentioned."
        )

        # Step 2: Extract structured facts in parallel — multiple data types
        task1 = self.generate(instruction="Extract all numeric values from the passage with their associated context (e.g., '116.6 million tonnes' linked to year 2013&ndash;4).")
        task2 = self.generate(instruction="Identify all named entities that could be relevant to answering the question (e.g., teams, people, events).")
        task3 = self.generate(instruction="List all explicit comparisons or quantitative relationships in the passage.")
        
        extracted_facts, entities, comparisons = await asyncio.gather(task1, task2, task3)

        # Step 3: Generate candidate solutions using different strategies
        math_solution = await self.generate(
            instruction="Using only the extracted numeric values, solve the question by applying appropriate arithmetic operations (addition, subtraction, etc.).",
            context=extracted_facts
        )
        
        entity_solution = await self.generate(
            instruction="Based on the identified entities, extract the answer as a text span or list of spans relevant to the question.",
            context=entities
        )
        
        comparison_solution = await self.generate(
            instruction="Use the explicit comparisons to infer the correct answer if it's a comparative question (e.g., which is greater?).",
            context=comparisons
        )

        # Step 4: Ensemble to resolve conflicts or improve robustness
        final_answer = await self.ensemble(
            instruction="Choose the most consistent and logically sound answer among the three candidates. If they conflict, prioritize based on clarity and direct evidence from the passage.",
            contexts_to_ensemble=[math_solution, entity_solution, comparison_solution]
        )

        # Step 5: Revise for precision if needed (optional feedback loop)
        revised_answer = await self.revise(
            instruction="Critique the final answer: does it match the question intent? Is there ambiguity in entity-number association? Improve if necessary.",
            context_to_revise=final_answer
        )

        return revised_answer