# Workflow ID: drop_90_0
# Benchmark: drop
# Data Indices: [195, 115]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question type and domain
        analysis = await self.generate(
            instruction="Analyze the passage and question to determine the required reasoning type (e.g., counting, arithmetic, comparison, span extraction). Also identify key entities and numerical references."
        )

        # Step 2: Extract all relevant facts in parallel — both explicit and implicit
        extract_facts_task = self.generate(
            instruction="Extract all explicit numerical values and associated entities from the passage. List them clearly as 'Entity: Value' pairs."
        )
        extract_entities_task = self.generate(
            instruction="Identify all named entities mentioned in the passage that could be relevant to answering the question (e.g., people, teams, events, locations)."
        )
        extract_context_task = self.generate(
            instruction="Summarize the key context around the question topic, focusing on relationships between entities and potential multi-hop links."
        )

        # Execute parallel extraction tasks
        facts, entities, context = await asyncio.gather(
            extract_facts_task,
            extract_entities_task,
            extract_context_task
        )

        # Step 3: Generate multiple candidate solutions based on different interpretations
        solution_math = self.generate(
            instruction="If the question involves numbers, compute the answer using only the extracted facts. If it's about totals or differences, apply appropriate arithmetic.",
            context=facts + "\n\n" + context
        )
        solution_span = self.generate(
            instruction="If the question asks for an entity name or phrase, identify the correct one by matching against the extracted entities and their roles in the passage.",
            context=entities + "\n\n" + context
        )
        solution_comparison = self.generate(
            instruction="If the question compares two values or entities, compare the relevant ones using the extracted facts and explain which is greater or more numerous.",
            context=facts + "\n\n" + context
        )

        # Step 4: Ensemble the three candidate answers to resolve ambiguity
        final_answer = await self.ensemble(
            instruction="Choose the most consistent and accurate answer among the three candidates. Justify your choice based on clarity, completeness, and alignment with the original question.",
            contexts_to_ensemble=[solution_math, solution_span, solution_comparison]
        )

        # Step 5: Revise final answer if needed — check for logical consistency
        revised_final = await self.revise(
            instruction="Review the final answer for correctness, clarity, and whether it fully addresses the question. If uncertain, revise to improve precision or add justification.",
            context_to_revise=final_answer
        )

        return revised_final