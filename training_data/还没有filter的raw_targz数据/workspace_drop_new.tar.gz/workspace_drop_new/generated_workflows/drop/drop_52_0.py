# Workflow ID: drop_52_0
# Benchmark: drop
# Data Indices: [2, 47]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to detect question type and key entities
        analysis = await self.generate(
            instruction="Analyze the question and passage to determine the required reasoning type (e.g., span extraction, arithmetic, comparison). Identify all relevant entities and numbers mentioned."
        )

        # Step 2: Extract structured facts — critical for multi-hop and numerical problems
        extracted_facts = await self.generate(
            instruction="Extract all relevant factual statements from the passage, focusing on entities, events, and associated values (e.g., scores, dates, counts). Format as bullet points.",
            context=analysis
        )

        # Step 3: Parallel exploration of possible interpretations or answer types
        task1 = self.generate(
            instruction="Generate a candidate answer based on direct span extraction (e.g., 'Who scored the last points?')",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Generate a candidate answer by identifying the most recent event in chronological order.",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Generate a candidate answer by analyzing temporal markers like 'last', 'final', or 'overtime'.",
            context=extracted_facts
        )
        results = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble to select the best answer among diverse candidates
        final_answer = await self.ensemble(
            instruction="Select the most accurate and coherent answer from the following candidates. Prioritize clarity, alignment with question intent, and consistency with evidence.",
            contexts_to_ensemble=results
        )

        # Step 5: Optional refinement if the ensemble result seems uncertain
        if "likely" in final_answer.lower() or "possibly" in final_answer.lower():
            refined_answer = await self.revise(
                instruction="Revise the answer to be more confident and precise, using only explicit evidence from the passage.",
                context_to_revise=final_answer
            )
            return refined_answer

        return final_answer