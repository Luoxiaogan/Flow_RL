# Workflow ID: drop_112_0
# Benchmark: drop
# Data Indices: [133, 114]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question type and key entities
        analysis = await self.generate(
            instruction="Analyze the passage and question to identify the type of reasoning required (e.g., span extraction, counting, arithmetic). Also list all named entities mentioned in the passage that may be relevant."
        )

        # Step 2: Extract structured facts from passage using parallel exploration
        extract_tasks = [
            self.generate("List all instances of field goals, including yardage and kicker name."),
            self.generate("List all touchdown passes, including receiver name, yardage, and quarterback."),
            self.generate("Identify all players with notable statistics (e.g., passing yards, touchdowns)."),
            self.generate("Extract all time-based events (quarter, overtime) and associated scores.")
        ]
        extracted_facts = await asyncio.gather(*extract_tasks)

        # Step 3: Summarize key elements for clarity and context management
        summary = await self.summarize("\n\n".join(extracted_facts))

        # Step 4: Generate candidate solutions based on different reasoning paths
        solution_candidates = []
        if "who caught" in analysis.lower():
            # Span extraction path
            candidate_1 = await self.generate(
                instruction="Based on the summary, identify the player who caught the specified touchdown pass.",
                context=summary
            )
            solution_candidates.append(candidate_1)

        if "how many" in analysis.lower() or "count" in analysis.lower():
            # Counting path
            candidate_2 = await self.generate(
                instruction="From the summary, count how many times the specified entity (e.g., kicker, team) appears in the passage.",
                context=summary
            )
            solution_candidates.append(candidate_2)

        if "difference" in analysis.lower() or "more" in analysis.lower():
            # Arithmetic path
            candidate_3 = await self.generate(
                instruction="Calculate the numerical difference between two values mentioned in the summary.",
                context=summary
            )
            solution_candidates.append(candidate_3)

        # Step 5: Ensemble to select best answer from competing interpretations
        final_answer = await self.ensemble(
            instruction="Choose the most accurate answer among the candidates based on relevance to the original question and consistency with the passage.",
            contexts_to_ensemble=solution_candidates
        )

        # Step 6: Revise final answer for clarity and correctness
        refined_answer = await self.revise(
            instruction="Improve the final answer by removing unnecessary details and ensuring it directly answers the question.",
            context_to_revise=final_answer
        )

        return refined_answer