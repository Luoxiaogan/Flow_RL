# Workflow ID: drop_29_0
# Benchmark: drop
# Data Indices: [266, 186]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand question type and extract key entities/numbers
        analysis = await self.generate(
            instruction="Analyze the passage and question to identify the type of reasoning required (e.g., comparison, counting, arithmetic). Extract all relevant numerical values and associated entities or events."
        )

        # Step 2: Parallel Exploration — Generate multiple solution strategies based on detected patterns
        task1 = self.generate(
            instruction="Based on the analysis, generate a step-by-step plan to solve this using explicit extraction and direct computation.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Generate an alternative approach focusing on identifying implicit comparisons or relationships in the text that may affect the answer.",
            context=analysis
        )
        task3 = self.generate(
            instruction="Create a structured summary of all named entities and their associated counts or values for precise tracking.",
            context=analysis
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble — Synthesize competing interpretations into one robust solution
        final_solution = await self.ensemble(
            instruction="Evaluate the three candidate solutions. Identify which one aligns best with the question intent and provides the most accurate answer based on evidence from the passage.",
            contexts_to_ensemble=solutions
        )

        # Step 4: Refinement — Improve clarity and correctness through targeted revision
        refined_solution = await self.revise(
            instruction="Review the final solution carefully. Ensure it correctly addresses the question, includes necessary calculations, and avoids ambiguous references or missing entities.",
            context_to_revise=final_solution
        )

        return refined_solution