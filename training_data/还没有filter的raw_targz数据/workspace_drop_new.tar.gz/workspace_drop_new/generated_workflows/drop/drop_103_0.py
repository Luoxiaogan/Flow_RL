# Workflow ID: drop_103_0
# Benchmark: drop
# Data Indices: [52, 203]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question type and passage structure
        analysis = await self.generate(
            instruction="Analyze the question and passage to determine the required reasoning type (e.g., arithmetic, counting, comparison, span extraction). Also identify key entities and numerical values."
        )

        # Step 2: Extract all relevant facts from the passage in parallel (for efficiency and completeness)
        extract_tasks = [
            self.generate(instruction="Extract all named entities mentioned in the passage."),
            self.generate(instruction="Extract all numerical values with their associated context (e.g., 'Tom Brady scored 3 touchdowns' -> ['Tom Brady', '3'])."),
            self.generate(instruction="Extract all temporal markers (dates, time periods) relevant to events.")
        ]
        extracted_facts = await asyncio.gather(*extract_tasks)

        # Step 3: Use the analysis to decide the appropriate reasoning path
        if "how many" in analysis.lower() or "total" in analysis.lower():
            # Arithmetic or counting task — generate solution based on extracted numbers
            num_context = "\n".join([f"Fact: {fact}" for fact in extracted_facts[1].split("\n") if "number" in fact.lower()])
            solution = await self.generate(
                instruction="Based on the extracted numerical facts, compute the answer using addition, subtraction, or other operations as needed.",
                context=num_context
            )
        elif "which" in analysis.lower() and ("first" in analysis.lower() or "last" in analysis.lower()):
            # Temporal ordering — compare dates/events
            date_context = "\n".join([f"Fact: {fact}" for fact in extracted_facts[2].split("\n") if "date" in fact.lower()])
            solution = await self.generate(
                instruction="Using the timeline facts, determine which event occurred first or last based on chronological order.",
                context=date_context
            )
        elif "who" in analysis.lower() or "what" in analysis.lower():
            # Span extraction — find entity matching the question
            entity_context = "\n".join([f"Fact: {fact}" for fact in extracted_facts[0].split("\n") if "entity" in fact.lower()])
            solution = await self.generate(
                instruction="Identify the correct entity that answers the question by matching it with the passage's context.",
                context=entity_context
            )
        else:
            # General fallback — summarize and reason
            combined_context = "\n\n".join(extracted_facts)
            summary = await self.summarize(context_to_summarize=combined_context)
            solution = await self.generate(
                instruction="Based on the summarized information, provide a precise answer to the question.",
                context=summary
            )

        # Step 4: Optional refinement via revision for accuracy
        refined_solution = await self.revise(
            instruction="Review the generated solution for logical consistency, correctness, and clarity. If any issues are found, revise accordingly.",
            context_to_revise=solution
        )

        # Step 5: Ensemble multiple solutions if possible (enhances robustness)
        # Generate two alternative approaches for critical cases (e.g., math-heavy questions)
        if "how many" in analysis.lower() or "difference" in analysis.lower():
            alt_solution = await self.generate(
                instruction="Generate an alternative solution path focusing on step-by-step arithmetic reasoning.",
                context=analysis
            )
            final_answer = await self.ensemble(
                instruction="Choose the best answer between the original and alternative solutions based on internal consistency and clarity.",
                contexts_to_ensemble=[refined_solution, alt_solution]
            )
        else:
            final_answer = refined_solution

        return final_answer