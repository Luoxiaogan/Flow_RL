# Workflow ID: drop_149_0
# Benchmark: drop
# Data Indices: [108, 67]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to detect question type and key entities
        analysis = await self.generate(
            instruction="Analyze the passage and question. Identify whether this requires arithmetic reasoning, counting, comparison, span extraction, or multi-hop inference. Also extract all named entities, dates, numbers, and relationships mentioned."
        )

        # Step 2: Parallel exploration of different reasoning paths based on detected intent
        task1 = self.generate(
            instruction="If this is an arithmetic or counting question, list all relevant numerical values and their associated entities.",
            context=analysis
        )
        task2 = self.generate(
            instruction="If this is a comparison question, identify the two items being compared and their respective values.",
            context=analysis
        )
        task3 = self.generate(
            instruction="If this involves entity tracking or span extraction, locate all candidate answers in the passage and explain why each might be correct.",
            context=analysis
        )

        results = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble the three perspectives to form a comprehensive solution
        ensemble_result = await self.ensemble(
            instruction="Synthesize the three approaches above into one coherent answer. Prioritize clarity, correctness, and alignment with the original question.",
            contexts_to_ensemble=results
        )

        # Step 4: Refine using iterative revision to catch potential errors
        revised_solution = await self.revise(
            instruction="Critically review the ensemble result for logical consistency, numerical accuracy, and proper entity-number association. Fix any identified issues.",
            context_to_revise=ensemble_result
        )

        # Step 5: Final summary to ensure the output is concise yet complete
        final_answer = await self.summarize(
            context_to_summarize=revised_solution
        )

        return final_answer