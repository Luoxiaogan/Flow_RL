# Workflow ID: drop_17_0
# Benchmark: drop
# Data Indices: [241, 93]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question intent and extract key entities
        analysis = await self.generate(
            instruction="Analyze the question and passage to identify what type of reasoning is required (e.g., counting, comparison, arithmetic). Also list all relevant numerical values and their associated entities."
        )

        # Step 2: Extract structured facts from the passage based on analysis
        extraction = await self.generate(
            instruction="Based on the analysis, extract all relevant numerical data points with their corresponding entities in a clear format like 'Entity: Value'.",
            context=analysis
        )

        # Step 3: Generate multiple solution strategies using parallel exploration
        task1 = self.generate(
            instruction="Generate a step-by-step solution assuming this is a simple count-based question.",
            context=extraction
        )
        task2 = self.generate(
            instruction="Generate a step-by-step solution assuming this requires comparing values across entities.",
            context=extraction
        )
        task3 = self.generate(
            instruction="Generate a step-by-step solution assuming this involves filtering based on thresholds (e.g., under X).",
            context=extraction
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble the competing solutions to select the best one
        final_answer = await self.ensemble(
            instruction="Select the most accurate and coherent answer among the three candidates based on alignment with the original question and consistency with extracted facts.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional refinement if uncertainty remains
        refined_answer = await self.revise(
            instruction="If the answer lacks clarity or precision, improve it by focusing on exact matching of the question's requirements.",
            context_to_revise=final_answer
        )

        return refined_answer