# Workflow ID: drop_60_0
# Benchmark: drop
# Data Indices: [173, 268]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question type and key entities
        analysis = await self.generate(
            instruction="Analyze the passage and question. Identify the required reasoning type (e.g., arithmetic, counting, comparison, span extraction) and list all relevant entities and numerical values."
        )

        # Step 2: Extract structured data from the passage
        extracted_data = await self.generate(
            instruction="Extract all named entities and their associated numeric values relevant to the question. Format as bullet points: 'Entity: Value'.",
            context=analysis
        )

        # Step 3: Generate multiple candidate solutions based on different interpretations
        candidates = []
        tasks = [
            self.generate("Generate solution assuming the question requires summing values.", context=extracted_data),
            self.generate("Generate solution assuming the question requires finding differences between values.", context=extracted_data),
            self.generate("Generate solution assuming the question requires identifying the maximum/minimum value.", context=extracted_data),
            self.generate("Generate solution assuming the question requires selecting a specific entity by name or role.", context=extracted_data)
        ]
        candidates = await asyncio.gather(*tasks)

        # Step 4: Ensemble to select the best solution
        final_answer = await self.ensemble(
            instruction="Select the most accurate answer based on the evidence in the passage and the logical consistency of each candidate.",
            contexts_to_ensemble=candidates
        )

        # Step 5: Optional refinement if ambiguity remains
        if "uncertain" in final_answer.lower() or "not clear" in final_answer.lower():
            refined_answer = await self.revise(
                instruction="Revise the answer based on clearer interpretation of the question intent and entity-number associations.",
                context_to_revise=final_answer
            )
            return refined_answer

        return final_answer