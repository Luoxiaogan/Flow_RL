# Workflow ID: drop_138_0
# Benchmark: drop
# Data Indices: [7, 42]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question intent and passage structure
        analysis = await self.generate(
            instruction="Analyze the question and passage to identify key entities, numerical references, and reasoning type (e.g., span extraction, counting, arithmetic)."
        )

        # Step 2: Extract all relevant information from the passage
        extraction = await self.generate(
            instruction="Extract all named entities, numbers, and relationships mentioned in the passage that could be relevant to answering the question.",
            context=analysis
        )

        # Step 3: Generate multiple candidate solutions using different reasoning paths
        task1 = self.generate(
            instruction="Generate a solution based on direct span extraction from the passage.",
            context=extraction
        )
        task2 = self.generate(
            instruction="Generate a solution by focusing only on numerical values and their associated entities.",
            context=extraction
        )
        task3 = self.generate(
            instruction="Generate a solution assuming the question requires multi-hop inference or entity disambiguation.",
            context=extraction
        )

        # Run parallel exploration
        candidates = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble the candidate solutions to select the most robust answer
        final_answer = await self.ensemble(
            instruction="Select the best answer among the three generated candidates based on consistency, clarity, and relevance to the original question.",
            contexts_to_ensemble=candidates
        )

        # Step 5: Optional refinement if confidence is low
        if "uncertain" in final_answer.lower() or "not clear" in final_answer.lower():
            refined = await self.revise(
                instruction="Revise the answer to resolve ambiguity or improve precision using additional reasoning.",
                context_to_revise=final_answer
            )
            return refined

        return final_answer