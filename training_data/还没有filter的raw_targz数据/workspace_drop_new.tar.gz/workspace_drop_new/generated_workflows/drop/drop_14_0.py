# Workflow ID: drop_14_0
# Benchmark: drop
# Data Indices: [264, 289]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question intent and key entities
        analysis = await self.generate(
            instruction="Analyze the passage and question. Identify the type of reasoning required (e.g., arithmetic, counting, comparison) and extract all relevant numerical values with their associated entities."
        )

        # Step 2: Parallel exploration of different interpretation paths based on question type
        tasks = [
            self.generate(
                instruction="Extract all numeric values and their context from the passage for potential use in calculations.",
                context=analysis
            ),
            self.generate(
                instruction="Identify all named entities mentioned in the passage that might be relevant to answering the question.",
                context=analysis
            )
        ]
        extracted_values, entity_list = await asyncio.gather(*tasks)

        # Step 3: Generate candidate solutions using both structured data
        solution_from_values = await self.generate(
            instruction="Using only the extracted values, generate a step-by-step solution to answer the question.",
            context=extracted_values
        )
        solution_from_entities = await self.generate(
            instruction="Using only the identified entities, generate a step-by-step solution to answer the question.",
            context=entity_list
        )

        # Step 4: Ensemble to resolve conflicts or combine strengths
        final_answer = await self.ensemble(
            instruction="Compare the two generated solutions. If they agree, return the common answer. If they differ, choose the one most consistent with the original passage and question.",
            contexts_to_ensemble=[solution_from_values, solution_from_entities]
        )

        # Step 5: Optional refinement if needed — detect ambiguity or uncertainty
        revised_answer = await self.revise(
            instruction="If the answer appears uncertain or incomplete, refine it based on logical consistency and evidence from the passage.",
            context_to_revise=final_answer
        )

        return revised_answer