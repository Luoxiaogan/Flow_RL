# Workflow ID: drop_88_0
# Benchmark: drop
# Data Indices: [140, 30]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis – Understand the question type and extract key entities
        analysis = await self.generate(
            instruction="Analyze the question to determine its type (e.g., arithmetic, counting, comparison, span extraction) and identify all relevant entities or numbers in the passage."
        )

        # Step 2: Extract Structured Facts – Pull out all potentially relevant data points
        facts = await self.generate(
            instruction="Extract all numeric values and associated entities from the passage that might be relevant to answering the question.",
            context=analysis
        )

        # Step 3: Parallel Exploration – Generate multiple solution paths based on different interpretations
        task1 = self.generate(
            instruction="Generate a step-by-step solution assuming this is an arithmetic question involving subtraction or difference.",
            context=facts
        )
        task2 = self.generate(
            instruction="Generate a step-by-step solution assuming this is a simple count or span-based question.",
            context=facts
        )
        task3 = self.generate(
            instruction="Generate a step-by-step solution assuming this involves identifying the correct time period or year range.",
            context=facts
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble – Synthesize the best answer from diverse perspectives
        final_answer = await self.ensemble(
            instruction="Select the most consistent and logically supported answer among the three generated solutions. If there's disagreement, explain why one is preferred.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional Refinement – Revise if the answer seems ambiguous or incomplete
        if "not sure" in final_answer.lower() or "?" in final_answer:
            final_answer = await self.revise(
                instruction="Revise the answer to resolve ambiguity. Focus on clarifying which entity-number pair was used and how it leads to the final result.",
                context_to_revise=final_answer
            )

        return final_answer