# Workflow ID: drop_28_0
# Benchmark: drop
# Data Indices: [151, 169]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question intent and extract key entities
        analysis = await self.generate(
            instruction="Analyze the passage and question to determine the required reasoning type (e.g., comparison, counting, arithmetic) and identify all relevant entities, events, or numerical values."
        )

        # Step 2: Extract structured data from the passage — critical for multi-hop problems
        extraction = await self.generate(
            instruction="Extract all named entities, dates, and numerical values relevant to answering the question. Format as bullet points with clear associations.",
            context=analysis
        )

        # Step 3: Generate multiple solution paths in parallel — handles ambiguity and ensures completeness
        task1 = self.generate(
            instruction="Based on the extracted facts, generate a direct answer by comparing the relevant values mentioned in the question.",
            context=extraction
        )
        task2 = self.generate(
            instruction="Generate an alternative solution path by focusing only on chronological order if the question involves time-based comparisons.",
            context=extraction
        )
        task3 = self.generate(
            instruction="Generate a third approach that checks for implicit relationships between entities not explicitly stated but implied by context.",
            context=extraction
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble the competing solutions to resolve contradictions and select the most robust answer
        final_answer = await self.ensemble(
            instruction="Select the best answer based on consistency across all three approaches. If there's disagreement, prioritize the one supported by explicit evidence over inferred or temporal reasoning.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional refinement loop — improve accuracy through iterative feedback
        refined_answer = await self.revise(
            instruction="Critique the final answer for logical consistency, entity alignment, and whether it fully addresses the original question. Revise if necessary.",
            context_to_revise=final_answer
        )

        return refined_answer