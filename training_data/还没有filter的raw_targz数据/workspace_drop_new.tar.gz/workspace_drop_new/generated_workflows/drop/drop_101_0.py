# Workflow ID: drop_101_0
# Benchmark: drop
# Data Indices: [281, 215]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand question type and key entities
        analysis = await self.generate(
            instruction="Analyze the question to identify whether it requires counting, arithmetic, comparison, or span extraction. Also extract all named entities and numerical references in the passage relevant to the question."
        )

        # Step 2: Parallel Exploration — Generate multiple solution paths based on detected intent
        task1 = self.generate(
            instruction="If the question involves counting or summing, list all instances of the target entity mentioned in the passage.",
            context=analysis
        )
        task2 = self.generate(
            instruction="If the question involves dates or comparisons, extract all relevant temporal facts and their values.",
            context=analysis
        )
        task3 = self.generate(
            instruction="If the question asks for a specific span (like name, phrase), locate all possible candidates and their contexts.",
            context=analysis
        )

        results = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble — Synthesize candidate solutions from different angles
        ensemble_result = await self.ensemble(
            instruction="Evaluate each candidate solution path. Choose the one that best matches the question's intent and has strongest evidence from the passage.",
            contexts_to_ensemble=results
        )

        # Step 4: Refinement Loop — Revise if needed using feedback from reasoning steps
        revised_solution = await self.revise(
            instruction="Critically review the final solution. Check for missing entities, incorrect associations, or logical errors. Improve clarity and precision.",
            context_to_revise=ensemble_result
        )

        return revised_solution