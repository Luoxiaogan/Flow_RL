# Workflow ID: drop_69_0
# Benchmark: drop
# Data Indices: [170, 210]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis - Understand the question type and structure
        analysis = await self.generate(
            instruction="Analyze the question to determine what kind of reasoning is required (e.g., counting, arithmetic, comparison, span extraction). Also identify key entities and numbers in the passage relevant to the question."
        )

        # Step 2: Extract Relevant Information - Identify all instances of entities and values
        extraction = await self.generate(
            instruction="Extract all relevant numerical values and their associated entities from the passage. For example, list each field goal with its yardage and kicker name, or each demographic value with its category.",
            context=analysis
        )

        # Step 3: Generate Multiple Solutions Based on Different Interpretations
        # Use parallel exploration for ambiguous problems like "second most"
        task1 = self.generate(
            instruction="Generate a solution assuming the question asks for the entity with the second-highest count of occurrences (e.g., field goals).",
            context=extraction
        )
        task2 = self.generate(
            instruction="Generate a solution assuming the question requires identifying the entity that appears second in chronological order.",
            context=extraction
        )
        task3 = self.generate(
            instruction="Generate a solution assuming the question involves comparing totals across categories (e.g., total points scored by each team).",
            context=extraction
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer - Choose best-supported solution
        final_answer = await self.ensemble(
            instruction="Select the most accurate answer based on consistency with the passage and logical coherence. Reject contradictory or unsupported interpretations.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Revise for Precision - Check for common errors (e.g., misidentifying 'second' as first)
        revised_answer = await self.revise(
            instruction="Review the final answer carefully. Ensure it correctly identifies the second highest count, not the first. Also verify that all numbers are properly attributed to correct entities.",
            context_to_revise=final_answer
        )

        return revised_answer