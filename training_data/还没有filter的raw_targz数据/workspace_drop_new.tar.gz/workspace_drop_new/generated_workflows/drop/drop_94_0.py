# Workflow ID: drop_94_0
# Benchmark: drop
# Data Indices: [177, 243]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand the question type and extract key entities
        analysis = await self.generate(
            instruction="Analyze the question to determine the required reasoning type (e.g., arithmetic, counting, comparison, span extraction). Identify all relevant entities, numbers, and relationships in the passage that may be needed to answer it."
        )

        # Step 2: Parallel Extraction — Extract structured facts from passage using multiple strategies
        task1 = self.generate(
            instruction="Extract all numerical values mentioned in the passage along with their associated entities or contexts (e.g., field goals, players, dates)."
        )
        task2 = self.generate(
            instruction="Identify all named entities (people, teams, locations) that appear in the passage and note their roles or associations."
        )
        task3 = self.generate(
            instruction="List all comparative statements or implicit relations (e.g., 'more than', 'greater than', 'longer than') and their referents."
        )
        
        results = await asyncio.gather(task1, task2, task3)
        extracted_facts = "\n\n".join(results)

        # Step 3: Generate Multiple Candidate Solutions Based on Different Reasoning Paths
        solution_math = await self.generate(
            instruction="If the question involves arithmetic, counting, or comparisons, solve it directly using the extracted facts.",
            context=extracted_facts
        )
        solution_span = await self.generate(
            instruction="If the question asks for a specific entity or phrase, identify the correct one by matching context clues and coreference resolution.",
            context=extracted_facts
        )
        solution_inference = await self.generate(
            instruction="If the question requires inference (not directly stated), derive the answer based on logical deduction from the passage.",
            context=extracted_facts
        )

        # Step 4: Ensemble Final Answer — Compare and synthesize candidate solutions
        final_answer = await self.ensemble(
            instruction="Compare the three candidate solutions and select the most consistent, well-supported answer based on evidence from the passage. If there's disagreement, prioritize clarity and direct textual support.",
            contexts_to_ensemble=[solution_math, solution_span, solution_inference]
        )

        # Step 5: Optional Refinement — Use revision if uncertainty remains
        refined_answer = await self.revise(
            instruction="Critique the final answer: does it match the question intent? Is it supported by explicit or implicit evidence in the passage? Revise only if necessary.",
            context_to_revise=final_answer
        )

        return refined_answer