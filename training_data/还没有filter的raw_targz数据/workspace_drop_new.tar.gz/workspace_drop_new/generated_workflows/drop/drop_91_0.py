# Workflow ID: drop_91_0
# Benchmark: drop
# Data Indices: [220, 110]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question intent and passage structure
        analysis = await self.generate(
            instruction="Analyze the question and passage to identify key entities, numerical values, and reasoning type (e.g., counting, arithmetic, comparison)."
        )

        # Step 2: Extract relevant facts from the passage in parallel — both explicit and implicit
        extract_tasks = [
            self.generate("Extract all named entities mentioned in the passage.", context=analysis),
            self.generate("List all numerical values with their associated context (e.g., yardage, count, percentage).", context=analysis),
            self.generate("Identify any comparative or relational phrases that might affect interpretation.", context=analysis)
        ]
        extracted_facts_raw = await asyncio.gather(*extract_tasks)

        # Step 3: Summarize extracted information into structured format
        summarized_context = await self.summarize("\n\n".join(extracted_facts_raw))

        # Step 4: Generate multiple candidate solutions based on different interpretations
        candidates = []
        if "how many" in analysis.lower():
            candidates.append(await self.generate("Generate a solution focusing on counting all instances matching the criteria in the question.", context=summarized_context))
        if "difference" in analysis.lower() or "more" in analysis.lower():
            candidates.append(await self.generate("Generate a solution involving subtraction or comparison between two values.", context=summarized_context))
        if "percent" in analysis.lower() or "percentage" in analysis.lower():
            candidates.append(await self.generate("Generate a solution involving percentage calculation based on total and subset values.", context=summarized_context))

        # Step 5: Ensemble the best answer from competing interpretations
        final_answer = await self.ensemble(
            instruction="Select the most accurate answer by comparing all generated solutions. If there's disagreement, resolve based on clarity, alignment with the question, and logical consistency.",
            contexts_to_ensemble=candidates
        )

        # Step 6: Revise final output for precision and clarity
        refined_answer = await self.revise(
            instruction="Refine the final answer to ensure it directly addresses the question without ambiguity, using only the information explicitly supported by the passage.",
            context_to_revise=final_answer
        )

        return refined_answer