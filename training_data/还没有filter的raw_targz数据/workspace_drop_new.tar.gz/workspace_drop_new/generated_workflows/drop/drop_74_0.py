# Workflow ID: drop_74_0
# Benchmark: drop
# Data Indices: [34, 82]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand the question type and key entities
        analysis = await self.generate(
            instruction="Analyze the passage and question to identify the required reasoning type (e.g., arithmetic, counting, comparison) and relevant entities or values."
        )

        # Step 2: Extract Key Facts — Pull out all numeric data and entity references
        extraction = await self.generate(
            instruction="Extract all numerical values, dates, and named entities from the passage that may be relevant to answering the question.",
            context=analysis
        )

        # Step 3: Parallel Hypothesis Generation — Generate multiple candidate solutions based on different interpretations
        task1 = self.generate(
            instruction="Generate a solution assuming the question asks for a sum of all mentioned values related to the target concept.",
            context=extraction
        )
        task2 = self.generate(
            instruction="Generate a solution focusing only on the most recent or final value mentioned in the passage that matches the question's intent.",
            context=extraction
        )
        task3 = self.generate(
            instruction="Generate a solution by identifying the exact phrase or sentence in the passage that directly answers the question.",
            context=extraction
        )

        # Execute parallel hypotheses
        results = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble — Synthesize the best answer from competing solutions
        final_answer = await self.ensemble(
            instruction="Select the most accurate and consistent answer from the following three candidates, considering which one aligns best with the original question and passage.",
            contexts_to_ensemble=results
        )

        # Step 5: Revise — Improve the final answer through meta-reflection
        refined_answer = await self.revise(
            instruction="Critique the final answer for clarity, precision, and correctness. If it lacks justification, add a brief explanation.",
            context_to_revise=final_answer
        )

        return refined_answer