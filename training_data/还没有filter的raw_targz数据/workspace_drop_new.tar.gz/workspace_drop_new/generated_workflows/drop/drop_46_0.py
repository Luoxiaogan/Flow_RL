# Workflow ID: drop_46_0
# Benchmark: drop
# Data Indices: [161, 107]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand question intent and extract key entities
        analysis = await self.generate(
            instruction="Analyze the question to determine what type of reasoning is required (e.g., arithmetic, counting, comparison, span extraction). Identify all relevant numerical values and entities mentioned in the passage that relate to the question."
        )

        # Step 2: Parallel Exploration — Generate multiple candidate solutions based on different interpretations
        task1 = self.generate(
            instruction="Extract all numerical facts from the passage relevant to the question.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Identify and resolve ambiguous references (pronouns or partial names) in the passage using context.",
            context=analysis
        )
        task3 = self.generate(
            instruction="Determine whether the answer requires explicit extraction, calculation, or inference from the passage.",
            context=analysis
        )
        
        results = await asyncio.gather(task1, task2, task3)
        extracted_facts, resolved_references, reasoning_type = results

        # Step 3: Diverge-Converge Pattern — Use each perspective to generate a solution
        solution1 = await self.generate(
            instruction="Based on the extracted facts, solve the problem directly if possible.",
            context=extracted_facts
        )
        solution2 = await self.generate(
            instruction="Using the resolved references, derive the correct answer by aligning entities with their associated values.",
            context=resolved_references
        )
        solution3 = await self.generate(
            instruction="Apply logical reasoning based on the determined reasoning type (arithmetic, count, etc.) to compute the answer.",
            context=reasoning_type
        )

        # Step 4: Ensemble Final Answer — Synthesize competing solutions into one robust output
        final_answer = await self.ensemble(
            instruction="Choose the most consistent and accurate answer among the three candidates. If there's disagreement, identify the source of conflict and select the best-supported option.",
            contexts_to_ensemble=[solution1, solution2, solution3]
        )

        # Optional: Iterative Refinement for high-stakes accuracy
        refined_answer = await self.revise(
            instruction="Review the final answer for clarity, correctness, and completeness. Ensure it addresses the original question precisely without introducing new assumptions.",
            context_to_revise=final_answer
        )

        return refined_answer