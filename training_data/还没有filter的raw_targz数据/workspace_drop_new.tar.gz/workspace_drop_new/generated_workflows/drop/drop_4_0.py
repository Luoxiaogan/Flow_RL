# Workflow ID: drop_4_0
# Benchmark: drop
# Data Indices: [285, 246]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question type and key entities
        analysis = await self.generate(
            instruction="Analyze the passage and question to determine the required reasoning type (e.g., arithmetic, counting, comparison, span extraction) and identify all relevant entities, numbers, and timepoints."
        )

        # Step 2: Extract structured facts from passage — crucial for disambiguation
        extraction = await self.generate(
            instruction="Extract all numerical values, named entities, and temporal markers from the passage that may be relevant to answering the question. Format as bullet points with clear entity-number associations.",
            context=analysis
        )

        # Step 3: Parallel exploration — generate multiple candidate solutions using different reasoning paths
        task1 = self.generate(
            instruction="Generate a solution by focusing on direct numerical relationships in the extracted facts.",
            context=extraction
        )
        task2 = self.generate(
            instruction="Generate a solution by focusing on chronological order and event sequences in the passage.",
            context=extraction
        )
        task3 = self.generate(
            instruction="Generate a solution by identifying and resolving ambiguous references (pronouns, partial names) in the passage.",
            context=extraction
        )

        # Run parallel candidates
        candidates = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble to select best answer based on consistency across approaches
        final_answer = await self.ensemble(
            instruction="Evaluate the three candidate solutions and select the most consistent, logically sound, and evidence-backed answer. If there's disagreement, prioritize the one supported by the clearest passage evidence.",
            contexts_to_ensemble=candidates
        )

        # Step 5: Optional refinement if needed — detect ambiguity or uncertainty
        if "uncertain" in final_answer.lower() or "multiple" in final_answer.lower():
            refined = await self.revise(
                instruction="Revise the answer by explicitly justifying why this particular interpretation is correct over others, based on the passage structure and logical coherence.",
                context_to_revise=final_answer
            )
            return refined

        return final_answer