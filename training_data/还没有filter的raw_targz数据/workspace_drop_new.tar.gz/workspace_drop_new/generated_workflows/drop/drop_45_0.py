# Workflow ID: drop_45_0
# Benchmark: drop
# Data Indices: [211, 134]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand question type and key entities
        analysis = await self.generate(
            instruction="Analyze the passage and question to identify the type of reasoning required (e.g., counting, arithmetic, comparison, span extraction). Also extract all relevant named entities and numerical values."
        )

        # Step 2: Parallel Exploration — Generate multiple interpretations or data extractions
        task1 = self.generate(
            instruction="Extract all explicit numerical facts from the passage, including dates, counts, scores, distances, etc.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Identify all events or actions that could contribute to answering the question, especially those involving quantities or comparisons.",
            context=analysis
        )
        task3 = self.generate(
            instruction="Determine if the question requires summing multiple instances, selecting one instance, or comparing values.",
            context=analysis
        )

        # Execute parallel tasks
        results = await asyncio.gather(task1, task2, task3)

        # Step 3: Diverge-Converge Pattern — Synthesize diverse perspectives
        summary = await self.summarize(context_to_summarize="\n".join(results))

        # Step 4: Hypothesis Testing — Generate candidate answers based on different interpretations
        hypothesis1 = await self.generate(
            instruction="Based on the summarized information, generate an answer assuming the question asks for a total count across all instances.",
            context=summary
        )
        hypothesis2 = await self.generate(
            instruction="Generate an alternative answer assuming the question refers to a single specific instance (e.g., first, last, or most prominent).",
            context=summary
        )
        hypothesis3 = await self.generate(
            instruction="Generate another answer based on implicit reasoning — e.g., inferring missing values from context like time spans or sequences.",
            context=summary
        )

        # Step 5: Ensemble Decision — Select best-supported answer
        final_answer = await self.ensemble(
            instruction="Evaluate the three candidate answers and choose the one most strongly supported by the passage. If uncertain, explain why.",
            contexts_to_ensemble=[hypothesis1, hypothesis2, hypothesis3]
        )

        # Step 6: Iterative Refinement — Self-check for common errors
        refined_answer = await self.revise(
            instruction="Review the final answer for logical consistency, correctness in number association, and alignment with the original question intent. Fix any identified issues.",
            context_to_revise=final_answer
        )

        return refined_answer