# Workflow ID: drop_48_0
# Benchmark: drop
# Data Indices: [123, 146]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question type and passage structure
        analysis = await self.generate(
            instruction="Analyze the question and passage to identify the required reasoning type (e.g., counting, arithmetic, comparison, span extraction) and key entities involved."
        )

        # Step 2: Extract all relevant numerical facts from the passage
        raw_facts = await self.generate(
            instruction="Extract all numeric values (like yards, scores, counts) and their associated entities or events from the passage. Format as 'Entity: Value' pairs.",
            context=analysis
        )

        # Step 3: Summarize extracted facts to reduce noise and highlight patterns
        summarized_facts = await self.summarize(context_to_summarize=raw_facts)

        # Step 4: Generate multiple candidate solutions based on different interpretations
        task1 = self.generate(
            instruction="Generate a solution assuming the question asks for a total sum of field goals.",
            context=summarized_facts
        )
        task2 = self.generate(
            instruction="Generate a solution assuming the question requires identifying the player with the most field goals in the first half.",
            context=summarized_facts
        )
        task3 = self.generate(
            instruction="Generate a solution focusing on counting occurrences of specific events (e.g., field goals by team).",
            context=summarized_facts
        )

        # Step 5: Run parallel exploration to handle ambiguity
        candidates = await asyncio.gather(task1, task2, task3)

        # Step 6: Ensemble the best solution based on consistency and clarity
        final_answer = await self.ensemble(
            instruction="Select the most accurate and coherent answer among the three candidates based on alignment with the original question intent.",
            contexts_to_ensemble=candidates
        )

        # Step 7: Optional refinement if needed — check for logical inconsistencies
        refined_answer = await self.revise(
            instruction="Review the final answer for correctness, clarity, and completeness. If it lacks precision, improve it using insights from the previous steps.",
            context_to_revise=final_answer
        )

        return refined_answer