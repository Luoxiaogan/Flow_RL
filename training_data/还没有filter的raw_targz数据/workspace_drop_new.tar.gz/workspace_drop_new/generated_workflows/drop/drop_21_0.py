# Workflow ID: drop_21_0
# Benchmark: drop
# Data Indices: [198, 126]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand the question type and key entities
        analysis = await self.generate(
            instruction="Analyze the question to determine its type (e.g., arithmetic, counting, comparison, span extraction) and identify all relevant entities or numbers in the passage."
        )

        # Step 2: Extract Relevant Information — Pull out all numeric facts and named entities
        extraction = await self.generate(
            instruction="Extract all numerical values and named entities that could be relevant to answering the question. Include context around each value.",
            context=analysis
        )

        # Step 3: Parallel Exploration — Generate multiple solution paths based on different interpretations
        task1 = self.generate(
            instruction="If this is an arithmetic question, calculate the required operation directly from the extracted values.",
            context=extraction
        )
        task2 = self.generate(
            instruction="If this is a comparative question, compare the relevant values and state which is greater or what the difference is.",
            context=extraction
        )
        task3 = self.generate(
            instruction="If this is a span extraction question, locate the exact text span that answers the question using entity tracking.",
            context=extraction
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble — Choose the best solution by evaluating consistency and relevance
        final_answer = await self.ensemble(
            instruction="Evaluate the three candidate solutions and select the one that best aligns with the original question and evidence from the passage.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Revise — Improve the answer if it lacks clarity or precision
        refined_answer = await self.revise(
            instruction="Refine the selected answer to ensure it precisely addresses the question, uses clear language, and includes only necessary information.",
            context_to_revise=final_answer
        )

        return refined_answer