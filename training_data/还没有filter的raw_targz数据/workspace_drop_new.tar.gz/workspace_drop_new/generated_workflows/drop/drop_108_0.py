# Workflow ID: drop_108_0
# Benchmark: drop
# Data Indices: [3, 90]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question type and key entities
        analysis = await self.generate(
            instruction="Analyze the passage and question. Identify the core reasoning task (e.g., arithmetic, counting, comparison, span extraction). Also extract all named entities relevant to the question."
        )

        # Step 2: Extract structured facts — focus on numbers and their associated entities
        extraction = await self.generate(
            instruction="From the passage, extract all numerical values and their associated entities or events. Format as a list of 'entity: value' pairs.",
            context=analysis
        )

        # Step 3: Parallel exploration — generate multiple candidate solutions based on different interpretations
        task1 = self.generate(
            instruction="Based on the extracted facts, directly answer the question if possible using exact matches.",
            context=extraction
        )
        task2 = self.generate(
            instruction="If the question requires inference (like comparisons or counts), reason step-by-step about how to compute the answer from the extracted facts.",
            context=extraction
        )
        task3 = self.generate(
            instruction="Generate an alternative interpretation of the question, especially focusing on ambiguous references (e.g., pronouns, partial names). Then solve it accordingly.",
            context=analysis
        )

        # Step 4: Use Ensemble to select the best solution among candidates
        results = await asyncio.gather(task1, task2, task3)
        final_answer = await self.ensemble(
            instruction="Choose the most accurate and well-supported answer from the three candidates. Consider clarity, consistency with the passage, and direct relevance to the question.",
            contexts_to_ensemble=results
        )

        # Step 5: Optional refinement via Revise if confidence is low
        revised = await self.revise(
            instruction="Review the final answer critically. If it lacks clarity, precision, or seems inconsistent with the passage, improve it.",
            context_to_revise=final_answer
        )

        return revised