# Workflow ID: drop_1_0
# Benchmark: drop
# Data Indices: [168, 5]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question type and passage structure
        analysis = await self.generate(
            instruction="Analyze the question and passage to determine the required reasoning type (e.g., counting, comparison, span extraction) and identify key entities, numbers, and relationships."
        )

        # Step 2: Extract structured information from the passage using parallel exploration
        extract_tasks = [
            self.generate("Extract all numerical values mentioned in the passage with their associated context.", context=analysis),
            self.generate("List all named entities (people, teams, events) mentioned in the passage.", context=analysis),
            self.generate("Identify all explicit mentions of field goals, touchdowns, or similar discrete events.", context=analysis)
        ]
        extracted_data = await asyncio.gather(*extract_tasks)

        # Step 3: Summarize the extracted data to reduce noise and focus on relevant facts
        summary = await self.summarize("\n\n".join(extracted_data))

        # Step 4: Generate multiple candidate solutions based on different interpretations
        hypotheses = [
            self.generate("Generate a solution assuming the question requires counting specific events (e.g., field goals).", context=summary),
            self.generate("Generate a solution focusing on entity-number associations (e.g., who scored what).", context=summary),
            self.generate("Generate a solution that involves comparing values or identifying differences.", context=summary)
        ]

        # Step 5: Ensemble the competing solutions to resolve ambiguity
        final_answer = await self.ensemble(
            instruction="Select the most consistent and accurate answer based on the evidence from the three candidate solutions.",
            contexts_to_ensemble=hypotheses
        )

        # Step 6: Optional refinement if confidence is low — detect uncertainty in final answer
        if "uncertain" in final_answer.lower() or "multiple" in final_answer.lower():
            refined = await self.revise(
                instruction="Refine the answer by re-examining the passage for any missed instances or misinterpreted relationships.",
                context_to_revise=final_answer
            )
            return refined

        return final_answer