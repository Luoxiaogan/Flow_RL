# Workflow ID: drop_85_0
# Benchmark: drop
# Data Indices: [208, 128]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question type and key entities
        analysis = await self.generate(
            instruction="Analyze the passage and question to identify the type of reasoning required (e.g., arithmetic, comparison, count, span extraction) and extract all relevant numerical or named entities."
        )

        # Step 2: Parallel exploration — generate multiple interpretations/strategies
        task1 = self.generate(
            instruction="Extract all numeric values from the passage along with their associated entities (e.g., receiver names and yardage).",
            context=analysis
        )
        task2 = self.generate(
            instruction="Identify all comparative statements in the passage that might relate to the question.",
            context=analysis
        )
        task3 = self.generate(
            instruction="List all named entities mentioned in the passage that could be relevant to answering the question.",
            context=analysis
        )

        results = await asyncio.gather(task1, task2, task3)

        # Step 3: Summarize each perspective to reduce noise
        summarized_1 = await self.summarize(results[0])
        summarized_2 = await self.summarize(results[1])
        summarized_3 = await self.summarize(results[2])

        # Step 4: Ensemble to select best approach based on relevance
        ensemble_instruction = "Based on the three perspectives (numeric data, comparisons, entity list), determine which strategy is most likely to yield the correct answer for this question."
        strategy = await self.ensemble(
            instruction=ensemble_instruction,
            contexts_to_ensemble=[summarized_1, summarized_2, summarized_3]
        )

        # Step 5: Generate solution using the chosen strategy
        solution = await self.generate(
            instruction=f"Using the selected strategy: '{strategy}', now solve the original question step-by-step.",
            context=analysis
        )

        # Step 6: Revise for precision — check if the solution matches expected answer format
        revise_instruction = "Review the generated solution for accuracy, clarity, and correctness. Ensure it directly addresses the question without ambiguity."
        final_solution = await self.revise(
            instruction=revise_instruction,
            context_to_revise=solution
        )

        return final_solution