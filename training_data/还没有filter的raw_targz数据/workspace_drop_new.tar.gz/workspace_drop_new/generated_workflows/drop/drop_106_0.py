# Workflow ID: drop_106_0
# Benchmark: drop
# Data Indices: [75, 130]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question type and key entities
        analysis = await self.generate(
            instruction="Analyze the passage and question to determine the required reasoning type (e.g., entity extraction, arithmetic, comparison) and identify all relevant named entities or numerical values."
        )

        # Step 2: Extract key information from passage in parallel (divergence)
        extract_tasks = [
            self.generate(instruction="Extract all named entities mentioned in the passage.", context=analysis),
            self.generate(instruction="Identify all numbers, percentages, or quantities mentioned in the passage.", context=analysis),
            self.generate(instruction="List all relationships between entities (e.g., roles, events, locations).", context=analysis)
        ]
        extracted_info = await asyncio.gather(*extract_tasks)

        # Step 3: Summarize the extracted information to reduce noise
        summary = await self.summarize(context_to_summarize="\n".join(extracted_info))

        # Step 4: Generate multiple candidate solutions based on different interpretations
        candidates = []
        if "how many" in analysis.lower() or "percent" in analysis.lower():
            candidates.append(await self.generate(
                instruction="Generate a solution focused on numerical reasoning using the summarized facts.",
                context=summary
            ))
        if "who" in analysis.lower() or "which" in analysis.lower():
            candidates.append(await self.generate(
                instruction="Generate a solution focused on entity identification and coreference resolution.",
                context=summary
            ))
        if "difference" in analysis.lower() or "more" in analysis.lower():
            candidates.append(await self.generate(
                instruction="Generate a solution focused on subtraction or comparison between two values.",
                context=summary
            ))

        # Step 5: Ensemble the candidate solutions to select the most consistent answer
        final_answer = await self.ensemble(
            instruction="Evaluate the following candidate answers and select the one that best matches the question's intent and is most supported by the passage.",
            contexts_to_ensemble=candidates
        )

        # Step 6: Revise the final answer for clarity and correctness
        refined_answer = await self.revise(
            instruction="Improve the clarity and precision of the final answer while ensuring it directly addresses the original question.",
            context_to_revise=final_answer
        )

        return refined_answer