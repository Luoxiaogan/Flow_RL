# Workflow ID: drop_76_0
# Benchmark: drop
# Data Indices: [171, 136]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question type and key entities
        analysis = await self.generate(
            instruction="Analyze the question and passage to identify the required reasoning type (e.g., arithmetic, counting, comparison, span extraction) and all relevant entities or values."
        )

        # Step 2: Extract all candidate numerical values and their associated entities
        extraction = await self.generate(
            instruction="Extract all numbers mentioned in the passage along with the entities they refer to. Format as: 'Entity: Value' pairs.",
            context=analysis
        )

        # Step 3: If question involves math or comparison, generate step-by-step solution
        if "how many" in analysis.lower() or "difference" in analysis.lower() or "more" in analysis.lower():
            math_solution = await self.generate(
                instruction="Using the extracted values and their entities, compute the answer based on the question's intent (e.g., sum, difference, count). Be explicit about which values are used and why.",
                context=extraction
            )
            
            # Optional refinement loop for mathematical accuracy
            refined_math = await self.revise(
                instruction="Review the math solution for logical consistency and correct calculation steps. Fix any errors in association or computation.",
                context_to_revise=math_solution
            )
            
            return refined_math
        
        # Step 4: For span extraction questions (e.g., who did what), generate answer directly
        elif "who" in analysis.lower() or "what was the name" in analysis.lower():
            span_solution = await self.generate(
                instruction="Based on the passage and question, extract the exact text span that answers the question. Do not paraphrase — return the original phrase from the passage.",
                context=analysis
            )
            
            # Refine for clarity and correctness
            refined_span = await self.revise(
                instruction="Ensure the extracted span precisely matches the question. Remove any irrelevant text or ambiguity.",
                context_to_revise=span_solution
            )
            
            return refined_span
        
        # Step 5: For complex multi-hop or ambiguous cases, use parallel exploration + ensemble
        else:
            # Generate multiple interpretations
            hypo1 = await self.generate(
                instruction="Generate one possible interpretation of the question and its answer based on the passage.",
                context=analysis
            )
            
            hypo2 = await self.generate(
                instruction="Generate an alternative interpretation of the same question, focusing on different parts of the passage.",
                context=analysis
            )
            
            # Summarize each hypothesis
            summary1 = await self.summarize(hypo1)
            summary2 = await self.summarize(hypo2)
            
            # Ensemble to select best-supported answer
            final_answer = await self.ensemble(
                instruction="Choose the most plausible answer based on the evidence in both hypotheses. Justify briefly.",
                contexts_to_ensemble=[summary1, summary2]
            )
            
            return final_answer