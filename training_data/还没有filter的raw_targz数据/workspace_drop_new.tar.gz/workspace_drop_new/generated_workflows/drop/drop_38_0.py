# Workflow ID: drop_38_0
# Benchmark: drop
# Data Indices: [124, 50]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question type and passage structure
        analysis = await self.generate(
            instruction="Analyze the question and passage to determine the required reasoning type (e.g., counting, arithmetic, span extraction, comparison). Identify key entities and numerical values mentioned."
        )

        # Step 2: Extract structured facts — separate text spans and numbers
        extract_span = await self.generate(
            instruction="Extract all relevant text spans that could be answers (e.g., names, phrases).",
            context=analysis
        )
        extract_numbers = await self.generate(
            instruction="Extract all numerical values with their associated entities or events (e.g., '48-yard field goal by Matt Prater').",
            context=analysis
        )

        # Step 3: Parallel exploration — generate candidate solutions from different perspectives
        task1 = self.generate(
            instruction="Generate a solution based on the extracted spans.",
            context=extract_span
        )
        task2 = self.generate(
            instruction="Generate a solution based on the extracted numbers and their associations.",
            context=extract_numbers
        )
        task3 = self.generate(
            instruction="Generate a solution using both extracted spans and numbers together.",
            context=f"{extract_span}\n\n{extract_numbers}"
        )

        # Execute in parallel
        results = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble to select the best answer among competing interpretations
        final_answer = await self.ensemble(
            instruction="Choose the most accurate and coherent answer from the three generated solutions. Resolve conflicts if present.",
            contexts_to_ensemble=results
        )

        # Step 5: Optional refinement if the answer seems uncertain
        if "unknown" in final_answer.lower() or "not found" in final_answer.lower():
            refined_answer = await self.revise(
                instruction="Improve the answer by re-examining the original passage and the current solution. Focus on resolving ambiguity in entity-number associations.",
                context_to_revise=final_answer
            )
            return refined_answer

        return final_answer