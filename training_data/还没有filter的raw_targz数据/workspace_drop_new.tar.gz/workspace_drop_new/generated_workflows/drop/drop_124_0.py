# Workflow ID: drop_124_0
# Benchmark: drop
# Data Indices: [131, 240]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand the question type and key entities
        analysis = await self.generate(
            instruction="Analyze the question to determine its type (e.g., count, arithmetic, comparison, span extraction). Identify all key entities mentioned in both passage and question."
        )

        # Step 2: Extract Relevant Information — Focus on discrete facts from the passage
        extraction = await self.generate(
            instruction="Extract all relevant numerical values, named entities, and events from the passage that could be used to answer the question.",
            context=analysis
        )

        # Step 3: Parallel Exploration — Generate multiple candidate solutions based on different interpretations
        task1 = self.generate(
            instruction="Generate a solution assuming the question asks for the total sum of all relevant values.",
            context=extraction
        )
        task2 = self.generate(
            instruction="Generate a solution assuming the question requires identifying the single best match (e.g., longest pass, highest score).",
            context=extraction
        )
        task3 = self.generate(
            instruction="Generate a solution focusing only on explicit mentions without inference.",
            context=extraction
        )

        candidates = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble — Synthesize the best possible answer from competing solutions
        final_answer = await self.ensemble(
            instruction="Choose the most accurate and consistent answer among the three candidates based on clarity, relevance, and logical grounding in the passage.",
            contexts_to_ensemble=candidates
        )

        # Step 5: Revise — Improve the final answer by checking for common errors like misaligned numbers or ambiguous references
        refined_answer = await self.revise(
            instruction="Review the final answer carefully. If it contains any ambiguity, missing data, or incorrect associations between entities and values, revise it accordingly.",
            context_to_revise=final_answer
        )

        return refined_answer