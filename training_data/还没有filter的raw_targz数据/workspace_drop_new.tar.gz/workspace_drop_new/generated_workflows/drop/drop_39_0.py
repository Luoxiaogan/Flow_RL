# Workflow ID: drop_39_0
# Benchmark: drop
# Data Indices: [64, 85]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question intent and passage structure
        analysis = await self.generate(
            instruction="Analyze the passage and question to identify key entities, numerical references, and what type of reasoning is required (e.g., counting, comparison, span extraction, arithmetic)."
        )

        # Step 2: Extract all relevant information from the passage in parallel
        extract_tasks = [
            self.generate("Extract all named players and their associated statistics or events mentioned in the passage.", context=analysis),
            self.generate("Identify all time-related facts (dates, years, durations) in the passage.", context=analysis),
            self.generate("List all comparative or quantitative phrases (e.g., 'more than', 'how many', 'difference between') to guide further processing.", context=analysis)
        ]
        extracted_contexts = await asyncio.gather(*extract_tasks)

        # Step 3: Summarize each extracted context for clarity and focus
        summarized_contexts = [
            await self.summarize(extracted_contexts[0]),
            await self.summarize(extracted_contexts[1]),
            await self.summarize(extracted_contexts[2])
        ]

        # Step 4: Generate candidate solutions based on different interpretations
        candidates = []
        for i, summary in enumerate(summarized_contexts):
            if "player" in summary.lower() or "pass" in summary.lower():
                candidate = await self.generate(
                    instruction="Based on this summary, generate a solution to the question by identifying the correct player and their corresponding TD pass length.",
                    context=summary
                )
                candidates.append(candidate)
            elif "year" in summary.lower() or "date" in summary.lower():
                candidate = await self.generate(
                    instruction="Using this year-based summary, calculate the difference between the year the governor made the suggestion and when he became governor.",
                    context=summary
                )
                candidates.append(candidate)
            else:
                candidate = await self.generate(
                    instruction="Generate a possible answer based on this summary, focusing on direct extraction or simple inference.",
                    context=summary
                )
                candidates.append(candidate)

        # Step 5: Ensemble the candidate answers to reach a robust final answer
        final_answer = await self.ensemble(
            instruction="Compare the following candidate solutions and select the one that best addresses the original question with clear justification.",
            contexts_to_ensemble=candidates
        )

        # Optional: Final revision step to refine grammar, precision, or formatting
        refined_answer = await self.revise(
            instruction="Improve clarity, correctness, and conciseness of the final answer without changing its meaning.",
            context_to_revise=final_answer
        )

        return refined_answer