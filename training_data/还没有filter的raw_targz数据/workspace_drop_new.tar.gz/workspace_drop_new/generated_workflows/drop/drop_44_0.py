# Workflow ID: drop_44_0
# Benchmark: drop
# Data Indices: [20, 219]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Analyze the question to determine required reasoning type
        analysis = await self.generate(
            instruction="Identify the type of reasoning needed: arithmetic, counting, comparison, selection, or span extraction. Also note key entities and numerical references."
        )

        # Step 2: Extract all relevant structured facts from the passage
        extraction = await self.generate(
            instruction="Extract all relevant numerical values and their associated entities (e.g., '5,900 new schools'). Do not summarize — list everything explicitly.",
            context=analysis
        )

        # Step 3: Generate multiple candidate solutions based on different interpretations
        task1 = self.generate(
            instruction="Based on the extracted data, solve the question directly using exact matching and basic operations (e.g., count how many values are < 100).",
            context=extraction
        )
        task2 = self.generate(
            instruction="Generate an alternative interpretation of the question — perhaps involving implicit reasoning or entity disambiguation — and provide a solution accordingly.",
            context=analysis + "\n\n" + extraction
        )
        task3 = self.generate(
            instruction="Generate a third possible approach that involves comparing the magnitude of numbers across categories and identifying patterns.",
            context=extraction
        )

        # Step 4: Run parallel exploration and ensemble final answer
        candidates = await asyncio.gather(task1, task2, task3)
        final_answer = await self.ensemble(
            instruction="Select the most consistent and logically supported answer from the three candidates. If there's disagreement, explain why one is preferred over others.",
            contexts_to_ensemble=candidates
        )

        # Step 5: Optional refinement if the answer seems uncertain
        if "uncertain" in final_answer.lower() or "?" in final_answer:
            refined_answer = await self.revise(
                instruction="Refine the answer by re-examining the original passage and ensuring all relevant instances have been considered. Focus especially on ambiguous references or missing counts.",
                context_to_revise=final_answer
            )
            return refined_answer

        return final_answer