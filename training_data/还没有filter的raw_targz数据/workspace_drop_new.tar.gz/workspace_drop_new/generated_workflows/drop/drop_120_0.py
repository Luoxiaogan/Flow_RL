# Workflow ID: drop_120_0
# Benchmark: drop
# Data Indices: [255, 223]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question type and passage structure
        analysis = await self.generate(
            instruction="Analyze the passage and question to identify the required reasoning type (e.g., arithmetic, counting, comparison, span extraction). Also note key entities, numbers, and relationships."
        )

        # Step 2: Extract structured facts from passage for precise reasoning
        extracted_facts = await self.generate(
            instruction="Extract all relevant numerical values, named entities, and their associations from the passage. Format as bullet points with clear entity-number links.",
            context=analysis
        )

        # Step 3: Generate multiple solution paths based on different interpretations
        task1 = self.generate(
            instruction="Generate a solution assuming this is a simple span extraction question.",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Generate a solution assuming this involves numerical calculation or comparison.",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Generate a solution assuming this requires multi-hop inference or entity tracking across the passage.",
            context=extracted_facts
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble to select the most coherent and evidence-supported answer
        final_answer = await self.ensemble(
            instruction="Evaluate the three candidate solutions and select the one best supported by the passage. Prioritize clarity, correctness, and alignment with the question's intent.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Revise if needed — add a final check for consistency and completeness
        revised_answer = await self.revise(
            instruction="Review the final answer for accuracy, completeness, and whether it directly addresses the original question without ambiguity.",
            context_to_revise=final_answer
        )

        return revised_answer