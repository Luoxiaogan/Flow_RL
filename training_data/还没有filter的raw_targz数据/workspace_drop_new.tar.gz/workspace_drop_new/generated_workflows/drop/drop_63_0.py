# Workflow ID: drop_63_0
# Benchmark: drop
# Data Indices: [96, 299]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis - Understand question intent and extract key entities
        analysis = await self.generate(
            instruction="Analyze the passage and question to determine what type of reasoning is required (e.g., span extraction, counting, comparison, arithmetic). Identify all relevant entities mentioned in the passage that may be involved in answering the question."
        )

        # Step 2: Parallel Exploration - Extract different types of evidence
        task1 = self.generate(
            instruction="Extract all instances of players who caught touchdown passes, along with the yardage of each pass."
        )
        task2 = self.generate(
            instruction="Identify all field goal attempts by kickers and whether they were successful or not."
        )
        task3 = self.generate(
            instruction="List all numerical values related to scores, yardages, or counts that might be needed for calculation."
        )
        extracted_data = await asyncio.gather(task1, task2, task3)

        # Step 3: Diverge-Converge Strategy - Generate multiple interpretations/solutions
        solution_candidates = []
        for i, data in enumerate(extracted_data):
            candidate = await self.generate(
                instruction=f"Based on the extracted data from source {i+1}, generate a candidate answer to the original question. Be precise and explicit about how the data supports your answer.",
                context=data
            )
            solution_candidates.append(candidate)

        # Step 4: Ensemble Decision - Select best-supported answer from candidates
        final_answer = await self.ensemble(
            instruction="Evaluate all candidate answers based on consistency with the passage, logical soundness, and alignment with the question's intent. Choose the single most reliable answer.",
            contexts_to_ensemble=solution_candidates
        )

        # Step 5: Optional Refinement - If answer seems ambiguous, revise once more
        if "multiple" in final_answer.lower() or "ambiguous" in final_answer.lower():
            final_answer = await self.revise(
                instruction="Refine the answer by resolving ambiguity using only direct evidence from the passage. Avoid speculation.",
                context_to_revise=final_answer
            )

        return final_answer