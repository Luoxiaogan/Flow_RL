# Workflow ID: drop_86_0
# Benchmark: drop
# Data Indices: [212, 32]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand question intent and key entities
        analysis = await self.generate(
            instruction="Analyze the question and passage to identify what type of reasoning is required (e.g., counting, comparison, span extraction). Also note all named entities mentioned in the passage that may be relevant."
        )

        # Step 2: Extract Key Facts — Create structured data from dense text
        extraction = await self.generate(
            instruction="Extract all relevant facts from the passage that could help answer the question. Focus on events, scores, times, and entity references.",
            context=analysis
        )

        # Step 3: Parallel Exploration — Generate multiple solution paths based on different interpretations
        task1 = self.generate(
            instruction="Generate a step-by-step plan assuming this is a counting or selection question (e.g., 'How many teams scored?' or 'Which team won?').",
            context=extraction
        )
        task2 = self.generate(
            instruction="Generate a step-by-step plan assuming this requires numerical reasoning (e.g., difference, total, ratio).",
            context=extraction
        )
        task3 = self.generate(
            instruction="Generate a step-by-step plan assuming this requires identifying a specific event or entity (span extraction).",
            context=extraction
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble — Synthesize best candidate answers from parallel paths
        final_answer = await self.ensemble(
            instruction="Based on the three solution paths, determine which one best matches the question's intent and provides the correct answer. If there is ambiguity, select the most supported by evidence.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Revise — Self-correct if necessary using feedback loop
        revised_answer = await self.revise(
            instruction="Review the final answer critically. Does it align with the question? Is it logically consistent with the extracted facts? If not, revise accordingly.",
            context_to_revise=final_answer
        )

        return revised_answer