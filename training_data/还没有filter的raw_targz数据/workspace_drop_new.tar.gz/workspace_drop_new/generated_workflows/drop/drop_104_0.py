# Workflow ID: drop_104_0
# Benchmark: drop
# Data Indices: [48, 218]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis – Understand question intent and passage structure
        analysis = await self.generate(
            instruction="Analyze the question and passage to identify key entities, numerical values, and what type of reasoning is required (e.g., counting, arithmetic, comparison, span extraction)."
        )

        # Step 2: Extract all relevant facts using parallel exploration
        extract_tasks = [
            self.generate(instruction="Extract all named entities mentioned in the passage with their associated numerical values.", context=analysis),
            self.generate(instruction="Identify all instances of events or actions that may be relevant to answering the question.", context=analysis),
            self.generate(instruction="List all explicit mentions of counts, totals, differences, or comparisons in the passage.", context=analysis)
        ]
        extracted_facts = await asyncio.gather(*extract_tasks)

        # Step 3: Summarize extracted facts for clarity and focus
        summarized_facts = await self.summarize(context_to_summarize="\n\n".join(extracted_facts))

        # Step 4: Generate multiple candidate solutions based on different interpretations
        candidates = []
        candidate_instructions = [
            "Generate a solution by focusing only on explicit numerical mentions.",
            "Generate a solution by tracking entity-number associations carefully.",
            "Generate a solution considering implicit information like 'total' or 'combined'."
        ]
        for instr in candidate_instructions:
            candidate = await self.generate(instruction=instr, context=summarized_facts)
            candidates.append(candidate)

        # Step 5: Ensemble to select best-supported answer from competing solutions
        final_answer = await self.ensemble(
            instruction="Select the most accurate and well-supported answer from the following candidate responses. Consider consistency, completeness, and alignment with the original question.",
            contexts_to_ensemble=candidates
        )

        # Step 6: Optional refinement if needed — check for ambiguity or errors
        if "ambiguous" in final_answer.lower() or "uncertain" in final_answer.lower():
            refined = await self.revise(
                instruction="Refine the answer by re-examining the passage for any missed details or misinterpretations. Focus on resolving ambiguities.",
                context_to_revise=final_answer
            )
            return refined

        return final_answer