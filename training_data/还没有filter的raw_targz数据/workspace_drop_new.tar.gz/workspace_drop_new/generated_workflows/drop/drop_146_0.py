# Workflow ID: drop_146_0
# Benchmark: drop
# Data Indices: [248, 83]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question intent and passage structure
        analysis = await self.generate(
            instruction="Analyze the question and passage to identify the type of reasoning required (e.g., arithmetic, counting, comparison, span extraction) and key entities involved."
        )

        # Step 2: Extract relevant numerical and textual facts from the passage
        extract_instruction = "Extract all relevant numerical values, percentages, dates, and named entities mentioned in the passage that could be related to the question."
        extracted_facts = await self.generate(
            instruction=extract_instruction,
            context=analysis
        )

        # Step 3: Summarize extracted facts for clarity and focus
        summarized_facts = await self.summarize(context_to_summarize=extracted_facts)

        # Step 4: Generate multiple solution paths based on different interpretations
        diverse_solutions = [
            await self.generate(
                instruction="Generate a solution assuming the question asks for a direct percentage calculation.",
                context=summarized_facts
            ),
            await self.generate(
                instruction="Generate a solution assuming the question requires identifying an event that caused a specific consequence.",
                context=summarized_facts
            )
        ]

        # Step 5: Ensemble the solutions to resolve ambiguity or conflict
        final_answer = await self.ensemble(
            instruction="Select the most accurate answer based on the evidence provided in the passage and the consistency across both solutions.",
            contexts_to_ensemble=diverse_solutions
        )

        # Step 6: Revise the final answer if it lacks precision or contains errors
        revised_answer = await self.revise(
            instruction="Check for logical consistency, correctness of arithmetic, and proper entity association. Improve clarity and accuracy if needed.",
            context_to_revise=final_answer
        )

        return revised_answer