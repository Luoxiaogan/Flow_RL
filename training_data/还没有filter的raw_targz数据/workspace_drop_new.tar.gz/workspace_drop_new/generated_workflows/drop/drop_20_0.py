# Workflow ID: drop_20_0
# Benchmark: drop
# Data Indices: [202, 265]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question intent and passage structure
        analysis = await self.generate(
            instruction="Analyze the question and passage to determine what type of reasoning is required (e.g., counting, arithmetic, comparison, span extraction). Also identify key entities and numerical values."
        )

        # Step 2: Extract all relevant facts from the passage using parallel exploration
        extract_tasks = [
            self.generate(instruction="Extract all instances of touchdowns and their distances from the passage."),
            self.generate(instruction="Extract all field goals and their distances from the passage."),
            self.generate(instruction="Identify all named entities mentioned in the passage (e.g., players, teams, events).")
        ]
        extracted_facts = await asyncio.gather(*extract_tasks)

        # Step 3: Summarize the extracted facts to reduce noise and improve focus
        summarized_facts = await self.summarize(context_to_summarize="\n".join(extracted_facts))

        # Step 4: Generate multiple candidate solutions based on different interpretations
        candidates = []
        if "how many" in analysis.lower():
            candidates.append(await self.generate(
                instruction="Generate a solution focused on counting occurrences of the specified event or entity.",
                context=summarized_facts
            ))
        if "difference" in analysis.lower() or "more" in analysis.lower():
            candidates.append(await self.generate(
                instruction="Generate a solution focused on calculating the difference between two values mentioned in the passage.",
                context=summarized_facts
            ))
        if "which" in analysis.lower() or "who had more" in analysis.lower():
            candidates.append(await self.generate(
                instruction="Generate a solution focused on comparing values associated with different entities.",
                context=summarized_facts
            ))
        if "from what distances" in analysis.lower() or "what was the name of" in analysis.lower():
            candidates.append(await self.generate(
                instruction="Generate a solution focused on extracting exact spans or lists of values related to specific entities.",
                context=summarized_facts
            ))

        # Step 5: Ensemble the best candidate based on coherence and alignment with the question
        final_answer = await self.ensemble(
            instruction="Select the most accurate and coherent answer among the candidates based on how well each addresses the original question.",
            contexts_to_ensemble=candidates
        )

        # Step 6: Optional refinement via iterative revision if confidence is low
        if "not sure" in final_answer.lower() or "uncertain" in final_answer.lower():
            refined_answer = await self.revise(
                instruction="Improve the answer by resolving ambiguities and ensuring it directly addresses the question without unnecessary details.",
                context_to_revise=final_answer
            )
            return refined_answer

        return final_answer