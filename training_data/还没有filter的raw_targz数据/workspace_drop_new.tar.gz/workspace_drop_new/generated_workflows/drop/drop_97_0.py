# Workflow ID: drop_97_0
# Benchmark: drop
# Data Indices: [158, 69]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis
        analysis = await self.generate(
            instruction="Analyze the passage and question to identify key entities, numerical values, and required operations (e.g., sum, difference, count)."
        )

        # Step 2: Extract relevant facts in parallel — one for each likely data type
        task1 = self.generate(
            instruction="Extract all instances of 'yards' associated with touchdowns (passing or running) from the passage."
        )
        task2 = self.generate(
            instruction="Extract all field goal distances mentioned in the passage."
        )
        task3 = self.generate(
            instruction="Identify all scoring plays and their types (TD pass, TD run, FG, etc.) with yardage details."
        )
        extracted_facts = await asyncio.gather(task1, task2, task3)

        # Step 3: Summarize the extracted facts for clarity
        summarized_facts = await self.summarize(context_to_summarize="\n".join(extracted_facts))

        # Step 4: Generate multiple candidate solutions based on different interpretations
        solution1 = await self.generate(
            instruction="Based on the summarized facts, compute the difference between total passing touchdown yards and running touchdown yards.",
            context=summarized_facts
        )
        solution2 = await self.generate(
            instruction="Compute the total yards from all field goals mentioned in the passage.",
            context=summarized_facts
        )

        # Step 5: Ensemble the two solutions to resolve ambiguity or improve accuracy
        final_answer = await self.ensemble(
            instruction="Choose the correct answer based on the question's intent: if it asks about a difference, pick solution1; if it asks about total field goals, pick solution2.",
            contexts_to_ensemble=[solution1, solution2]
        )

        # Step 6: Optional refinement — revise if there's uncertainty
        refined_answer = await self.revise(
            instruction="Check for logical consistency: does the final answer match what the question explicitly asks? If not, adjust accordingly.",
            context_to_revise=final_answer
        )

        return refined_answer