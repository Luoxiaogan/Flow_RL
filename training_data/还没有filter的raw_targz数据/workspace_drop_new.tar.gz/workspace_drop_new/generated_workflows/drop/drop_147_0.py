# Workflow ID: drop_147_0
# Benchmark: drop
# Data Indices: [53, 56]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question type and passage structure
        analysis = await self.generate(
            instruction="Analyze the question and passage to determine the required reasoning type (e.g., span extraction, comparison, counting) and identify key entities or numbers."
        )

        # Step 2: Extract all relevant information in parallel to handle ambiguity and completeness
        extract_span = self.generate(
            instruction="Identify all named entities, dates, numerical values, and their associated contexts in the passage."
        )
        extract_numbers = self.generate(
            instruction="List all numerical values mentioned in the passage along with their referents (e.g., '5 apples' → value=5, entity='apples')."
        )
        extract_relations = self.generate(
            instruction="Extract explicit relationships between entities such as 'X has Y', 'Z occurs after W', etc."
        )
        extracted_data = await asyncio.gather(extract_span, extract_numbers, extract_relations)

        # Step 3: Summarize to reduce noise and highlight structured facts
        summarized = await self.summarize(context_to_summarize="\n\n".join(extracted_data))

        # Step 4: Generate multiple candidate solutions based on different interpretations
        if "which" in analysis.lower() or "who" in analysis.lower():
            # For selection questions
            candidates = [
                self.generate(instruction="Generate answer based on direct entity matching.", context=summarized),
                self.generate(instruction="Generate answer by focusing only on comparative or qualifying phrases in the passage.", context=summarized)
            ]
        elif "how many" in analysis.lower() or "total" in analysis.lower():
            # For counting/arithmetic questions
            candidates = [
                self.generate(instruction="Calculate total count of all instances matching the query.", context=summarized),
                self.generate(instruction="Calculate sum of all numeric values related to the queried entity.", context=summarized)
            ]
        else:
            # Default: generate solution using full context
            candidates = [self.generate(instruction="Generate a solution based on the summarized context.", context=summarized)]

        # Step 5: Ensemble to resolve ambiguity or conflicting answers
        final_answer = await self.ensemble(
            instruction="Choose the most accurate and coherent answer from the candidates, resolving any contradictions.",
            contexts_to_ensemble=candidates
        )

        # Step 6: Optional refinement if confidence is low (detect via language cues)
        if "uncertain" in final_answer.lower() or "possibly" in final_answer.lower():
            refined = await self.revise(
                instruction="Improve clarity and accuracy of the answer by addressing potential ambiguities or missing references.",
                context_to_revise=final_answer
            )
            return refined

        return final_answer