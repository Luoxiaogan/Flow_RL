# Workflow ID: drop_143_0
# Benchmark: drop
# Data Indices: [176, 205]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand the question type and extract key entities
        analysis = await self.generate(
            instruction="Analyze the question to determine its type (e.g., arithmetic, counting, comparison, span extraction). Identify all named entities, dates, numbers, and relationships mentioned in the passage relevant to the question."
        )

        # Step 2: Parallel Exploration — Generate multiple interpretations or solution paths
        task1 = self.generate(
            instruction="Extract all relevant numerical values and their associated entities from the passage.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Identify all temporal references (dates, time intervals) and their meanings in context.",
            context=analysis
        )
        task3 = self.generate(
            instruction="List all key entities and their roles or attributes mentioned in the passage.",
            context=analysis
        )

        results = await asyncio.gather(task1, task2, task3)

        # Step 3: Diverge-Converge — Summarize common elements across perspectives
        summary = await self.summarize(context_to_summarize="\n\n".join(results))

        # Step 4: Hypothesis Testing — Generate candidate solutions based on different interpretations
        hypothesis1 = await self.generate(
            instruction="Based on the summary, propose a step-by-step solution assuming this is an arithmetic difference question.",
            context=summary
        )
        hypothesis2 = await self.generate(
            instruction="Based on the summary, propose a step-by-step solution assuming this is a counting or selection question.",
            context=summary
        )
        hypothesis3 = await self.generate(
            instruction="Based on the summary, propose a step-by-step solution assuming this is a date-based interval question.",
            context=summary
        )

        # Step 5: Ensemble — Select best-supported solution using meta-evaluation
        final_answer = await self.ensemble(
            instruction="Evaluate the three proposed solutions and select the one that best fits the evidence in the passage and aligns with the question's intent.",
            contexts_to_ensemble=[hypothesis1, hypothesis2, hypothesis3]
        )

        # Step 6: Final Refinement — Revise for clarity, correctness, and completeness
        refined_answer = await self.revise(
            instruction="Improve the final answer by checking for logical consistency, numerical accuracy, and proper entity alignment.",
            context_to_revise=final_answer
        )

        return refined_answer