# Workflow ID: drop_35_0
# Benchmark: drop
# Data Indices: [88, 33]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand the question type and domain
        analysis = await self.generate(
            instruction="Analyze the question and passage to determine what type of reasoning is required (e.g., counting, arithmetic, comparison, span extraction). Also identify key entities and numerical values relevant to the answer."
        )

        # Step 2: Extract all relevant facts from the passage
        extraction = await self.generate(
            instruction="Extract all factual statements that could be relevant to answering the question. Focus on numbers, named entities, and relationships between them. Format as bullet points.",
            context=analysis
        )

        # Step 3: Generate multiple candidate solutions using different reasoning strategies
        tasks = [
            self.generate(
                instruction="Based on the extracted facts, generate a solution using a direct interpretation of the question. Assume this is the primary approach.",
                context=extraction
            ),
            self.generate(
                instruction="Now consider the possibility of multi-hop reasoning: look for implicit connections or comparisons across sentences that might affect the answer. Generate a solution based on this deeper inference.",
                context=extraction
            ),
            self.generate(
                instruction="Assume the question requires careful entity-number association — such as distinguishing between similar items (e.g., multiple minerals or field goals). Generate a solution focusing on correct mapping of values to entities.",
                context=extraction
            )
        ]
        candidates = await asyncio.gather(*tasks)

        # Step 4: Ensemble the candidate solutions to resolve conflicts and select the best one
        final_answer = await self.ensemble(
            instruction="Compare the three candidate solutions. Identify which one aligns best with the question intent, avoids ambiguity, and correctly handles entity-number associations. If there's disagreement, choose the most consistent and evidence-based answer.",
            contexts_to_ensemble=candidates
        )

        # Step 5: Optional refinement if needed — check for clarity, completeness, or errors
        refined_answer = await self.revise(
            instruction="Review the final answer carefully. Ensure it directly addresses the question without overcomplicating or omitting necessary details. If the answer seems unclear or incomplete, improve clarity while preserving accuracy.",
            context_to_revise=final_answer
        )

        return refined_answer