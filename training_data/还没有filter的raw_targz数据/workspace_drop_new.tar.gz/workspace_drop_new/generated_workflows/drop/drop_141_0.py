# Workflow ID: drop_141_0
# Benchmark: drop
# Data Indices: [267, 160]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question type and key entities
        analysis = await self.generate(
            instruction="Analyze the question and passage to identify the required reasoning type (e.g., counting, arithmetic, comparison) and relevant entities or events."
        )

        # Step 2: Extract all candidate instances relevant to the question
        extraction_instruction = "Identify all occurrences of entities or values that could be relevant to answering the question. List them clearly with their context."
        candidates = await self.generate(
            instruction=extraction_instruction,
            context=analysis
        )

        # Step 3: Parallel exploration — generate multiple interpretations/solutions
        task1 = self.generate("Generate one possible solution based on direct count of relevant events.", context=candidates)
        task2 = self.generate("Generate an alternative solution considering potential implicit references or multi-hop inference.", context=candidates)
        task3 = self.generate("Generate a third solution focusing on entity-number association accuracy.", context=candidates)
        
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble to select the most consistent and accurate answer
        final_answer = await self.ensemble(
            instruction="Select the best answer from the three generated solutions. Consider consistency, clarity, and alignment with the question intent.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional refinement if needed — check for ambiguity or inconsistency
        if "ambiguous" in final_answer.lower() or "uncertain" in final_answer.lower():
            refined_answer = await self.revise(
                instruction="Revise the answer to resolve ambiguity by re-examining the original passage for explicit mentions of the target quantity.",
                context_to_revise=final_answer
            )
            return refined_answer
        
        return final_answer