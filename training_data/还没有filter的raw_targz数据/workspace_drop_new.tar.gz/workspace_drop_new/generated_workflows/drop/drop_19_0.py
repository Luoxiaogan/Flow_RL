# Workflow ID: drop_19_0
# Benchmark: drop
# Data Indices: [11, 104]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question type and passage structure
        analysis = await self.generate(
            instruction="Analyze the question and passage to determine the required reasoning type (e.g., counting, comparison, span extraction, arithmetic). Also identify key entities, numbers, and relationships."
        )

        # Step 2: Extract structured facts from the passage — crucial for multi-hop reasoning
        extraction = await self.generate(
            instruction="Extract all relevant named entities, numerical values, and their associated contexts (e.g., player names, scores, times, events) in a clear, structured format like 'Entity: Value (Context)'",
            context=analysis
        )

        # Step 3: Generate multiple candidate solutions using different strategies
        # Parallel exploration: one focusing on direct extraction, another on inference
        task1 = self.generate(
            instruction="Based on the extracted facts, directly answer the question if possible.",
            context=extraction
        )
        task2 = self.generate(
            instruction="Use logical reasoning and context clues to infer the answer when it's not explicitly stated.",
            context=extraction
        )
        task3 = self.generate(
            instruction="Identify ambiguous references or pronouns and resolve them based on surrounding context.",
            context=extraction
        )
        results = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble the three candidates to select the most consistent answer
        final_answer = await self.ensemble(
            instruction="Choose the best answer among the three candidates. Prioritize consistency with the passage, clarity, and logical soundness.",
            contexts_to_ensemble=results
        )

        # Step 5: Revise for precision — check for common errors like misattribution or missing steps
        refined_answer = await self.revise(
            instruction="Review the final answer carefully. Check for entity-number mismatches, incorrect comparisons, or missing multi-hop links. If any issues found, revise accordingly.",
            context_to_revise=final_answer
        )

        return refined_answer