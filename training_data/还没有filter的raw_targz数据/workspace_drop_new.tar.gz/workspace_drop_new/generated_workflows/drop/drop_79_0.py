# Workflow ID: drop_79_0
# Benchmark: drop
# Data Indices: [226, 196]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question intent and key entities
        analysis = await self.generate(
            instruction="Analyze the passage and question to identify the type of reasoning required (e.g., comparison, counting, arithmetic). Also extract all named entities relevant to the question."
        )

        # Step 2: Parallel exploration of different reasoning paths based on detected intent
        task1 = self.generate(
            instruction="Extract all numerical facts from the passage that might be relevant to answering the question.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Identify all explicit comparisons or relationships between entities mentioned in the passage.",
            context=analysis
        )
        task3 = self.generate(
            instruction="List all entities mentioned in the passage with their associated attributes (e.g., backing countries, counts, dates).",
            context=analysis
        )

        results = await asyncio.gather(task1, task2, task3)

        # Step 3: Summarize each candidate solution path to reduce noise
        summaries = [
            await self.summarize(results[0]),
            await self.summarize(results[1]),
            await self.summarize(results[2])
        ]

        # Step 4: Ensemble the three summaries to produce a final reasoned answer
        final_answer = await self.ensemble(
            instruction="Based on the summarized evidence, determine the correct answer to the question. If multiple interpretations exist, choose the one best supported by the passage.",
            contexts_to_ensemble=summaries
        )

        # Step 5: Optional refinement if the answer seems ambiguous or incomplete
        if "uncertain" in final_answer.lower() or "multiple" in final_answer.lower():
            refined_answer = await self.revise(
                instruction="Revise the answer by focusing on the most unambiguous piece of evidence from the passage. Eliminate speculative elements.",
                context_to_revise=final_answer
            )
            return refined_answer

        return final_answer