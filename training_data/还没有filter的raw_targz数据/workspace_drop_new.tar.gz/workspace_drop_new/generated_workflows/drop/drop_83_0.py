# Workflow ID: drop_83_0
# Benchmark: drop
# Data Indices: [252, 183]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand question intent and extract key entities
        analysis = await self.generate(
            instruction="Analyze the passage and question to identify the type of reasoning required (e.g., counting, arithmetic, comparison, span extraction) and key entities involved."
        )

        # Step 2: Extract relevant facts — Focus on discrete, structured data points
        extraction = await self.generate(
            instruction="Extract all relevant numerical values, named entities, and temporal markers from the passage that could be used to answer the question.",
            context=analysis
        )

        # Step 3: Parallel Exploration — Generate multiple candidate solutions using different strategies
        task1 = self.generate(
            instruction="Generate a solution assuming the question requires simple span extraction.",
            context=extraction
        )
        task2 = self.generate(
            instruction="Generate a solution assuming the question requires multi-hop inference or entity-number association.",
            context=extraction
        )
        task3 = self.generate(
            instruction="Generate a solution assuming the question involves arithmetic operations like sum or difference.",
            context=extraction
        )

        # Execute parallel paths
        candidates = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble — Synthesize the best answer from competing solutions
        final_answer = await self.ensemble(
            instruction="Choose the most consistent and logically supported answer among the three candidates. If there's disagreement, prioritize based on clarity of evidence in the passage.",
            contexts_to_ensemble=candidates
        )

        # Step 5: Optional refinement — Revise if uncertainty remains
        revised_answer = await self.revise(
            instruction="Critique the final answer for accuracy, completeness, and logical consistency with the passage. Fix any inconsistencies.",
            context_to_revise=final_answer
        )

        return revised_answer