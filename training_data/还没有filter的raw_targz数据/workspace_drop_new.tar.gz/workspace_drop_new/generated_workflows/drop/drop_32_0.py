# Workflow ID: drop_32_0
# Benchmark: drop
# Data Indices: [231, 181]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand question type and extract key entities
        analysis = await self.generate(
            instruction="Analyze the passage and question to determine the required reasoning type (e.g., counting, arithmetic, span extraction). Also identify all relevant named entities mentioned in the passage that may relate to the answer."
        )

        # Step 2: Parallel Exploration — Generate multiple candidate solutions based on different interpretations
        task1 = self.generate(
            instruction="Extract all instances of entities related to the question, especially those with numerical values or descriptive attributes.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Identify all spans in the passage that could be potential answers to the question, focusing on explicit mentions and implicit references.",
            context=analysis
        )
        task3 = self.generate(
            instruction="Determine if the question involves comparison, summation, or selection among entities; describe how to resolve ambiguity if present.",
            context=analysis
        )

        results = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble — Synthesize diverse perspectives into one coherent solution
        ensemble_result = await self.ensemble(
            instruction="Combine the three candidate approaches: structured data extraction, span identification, and intent classification. Choose the most consistent and complete answer based on evidence from the passage.",
            contexts_to_ensemble=results
        )

        # Step 4: Refinement — Improve the final solution through targeted revision
        final_answer = await self.revise(
            instruction="Critically review the proposed answer for accuracy, clarity, and completeness. Ensure it directly addresses the question without overgeneralization or missing critical details.",
            context_to_revise=ensemble_result
        )

        return final_answer