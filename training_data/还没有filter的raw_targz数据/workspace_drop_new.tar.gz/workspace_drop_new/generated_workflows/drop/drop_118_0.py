# Workflow ID: drop_118_0
# Benchmark: drop
# Data Indices: [145, 227]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to detect question type and key entities
        analysis = await self.generate(
            instruction="Analyze the question and passage to identify the required reasoning type (e.g., arithmetic, counting, comparison, span extraction) and all relevant entities or numbers."
        )

        # Step 2: Extract structured facts from the passage using parallel exploration
        extract_task_1 = self.generate(
            instruction="Extract all numerical values mentioned in the passage along with their context (e.g., who, what, when)."
        )
        extract_task_2 = self.generate(
            instruction="Identify all named entities (people, teams, locations, events) and their associated actions or attributes."
        )
        extract_task_3 = self.generate(
            instruction="List time-related information such as dates, quarters, or sequences that might be relevant to temporal reasoning."
        )
        extracted_facts = await asyncio.gather(extract_task_1, extract_task_2, extract_task_3)

        # Step 3: Summarize the extracted facts to reduce noise and focus on relevance
        summarized_facts = await self.summarize(context_to_summarize="\n\n".join(extracted_facts))

        # Step 4: Generate multiple candidate solutions based on different interpretations
        solution_1 = await self.generate(
            instruction="Based on the summarized facts, generate a direct answer if possible.",
            context=summarized_facts
        )
        solution_2 = await self.generate(
            instruction="Now, consider only the numerical values and perform calculations step-by-step.",
            context=summarized_facts
        )
        solution_3 = await self.generate(
            instruction="If the question involves comparisons or selections, reason through each option using the passage details.",
            context=summarized_facts
        )

        # Step 5: Ensemble to select the most consistent and accurate answer
        final_answer = await self.ensemble(
            instruction="Compare the three generated solutions. Choose the one that best aligns with the original question and passage evidence. If there's disagreement, explain why.",
            contexts_to_ensemble=[solution_1, solution_2, solution_3]
        )

        # Step 6: Optional refinement loop for high-stakes accuracy
        if "uncertain" in final_answer.lower() or "multiple" in final_answer.lower():
            refined_answer = await self.revise(
                instruction="Revise the answer by checking for missing entities, incorrect associations, or ambiguous references. Ensure it directly answers the question.",
                context_to_revise=final_answer
            )
            return refined_answer

        return final_answer