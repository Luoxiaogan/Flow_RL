# Workflow ID: drop_6_0
# Benchmark: drop
# Data Indices: [214, 62]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand the question type and extract key elements
        analysis = await self.generate(
            instruction="Analyze the passage and question to identify the type of reasoning required (e.g., counting, arithmetic, comparison, span extraction). Also identify all entities and numerical values relevant to the question."
        )

        # Step 2: Parallel Exploration — Extract different kinds of information in parallel
        task1 = self.generate(instruction="Extract all named entities mentioned in the passage that could be relevant to answering the question.")
        task2 = self.generate(instruction="List all numeric values in the passage along with their associated entities or context.")
        task3 = self.generate(instruction="Identify explicit vs implicit information that might be needed to answer the question.")

        entity_extract, value_extract, info_type = await asyncio.gather(task1, task2, task3)

        # Step 3: Synthesize Context — Combine extracted pieces into structured knowledge
        synthesis = await self.generate(
            instruction="Using the extracted entities, values, and information types, synthesize a clear summary of what needs to be computed or retrieved to answer the question.",
            context=f"Entities: {entity_extract}\nValues: {value_extract}\nInfo Type: {info_type}"
        )

        # Step 4: Generate Candidate Solutions — Create multiple approaches based on interpretation
        math_approach = await self.generate(
            instruction="If the question involves arithmetic or counting, generate a step-by-step calculation plan using only the relevant values and entities from the synthesis.",
            context=synthesis
        )
        
        logical_approach = await self.generate(
            instruction="If the question requires identifying the most common, greatest, or specific item, generate a reasoning path based on comparing or selecting from the extracted data.",
            context=synthesis
        )

        # Step 5: Ensemble Final Answer — Choose best solution based on consistency and clarity
        final_answer = await self.ensemble(
            instruction="Evaluate both candidate solutions and select the one that most accurately answers the original question. If there's ambiguity, choose the more directly supported one.",
            contexts_to_ensemble=[math_approach, logical_approach]
        )

        # Step 6: Optional Refinement — If the answer seems uncertain, apply iterative revision
        if "uncertain" in final_answer.lower() or "?" in final_answer:
            refined_answer = await self.revise(
                instruction="Revise the answer by checking for any missed entities, incorrect associations, or ambiguous references. Ensure it directly addresses the question without overcomplicating.",
                context_to_revise=final_answer
            )
            return refined_answer

        return final_answer