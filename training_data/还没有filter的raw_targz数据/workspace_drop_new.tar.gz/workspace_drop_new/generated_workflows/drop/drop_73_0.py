# Workflow ID: drop_73_0
# Benchmark: drop
# Data Indices: [291, 22]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis - Understand question intent and key entities
        analysis = await self.generate(
            instruction="Analyze the passage and question to determine what type of reasoning is required (e.g., counting, arithmetic, span extraction). Identify all relevant entities mentioned in the passage that may relate to the answer."
        )

        # Step 2: Extract Relevant Information - Create structured facts from the passage
        extracted_facts = await self.generate(
            instruction="Extract all numerical data and related events from the passage that could be relevant to answering the question. Format as bullet points with clear entity-number associations.",
            context=analysis
        )

        # Step 3: Generate Multiple Candidate Solutions via Parallel Exploration
        task1 = self.generate(
            instruction="Based on the extracted facts, generate a solution by focusing only on explicit mentions of counts or numbers related to the question.",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Re-express the question as a mathematical query and solve it using only numeric values found in the passage, ignoring context.",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Identify the longest sequence of actions described in the passage and calculate its length if it matches the question's focus (e.g., 'longest drive').",
            context=extracted_facts
        )

        candidates = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer - Compare and select the most consistent solution
        final_answer = await self.ensemble(
            instruction="Compare the three candidate solutions. Choose the one that best aligns with the question intent, uses the most accurate evidence from the passage, and resolves any contradictions between them.",
            contexts_to_ensemble=candidates
        )

        # Step 5: Revise for Precision - Refine based on potential errors like miscounting or ambiguous references
        refined_answer = await self.revise(
            instruction="Review the final answer critically. Check for common pitfalls such as misattributing numbers to wrong entities, missing multi-hop dependencies, or failing to count all instances of an event. If needed, revise accordingly.",
            context_to_revise=final_answer
        )

        return refined_answer