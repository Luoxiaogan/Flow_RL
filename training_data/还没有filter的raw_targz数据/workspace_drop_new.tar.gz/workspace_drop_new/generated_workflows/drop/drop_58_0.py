# Workflow ID: drop_58_0
# Benchmark: drop
# Data Indices: [283, 6]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to detect question type and key entities
        analysis = await self.generate(
            instruction="Analyze the question and passage to identify the core reasoning task (e.g., comparison, count, arithmetic), key entities involved, and whether numerical or textual comparison is needed."
        )

        # Step 2: Extract relevant numerical facts from passage
        extraction = await self.generate(
            instruction="Extract all named entities with associated numerical values relevant to the question. Format as 'Entity: Value' pairs.",
            context=analysis
        )

        # Step 3: Parallel exploration of candidate answers using different strategies
        tasks = [
            self.generate(
                instruction="Generate a solution by directly comparing the extracted values from the passage.",
                context=extraction
            ),
            self.generate(
                instruction="Generate a solution by first summarizing the passage's key events and then inferring the answer based on that summary.",
                context=analysis
            ),
            self.generate(
                instruction="Generate a solution by identifying which entity in the passage corresponds to each value mentioned in the question.",
                context=extraction
            )
        ]
        candidates = await asyncio.gather(*tasks)

        # Step 4: Ensemble the best candidate based on consistency and clarity
        final_answer = await self.ensemble(
            instruction="Select the most accurate and consistent answer among the three generated solutions. If there is disagreement, choose the one that best aligns with the original question intent.",
            contexts_to_ensemble=candidates
        )

        # Step 5: Optional refinement if the answer seems ambiguous
        if "uncertain" in final_answer.lower() or "?" in final_answer:
            refined_answer = await self.revise(
                instruction="Refine the answer by re-evaluating the evidence from the passage and focusing only on what is explicitly stated or logically implied.",
                context_to_revise=final_answer
            )
            return refined_answer

        return final_answer