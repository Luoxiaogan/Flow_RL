# Workflow ID: drop_82_0
# Benchmark: drop
# Data Indices: [297, 156]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis - Understand question intent and key entities
        analysis = await self.generate(
            instruction="Analyze the question to determine what type of reasoning is required (e.g., counting, arithmetic, span extraction). Identify all relevant entities mentioned in the passage that could be related to the answer."
        )

        # Step 2: Extract Relevant Information - Pull out all potential candidates
        extraction = await self.generate(
            instruction="Extract all instances of relevant entities or numbers from the passage that might relate to the question. For example, if the question asks about field goals, extract every mention of a field goal, including who made it, distance, and time.",
            context=analysis
        )

        # Step 3: Parallel Exploration - Generate multiple interpretations or solutions
        task1 = self.generate(
            instruction="Based on the extracted data, generate a solution assuming this is a simple span extraction question (i.e., just list the items).",
            context=extraction
        )
        task2 = self.generate(
            instruction="Now, generate a solution assuming this is a multi-hop inference question — e.g., some information must be combined or inferred from context.",
            context=extraction
        )
        task3 = self.generate(
            instruction="Generate an alternative interpretation based on ambiguous references (e.g., pronouns like 'he' or 'they').",
            context=extraction
        )
        results = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer - Synthesize the best candidate
        final_answer = await self.ensemble(
            instruction="Choose the most accurate and complete answer among the three generated solutions. If there's disagreement, prioritize the one that aligns with explicit evidence over implicit assumptions.",
            contexts_to_ensemble=results
        )

        # Step 5: Optional Refinement - If needed, revise for clarity or correctness
        if "not fully resolved" in final_answer.lower():
            final_answer = await self.revise(
                instruction="Revise the answer to ensure it clearly addresses the original question without ambiguity. Focus on precision and completeness.",
                context_to_revise=final_answer
            )

        return final_answer