# Workflow ID: drop_130_0
# Benchmark: drop
# Data Indices: [81, 149]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis – Understand question intent and extract key entities
        analysis = await self.generate(
            instruction="Analyze the passage and question to determine what type of reasoning is needed (e.g., counting, arithmetic, comparison, span extraction). Identify all relevant named entities and numerical values."
        )

        # Step 2: Extract Structured Data – Turn dense text into usable facts
        extraction = await self.generate(
            instruction="Extract all relevant factual statements from the passage that could be used to answer the question. Format as bullet points with clear entity-number associations.",
            context=analysis
        )

        # Step 3: Parallel Reasoning Paths – Generate multiple solution approaches
        task1 = self.generate(
            instruction="Based on the extracted facts, generate a step-by-step solution assuming this is a simple count or direct lookup.",
            context=extraction
        )
        task2 = self.generate(
            instruction="Now generate a solution using multi-hop reasoning—connect related facts across sentences to infer the correct answer.",
            context=extraction
        )
        task3 = self.generate(
            instruction="Generate a solution focusing on resolving ambiguous references (like pronouns or partial names) in the passage.",
            context=extraction
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble – Synthesize best candidate answers
        final_answer = await self.ensemble(
            instruction="Choose the most accurate answer based on consistency, clarity, and alignment with the original question. If there's disagreement, explain why one is preferred.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional Refinement – Improve final answer if needed
        refined_answer = await self.revise(
            instruction="Review the final answer for completeness, correctness, and whether it fully addresses the question without unnecessary assumptions.",
            context_to_revise=final_answer
        )

        return refined_answer