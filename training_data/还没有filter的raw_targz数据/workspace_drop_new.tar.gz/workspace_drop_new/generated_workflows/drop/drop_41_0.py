# Workflow ID: drop_41_0
# Benchmark: drop
# Data Indices: [26, 65]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Analyze question type and extract key intent
        analysis = await self.generate(
            instruction="Identify the core reasoning task from the question: "
                        "Is it counting, arithmetic, comparison, span extraction, or multi-hop inference?"
        )

        # Step 2: Extract all relevant entities and values from passage
        extraction = await self.generate(
            instruction="Extract all named entities (people, teams, dates) and numerical values with their context.",
            context=analysis
        )

        # Step 3: If question involves numbers, generate structured facts for reasoning
        if "count" in analysis.lower() or "how many" in analysis.lower():
            structured_facts = await self.generate(
                instruction="Convert extracted data into structured key-value pairs for counting tasks.",
                context=extraction
            )
        elif "difference" in analysis.lower() or "more" in analysis.lower():
            structured_facts = await self.generate(
                instruction="Identify which values need to be compared or subtracted based on the question intent.",
                context=extraction
            )
        else:
            structured_facts = extraction

        # Step 4: Generate multiple candidate solutions using different strategies
        task1 = self.generate(
            instruction="Solve using direct extraction: return only the answer based on exact matches.",
            context=structured_facts
        )
        task2 = self.generate(
            instruction="Solve using step-by-step reasoning: break down the problem logically.",
            context=structured_facts
        )
        task3 = self.generate(
            instruction="Solve by first summarizing the passage, then applying reasoning.",
            context=await self.summarize(structured_facts)
        )

        # Step 5: Parallel exploration → Ensemble final answer
        candidates = await asyncio.gather(task1, task2, task3)
        final_answer = await self.ensemble(
            instruction="Choose the most consistent and accurate answer among these candidates.",
            contexts_to_ensemble=candidates
        )

        # Step 6: Optional refinement loop if uncertainty remains
        if "uncertain" in final_answer.lower() or "?" in final_answer:
            refined_answer = await self.revise(
                instruction="Improve clarity and precision of the answer. Eliminate ambiguity.",
                context_to_revise=final_answer
            )
            return refined_answer

        return final_answer