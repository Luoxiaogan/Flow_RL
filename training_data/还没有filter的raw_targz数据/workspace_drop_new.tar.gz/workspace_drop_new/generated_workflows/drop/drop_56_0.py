# Workflow ID: drop_56_0
# Benchmark: drop
# Data Indices: [36, 10]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Analyze the question to determine type and required reasoning
        analysis = await self.generate(
            instruction="Analyze the question to identify its type (e.g., counting, arithmetic, comparison) and key entities or numbers involved."
        )

        # Step 2: Extract all relevant facts from the passage — crucial for multi-hop problems
        extraction = await self.generate(
            instruction="Extract all factual statements related to the question, focusing on numerical values, entities, and their relationships. Do not interpret yet.",
            context=analysis
        )

        # Step 3: Summarize the extracted facts to reduce noise and highlight patterns
        summarized = await self.summarize(extraction)

        # Step 4: Generate multiple candidate solutions using different reasoning strategies
        # Parallel exploration of diverse interpretations
        task1 = self.generate(
            instruction="Based on the summary, count all instances matching the question's criteria. Be exhaustive and precise.",
            context=summarized
        )
        task2 = self.generate(
            instruction="Re-analyze the passage with a focus on entity-number associations. Identify potential ambiguities in references.",
            context=summarized
        )
        task3 = self.generate(
            instruction="Identify any implicit information that might be needed to answer the question correctly, such as totals or comparisons.",
            context=summarized
        )

        # Run parallel tasks to explore diverse reasoning paths
        candidates = await asyncio.gather(task1, task2, task3)

        # Step 5: Ensemble the candidate solutions to select the most robust answer
        final_answer = await self.ensemble(
            instruction="Evaluate the three candidate responses. Choose the one that best matches the question intent, handles ambiguity correctly, and aligns with explicit and implicit evidence.",
            contexts_to_ensemble=candidates
        )

        # Step 6: Optional refinement if the ensemble result seems uncertain
        if "uncertain" in final_answer.lower() or "not clear" in final_answer.lower():
            refined = await self.revise(
                instruction="Revise the answer based on the identified uncertainties. Clarify ambiguous references and ensure no entity-number mismatches exist.",
                context_to_revise=final_answer
            )
            return refined

        return final_answer