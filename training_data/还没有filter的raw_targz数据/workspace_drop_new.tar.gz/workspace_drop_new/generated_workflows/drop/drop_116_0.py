# Workflow ID: drop_116_0
# Benchmark: drop
# Data Indices: [263, 187]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question intent and passage structure
        analysis = await self.generate(
            instruction="Analyze the question and passage to identify key entities, relationships, and reasoning type (e.g., counting, comparison, extraction)."
        )

        # Step 2: Extract all relevant named entities and numerical facts
        extraction = await self.generate(
            instruction="Extract all named entities, dates, and numerical values from the passage that could be relevant to answering the question.",
            context=analysis
        )

        # Step 3: Generate multiple candidate solutions using different reasoning paths
        task1 = self.generate(
            instruction="Based on the extracted facts, generate a solution by focusing on direct entity-number associations.",
            context=extraction
        )
        task2 = self.generate(
            instruction="Generate an alternative solution by considering implicit information or multi-hop inferences from the passage.",
            context=extraction
        )
        task3 = self.generate(
            instruction="Generate a third solution by explicitly identifying which part of the passage supports each answer choice.",
            context=extraction
        )

        # Step 4: Run parallel exploration
        candidates = await asyncio.gather(task1, task2, task3)

        # Step 5: Ensemble to select the most consistent and supported answer
        final_answer = await self.ensemble(
            instruction="Evaluate the three candidate solutions and select the one that best aligns with the passage evidence and question intent.",
            contexts_to_ensemble=candidates
        )

        # Step 6: Optional refinement if confidence is low
        if "uncertain" in final_answer.lower() or "not clear" in final_answer.lower():
            refined = await self.revise(
                instruction="Revise the answer based on potential ambiguities in entity references or missing context.",
                context_to_revise=final_answer
            )
            return refined

        return final_answer