# Workflow ID: drop_77_0
# Benchmark: drop
# Data Indices: [209, 247]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question type and key entities
        analysis = await self.generate(
            instruction="Analyze the passage and question. Identify the type of reasoning required (e.g., counting, comparison, arithmetic, span extraction) and key entities involved."
        )

        # Step 2: Extract relevant information from the passage in parallel
        extract_tasks = [
            self.generate(instruction="Extract all named entities and their associated numerical values if present."),
            self.generate(instruction="Identify explicit comparisons or relationships between entities mentioned in the passage."),
            self.generate(instruction="List all dates, events, and sequences that might be relevant to answering the question.")
        ]
        extracted_contexts = await asyncio.gather(*extract_tasks)

        # Step 3: Summarize the extracted contexts for clarity and focus
        summarized_contexts = [
            await self.summarize(extracted_contexts[0]),
            await self.summarize(extracted_contexts[1]),
            await self.summarize(extracted_contexts[2])
        ]

        # Step 4: Generate multiple candidate solutions based on different interpretations
        candidates = []
        for i, ctx in enumerate(summarized_contexts):
            if "difference" in analysis.lower() or "more" in analysis.lower():
                candidate = await self.generate(
                    instruction="Based on the context, calculate the difference between relevant numbers.",
                    context=ctx
                )
            elif "how many" in analysis.lower() or "count" in analysis.lower():
                candidate = await self.generate(
                    instruction="Count the number of instances of the entity mentioned in the question.",
                    context=ctx
                )
            elif "who won" in analysis.lower() or "lost" in analysis.lower():
                candidate = await self.generate(
                    instruction="Determine which party or entity lost the conflict based on the outcome described.",
                    context=ctx
                )
            else:
                candidate = await self.generate(
                    instruction="Generate a solution based on the context provided.",
                    context=ctx
                )
            candidates.append(candidate)

        # Step 5: Ensemble to select the most coherent and accurate answer
        final_answer = await self.ensemble(
            instruction="Select the best answer among the candidates by evaluating consistency with the passage and logical coherence.",
            contexts_to_ensemble=candidates
        )

        # Step 6: Revise once more for precision — especially important for numerical or comparative answers
        refined_answer = await self.revise(
            instruction="Review the final answer carefully. Ensure it directly addresses the original question without ambiguity or overgeneralization.",
            context_to_revise=final_answer
        )

        return refined_answer