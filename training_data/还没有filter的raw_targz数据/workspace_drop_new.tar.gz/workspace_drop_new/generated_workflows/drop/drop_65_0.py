# Workflow ID: drop_65_0
# Benchmark: drop
# Data Indices: [106, 127]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Analyze question type and extract key entities/numbers
        analysis = await self.generate(
            instruction="Analyze the question to determine required operations (e.g., arithmetic, counting, comparison) and identify all relevant numbers and entities in the passage."
        )

        # Step 2: Extract structured facts from passage based on analysis
        extraction = await self.generate(
            instruction="Based on the analysis, extract all relevant numerical values and their associated entities or contexts.",
            context=analysis
        )

        # Step 3: Generate multiple candidate solutions using different reasoning paths
        task1 = self.generate(
            instruction="Generate a solution assuming this is an arithmetic difference question (e.g., 'How many more...').",
            context=extraction
        )
        task2 = self.generate(
            instruction="Generate a solution assuming this is a percentage calculation question (e.g., 'How many percent were not...').",
            context=extraction
        )
        task3 = self.generate(
            instruction="Generate a solution by first summarizing the passage's key statistics before solving.",
            context=extraction
        )
        results = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble the three candidates to select the most consistent answer
        final_answer = await self.ensemble(
            instruction="Choose the best answer among these three solutions based on internal consistency and alignment with the question intent.",
            contexts_to_ensemble=results
        )

        # Step 5: Optional refinement if answer seems ambiguous or incomplete
        if "not clear" in final_answer.lower() or "uncertain" in final_answer.lower():
            refined_answer = await self.revise(
                instruction="Refine the answer by focusing on clarity, correctness, and ensuring it matches the exact question phrasing.",
                context_to_revise=final_answer
            )
            return refined_answer

        return final_answer