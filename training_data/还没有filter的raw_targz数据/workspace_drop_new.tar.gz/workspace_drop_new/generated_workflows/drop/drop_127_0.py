# Workflow ID: drop_127_0
# Benchmark: drop
# Data Indices: [73, 162]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis – Understand question intent and passage structure
        analysis = await self.generate(
            instruction="Analyze the question to determine its type (e.g., comparison, count, arithmetic). Identify key entities, dates, or values mentioned in both the passage and question."
        )

        # Step 2: Extract Relevant Information – Pull out all potential answer-relevant facts
        extraction = await self.generate(
            instruction="Extract all relevant named entities, numerical values, and temporal markers from the passage that could be used to answer the question. Include context for each extracted item.",
            context=analysis
        )

        # Step 3: Parallel Exploration – Generate multiple candidate solutions based on different interpretations
        task1 = self.generate(
            instruction="Based on the extracted information, generate a solution assuming the question asks for a direct span match.",
            context=extraction
        )
        task2 = self.generate(
            instruction="Based on the extracted information, generate a solution assuming the question requires multi-hop reasoning or implicit inference.",
            context=extraction
        )
        task3 = self.generate(
            instruction="Based on the extracted information, generate a solution assuming the question involves counting or summing occurrences.",
            context=extraction
        )

        candidates = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble – Synthesize the best answer from competing interpretations
        final_answer = await self.ensemble(
            instruction="Choose the most accurate answer by comparing the three candidate solutions. Consider consistency with the original passage and logical coherence.",
            contexts_to_ensemble=candidates
        )

        # Step 5: Optional Refinement – If needed, revise based on potential errors or ambiguity
        if "ambiguous" in analysis.lower() or "multiple" in analysis.lower():
            refined_answer = await self.revise(
                instruction="Refine the final answer by addressing possible ambiguities or inconsistencies found in the previous step.",
                context_to_revise=final_answer
            )
            return refined_answer

        return final_answer