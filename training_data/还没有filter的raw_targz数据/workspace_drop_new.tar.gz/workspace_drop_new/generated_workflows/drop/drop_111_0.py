# Workflow ID: drop_111_0
# Benchmark: drop
# Data Indices: [274, 204]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis – Understand question intent and extract key entities
        analysis = await self.generate(
            instruction="Analyze the question to determine what type of reasoning is required (e.g., counting, arithmetic, comparison) and identify all relevant entities or quantities mentioned in the passage."
        )

        # Step 2: Parallel Extraction – Extract structured facts from passage based on question intent
        tasks = [
            self.generate(
                instruction="Extract all numerical values related to minerals mentioned in the passage.",
                context=analysis
            ),
            self.generate(
                instruction="Extract all named entities that could be relevant to the question, such as people, teams, or locations.",
                context=analysis
            ),
            self.generate(
                instruction="Identify any implicit relationships or counts that may not be explicitly stated but can be inferred from context.",
                context=analysis
            )
        ]
        extracted_facts, relevant_entities, inferences = await asyncio.gather(*tasks)

        # Step 3: Reasoning Phase – Generate candidate solutions using different approaches
        solution_from_facts = await self.generate(
            instruction="Using only the extracted numerical facts, solve the question directly.",
            context=extracted_facts
        )
        solution_from_entities = await self.generate(
            instruction="Using only the relevant entities, infer the answer by mapping them to their associated values.",
            context=relevant_entities
        )
        solution_from_inferences = await self.generate(
            instruction="Using the implicit inferences, derive the correct answer.",
            context=inferences
        )

        # Step 4: Ensemble – Synthesize competing solutions into a single robust answer
        final_answer = await self.ensemble(
            instruction="Compare the three candidate answers and select the most consistent one. If there's disagreement, explain why and choose the best-supported option.",
            contexts_to_ensemble=[solution_from_facts, solution_from_entities, solution_from_inferences]
        )

        # Step 5: Optional Refinement – Revise if uncertainty remains
        revised_answer = await self.revise(
            instruction="Critique the final answer for logical consistency, completeness, and correctness. If any ambiguity exists, refine it accordingly.",
            context_to_revise=final_answer
        )

        return revised_answer