# Workflow ID: drop_123_0
# Benchmark: drop
# Data Indices: [12, 189]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question intent and passage structure
        analysis = await self.generate(
            instruction="Analyze the passage and question to determine the type of reasoning required (e.g., counting, comparison, span extraction). Identify key entities and numerical values."
        )

        # Step 2: Extract all relevant factual elements from the passage
        extraction = await self.generate(
            instruction="Extract all named entities (teams, players, scores) and associated numerical values (yards, counts, dates) in structured format like 'Entity: Value'. Be exhaustive.",
            context=analysis
        )

        # Step 3: Parallel exploration of possible interpretations
        task1 = self.generate(
            instruction="Generate one solution path assuming this is a counting question (e.g., count how many times a specific entity appears).",
            context=extraction
        )
        task2 = self.generate(
            instruction="Generate one solution path assuming this is a comparative question (e.g., which team scored more or had a higher value).",
            context=extraction
        )
        task3 = self.generate(
            instruction="Generate one solution path assuming this is a span extraction question (e.g., who did something or what was the name of an event).",
            context=extraction
        )

        # Run parallel paths
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble to select the best answer based on coherence and alignment with the question
        final_answer = await self.ensemble(
            instruction="Evaluate the three candidate answers. Choose the one that best matches the question's intent, uses correct entity-number associations, and avoids ambiguity.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional refinement if the ensemble result seems incomplete or unclear
        if "not enough information" in final_answer.lower() or "uncertain" in final_answer.lower():
            refined = await self.revise(
                instruction="Revise the answer by re-examining the original passage and extraction for overlooked details. Focus on resolving ambiguity or missing connections.",
                context_to_revise=final_answer
            )
            return refined

        return final_answer