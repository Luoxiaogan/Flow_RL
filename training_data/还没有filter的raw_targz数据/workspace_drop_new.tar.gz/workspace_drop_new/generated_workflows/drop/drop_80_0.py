# Workflow ID: drop_80_0
# Benchmark: drop
# Data Indices: [199, 111]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand the question type and key entities
        analysis = await self.generate(
            instruction="Analyze the question and passage to identify the required reasoning type (e.g., comparison, counting, arithmetic), key entities, and what must be extracted."
        )

        # Step 2: Extract relevant numerical and factual data from the passage
        extraction = await self.generate(
            instruction="Extract all relevant numerical values, named entities, and their relationships from the passage. Focus on numbers tied to specific entities mentioned in the question.",
            context=analysis
        )

        # Step 3: Generate multiple candidate solutions using different reasoning paths
        task1 = self.generate(
            instruction="Generate a solution by directly identifying the answer based on the extracted facts.",
            context=extraction
        )
        task2 = self.generate(
            instruction="Generate a solution by first summarizing the passage, then solving the question from the summary.",
            context=await self.summarize(extraction)
        )
        task3 = self.generate(
            instruction="Generate a solution by focusing only on the entities mentioned in the question and ignoring unrelated details.",
            context=extraction
        )
        candidates = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble to select the most consistent and accurate answer
        final_answer = await self.ensemble(
            instruction="Choose the best answer among the three generated solutions. If there's disagreement, prioritize the one that aligns with the explicit evidence in the passage.",
            contexts_to_ensemble=candidates
        )

        # Step 5: Revise if needed — check for consistency or ambiguity
        revised_answer = await self.revise(
            instruction="Review the final answer for clarity, correctness, and whether it addresses the exact intent of the question. If uncertain, refine the answer.",
            context_to_revise=final_answer
        )

        return revised_answer