# Workflow ID: drop_92_0
# Benchmark: drop
# Data Indices: [113, 175]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis - Understand question intent and passage structure
        analysis = await self.generate(
            instruction="Analyze the question to determine if it requires temporal ordering, numerical reasoning, entity comparison, or span extraction."
        )

        # Step 2: Extract Key Events or Entities Based on Question Type
        extraction_instruction = "Extract all relevant events, dates, entities, or values from the passage that could be involved in answering the question."
        raw_extraction = await self.generate(instruction=extraction_instruction)

        # Step 3: Summarize to Reduce Noise and Focus on Core Elements
        focused_summary = await self.summarize(context_to_summarize=raw_extraction)

        # Step 4: Parallel Hypothesis Generation – Generate multiple interpretations
        task1 = self.generate(
            instruction="Generate a timeline-based interpretation focusing on chronological order of events.",
            context=focused_summary
        )
        task2 = self.generate(
            instruction="Generate an event-based interpretation focusing on what happened first based on causal or textual cues.",
            context=focused_summary
        )
        task3 = self.generate(
            instruction="Generate a comparative interpretation by identifying key entities mentioned in the question and their associated facts.",
            context=focused_summary
        )

        # Execute parallel hypotheses
        hypotheses = await asyncio.gather(task1, task2, task3)

        # Step 5: Ensemble to Synthesize Best Answer
        ensemble_instruction = "Compare the three interpretations and select the one that most directly addresses the question while being consistent with the passage."
        final_answer = await self.ensemble(
            instruction=ensemble_instruction,
            contexts_to_ensemble=hypotheses
        )

        # Step 6: Optional Refinement Loop – If answer lacks clarity, revise
        if "unclear" in final_answer.lower() or "not sure" in final_answer.lower():
            refined_answer = await self.revise(
                instruction="Revise the answer to clarify which event occurred first based on explicit evidence in the passage.",
                context_to_revise=final_answer
            )
            return refined_answer

        return final_answer