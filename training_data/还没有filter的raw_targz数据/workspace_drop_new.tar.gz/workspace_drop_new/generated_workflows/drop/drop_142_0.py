# Workflow ID: drop_142_0
# Benchmark: drop
# Data Indices: [100, 153]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand question intent and passage structure
        analysis = await self.generate(
            instruction="Analyze the question to determine the type of reasoning required (e.g., counting, arithmetic, span extraction, comparison). Also identify key entities and numerical values in the passage relevant to the question."
        )

        # Step 2: Extract Relevant Information — Isolate all instances that may answer the question
        extraction = await self.generate(
            instruction="Extract all relevant facts from the passage related to the question. Focus on entities, numbers, events, and their relationships. Format as a structured list: [entity, value, context].",
            context=analysis
        )

        # Step 3: Parallel Exploration — Generate multiple interpretations or solution paths
        task1 = self.generate(
            instruction="Based on the extracted facts, generate a step-by-step reasoning path to solve the question directly.",
            context=extraction
        )
        task2 = self.generate(
            instruction="Generate an alternative approach by focusing only on numerical values and operations needed to answer the question.",
            context=extraction
        )
        task3 = self.generate(
            instruction="Identify any ambiguous references or potential misassociations in the text that might affect the answer, and propose corrections.",
            context=extraction
        )

        # Execute parallel tasks concurrently
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble — Synthesize competing solutions into one coherent answer
        final_answer = await self.ensemble(
            instruction="Evaluate the three candidate answers. Choose the one that best aligns with the question's intent, is most consistent with the passage, and resolves ambiguities identified earlier.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional Refinement — If the answer seems uncertain, revise it using feedback from the ensemble process
        if "uncertain" in final_answer.lower() or "ambiguous" in final_answer.lower():
            refined_answer = await self.revise(
                instruction="Revise the answer based on the following critique: 'The initial answer lacks clarity or confidence due to ambiguity in entity-number associations. Re-express it precisely, citing specific evidence from the passage.'",
                context_to_revise=final_answer
            )
            return refined_answer

        return final_answer