# Workflow ID: drop_62_0
# Benchmark: drop
# Data Indices: [217, 278]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand question intent and passage structure
        analysis = await self.generate(
            instruction="Analyze the question and passage to identify key entities, numbers, and reasoning type (e.g., comparison, count, arithmetic)."
        )

        # Step 2: Extract all relevant numerical facts and named entities in parallel
        num_extract_task = self.generate(
            instruction="Extract all numerical values from the passage with their associated context (e.g., year, entity name)."
        )
        entity_extract_task = self.generate(
            instruction="Identify all named entities mentioned in the passage that could be relevant to answering the question."
        )
        extracted_data = await asyncio.gather(num_extract_task, entity_extract_task)

        # Step 3: Summarize extracted data to reduce noise and focus on relevant parts
        summarized_data = await self.summarize(context_to_summarize="\n".join(extracted_data))

        # Step 4: Generate multiple candidate solutions based on different interpretations
        if "compare" in analysis.lower() or "which is greater" in analysis.lower():
            # For comparison questions, generate both possible answers
            sol1 = await self.generate(
                instruction="Generate the answer assuming the first option is correct.",
                context=summarized_data
            )
            sol2 = await self.generate(
                instruction="Generate the answer assuming the second option is correct.",
                context=summarized_data
            )
            candidates = [sol1, sol2]
        elif "how many" in analysis.lower() or "count" in analysis.lower():
            # For counting questions, generate a structured list of counts
            sol = await self.generate(
                instruction="List all occurrences of the target entity and count them explicitly.",
                context=summarized_data
            )
            candidates = [sol]
        else:
            # General case: generate solution using full context
            sol = await self.generate(
                instruction="Generate a step-by-step solution using the summarized data.",
                context=summarized_data
            )
            candidates = [sol]

        # Step 5: Ensemble to select best answer among candidates
        final_answer = await self.ensemble(
            instruction="Select the most accurate answer based on evidence from the candidates.",
            contexts_to_ensemble=candidates
        )

        # Step 6: Optional refinement if answer seems ambiguous
        if "uncertain" in final_answer.lower() or "both" in final_answer.lower():
            refined = await self.revise(
                instruction="Revise the answer to resolve ambiguity by re-examining the original passage.",
                context_to_revise=final_answer
            )
            return refined

        return final_answer