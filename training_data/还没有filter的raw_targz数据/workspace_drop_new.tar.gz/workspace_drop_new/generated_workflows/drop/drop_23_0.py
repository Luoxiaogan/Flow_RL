# Workflow ID: drop_23_0
# Benchmark: drop
# Data Indices: [237, 295]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand the question type and key entities
        analysis = await self.generate(
            instruction="Analyze the question to determine the required reasoning type (e.g., count, compare, calculate difference) and identify key entities involved."
        )

        # Step 2: Extract all relevant factual data from passage
        extraction = await self.generate(
            instruction="Extract all numerical facts and named entities related to the question. Focus on values associated with specific people, teams, or events.",
            context=analysis
        )

        # Step 3: Parallel Exploration — Generate multiple interpretations if ambiguous
        task1 = self.generate("Generate one possible interpretation of how to solve this based on the extracted facts.")
        task2 = self.generate("Generate an alternative approach to solving this, focusing on different entity-number associations.")
        task3 = self.generate("Generate a third method that checks for implicit information in the passage.")

        results = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble — Select best solution among competing interpretations
        final_solution = await self.ensemble(
            instruction="Choose the most accurate solution by comparing the three candidate approaches. Prioritize consistency with the passage and logical soundness.",
            contexts_to_ensemble=results
        )

        # Step 5: Revise — Improve accuracy via self-correction using feedback
        revised_solution = await self.revise(
            instruction="Critically review the selected solution. Identify potential errors such as misattribution of numbers to entities or incorrect arithmetic operations.",
            context_to_revise=final_solution
        )

        return revised_solution