# Workflow ID: drop_114_0
# Benchmark: drop
# Data Indices: [280, 194]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand the question type and extract key entities
        analysis = await self.generate(
            instruction="Analyze the question to determine if it requires counting, arithmetic, comparison, or span extraction. Also identify all relevant entities (people, teams, events) mentioned in the passage that may relate to the answer."
        )

        # Step 2: Parallel Extraction — Extract structured facts from passage using multiple lenses
        task1 = self.generate(
            instruction="Extract all instances of 'touchdowns' or 'field goals' with their associated yardage and responsible entity (e.g., player/team)."
        )
        task2 = self.generate(
            instruction="Identify all named entities (players, teams, events) and their roles in the narrative to resolve ambiguous references like 'he', 'they', etc."
        )
        task3 = self.generate(
            instruction="List all numerical values in the passage along with their context (e.g., '42-yard field goal by Matt Bryant') to enable precise association."
        )
        extracted_facts, entity_resolution, numerical_context = await asyncio.gather(task1, task2, task3)

        # Step 3: Refinement Loop — Revise based on multi-angle feedback
        revised_analysis = await self.revise(
            instruction="Review the initial analysis against the extracted facts. Correct any misinterpretations about which entities are relevant or what kind of calculation is needed.",
            context_to_revise=analysis
        )
        refined_facts = await self.revise(
            instruction="Ensure each extracted fact includes clear associations between numbers, entities, and actions (e.g., 'Randy Moss caught a 3-yard TD pass').",
            context_to_revise=extracted_facts
        )

        # Step 4: Hypothesis Testing — Generate candidate solutions from different interpretations
        hypothesis_1 = await self.generate(
            instruction="Assuming the question asks for a specific instance (e.g., one touchdown), find the exact match using the resolved entities and context.",
            context=refined_facts
        )
        hypothesis_2 = await self.generate(
            instruction="If the question implies aggregation (like total or difference), compute the required sum or difference using only relevant values from the extracted facts.",
            context=refined_facts
        )

        # Step 5: Ensemble Decision — Synthesize best-supported answer
        final_answer = await self.ensemble(
            instruction="Choose the most accurate answer based on the evidence. If both hypotheses agree, pick that. If they differ, select the one better supported by the passage context.",
            contexts_to_ensemble=[hypothesis_1, hypothesis_2]
        )

        return final_answer