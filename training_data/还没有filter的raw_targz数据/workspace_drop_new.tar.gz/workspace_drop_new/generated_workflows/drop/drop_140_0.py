# Workflow ID: drop_140_0
# Benchmark: drop
# Data Indices: [271, 8]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand question intent and key entities
        analysis = await self.generate(
            instruction="Analyze the question to determine what type of reasoning is required (e.g., counting, arithmetic, comparison, span extraction). Also identify all relevant entities mentioned in the passage that could be involved in the answer."
        )

        # Step 2: Extract Relevant Information — Create structured facts from passage
        extraction = await self.generate(
            instruction="Extract all relevant events, scores, and numerical data from the passage. Include timestamps (quarter), actions, players, teams, and values. Format as a list of bullet points with clear entity-number associations.",
            context=analysis
        )

        # Step 3: Parallel Exploration — Generate multiple solution paths based on different interpretations
        task1 = self.generate(
            instruction="Based on the extracted facts, generate a direct answer using explicit information only.",
            context=extraction
        )
        task2 = self.generate(
            instruction="Generate an answer by identifying implicit relationships or multi-hop reasoning steps (e.g., combining two separate events).",
            context=extraction
        )
        task3 = self.generate(
            instruction="If the question involves comparison or selection, generate a ranked list of candidates based on evidence.",
            context=extraction
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble — Synthesize best answer from diverse approaches
        final_answer = await self.ensemble(
            instruction="Choose the most accurate and well-supported answer among the three generated solutions. Justify briefly if there's uncertainty.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional Refinement — If needed, revise for clarity or precision
        refined_answer = await self.revise(
            instruction="Improve the clarity and correctness of the final answer. Ensure it directly addresses the original question without ambiguity.",
            context_to_revise=final_answer
        )

        return refined_answer