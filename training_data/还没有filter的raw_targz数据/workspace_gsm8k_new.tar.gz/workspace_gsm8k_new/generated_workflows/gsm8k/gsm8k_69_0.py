# Workflow ID: gsm8k_69_0
# Benchmark: gsm8k
# Data Indices: [288, 136]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Extract key entities and values from the problem
        extraction = await self.generate(
            instruction="Extract all numerical values, units, and relationships in the problem. Focus on quantities, operations, and context (e.g., 'John has 5 toys', 'each costs $3', '20% discount')."
        )

        # Step 2: Analyze the problem structure to determine required operations
        analysis = await self.generate(
            instruction="Based on the extracted information, identify the sequence of mathematical operations needed to solve the problem. Include steps like calculating total cost before discount, applying percentage, etc.",
            context=extraction
        )

        # Step 3: Generate a detailed solution plan
        plan = await self.generate(
            instruction="Now, write a step-by-step solution plan that includes unit tracking, intermediate calculations, and final answer formatting.",
            context=analysis
        )

        # Step 4: Revise the plan iteratively for accuracy and clarity
        revised_plan = await self.revise(
            instruction="Critically review the plan for logical errors, missing steps, or incorrect unit handling. Improve clarity and correctness.",
            context_to_revise=plan
        )

        # Step 5: Summarize the refined plan to reduce context length while preserving key steps
        summary = await self.summarize(context_to_summarize=revised_plan)

        # Step 6: Generate multiple candidate solutions using different reasoning paths
        task1 = self.generate(instruction="Solve using direct arithmetic steps.", context=summary)
        task2 = self.generate(instruction="Solve by first converting all values to base units (e.g., dollars, minutes), then compute.", context=summary)
        task3 = self.generate(instruction="Solve by modeling as a proportional relationship (e.g., discount rate).", context=summary)

        # Execute parallel exploration
        candidates = await asyncio.gather(task1, task2, task3)

        # Step 7: Ensemble the best solution based on consistency and reasoning quality
        final_answer = await self.ensemble(
            instruction="Select the most consistent and logically sound solution from the three candidates. If there's disagreement, choose the one that aligns with the original problem constraints.",
            contexts_to_ensemble=candidates
        )

        return final_answer