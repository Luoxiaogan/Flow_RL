# Workflow ID: gsm8k_10_0
# Benchmark: gsm8k
# Data Indices: [98, 130]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Identify key entities, values, and relationships
        analysis = await self.generate(
            instruction="Extract all numerical values, variables, and relationships from the problem. Focus on who has what, how quantities change, and what the question asks."
        )

        # Step 2: Decompose into structured facts — Convert natural language to math-ready statements
        decomposition = await self.generate(
            instruction="Based on the analysis, list each known fact as a clear mathematical relationship or equation (e.g., 'Sam has twice as many marbles as Steve' → S = 2*Steve).",
            context=analysis
        )

        # Step 3: Parallel Exploration — Generate multiple solution paths based on different interpretations
        task1 = self.generate(
            instruction="Solve using direct substitution: assume initial counts and apply changes step-by-step.",
            context=decomposition
        )
        task2 = self.generate(
            instruction="Set up equations with unknowns and solve algebraically (e.g., let x = Steve's initial marbles).",
            context=decomposition
        )
        task3 = self.generate(
            instruction="Use unit tracking: track how many marbles each person has at each stage.",
            context=decomposition
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble — Compare and synthesize the best solution from multiple approaches
        final_answer = await self.ensemble(
            instruction="Evaluate the three proposed solutions. Choose the one that matches the constraints, is logically consistent, and resolves the original question clearly.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Final Verification — Check if the answer makes sense in context
        verification = await self.revise(
            instruction="Verify that the final answer satisfies all conditions in the original problem (e.g., no negative marbles, correct totals, proper sequence of events). If not, revise the solution accordingly.",
            context_to_revise=final_answer
        )

        return verification