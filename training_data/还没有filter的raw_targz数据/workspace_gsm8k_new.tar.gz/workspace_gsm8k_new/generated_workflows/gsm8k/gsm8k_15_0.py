# Workflow ID: gsm8k_15_0
# Benchmark: gsm8k
# Data Indices: [293, 120]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify key entities, relationships, and unknowns
        analysis = await self.generate(
            instruction="Extract all named entities (people, objects), their quantities, and how they relate to each other. Identify the final question being asked."
        )

        # Step 2: Generate multiple solution paths using parallel exploration
        task1 = self.generate(
            instruction="First, solve by building up from the smallest known quantity (e.g., Bridget's albums if Adele's is given).",
            context=analysis
        )
        task2 = self.generate(
            instruction="Second, solve by working backward from the final total or target value.",
            context=analysis
        )
        task3 = self.generate(
            instruction="Third, write out the mathematical expressions for each relationship and compute step-by-step in order.",
            context=analysis
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble to select the most consistent and accurate solution
        final_answer = await self.ensemble(
            instruction="Choose the answer that best matches all given relationships and makes logical sense in context. If there's disagreement, pick the one with clear arithmetic steps.",
            contexts_to_ensemble=solutions
        )

        # Step 4: Optional refinement via revision if needed
        revised_answer = await self.revise(
            instruction="Check if the answer fits all constraints: no negative values, proper unit handling, and correct sequence of operations. If not, revise accordingly.",
            context_to_revise=final_answer
        )

        return revised_answer