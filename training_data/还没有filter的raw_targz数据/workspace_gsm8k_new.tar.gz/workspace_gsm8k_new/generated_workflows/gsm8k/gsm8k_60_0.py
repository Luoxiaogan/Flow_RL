# Workflow ID: gsm8k_60_0
# Benchmark: gsm8k
# Data Indices: [88, 166]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Analyze problem structure and identify key elements
        analysis = await self.generate(
            instruction="Identify all numerical values, relationships, and what must be calculated. Extract known quantities, unknowns, and operations required."
        )

        # Step 2: Generate multiple solution paths using parallel exploration
        task1 = self.generate(
            instruction="Create a step-by-step plan based on the order of events described in the problem.",
            context=analysis
        )
        task2 = self.generate(
            instruction="List all mathematical operations needed to solve this problem, in order.",
            context=analysis
        )
        task3 = self.generate(
            instruction="Outline how units (e.g., dollars, feet) should be tracked through each operation.",
            context=analysis
        )
        
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble the competing approaches to find a robust solution
        ensemble_solution = await self.ensemble(
            instruction="Compare the three proposed solution strategies. Choose the one that most clearly addresses the problem's requirements and handles all steps correctly.",
            contexts_to_ensemble=solutions
        )

        # Step 4: Revise for accuracy — test intermediate logic and verify unit consistency
        revised_solution = await self.revise(
            instruction="Review the solution for logical flow, correct arithmetic steps, and consistent unit handling. Fix any errors or ambiguities.",
            context_to_revise=ensemble_solution
        )

        # Step 5: Final verification via bidirectional check if possible
        verification_check = await self.generate(
            instruction="Generate an inverse problem from the final answer and check whether solving it leads back to the original scenario.",
            context=revised_solution
        )

        # Step 6: Return the final cleaned-up solution
        final_answer = await self.summarize(
            context_to_summarize=revised_solution + "\n\n" + verification_check
        )

        return final_answer