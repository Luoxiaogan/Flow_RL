# Workflow ID: gsm8k_128_0
# Benchmark: gsm8k
# Data Indices: [264, 182]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify problem type and key elements
        analysis = await self.generate(
            instruction="Analyze the problem to identify known values, unknowns, relationships, and required operations."
        )

        # Step 2: Extract structured facts from analysis for clarity
        extracted_facts = await self.generate(
            instruction="From the analysis, extract all numerical values, variables, and relationships in structured format (e.g., 'known: X=5', 'relationship: Y = 3 * X').",
            context=analysis
        )

        # Step 3: Generate multiple solution paths using parallel exploration
        task1 = self.generate(
            instruction="Generate a step-by-step mathematical solution based on the extracted facts.",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Generate an alternative approach by solving for the unknown variable directly using algebraic reasoning.",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Generate a solution that explicitly tracks units and checks consistency throughout the calculation.",
            context=extracted_facts
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble the solutions to select the most consistent and accurate one
        final_answer = await self.ensemble(
            instruction="Compare the three generated solutions and choose the one that is mathematically sound, logically consistent, and matches the expected answer type (a single number).",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional refinement if needed — check for hidden steps or unit errors
        if "step" in final_answer.lower() or "calculate" in final_answer.lower():
            refined = await self.revise(
                instruction="Revise the solution to ensure it contains only the final numerical answer without explanation.",
                context_to_revise=final_answer
            )
            return refined.strip()
        
        return final_answer.strip()