# Workflow ID: gsm8k_8_0
# Benchmark: gsm8k
# Data Indices: [149, 183]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Analyze the problem to identify key entities, values, and relationships
        analysis = await self.generate(
            instruction="Identify all numerical values, entities (people/objects), and mathematical relationships in the problem."
        )

        # Step 2: Extract structured facts from the analysis for reliable reasoning
        extracted_facts = await self.generate(
            instruction="From the analysis, extract each fact as a key-value pair or equation, ensuring no ambiguity.",
            context=analysis
        )

        # Step 3: Generate multiple solution paths using parallel exploration
        task1 = self.generate(
            instruction="Solve step-by-step following chronological order if time-based; otherwise, follow logical dependencies.",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Break down the problem into sub-problems and solve them independently before combining results.",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Apply unit tracking throughout the calculation—ensure consistency of units like dollars, apples, hours.",
            context=extracted_facts
        )
        
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble the three candidate solutions to find the most robust answer
        final_answer = await self.ensemble(
            instruction="Choose the most consistent and logically sound solution based on the three generated approaches.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional refinement loop — check if answer makes sense in context
        verification = await self.revise(
            instruction="Review the final answer: Does it align with real-world constraints (e.g., no negative fruits, whole numbers where needed)? If not, revise accordingly.",
            context_to_revise=final_answer
        )

        return verification