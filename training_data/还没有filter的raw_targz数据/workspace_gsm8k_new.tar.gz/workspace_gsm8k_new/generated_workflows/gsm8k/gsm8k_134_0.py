# Workflow ID: gsm8k_134_0
# Benchmark: gsm8k
# Data Indices: [32, 281]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Identify key entities, values, and relationships
        analysis = await self.generate(
            instruction="Identify all named individuals or objects, their known quantities, and how they relate to each other in the problem."
        )

        # Step 2: Extract Structured Facts — Convert narrative into clean data points
        extraction = await self.generate(
            instruction="Extract structured facts from the analysis: names, known values, and mathematical relationships (e.g., 'twice as much', '3/5 times', 'more than').",
            context=analysis
        )

        # Step 3: Parallel Exploration — Generate multiple solution paths based on different interpretations or sub-problems
        task1 = self.generate(
            instruction="Solve by first determining Dorothy's score, then Ivanna's, then Tatuya's, and finally compute average.",
            context=extraction
        )
        task2 = self.generate(
            instruction="Model this as a system of equations: Let D = Dorothy’s score, I = Ivanna’s, T = Tatuya’s. Then T = 2*I, I = (3/5)*D, and average = (T + I + D)/3.",
            context=extraction
        )
        solutions = await asyncio.gather(task1, task2)

        # Step 4: Ensemble Final Answer — Compare both approaches and select most consistent result
        final_answer = await self.ensemble(
            instruction="Compare the two solution approaches. If they agree, return the common answer. If not, choose the one that better aligns with the original problem structure and constraints.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional Refinement — Check for logical consistency and unit correctness
        refined = await self.revise(
            instruction="Verify that the final answer makes sense in context: Is it a reasonable number? Does it respect all given constraints (e.g., no negative scores)?",
            context_to_revise=final_answer
        )

        return refined