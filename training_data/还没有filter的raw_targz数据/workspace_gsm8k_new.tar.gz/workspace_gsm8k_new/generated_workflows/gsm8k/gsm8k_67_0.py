# Workflow ID: gsm8k_67_0
# Benchmark: gsm8k
# Data Indices: [189, 209]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Extract key numerical values and relationships
        extraction = await self.generate(
            instruction="Extract all numerical values and their associated contexts (e.g., earnings per day, overtime rate, hours, days, quantities). Do not compute yet."
        )

        # Step 2: Generate initial solution plan based on extracted data
        planning = await self.generate(
            instruction="Based on the extracted values, generate a step-by-step plan to solve the problem. Identify required operations (addition, multiplication, division) and units involved.",
            context=extraction
        )

        # Step 3: Solve using linear decomposition — execute steps sequentially
        solution_steps = []
        current_context = planning
        for i in range(3):  # Max 3 steps for typical GSM8K problems
            step = await self.generate(
                instruction=f"Execute step {i+1} of the plan. Use only the information from previous steps and the original problem. Be explicit about calculations and units.",
                context=current_context
            )
            solution_steps.append(step)
            current_context = step

        # Step 4: Summarize full reasoning chain for clarity
        summary = await self.summarize("\n".join(solution_steps))

        # Step 5: Revise once for common errors (unit mismatches, missing steps)
        revised = await self.revise(
            instruction="Review the full solution for logical consistency, unit tracking, and correctness of arithmetic steps. Fix any mistakes or missing parts.",
            context_to_revise=summary
        )

        # Step 6: Final ensemble with multiple perspectives if needed
        # Parallel exploration of alternative interpretations (if problem has ambiguity)
        task1 = self.generate("Generate an alternative approach to solving this problem by focusing on different aspects of the scenario.")
        task2 = self.generate("Generate a solution assuming a different interpretation of ambiguous terms like 'additional' or 'half'.")
        
        alternatives = await asyncio.gather(task1, task2)
        final_answer = await self.ensemble(
            instruction="Choose the most consistent and accurate solution among the alternatives. Prioritize solutions that match the original problem's context and avoid negative results.",
            contexts_to_ensemble=[revised] + alternatives
        )

        return final_answer