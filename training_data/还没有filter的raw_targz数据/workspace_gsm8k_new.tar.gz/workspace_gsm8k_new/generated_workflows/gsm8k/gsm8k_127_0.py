# Workflow ID: gsm8k_127_0
# Benchmark: gsm8k
# Data Indices: [163, 10]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis
        analysis = await self.generate(
            instruction="Identify all known quantities, unknowns, and relationships in the problem. Focus on mathematical structure (e.g., sequences, rates, proportions)."
        )

        # Step 2: Extract Key Data
        extracted_data = await self.generate(
            instruction="From the analysis, extract all numerical values, units, and operations needed to solve the problem. Format as a structured list of key facts.",
            context=analysis
        )

        # Step 3: Generate Multiple Solution Paths
        task1 = self.generate(
            instruction="Generate a step-by-step solution using sequential reasoning based on the extracted data."
        )
        task2 = self.generate(
            instruction="Generate an alternative solution path using proportional reasoning or unit-based scaling."
        )
        task3 = self.generate(
            instruction="Generate a solution path that explicitly tracks units at each step to ensure consistency."
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer
        final_answer = await self.ensemble(
            instruction="Select the most consistent and accurate solution from the three candidates. Justify briefly if there are discrepancies.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Verify via Bidirectional Check (if needed)
        verification = await self.generate(
            instruction="Now, reverse-engineer the answer: assume this is correct, then reconstruct the original conditions to see if they match. If not, revise accordingly.",
            context=final_answer
        )

        # Optional refinement loop
        if "verify" in verification.lower() or "reconstruct" in verification.lower():
            refined_answer = await self.revise(
                instruction="Revise the final answer based on the verification check. Ensure it makes sense in context and satisfies all constraints.",
                context_to_revise=final_answer
            )
            return refined_answer
        else:
            return final_answer