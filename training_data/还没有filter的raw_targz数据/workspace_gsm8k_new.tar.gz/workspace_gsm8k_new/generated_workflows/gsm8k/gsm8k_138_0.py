# Workflow ID: gsm8k_138_0
# Benchmark: gsm8k
# Data Indices: [36, 162]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis – Understand the problem type and extract key elements
        analysis = await self.generate(
            instruction="Identify the core mathematical structure: What operations are needed? What quantities are given vs unknown? Are there hidden steps or unit conversions?"
        )

        # Step 2: Extract Structured Facts – Convert narrative into clear numerical relationships
        extracted_facts = await self.generate(
            instruction="Extract all known values, units, and relationships from the problem in a structured format like: 'Given: [value] [unit], relationship: [formula]'",
            context=analysis
        )

        # Step 3: Generate Multiple Solution Paths – Use parallel exploration to handle ambiguity
        task1 = self.generate(
            instruction="First, solve step-by-step using sequential reasoning based on the order of events described.",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Second, reframe the problem as a proportional or rate-based calculation if applicable (e.g., per-unit cost, time-rate).",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Third, identify any constraints (like non-negative results) and ensure they're respected in the solution.",
            context=extracted_facts
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer – Synthesize competing approaches
        final_answer = await self.ensemble(
            instruction="Compare the three proposed solutions. Choose the one that best aligns with the original problem's context and arithmetic logic. If inconsistent, explain why.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Verify via Bidirectional Check – Ensure correctness by reversing the logic
        verification = await self.generate(
            instruction="Now, reverse-engineer the problem: Given the final answer, reconstruct a plausible scenario that would lead to this result. Does it match the original setup?",
            context=final_answer
        )

        # Step 6: Final Refinement – Revise based on bidirectional consistency check
        final_solution = await self.revise(
            instruction="If the verification shows inconsistency, revise the solution to fix logical errors. Otherwise, return the current answer unchanged.",
            context_to_revise=final_answer + "\n\nVerification:\n" + verification
        )

        return final_solution