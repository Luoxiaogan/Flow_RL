# Workflow ID: gsm8k_61_0
# Benchmark: gsm8k
# Data Indices: [197, 251]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify key elements (values, relationships, unknowns)
        analysis = await self.generate(
            instruction="Extract all numerical values, quantities, and relationships from the problem. Identify what is known and what needs to be calculated."
        )

        # Step 2: Generate multiple solution paths based on different interpretations or sub-problems
        task1 = self.generate(
            instruction="Break down the problem into sequential steps based on the order of events or operations described.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Identify ratios, percentages, or proportional relationships in the problem and derive equations from them.",
            context=analysis
        )
        task3 = self.generate(
            instruction="Check if there are hidden constraints or unit conversions that must be handled before calculation.",
            context=analysis
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble the candidate solutions to find the most consistent and accurate answer
        final_answer = await self.ensemble(
            instruction="Compare the three proposed solutions. Select the one that best aligns with the problem's structure and avoids contradictions.",
            contexts_to_ensemble=solutions
        )

        # Step 4: Optional refinement — revise if any inconsistencies remain
        refined_answer = await self.revise(
            instruction="Review the final answer for logical consistency, correct units, and whether it makes sense in the real-world context of the problem.",
            context_to_revise=final_answer
        )

        return refined_answer