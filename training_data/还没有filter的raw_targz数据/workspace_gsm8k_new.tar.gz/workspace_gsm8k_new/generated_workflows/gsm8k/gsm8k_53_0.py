# Workflow ID: gsm8k_53_0
# Benchmark: gsm8k
# Data Indices: [222, 228]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Analyze the problem structure and identify key elements
        analysis = await self.generate(
            instruction="Identify all numerical values, units, relationships, and what needs to be calculated. Focus on hidden steps and constraints."
        )

        # Step 2: Extract structured data from the analysis for clarity
        extracted_data = await self.generate(
            instruction="From the analysis, extract all relevant numbers, their units, and how they relate (e.g., rates, totals, differences). Format as bullet points.",
            context=analysis
        )

        # Step 3: Generate multiple solution paths in parallel — one for each major operation type (addition, multiplication, etc.)
        task1 = self.generate(
            instruction="Propose a step-by-step plan assuming this is a sequential calculation problem (e.g., deposit then withdrawal).",
            context=extracted_data
        )
        task2 = self.generate(
            instruction="Propose a step-by-step plan assuming this is a rate or unit conversion problem (e.g., speed × time = distance).",
            context=extracted_data
        )
        task3 = self.generate(
            instruction="Propose a step-by-step plan assuming this is a proportional or percentage-based problem (e.g., discounts, shares).",
            context=extracted_data
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble the three candidate solutions into one robust answer
        final_solution = await self.ensemble(
            instruction="Evaluate and synthesize the three proposed plans. Choose the one that best fits the original problem's context and logical flow. If there’s disagreement, resolve it by checking consistency with known values.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional refinement loop — if the problem seems complex, revise once more
        if "complex" in analysis.lower() or "multiple steps" in analysis.lower():
            refined_solution = await self.revise(
                instruction="Check for arithmetic errors, unit consistency, and whether the final answer makes sense in real-world terms (e.g., no negative items, proper rounding).",
                context_to_revise=final_solution
            )
            return refined_solution

        return final_solution