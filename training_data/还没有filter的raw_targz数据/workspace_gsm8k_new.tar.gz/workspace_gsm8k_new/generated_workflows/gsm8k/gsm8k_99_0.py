# Workflow ID: gsm8k_99_0
# Benchmark: gsm8k
# Data Indices: [47, 285]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Extract key facts and unknowns from the problem
        analysis = await self.generate(
            instruction="Identify all known quantities, units, relationships, and the final unknown in this math word problem."
        )

        # Step 2: Generate multiple solution paths (parallel exploration)
        task1 = self.generate(
            instruction="Create a step-by-step plan to solve using basic arithmetic operations only.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Create an alternative solution path by first summarizing the problem structure and then solving.",
            context=analysis
        )
        task3 = self.generate(
            instruction="Generate a solution using unit tracking and dimensional analysis to ensure consistency.",
            context=analysis
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble the candidate solutions to select the most robust one
        final_solution = await self.ensemble(
            instruction="Compare the three generated solutions and choose the most accurate based on logical consistency and mathematical correctness.",
            contexts_to_ensemble=solutions
        )

        # Step 4: Revise if necessary — check for errors or inconsistencies
        revised_solution = await self.revise(
            instruction="Review the final solution carefully for any missing steps, incorrect assumptions, or unit mismatches. Correct any issues found.",
            context_to_revise=final_solution
        )

        return revised_solution