# Workflow ID: gsm8k_70_0
# Benchmark: gsm8k
# Data Indices: [71, 49]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify key elements and structure
        analysis = await self.generate(
            instruction="Identify all known quantities, unknowns, relationships, and operations needed to solve this problem."
        )

        # Step 2: Extract structured facts from the analysis
        extracted_facts = await self.generate(
            instruction="From the analysis, extract a list of numerical values, variables, and their roles (e.g., 'income = x', 'groceries = $20').",
            context=analysis
        )

        # Step 3: Generate multiple solution strategies in parallel
        task1 = self.generate(
            instruction="Generate a step-by-step arithmetic plan based on the extracted facts.",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Generate an algebraic equation approach using variables for unknowns.",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Generate a unit-based reasoning path focusing on tracking money or items throughout the problem.",
            context=extracted_facts
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble the candidate solutions
        final_solution = await self.ensemble(
            instruction="Select the most consistent and accurate solution among the three approaches.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Revise if necessary — check for logical consistency and unit validity
        revised_solution = await self.revise(
            instruction="Review the final solution for correctness, clarity, and whether it satisfies all constraints in the original problem.",
            context_to_revise=final_solution
        )

        return revised_solution