# Workflow ID: gsm8k_98_0
# Benchmark: gsm8k
# Data Indices: [99, 37]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify key elements and structure
        analysis = await self.generate(
            instruction="Identify all numerical values, operations, and relationships in the problem. Extract known quantities, unknowns, and units."
        )

        # Step 2: Generate multiple solution paths using parallel exploration
        task1 = self.generate(
            instruction="Create a step-by-step plan assuming a linear sequence of operations.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Create an alternative plan that first identifies hidden steps or unit conversions needed.",
            context=analysis
        )
        task3 = self.generate(
            instruction="Create a plan focused on identifying proportional reasoning or rate-based calculations if applicable.",
            context=analysis
        )
        
        plans = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble the best approach based on coherence and completeness
        best_plan = await self.ensemble(
            instruction="Evaluate the three proposed plans and select the one that most clearly addresses all aspects of the problem with logical flow and unit consistency.",
            contexts_to_ensemble=plans
        )

        # Step 4: Generate full solution using the selected plan
        solution = await self.generate(
            instruction="Now solve the problem completely using the chosen strategy. Show each intermediate calculation explicitly.",
            context=best_plan
        )

        # Step 5: Revise for accuracy — test against common pitfalls like order of operations, unit errors, or negative results
        revised_solution = await self.revise(
            instruction="Review the solution for correctness: check arithmetic, unit consistency, and whether the answer makes sense in context (e.g., no negative items). If any issue found, correct it.",
            context_to_revise=solution
        )

        # Step 6: Final verification via bidirectional reasoning (optional but robust)
        verification_prompt = "Based on the final answer, generate an inverse problem that should lead back to the original input values. Solve this inverse problem to confirm consistency."
        inverse_check = await self.generate(
            instruction=verification_prompt,
            context=revised_solution
        )

        # Step 7: Ensemble final output with verification result
        final_answer = await self.ensemble(
            instruction="Choose between the original solution and the inverse-check solution. If they match, return the solution. If not, revise again.",
            contexts_to_ensemble=[revised_solution, inverse_check]
        )

        return final_answer