# Workflow ID: gsm8k_94_0
# Benchmark: gsm8k
# Data Indices: [82, 272]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify key elements (values, unknowns, operations)
        analysis = await self.generate(
            instruction="Identify all known quantities, unknowns, and required mathematical operations from the problem."
        )

        # Step 2: Extract structured data for clarity and unit tracking
        extracted_data = await self.generate(
            instruction="Extract numerical values, units, and relationships into a clear, structured format like: 'Known: [value] [unit]; Unknown: [variable]; Operation: [type]'",
            context=analysis
        )

        # Step 3: Generate multiple solution paths in parallel — one for each major interpretation or approach
        task1 = self.generate(
            instruction="Generate a step-by-step plan assuming this is a rate/proportional problem.",
            context=extracted_data
        )
        task2 = self.generate(
            instruction="Generate a step-by-step plan assuming this is a sequential change problem (e.g., add then subtract).",
            context=extracted_data
        )
        task3 = self.generate(
            instruction="Generate a step-by-step plan assuming this involves distribution or equal sharing.",
            context=extracted_data
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble the three candidate solutions to select the most coherent and accurate one
        final_solution = await self.ensemble(
            instruction="Evaluate and synthesize the three candidate solutions. Choose the one that best fits the original problem's logic and constraints.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional refinement if the answer seems ambiguous or incomplete
        if "how many" not in final_solution.lower() or "answer" not in final_solution.lower():
            refined_solution = await self.revise(
                instruction="Improve the solution by making sure it explicitly states the final numerical answer in a boxed format like \\boxed{X}.",
                context_to_revise=final_solution
            )
            return refined_solution

        return final_solution