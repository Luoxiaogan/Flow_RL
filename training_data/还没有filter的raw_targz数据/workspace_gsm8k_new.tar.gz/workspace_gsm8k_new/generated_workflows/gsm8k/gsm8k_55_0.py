# Workflow ID: gsm8k_55_0
# Benchmark: gsm8k
# Data Indices: [204, 4]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify key elements and structure
        analysis = await self.generate(
            instruction="Identify all numerical values, relationships, unknowns, and required operations in this word problem."
        )

        # Step 2: Extract structured facts (e.g., quantities, units, constraints)
        extracted = await self.generate(
            instruction="From the analysis, extract a clear list of known values, variables, and what must be calculated.",
            context=analysis
        )

        # Step 3: Generate multiple solution paths in parallel — one for each major operation type
        task1 = self.generate("Solve using step-by-step arithmetic progression based on sequence of events.")
        task2 = self.generate("Solve by setting up an equation with unknowns and solving algebraically.")
        task3 = self.generate("Solve by first summarizing the problem into unit-based chunks (e.g., per hour, per person).")

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble the top candidates based on internal consistency and clarity
        final_solution = await self.ensemble(
            instruction="Choose the most consistent, well-structured, and logically sound solution from the three generated options.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Revise if necessary — check for unit errors, negative values, or missing steps
        revised = await self.revise(
            instruction="Review the solution for mathematical accuracy, proper unit handling, and logical flow. Fix any inconsistencies.",
            context_to_revise=final_solution
        )

        return revised