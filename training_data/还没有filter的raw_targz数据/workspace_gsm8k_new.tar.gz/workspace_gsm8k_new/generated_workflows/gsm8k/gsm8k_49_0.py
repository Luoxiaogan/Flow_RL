# Workflow ID: gsm8k_49_0
# Benchmark: gsm8k
# Data Indices: [200, 107]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis – Understand the problem structure and identify key entities/quantities
        analysis = await self.generate(
            instruction="Analyze the problem to identify all quantities, units, relationships, and required operations. Focus on what needs to be calculated."
        )

        # Step 2: Extract Structured Facts – Convert narrative into discrete data points
        extracted_facts = await self.generate(
            instruction="Extract all numerical values, their units, and associated contexts from the analysis. Present as a bullet list with clear labels.",
            context=analysis
        )

        # Step 3: Generate Multiple Solution Paths – Use parallel exploration for robustness
        task1 = self.generate(
            instruction="Generate a step-by-step solution based on chronological order of events or logical sequence (e.g., daily → weekly).",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Generate an alternative solution path focusing on unit conversions and scaling (e.g., convert everything to hours, then multiply by days).",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Generate a third approach that explicitly tracks each entity separately (e.g., commute vs. weekend driving) before combining.",
            context=extracted_facts
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer – Synthesize the best solution from multiple paths
        final_answer = await self.ensemble(
            instruction="Choose the most accurate and consistent answer from the three generated solutions. If they differ, explain why and select the one that aligns best with the original problem constraints.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Revise for Accuracy – Self-check using bidirectional verification if possible
        revised_answer = await self.revise(
            instruction="Review the final answer for correctness in arithmetic, unit consistency, and logical flow. If errors found, correct them directly. Otherwise, return unchanged.",
            context_to_revise=final_answer
        )

        return revised_answer