# Workflow ID: gsm8k_18_0
# Benchmark: gsm8k
# Data Indices: [19, 221]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand problem type and structure
        analysis = await self.generate(
            instruction="Identify the key elements: known quantities, unknowns, units, and relationships. Classify the problem type (e.g., rate, proportion, sequential)."
        )

        # Step 2: Extract structured data from the analysis for precise reasoning
        extraction = await self.generate(
            instruction="Extract all numerical values, units, and operations mentioned in the problem into a structured list format.",
            context=analysis
        )

        # Step 3: Generate multiple solution paths in parallel — one for each likely interpretation or approach
        task1 = self.generate(
            instruction="Solve using direct proportional reasoning: if A quantity relates to B over time, scale accordingly.",
            context=extraction
        )
        task2 = self.generate(
            instruction="Solve by breaking down into unit rates first (e.g., worms per crow per hour), then scale up.",
            context=extraction
        )
        task3 = self.generate(
            instruction="Solve using algebraic modeling: define variables for unknowns and set up equations based on given relationships.",
            context=extraction
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble to select the most consistent and logically sound answer
        final_answer = await self.ensemble(
            instruction="Choose the best solution among the three candidates. Consider consistency with original problem constraints, logical flow, and unit correctness.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional refinement loop for high confidence in critical problems
        if "rate" in analysis.lower() or "proportion" in analysis.lower():
            refined_answer = await self.revise(
                instruction="Review the final answer for accuracy in arithmetic steps, unit handling, and real-world plausibility. If needed, correct any errors.",
                context_to_revise=final_answer
            )
            return refined_answer

        return final_answer