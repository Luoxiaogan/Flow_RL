# Workflow ID: gsm8k_148_0
# Benchmark: gsm8k
# Data Indices: [287, 244]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Identify key entities, quantities, and relationships
        analysis = await self.generate(
            instruction="Identify all named individuals or objects, their quantities, and mathematical relationships in the problem."
        )

        # Step 2: Extract Structured Facts — Convert narrative into clean data points
        extraction = await self.generate(
            instruction="Extract structured facts from the analysis: list each person/quantity and how they relate to others.",
            context=analysis
        )

        # Step 3: Generate Multiple Solution Paths — Use parallel exploration for robustness
        task1 = self.generate(
            instruction="First, solve step-by-step by modeling the problem as a sequence of operations (e.g., compute total sisters' hotdogs first).",
            context=extraction
        )
        task2 = self.generate(
            instruction="Second, solve by setting up algebraic equations based on the relationships described.",
            context=extraction
        )
        task3 = self.generate(
            instruction="Third, solve using proportional reasoning — treat each person’s intake as a multiple of the base unit (sisters' amount).",
            context=extraction
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer — Synthesize best solution from diverse approaches
        final_answer = await self.ensemble(
            instruction="Select the most consistent and logically sound numerical answer across all three solution paths.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Verify Contextual Plausibility — Ensure no negative values, unit consistency, etc.
        verification = await self.revise(
            instruction="Check that the final answer makes sense in the real-world context — e.g., no fractional people, reasonable totals.",
            context_to_revise=final_answer
        )

        return verification