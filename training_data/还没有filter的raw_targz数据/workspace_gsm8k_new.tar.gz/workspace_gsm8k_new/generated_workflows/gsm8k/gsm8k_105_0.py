# Workflow ID: gsm8k_105_0
# Benchmark: gsm8k
# Data Indices: [31, 193]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand the problem structure and identify key elements
        analysis = await self.generate(
            instruction="Identify all numerical values, relationships, units, and required operations in this word problem."
        )

        # Step 2: Extract structured facts from the analysis for precise reasoning
        extracted_facts = await self.generate(
            instruction="From the analysis, extract only the key numbers, units, and mathematical relationships as a bullet list.",
            context=analysis
        )

        # Step 3: Generate multiple solution paths (parallel exploration) — e.g., step-by-step breakdowns or alternative interpretations
        task1 = self.generate(
            instruction="Generate a step-by-step solution plan based on the extracted facts.",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Generate an alternative solution approach focusing on unit consistency and dimensional analysis.",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Generate a solution using algebraic modeling (define variables and equations).",
            context=extracted_facts
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble the top candidate solutions to resolve ambiguity or inconsistency
        final_solution = await self.ensemble(
            instruction="Select the most consistent and logically sound solution among the three candidates. If they differ, choose the one that best aligns with the problem's real-world constraints.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional refinement via iterative revision if needed (e.g., check arithmetic or logical flow)
        revised_solution = await self.revise(
            instruction="Review the final solution for any calculation errors, missing steps, or unit inconsistencies. Correct them if found.",
            context_to_revise=final_solution
        )

        return revised_solution