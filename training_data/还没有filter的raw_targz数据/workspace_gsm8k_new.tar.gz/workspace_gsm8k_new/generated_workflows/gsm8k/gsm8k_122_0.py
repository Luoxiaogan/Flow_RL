# Workflow ID: gsm8k_122_0
# Benchmark: gsm8k
# Data Indices: [26, 72]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify key entities, relationships, and unknowns
        analysis = await self.generate(
            instruction="Identify all named individuals or objects, their known values, and the target unknown in this word problem."
        )

        # Step 2: Extract structured facts from the analysis for easier reasoning
        extraction = await self.generate(
            instruction="Extract all numerical values and relationships between entities into a structured format like 'Entity A: value X, relationship with Entity B'.",
            context=analysis
        )

        # Step 3: Generate multiple solution paths — one linear, one based on unit tracking
        task1 = self.generate(
            instruction="Solve step-by-step by following chronological order of events or dependencies in the problem.",
            context=extraction
        )
        task2 = self.generate(
            instruction="Track units (e.g., years, dollars, items) through each operation to ensure consistency.",
            context=extraction
        )
        solutions = await asyncio.gather(task1, task2)

        # Step 4: Ensemble to select the best solution among competing approaches
        final_answer = await self.ensemble(
            instruction="Choose the most consistent and logically sound solution based on both reasoning paths.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional refinement if the answer seems ambiguous or incomplete
        if "uncertain" in final_answer.lower() or "unknown" in final_answer.lower():
            refined = await self.revise(
                instruction="Improve clarity and precision by explicitly showing intermediate steps and verifying unit consistency.",
                context_to_revise=final_answer
            )
            return refined

        return final_answer