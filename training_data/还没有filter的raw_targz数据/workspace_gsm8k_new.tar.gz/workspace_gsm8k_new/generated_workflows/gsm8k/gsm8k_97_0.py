# Workflow ID: gsm8k_97_0
# Benchmark: gsm8k
# Data Indices: [94, 224]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Analyze the problem to identify key elements and structure
        analysis = await self.generate(
            instruction="Identify all numerical values, relationships, units, and the unknown in this word problem."
        )

        # Step 2: Extract structured facts from the analysis for clarity
        extracted_facts = await self.generate(
            instruction="From the analysis, extract each fact as a key-value pair: 'value', 'unit', 'role' (e.g., known or unknown).",
            context=analysis
        )

        # Step 3: Summarize the extracted facts to reduce noise and focus on math-relevant parts
        concise_facts = await self.summarize(extracted_facts)

        # Step 4: Generate multiple solution paths based on different interpretations or strategies
        path1 = await self.generate(
            instruction="Generate a step-by-step solution assuming this is a sequential operation problem.",
            context=concise_facts
        )
        path2 = await self.generate(
            instruction="Generate a step-by-step solution assuming this is a proportional reasoning problem.",
            context=concise_facts
        )
        path3 = await self.generate(
            instruction="Generate a step-by-step solution assuming this is a rate or unit conversion problem.",
            context=concise_facts
        )

        # Step 5: Ensemble the three candidate solutions to find the most consistent one
        final_solution = await self.ensemble(
            instruction="Select the most coherent and accurate solution based on logical consistency and mathematical correctness.",
            contexts_to_ensemble=[path1, path2, path3]
        )

        # Step 6: Revise the final solution using a second pass to catch hidden errors
        refined_solution = await self.revise(
            instruction="Review the final solution for any arithmetic mistakes, missing steps, or incorrect unit handling.",
            context_to_revise=final_solution
        )

        return refined_solution