# Workflow ID: gsm8k_126_0
# Benchmark: gsm8k
# Data Indices: [113, 122]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Identify key entities, relationships, and unknowns
        analysis = await self.generate(
            instruction="Identify all known values, unknown variables, and mathematical relationships in the problem. List them clearly."
        )

        # Step 2: Extract Structured Data — Convert natural language into clean facts
        extracted_facts = await self.generate(
            instruction="Extract all numerical values and their associated entities (e.g., people, objects) from the analysis. Format as bullet points.",
            context=analysis
        )

        # Step 3: Generate Multiple Solution Paths — Use parallel exploration for robustness
        task1 = self.generate(
            instruction="Generate a step-by-step solution assuming this is a system of equations problem.",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Generate a solution focusing on unit-based reasoning and proportional relationships.",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Generate a solution using sequential operations based on time or order mentioned in the problem.",
            context=extracted_facts
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer — Synthesize best solution from multiple perspectives
        final_answer = await self.ensemble(
            instruction="Select the most consistent and mathematically sound answer from the three generated solutions. If there's disagreement, explain why one is preferred.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional Refinement — Revise if needed to ensure correctness and clarity
        refined_answer = await self.revise(
            instruction="Review the final answer for logical consistency, proper units, and whether it satisfies all constraints in the original problem.",
            context_to_revise=final_answer
        )

        return refined_answer