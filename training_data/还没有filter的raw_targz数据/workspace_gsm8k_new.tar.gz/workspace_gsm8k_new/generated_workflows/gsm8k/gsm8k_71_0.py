# Workflow ID: gsm8k_71_0
# Benchmark: gsm8k
# Data Indices: [280, 233]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify key elements and structure
        analysis = await self.generate(
            instruction="Identify all known quantities, unknowns, and relationships in the problem. Focus on what needs to be calculated."
        )

        # Step 2: Extract structured facts (e.g., numbers, entities, operations)
        extraction = await self.generate(
            instruction="Extract all numerical values, units, and relationships from the analysis. Format as a list of key facts.",
            context=analysis
        )

        # Step 3: Generate multiple solution paths — one linear, one using proportional reasoning if applicable
        linear_path = await self.generate(
            instruction="Generate a step-by-step solution assuming sequential operations based on the extracted facts.",
            context=extraction
        )

        # Check for multi-entity or distribution cues — if found, explore parallel approach
        entity_check = await self.generate(
            instruction="Does the problem involve multiple people/objects with different quantities? If yes, suggest an alternative strategy that tracks each entity separately.",
            context=analysis
        )

        if "multiple" in entity_check.lower() or "each" in entity_check.lower():
            parallel_path = await self.generate(
                instruction="Generate a solution path that explicitly tracks each entity's contribution separately.",
                context=extraction
            )
            candidates = [linear_path, parallel_path]
        else:
            candidates = [linear_path]

        # Step 4: Ensemble to choose best solution among candidates
        final_solution = await self.ensemble(
            instruction="Select the most accurate and logically consistent solution from the candidates. Justify briefly.",
            contexts_to_ensemble=candidates
        )

        # Step 5: Optional refinement loop — revise if answer seems inconsistent
        revision_feedback = await self.generate(
            instruction="Check whether the final answer makes sense in context. If not, suggest corrections.",
            context=final_solution
        )

        if "inconsistent" in revision_feedback.lower() or "not make sense" in revision_feedback.lower():
            refined_solution = await self.revise(
                instruction="Revise the solution to fix inconsistencies while preserving logical steps.",
                context_to_revise=final_solution
            )
            return refined_solution
        else:
            return final_solution