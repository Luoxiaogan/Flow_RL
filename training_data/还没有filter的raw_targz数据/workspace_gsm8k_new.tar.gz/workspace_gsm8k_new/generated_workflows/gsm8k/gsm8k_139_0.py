# Workflow ID: gsm8k_139_0
# Benchmark: gsm8k
# Data Indices: [8, 173]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis – Understand the problem type and extract key entities
        analysis = await self.generate(
            instruction="Identify the mathematical structure of this problem: Is it sequential, proportional, comparative, or multi-entity? Also list all known quantities, units, and unknowns."
        )

        # Step 2: Extract structured data – Turn natural language into clean facts
        extracted_data = await self.generate(
            instruction="From the analysis, extract all numerical values with their associated units and roles (e.g., 'width', 'volume', 'total cost').",
            context=analysis
        )

        # Step 3: Generate multiple solution paths in parallel – Use Diverge-Converge pattern
        task1 = self.generate(
            instruction="Solve step-by-step using basic arithmetic operations only, assuming all units are consistent.",
            context=extracted_data
        )
        task2 = self.generate(
            instruction="Convert all units to a common base first (e.g., inches to feet), then solve.",
            context=extracted_data
        )
        task3 = self.generate(
            instruction="If there's a comparison involved, calculate both totals first, then find the difference.",
            context=extracted_data
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble – Select best solution based on consistency and clarity
        final_answer = await self.ensemble(
            instruction="Compare the three generated solutions. Choose the one that correctly handles units, follows logical steps, and matches expected answer format (integer or decimal). If uncertain, pick the most detailed and mathematically sound approach.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional refinement – Revise if needed for clarity or correctness
        revised_answer = await self.revise(
            instruction="Check if the final answer makes sense in context. Does it reflect the correct unit? Is it logically derived from the problem? If not, improve it.",
            context_to_revise=final_answer
        )

        return revised_answer