# Workflow ID: gsm8k_136_0
# Benchmark: gsm8k
# Data Indices: [64, 15]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis – Understand the problem structure and identify knowns/unknowns
        analysis = await self.generate(
            instruction="Analyze the problem to identify all numerical values, relationships, units, and what needs to be calculated. Output as structured facts."
        )

        # Step 2: Extract Key Facts – Convert unstructured analysis into clean data points
        extracted_facts = await self.generate(
            instruction="Extract only the key numerical values, variables, and relationships from the analysis. Format as bullet points.",
            context=analysis
        )

        # Step 3: Generate Multiple Solution Paths – Use parallel exploration for robustness
        task1 = self.generate(
            instruction="Based on the extracted facts, generate a step-by-step solution assuming a linear approach (order matters).",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Generate an alternative solution path by first solving for intermediate unknowns before final calculation.",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Generate a solution focusing on unit conversions or proportional reasoning if applicable.",
            context=extracted_facts
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer – Synthesize best solution from multiple approaches
        final_answer = await self.ensemble(
            instruction="Compare the three generated solutions and select the one that is most consistent with the problem's logic and constraints. If there are discrepancies, resolve them based on mathematical validity and contextual plausibility.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Revise for Accuracy – Self-check using bidirectional verification
        revised_answer = await self.revise(
            instruction="Verify the correctness of the answer by checking if it makes sense in context and satisfies all given conditions. If not, revise accordingly.",
            context_to_revise=final_answer
        )

        return revised_answer