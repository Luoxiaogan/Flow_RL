# Workflow ID: gsm8k_100_0
# Benchmark: gsm8k
# Data Indices: [235, 106]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify key elements and problem type
        analysis = await self.generate(
            instruction="Identify all known quantities, unknowns, and relationships in the problem. Classify it as sequential, rate, proportional, distribution, comparison, or multi-entity."
        )

        # Step 2: Extract structured facts from analysis for clearer reasoning
        extracted_facts = await self.generate(
            instruction="Extract only the numerical values and their roles (e.g., 'Joe's bid = $160,000') from the analysis. Format clearly as bullet points.",
            context=analysis
        )

        # Step 3: Generate multiple solution paths based on different interpretations or strategies
        task1 = self.generate(
            instruction="Solve using direct arithmetic: compute thrice Joe’s bid, then add $2000. Only show final calculation.",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Set up an equation: Let Nelly’s bid be x. Then x = 3*Joe's bid + 2000. Solve for x.",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Break into steps: First calculate 3 times Joe’s bid, then add 2000. Show each step explicitly.",
            context=extracted_facts
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble the candidate solutions to resolve discrepancies
        final_answer = await self.ensemble(
            instruction="Choose the most consistent and mathematically sound answer from these three approaches. If they differ, explain why one is likely correct.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional refinement if the ensemble result seems uncertain
        if "uncertain" in final_answer.lower() or "discrepancy" in final_answer.lower():
            refined_answer = await self.revise(
                instruction="Refine the answer by checking units, order of operations, and whether the result makes sense in context.",
                context_to_revise=final_answer
            )
            return refined_answer

        return final_answer