# Workflow ID: gsm8k_30_0
# Benchmark: gsm8k
# Data Indices: [81, 249]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand structure and identify key elements
        analysis = await self.generate(
            instruction="Identify all quantities, relationships, and unknowns in the problem. Extract numerical values and their roles (e.g., totals, parts, differences)."
        )

        # Step 2: Extract structured data from analysis for reliable reasoning
        extracted_data = await self.generate(
            instruction="From the analysis, extract a clear list of known values and what must be calculated. Format as bullet points with units if applicable.",
            context=analysis
        )

        # Step 3: Generate multiple solution paths in parallel — one linear, one based on proportional reasoning
        task1 = self.generate(
            instruction="Solve step-by-step using sequential operations: process each sentence in order, updating running totals or intermediate values.",
            context=extracted_data
        )
        task2 = self.generate(
            instruction="Use proportional reasoning: determine ratios or fractions that relate given quantities to the unknown. Solve algebraically if needed.",
            context=extracted_data
        )
        solutions = await asyncio.gather(task1, task2)

        # Step 4: Ensemble to select best solution based on consistency and clarity
        final_answer = await self.ensemble(
            instruction="Compare both solutions. Choose the one that logically follows from the problem description and produces a valid numerical result consistent with units and constraints.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional refinement if the answer seems ambiguous or incomplete
        if "unknown" in final_answer.lower() or "not enough" in final_answer.lower():
            refined = await self.revise(
                instruction="Revise the solution by re-examining the original problem to ensure no steps were missed or misinterpreted. Pay attention to hidden steps like total subtraction or unit conversions.",
                context_to_revise=final_answer
            )
            return refined

        return final_answer