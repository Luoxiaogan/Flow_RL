# Workflow ID: gsm8k_28_0
# Benchmark: gsm8k
# Data Indices: [210, 97]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Analyze the problem to identify key elements (values, operations, unknowns)
        analysis = await self.generate(
            instruction="Extract all known numerical values, units, and relationships from the problem. Identify what needs to be calculated."
        )

        # Step 2: Generate multiple solution paths in parallel — one for each major type of math involved
        task1 = self.generate(
            instruction="Generate a step-by-step solution focusing on basic arithmetic operations like addition, subtraction, multiplication, division.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Generate a solution focused on proportional reasoning or percentages if applicable.",
            context=analysis
        )
        task3 = self.generate(
            instruction="Generate a solution that explicitly tracks units throughout the calculation to ensure consistency.",
            context=analysis
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble the three candidate solutions to select the most robust answer
        final_answer = await self.ensemble(
            instruction="Choose the most consistent and accurate solution based on the three generated approaches. If there's disagreement, resolve it using logical reasoning.",
            contexts_to_ensemble=solutions
        )

        # Step 4: Optional refinement loop – check if the answer makes sense in context
        # This ensures real-world constraints (e.g., no negative quantities) are respected
        verification = await self.revise(
            instruction="Check whether the final answer is logically consistent with the original problem statement. For example, verify it doesn't violate unit constraints or result in impossible values like negative items.",
            context_to_revise=final_answer
        )

        return verification