# Workflow ID: gsm8k_114_0
# Benchmark: gsm8k
# Data Indices: [211, 253]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Extract key numerical values and relationships from the problem
        extraction = await self.generate(
            instruction="Extract all known quantities, units, and relationships from the problem. Focus on numbers, operations implied, and what needs to be found."
        )

        # Step 2: Generate a high-level solution plan based on extracted info
        planning = await self.generate(
            instruction="Based on the extracted information, outline a step-by-step plan to solve the problem. Identify intermediate steps and required operations.",
            context=extraction
        )

        # Step 3: Use parallel exploration to generate multiple possible interpretations or approaches
        task1 = self.generate("Approach 1: Solve directly using basic arithmetic based on the plan.")
        task2 = self.generate("Approach 2: Model this as a division with remainder if applicable.")
        task3 = self.generate("Approach 3: Formulate an equation and solve for the unknown.")

        results = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble the candidate solutions to choose the most consistent one
        final_answer = await self.ensemble(
            instruction="Evaluate the three proposed solutions. Choose the one that best fits the original problem's constraints and makes logical sense.",
            contexts_to_ensemble=results
        )

        # Step 5: Optional refinement via revision if needed (e.g., unit check or sanity test)
        revised_answer = await self.revise(
            instruction="Check whether the final answer aligns with real-world constraints (e.g., no negative boxes, whole numbers where expected). If not, revise accordingly.",
            context_to_revise=final_answer
        )

        return revised_answer