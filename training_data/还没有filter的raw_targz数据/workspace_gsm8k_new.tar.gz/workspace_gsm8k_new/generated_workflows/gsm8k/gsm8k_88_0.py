# Workflow ID: gsm8k_88_0
# Benchmark: gsm8k
# Data Indices: [105, 284]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand the problem type and key elements
        analysis = await self.generate(
            instruction="Identify the known values, unknowns, units, and mathematical operations required to solve this problem."
        )

        # Step 2: Extract Structured Facts — Convert natural language into clean numerical relationships
        extracted_facts = await self.generate(
            instruction="Extract all relevant numerical values, quantities, and their relationships from the analysis. Format as bullet points with clear variables (e.g., 'total_books = 9900', 'fraction_remaining = 4/6').",
            context=analysis
        )

        # Step 3: Generate Multiple Solution Paths — Use parallel exploration for robustness
        task1 = self.generate(
            instruction="Solve using direct calculation based on extracted facts.",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Solve by first computing the difference between total and remaining, then verifying it matches expected logic.",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Break down the problem into steps: identify what's given, what needs to be found, and compute step-by-step in order.",
            context=extracted_facts
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer — Select best-supported solution
        final_answer = await self.ensemble(
            instruction="Choose the most consistent and logically sound answer from the three candidate solutions. If there is disagreement, resolve based on clarity and correctness of reasoning.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Verify Against Problem Context — Ensure answer makes sense in real-world terms
        verification = await self.revise(
            instruction="Check if the final answer aligns with the original problem constraints (e.g., no negative items, valid units, logical consistency). If not, revise accordingly.",
            context_to_revise=final_answer
        )

        return verification