# Workflow ID: gsm8k_112_0
# Benchmark: gsm8k
# Data Indices: [83, 295]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify key elements (values, unknowns, operations)
        analysis = await self.generate(
            instruction="Identify all known quantities, unknowns, and mathematical relationships in the problem."
        )

        # Step 2: Extract structured data from the analysis to guide reasoning
        extracted_data = await self.generate(
            instruction="Extract the numerical values and their units, along with the question being asked.",
            context=analysis
        )

        # Step 3: Generate multiple solution paths based on different interpretations or approaches
        path1 = self.generate(
            instruction="Solve step-by-step using sequential arithmetic based on the order described in the problem.",
            context=extracted_data
        )
        path2 = self.generate(
            instruction="Model the problem as a system of equations if applicable, then solve algebraically.",
            context=extracted_data
        )
        path3 = self.generate(
            instruction="Break down the problem into sub-problems: first find total cost, then max quantity possible.",
            context=extracted_data
        )

        # Step 4: Parallel exploration → Ensemble to select best candidate
        candidates = [path1, path2, path3]
        ensemble_result = await self.ensemble(
            instruction="Compare the three solution paths. Choose the one that most consistently follows the problem logic and produces a valid numerical answer.",
            contexts_to_ensemble=candidates
        )

        # Step 5: Revise the final solution for clarity, correctness, and unit consistency
        final_solution = await self.revise(
            instruction="Check the final solution for logical consistency, proper units, and correctness against the original problem constraints. If needed, refine the explanation and ensure it answers exactly what was asked.",
            context_to_revise=ensemble_result
        )

        return final_solution