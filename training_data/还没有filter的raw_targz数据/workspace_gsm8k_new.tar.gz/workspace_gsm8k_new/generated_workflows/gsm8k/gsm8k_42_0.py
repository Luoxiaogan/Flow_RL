# Workflow ID: gsm8k_42_0
# Benchmark: gsm8k
# Data Indices: [42, 174]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand the problem structure
        analysis = await self.generate(
            instruction="Identify all known values, unknowns, and relationships in the problem. Focus on quantities, units, and operations needed."
        )

        # Step 2: Extract structured facts (e.g., numbers, entities, operations)
        extracted_facts = await self.generate(
            instruction="From the analysis, extract key numerical values and their associated context (e.g., 'Jenny has 1 person', 'cost per night is $40').",
            context=analysis
        )

        # Step 3: Generate multiple solution paths using parallel exploration
        task1 = self.generate(
            instruction="Generate a step-by-step solution assuming sequential calculation (e.g., compute total people first, then cost).",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Generate an alternative solution focusing on unit-based reasoning (e.g., calculate total nights × cost per night × people).",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Generate a solution that explicitly tracks units at each step (e.g., dollars, persons, nights).",
            context=extracted_facts
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble the best solution based on consistency and clarity
        final_solution = await self.ensemble(
            instruction="Select the most accurate and coherent solution from the three generated options.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional refinement if the solution seems ambiguous or incomplete
        if "step" not in final_solution.lower() or "answer" not in final_solution.lower():
            final_solution = await self.revise(
                instruction="Improve clarity and completeness by adding explicit steps and verifying the final answer matches the question.",
                context_to_revise=final_solution
            )

        return final_solution