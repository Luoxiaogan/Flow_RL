# Workflow ID: gsm8k_64_0
# Benchmark: gsm8k
# Data Indices: [283, 65]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify key elements (values, relationships, unknowns)
        analysis = await self.generate(
            instruction="Extract all numerical values, entities, and relationships from the problem. Identify what needs to be calculated."
        )

        # Step 2: Generate multiple solution paths in parallel — one for each major interpretation or sub-problem
        task1 = self.generate(
            instruction="Break down the problem into sequential steps based on chronological order or dependency chains.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Identify units involved (dollars, feet, items) and ensure they are tracked consistently throughout the solution.",
            context=analysis
        )
        task3 = self.generate(
            instruction="Determine if any hidden steps are required (e.g., intermediate calculations not explicitly stated).",
            context=analysis
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble the three candidate solutions to resolve contradictions and refine the best approach
        refined_solution = await self.ensemble(
            instruction="Compare the three proposed solutions. Select the most coherent, logically consistent, and mathematically sound approach that addresses all parts of the problem.",
            contexts_to_ensemble=solutions
        )

        # Step 4: Revise the final solution iteratively using different verification lenses
        revised_solution = await self.revise(
            instruction="Verify the solution by checking unit consistency, arithmetic correctness, and logical flow. If errors found, correct them.",
            context_to_revise=refined_solution
        )

        # Step 5: Final summary to ensure clarity and completeness
        final_answer = await self.summarize(
            context_to_summarize=revised_solution
        )

        return final_answer