# Workflow ID: gsm8k_116_0
# Benchmark: gsm8k
# Data Indices: [129, 25]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis – Identify key entities, values, and relationships
        analysis = await self.generate(
            instruction="Identify all numerical values, variables, and relationships in the problem. Extract key facts as structured points."
        )

        # Step 2: Decompose into sub-problems if needed (e.g., multi-entity or nested logic)
        decomposition = await self.generate(
            instruction="Break down the problem into smaller, sequential steps based on the relationships identified. List each step clearly.",
            context=analysis
        )

        # Step 3: Parallel Exploration – Generate multiple solution paths (if ambiguity exists)
        tasks = [
            self.generate("Solve using a direct arithmetic approach.", context=decomposition),
            self.generate("Solve by modeling the problem as an algebraic equation.", context=decomposition),
            self.generate("Solve by tracking units and scaling relationships step-by-step.", context=decomposition)
        ]
        solutions = await asyncio.gather(*tasks)

        # Step 4: Ensemble to select best solution from diverse approaches
        final_answer = await self.ensemble(
            instruction="Choose the most consistent and accurate solution among the candidates based on logical coherence and mathematical correctness.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Revise for accuracy and unit consistency
        revised_answer = await self.revise(
            instruction="Review the final answer for correctness, unit consistency, and whether it makes sense in the real-world context described.",
            context_to_revise=final_answer
        )

        return revised_answer