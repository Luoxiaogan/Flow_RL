# Workflow ID: gsm8k_48_0
# Benchmark: gsm8k
# Data Indices: [254, 212]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand the problem structure and identify key elements
        analysis = await self.generate(
            instruction="Identify all quantities, relationships, and what needs to be calculated. Extract named entities (people, objects) and their associated values or operations."
        )

        # Step 2: Extract Structured Facts — Convert narrative into actionable facts
        extracted_facts = await self.generate(
            instruction="From the analysis, extract structured facts as bullet points: 'Entity: Value/Operation'. Avoid interpretation—just list raw data.",
            context=analysis
        )

        # Step 3: Generate Multiple Solution Paths — Explore different reasoning orders
        path1 = self.generate(
            instruction="Solve using sequential steps from left to right in the text order.",
            context=extracted_facts
        )
        path2 = self.generate(
            instruction="Solve by identifying the final unknown first, then work backward to find it.",
            context=extracted_facts
        )
        path3 = self.generate(
            instruction="Break the problem into sub-problems based on entities involved (e.g., Martha's cat, Cara's cat). Solve each independently and combine.",
            context=extracted_facts
        )

        # Step 4: Parallel Execution — Run all three paths concurrently
        solutions = await asyncio.gather(path1, path2, path3)

        # Step 5: Ensemble Final Answer — Compare and choose the most consistent solution
        final_answer = await self.ensemble(
            instruction="Select the answer that best matches across all three approaches. If there is disagreement, prioritize the one that correctly handles unit tracking and logical dependencies.",
            contexts_to_ensemble=solutions
        )

        # Step 6: Optional Refinement — Check for consistency and correctness
        revised_final = await self.revise(
            instruction="Verify the final answer makes sense in context. Does it respect real-world constraints (e.g., no negative animals)? Is the calculation mathematically sound?",
            context_to_revise=final_answer
        )

        return revised_final