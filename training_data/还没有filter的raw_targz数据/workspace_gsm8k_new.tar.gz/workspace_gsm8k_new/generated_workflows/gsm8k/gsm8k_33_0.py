# Workflow ID: gsm8k_33_0
# Benchmark: gsm8k
# Data Indices: [39, 230]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis
        analysis = await self.generate(
            instruction="Identify all numerical values, quantities, and relationships in the problem. Extract key entities and operations needed."
        )

        # Step 2: Extract Structured Data (Parallel Exploration)
        tasks = [
            self.generate("List all known quantities and their units from the problem.", context=analysis),
            self.generate("Identify the sequence of events or operations described in chronological order.", context=analysis),
            self.generate("Determine what the final question is asking for—what value must be computed?", context=analysis)
        ]
        extracted_data, timeline, goal = await asyncio.gather(*tasks)

        # Step 3: Generate Multiple Solution Paths (Parallel Exploration)
        solution_paths = []
        paths_to_generate = [
            ("Sequential Calculation", "Build a step-by-step plan using the timeline."),
            ("Unit-Based Tracking", "Track units (e.g., books, cookies) at each step to ensure consistency."),
            ("Mathematical Modeling", "Convert the scenario into mathematical expressions.")
        ]
        
        async def generate_path(name, instruction):
            return await self.generate(instruction, context=f"{timeline}\n\n{extracted_data}")
        
        path_tasks = [generate_path(name, instr) for name, instr in paths_to_generate]
        solution_paths = await asyncio.gather(*path_tasks)

        # Step 4: Ensemble Final Solution
        final_instruction = (
            "You have generated multiple solution approaches. "
            "Compare them for consistency, logical flow, and correctness. "
            "Select the most robust and mathematically sound approach. "
            "Provide the final answer as a single numerical value."
        )
        final_answer = await self.ensemble(final_instruction, solution_paths)

        # Step 5: Revise for Accuracy (Iterative Refinement)
        revise_instruction = (
            "Review the final answer carefully. Check if it makes sense in the context of the original problem. "
            "Ensure no steps were skipped or misinterpreted. If necessary, adjust the answer based on logical consistency."
        )
        refined_answer = await self.revise(revise_instruction, final_answer)

        return refined_answer