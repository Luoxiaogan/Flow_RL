# Workflow ID: gsm8k_46_0
# Benchmark: gsm8k
# Data Indices: [160, 238]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand what needs to be calculated
        analysis = await self.generate(
            instruction="Identify all quantities, operations, and relationships in the problem. Extract key values, units, and target unknowns."
        )

        # Step 2: Structure the Problem — Break into sub-components if needed
        structured_plan = await self.generate(
            instruction="Based on the analysis, break the problem into clear steps: identify knowns, unknowns, required operations, and sequence them logically.",
            context=analysis
        )

        # Step 3: Parallel Exploration — Generate multiple solution paths for robustness
        task1 = self.generate(
            instruction="Solve step-by-step using arithmetic order: compute each item's discounted price first, then sum totals.",
            context=structured_plan
        )
        task2 = self.generate(
            instruction="Reframe as algebraic expressions: define variables for unknowns, set up equations from given relations, solve for final answer.",
            context=structured_plan
        )
        task3 = self.generate(
            instruction="Use unit tracking: maintain dollars, percentages, and item counts explicitly at every step to avoid errors.",
            context=structured_plan
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble — Select best solution based on consistency and clarity
        final_answer = await self.ensemble(
            instruction="Evaluate the three candidate solutions. Choose the one that is most consistent with the original problem, mathematically sound, and clearly explained.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Final Verification — Self-check for realism and correctness
        verification = await self.revise(
            instruction="Review the final answer: does it make sense in context? Are units correct? Is it plausible (e.g., no negative items)? If not, revise accordingly.",
            context_to_revise=final_answer
        )

        return verification