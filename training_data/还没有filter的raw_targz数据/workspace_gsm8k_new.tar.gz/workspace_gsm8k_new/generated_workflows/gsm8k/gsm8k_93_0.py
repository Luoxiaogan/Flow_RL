# Workflow ID: gsm8k_93_0
# Benchmark: gsm8k
# Data Indices: [100, 70]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand the structure and key elements
        analysis = await self.generate(
            instruction="Identify all numerical values, operations, and relationships in the problem. List them clearly."
        )

        # Step 2: Extract Structured Facts — Convert unstructured text into structured data
        extracted = await self.generate(
            instruction="From the analysis, extract key facts as bullet points: known values, unknowns, units, and required operations.",
            context=analysis
        )

        # Step 3: Generate Multiple Solution Paths — Explore different reasoning strategies
        task1 = self.generate(
            instruction="Solve using a linear step-by-step approach, following the chronological order described in the problem."
        )
        task2 = self.generate(
            instruction="Break down the problem into sub-components (e.g., time to heat, time to cool) and calculate each separately."
        )
        task3 = self.generate(
            instruction="Use proportional reasoning if applicable — e.g., rate × time = change in value."
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer — Select best solution based on consistency and clarity
        final_answer = await self.ensemble(
            instruction="Compare the three proposed solutions. Choose the one that is most consistent with the problem constraints and mathematically sound.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Revise for Accuracy — Self-check by verifying units, logic, and arithmetic
        revised = await self.revise(
            instruction="Review the final answer carefully. Check for unit consistency, logical flow, and whether it makes sense in context. If any issue is found, correct it.",
            context_to_revise=final_answer
        )

        return revised