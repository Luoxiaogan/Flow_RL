# Workflow ID: gsm8k_129_0
# Benchmark: gsm8k
# Data Indices: [55, 268]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand what needs to be calculated
        analysis = await self.generate(
            instruction="Identify all known quantities and the unknown in this word problem. Focus on mathematical relationships like addition, subtraction, multiplication, division, or comparisons."
        )

        # Step 2: Extract Structured Data — Turn narrative into usable facts
        extracted_data = await self.generate(
            instruction="From the analysis, extract numerical values and their associated entities (e.g., 'tomatoes: 2073', 'corn: 4112'). Use clear labels for each quantity.",
            context=analysis
        )

        # Step 3: Generate Multiple Solution Paths — Explore different interpretations if ambiguous
        path1 = self.generate(
            instruction="First approach: Solve step-by-step based on direct operations described in the problem text.",
            context=extracted_data
        )
        path2 = self.generate(
            instruction="Second approach: Break down the problem using proportional reasoning or unit-based calculations if applicable.",
            context=extracted_data
        )
        path3 = self.generate(
            instruction="Third approach: Consider whether there are hidden steps or constraints (like non-negative results) that must be enforced.",
            context=extracted_data
        )

        # Step 4: Parallel Execution & Ensemble — Combine diverse solutions robustly
        tasks = [path1, path2, path3]
        parallel_solutions = await asyncio.gather(*tasks)
        final_solution = await self.ensemble(
            instruction="Select the most consistent and mathematically sound solution from these three approaches. If they differ, choose the one that aligns best with the original problem's wording and constraints.",
            contexts_to_ensemble=parallel_solutions
        )

        # Step 5: Refinement Loop — Improve final answer through iterative self-checking
        revised_solution = await self.revise(
            instruction="Check for logical consistency, unit correctness, and arithmetic accuracy. If any issue is found, correct it while preserving the core structure of the solution.",
            context_to_revise=final_solution
        )

        # Step 6: Final Summary — Condense the full reasoning chain into a concise output
        final_output = await self.summarize(
            context_to_summarize=revised_solution
        )

        return final_output