# Workflow ID: gsm8k_113_0
# Benchmark: gsm8k
# Data Indices: [179, 146]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis - Understand the problem structure and identify key elements
        analysis = await self.generate(
            instruction="Identify all numerical values, quantities, units, and relationships in the problem. Extract entities like people, items, prices, rates, times, and operations required."
        )

        # Step 2: Structure Extraction - Turn raw text into structured facts
        structured_facts = await self.generate(
            instruction="Based on the analysis, extract all known values and their units (e.g., price per item, quantity sold, speed, distance). Format as a list of key-value pairs.",
            context=analysis
        )

        # Step 3: Parallel Solution Attempts - Generate multiple valid approaches
        task1 = self.generate(
            instruction="Create a step-by-step solution path using basic arithmetic operations based on the extracted facts.",
            context=structured_facts
        )
        task2 = self.generate(
            instruction="Generate an alternative solution approach that explicitly tracks units at each step to avoid errors.",
            context=structured_facts
        )
        task3 = self.generate(
            instruction="Propose a solution using proportional reasoning or rate-based calculations if applicable.",
            context=structured_facts
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer - Choose best solution based on consistency and clarity
        final_answer = await self.ensemble(
            instruction="Evaluate the three proposed solutions. Select the one that correctly applies mathematical principles, maintains unit consistency, and matches the expected answer format (single number).",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional Refinement - If the answer seems ambiguous, revise once more
        if "unknown" in final_answer.lower() or "cannot determine" in final_answer.lower():
            refined = await self.revise(
                instruction="The previous ensemble did not yield a clear numerical result. Re-evaluate the original problem and the extracted facts to resolve ambiguity.",
                context_to_revise=final_answer
            )
            return refined

        return final_answer