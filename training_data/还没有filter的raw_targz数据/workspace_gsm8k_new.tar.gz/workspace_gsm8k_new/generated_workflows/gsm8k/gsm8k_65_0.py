# Workflow ID: gsm8k_65_0
# Benchmark: gsm8k
# Data Indices: [263, 202]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Identify key entities, quantities, and operations
        analysis = await self.generate(
            instruction="Identify all numerical values, units, relationships, and required calculations in the problem."
        )

        # Step 2: Extract Structured Facts — Convert natural language into structured math facts
        extracted_facts = await self.generate(
            instruction="Extract all known values, units, and mathematical relationships as a clear list of facts.",
            context=analysis
        )

        # Step 3: Generate Multiple Solution Paths — Use parallel exploration to explore different interpretations or steps
        task1 = self.generate(
            instruction="First, solve by calculating total cost for individual items separately.",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Second, solve by applying bulk discounts or group pricing if applicable.",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Third, solve by tracking each entity (e.g., teachers vs friends) separately.",
            context=extracted_facts
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble — Compare and synthesize the best solution from multiple paths
        final_solution = await self.ensemble(
            instruction="Compare the three candidate solutions. Select the most accurate one based on consistency with the problem constraints.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Final Verification — Revise using a backward-checking strategy to ensure correctness
        verification = await self.revise(
            instruction="Check that the final answer makes sense in context: does it respect units, quantities, and logical order? If not, correct it.",
            context_to_revise=final_solution
        )

        return verification