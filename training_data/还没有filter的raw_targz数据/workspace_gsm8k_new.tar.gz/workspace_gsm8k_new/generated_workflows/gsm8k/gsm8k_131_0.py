# Workflow ID: gsm8k_131_0
# Benchmark: gsm8k
# Data Indices: [145, 167]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify key elements and structure
        analysis = await self.generate(
            instruction="Identify all numerical values, relationships, units, and operations required in this word problem."
        )

        # Step 2: Extract structured facts from the analysis (e.g., quantities, rules, constraints)
        structured_data = await self.generate(
            instruction="Extract all relevant numerical values, ratios, and rules into a clean list format.",
            context=analysis
        )

        # Step 3: Generate multiple solution paths using parallel exploration
        task1 = self.generate(
            instruction="Solve step-by-step by following the chronological order of events described.",
            context=structured_data
        )
        task2 = self.generate(
            instruction="Break down the problem into sub-problems based on different entities (e.g., jackets vs t-shirts).",
            context=structured_data
        )
        task3 = self.generate(
            instruction="Use proportional reasoning to compute totals considering free items or discounts.",
            context=structured_data
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble to select the most consistent and logically sound answer
        final_answer = await self.ensemble(
            instruction="Evaluate the three candidate solutions and choose the one that best matches the problem's logic and constraints.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional refinement if there's ambiguity or inconsistency
        if "inconsistent" in final_answer.lower() or "multiple" in final_answer.lower():
            refined_answer = await self.revise(
                instruction="Refine the answer by checking unit consistency, logical flow, and ensuring no negative values or impossible results.",
                context_to_revise=final_answer
            )
            return refined_answer

        return final_answer