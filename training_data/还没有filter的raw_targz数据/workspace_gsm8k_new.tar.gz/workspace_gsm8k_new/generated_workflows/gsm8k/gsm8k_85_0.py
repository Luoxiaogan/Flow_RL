# Workflow ID: gsm8k_85_0
# Benchmark: gsm8k
# Data Indices: [175, 151]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis - Understand the problem structure and identify key entities
        analysis = await self.generate(
            instruction="Identify all people, quantities, relationships, and unknowns in the problem. List them clearly."
        )

        # Step 2: Extract Key Facts - Convert narrative into structured data
        extracted_facts = await self.generate(
            instruction="From the analysis, extract only the numerical values and their associated relationships (e.g., 'Marcia has twice Cindi's pencils').",
            context=analysis
        )

        # Step 3: Generate Multiple Solution Paths - Explore different reasoning approaches
        path1 = self.generate(
            instruction="Solve by starting from the known quantity (Cindi) and working forward step-by-step to Donna and Marcia.",
            context=extracted_facts
        )
        path2 = self.generate(
            instruction="Solve by setting up equations based on proportional relationships between people.",
            context=extracted_facts
        )
        path3 = self.generate(
            instruction="Solve by creating a table or diagram showing how each person's quantity relates to another.",
            context=extracted_facts
        )

        # Step 4: Parallel Ensemble - Compare and synthesize multiple solution paths
        ensemble_result = await self.ensemble(
            instruction="Compare the three solution paths. Select the most consistent one that matches all given constraints.",
            contexts_to_ensemble=[path1, path2, path3]
        )

        # Step 5: Refine with Bidirectional Verification - Check if the answer makes sense in reverse
        verification_check = await self.generate(
            instruction="Now generate an inverse problem using the final answer: if this is correct, what would the original input need to be? Does it match the initial problem?",
            context=ensemble_result
        )

        # Step 6: Final Revision - Improve clarity and correctness based on verification
        final_solution = await self.revise(
            instruction="Improve the solution to ensure it’s clear, logically sound, and includes all steps explicitly.",
            context_to_revise=ensemble_result
        )

        return final_solution