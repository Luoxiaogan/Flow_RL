# Workflow ID: gsm8k_147_0
# Benchmark: gsm8k
# Data Indices: [80, 11]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand structure and identify key elements
        analysis = await self.generate(
            instruction="Analyze the problem to identify known quantities, unknowns, relationships, and required operations. Focus on what needs to be calculated."
        )

        # Step 2: Extract Structured Data — Convert natural language into clear facts
        extracted_facts = await self.generate(
            instruction="From the analysis, extract all numerical values, variables, and their roles (e.g., 'bananas per loaf', 'loaves made on Monday').",
            context=analysis
        )

        # Step 3: Generate Multiple Reasoning Paths — Use parallel exploration for robustness
        task1 = self.generate(
            instruction="Generate a step-by-step solution based on sequential reasoning: solve one operation at a time in order.",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Generate an alternative solution using algebraic modeling: define variables and set up equations.",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Generate a solution using proportional reasoning or unit-based calculations if applicable.",
            context=extracted_facts
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer — Select best-supported solution from multiple approaches
        final_answer = await self.ensemble(
            instruction="Evaluate the three candidate solutions. Choose the one that is most consistent with the problem constraints and makes logical sense.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional Refinement — If the answer seems ambiguous or inconsistent, revise once more
        if "cannot determine" in final_answer.lower() or "not enough information" in final_answer.lower():
            revised_answer = await self.revise(
                instruction="Revise the answer by re-examining the original problem for hidden steps or missing constraints.",
                context_to_revise=final_answer
            )
            return revised_answer

        return final_answer