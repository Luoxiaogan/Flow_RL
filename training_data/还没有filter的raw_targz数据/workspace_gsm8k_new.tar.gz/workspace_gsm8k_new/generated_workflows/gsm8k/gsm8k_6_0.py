# Workflow ID: gsm8k_6_0
# Benchmark: gsm8k
# Data Indices: [45, 239]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Extract key numerical values and relationships from the problem
        extraction = await self.generate(
            instruction="Extract all numerical values, units, and relationships from the problem. List them clearly."
        )

        # Step 2: Generate an initial solution plan based on the extracted facts
        plan = await self.generate(
            instruction="Based on the extracted facts, generate a step-by-step solution plan that identifies what to calculate first, second, etc.",
            context=extraction
        )

        # Step 3: Parallel exploration of multiple interpretations or approaches if needed
        # Use Ensemble only if there's ambiguity — detect via analysis
        analysis = await self.generate(
            instruction="Analyze whether the problem has ambiguous steps or multiple valid interpretations. If yes, list possible approaches.",
            context=plan
        )
        
        if "ambiguous" in analysis.lower() or "multiple" in analysis.lower():
            # Parallel paths: different solution strategies
            task1 = self.generate(
                instruction="Generate one possible solution path using direct arithmetic interpretation.",
                context=extraction
            )
            task2 = self.generate(
                instruction="Generate an alternative solution path focusing on unit conversions or hidden steps.",
                context=extraction
            )
            task3 = self.generate(
                instruction="Generate a third solution path by identifying potential rate or proportional reasoning elements.",
                context=extraction
            )
            
            results = await asyncio.gather(task1, task2, task3)
            final_solution = await self.ensemble(
                instruction="Choose the most consistent and logically sound solution among the three candidates.",
                contexts_to_ensemble=results
            )
        else:
            # Linear decomposition for straightforward problems
            final_solution = await self.generate(
                instruction="Using the plan, now compute the final answer step-by-step with clear intermediate calculations.",
                context=plan
            )

        # Step 4: Refine the solution through iterative revision to ensure correctness
        revised_solution = await self.revise(
            instruction="Review the solution carefully for errors in arithmetic, unit consistency, or logical flow. Correct any mistakes.",
            context_to_revise=final_solution
        )

        # Optional: Bidirectional verification for high-stakes accuracy (if time permits)
        # For now, we'll assume it's always beneficial to do a quick check
        verification = await self.generate(
            instruction="Create a simple inverse problem based on the final answer and verify that it leads back to the original scenario.",
            context=revised_solution
        )

        # Final ensemble to resolve any remaining uncertainty
        final_output = await self.ensemble(
            instruction="Return the final numerical answer. Ensure it matches the question format and makes sense in context.",
            contexts_to_ensemble=[revised_solution, verification]
        )

        return final_output