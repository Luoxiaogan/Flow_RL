# Workflow ID: gsm8k_76_0
# Benchmark: gsm8k
# Data Indices: [53, 201]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Extract key numerical values and relationships
        extraction = await self.generate(
            instruction="Identify all numerical values, units, and operations mentioned in the problem. List them clearly."
        )

        # Step 2: Analyze structure — determine if it's sequential, proportional, or multi-step
        analysis = await self.generate(
            instruction="Based on the extracted information, classify the problem type (e.g., sequential, rate, proportion, distribution).",
            context=extraction
        )

        # Step 3: Generate multiple solution paths using parallel exploration
        task1 = self.generate(
            instruction="Solve step-by-step using a linear decomposition approach.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Generate an alternative solution path by first identifying hidden steps not explicitly stated.",
            context=analysis
        )
        task3 = self.generate(
            instruction="Propose a solution using unit-based reasoning to ensure consistency across operations.",
            context=analysis
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble the candidate solutions to select the most robust answer
        final_answer = await self.ensemble(
            instruction="Choose the best solution based on consistency, clarity, and alignment with the original problem constraints.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Revise the final answer for accuracy and logical soundness
        revised_final = await self.revise(
            instruction="Critically review the selected solution for any errors in calculation, unit handling, or missing steps.",
            context_to_revise=final_answer
        )

        return revised_final