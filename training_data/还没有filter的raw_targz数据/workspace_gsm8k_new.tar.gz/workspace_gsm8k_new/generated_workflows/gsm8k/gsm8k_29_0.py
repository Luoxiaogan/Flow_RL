# Workflow ID: gsm8k_29_0
# Benchmark: gsm8k
# Data Indices: [58, 91]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify key elements (knowns, unknowns, operations)
        analysis = await self.generate(
            instruction="Identify all known quantities, unknowns, and required mathematical operations in this word problem."
        )

        # Step 2: Extract structured facts from analysis for clarity
        extracted_facts = await self.generate(
            instruction="From the analysis, extract the key numerical values and relationships as a concise bullet list.",
            context=analysis
        )

        # Step 3: Generate multiple solution paths using parallel exploration
        task1 = self.generate(
            instruction="Create a step-by-step solution assuming the problem involves sequential operations.",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Create a step-by-step solution focusing on proportional reasoning or unit conversion if applicable.",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Create a step-by-step solution based on identifying hidden steps or constraints not explicitly stated.",
            context=extracted_facts
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble the three candidate solutions to select the most robust answer
        final_answer = await self.ensemble(
            instruction="Choose the most accurate and logically consistent solution among these candidates.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Revise the final answer for correctness and clarity
        revised_answer = await self.revise(
            instruction="Review the final solution for accuracy, completeness, and proper handling of units and arithmetic.",
            context_to_revise=final_answer
        )

        return revised_answer