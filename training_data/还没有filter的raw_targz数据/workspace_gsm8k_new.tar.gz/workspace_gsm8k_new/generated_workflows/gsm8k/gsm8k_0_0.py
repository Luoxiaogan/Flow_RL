# Workflow ID: gsm8k_0_0
# Benchmark: gsm8k
# Data Indices: [276, 217]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify key elements (knowns, unknowns, operations)
        analysis = await self.generate(
            instruction="Identify all known quantities, unknowns, and mathematical relationships in the problem. List them clearly."
        )

        # Step 2: Extract structured facts from the analysis for reliable reasoning
        extracted_facts = await self.generate(
            instruction="From the analysis, extract only the numerical values and their associated units or roles (e.g., 'John has 5 apples' → {'John': 5, 'unit': 'apples'}).",
            context=analysis
        )

        # Step 3: Generate multiple solution paths in parallel — one for each major operation type (addition, multiplication, etc.)
        task1 = self.generate(
            instruction="Solve using step-by-step arithmetic based on the extracted facts. Show every calculation explicitly.",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Model this as a system of equations if applicable, then solve for the unknowns.",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Use proportional reasoning or unit conversion techniques to solve, if relevant.",
            context=extracted_facts
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble the three candidate solutions to find consensus or resolve discrepancies
        final_answer = await self.ensemble(
            instruction="Evaluate the three proposed solutions. Choose the most consistent and logically sound answer. If there's disagreement, explain why one is preferred.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Revise final answer with verification logic
        revised_answer = await self.revise(
            instruction="Verify that the final answer makes sense in context: check units, reasonableness, and whether it satisfies all conditions in the original problem.",
            context_to_revise=final_answer
        )

        return revised_answer