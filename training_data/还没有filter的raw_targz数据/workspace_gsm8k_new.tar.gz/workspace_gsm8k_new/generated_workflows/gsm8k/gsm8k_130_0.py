# Workflow ID: gsm8k_130_0
# Benchmark: gsm8k
# Data Indices: [79, 194]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify key elements and structure
        analysis = await self.generate(
            instruction="Identify all known quantities, unknowns, relationships, and required operations in this math word problem."
        )

        # Step 2: Extract structured facts from analysis (if needed)
        extracted_facts = await self.generate(
            instruction="From the analysis, extract a clean list of numerical values and their associated variables or descriptions.",
            context=analysis
        )

        # Step 3: Generate multiple solution paths using parallel exploration
        task1 = self.generate(
            instruction="Generate a step-by-step plan based on sequential operations and direct calculations.",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Generate an alternative approach focusing on proportional reasoning or algebraic modeling.",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Generate a third approach that explicitly tracks units and checks for consistency across steps.",
            context=extracted_facts
        )

        # Run all approaches in parallel
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble to select the most consistent and logically sound solution
        final_solution = await self.ensemble(
            instruction="Compare the three candidate solutions and choose the one that best aligns with the original problem constraints and mathematical logic.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional refinement loop for high confidence
        if "uncertain" not in final_solution.lower():
            refined_solution = await self.revise(
                instruction="Review the final solution for potential errors in arithmetic, unit handling, or logical flow. Improve clarity and correctness if needed.",
                context_to_revise=final_solution
            )
            return refined_solution

        # If uncertain, try again with more detailed breakdown
        detailed_analysis = await self.generate(
            instruction="Break down the problem into smaller sub-problems, solving each one independently before combining the results.",
            context=analysis
        )
        refined_solution = await self.generate(
            instruction="Now solve the problem using the detailed sub-problem breakdown.",
            context=detailed_analysis
        )
        return refined_solution