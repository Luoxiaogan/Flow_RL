# Workflow ID: gsm8k_111_0
# Benchmark: gsm8k
# Data Indices: [78, 95]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Extract key facts and entities from the problem
        analysis = await self.generate(
            instruction="Extract all numerical values, units, and relationships in the problem. List them clearly."
        )

        # Step 2: Generate a structured plan based on the extracted facts
        plan = await self.generate(
            instruction="Based on the extracted facts, generate a step-by-step solution plan. Include intermediate calculations needed.",
            context=analysis
        )

        # Step 3: Execute the plan by generating each step (parallel if possible)
        steps = await self.generate(
            instruction="Now, execute each step of the plan one by one. Show all intermediate results with units clearly labeled.",
            context=plan
        )

        # Step 4: Summarize the full solution for clarity
        summary = await self.summarize(steps)

        # Step 5: Revise to check for logical consistency, unit errors, or arithmetic mistakes
        revised_solution = await self.revise(
            instruction="Review the solution carefully. Check that all steps follow logically, units are consistent, and no negative quantities appear when invalid.",
            context_to_revise=summary
        )

        # Step 6: If the problem involves multiple interpretations or ambiguous phrasing, explore alternatives
        if "ambiguous" in revised_solution.lower() or "multiple ways" in revised_solution.lower():
            # Parallel exploration of different interpretations
            task1 = self.generate("Alternative interpretation: assume X", context=revised_solution)
            task2 = self.generate("Alternative interpretation: assume Y", context=revised_solution)
            alternatives = await asyncio.gather(task1, task2)
            final_answer = await self.ensemble(
                instruction="Choose the most plausible solution based on real-world constraints and clear reasoning.",
                contexts_to_ensemble=alternatives + [revised_solution]
            )
        else:
            final_answer = revised_solution

        return final_answer