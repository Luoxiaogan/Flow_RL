# Workflow ID: gsm8k_36_0
# Benchmark: gsm8k
# Data Indices: [2, 125]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis – Understand the problem structure and identify key elements
        analysis = await self.generate(
            instruction="Identify all known quantities, unknowns, relationships, and operations required to solve this problem."
        )

        # Step 2: Extract Structured Facts – Convert natural language into clean mathematical facts
        extracted_facts = await self.generate(
            instruction="Extract all numerical values, variables, and equations from the analysis. Format as bullet points.",
            context=analysis
        )

        # Step 3: Generate Multiple Solution Paths – Use parallel exploration for robustness
        task1 = self.generate(
            instruction="Generate a step-by-step solution path assuming we solve using direct substitution.",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Generate an alternative solution path by setting up algebraic equations first.",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Generate a solution path focusing on proportional reasoning or unit-based calculations if applicable.",
            context=extracted_facts
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer – Choose best-supported answer based on consistency across paths
        final_answer = await self.ensemble(
            instruction="Select the most consistent and mathematically sound numerical answer from the three generated solutions.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Verify Contextual Plausibility – Ensure the answer makes sense in real-world terms
        verification = await self.revise(
            instruction="Check that the final answer satisfies all constraints in the original problem (e.g., no negative items, correct units). If not, revise it accordingly.",
            context_to_revise=final_answer
        )

        return verification