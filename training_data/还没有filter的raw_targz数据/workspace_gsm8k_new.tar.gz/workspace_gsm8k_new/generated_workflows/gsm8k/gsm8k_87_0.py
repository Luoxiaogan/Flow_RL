# Workflow ID: gsm8k_87_0
# Benchmark: gsm8k
# Data Indices: [192, 132]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis - Understand the problem type and extract key elements
        analysis = await self.generate(
            instruction="Identify the main question, known quantities, units, and required operations in this math word problem."
        )

        # Step 2: Extract structured facts (e.g., numbers, units, relationships)
        extracted_facts = await self.generate(
            instruction="From the analysis, extract all numerical values with their units and what they represent.",
            context=analysis
        )

        # Step 3: Generate multiple solution paths using parallel exploration
        task1 = self.generate(
            instruction="Generate a step-by-step plan to solve the problem based on the extracted facts.",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Propose an alternative approach to solving the same problem by reinterpreting the relationships between quantities.",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Create a simplified version of the problem that captures its core mathematical structure.",
            context=extracted_facts
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble the candidate solutions to find the most consistent answer
        final_solution = await self.ensemble(
            instruction="Evaluate the three proposed solutions and select the one that best matches the original problem constraints and yields a numerically valid result.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Revise for correctness and clarity
        refined_solution = await self.revise(
            instruction="Check if the solution makes sense in context—verify unit consistency, arithmetic accuracy, and logical flow. If needed, revise it for clarity and correctness.",
            context_to_revise=final_solution
        )

        return refined_solution