# Workflow ID: gsm8k_119_0
# Benchmark: gsm8k
# Data Indices: [153, 110]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify problem type and key elements
        analysis = await self.generate(
            instruction="Identify the type of math problem (e.g., rate, proportion, distribution), extract all numerical values, units, and relationships between them."
        )

        # Step 2: Extract structured facts for clearer reasoning
        extracted_facts = await self.generate(
            instruction="From the analysis, extract key values, operations needed, and constraints in a clear list format (e.g., 'value: 600 pages', 'operation: divide by 4', 'unit: sheets').",
            context=analysis
        )

        # Step 3: Generate multiple solution approaches in parallel (Diverge)
        task1 = self.generate(
            instruction="Generate a step-by-step arithmetic solution based on the extracted facts.",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Generate an algebraic approach (define variables, write equations, solve).",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Generate a unit-based dimensional analysis approach (track units through each operation).",
            context=extracted_facts
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble to select the best solution
        final_solution = await self.ensemble(
            instruction="Evaluate the three candidate solutions. Choose the one that is most consistent with the problem constraints, uses correct units, and shows logical progression.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Revise for precision and sanity check
        revised_solution = await self.revise(
            instruction="Check the final solution for correctness: verify all steps, ensure no negative quantities or invalid units, and confirm it answers the original question exactly.",
            context_to_revise=final_solution
        )

        return revised_solution