# Workflow ID: gsm8k_91_0
# Benchmark: gsm8k
# Data Indices: [112, 93]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand the problem type and key elements
        analysis = await self.generate(
            instruction="Identify the problem type (e.g., proportional reasoning, sequential operations), known values, unknowns, and units involved."
        )

        # Step 2: Extract Key Facts — Convert dense text into structured data
        extracted_facts = await self.generate(
            instruction="Extract all numerical values, relationships, and constraints from the problem in a structured format like: 'value: [number], unit: [unit], description: [what it represents].'",
            context=analysis
        )

        # Step 3: Generate Multiple Solution Paths — Parallel exploration of different interpretations
        task1 = self.generate(
            instruction="Generate a step-by-step solution assuming a linear sequence of operations.",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Generate an alternative solution path that considers hidden steps or unit conversions first.",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Generate a solution using algebraic modeling — define variables and equations based on the problem.",
            context=extracted_facts
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble — Select the most consistent and logically sound solution
        final_solution = await self.ensemble(
            instruction="Compare the three candidate solutions. Choose the one that best matches the original problem's constraints, avoids contradictions, and includes all necessary steps.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Revise for Accuracy — Self-check with error detection
        revised_solution = await self.revise(
            instruction="Review the final solution for logical consistency, unit correctness, and whether it answers the exact question asked. Fix any errors or missing steps.",
            context_to_revise=final_solution
        )

        return revised_solution