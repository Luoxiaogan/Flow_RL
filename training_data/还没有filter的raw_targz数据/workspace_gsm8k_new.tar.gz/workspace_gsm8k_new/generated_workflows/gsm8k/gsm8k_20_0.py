# Workflow ID: gsm8k_20_0
# Benchmark: gsm8k
# Data Indices: [102, 75]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify key elements and structure
        analysis = await self.generate(
            instruction="Identify all numerical values, units, relationships, and what must be calculated in this problem."
        )

        # Step 2: Extract structured facts from the analysis for clarity
        extracted_facts = await self.generate(
            instruction="From the analysis, extract a clear list of known quantities, units, and unknowns.",
            context=analysis
        )

        # Step 3: Generate multiple solution paths (parallel exploration)
        task1 = self.generate(
            instruction="Generate a step-by-step solution assuming the problem involves sequential operations.",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Generate a solution focusing on proportional reasoning or unit conversion if applicable.",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Generate an alternative approach using algebraic modeling (e.g., setting up equations).",
            context=extracted_facts
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble to select the most consistent and accurate solution
        final_answer = await self.ensemble(
            instruction="Compare the three candidate solutions and select the one that best fits the original problem constraints and arithmetic logic.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional refinement — revise based on logical consistency check
        revised_answer = await self.revise(
            instruction="Review the selected answer for correctness, unit consistency, and plausibility in context. If incorrect, correct it.",
            context_to_revise=final_answer
        )

        return revised_answer