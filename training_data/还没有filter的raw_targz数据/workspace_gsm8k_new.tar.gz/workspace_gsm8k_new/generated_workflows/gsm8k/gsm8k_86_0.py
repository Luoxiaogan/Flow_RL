# Workflow ID: gsm8k_86_0
# Benchmark: gsm8k
# Data Indices: [206, 52]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Extract key numerical values and relationships from the problem
        extraction = await self.generate(
            instruction="Extract all numerical values and their associated actions (e.g., gain, lose, share) from the problem. List them clearly as 'Action: Value' pairs."
        )

        # Step 2: Generate an initial step-by-step solution based on the extracted facts
        analysis = await self.generate(
            instruction="Based on the extracted facts, analyze the sequence of operations needed to solve this problem. Identify the order in which arithmetic steps must be performed.",
            context=extraction
        )

        # Step 3: Generate a detailed calculation plan with intermediate results
        plan = await self.generate(
            instruction="Create a clear, step-by-step plan showing each operation and its result. Track units (dollars, eyes, etc.) throughout.",
            context=analysis
        )

        # Step 4: Use iterative refinement to improve accuracy by checking for common errors
        refined_plan = await self.revise(
            instruction="Review the plan for logical consistency, unit tracking, and correctness of arithmetic. Correct any mistakes or ambiguities.",
            context_to_revise=plan
        )

        # Step 5: Summarize the final reasoning path for clarity and verification
        summary = await self.summarize(context_to_summarize=refined_plan)

        # Step 6: Generate one final answer based on the summarized plan
        final_answer = await self.generate(
            instruction="From the summarized reasoning, compute the final numerical answer. Return only the number, no explanation.",
            context=summary
        )

        return final_answer