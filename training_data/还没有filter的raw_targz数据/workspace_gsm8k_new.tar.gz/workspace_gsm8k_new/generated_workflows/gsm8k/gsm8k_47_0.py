# Workflow ID: gsm8k_47_0
# Benchmark: gsm8k
# Data Indices: [40, 258]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis – Understand the problem structure and identify key elements
        analysis = await self.generate(
            instruction="Identify all known quantities, unknowns, operations, and relationships in the problem. Focus on mathematical modeling and units."
        )

        # Step 2: Extract Key Facts – Convert dense text into structured facts for reasoning
        extracted_facts = await self.generate(
            instruction="Extract numerical values, operations, and constraints from the analysis. Format as bullet points with clear labels (e.g., 'Known: ...', 'Unknown: ...').",
            context=analysis
        )

        # Step 3: Generate Multiple Solution Paths – Use parallel exploration for robustness
        task1 = self.generate(
            instruction="Generate a step-by-step solution using sequential arithmetic operations based on the extracted facts.",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Generate an alternative solution path by identifying hidden steps or unit conversions not immediately obvious.",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Generate a solution that explicitly tracks units throughout each calculation to ensure consistency.",
            context=extracted_facts
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer – Synthesize competing solutions to find the most consistent one
        final_answer = await self.ensemble(
            instruction="Choose the most consistent and logically sound solution among the three candidates. If there's disagreement, resolve it using the original problem constraints.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Verify & Revise – Ensure correctness through bidirectional verification
        verification_check = await self.generate(
            instruction="Verify the final answer by reconstructing the problem backward: starting from the answer, check if it leads back to the given conditions.",
            context=final_answer
        )

        # Optional refinement if verification reveals issues
        if "inconsistent" in verification_check.lower() or "not match" in verification_check.lower():
            revised_answer = await self.revise(
                instruction="Revise the final answer based on the verification feedback. Ensure it aligns with all original constraints and units.",
                context_to_revise=final_answer
            )
            return revised_answer

        return final_answer