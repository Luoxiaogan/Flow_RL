# Workflow ID: gsm8k_58_0
# Benchmark: gsm8k
# Data Indices: [240, 154]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify key elements (knowns, unknowns, operations)
        analysis = await self.generate(
            instruction="Identify all known quantities, variables, and required mathematical operations in this problem. Focus on extracting numerical values, units, and relationships between entities."
        )

        # Step 2: Extract structured data from analysis for clearer reasoning
        extracted_data = await self.generate(
            instruction="From the analysis, extract all relevant numerical values, their units, and what they represent (e.g., cost per item, quantity needed). Format as a list of key-value pairs with clear descriptions.",
            context=analysis
        )

        # Step 3: Generate multiple solution paths — one for each possible interpretation or approach
        path1 = self.generate(
            instruction="Generate a step-by-step solution assuming we compute total cost for each option separately, then compare them to find the minimum.",
            context=extracted_data
        )
        path2 = self.generate(
            instruction="Generate an alternative solution path focusing on unit conversion first (e.g., ounces to pounds), then calculating total costs using consistent units.",
            context=extracted_data
        )
        path3 = self.generate(
            instruction="Generate a third solution path that explicitly tracks units at every step to ensure consistency and avoid errors like mixing pounds and ounces.",
            context=extracted_data
        )

        # Step 4: Run all three paths in parallel for efficiency and robustness
        solutions = await asyncio.gather(path1, path2, path3)

        # Step 5: Ensemble the three solutions to select the most consistent and accurate answer
        final_answer = await self.ensemble(
            instruction="Compare the three proposed solutions. Identify which one has the clearest logic, correct arithmetic, and consistent unit handling. Return only the final numerical answer.",
            contexts_to_ensemble=solutions
        )

        # Step 6: Optional refinement if there's ambiguity or low confidence
        if "multiple" in final_answer.lower() or "not unique" in final_answer.lower():
            refined = await self.revise(
                instruction="The initial ensemble returned ambiguous results. Re-evaluate all steps carefully and resolve any inconsistencies by checking unit conversions and arithmetic correctness.",
                context_to_revise=final_answer
            )
            return refined

        return final_answer