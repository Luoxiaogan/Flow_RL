# Workflow ID: gsm8k_109_0
# Benchmark: gsm8k
# Data Indices: [187, 236]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis – Understand the problem structure and identify key elements
        analysis = await self.generate(
            instruction="Analyze the problem to identify all quantities, units, relationships, and what needs to be calculated."
        )

        # Step 2: Extract Structured Data – Convert unstructured text into clear numerical facts
        extracted_data = await self.generate(
            instruction="Extract all relevant numerical values, their units, and associated entities (e.g., costs, rates, counts).",
            context=analysis
        )

        # Step 3: Generate Multiple Solution Paths – Explore different reasoning strategies (parallel exploration)
        task1 = self.generate(
            instruction="Generate a step-by-step solution assuming each cost component is computed individually and summed.",
            context=extracted_data
        )
        task2 = self.generate(
            instruction="Generate a solution by first computing total cost per category (meat, fruit, bread, janitorial) then summing.",
            context=extracted_data
        )
        task3 = self.generate(
            instruction="Generate a solution using proportional reasoning or unit pricing techniques if applicable.",
            context=extracted_data
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer – Synthesize multiple approaches to improve robustness
        final_answer = await self.ensemble(
            instruction="Choose the most consistent and logically sound answer from the three generated solutions.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Revise for Accuracy – Verify that the answer matches the problem's constraints
        revised_answer = await self.revise(
            instruction="Check if the final answer makes sense in context — does it respect units, avoid negatives, match expected scale?",
            context_to_revise=final_answer
        )

        return revised_answer