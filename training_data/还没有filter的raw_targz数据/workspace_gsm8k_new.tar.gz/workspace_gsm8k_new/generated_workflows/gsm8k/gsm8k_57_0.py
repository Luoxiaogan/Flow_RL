# Workflow ID: gsm8k_57_0
# Benchmark: gsm8k
# Data Indices: [48, 291]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis – Understand the structure and key elements
        analysis = await self.generate(
            instruction="Identify all known quantities, unknowns, relationships, and units in the problem. Do not calculate yet."
        )

        # Step 2: Extract Structured Facts – Convert natural language into math-friendly format
        extracted_facts = await self.generate(
            instruction="From the analysis, extract numerical values, percentages, ratios, and relationships as structured facts (e.g., 'spruce_trees = total_trees * 0.10').",
            context=analysis
        )

        # Step 3: Generate Multiple Solution Paths – Explore different reasoning approaches
        path1 = self.generate(
            instruction="Generate a step-by-step solution using direct arithmetic based on the extracted facts.",
            context=extracted_facts
        )
        path2 = self.generate(
            instruction="Generate an alternative approach by setting up equations for each variable and solving them systematically.",
            context=extracted_facts
        )
        path3 = self.generate(
            instruction="Generate a solution focusing on unit tracking and proportional reasoning to verify consistency across steps.",
            context=extracted_facts
        )

        # Step 4: Parallel Ensemble – Synthesize diverse solutions into one robust answer
        ensemble_result = await self.ensemble(
            instruction="Compare the three solutions and select the most consistent and accurate final answer based on mathematical correctness and internal coherence.",
            contexts_to_ensemble=[path1, path2, path3]
        )

        # Step 5: Iterative Refinement – Check for logical errors or missing constraints
        final_solution = await self.revise(
            instruction="Review the ensemble result for potential mistakes, such as incorrect order of operations, unit mismatches, or invalid assumptions. Correct if needed.",
            context_to_revise=ensemble_result
        )

        # Step 6: Final Verification – Ensure answer makes sense in real-world context
        verification = await self.generate(
            instruction="Verify that the final answer is reasonable given the original scenario (e.g., no negative counts, whole numbers where required). If it's unreasonable, suggest a correction.",
            context=final_solution
        )

        return verification