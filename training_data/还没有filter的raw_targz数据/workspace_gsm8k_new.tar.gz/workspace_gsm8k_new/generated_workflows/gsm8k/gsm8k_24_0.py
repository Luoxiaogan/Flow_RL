# Workflow ID: gsm8k_24_0
# Benchmark: gsm8k
# Data Indices: [147, 35]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify key elements (entities, quantities, operations)
        analysis = await self.generate(
            instruction="Identify all numerical values, entities, and mathematical relationships in the problem. Extract structured facts like names, amounts, rates, and units."
        )

        # Step 2: Generate multiple solution paths — one based on direct math, another on step-by-step breakdown
        task1 = self.generate(
            instruction="Generate a direct calculation approach using the extracted facts.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Break down the problem into sequential steps with explicit intermediate results.",
            context=analysis
        )
        solutions = await asyncio.gather(task1, task2)

        # Step 3: Ensemble to select the most robust solution
        final_solution = await self.ensemble(
            instruction="Choose the best solution by comparing both approaches. Consider clarity, correctness, and completeness.",
            contexts_to_ensemble=solutions
        )

        # Step 4: Optional refinement if needed — test against common errors (e.g., unit mismatches, missing steps)
        revised_solution = await self.revise(
            instruction="Check for logical consistency, unit tracking, and hidden steps. Correct any flaws found.",
            context_to_revise=final_solution
        )

        # Step 5: Final verification via bidirectional check — generate inverse problem to validate result
        inverse_check = await self.generate(
            instruction="Create an inverse version of this problem that should yield the same answer when solved correctly. Use the proposed solution as input.",
            context=revised_solution
        )

        # Step 6: Final ensemble between original and inverse-checking solution
        final_answer = await self.ensemble(
            instruction="Select the most consistent answer from the main solution and the inverse-problem verification.",
            contexts_to_ensemble=[revised_solution, inverse_check]
        )

        return final_answer