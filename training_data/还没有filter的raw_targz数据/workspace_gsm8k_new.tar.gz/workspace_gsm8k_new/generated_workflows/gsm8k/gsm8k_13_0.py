# Workflow ID: gsm8k_13_0
# Benchmark: gsm8k
# Data Indices: [116, 51]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis – Understand the problem structure and identify knowns/unknowns
        analysis = await self.generate(
            instruction="Analyze the problem to identify all given quantities, relationships, and what needs to be calculated. Focus on identifying units (e.g., hours, books, dollars) and mathematical operations required."
        )

        # Step 2: Extract Structured Data – Convert natural language into clean facts
        extracted_data = await self.generate(
            instruction="From the analysis, extract key numerical values and their meanings in structured format (e.g., 'time_per_day: 8 hours', 'percentage_games: 75%', 'reading_speed: 60 pages/hour').",
            context=analysis
        )

        # Step 3: Generate Multiple Solution Paths – Use parallel exploration for robustness
        task1 = self.generate(
            instruction="First approach: Calculate total reading time first, then determine how many books that allows based on page count per book.",
            context=extracted_data
        )
        task2 = self.generate(
            instruction="Second approach: Compute total free time over weekend, apply percentage split, then compute number of books read using reading speed and book size.",
            context=extracted_data
        )
        task3 = self.generate(
            instruction="Third approach: Treat this as a unit conversion problem—convert time to pages, then pages to books.",
            context=extracted_data
        )

        # Execute all paths in parallel
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer – Choose best solution from multiple approaches
        final_answer = await self.ensemble(
            instruction="Compare the three generated solutions. Select the one that is most consistent with the problem constraints and logical flow. If there's disagreement, choose the one that better aligns with real-world expectations (e.g., no negative or fractional books).",
            contexts_to_ensemble=solutions
        )

        # Optional: Revise if needed — add a refinement step if output seems ambiguous
        if "ambiguous" in final_answer.lower() or "?" in final_answer:
            final_answer = await self.revise(
                instruction="Revise the answer to ensure it's a clear, single numerical value that makes sense in context. Double-check calculations and units.",
                context_to_revise=final_answer
            )

        return final_answer