# Workflow ID: gsm8k_135_0
# Benchmark: gsm8k
# Data Indices: [155, 118]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify key elements (quantities, operations, units)
        analysis = await self.generate(
            instruction="Identify all numerical values, entities, and operations mentioned in the problem. Extract quantities, rates, and relationships between them."
        )

        # Step 2: Use extract-and-reason pattern — generate structured breakdown
        structured_plan = await self.generate(
            instruction="Based on the analysis, create a step-by-step plan with clear mathematical operations needed to compute the final answer. Track units at each step.",
            context=analysis
        )

        # Step 3: Parallel exploration — generate multiple solution paths if ambiguous
        task1 = self.generate(
            instruction="Solve using sequential calculation based on the order described in the problem.",
            context=structured_plan
        )
        task2 = self.generate(
            instruction="Solve by grouping similar actions (e.g., group customers who bought same number of items).",
            context=structured_plan
        )
        task3 = self.generate(
            instruction="Solve by first calculating total number of people, then applying average purchase rate.",
            context=structured_plan
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble to select best solution among alternatives
        final_answer = await self.ensemble(
            instruction="Compare the three proposed solutions. Choose the one that correctly applies arithmetic principles, respects units, and matches the real-world constraints of the problem.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Final verification loop — revise if necessary
        revised_answer = await self.revise(
            instruction="Verify the final answer makes sense in context. Check for unit consistency, logical flow, and whether it aligns with the original question's intent.",
            context_to_revise=final_answer
        )

        return revised_answer