# Workflow ID: gsm8k_125_0
# Benchmark: gsm8k
# Data Indices: [41, 161]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify key entities, quantities, and operations
        analysis = await self.generate(
            instruction="Identify all numerical values, relationships, and required operations in this word problem."
        )

        # Step 2: Extract structured facts (e.g., percentages, totals, ratios) for clarity
        extracted_facts = await self.generate(
            instruction="From the analysis, extract clear mathematical facts such as 'total students = X', 'percentage of Y = Z%', etc.",
            context=analysis
        )

        # Step 3: Generate multiple solution paths (parallel exploration)
        task1 = self.generate(
            instruction="Solve using direct calculation: first compute the base quantity, then apply percentage or ratio.",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Solve by setting up an equation: define unknowns and solve algebraically.",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Break into steps: compute intermediate values like number of juniors before computing sports involvement.",
            context=extracted_facts
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble the best solution based on consistency and clarity
        final_answer = await self.ensemble(
            instruction="Choose the most accurate and clearly reasoned solution from the three candidates.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional refinement if needed — check for logical errors or unit mismatches
        refined_answer = await self.revise(
            instruction="Review the final answer for correctness, proper units, and whether it makes sense in the real-world context described.",
            context_to_revise=final_answer
        )

        return refined_answer