# Workflow ID: gsm8k_7_0
# Benchmark: gsm8k
# Data Indices: [67, 17]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Analyze the problem to identify key entities, values, and relationships
        analysis = await self.generate(
            instruction="Identify all known quantities, unknowns, and mathematical relationships in the problem. Extract structured facts like 'Mike has 6 toys' or 'Annie has three times more than Mike'."
        )

        # Step 2: Generate an initial solution using extracted facts
        initial_solution = await self.generate(
            instruction="Based on the extracted facts, generate a step-by-step plan to solve the problem. Include arithmetic operations and unit tracking.",
            context=analysis
        )

        # Step 3: Use iterative refinement to improve accuracy
        refined_solution = initial_solution
        for i in range(2):  # Run 2 refinement cycles
            critique = await self.generate(
                instruction="Critique the current solution: check for missing steps, incorrect operations, or inconsistent units. Suggest improvements.",
                context=refined_solution
            )
            refined_solution = await self.revise(
                instruction=f"Revise the solution based on this critique: {critique}",
                context_to_revise=refined_solution
            )

        # Step 4: Summarize the final reasoning chain to ensure clarity
        summary = await self.summarize(context_to_summarize=refined_solution)

        # Step 5: Ensemble with a parallel alternative approach (e.g., direct equation solving)
        parallel_approach = await self.generate(
            instruction="Generate an alternative solution path by formulating equations directly from the problem statement (e.g., A = 3*M, A = T - 2). Solve them step by step."
        )

        # Final ensemble to resolve any discrepancies between approaches
        final_answer = await self.ensemble(
            instruction="Choose the most accurate and consistent answer between the two solution paths. If they differ, explain why one is better.",
            contexts_to_ensemble=[summary, parallel_approach]
        )

        return final_answer