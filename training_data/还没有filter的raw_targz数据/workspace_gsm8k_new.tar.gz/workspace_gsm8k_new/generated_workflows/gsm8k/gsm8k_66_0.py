# Workflow ID: gsm8k_66_0
# Benchmark: gsm8k
# Data Indices: [101, 181]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Analyze the problem to identify key elements (values, operations, unknowns)
        analysis = await self.generate(
            instruction="Extract all numerical values, relationships, and the unknown quantity from the problem. List them clearly."
        )

        # Step 2: Generate a step-by-step solution plan based on the analysis
        plan = await self.generate(
            instruction="Based on the extracted values and relationships, outline a clear sequence of mathematical steps needed to solve the problem.",
            context=analysis
        )

        # Step 3: Execute the plan in parallel branches to explore different interpretations or calculation paths
        task1 = self.generate(
            instruction="Perform the first step of the plan: calculate [first operation].",
            context=plan
        )
        task2 = self.generate(
            instruction="Perform the second step of the plan: calculate [second operation].",
            context=plan
        )
        task3 = self.generate(
            instruction="Perform the third step of the plan: calculate [third operation].",
            context=plan
        )

        results = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble the intermediate results into a coherent final solution
        final_solution = await self.ensemble(
            instruction="Combine the three calculated steps into a single correct numerical answer.",
            contexts_to_ensemble=results
        )

        # Step 5: Revise the final solution using multiple angles to ensure correctness
        revised_solution = await self.revise(
            instruction="Review the final solution for unit consistency, logical flow, and arithmetic accuracy. If any error is found, fix it.",
            context_to_revise=final_solution
        )

        return revised_solution