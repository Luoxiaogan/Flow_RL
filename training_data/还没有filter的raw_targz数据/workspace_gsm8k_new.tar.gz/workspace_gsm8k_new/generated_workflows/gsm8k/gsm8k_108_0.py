# Workflow ID: gsm8k_108_0
# Benchmark: gsm8k
# Data Indices: [27, 199]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis – Understand the problem structure and identify knowns/unknowns
        analysis = await self.generate(
            instruction="Analyze the problem to identify all given quantities, relationships, and what needs to be calculated. List key variables and operations required."
        )

        # Step 2: Extract Structured Facts – Convert natural language into clean data points
        extracted_facts = await self.generate(
            instruction="Extract all numerical values and their associated units or roles (e.g., '50%' means 0.5 * total matches). Ignore irrelevant text.",
            context=analysis
        )

        # Step 3: Generate Multiple Solution Paths – Explore different valid approaches if ambiguous
        path1 = self.generate(
            instruction="Generate a step-by-step solution using direct arithmetic based on extracted facts.",
            context=extracted_facts
        )
        path2 = self.generate(
            instruction="Generate an alternative solution path by modeling this as a proportional reasoning problem (e.g., total wins = sum of partial wins).",
            context=extracted_facts
        )

        # Step 4: Parallel Ensemble – Synthesize both paths into one robust solution
        ensemble_solution = await self.ensemble(
            instruction="Compare the two solutions. If they agree, select that answer. If not, explain discrepancies and choose the most consistent one with the original problem constraints.",
            contexts_to_ensemble=[path1, path2]
        )

        # Step 5: Revise for Accuracy – Check for unit consistency, logical flow, and mathematical correctness
        final_solution = await self.revise(
            instruction="Review the solution for errors in calculation, missing steps, or inconsistent units. Ensure it makes sense in real-world context (e.g., no negative items).",
            context_to_revise=ensemble_solution
        )

        return final_solution