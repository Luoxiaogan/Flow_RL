# Workflow ID: gsm8k_144_0
# Benchmark: gsm8k
# Data Indices: [109, 104]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand the structure and identify knowns/unknowns
        analysis = await self.generate(
            instruction="Analyze the problem to identify all numerical values, relationships, and the unknown quantity (what needs to be found)."
        )

        # Step 2: Extract Key Facts — Clean up structured data from the analysis
        extracted_facts = await self.generate(
            instruction="From the analysis, extract only the key numerical facts and their relationships in a concise list format.",
            context=analysis
        )

        # Step 3: Generate Multiple Solution Approaches — Parallel exploration of different reasoning paths
        task1 = self.generate(
            instruction="Generate a step-by-step solution using direct algebraic modeling based on the extracted facts.",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Generate an alternative solution by setting up an equation from the given relationships.",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Generate a solution that explicitly tracks units and ensures dimensional consistency at each step.",
            context=extracted_facts
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer — Synthesize multiple perspectives for robustness
        final_answer = await self.ensemble(
            instruction="Compare the three generated solutions and select the one that best aligns with mathematical principles and contextual constraints.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Revise for Accuracy — Self-checking loop to catch hidden errors or unit mismatches
        revised_answer = await self.revise(
            instruction="Review the final answer carefully for logical consistency, unit correctness, and whether it satisfies all conditions in the original problem.",
            context_to_revise=final_answer
        )

        return revised_answer