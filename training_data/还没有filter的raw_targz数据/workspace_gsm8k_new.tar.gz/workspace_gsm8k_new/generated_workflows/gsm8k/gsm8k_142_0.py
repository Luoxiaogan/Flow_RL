# Workflow ID: gsm8k_142_0
# Benchmark: gsm8k
# Data Indices: [292, 18]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify key entities, quantities, and operations
        analysis = await self.generate(
            instruction="Identify all numerical values, units, and relationships in the problem. Extract key facts as structured bullet points."
        )

        # Step 2: Generate multiple solution paths (parallel exploration)
        task1 = self.generate(
            instruction="Generate a step-by-step solution assuming all values are additive.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Generate a step-by-step solution focusing on unit conversions or proportional reasoning if applicable.",
            context=analysis
        )
        task3 = self.generate(
            instruction="Generate a solution by identifying hidden steps or intermediate calculations not explicitly stated.",
            context=analysis
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble to select best solution based on coherence and logical consistency
        final_solution = await self.ensemble(
            instruction="Compare the three candidate solutions and choose the one that best resolves all given information without contradictions.",
            contexts_to_ensemble=solutions
        )

        # Step 4: Revise to catch potential errors (e.g., negative counts, incorrect order of operations)
        refined_solution = await self.revise(
            instruction="Review the final solution for logical consistency, correct arithmetic, and real-world feasibility (e.g., no negative items).",
            context_to_revise=final_solution
        )

        return refined_solution