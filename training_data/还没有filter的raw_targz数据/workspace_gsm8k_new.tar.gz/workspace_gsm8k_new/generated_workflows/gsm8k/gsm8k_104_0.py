# Workflow ID: gsm8k_104_0
# Benchmark: gsm8k
# Data Indices: [141, 164]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify key elements (values, operations, units)
        analysis = await self.generate(
            instruction="Identify all numerical values, relationships, and required operations in the problem. Extract key entities like people, items, and their quantities."
        )

        # Step 2: Generate multiple solution paths using parallel exploration
        task1 = self.generate(
            instruction="Create a step-by-step plan based on sequential operations.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Generate an alternative approach focusing on proportional reasoning or unit conversion if applicable.",
            context=analysis
        )
        task3 = self.generate(
            instruction="Propose a third method that explicitly tracks units throughout the calculation.",
            context=analysis
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble to select the most consistent and logical solution
        final_solution = await self.ensemble(
            instruction="Evaluate the three candidate solutions and choose the one that best aligns with the problem's structure and constraints.",
            contexts_to_ensemble=solutions
        )

        # Step 4: Optional refinement loop for high-stakes accuracy
        if "likely" in final_solution.lower() or "maybe" in final_solution.lower():
            refined_solution = await self.revise(
                instruction="Revise the solution to eliminate ambiguity and ensure it directly answers the question with clear arithmetic steps.",
                context_to_revise=final_solution
            )
            return refined_solution

        return final_solution