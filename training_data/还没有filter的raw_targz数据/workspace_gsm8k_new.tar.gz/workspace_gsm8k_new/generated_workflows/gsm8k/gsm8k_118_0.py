# Workflow ID: gsm8k_118_0
# Benchmark: gsm8k
# Data Indices: [252, 30]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand structure and identify key elements
        analysis = await self.generate(
            instruction="Identify all numerical values, relationships, entities, and operations mentioned in the problem. List them clearly."
        )

        # Step 2: Extract Structured Facts — Turn narrative into structured data
        extracted_facts = await self.generate(
            instruction="From the analysis, extract a list of key facts as (entity, value, unit) tuples.",
            context=analysis
        )

        # Step 3: Generate Multiple Solution Paths — Explore different reasoning strategies
        task1 = self.generate("Generate a step-by-step solution assuming the problem involves sequential operations.")
        task2 = self.generate("Generate a solution using proportional reasoning or ratios if applicable.")
        task3 = self.generate("Generate a solution treating this as a comparison problem (e.g., how many more).")

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer — Select best-supported solution based on consistency
        final_answer = await self.ensemble(
            instruction="Select the most consistent and logically sound solution among the three candidates. If there's disagreement, explain why one is preferred.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Revise for Accuracy — Validate against common pitfalls like unit errors or negative results
        revised_answer = await self.revise(
            instruction="Check the final answer for logical consistency: Does it respect units? Is it realistic? Are intermediate steps valid?",
            context_to_revise=final_answer
        )

        return revised_answer