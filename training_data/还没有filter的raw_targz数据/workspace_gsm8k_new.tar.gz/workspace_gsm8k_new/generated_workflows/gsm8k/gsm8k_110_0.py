# Workflow ID: gsm8k_110_0
# Benchmark: gsm8k
# Data Indices: [33, 6]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand the problem type and extract key elements
        analysis = await self.generate(
            instruction="Identify the problem type (e.g., rate, proportional, distribution), known values, unknowns, and units involved."
        )

        # Step 2: Extract structured facts from the analysis
        facts = await self.generate(
            instruction="From the analysis, extract all numerical values, their associated quantities, and relationships in a structured format like 'key: value' pairs.",
            context=analysis
        )

        # Step 3: Generate multiple solution paths based on different interpretations or strategies
        task1 = self.generate(
            instruction="Generate a step-by-step solution assuming this is a sequential operation problem.",
            context=facts
        )
        task2 = self.generate(
            instruction="Generate a step-by-step solution assuming this is a proportional reasoning problem.",
            context=facts
        )
        task3 = self.generate(
            instruction="Generate a step-by-step solution assuming this involves unit conversions or multi-entity tracking.",
            context=facts
        )
        
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble to select the most consistent and logical solution
        final_solution = await self.ensemble(
            instruction="Compare the three proposed solutions and select the one that best aligns with the original problem statement and mathematical consistency.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Revise if necessary — check for common errors (negative results, incorrect units, missing steps)
        revised_solution = await self.revise(
            instruction="Review the selected solution for logical consistency, proper arithmetic, correct units, and absence of negative quantities where not allowed.",
            context_to_revise=final_solution
        )

        return revised_solution