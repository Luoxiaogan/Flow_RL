# Workflow ID: gsm8k_17_0
# Benchmark: gsm8k
# Data Indices: [128, 168]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis
        analysis = await self.generate(
            instruction="Identify all known quantities, unknowns, and relationships in the problem. Focus on units and mathematical operations needed."
        )

        # Step 2: Extract Structured Facts (if applicable)
        extracted = await self.generate(
            instruction="Extract all numerical values and their associated units from the analysis. Format as: 'Value: Unit'.",
            context=analysis
        )

        # Step 3: Generate Multiple Solution Paths (Parallel Exploration)
        task1 = self.generate(
            instruction="Generate a step-by-step solution using sequential arithmetic reasoning.",
            context=extracted
        )
        task2 = self.generate(
            instruction="Generate a solution using proportional reasoning or unit conversion if relevant.",
            context=extracted
        )
        task3 = self.generate(
            instruction="Generate a solution that explicitly tracks units at each step to avoid errors.",
            context=extracted
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer
        final_answer = await self.ensemble(
            instruction="Choose the most consistent and mathematically sound answer among the three approaches. If there's disagreement, prioritize the one with explicit unit tracking.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Revise for Clarity and Correctness
        revised = await self.revise(
            instruction="Review the final answer for logical consistency, correct unit handling, and clarity. Ensure it directly answers the original question.",
            context_to_revise=final_answer
        )

        return revised