# Workflow ID: gsm8k_34_0
# Benchmark: gsm8k
# Data Indices: [231, 261]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand the problem type and key elements
        analysis = await self.generate(
            instruction="Identify the problem type (e.g., rate, proportion, sequential operations), known values, unknowns, and units involved."
        )

        # Step 2: Extract Structured Data — Turn natural language into structured facts
        extracted_facts = await self.generate(
            instruction="Extract all numerical values, relationships, and constraints from the problem in a structured format like 'key: value' pairs.",
            context=analysis
        )

        # Step 3: Generate Multiple Solution Paths — Parallel exploration of different strategies
        task1 = self.generate(
            instruction="Generate a step-by-step solution assuming this is a proportional reasoning problem.",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Generate a step-by-step solution assuming this is a sequential operation problem.",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Generate a step-by-step solution assuming this involves unit conversion or distribution.",
            context=extracted_facts
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer — Select best-supported solution
        final_answer = await self.ensemble(
            instruction="Choose the most consistent and logically sound solution based on the three generated paths.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Revise for Accuracy — Self-check using bidirectional verification
        revised_answer = await self.revise(
            instruction="Review the final answer by checking if it makes sense in context and matches the original question's requirements.",
            context_to_revise=final_answer
        )

        return revised_answer