# Workflow ID: gsm8k_25_0
# Benchmark: gsm8k
# Data Indices: [66, 138]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify key elements and structure
        analysis = await self.generate(
            instruction="Identify all numerical values, relationships, and unknowns in the problem. List them clearly."
        )

        # Step 2: Extract structured facts from analysis (e.g., quantities, operations, constraints)
        extracted_facts = await self.generate(
            instruction="From the analysis, extract only the essential numerical facts and their roles (known/unknown). Format as bullet points.",
            context=analysis
        )

        # Step 3: Generate multiple solution paths based on different interpretations or strategies
        task1 = self.generate(
            instruction="Generate a step-by-step plan assuming sequential calculation is needed.",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Generate an alternative approach using proportional reasoning or algebraic modeling.",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Generate a solution path focusing on unit consistency and real-world constraints.",
            context=extracted_facts
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble to select the most consistent and logically sound solution
        final_solution = await self.ensemble(
            instruction="Evaluate the three candidate solutions and choose the one that best aligns with the problem's constraints and logical flow.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Revise for accuracy — test against known constraints or common pitfalls
        revised_solution = await self.revise(
            instruction="Review the final solution for correctness, especially checking units, arithmetic, and whether it makes sense in context.",
            context_to_revise=final_solution
        )

        return revised_solution