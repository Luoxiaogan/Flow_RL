# Workflow ID: gsm8k_115_0
# Benchmark: gsm8k
# Data Indices: [186, 63]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Identify key entities, values, and relationships
        analysis = await self.generate(
            instruction="Identify all known quantities, unknowns, and relationships in the problem. List them clearly."
        )

        # Step 2: Extract Structured Data — Convert natural language into structured facts
        extracted = await self.generate(
            instruction="Extract numerical values and their associated entities (e.g., names, time periods) from the analysis. Format as bullet points.",
            context=analysis
        )

        # Step 3: Generate Multiple Solution Paths — Use parallel exploration for robustness
        task1 = self.generate(
            instruction="Generate a step-by-step solution using basic arithmetic operations based on the extracted facts.",
            context=extracted
        )
        task2 = self.generate(
            instruction="Generate an alternative solution path by identifying hidden steps or unit conversions that might be needed.",
            context=extracted
        )
        task3 = self.generate(
            instruction="Generate a solution using algebraic modeling: define variables and write equations based on the problem description.",
            context=extracted
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer — Synthesize the best answer from multiple approaches
        final_answer = await self.ensemble(
            instruction="Compare the three generated solutions. Select the most consistent and logically sound answer. If there's disagreement, resolve it by checking which one satisfies all constraints in the original problem.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional Refinement — If the answer seems ambiguous or inconsistent, revise once more
        if "not sure" in final_answer.lower() or "multiple answers" in final_answer.lower():
            refined = await self.revise(
                instruction="Revise the final answer to ensure it resolves any ambiguity and matches the problem's constraints exactly.",
                context_to_revise=final_answer
            )
            return refined

        return final_answer