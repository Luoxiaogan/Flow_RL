# Workflow ID: gsm8k_89_0
# Benchmark: gsm8k
# Data Indices: [246, 195]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Analyze the problem to identify key entities, values, and operations
        analysis = await self.generate(
            instruction="Identify all numerical values, relationships, and what needs to be calculated. Focus on units (e.g., dollars, gallons, people) and whether it's sequential, proportional, or comparative."
        )

        # Step 2: Extract structured facts from the analysis for clarity
        extracted_facts = await self.generate(
            instruction="Extract all relevant numerical values and their roles (e.g., total, part, rate, difference). List them clearly as 'Key: Value' pairs.",
            context=analysis
        )

        # Step 3: Generate multiple solution strategies in parallel — one for each major type of math involved
        task1 = self.generate(
            instruction="Solve using step-by-step arithmetic based on the order described in the problem.",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Solve by first identifying the unknown variable and setting up an equation based on the relationships given.",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Solve by breaking down into sub-problems: find intermediate quantities first, then combine them.",
            context=extracted_facts
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble the three candidate solutions to select the most consistent answer
        final_answer = await self.ensemble(
            instruction="Choose the most consistent and logically sound answer among the three approaches. If they differ, explain why one might be preferred.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Revise if needed — check for unit consistency, negative results, or logical flaws
        revised_answer = await self.revise(
            instruction="Check the final answer for correctness: Does it match the question? Is it in the right unit? Are there any impossible values (like negative items)? If not, revise accordingly.",
            context_to_revise=final_answer
        )

        return revised_answer