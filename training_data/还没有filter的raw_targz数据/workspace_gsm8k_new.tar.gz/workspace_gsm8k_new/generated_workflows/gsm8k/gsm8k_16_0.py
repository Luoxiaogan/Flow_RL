# Workflow ID: gsm8k_16_0
# Benchmark: gsm8k
# Data Indices: [274, 38]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify key elements (values, units, relationships)
        analysis = await self.generate(
            instruction="Extract all numerical values, units, and relationships from the problem. Focus on what is known, what needs to be found, and how quantities relate."
        )

        # Step 2: Generate multiple solution paths in parallel — one for each likely interpretation or approach
        task1 = self.generate(
            instruction="Generate a step-by-step plan assuming this is a proportional reasoning problem (e.g., scaling based on time or quantity).",
            context=analysis
        )
        task2 = self.generate(
            instruction="Generate a step-by-step plan assuming this is a sequential operation problem (e.g., doing one thing after another).",
            context=analysis
        )
        task3 = self.generate(
            instruction="Generate a step-by-step plan assuming this involves unit conversions or tracking (e.g., miles per gallon, daily vs monthly).",
            context=analysis
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble the three candidate solutions to select the most consistent and accurate one
        final_plan = await self.ensemble(
            instruction="Compare the three generated plans and choose the one that best fits the structure of the problem. Prioritize clarity, correctness, and logical flow.",
            contexts_to_ensemble=solutions
        )

        # Step 4: Solve using the chosen plan
        solution = await self.generate(
            instruction="Now solve the problem step-by-step using the selected plan. Be explicit about each calculation, including intermediate results and unit handling.",
            context=final_plan
        )

        # Step 5: Revise the solution to check for errors, inconsistencies, or missing steps
        revised_solution = await self.revise(
            instruction="Review the solution for mathematical accuracy, unit consistency, and whether it fully addresses the question. Fix any issues found.",
            context_to_revise=solution
        )

        # Step 6: Final verification via bidirectional reasoning – generate an inverse problem and test if it leads back to original
        inverse_test = await self.generate(
            instruction="Create an inverse version of the problem: given the answer, reconstruct the input conditions that would lead to it. Check if this matches the original setup.",
            context=revised_solution
        )

        # Step 7: Ensemble final output with inverse validation to ensure robustness
        final_answer = await self.ensemble(
            instruction="The main solution must be correct and logically sound. The inverse test validates it. Choose the final answer based on both the solution and its inverse consistency.",
            contexts_to_ensemble=[revised_solution, inverse_test]
        )

        return final_answer