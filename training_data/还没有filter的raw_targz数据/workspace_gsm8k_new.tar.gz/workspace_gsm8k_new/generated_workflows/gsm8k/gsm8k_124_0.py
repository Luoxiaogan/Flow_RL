# Workflow ID: gsm8k_124_0
# Benchmark: gsm8k
# Data Indices: [57, 24]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify key elements and structure
        analysis = await self.generate(
            instruction="Identify all known values, unknowns, and relationships in the problem. Focus on quantities, operations, and units."
        )

        # Step 2: Extract structured facts (e.g., numbers, variables, constraints)
        extracted_facts = await self.generate(
            instruction="From the analysis, extract only numerical values, variables, and their meanings as a concise list. Include units if mentioned.",
            context=analysis
        )

        # Step 3: Generate multiple solution paths based on different interpretations or strategies
        plan1 = await self.generate(
            instruction="Propose one possible step-by-step solution path using basic arithmetic and unit tracking.",
            context=extracted_facts
        )
        plan2 = await self.generate(
            instruction="Propose an alternative solution path focusing on proportional reasoning or algebraic setup.",
            context=extracted_facts
        )
        plan3 = await self.generate(
            instruction="Propose a third solution path that explicitly tracks remaining items or time-based steps.",
            context=extracted_facts
        )

        # Step 4: Ensemble the three plans to select the most coherent and accurate approach
        selected_plan = await self.ensemble(
            instruction="Choose the best solution strategy by comparing the clarity, logical flow, and consistency with the original problem.",
            contexts_to_ensemble=[plan1, plan2, plan3]
        )

        # Step 5: Generate final solution using the selected plan
        final_solution = await self.generate(
            instruction="Now solve the problem completely using the selected strategy. Show each intermediate step clearly.",
            context=selected_plan
        )

        # Step 6: Revise for correctness — test against hidden constraints and unit consistency
        revised_solution = await self.revise(
            instruction="Check the solution for mathematical accuracy, proper unit handling, and whether it satisfies all conditions in the problem. Fix any errors.",
            context_to_revise=final_solution
        )

        # Step 7: Final verification — ensure answer makes sense in context
        final_answer = await self.generate(
            instruction="Verify that the final numerical answer fits logically within the scenario described. If not, suggest corrections.",
            context=revised_solution
        )

        return final_answer