# Workflow ID: gsm8k_121_0
# Benchmark: gsm8k
# Data Indices: [278, 117]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Analyze the problem structure and identify key elements
        analysis = await self.generate(
            instruction="Identify all known quantities, unknowns, units, and relationships in the problem. Focus on what needs to be calculated."
        )

        # Step 2: Extract structured data from the analysis (e.g., numbers, operations)
        extraction = await self.generate(
            instruction="From the analysis, extract numerical values, their units, and the mathematical relationship between them. Format as a list of facts.",
            context=analysis
        )

        # Step 3: Generate multiple solution paths — one linear, one with unit conversion check
        linear_path = await self.generate(
            instruction="Generate a step-by-step solution assuming a straightforward sequence of operations based on the extracted facts.",
            context=extraction
        )

        unit_check_path = await self.generate(
            instruction="Generate an alternative solution path that explicitly checks unit consistency at each step and converts units if needed.",
            context=extraction
        )

        # Step 4: Ensemble the two paths to resolve discrepancies or confirm correctness
        final_solution = await self.ensemble(
            instruction="Compare both solutions. If they agree, return the common answer. If they differ, choose the one that better handles real-world constraints like non-negative results or unit validity.",
            contexts_to_ensemble=[linear_path, unit_check_path]
        )

        # Step 5: Optional refinement loop if initial ensemble seems uncertain
        if "uncertain" in final_solution.lower() or "discrepancy" in final_solution.lower():
            refined_solution = await self.revise(
                instruction="Refine the solution by addressing the uncertainty. Consider whether the problem implies hidden steps or contextual constraints (e.g., no negative items).",
                context_to_revise=final_solution
            )
            return refined_solution

        return final_solution