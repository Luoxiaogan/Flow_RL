# Workflow ID: gsm8k_132_0
# Benchmark: gsm8k
# Data Indices: [262, 297]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Analyze the problem structure and identify key elements
        analysis = await self.generate(
            instruction="Identify all numerical values, relationships, and unknowns in the problem. List them clearly."
        )

        # Step 2: Extract structured facts from the analysis (e.g., quantities, operations)
        extracted_facts = await self.generate(
            instruction="From the analysis, extract each fact as a clear statement like 'John has X apples' or 'The rate is Y per Z'.",
            context=analysis
        )

        # Step 3: Generate multiple solution paths based on different interpretations or strategies
        path1 = self.generate(
            instruction="Generate a step-by-step plan assuming this is a sequential operation problem.",
            context=extracted_facts
        )
        path2 = self.generate(
            instruction="Generate a step-by-step plan assuming this is a proportional reasoning problem.",
            context=extracted_facts
        )
        path3 = self.generate(
            instruction="Generate a step-by-step plan assuming this is a distribution or comparison problem.",
            context=extracted_facts
        )

        # Execute all paths in parallel to explore diverse reasoning approaches
        solutions = await asyncio.gather(path1, path2, path3)

        # Step 4: Ensemble the three candidate solutions to find the most consistent answer
        final_solution = await self.ensemble(
            instruction="Select the most accurate and consistent numerical solution among these candidates. Justify briefly.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional refinement — if the ensemble result seems ambiguous, revise it
        if "likely" in final_solution.lower() or "uncertain" in final_solution.lower():
            refined_solution = await self.revise(
                instruction="Revise the solution by focusing on unit consistency and logical order of operations. Ensure no negative or fractional items if not allowed.",
                context_to_revise=final_solution
            )
            return refined_solution

        return final_solution