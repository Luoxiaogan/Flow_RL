# Workflow ID: gsm8k_19_0
# Benchmark: gsm8k
# Data Indices: [54, 127]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify key entities, quantities, and operations
        analysis = await self.generate(
            instruction="Identify all numerical values, relationships, and required operations in the problem."
        )

        # Step 2: Extract structured facts (e.g., "John has 5 apples", "Mary has 3 more than John")
        extracted_facts = await self.generate(
            instruction="From the analysis, extract clean, structured facts about known values and their relationships.",
            context=analysis
        )

        # Step 3: Generate multiple solution paths (parallel exploration)
        task1 = self.generate(
            instruction="Generate a step-by-step solution based on the extracted facts using sequential reasoning.",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Generate an alternative solution path by focusing on unit tracking and conversion if needed.",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Generate a solution that explicitly checks for contextual constraints (e.g., no negative items).",
            context=extracted_facts
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble to select the most consistent and logically sound answer
        final_answer = await self.ensemble(
            instruction="Choose the best solution among the three candidates based on logical consistency, clarity, and correctness.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional refinement if needed — check for errors or missing steps
        revised_answer = await self.revise(
            instruction="Review the final answer for mathematical accuracy, unit handling, and whether it matches the original question's intent.",
            context_to_revise=final_answer
        )

        return revised_answer