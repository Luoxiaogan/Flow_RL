# Workflow ID: gsm8k_51_0
# Benchmark: gsm8k
# Data Indices: [177, 143]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Analyze the problem to identify key entities, operations, and unknowns
        analysis = await self.generate(
            instruction="Identify all numerical values, relationships, and the final quantity to find. Extract known quantities, operations (addition, subtraction, etc.), and constraints."
        )

        # Step 2: Generate an initial solution plan based on the analysis
        plan = await self.generate(
            instruction="Based on the analysis, generate a step-by-step solution strategy that handles each operation in correct order, accounting for units and context (e.g., inventory changes, transfers).",
            context=analysis
        )

        # Step 3: Execute the plan in parallel where possible (e.g., independent calculations)
        # Use extract-and-reason pattern to break down complex steps
        structured_plan = await self.summarize(context=plan)
        steps = await self.generate(
            instruction="Break the plan into individual computational steps. Each step should be self-contained and clearly labeled.",
            context=structured_plan
        )

        # Step 4: If multiple interpretations exist or uncertainty remains, explore alternatives
        if "ambiguous" in steps.lower() or "multiple ways" in steps.lower():
            alt_solutions = [
                await self.generate("Generate one possible interpretation and solution path.", context=steps),
                await self.generate("Generate a different interpretation and solution path.", context=steps)
            ]
            final_solution = await self.ensemble(
                instruction="Choose the most consistent and logically sound solution based on the original problem's constraints and real-world plausibility.",
                contexts_to_ensemble=alt_solutions
            )
        else:
            # Step 5: Proceed with linear execution of the plan
            final_solution = await self.generate(
                instruction="Execute the plan step by step. Show intermediate results explicitly and ensure unit consistency throughout.",
                context=steps
            )

        # Step 6: Verify the answer using bidirectional verification
        verification = await self.generate(
            instruction="Create a reverse problem from the final answer and verify it leads back to the original input values.",
            context=final_solution
        )

        # Step 7: Final refinement — revise based on verification insights
        final_answer = await self.revise(
            instruction="Refine the solution based on verification feedback. Ensure no arithmetic errors, unit mismatches, or logical inconsistencies remain.",
            context_to_revise=final_solution
        )

        return final_answer