# Workflow ID: gsm8k_80_0
# Benchmark: gsm8k
# Data Indices: [22, 137]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify key elements and structure
        analysis = await self.generate(
            instruction="Identify all numerical values, units, relationships, and operations required in this word problem."
        )

        # Step 2: Extract structured facts (e.g., quantities, rates, timeframes)
        extraction = await self.generate(
            instruction="From the analysis, extract all relevant numerical facts, units, and mathematical relationships as a clean list.",
            context=analysis
        )

        # Step 3: Generate multiple solution paths in parallel — one for each major operation type
        task1 = self.generate(
            instruction="Generate a step-by-step plan assuming this is a sequential calculation problem.",
            context=extraction
        )
        task2 = self.generate(
            instruction="Generate a step-by-step plan assuming this involves proportional reasoning or unit conversion.",
            context=extraction
        )
        task3 = self.generate(
            instruction="Generate a step-by-step plan assuming this requires rate-based computation (e.g., per day, per hour).",
            context=extraction
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble the three candidate solutions to select the most consistent and logical one
        final_solution = await self.ensemble(
            instruction="Choose the best solution based on internal consistency, clarity, and alignment with the original problem's constraints.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional refinement loop if uncertainty remains — use revise to improve precision
        revised = await self.revise(
            instruction="Critically review the final solution for arithmetic errors, unit mismatches, or missing steps. If needed, correct them.",
            context_to_revise=final_solution
        )

        return revised