# Workflow ID: gsm8k_103_0
# Benchmark: gsm8k
# Data Indices: [257, 96]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand structure and identify knowns/unknowns
        analysis = await self.generate(
            instruction="Analyze the problem to identify all given quantities, unknowns, and relationships between them."
        )

        # Step 2: Extract Structured Facts — Turn narrative into math-ready facts
        extracted_facts = await self.generate(
            instruction="From the analysis, extract key numerical values and their roles (e.g., initial amount, fractions used, final quantity needed).",
            context=analysis
        )

        # Step 3: Parallel Exploration — Generate multiple solution paths if ambiguous
        task1 = self.generate(
            instruction="Generate a step-by-step arithmetic solution assuming sequential operations (like usage over time).",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Generate a proportional reasoning solution focusing on fractions or percentages.",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Generate an algebraic approach by setting up equations based on the problem's constraints.",
            context=extracted_facts
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble — Combine competing approaches to select most robust answer
        final_answer = await self.ensemble(
            instruction="Compare the three proposed solutions and determine which one best matches the problem's logic and units.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Revise for Accuracy — Self-check using bidirectional verification
        verification = await self.revise(
            instruction="Check whether the final answer makes sense in context: does it respect units, logical constraints (e.g., no negatives), and match the question being asked?",
            context_to_revise=final_answer
        )

        return verification