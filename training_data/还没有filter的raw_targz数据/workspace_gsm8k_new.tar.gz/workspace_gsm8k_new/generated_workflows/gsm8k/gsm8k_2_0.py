# Workflow ID: gsm8k_2_0
# Benchmark: gsm8k
# Data Indices: [134, 169]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand the problem structure
        analysis = await self.generate(
            instruction="Identify all known quantities, unknowns, and relationships in the problem. Focus on numerical values and operations required."
        )

        # Step 2: Extract structured facts from the analysis for clarity
        extracted_facts = await self.generate(
            instruction="From the analysis, extract only the key numerical values and their roles (e.g., 'total nails', 'nails per dog', 'dogs with missing legs').",
            context=analysis
        )

        # Step 3: Generate multiple solution paths — parallel exploration
        task1 = self.generate(
            instruction="Solve using step-by-step arithmetic reasoning based on the extracted facts.",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Model this as an algebraic equation: define variables and solve for the unknown quantity.",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Break down the problem into sub-problems (e.g., calculate total expected nails if all dogs had 4 legs, then adjust for missing legs).",
            context=extracted_facts
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble to select the most consistent and logical answer
        final_answer = await self.ensemble(
            instruction="Compare the three generated solutions. Choose the one that aligns best with the original problem's constraints and makes sense in context.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional refinement — revise if there's ambiguity or inconsistency
        revised_answer = await self.revise(
            instruction="If any of the solutions conflict or seem unrealistic (e.g., negative dogs), revise the final answer accordingly.",
            context_to_revise=final_answer
        )

        return revised_answer