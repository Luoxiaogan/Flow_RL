# Workflow ID: gsm8k_133_0
# Benchmark: gsm8k
# Data Indices: [180, 144]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand the problem structure and identify key elements
        analysis = await self.generate(
            instruction="Identify all known quantities, unknowns, units, and relationships in the problem. Highlight any hidden steps or constraints."
        )

        # Step 2: Extract Structured Facts — Turn dense text into clean data points
        extracted_facts = await self.generate(
            instruction="Extract all numerical values, their units, and associated contexts from the analysis. Format as bullet points.",
            context=analysis
        )

        # Step 3: Generate Multiple Reasoning Paths — Explore different valid interpretations or solution strategies
        path1 = self.generate(
            instruction="Solve the problem using a linear step-by-step approach based on the extracted facts.",
            context=extracted_facts
        )
        path2 = self.generate(
            instruction="Break the problem into sub-problems (e.g., sugar for batter vs. frosting), solve each independently, then combine.",
            context=extracted_facts
        )
        path3 = self.generate(
            instruction="Create an inverse check: assume a final answer and verify if it leads back to the original conditions.",
            context=extracted_facts
        )

        # Step 4: Parallel Execution — Run all paths concurrently to save time
        results = await asyncio.gather(path1, path2, path3)

        # Step 5: Ensemble Final Answer — Synthesize best solution from competing paths
        final_answer = await self.ensemble(
            instruction="Choose the most consistent and logically sound answer among the three solutions. If there's disagreement, explain why one is preferred.",
            contexts_to_ensemble=results
        )

        # Step 6: Revise for Precision — Refine the final answer with error-checking focus
        refined_answer = await self.revise(
            instruction="Review the final answer for correctness, unit consistency, and logical coherence. Correct any errors found.",
            context_to_revise=final_answer
        )

        return refined_answer