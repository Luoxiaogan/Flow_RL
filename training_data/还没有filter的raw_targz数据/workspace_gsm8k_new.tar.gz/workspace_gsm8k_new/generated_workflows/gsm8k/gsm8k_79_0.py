# Workflow ID: gsm8k_79_0
# Benchmark: gsm8k
# Data Indices: [196, 282]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis
        analysis = await self.generate(
            instruction="Identify all known quantities, unknowns, and relationships in the problem. Extract numerical values, units, and operations required."
        )

        # Step 2: Structured Data Extraction (Parallel Branching)
        extract_tasks = [
            self.generate("Extract all items, their quantities per unit, and costs or rates."),
            self.generate("List all entities involved and how they relate to each other.")
        ]
        extracted_data, entity_relations = await asyncio.gather(*extract_tasks)

        # Step 3: Generate Multiple Solution Paths (Diverge)
        solution_paths = []
        path_instructions = [
            "Generate a step-by-step calculation plan assuming all items are multiplied by count.",
            "Generate a plan focusing on unit cost breakdown first, then total sum.",
            "Generate a plan that accounts for discounts or constraints explicitly."
        ]
        for instr in path_instructions:
            solution_paths.append(await self.generate(instr, context=analysis))

        # Step 4: Ensemble Best Solutions (Converge)
        final_plan = await self.ensemble(
            instruction="Compare the three solution paths and select the most consistent and complete approach.",
            contexts_to_ensemble=solution_paths
        )

        # Step 5: Execute Plan with Iterative Refinement
        current_solution = await self.generate(
            instruction="Now compute the final numerical answer based on the selected plan.",
            context=final_plan
        )

        # Step 6: Revise Based on Logical Consistency
        revised_solution = await self.revise(
            instruction="Check for unit consistency, arithmetic errors, and whether the answer makes sense in context.",
            context_to_revise=current_solution
        )

        # Step 7: Final Verification via Bidirectional Check (Optional but Robust)
        verification_check = await self.generate(
            instruction="Create an inverse problem from this solution and verify it leads back to the original scenario.",
            context=revised_solution
        )

        # Step 8: Final Ensemble of Original + Revised + Verified
        final_answer = await self.ensemble(
            instruction="Choose the most accurate numerical result after considering original reasoning, revision, and verification.",
            contexts_to_ensemble=[current_solution, revised_solution, verification_check]
        )

        return final_answer