# Workflow ID: gsm8k_73_0
# Benchmark: gsm8k
# Data Indices: [279, 259]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify key elements and structure
        analysis = await self.generate(
            instruction="Identify all known quantities, unknowns, units, and relationships in the problem. Focus on mathematical operations needed."
        )

        # Step 2: Extract structured facts from analysis (e.g., numbers, operations, entities)
        extracted_facts = await self.generate(
            instruction="From the analysis, extract a clear list of numerical values, their units, and what they represent.",
            context=analysis
        )

        # Step 3: Generate multiple solution paths in parallel — one for each likely interpretation or approach
        task1 = self.generate(
            instruction="Generate a step-by-step solution assuming a linear sequence of operations based on the extracted facts.",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Generate an alternative solution path that explicitly handles unit conversions or proportional reasoning if applicable.",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Generate a solution using algebraic modeling (define variables, write equations).",
            context=extracted_facts
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble to select the most consistent and accurate solution
        final_answer = await self.ensemble(
            instruction="Choose the best solution among these three by comparing logical consistency, correctness of operations, and alignment with the original question.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional refinement — check for common errors like negative results or unit mismatches
        revised_answer = await self.revise(
            instruction="Review the final answer: does it make sense in context? Is it positive? Are units correct? If not, revise accordingly.",
            context_to_revise=final_answer
        )

        return revised_answer