# Workflow ID: gsm8k_95_0
# Benchmark: gsm8k
# Data Indices: [74, 77]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Analyze the problem structure and identify key elements
        analysis = await self.generate(
            instruction="Identify all known quantities, unknowns, units, and relationships in the problem. Focus on mathematical operations needed."
        )

        # Step 2: Extract structured data (quantities, operations, context)
        extracted_data = await self.generate(
            instruction="Extract all numerical values, their units, and what they represent (e.g., '4 shirts', '5 buttons per shirt').",
            context=analysis
        )

        # Step 3: Generate multiple solution paths based on different interpretations or approaches
        task1 = self.generate(
            instruction="First approach: Break down the problem into sequential steps using basic arithmetic.",
            context=extracted_data
        )
        task2 = self.generate(
            instruction="Second approach: Identify proportional or rate-based relationships (if applicable).",
            context=extracted_data
        )
        task3 = self.generate(
            instruction="Third approach: Consider unit conversions or distribution logic if relevant.",
            context=extracted_data
        )

        # Execute parallel exploration
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble the competing solutions to select the most consistent and accurate one
        final_answer = await self.ensemble(
            instruction="Compare the three candidate solutions. Choose the one that best aligns with the original problem constraints and makes logical sense.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional refinement via revision if confidence is low (detectable from ensemble result)
        if "uncertain" in final_answer.lower() or "multiple" in final_answer.lower():
            refined_answer = await self.revise(
                instruction="Refine the answer by focusing on the most logically sound path. Recheck units and intermediate steps.",
                context_to_revise=final_answer
            )
            return refined_answer

        return final_answer