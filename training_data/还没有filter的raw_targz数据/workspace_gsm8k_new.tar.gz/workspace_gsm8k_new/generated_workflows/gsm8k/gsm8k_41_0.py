# Workflow ID: gsm8k_41_0
# Benchmark: gsm8k
# Data Indices: [159, 198]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand the structure and key elements
        analysis = await self.generate(
            instruction="Identify all known quantities, unknowns, units, and relationships in the problem. Highlight if it involves rates, proportions, or sequential operations."
        )

        # Step 2: Extract structured facts from the analysis
        extracted_facts = await self.generate(
            instruction="From the analysis, extract only numerical values and their associated units or context (e.g., '5 players', '1 yellow card each'). Return as bullet points.",
            context=analysis
        )

        # Step 3: Generate multiple solution paths based on different interpretations
        path1 = await self.generate(
            instruction="Solve this using step-by-step arithmetic reasoning, treating each sentence as a separate operation.",
            context=extracted_facts
        )
        
        path2 = await self.generate(
            instruction="Model this as a proportional relationship or equation (e.g., set up variables and solve algebraically).",
            context=extracted_facts
        )

        # Step 4: Parallel exploration → Ensemble the two solutions
        ensemble_result = await self.ensemble(
            instruction="Compare both approaches and select the one that best fits the original problem's logic and constraints.",
            contexts_to_ensemble=[path1, path2]
        )

        # Step 5: Revise with verification angle — check if the answer makes sense contextually
        final_solution = await self.revise(
            instruction="Verify the solution by checking unit consistency, logical flow, and whether the result matches real-world expectations (e.g., no negative counts).",
            context_to_revise=ensemble_result
        )

        return final_solution