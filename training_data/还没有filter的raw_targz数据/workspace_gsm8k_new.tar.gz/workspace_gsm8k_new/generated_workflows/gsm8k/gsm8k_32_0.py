# Workflow ID: gsm8k_32_0
# Benchmark: gsm8k
# Data Indices: [242, 7]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand structure and key elements
        analysis = await self.generate(
            instruction="Identify all entities, quantities, relationships, and operations mentioned in the problem. Focus on what needs to be calculated."
        )

        # Step 2: Extract structured facts from the analysis
        extracted_facts = await self.generate(
            instruction="From the analysis, extract all numerical values, variables, and their relationships as bullet points or a list format.",
            context=analysis
        )

        # Step 3: Generate multiple solution paths — one for each possible interpretation or calculation sequence
        task1 = self.generate(
            instruction="Generate a step-by-step solution assuming the problem involves sequential operations (e.g., first throw, second throw, etc.).",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Generate an alternative solution focusing on proportional reasoning or unit-based comparisons.",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Generate a solution that explicitly tracks units (feet, mugs, etc.) at every step to ensure consistency.",
            context=extracted_facts
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble the three candidate solutions to resolve discrepancies
        final_answer = await self.ensemble(
            instruction="Compare the three proposed solutions and select the most consistent one based on internal logic, unit handling, and adherence to the problem constraints.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Revise final answer using a verification-focused prompt
        verified_answer = await self.revise(
            instruction="Check if the final answer makes sense in context: does it respect real-world constraints (e.g., no negative counts), match expected operations, and align with all given data?",
            context_to_revise=final_answer
        )

        return verified_answer