# Workflow ID: gsm8k_101_0
# Benchmark: gsm8k
# Data Indices: [133, 73]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Analyze the problem structure and identify key elements
        analysis = await self.generate(
            instruction="Identify all known values, unknowns, relationships, and required operations in the problem."
        )

        # Step 2: Extract structured facts from the analysis for clear reasoning
        extracted_facts = await self.generate(
            instruction="From the analysis, extract only numerical values and their associated variables or entities.",
            context=analysis
        )

        # Step 3: Generate multiple solution paths based on different interpretations
        path1 = await self.generate(
            instruction="Solve step-by-step using a linear decomposition approach.",
            context=extracted_facts
        )
        path2 = await self.generate(
            instruction="Solve by first identifying what needs to be calculated first (e.g., intermediate variables).",
            context=extracted_facts
        )
        path3 = await self.generate(
            instruction="Solve by setting up equations for each relationship described in the problem.",
            context=extracted_facts
        )

        # Step 4: Ensemble the three solutions to resolve discrepancies
        final_answer = await self.ensemble(
            instruction="Choose the most consistent and mathematically valid answer among the three solutions.",
            contexts_to_ensemble=[path1, path2, path3]
        )

        # Step 5: Revise final answer if needed — test consistency with original problem
        revised_answer = await self.revise(
            instruction="Check that the final answer makes sense in the context of the original problem and verify units/dimensions.",
            context_to_revise=final_answer
        )

        return revised_answer