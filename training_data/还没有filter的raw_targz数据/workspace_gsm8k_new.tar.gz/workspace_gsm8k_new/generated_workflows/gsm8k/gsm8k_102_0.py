# Workflow ID: gsm8k_102_0
# Benchmark: gsm8k
# Data Indices: [90, 207]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify key elements (values, operations, unknowns)
        analysis = await self.generate(
            instruction="Extract all numerical values, relationships, and what needs to be calculated from the problem. List them clearly."
        )

        # Step 2: Generate multiple solution paths based on different interpretations
        task1 = self.generate(
            instruction="Generate a step-by-step solution assuming the problem involves sequential operations.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Generate a solution focusing on proportional reasoning or unit-based calculations if applicable.",
            context=analysis
        )
        task3 = self.generate(
            instruction="Generate a solution that explicitly tracks units (e.g., plates, computers) through each step.",
            context=analysis
        )

        # Execute in parallel for efficiency
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble to select the most consistent and accurate solution
        final_answer = await self.ensemble(
            instruction="Choose the best solution based on clarity, consistency with the problem, and logical correctness. If there's disagreement, resolve it by prioritizing explicit arithmetic steps over assumptions.",
            contexts_to_ensemble=solutions
        )

        # Step 4: Optional refinement via revision if needed
        refined_answer = await self.revise(
            instruction="Check if the final answer makes sense in the context of the original problem. Ensure no negative quantities, proper rounding, and correct units are used.",
            context_to_revise=final_answer
        )

        return refined_answer