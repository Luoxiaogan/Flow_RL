# Workflow ID: gsm8k_146_0
# Benchmark: gsm8k
# Data Indices: [267, 215]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand the structure and required operations
        analysis = await self.generate(
            instruction="Identify all known quantities, unknowns, and relationships in the problem. Focus on mathematical operations needed (e.g., addition, subtraction, ratios)."
        )

        # Step 2: Extract structured facts from the analysis for precise reasoning
        extracted_facts = await self.generate(
            instruction="From the analysis, extract key numerical values and their roles (e.g., 'Sally has X', 'Jolly has Y'). Format as a list of facts.",
            context=analysis
        )

        # Step 3: Generate multiple solution paths in parallel — one for each major operation type
        task1 = self.generate(
            instruction="Assume this is a simple arithmetic problem involving basic operations like addition or subtraction. Solve step-by-step."
        )
        task2 = self.generate(
            instruction="Assume this involves proportional reasoning (e.g., ratios, scaling). Solve accordingly."
        )
        task3 = self.generate(
            instruction="Assume this requires solving for an unknown using algebraic expressions. Set up equations and solve."
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble the three candidate solutions to select the most consistent and accurate one
        final_answer = await self.ensemble(
            instruction="Evaluate the three candidate solutions based on consistency with the original problem and logical coherence. Select the best one.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional refinement if confidence is low — test against real-world constraints
        if "likely incorrect" in final_answer.lower() or "inconsistent" in final_answer.lower():
            refined_answer = await self.revise(
                instruction="Revise the solution considering unit tracking, non-negative results, and logical feasibility in context.",
                context_to_revise=final_answer
            )
            return refined_answer

        return final_answer