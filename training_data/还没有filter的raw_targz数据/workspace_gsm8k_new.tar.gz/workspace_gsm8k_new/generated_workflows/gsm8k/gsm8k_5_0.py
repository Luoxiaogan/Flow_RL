# Workflow ID: gsm8k_5_0
# Benchmark: gsm8k
# Data Indices: [124, 213]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis – Understand the problem structure and identify key elements
        analysis = await self.generate(
            instruction="Identify all known quantities, unknowns, and relationships in the problem. Focus on units, operations, and constraints."
        )

        # Step 2: Extract Structured Facts – Turn narrative into clean data points
        extracted_facts = await self.generate(
            instruction="Extract all numerical values, variables, and their roles (e.g., 'Jacob has 8 fish', 'Alex caught 7x Jacob's fish').",
            context=analysis
        )

        # Step 3: Generate Multiple Solution Paths – Use parallel exploration to handle ambiguity or complexity
        task1 = self.generate(
            instruction="Solve step-by-step using sequential reasoning: calculate Alex’s initial catch, then subtract lost fish, then determine how many Jacob needs to beat Alex by 1.",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Model this as an algebraic equation: Let x be Jacob’s final count. Set up inequality based on 'beat Alex by 1 fish' and solve for x.",
            context=extracted_facts
        )
        solutions = await asyncio.gather(task1, task2)

        # Step 4: Ensemble Final Answer – Compare both approaches to resolve discrepancies
        final_answer = await self.ensemble(
            instruction="Compare both solution paths. If they agree, return the common answer. If not, choose the one that better respects constraints like non-negative counts and unit consistency.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional Refinement – Revise if the answer seems implausible
        revised_answer = await self.revise(
            instruction="Check if the final answer makes sense in context: Does it respect real-world constraints (no negative fish, whole numbers)? If not, correct it.",
            context_to_revise=final_answer
        )

        return revised_answer