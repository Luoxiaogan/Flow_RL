# Workflow ID: gsm8k_38_0
# Benchmark: gsm8k
# Data Indices: [184, 12]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify key elements and structure
        analysis = await self.generate(
            instruction="Identify all known quantities, unknowns, units, and relationships in the problem. Extract numerical values and their context."
        )

        # Step 2: Generate multiple solution paths using parallel exploration
        task1 = self.generate(
            instruction="Create a step-by-step solution focusing on mathematical modeling and unit tracking.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Create an alternative solution path by first identifying hidden steps or constraints not immediately obvious.",
            context=analysis
        )
        task3 = self.generate(
            instruction="Create a solution that explicitly tracks units (e.g., dollars, items, time) at each step to avoid errors.",
            context=analysis
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble to select the most robust solution
        final_solution = await self.ensemble(
            instruction="Evaluate the three candidate solutions. Choose the one that best handles all given data, respects units, and avoids contradictions.",
            contexts_to_ensemble=solutions
        )

        # Step 4: Revise for precision — test against common pitfalls like negative results or unit mismatches
        revised_solution = await self.revise(
            instruction="Review the selected solution for logical consistency, arithmetic correctness, and whether it satisfies all real-world constraints (e.g., no negative items).",
            context_to_revise=final_solution
        )

        return revised_solution