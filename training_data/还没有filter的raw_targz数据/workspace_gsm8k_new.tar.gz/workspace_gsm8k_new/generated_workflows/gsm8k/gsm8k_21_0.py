# Workflow ID: gsm8k_21_0
# Benchmark: gsm8k
# Data Indices: [131, 275]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis
        analysis = await self.generate(
            instruction="Analyze the problem to identify known values, unknowns, relationships, and required operations."
        )

        # Step 2: Extract Structured Facts
        facts = await self.generate(
            instruction="Extract all numerical values, variables, and key relationships from the analysis into a structured format.",
            context=analysis
        )

        # Step 3: Generate Multiple Solution Paths (Parallel Exploration)
        task1 = self.generate(
            instruction="Generate a step-by-step solution using a sequential approach based on the extracted facts.",
            context=facts
        )
        task2 = self.generate(
            instruction="Generate an alternative solution path by identifying hidden steps or unit conversions that may be needed.",
            context=facts
        )
        task3 = self.generate(
            instruction="Generate a solution path focusing on proportional reasoning or ratios if applicable.",
            context=facts
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer
        final_answer = await self.ensemble(
            instruction="Select the most consistent and logically sound solution from the three candidates. If there's disagreement, explain why one stands out.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Revise for Accuracy and Unit Consistency
        revised_answer = await self.revise(
            instruction="Review the final answer for mathematical correctness, logical consistency, and proper handling of units or constraints (e.g., no negative counts).",
            context_to_revise=final_answer
        )

        return revised_answer