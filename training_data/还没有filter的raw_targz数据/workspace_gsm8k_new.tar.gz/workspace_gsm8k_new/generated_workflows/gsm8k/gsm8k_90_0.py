# Workflow ID: gsm8k_90_0
# Benchmark: gsm8k
# Data Indices: [269, 43]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Analyze the problem to identify key entities, quantities, and relationships
        analysis = await self.generate(
            instruction="Identify all numerical values, variables, and operations described in the problem. Extract key facts including who, what, how many, and how things change over time or through actions."
        )

        # Step 2: Generate a step-by-step solution plan based on the analysis
        plan = await self.generate(
            instruction="Based on the extracted facts, generate a clear, sequential plan to solve this math word problem. Include steps for unit tracking, intermediate calculations, and final answer extraction.",
            context=analysis
        )

        # Step 3: Execute the plan by generating each calculation step
        steps = []
        step_count = 0
        while True:
            if step_count == 0:
                step_instruction = "First, perform the initial calculation based on the plan."
            else:
                step_instruction = f"Next, perform step {step_count + 1} of the plan."

            step_result = await self.generate(
                instruction=step_instruction,
                context=f"Plan: {plan}\nCurrent progress: {steps if steps else 'None'}"
            )
            steps.append(step_result)
            
            # Check if we've reached the end of the plan (e.g., when a numeric answer appears)
            if any(keyword in step_result.lower() for keyword in ["answer", "final result", "total", "value"]):
                break
            
            step_count += 1

        # Step 4: Summarize the full reasoning chain for clarity and consistency
        reasoning_summary = await self.summarize(
            context="\n".join(steps)
        )

        # Step 5: Revise the solution for potential errors or missing steps
        revised_solution = await self.revise(
            instruction="Review the entire solution for logical consistency, arithmetic accuracy, unit correctness, and whether it fully answers the original question. Fix any issues found.",
            context_to_revise=reasoning_summary
        )

        # Step 6: If multiple solutions exist (e.g., from parallel exploration), ensemble them
        # For now, assume one solution path — but structure for future expansion
        final_answer = await self.generate(
            instruction="Extract only the final numerical answer from the revised solution. Do not include any explanation or text around it.",
            context=revised_solution
        )

        return final_answer