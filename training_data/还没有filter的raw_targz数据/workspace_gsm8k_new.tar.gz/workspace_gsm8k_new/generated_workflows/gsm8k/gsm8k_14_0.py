# Workflow ID: gsm8k_14_0
# Benchmark: gsm8k
# Data Indices: [140, 289]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Extract key numerical values and relationships from the problem
        extraction = await self.generate(
            instruction="Extract all numerical values and their associated entities (e.g., '325 chickens', '28 roosters', '20 hens do not lay eggs')."
        )

        # Step 2: Analyze the structure of the problem to identify required operations
        analysis = await self.generate(
            instruction="Based on the extracted information, determine the sequence of calculations needed to solve the problem. Identify knowns, unknowns, and whether it involves subtraction, division, or proportional reasoning.",
            context=extraction
        )

        # Step 3: Generate multiple solution paths if ambiguity exists (e.g., ratio vs. percentage)
        parallel_paths = [
            self.generate(
                instruction="Generate one possible step-by-step solution path based on the analysis.",
                context=analysis
            ),
            self.generate(
                instruction="Generate an alternative solution path considering different interpretations of the same data (e.g., order of operations or unit conversions).",
                context=analysis
            )
        ]
        solutions = await asyncio.gather(*parallel_paths)

        # Step 4: Ensemble the two paths to select the most coherent and accurate solution
        final_solution = await self.ensemble(
            instruction="Compare the two solution paths and choose the one that correctly applies mathematical logic and matches the problem constraints.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Revise the final answer with error-checking prompts
        revised_solution = await self.revise(
            instruction="Verify that the final answer makes sense in context — check units, ensure no negative counts, and confirm arithmetic correctness.",
            context_to_revise=final_solution
        )

        return revised_solution