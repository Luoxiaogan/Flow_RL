# Workflow ID: gsm8k_56_0
# Benchmark: gsm8k
# Data Indices: [61, 271]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify key elements and problem type
        analysis = await self.generate(
            instruction="Identify all known values, unknowns, units, and relationships in the problem. Classify it as sequential, rate, proportional, distribution, comparison, or multi-entity."
        )

        # Step 2: Extract structured facts from analysis for precise reasoning
        extracted_facts = await self.generate(
            instruction="Extract all numerical values, variables, and relationships into a clean, structured list of key facts.",
            context=analysis
        )

        # Step 3: Generate multiple solution paths in parallel based on different interpretations
        task1 = self.generate(
            instruction="Solve using a step-by-step arithmetic approach, assuming no hidden steps.",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Solve by setting up an equation or system of equations based on the relationships described.",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Solve by breaking the problem into sub-problems (e.g., find intermediate values first).",
            context=extracted_facts
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble the three candidate solutions to select the most consistent one
        final_answer = await self.ensemble(
            instruction="Select the best solution among the three candidates. If they differ, choose the one that aligns with the problem's constraints and makes logical sense.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional refinement loop if there's ambiguity or inconsistency
        if "ambiguous" in final_answer.lower() or "multiple" in final_answer.lower():
            refined = await self.revise(
                instruction="Revise the answer based on the most consistent interpretation. Focus on unit consistency, order of operations, and real-world feasibility.",
                context_to_revise=final_answer
            )
            return refined

        return final_answer