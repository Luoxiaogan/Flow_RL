# Workflow ID: gsm8k_22_0
# Benchmark: gsm8k
# Data Indices: [294, 20]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Identify knowns, unknowns, and structure
        analysis = await self.generate(
            instruction="Identify all known quantities, unknowns, units, and relationships in the problem. List them clearly."
        )

        # Step 2: Extract Structured Data — Convert narrative into structured facts
        structured_data = await self.generate(
            instruction="Extract numerical values, variables, and constraints from the analysis. Format as key-value pairs.",
            context=analysis
        )

        # Step 3: Generate Multiple Solution Paths — Use parallel exploration for robustness
        task1 = self.generate(
            instruction="Generate a step-by-step solution assuming the problem requires sequential operations.",
            context=structured_data
        )
        task2 = self.generate(
            instruction="Generate a solution focusing on proportional reasoning or unit-based calculations.",
            context=structured_data
        )
        task3 = self.generate(
            instruction="Generate a solution using algebraic modeling (define variable x, set up equation).",
            context=structured_data
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer — Select best-supported solution
        final_answer = await self.ensemble(
            instruction="Compare the three proposed solutions. Choose the one that aligns with all given constraints and makes logical sense.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Verify & Revise — Self-check for consistency and correctness
        verification = await self.generate(
            instruction="Verify the final answer by checking if it satisfies all conditions in the original problem. If not, revise accordingly.",
            context=final_answer
        )

        # Optional: If verification fails, try another round of revision
        if "incorrect" in verification.lower() or "not valid" in verification.lower():
            revised_final = await self.revise(
                instruction="Revise the solution to fix inconsistencies found during verification.",
                context_to_revise=verification
            )
            return revised_final

        return verification