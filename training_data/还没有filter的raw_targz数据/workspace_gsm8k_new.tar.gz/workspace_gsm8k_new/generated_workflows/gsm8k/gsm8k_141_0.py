# Workflow ID: gsm8k_141_0
# Benchmark: gsm8k
# Data Indices: [9, 68]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify key entities, values, and relationships
        analysis = await self.generate(
            instruction="Extract all numerical values, units, and relationships from the problem. Identify whether it involves rates, proportions, comparisons, or multi-step operations."
        )

        # Step 2: Generate multiple solution paths based on different interpretations or strategies
        task1 = self.generate(
            instruction="Generate a step-by-step solution assuming the problem requires proportional reasoning (e.g., percentages, ratios).",
            context=analysis
        )
        task2 = self.generate(
            instruction="Generate a step-by-step solution assuming the problem requires sequential arithmetic steps.",
            context=analysis
        )
        task3 = self.generate(
            instruction="Generate a solution focusing on unit tracking and conversion if applicable.",
            context=analysis
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble the candidate solutions to select the most consistent and logical one
        final_answer = await self.ensemble(
            instruction="Compare the three proposed solutions. Select the one that best aligns with the original problem's structure, uses correct mathematical logic, and avoids contradictions or impossible values (like negative counts).",
            contexts_to_ensemble=solutions
        )

        # Step 4: Optional refinement — check if answer makes sense in context
        verification = await self.revise(
            instruction="Review the final answer. Does it satisfy all constraints mentioned in the problem? If not, revise it accordingly.",
            context_to_revise=final_answer
        )

        return verification