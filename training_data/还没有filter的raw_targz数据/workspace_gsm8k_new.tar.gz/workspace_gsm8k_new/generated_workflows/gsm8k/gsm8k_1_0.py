# Workflow ID: gsm8k_1_0
# Benchmark: gsm8k
# Data Indices: [5, 29]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Analyze the problem structure and identify key elements
        analysis = await self.generate(
            instruction="Identify all numerical values, relationships, units, and unknowns in the problem. Extract explicit and implicit quantities."
        )

        # Step 2: Generate a structured plan based on the analysis
        planning = await self.generate(
            instruction="Based on the extracted information, generate a step-by-step solution plan. Include unit tracking and logical order of operations.",
            context=analysis
        )

        # Step 3: Parallel exploration — try two different reasoning paths if ambiguous
        task1 = self.generate(
            instruction="Solve the problem using a linear sequence of operations as per the plan.",
            context=planning
        )
        task2 = self.generate(
            instruction="Re-solve the problem by first summarizing all known values and then computing step-by-step from the start.",
            context=analysis
        )
        solutions = await asyncio.gather(task1, task2)

        # Step 4: Ensemble to select the most consistent solution
        final_answer = await self.ensemble(
            instruction="Compare both solutions and choose the one that aligns best with the original problem constraints, including unit consistency and realistic values.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional refinement if there's ambiguity or inconsistency
        if "ambiguous" in final_answer.lower() or "uncertain" in final_answer.lower():
            refined = await self.revise(
                instruction="Refine the answer by checking each step for arithmetic correctness, unit conversion, and real-world plausibility.",
                context_to_revise=final_answer
            )
            return refined

        return final_answer