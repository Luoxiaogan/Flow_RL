# Workflow ID: gsm8k_43_0
# Benchmark: gsm8k
# Data Indices: [220, 84]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis – Understand the problem structure and identify key elements
        analysis = await self.generate(
            instruction="Identify all known quantities, unknowns, relationships, and units in the problem. Break it down into components."
        )

        # Step 2: Extract Structured Facts – Convert natural language to structured data
        extracted_facts = await self.generate(
            instruction="Extract numerical values, operations, and constraints from the analysis. Format as bullet points with clear labels (e.g., 'Known Value: ...', 'Operation: ...').",
            context=analysis
        )

        # Step 3: Generate Multiple Solution Paths – Use parallel exploration for robustness
        task1 = self.generate(
            instruction="Propose a step-by-step solution based on the extracted facts, focusing on sequential calculations.",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Propose an alternative approach—e.g., using ratios, percentages, or unit conversion if applicable.",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Generate a solution that explicitly tracks units at each step to ensure consistency.",
            context=extracted_facts
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer – Combine multiple perspectives for accuracy
        final_answer = await self.ensemble(
            instruction="Compare the three proposed solutions. Choose the most consistent one that respects all given constraints and units. If there's disagreement, resolve by prioritizing logical flow and mathematical correctness.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Verify & Revise – Check internal consistency and reasonableness
        verification = await self.generate(
            instruction="Review the final answer: Does it make sense in the context? Are all steps logically sound? Is the unit correct?",
            context=final_answer
        )
        
        # Optional: Refine if needed
        refined_answer = await self.revise(
            instruction="If the verification reveals any inconsistencies, revise the answer accordingly while preserving the original reasoning path.",
            context_to_revise=final_answer + "\n\n" + verification
        )

        return refined_answer