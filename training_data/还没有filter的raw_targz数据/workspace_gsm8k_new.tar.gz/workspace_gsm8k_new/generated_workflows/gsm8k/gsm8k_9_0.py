# Workflow ID: gsm8k_9_0
# Benchmark: gsm8k
# Data Indices: [205, 223]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify key entities, quantities, and operations
        analysis = await self.generate(
            instruction="Identify all numerical values, relationships, and required operations in the problem. Extract key facts like total quantities, changes, ratios, and unknowns."
        )

        # Step 2: Generate a step-by-step solution plan based on analysis
        plan = await self.generate(
            instruction="Based on the extracted facts, generate a clear, sequential plan to solve this math word problem. Include how to handle units, order of operations, and intermediate steps.",
            context=analysis
        )

        # Step 3: Parallel exploration of multiple solution paths (if needed)
        # Use ensemble if ambiguity exists; otherwise proceed linearly
        plan_summary = await self.summarize(plan)
        if "multiple interpretations" in plan_summary.lower() or "ambiguous" in plan_summary.lower():
            # If ambiguity detected, explore multiple approaches
            task1 = self.generate("Generate one possible solution path using the first interpretation.")
            task2 = self.generate("Generate an alternative solution path using a different interpretation.", context=analysis)
            results = await asyncio.gather(task1, task2)
            final_solution = await self.ensemble(
                instruction="Choose the most consistent and logically sound solution from the candidates.",
                contexts_to_ensemble=results
            )
        else:
            # Linear decomposition for straightforward problems
            final_solution = await self.generate(
                instruction="Execute the plan step by step, showing each calculation clearly and tracking units throughout.",
                context=plan
            )

        # Step 4: Revise for accuracy — check for unit consistency, logical flow, and numerical correctness
        revised_solution = await self.revise(
            instruction="Critically review the solution for errors in arithmetic, unit handling, and logical sequencing. Correct any mistakes found.",
            context_to_revise=final_solution
        )

        # Step 5: Final verification via bidirectional check if possible
        # For problems with clear inverse relationships, test backward reasoning
        if "inverse" in revised_solution.lower() or "check" in revised_solution.lower():
            verification = await self.generate(
                instruction="Create a reverse version of this problem starting from the answer and verify that it leads back to the original scenario.",
                context=revised_solution
            )
            final_answer = await self.ensemble(
                instruction="Select the most accurate final answer based on both the direct solution and its reverse verification.",
                contexts_to_ensemble=[revised_solution, verification]
            )
        else:
            final_answer = revised_solution

        return final_answer