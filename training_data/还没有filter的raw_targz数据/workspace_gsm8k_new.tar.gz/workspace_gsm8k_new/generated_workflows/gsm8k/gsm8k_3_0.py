# Workflow ID: gsm8k_3_0
# Benchmark: gsm8k
# Data Indices: [148, 286]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify key quantities and relationships
        analysis = await self.generate(
            instruction="Identify all numerical values, units, and relationships in the problem. Extract what is known and what needs to be calculated."
        )

        # Step 2: Generate multiple solution paths using parallel exploration
        task1 = self.generate(
            instruction="Generate a step-by-step solution assuming sequential operations only."
        )
        task2 = self.generate(
            instruction="Generate a solution focusing on proportional reasoning (e.g., percentages, fractions)."
        )
        task3 = self.generate(
            instruction="Generate a solution treating this as a multi-entity tracking problem (e.g., time-based accumulation)."
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble to select the most consistent solution
        final_solution = await self.ensemble(
            instruction="Compare the three generated solutions. Choose the one that best fits the problem's context and arithmetic logic.",
            contexts_to_ensemble=solutions
        )

        # Step 4: Optional refinement via iterative revision if uncertainty remains
        revised_solution = await self.revise(
            instruction="Check for logical consistency, unit tracking, and whether the answer makes sense in real-world terms (e.g., no negative items, reasonable magnitude). If needed, improve clarity or fix errors.",
            context_to_revise=final_solution
        )

        return revised_solution