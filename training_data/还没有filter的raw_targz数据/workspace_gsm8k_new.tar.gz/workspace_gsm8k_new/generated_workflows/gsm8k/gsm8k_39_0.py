# Workflow ID: gsm8k_39_0
# Benchmark: gsm8k
# Data Indices: [178, 298]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify problem type and key elements
        analysis = await self.generate(
            instruction="Analyze the problem to determine its type (e.g., distribution, rate, comparison) and extract all known quantities, units, and relationships."
        )

        # Step 2: Extract structured data from the analysis for clarity
        extracted_data = await self.generate(
            instruction="From the analysis, extract all numerical values and their associated contexts (e.g., 'red sweets = 49', 'green sweets = 59').",
            context=analysis
        )

        # Step 3: Generate multiple solution paths in parallel — one for each possible interpretation or approach
        task1 = self.generate(
            instruction="Generate a step-by-step arithmetic solution based on the extracted data.",
            context=extracted_data
        )
        task2 = self.generate(
            instruction="Generate an alternative solution path by identifying hidden steps or unit conversions that might be required.",
            context=extracted_data
        )
        task3 = self.generate(
            instruction="Generate a solution using proportional reasoning or algebraic modeling if applicable.",
            context=extracted_data
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble to select the most robust and consistent answer
        final_answer = await self.ensemble(
            instruction="Compare the three generated solutions and choose the one that best aligns with the original problem's constraints and mathematical logic.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional refinement via iterative revision if uncertainty remains
        revised_answer = await self.revise(
            instruction="Review the final answer for logical consistency, unit correctness, and whether it makes sense in the real-world context described in the problem.",
            context_to_revise=final_answer
        )

        return revised_answer