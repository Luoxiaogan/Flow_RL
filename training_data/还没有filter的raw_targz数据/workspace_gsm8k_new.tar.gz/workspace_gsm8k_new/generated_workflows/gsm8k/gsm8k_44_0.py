# Workflow ID: gsm8k_44_0
# Benchmark: gsm8k
# Data Indices: [50, 290]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify key elements and structure
        analysis = await self.generate(
            instruction="Identify all numerical values, relationships, and unknowns in the problem. Extract quantities, operations, and units."
        )

        # Step 2: Summarize to reduce noise and focus on core math facts
        structured_facts = await self.summarize(analysis)

        # Step 3: Generate multiple solution paths (parallel exploration)
        task1 = self.generate(
            instruction="Solve step-by-step using sequential operations based on the order described in the problem.",
            context=structured_facts
        )
        task2 = self.generate(
            instruction="Solve by first identifying all variables and then setting up equations or proportional reasoning.",
            context=structured_facts
        )
        task3 = self.generate(
            instruction="Break down into sub-problems: isolate each entity's contribution and calculate separately before combining.",
            context=structured_facts
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble to select best solution from diverse approaches
        final_answer = await self.ensemble(
            instruction="Choose the most consistent and logically sound answer from the three generated solutions.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional refinement if needed (e.g., verify unit consistency or arithmetic)
        if "verify" in final_answer.lower():
            refined_answer = await self.revise(
                instruction="Check that the final answer makes sense in context — no negative items, correct units, and logical flow.",
                context_to_revise=final_answer
            )
            return refined_answer
        else:
            return final_answer