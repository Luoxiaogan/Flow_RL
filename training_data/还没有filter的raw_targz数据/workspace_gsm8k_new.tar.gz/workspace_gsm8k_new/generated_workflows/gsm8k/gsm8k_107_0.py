# Workflow ID: gsm8k_107_0
# Benchmark: gsm8k
# Data Indices: [172, 142]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand the problem structure and identify key elements
        analysis = await self.generate(
            instruction="Identify all known values, unknowns, and relationships in the problem. Highlight any hidden steps or unit conversions needed."
        )

        # Step 2: Extract Structured Facts — Convert narrative into clear numerical facts
        extracted_facts = await self.generate(
            instruction="Extract all numerical values, variables, and their relationships from the analysis. Format as bullet points with units if applicable.",
            context=analysis
        )

        # Step 3: Generate Multiple Solution Paths — Use parallel exploration to handle ambiguity
        task1 = self.generate(
            instruction="Generate a step-by-step solution based on direct arithmetic operations from the extracted facts.",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Generate an alternative solution path using proportional reasoning or algebraic setup (e.g., setting up equations).",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Generate a solution path that explicitly tracks units throughout the calculation to ensure consistency.",
            context=extracted_facts
        )

        # Run in parallel to explore diverse strategies
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble — Combine the best aspects of each approach
        final_solution = await self.ensemble(
            instruction="Choose the most accurate and coherent solution by comparing all three approaches. Resolve any discrepancies through logical consistency checks.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Revise for Accuracy — Self-correct based on potential errors or inconsistencies
        revised_solution = await self.revise(
            instruction="Review the final solution for mathematical correctness, unit consistency, and logical coherence. Fix any issues found.",
            context_to_revise=final_solution
        )

        # Step 6: Final Summary — Ensure clarity and correctness before return
        summary = await self.summarize(context_to_summarize=revised_solution)

        return summary