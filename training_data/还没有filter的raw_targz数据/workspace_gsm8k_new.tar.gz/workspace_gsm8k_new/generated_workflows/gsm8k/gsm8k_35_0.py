# Workflow ID: gsm8k_35_0
# Benchmark: gsm8k
# Data Indices: [256, 296]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis – Understand problem structure and identify key entities
        analysis = await self.generate(
            instruction="Identify all numerical values, relationships, and what needs to be calculated. Extract key variables like quantities, rates, and operations."
        )

        # Step 2: Structured Reasoning – Generate step-by-step solution plan
        reasoning_plan = await self.generate(
            instruction="Based on the analysis, create a clear, sequential plan to solve this math word problem. Include intermediate steps and unit tracking.",
            context=analysis
        )

        # Step 3: Parallel Exploration – Try two different solution approaches (e.g., direct calculation vs. formula-based)
        task1 = self.generate(
            instruction="Solve using a direct step-by-step arithmetic approach based on the reasoning plan.",
            context=reasoning_plan
        )
        task2 = self.generate(
            instruction="Solve by identifying and applying relevant mathematical formulas or patterns from the problem structure.",
            context=reasoning_plan
        )
        solutions = await asyncio.gather(task1, task2)

        # Step 4: Ensemble – Combine both solutions to improve accuracy
        final_solution = await self.ensemble(
            instruction="Compare the two candidate solutions and select the most accurate one. If they differ, explain why and choose the best-supported answer.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Refinement – Self-check for consistency, units, and logical errors
        refined_solution = await self.revise(
            instruction="Review the final solution for correctness: does it match the problem’s question? Are units consistent? Is the answer reasonable in context?",
            context_to_revise=final_solution
        )

        return refined_solution