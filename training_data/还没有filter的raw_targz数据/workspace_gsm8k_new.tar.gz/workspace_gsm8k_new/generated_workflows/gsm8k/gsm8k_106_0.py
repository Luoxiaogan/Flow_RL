# Workflow ID: gsm8k_106_0
# Benchmark: gsm8k
# Data Indices: [190, 115]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Identify key entities, quantities, and relationships
        analysis = await self.generate(
            instruction="Extract all numerical values, units, and relationships from the problem. List them clearly."
        )

        # Step 2: Structure the Problem — Convert to a step-by-step plan
        planning = await self.generate(
            instruction="Based on the extracted facts, outline a clear sequence of steps needed to solve this problem.",
            context=analysis
        )

        # Step 3: Execute Plan — Perform calculations in order
        execution = await self.generate(
            instruction="Now compute each step one by one using the plan. Show intermediate results explicitly.",
            context=planning
        )

        # Step 4: Validate Logic — Check if steps make sense together
        validation = await self.revise(
            instruction="Review the solution for logical consistency: do the steps follow naturally? Are there missing assumptions?",
            context_to_revise=execution
        )

        # Step 5: Final Answer Extraction — Isolate the final numerical answer
        final_answer = await self.generate(
            instruction="From the validated solution, extract only the final numerical answer. Do not include explanations.",
            context=validation
        )

        # Step 6: Ensemble for Robustness — Generate alternative approaches (if feasible) and combine
        try:
            # Parallel exploration of different interpretations or methods
            task1 = self.generate(instruction="Generate an alternative approach based on unit-based reasoning.")
            task2 = self.generate(instruction="Generate another approach focusing on proportional relationships.")
            alternatives = await asyncio.gather(task1, task2)
            ensemble_result = await self.ensemble(
                instruction="Choose the most consistent and accurate final answer among these solutions.",
                contexts_to_ensemble=[final_answer] + alternatives
            )
        except Exception:
            # Fallback if parallel tasks fail (e.g., due to LLM constraints)
            ensemble_result = final_answer

        return ensemble_result