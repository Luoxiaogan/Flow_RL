# Workflow ID: gsm8k_31_0
# Benchmark: gsm8k
# Data Indices: [243, 1]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand the problem type and key elements
        analysis = await self.generate(
            instruction="Identify the problem type (e.g., percentage, comparison, rate), known quantities, unknowns, and units involved."
        )

        # Step 2: Extract structured data from the problem text for precise reasoning
        extracted_data = await self.generate(
            instruction="Extract all numerical values, relationships, and units into a structured format like 'key: value' pairs.",
            context=analysis
        )

        # Step 3: Generate multiple solution paths in parallel to handle ambiguity or complexity
        task1 = self.generate(
            instruction="Step-by-step solution using arithmetic operations based on the extracted data.",
            context=extracted_data
        )
        task2 = self.generate(
            instruction="Alternative step-by-step solution focusing on unit consistency and conversion if needed.",
            context=extracted_data
        )
        task3 = self.generate(
            instruction="Solution path that explicitly tracks how each quantity changes over time or steps.",
            context=extracted_data
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble to select the most consistent and accurate solution
        final_solution = await self.ensemble(
            instruction="Choose the best solution among the three generated approaches. Prioritize logical consistency, unit handling, and correctness.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional refinement if the answer seems uncertain or needs verification
        if "uncertain" in final_solution.lower() or "check" in final_solution.lower():
            refined_solution = await self.revise(
                instruction="Revise the solution to ensure it correctly answers the original question and makes sense in context.",
                context_to_revise=final_solution
            )
            return refined_solution

        return final_solution