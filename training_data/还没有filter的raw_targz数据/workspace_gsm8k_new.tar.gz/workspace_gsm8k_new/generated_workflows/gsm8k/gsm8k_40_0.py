# Workflow ID: gsm8k_40_0
# Benchmark: gsm8k
# Data Indices: [114, 265]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify key entities, quantities, and operations
        analysis = await self.generate(
            instruction="Identify all numerical values, relationships, and required operations in the problem."
        )

        # Step 2: Extract structured facts from the analysis (e.g., "50 girls", "20% have dogs")
        extracted_facts = await self.generate(
            instruction="From the analysis, extract each relevant fact as a clear, concise statement.",
            context=analysis
        )

        # Step 3: Generate multiple solution paths — one based on raw math, one based on unit tracking
        math_path = await self.generate(
            instruction="Solve the problem using step-by-step mathematical reasoning, focusing on arithmetic operations.",
            context=extracted_facts
        )
        
        unit_path = await self.generate(
            instruction="Solve the problem by explicitly tracking units (e.g., students, dogs, hours) at every step.",
            context=extracted_facts
        )

        # Step 4: Ensemble the two solutions to resolve discrepancies or ambiguities
        final_solution = await self.ensemble(
            instruction="Choose the most consistent and logically sound solution between the two approaches.",
            contexts_to_ensemble=[math_path, unit_path]
        )

        # Step 5: Revise the final answer with error-checking prompts
        revised_answer = await self.revise(
            instruction="Check if the final answer makes sense in context — does it respect real-world constraints like non-negative integers or unit consistency?",
            context_to_revise=final_solution
        )

        return revised_answer