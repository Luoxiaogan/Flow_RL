# Workflow ID: gsm8k_81_0
# Benchmark: gsm8k
# Data Indices: [13, 87]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand the problem structure and identify key entities
        analysis = await self.generate(
            instruction="Identify all numerical values, units, relationships, and unknowns in the problem. Also determine if it involves sequential steps, rates, proportions, or distribution."
        )

        # Step 2: Extract Structured Facts — Turn unstructured text into clean data points
        extracted_facts = await self.generate(
            instruction="Extract all relevant quantities, their units, and what they represent (e.g., '30 miles east' → distance to dermatologist). List them clearly.",
            context=analysis
        )

        # Step 3: Generate Multiple Solution Paths — Use parallel exploration for robustness
        task1 = self.generate(
            instruction="Generate a step-by-step solution assuming this is a sequential operation problem (e.g., driving to two places and returning).",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Generate a step-by-step solution assuming this is a proportional reasoning problem (e.g., unit conversion or rate-based calculation).",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Generate a step-by-step solution assuming this is a distribution or comparison problem (e.g., dividing total among people).",
            context=extracted_facts
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer — Synthesize best approach based on consistency and clarity
        final_answer = await self.ensemble(
            instruction="Choose the most consistent, logical, and mathematically sound solution from the three generated paths. If there's disagreement, prioritize the one that correctly handles units and order of operations.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Verify with Bidirectional Check — Test internal consistency by reversing the logic
        verification = await self.generate(
            instruction="Now generate an inverse problem based on the final answer: start from the result and show how it logically leads back to the original input values. Ensure no contradictions exist.",
            context=final_answer
        )

        # Step 6: Revise Final Output — Improve clarity and correctness using bidirectional feedback
        refined_solution = await self.revise(
            instruction="Improve the final solution by incorporating insights from the inverse verification. Remove ambiguity, ensure correct units, and fix any logical gaps.",
            context_to_revise=final_answer
        )

        return refined_solution