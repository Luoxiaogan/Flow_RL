# Workflow ID: gsm8k_78_0
# Benchmark: gsm8k
# Data Indices: [219, 46]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Analyze the problem to identify key elements and structure
        analysis = await self.generate(
            instruction="Identify all numerical values, operations, time steps, and relationships in the problem. Extract quantities, units, and what needs to be calculated."
        )

        # Step 2: Generate multiple solution paths — one based on raw extraction, one based on logical breakdown
        extract_task = self.generate(
            instruction="From the analysis, extract only the numbers and their associated contexts (e.g., 'Monday: 100 oranges')."
        )
        logic_task = self.generate(
            instruction="Based on the analysis, break down the problem into sequential steps with explicit arithmetic operations needed at each step."
        )
        tasks = [extract_task, logic_task]
        results = await asyncio.gather(*tasks)

        # Step 3: Summarize each candidate approach for clarity and consistency
        summary_extract = await self.summarize(results[0])
        summary_logic = await self.summarize(results[1])

        # Step 4: Ensemble the two summaries to produce a coherent plan
        planning = await self.ensemble(
            instruction="Combine both approaches into a unified step-by-step strategy that includes all necessary calculations and unit tracking.",
            contexts_to_ensemble=[summary_extract, summary_logic]
        )

        # Step 5: Generate final solution using the integrated plan
        solution = await self.generate(
            instruction="Using the plan, compute the final answer by performing all required arithmetic operations carefully, maintaining unit consistency.",
            context=planning
        )

        # Step 6: Revise once for precision — check for hidden steps, order errors, or unit mismatches
        revised_solution = await self.revise(
            instruction="Review the solution for logical correctness, proper sequencing of operations, and consistent handling of units. If any error is found, correct it.",
            context_to_revise=solution
        )

        # Step 7: Final verification via bidirectional reasoning if possible
        # Only attempt inverse check if the problem has clear forward-backward symmetry
        is_inverse_applicable = "inverse" in analysis.lower() or "reverse" in analysis.lower()
        if is_inverse_applicable:
            inverse_plan = await self.generate(
                instruction="Create an inverse problem from the original: start with the final result and work backward to see if you arrive at the initial conditions.",
                context=revised_solution
            )
            final_answer = await self.ensemble(
                instruction="Compare the original solution with the inverse result. If they align, return the solution. Otherwise, revise again based on discrepancies.",
                contexts_to_ensemble=[revised_solution, inverse_plan]
            )
        else:
            final_answer = revised_solution

        return final_answer