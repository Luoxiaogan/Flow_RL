# Workflow ID: gsm8k_74_0
# Benchmark: gsm8k
# Data Indices: [299, 158]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Identify key elements and structure
        analysis = await self.generate(
            instruction="Identify all known quantities, unknowns, and relationships in the problem. Focus on what needs to be calculated."
        )

        # Step 2: Extract Structured Facts — Convert natural language into math-friendly form
        extracted_facts = await self.generate(
            instruction="From the analysis, extract structured numerical values and their meanings (e.g., 'total cost', 'price per item', 'number of people').",
            context=analysis
        )

        # Step 3: Generate Multiple Solution Paths — Explore different logical approaches
        task1 = self.generate(
            instruction="Generate a solution using direct arithmetic based on the extracted facts.",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Generate an alternative solution path by setting up equations for unknowns.",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Generate a step-by-step breakdown assuming sequential operations (e.g., first find total items, then compute cost).",
            context=extracted_facts
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer — Synthesize best-supported solution
        final_answer = await self.ensemble(
            instruction="Choose the most consistent and logically sound solution among the three candidates. Justify briefly if needed.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Revise for Errors — Check for unit mismatches, negative results, or illogical steps
        refined_answer = await self.revise(
            instruction="Review the final answer for mathematical consistency, unit correctness, and real-world feasibility (e.g., no negative people). If any issue found, correct it.",
            context_to_revise=final_answer
        )

        return refined_answer