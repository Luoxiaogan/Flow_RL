# Workflow ID: gsm8k_82_0
# Benchmark: gsm8k
# Data Indices: [3, 123]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify key elements (values, operations, relationships)
        analysis = await self.generate(
            instruction="Identify all numerical values, variables, and mathematical relationships in the problem. List them clearly."
        )

        # Step 2: Extract structured facts for reliable reasoning
        extracted_facts = await self.generate(
            instruction="From the analysis, extract only the essential facts as a list of key-value pairs or equations.",
            context=analysis
        )

        # Step 3: Generate multiple solution paths in parallel (divergence)
        task1 = self.generate(
            instruction="Solve using step-by-step arithmetic based on the extracted facts.",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Create an algebraic model to represent the relationships and solve for the unknown.",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Break down the problem into smaller sub-problems and solve each independently.",
            context=extracted_facts
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble to select the most consistent and plausible answer
        final_answer = await self.ensemble(
            instruction="Choose the most accurate and logically sound solution from the three candidates. Justify briefly.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional refinement if needed — check for unit consistency and sanity
        refined_answer = await self.revise(
            instruction="Verify that the final answer makes sense in the real-world context of the problem. If not, revise accordingly.",
            context_to_revise=final_answer
        )

        return refined_answer