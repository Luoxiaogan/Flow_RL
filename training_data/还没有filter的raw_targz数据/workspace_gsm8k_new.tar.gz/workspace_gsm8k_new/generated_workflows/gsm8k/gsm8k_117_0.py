# Workflow ID: gsm8k_117_0
# Benchmark: gsm8k
# Data Indices: [270, 89]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify key entities, quantities, and relationships
        analysis = await self.generate(
            instruction="Extract all numerical values, units, and relationships from the problem. Identify what needs to be calculated."
        )

        # Step 2: Generate multiple solution paths in parallel — one focusing on costs, another on revenue
        cost_path_task = self.generate(
            instruction="Calculate total costs including purchase price and feeding expenses.",
            context=analysis
        )
        revenue_path_task = self.generate(
            instruction="Calculate total revenue based on selling prices and quantities.",
            context=analysis
        )

        cost_path, revenue_path = await asyncio.gather(cost_path_task, revenue_path_task)

        # Step 3: Use Ensemble to combine both approaches — ensures robustness against single-path errors
        combined_solution = await self.ensemble(
            instruction="Compare the cost and revenue solutions. Determine the final profit by subtracting total costs from total revenue.",
            contexts_to_ensemble=[cost_path, revenue_path]
        )

        # Step 4: Optional refinement loop if uncertainty remains
        if "profit" not in combined_solution.lower():
            refined_solution = await self.revise(
                instruction="Ensure the final answer explicitly states the profit amount. If missing, calculate it directly.",
                context_to_revise=combined_solution
            )
            return refined_solution

        return combined_solution