# Workflow ID: gsm8k_143_0
# Benchmark: gsm8k
# Data Indices: [76, 232]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis - Understand the structure and identify knowns/unknowns
        analysis = await self.generate(
            instruction="Identify all numerical values, relationships, and what needs to be solved. Extract key quantities like totals, rates, or changes."
        )

        # Step 2: Structured Decomposition - Break into steps using linear decomposition
        steps = await self.generate(
            instruction="Break the problem into clear, sequential steps based on the analysis. Each step should build logically on the previous one.",
            context=analysis
        )

        # Step 3: Parallel Exploration - Generate multiple solution paths if ambiguity exists
        try:
            # Use ensemble to test different interpretations
            math_approach = self.generate("Solve directly using arithmetic operations.", context=steps)
            logic_approach = self.generate("Solve by identifying constraints and logical deductions.", context=steps)
            unit_approach = self.generate("Track units (dollars, hours, pages) throughout the calculation to ensure consistency.", context=steps)
            
            solutions = await asyncio.gather(math_approach, logic_approach, unit_approach)
            refined_solution = await self.ensemble(
                instruction="Choose the most consistent and accurate solution based on all three approaches. Resolve contradictions by checking unit validity and logical flow.",
                contexts_to_ensemble=solutions
            )
        except Exception:
            # Fallback if parallelism fails
            refined_solution = await self.generate(
                instruction="Based on the structured steps, now compute the final answer carefully, ensuring correct order of operations and unit handling.",
                context=steps
            )

        # Step 4: Final Verification - Bidirectional check to ensure correctness
        verification = await self.generate(
            instruction="Create an inverse problem from the computed answer and verify it leads back to the original input conditions.",
            context=refined_solution
        )

        # Step 5: Output with confidence
        final_answer = await self.revise(
            instruction="Ensure the final answer is clearly stated as a single numerical value, with no text explanation unless necessary for clarity.",
            context_to_revise=verification
        )

        return final_answer