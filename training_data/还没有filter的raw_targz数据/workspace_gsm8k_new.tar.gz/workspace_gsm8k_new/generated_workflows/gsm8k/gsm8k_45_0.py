# Workflow ID: gsm8k_45_0
# Benchmark: gsm8k
# Data Indices: [14, 119]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis – Understand the problem structure and identify knowns/unknowns
        analysis = await self.generate(
            instruction="Analyze the problem to identify all known quantities, unknowns, and relationships between them. Focus on mathematical operations needed."
        )

        # Step 2: Extract Structured Facts – Turn dense text into clean data points
        extracted_facts = await self.generate(
            instruction="Extract all numerical values, variables, and key relationships from the analysis. Format as bullet points: 'Key: Value'.",
            context=analysis
        )

        # Step 3: Generate Multiple Solution Paths – Explore different interpretations or approaches
        path1 = self.generate(
            instruction="Generate a step-by-step solution assuming the problem involves direct arithmetic operations (e.g., addition/subtraction).",
            context=extracted_facts
        )
        path2 = self.generate(
            instruction="Generate a step-by-step solution assuming the problem requires setting up an equation with one unknown variable.",
            context=extracted_facts
        )
        path3 = self.generate(
            instruction="Generate a step-by-step solution assuming proportional reasoning or unit-based scaling is required.",
            context=extracted_facts
        )

        # Step 4: Parallel Execution – Run all three paths concurrently
        solutions = await asyncio.gather(path1, path2, path3)

        # Step 5: Ensemble Final Answer – Synthesize best solution based on consistency and clarity
        final_answer = await self.ensemble(
            instruction="Compare the three candidate solutions. Choose the one that is most consistent with the problem statement, mathematically sound, and clearly explained.",
            contexts_to_ensemble=solutions
        )

        # Step 6: Optional Refinement – If answer seems ambiguous or incomplete, revise once
        if "solution" not in final_answer.lower() or "answer" not in final_answer.lower():
            final_answer = await self.revise(
                instruction="Revise the solution to ensure it directly answers the question with a single numerical value and includes clear steps.",
                context_to_revise=final_answer
            )

        return final_answer