# Workflow ID: gsm8k_77_0
# Benchmark: gsm8k
# Data Indices: [176, 273]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand the structure and identify key elements
        analysis = await self.generate(
            instruction="Identify all numerical values, units, relationships, and unknowns in the problem. Output as structured bullet points."
        )

        # Step 2: Extract Core Facts — Convert unstructured analysis into clean data
        facts = await self.generate(
            instruction="From the analysis, extract only the relevant numerical values, operations needed, and what must be solved for. Format clearly.",
            context=analysis
        )

        # Step 3: Generate Multiple Solution Paths — Use parallel exploration to explore different interpretations or methods
        task1 = self.generate(
            instruction="Solve using a step-by-step arithmetic approach, assuming no hidden steps."
        )
        task2 = self.generate(
            instruction="Solve by identifying the mathematical relationship first (e.g., ratio, rate, equation), then compute."
        )
        task3 = self.generate(
            instruction="Break down the problem into sub-problems if applicable, solve each independently, then combine."
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer — Compare and select the most consistent solution
        final_answer = await self.ensemble(
            instruction="Choose the answer that best aligns with all three approaches and makes logical sense in context.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Verify Consistency — Ensure no contradictions or invalid assumptions
        verification = await self.revise(
            instruction="Check that the final answer respects all constraints from the original problem (units, positivity, integer/fractional validity). If not, revise accordingly.",
            context_to_revise=final_answer
        )

        return verification