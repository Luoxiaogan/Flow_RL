# Workflow ID: gsm8k_75_0
# Benchmark: gsm8k
# Data Indices: [157, 218]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify key elements (values, operations, unknowns)
        analysis = await self.generate(
            instruction="Identify all numerical values, operations, and the final unknown in the problem. List them clearly."
        )

        # Step 2: Extract structured facts from analysis for precise reasoning
        extracted = await self.generate(
            instruction="From the analysis, extract only the numerical values, their meanings, and the relationships between them in a structured format like 'value: meaning'.",
            context=analysis
        )

        # Step 3: Generate multiple solution paths — one linear, one with unit tracking, one with inverse check
        task1 = self.generate(
            instruction="Generate a step-by-step solution assuming a sequential order of operations based on the extracted facts.",
            context=extracted
        )
        task2 = self.generate(
            instruction="Generate a solution that explicitly tracks units (e.g., dollars, hours) at each step to ensure consistency.",
            context=extracted
        )
        task3 = self.generate(
            instruction="Generate an inverse verification approach: assume a result and work backward to see if it matches the original conditions.",
            context=extracted
        )

        # Run parallel exploration
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble the three candidate solutions to resolve discrepancies
        final_answer = await self.ensemble(
            instruction="Select the most consistent answer across the three approaches. If there's disagreement, choose the one that best aligns with the original problem constraints.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Final refinement using revision to catch subtle errors or inconsistencies
        refined_answer = await self.revise(
            instruction="Review the final answer for mathematical correctness, unit consistency, and logical plausibility. Correct any issues found.",
            context_to_revise=final_answer
        )

        return refined_answer