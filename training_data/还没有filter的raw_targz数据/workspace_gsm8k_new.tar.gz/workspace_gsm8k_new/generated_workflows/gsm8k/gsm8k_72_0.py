# Workflow ID: gsm8k_72_0
# Benchmark: gsm8k
# Data Indices: [208, 247]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Analyze the problem to identify key elements and structure
        analysis = await self.generate(
            instruction="Identify all known quantities, unknowns, and operations needed in this word problem. Extract numerical values, relationships, and units."
        )

        # Step 2: Generate an initial step-by-step solution plan
        plan = await self.generate(
            instruction="Based on the analysis, generate a clear, sequential plan to solve the problem step by step.",
            context=analysis
        )

        # Step 3: Execute the plan in parallel branches if multiple interpretations exist
        # First, try one straightforward interpretation
        solution_1 = await self.generate(
            instruction="Solve the problem using the following plan: " + plan,
            context=analysis
        )

        # Check if the problem involves multi-entity tracking or complex dependencies
        # If so, explore alternate interpretations via parallel paths
        if "multiple people" in analysis.lower() or "different entities" in analysis.lower():
            task1 = self.generate("Alternative approach: Reinterpret the problem focusing on entity-level tracking.")
            task2 = self.generate("Another alternative: Assume each action happens sequentially but track units separately.")
            tasks = [task1, task2]
            results = await asyncio.gather(*tasks)
            candidates = [solution_1] + results
            final_answer = await self.ensemble(
                instruction="Choose the most consistent and logically sound solution based on all candidate answers.",
                contexts_to_ensemble=candidates
            )
        else:
            final_answer = solution_1

        # Step 4: Refine the answer through iterative revision using different error-checking lenses
        revised_answer = await self.revise(
            instruction="Review the solution carefully for arithmetic errors, unit consistency, and logical flow. Correct any mistakes found.",
            context_to_revise=final_answer
        )

        # Optional: Bidirectional verification — create inverse problem to validate
        inverse_check = await self.generate(
            instruction="Create an inverse version of the original problem that would lead back to the computed result. Verify if solving it yields the same input values.",
            context=revised_answer
        )

        # Final ensemble between original and verified solution
        final_output = await self.ensemble(
            instruction="Select the best answer after considering both the main solution and its inverse verification.",
            contexts_to_ensemble=[revised_answer, inverse_check]
        )

        return final_output