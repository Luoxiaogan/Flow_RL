# Workflow ID: gsm8k_52_0
# Benchmark: gsm8k
# Data Indices: [170, 245]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis
        analysis = await self.generate(
            instruction="Identify all numerical values, relationships, and operations required to solve this problem."
        )

        # Step 2: Extract Structured Facts (Parallel Exploration for Robustness)
        task1 = self.generate(instruction="List all known quantities from the problem.")
        task2 = self.generate(instruction="List all mathematical operations implied in the problem.")
        task3 = self.generate(instruction="Identify any hidden steps or unit conversions needed.")
        structured_facts = await asyncio.gather(task1, task2, task3)

        # Step 3: Generate Multiple Solution Paths (Parallel Exploration)
        path1 = self.generate(
            instruction="Generate a step-by-step solution assuming a linear approach.",
            context=structured_facts[0] + "\n" + structured_facts[1]
        )
        path2 = self.generate(
            instruction="Generate an alternative solution using proportional reasoning.",
            context=structured_facts[0] + "\n" + structured_facts[2]
        )
        path3 = self.generate(
            instruction="Generate a solution focusing on unit consistency and tracking.",
            context=structured_facts[0] + "\n" + structured_facts[1]
        )

        # Step 4: Ensemble Final Answer (Diverge-Converge Pattern)
        final_answer = await self.ensemble(
            instruction="Compare the three candidate solutions and select the most consistent one based on correctness and clarity.",
            contexts_to_ensemble=[path1, path2, path3]
        )

        # Step 5: Self-Verification via Bidirectional Check (Optional but High-Quality)
        verification = await self.generate(
            instruction="Now verify this answer by constructing a reverse problem: if the result is correct, what would be the input scenario?",
            context=final_answer
        )

        # Step 6: Final Refinement Based on Verification
        final_solution = await self.revise(
            instruction="Revise the solution to ensure it accounts for all constraints and makes sense in context.",
            context_to_revise=final_answer + "\n\nVerification: " + verification
        )

        return final_solution