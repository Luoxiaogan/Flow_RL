# Workflow ID: gsm8k_12_0
# Benchmark: gsm8k
# Data Indices: [234, 156]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand structure and identify key elements
        analysis = await self.generate(
            instruction="Identify all numerical values, entities, operations, and relationships in the problem. Extract known quantities, unknowns, and units."
        )

        # Step 2: Structured Decomposition — Convert narrative into step-by-step math logic
        decomposition = await self.generate(
            instruction="Break down the problem into sequential steps. For each step, specify what operation to perform (e.g., subtraction, division) and why it's needed based on the context.",
            context=analysis
        )

        # Step 3: Parallel Exploration — Generate multiple solution paths if ambiguous
        try:
            # If there's ambiguity or multiple interpretations, explore them
            has_ambiguity = "ambiguous" in analysis.lower() or "multiple ways" in analysis.lower()
            if has_ambiguity:
                task1 = self.generate(instruction="Generate one possible interpretation and solution path.")
                task2 = self.generate(instruction="Generate an alternative interpretation and solution path.")
                solutions = await asyncio.gather(task1, task2)
                final_answer = await self.ensemble(
                    instruction="Choose the most consistent and logically sound solution based on the original problem constraints.",
                    contexts_to_ensemble=solutions
                )
            else:
                # Linear path: proceed directly with the main decomposition
                final_answer = await self.generate(
                    instruction="Using the step-by-step breakdown, compute the final answer. Show intermediate calculations clearly.",
                    context=decomposition
                )
        except Exception as e:
            # Fallback to simple linear approach if parallel fails
            final_answer = await self.generate(
                instruction="Compute the final numerical answer using the provided decomposition. Be explicit about each calculation step.",
                context=decomposition
            )

        # Step 4: Self-Correction Loop — Revise for errors in reasoning or arithmetic
        revised_answer = await self.revise(
            instruction="Review the solution carefully. Check for logical consistency, unit handling, and arithmetic accuracy. Fix any mistakes.",
            context_to_revise=final_answer
        )

        # Step 5: Final Verification — Bidirectional check or summary-based validation
        verification = await self.generate(
            instruction="Summarize the entire solution process and verify that the final answer makes sense in the context of the original problem. Ensure no real-world constraints were violated (e.g., negative sheep).",
            context=revised_answer
        )

        return verification