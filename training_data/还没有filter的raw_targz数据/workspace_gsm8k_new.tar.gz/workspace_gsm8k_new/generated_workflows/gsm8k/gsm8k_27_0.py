# Workflow ID: gsm8k_27_0
# Benchmark: gsm8k
# Data Indices: [62, 229]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify key elements and structure
        analysis = await self.generate(
            instruction="Identify all numerical values, units, relationships, and unknowns in the problem. Extract the core question."
        )

        # Step 2: Generate multiple solution paths using parallel exploration
        task1 = self.generate(
            instruction="Break down the problem into step-by-step arithmetic operations based on the analysis.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Generate an alternative approach by first identifying what needs to be solved and then working backward from the answer.",
            context=analysis
        )
        task3 = self.generate(
            instruction="Propose a proportional or rate-based method if applicable (e.g., per day, per unit).",
            context=analysis
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble to select the most consistent and logical solution
        final_answer = await self.ensemble(
            instruction="Compare the three proposed solutions. Choose the one that best aligns with the problem constraints and mathematical logic.",
            contexts_to_ensemble=solutions
        )

        # Step 4: Revise for accuracy and clarity — check consistency and unit handling
        revised_answer = await self.revise(
            instruction="Review the final solution for correctness: ensure all steps are logically sound, units are tracked properly, and no negative or impossible values exist.",
            context_to_revise=final_answer
        )

        return revised_answer