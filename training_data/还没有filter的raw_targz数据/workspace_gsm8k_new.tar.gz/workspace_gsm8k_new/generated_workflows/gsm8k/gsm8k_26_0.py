# Workflow ID: gsm8k_26_0
# Benchmark: gsm8k
# Data Indices: [23, 191]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Extract key numerical values and relationships
        extraction = await self.generate(
            instruction="Extract all numerical values, units, and relationships from the problem text. List them clearly as 'value: unit' or 'relationship: description'."
        )

        # Step 2: Analyze the structure — identify type (rate, proportion, comparison, etc.)
        analysis = await self.generate(
            instruction="Based on the extracted information, determine the problem type (e.g., rate, distribution, proportional reasoning) and outline the required steps to solve it.",
            context=extraction
        )

        # Step 3: Generate multiple solution paths in parallel (if applicable)
        task1 = self.generate(
            instruction="Generate a step-by-step solution using a sequential approach, solving one operation at a time.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Generate an alternative solution path by first identifying unknowns and setting up equations.",
            context=analysis
        )
        task3 = self.generate(
            instruction="Generate a solution focusing on unit conversions and consistency checks throughout.",
            context=analysis
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble the best solution based on clarity, correctness, and completeness
        final_solution = await self.ensemble(
            instruction="Compare the three generated solutions. Choose the one that is most logically sound, mathematically correct, and explicitly handles units and intermediate steps.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional refinement if the answer seems ambiguous or incomplete
        if "how many" in final_solution.lower() or "what is" in final_solution.lower():
            refined = await self.revise(
                instruction="Revise the solution to ensure it includes explicit intermediate calculations, clear labeling of units, and verification that the final answer makes sense in context.",
                context_to_revise=final_solution
            )
            return refined
        else:
            return final_solution