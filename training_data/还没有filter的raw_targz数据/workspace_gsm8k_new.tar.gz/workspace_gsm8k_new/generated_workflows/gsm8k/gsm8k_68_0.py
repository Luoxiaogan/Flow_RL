# Workflow ID: gsm8k_68_0
# Benchmark: gsm8k
# Data Indices: [241, 103]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis – Understand the structure and key elements
        analysis = await self.generate(
            instruction="Identify all numerical values, relationships, conditions, and unknowns in the problem. Extract the core variables and constraints."
        )

        # Step 2: Parallel Exploration – Generate multiple solution paths based on different interpretations
        task1 = self.generate(
            instruction="Generate a step-by-step mathematical plan assuming the problem involves sequential operations.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Generate a step-by-step plan focusing on proportional reasoning or unit-based calculations.",
            context=analysis
        )
        task3 = self.generate(
            instruction="Generate a plan that explicitly handles conditional rules (e.g., 'if X then Y') in the problem.",
            context=analysis
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 3: Ensemble – Combine the best aspects of each plan to form a robust strategy
        strategy = await self.ensemble(
            instruction="Synthesize the three approaches into one coherent, logically sound solution strategy that addresses all constraints.",
            contexts_to_ensemble=solutions
        )

        # Step 4: Execute Strategy – Build the actual solution using the refined plan
        solution = await self.generate(
            instruction="Now solve the problem following the synthesized strategy. Show each intermediate calculation clearly.",
            context=strategy
        )

        # Step 5: Refinement Loop – Use iterative revision to improve accuracy
        revised_solution = await self.revise(
            instruction="Check the solution for logical consistency, arithmetic correctness, and adherence to real-world constraints (e.g., no negative quantities). Fix any errors found.",
            context_to_revise=solution
        )

        # Step 6: Final Verification – Ensure answer makes sense in context
        verification = await self.generate(
            instruction="Verify that the final answer fits the original problem statement by re-evaluating the assumptions and steps taken.",
            context=revised_solution
        )

        return verification