# Workflow ID: gsm8k_59_0
# Benchmark: gsm8k
# Data Indices: [150, 227]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Identify key elements and structure
        analysis = await self.generate(
            instruction="Identify all numerical values, units, relationships, and what needs to be calculated. Extract the core math problem type (e.g., rate, proportion, comparison)."
        )

        # Step 2: Extract Structured Facts — Clean up the problem into structured data
        extracted = await self.generate(
            instruction="Based on the analysis, extract a list of key facts in this format: ['value1', 'unit1', 'relation1', ...]. Keep it concise.",
            context=analysis
        )

        # Step 3: Generate Multiple Solution Paths — Parallel exploration of different interpretations or strategies
        task1 = self.generate(instruction="Solve using step-by-step arithmetic reasoning.", context=extracted)
        task2 = self.generate(instruction="Solve by setting up an equation based on the relationship between quantities.", context=extracted)
        task3 = self.generate(instruction="If applicable, solve using proportional reasoning (ratios or percentages).", context=extracted)
        
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer — Compare and select the most consistent solution
        final_answer = await self.ensemble(
            instruction="Among the three proposed solutions, identify the one that is most consistent with the original problem constraints and mathematical logic. Return only the final numerical answer.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional Refinement — If there's ambiguity, revise for clarity or correctness
        if "multiple" in final_answer.lower() or "ambiguous" in final_answer.lower():
            final_answer = await self.revise(
                instruction="Refine the answer by resolving any ambiguity or inconsistency in the previous solution. Ensure it matches the real-world constraints of the problem (e.g., no negative items, whole numbers where needed).",
                context_to_revise=final_answer
            )

        return final_answer