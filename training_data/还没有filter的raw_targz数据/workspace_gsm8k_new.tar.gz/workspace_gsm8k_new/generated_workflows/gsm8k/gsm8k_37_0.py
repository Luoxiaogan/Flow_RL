# Workflow ID: gsm8k_37_0
# Benchmark: gsm8k
# Data Indices: [171, 255]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Analyze the problem to identify knowns, unknowns, and relationships
        analysis = await self.generate(
            instruction="Identify all numerical values, variables, and mathematical relationships in the problem. List them clearly."
        )

        # Step 2: Extract structured facts from the analysis (e.g., equations or key constraints)
        extraction = await self.generate(
            instruction="From the analysis, extract all explicit and implicit equations or constraints involving unknowns.",
            context=analysis
        )

        # Step 3: Generate multiple solution paths — one using direct equation solving, another by step-by-step substitution
        task1 = self.generate(
            instruction="Solve the problem by setting up and solving equations directly based on the extracted constraints.",
            context=extraction
        )
        task2 = self.generate(
            instruction="Solve the problem by modeling each person/entity's quantity step-by-step in chronological order.",
            context=extraction
        )
        solutions = await asyncio.gather(task1, task2)

        # Step 4: Ensemble the two solutions to resolve discrepancies or reinforce confidence
        final_solution = await self.ensemble(
            instruction="Compare both solutions and choose the most consistent one. If they differ, explain why and select the better-supported answer.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional refinement loop if there’s ambiguity or uncertainty
        if "ambiguous" in final_solution.lower() or "inconsistent" in final_solution.lower():
            refined = await self.revise(
                instruction="Revise the solution to clarify any inconsistencies or missing steps. Focus on unit tracking and logical flow.",
                context_to_revise=final_solution
            )
            final_solution = refined

        return final_solution