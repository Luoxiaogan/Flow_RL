# Workflow ID: gsm8k_149_0
# Benchmark: gsm8k
# Data Indices: [135, 126]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Extract key facts and entities from the problem
        analysis = await self.generate(
            instruction="Extract all numerical values, quantities, and relationships in the problem. List them clearly with units if applicable."
        )

        # Step 2: Generate a structured plan based on extracted facts
        plan = await self.generate(
            instruction="Based on the extracted facts, create a step-by-step solution plan that accounts for all operations needed to solve the problem. Include order of operations, unit tracking, and intermediate variables.",
            context=analysis
        )

        # Step 3: Parallel exploration of different interpretations (if ambiguous)
        try:
            # Attempt to detect ambiguity — e.g., multiple ways to interpret "twice as much"
            ambiguity_check = await self.generate(
                instruction="Identify any ambiguous phrases or potential misinterpretations in the problem statement."
            )
            if "ambiguous" in ambiguity_check.lower() or "multiple interpretations" in ambiguity_check.lower():
                # If ambiguous, explore multiple paths
                tasks = [
                    self.generate("Generate a solution assuming interpretation A."),
                    self.generate("Generate a solution assuming interpretation B.")
                ]
                solutions = await asyncio.gather(*tasks)
                final_answer = await self.ensemble(
                    instruction="Select the most plausible solution based on consistency with the original problem constraints.",
                    contexts_to_ensemble=solutions
                )
            else:
                # Proceed with single path
                final_answer = await self.generate(
                    instruction="Execute the plan step-by-step and compute the final answer. Show all intermediate calculations explicitly.",
                    context=plan
                )
        except Exception:
            # Fallback: just execute the plan directly
            final_answer = await self.generate(
                instruction="Execute the plan step-by-step and compute the final answer. Show all intermediate calculations explicitly.",
                context=plan
            )

        # Step 4: Revise for correctness using bidirectional verification
        verification = await self.generate(
            instruction="Create an inverse problem: given the final answer, reverse-engineer what inputs would produce it. Check if this matches the original problem description.",
            context=final_answer
        )
        
        # Step 5: Final ensemble of original and verified answers
        final_output = await self.ensemble(
            instruction="Choose the best answer by comparing the initial solution and the verification result. Resolve discrepancies if any.",
            contexts_to_ensemble=[final_answer, verification]
        )

        return final_output