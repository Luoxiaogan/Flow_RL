# Workflow ID: gsm8k_140_0
# Benchmark: gsm8k
# Data Indices: [248, 92]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Analyze and extract key elements (knowns, unknowns, units, relationships)
        analysis = await self.generate(
            instruction="Identify all known values, unknowns, units, and mathematical relationships in the problem."
        )

        # Step 2: Generate initial solution plan using structured reasoning
        plan = await self.generate(
            instruction="Based on the analysis, generate a step-by-step solution plan that handles units, order of operations, and hidden steps.",
            context=analysis
        )

        # Step 3: Use parallel exploration to test multiple approaches if ambiguity exists
        task1 = self.generate(
            instruction="Solve the problem using a direct arithmetic approach, tracking units at each step.",
            context=plan
        )
        task2 = self.generate(
            instruction="Reframe the problem as an algebraic equation and solve for the unknown.",
            context=plan
        )
        solutions = await asyncio.gather(task1, task2)

        # Step 4: Ensemble the candidate solutions to resolve discrepancies
        final_solution = await self.ensemble(
            instruction="Compare both solutions and select the one that correctly follows the problem constraints and unit conversions.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Revise based on verification — check if the answer makes sense in context
        revised_answer = await self.revise(
            instruction="Verify that the final answer is numerically correct and logically consistent with the original problem (e.g., no negative quantities, valid units).",
            context_to_revise=final_solution
        )

        return revised_answer