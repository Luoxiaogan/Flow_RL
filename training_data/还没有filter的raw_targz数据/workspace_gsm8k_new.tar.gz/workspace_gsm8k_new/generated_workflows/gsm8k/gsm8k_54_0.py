# Workflow ID: gsm8k_54_0
# Benchmark: gsm8k
# Data Indices: [216, 108]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis – Understand the problem structure and identify key elements
        analysis = await self.generate(
            instruction="Analyze the problem to identify known quantities, unknowns, units, and relationships between entities."
        )

        # Step 2: Extract Structured Data – Convert narrative into structured facts
        extracted_data = await self.generate(
            instruction="Extract all numerical values, their units, and what they represent (e.g., '6 homeless shelters', '30 people per shelter', '10 cans per person').",
            context=analysis
        )

        # Step 3: Generate Multiple Solution Paths – Use parallel exploration for robustness
        task1 = self.generate(
            instruction="Based on the extracted data, write a step-by-step solution using basic arithmetic operations in order.",
            context=extracted_data
        )
        task2 = self.generate(
            instruction="Reformulate the problem as a single equation or expression that captures the total quantity being sought.",
            context=extracted_data
        )
        task3 = self.generate(
            instruction="Identify if there are hidden steps (e.g., intermediate calculations like total people before computing cans).",
            context=extracted_data
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer – Synthesize best reasoning from multiple approaches
        final_answer = await self.ensemble(
            instruction="Compare the three proposed solutions. Select the one that correctly models the problem, respects unit consistency, and avoids logical errors.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional Refinement – If answer seems ambiguous or incomplete, revise once
        if "uncertain" in final_answer.lower() or "?" in final_answer:
            final_answer = await self.revise(
                instruction="Revise the solution to clarify any ambiguity, ensure it matches the original question exactly, and verify that all units and steps are logically consistent.",
                context_to_revise=final_answer
            )

        return final_answer