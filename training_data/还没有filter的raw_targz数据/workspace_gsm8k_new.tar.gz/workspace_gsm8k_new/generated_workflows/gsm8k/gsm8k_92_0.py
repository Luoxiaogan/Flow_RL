# Workflow ID: gsm8k_92_0
# Benchmark: gsm8k
# Data Indices: [139, 111]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis
        analysis = await self.generate(
            instruction="Identify all known quantities, unknowns, and relationships in the problem. Focus on mathematical operations needed."
        )

        # Step 2: Extract Structured Data (if needed)
        structured_data = await self.generate(
            instruction="Extract numerical values and their associated entities or units from the analysis. Format as bullet points.",
            context=analysis
        )

        # Step 3: Generate Multiple Solution Paths
        path1 = self.generate(
            instruction="Solve using sequential step-by-step arithmetic based on the order described in the problem.",
            context=structured_data
        )
        path2 = self.generate(
            instruction="Solve by first identifying the final target quantity and working backward to find required intermediate steps.",
            context=structured_data
        )
        path3 = self.generate(
            instruction="Model this as an equation system: define variables for each unknown and solve algebraically.",
            context=structured_data
        )

        # Execute all paths in parallel
        solutions = await asyncio.gather(path1, path2, path3)

        # Step 4: Ensemble Final Answer
        final_answer = await self.ensemble(
            instruction="Choose the most consistent and logically sound solution among the three approaches. If there's disagreement, explain why one is preferred.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional Refinement via Bidirectional Verification
        verification_check = await self.generate(
            instruction="Generate an inverse problem: if the answer is correct, what original input would lead to it? Does it match the original problem?",
            context=final_answer
        )

        # Final Summary + Output
        result = await self.summarize(
            context_to_summarize=f"Final answer: {final_answer}\n\nVerification: {verification_check}"
        )

        return result