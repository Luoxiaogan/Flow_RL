# Workflow ID: gsm8k_83_0
# Benchmark: gsm8k
# Data Indices: [86, 28]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis - Understand the structure and key elements
        analysis = await self.generate(
            instruction="Identify all quantities mentioned in the problem, what they represent, and any relationships between them. List known values, unknowns, and operations needed."
        )

        # Step 2: Extract Structured Facts - Convert narrative into clean data points
        structured_data = await self.generate(
            instruction="From the analysis, extract each numerical fact as a key-value pair with units if applicable. Format clearly.",
            context=analysis
        )

        # Step 3: Generate Multiple Solution Paths - Explore different interpretations or calculation orders
        path1 = self.generate(
            instruction="Solve step-by-step following the chronological order of events described in the problem.",
            context=structured_data
        )
        path2 = self.generate(
            instruction="Break down the problem into mathematical expressions first, then solve algebraically.",
            context=structured_data
        )
        path3 = self.generate(
            instruction="Focus on identifying hidden steps (e.g., total items, remaining after subtraction) before computing final answer.",
            context=structured_data
        )

        # Step 4: Parallel Exploration & Ensemble - Compare multiple approaches
        solutions = await asyncio.gather(path1, path2, path3)
        final_solution = await self.ensemble(
            instruction="Among the three candidate solutions, select the one that best matches the original problem constraints and makes logical sense.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Refine Final Answer - Check consistency and unit handling
        refined_answer = await self.revise(
            instruction="Verify that the final answer is consistent with all given facts and real-world constraints (e.g., no negative counts). If not, correct it.",
            context_to_revise=final_solution
        )

        return refined_answer