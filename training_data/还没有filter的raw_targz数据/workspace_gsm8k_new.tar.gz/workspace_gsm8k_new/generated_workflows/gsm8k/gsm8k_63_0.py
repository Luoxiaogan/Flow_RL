# Workflow ID: gsm8k_63_0
# Benchmark: gsm8k
# Data Indices: [260, 214]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Extract key facts and variables from the problem
        analysis = await self.generate(
            instruction="Identify all numerical values, units, and relationships in the problem. List them clearly."
        )

        # Step 2: Generate a structured plan based on identified elements
        plan = await self.generate(
            instruction="Based on the extracted facts, outline a step-by-step solution strategy. Include what operations are needed (e.g., multiplication, division, addition) and their order.",
            context=analysis
        )

        # Step 3: Execute the plan by generating intermediate calculations
        solution_draft = await self.generate(
            instruction="Now perform each step in the plan. Show all intermediate results with clear labels and units.",
            context=plan
        )

        # Step 4: Revise the draft using multiple angles to catch errors
        revision_1 = await self.revise(
            instruction="Check for arithmetic errors in the calculation steps.",
            context_to_revise=solution_draft
        )
        revision_2 = await self.revise(
            instruction="Verify that units are consistent throughout the solution.",
            context_to_revise=solution_draft
        )
        revision_3 = await self.revise(
            instruction="Ensure the final answer makes sense in the context of the original question.",
            context_to_revise=solution_draft
        )

        # Step 5: Ensemble the revised versions to produce a robust final answer
        final_solution = await self.ensemble(
            instruction="Select the most accurate and coherent solution from the three revisions.",
            contexts_to_ensemble=[revision_1, revision_2, revision_3]
        )

        return final_solution