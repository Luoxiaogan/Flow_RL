# Workflow ID: gsm8k_23_0
# Benchmark: gsm8k
# Data Indices: [188, 165]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis – Understand the problem structure and identify key elements
        analysis = await self.generate(
            instruction="Identify all known quantities, unknowns, relationships, and operations needed to solve this problem."
        )

        # Step 2: Extract Structured Facts – Convert narrative into mathematically usable form
        structured_facts = await self.generate(
            instruction="Extract all numerical values, variables, and their relationships from the analysis. Present as bullet points.",
            context=analysis
        )

        # Step 3: Generate Multiple Solution Paths – Explore different reasoning approaches
        task1 = self.generate(
            instruction="Solve step-by-step using a linear decomposition approach, following the chronological order in the problem."
        )
        task2 = self.generate(
            instruction="Model the problem algebraically by defining variables (e.g., x for unknowns) and writing equations based on the relationships."
        )
        task3 = self.generate(
            instruction="Break the problem into sub-problems if nested or multi-part, then combine solutions."
        )
        
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer – Choose best solution among candidates
        final_answer = await self.ensemble(
            instruction="Evaluate the three proposed solutions. Select the one that correctly models the problem, uses valid arithmetic, and makes sense in context.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional Refinement – Self-check for consistency and correctness
        refined_answer = await self.revise(
            instruction="Verify the final answer by checking units, logical constraints (e.g., no negative items), and whether it matches the original question's intent.",
            context_to_revise=final_answer
        )

        return refined_answer