# Workflow ID: gsm8k_62_0
# Benchmark: gsm8k
# Data Indices: [226, 250]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand the problem structure and identify key elements
        analysis = await self.generate(
            instruction="Analyze the problem to identify all quantities, units, operations, and relationships. List known values and unknowns clearly."
        )

        # Step 2: Extract Structured Data — Convert natural language into structured facts
        extracted_data = await self.generate(
            instruction="From the analysis, extract all numerical values with their associated units and what they represent (e.g., 'rose bushes = 20', 'cost per bush = $150').",
            context=analysis
        )

        # Step 3: Generate Multiple Solution Paths — Use parallel exploration for robustness
        task1 = self.generate(
            instruction="Generate a step-by-step solution assuming sequential operations (like cost breakdown).",
            context=extracted_data
        )
        task2 = self.generate(
            instruction="Generate an alternative solution path focusing on unit-based calculations (e.g., total cost per item type).",
            context=extracted_data
        )
        task3 = self.generate(
            instruction="Generate a solution using proportional reasoning if applicable (e.g., time-based growth or rate problems).",
            context=extracted_data
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer — Combine and select best-supported solution
        final_answer = await self.ensemble(
            instruction="Evaluate the three generated solutions. Choose the most consistent, logical, and accurate one based on the original problem constraints.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional Refinement — If needed, revise for precision or clarity
        refined_answer = await self.revise(
            instruction="Check the final answer for correctness, unit consistency, and whether it logically follows from the steps. If unsure, refine it further.",
            context_to_revise=final_answer
        )

        return refined_answer