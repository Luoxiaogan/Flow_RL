# Workflow ID: gsm8k_120_0
# Benchmark: gsm8k
# Data Indices: [59, 185]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand the problem type and extract key facts
        analysis = await self.generate(
            instruction="Identify the type of math problem (e.g., age difference, rate, distribution). Extract all known values, unknowns, and relationships between them."
        )

        # Step 2: Decompose into Steps — Generate a structured plan
        planning = await self.generate(
            instruction="Break down the problem into clear, sequential steps based on the analysis. Each step must involve one or more mathematical operations.",
            context=analysis
        )

        # Step 3: Parallel Exploration — Try multiple solution paths if ambiguity exists
        task1 = self.generate(
            instruction="Solve using forward calculation from initial conditions to final answer.",
            context=planning
        )
        task2 = self.generate(
            instruction="Solve by setting up equations for unknowns and solving algebraically.",
            context=planning
        )
        task3 = self.generate(
            instruction="Solve using unit-based reasoning (track units like years, apples, etc.) to ensure consistency.",
            context=planning
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer — Combine and select best solution
        final_answer = await self.ensemble(
            instruction="Choose the most consistent, logical, and numerically valid answer from the three approaches. If there's disagreement, prioritize clarity and correctness over complexity.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Revise for Errors — Self-correct based on common pitfalls (e.g., negative values, wrong order)
        revised_answer = await self.revise(
            instruction="Check for errors in unit handling, arithmetic, and logical flow. Ensure the final answer makes sense in context (e.g., no negative people or fractional items unless specified).",
            context_to_revise=final_answer
        )

        return revised_answer