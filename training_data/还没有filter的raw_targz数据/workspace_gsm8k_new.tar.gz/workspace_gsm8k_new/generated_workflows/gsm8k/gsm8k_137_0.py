# Workflow ID: gsm8k_137_0
# Benchmark: gsm8k
# Data Indices: [60, 44]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis
        analysis = await self.generate(
            instruction="Identify the key quantities, relationships, and unknowns in the problem. Focus on what needs to be calculated."
        )

        # Step 2: Extract Structured Facts
        extracted_facts = await self.generate(
            instruction="Extract all numerical values and their associated units from the problem text. List them clearly as 'value: unit'.",
            context=analysis
        )

        # Step 3: Generate Multiple Solution Paths (Parallel Exploration)
        task1 = self.generate(
            instruction="Generate a step-by-step solution using basic arithmetic operations based on the extracted facts.",
            context=extracted_facts
        )
        task2 = self.generate(
            instruction="Generate an alternative approach by identifying if this is a proportional reasoning or rate-based problem, then solve accordingly.",
            context=extracted_facts
        )
        task3 = self.generate(
            instruction="Generate a third possible interpretation — such as whether there's a hidden constraint (e.g., minimum items, time order) that must be respected.",
            context=extracted_facts
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer
        final_answer = await self.ensemble(
            instruction="Choose the most consistent and logically sound answer among the three generated solutions. If there is disagreement, resolve it by checking which one aligns best with the original problem constraints.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Revise for Accuracy & Clarity
        refined_answer = await self.revise(
            instruction="Check the final answer for correctness, unit consistency, and logical coherence. If any issues found, correct them while preserving the structure.",
            context_to_revise=final_answer
        )

        return refined_answer