# Workflow ID: gsm8k_50_0
# Benchmark: gsm8k
# Data Indices: [203, 21]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Analyze the problem structure and identify key entities, quantities, and relationships
        analysis = await self.generate(
            instruction="Analyze the problem to extract all known values, unknowns, and their relationships. Focus on identifying mathematical operations needed."
        )

        # Step 2: Extract structured data from the analysis (e.g., numbers, units, roles)
        extracted_data = await self.generate(
            instruction="From the analysis, extract all numerical values, units, and relationships in a structured format like 'key: value' pairs.",
            context=analysis
        )

        # Step 3: Generate multiple solution paths using different reasoning strategies
        task1 = self.generate(
            instruction="Generate a step-by-step plan based on sequential operations implied by the problem narrative."
        )
        task2 = self.generate(
            instruction="Generate a solution assuming proportional reasoning or unit-based scaling applies."
        )
        task3 = self.generate(
            instruction="Generate an alternative approach treating this as a distribution or comparison problem."
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble the three candidate solutions to find consensus or best-supported answer
        final_answer = await self.ensemble(
            instruction="Compare the three proposed solutions. Choose the one that aligns with the most consistent logical steps and avoids contradictions.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Revise the final answer using bidirectional verification — generate inverse problem and check consistency
        verification_check = await self.generate(
            instruction="Create a simple inverse version of the original problem based on the final answer. Verify if solving the inverse leads back to the original input values.",
            context=final_answer
        )

        # Step 6: If verification fails, apply iterative refinement; otherwise return the answer
        if "inconsistent" in verification_check.lower() or "does not match" in verification_check.lower():
            refined_answer = await self.revise(
                instruction="Revise the final answer based on the verification feedback. Ensure all units and intermediate steps are logically sound.",
                context_to_revise=final_answer
            )
            return refined_answer
        else:
            return final_answer