# Workflow ID: gsm8k_11_0
# Benchmark: gsm8k
# Data Indices: [277, 85]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to understand the problem structure and identify knowns/unknowns
        analysis = await self.generate(
            instruction="Identify all numerical values, units, relationships, and the final quantity to solve for. Do not compute yet."
        )

        # Step 2: Extract structured facts from the analysis for reliable reasoning
        extracted_facts = await self.generate(
            instruction="From the analysis, extract a list of key numerical values and their meanings (e.g., '7 pounds', '45 pounds', '5 pounds per dish').",
            context=analysis
        )

        # Step 3: Generate multiple solution paths in parallel — one for each major operation type (addition, multiplication, division, etc.)
        tasks = [
            self.generate(
                instruction="Solve using basic arithmetic operations in sequence, following the chronological order described in the problem.",
                context=extracted_facts
            ),
            self.generate(
                instruction="Solve by first combining all quantities before applying the unit conversion or rate.",
                context=extracted_facts
            ),
            self.generate(
                instruction="Solve by breaking down into sub-problems: first find total couscous, then divide by amount per dish.",
                context=extracted_facts
            )
        ]
        solutions = await asyncio.gather(*tasks)

        # Step 4: Ensemble the three candidate solutions to select the most consistent and accurate one
        final_answer = await self.ensemble(
            instruction="Select the best solution based on internal consistency, logical flow, and alignment with the original problem constraints.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Optional refinement loop if the answer seems ambiguous or inconsistent
        if "not sure" in final_answer.lower() or "multiple interpretations" in final_answer.lower():
            refined_answer = await self.revise(
                instruction="Improve clarity and correctness by rechecking all steps for unit consistency and logical coherence.",
                context_to_revise=final_answer
            )
            return refined_answer

        return final_answer