# Workflow ID: gsm8k_145_0
# Benchmark: gsm8k
# Data Indices: [69, 0]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Extract and understand key entities and quantities from the problem
        analysis = await self.generate(
            instruction="Identify all numerical values, relationships, and what needs to be calculated. Ignore irrelevant details."
        )

        # Step 2: Generate a structured plan based on the analysis
        plan = await self.generate(
            instruction="Based on the analysis, create a step-by-step solution plan that breaks down the problem into manageable arithmetic steps.",
            context=analysis
        )

        # Step 3: Execute the plan in parallel if possible (e.g., multiple independent calculations)
        tasks = [
            self.generate(
                instruction="Perform the first calculation step described in the plan.",
                context=plan
            ),
            self.generate(
                instruction="Perform the second calculation step described in the plan.",
                context=plan
            )
        ]
        intermediate_results = await asyncio.gather(*tasks)

        # Step 4: Synthesize results into a coherent solution
        synthesis = await self.generate(
            instruction="Using the intermediate results, write a complete step-by-step solution that leads to the final answer.",
            context="\n".join(intermediate_results)
        )

        # Step 5: Verify correctness using bidirectional reasoning
        inverse_problem = await self.generate(
            instruction="Create an inverse problem: given the final answer, reverse-engineer the original inputs to see if they match the problem statement.",
            context=synthesis
        )

        # Step 6: Ensemble between forward and inverse solutions to ensure consistency
        final_answer = await self.ensemble(
            instruction="Choose the most consistent and logically sound final answer between the forward solution and the inverse verification.",
            contexts_to_ensemble=[synthesis, inverse_problem]
        )

        # Step 7: Optional refinement loop for high-stakes accuracy
        refined_answer = await self.revise(
            instruction="Critique the final answer for logical consistency, unit correctness, and plausibility in the real-world context of the problem.",
            context_to_revise=final_answer
        )

        return refined_answer