# Workflow ID: gsm8k_96_0
# Benchmark: gsm8k
# Data Indices: [266, 237]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis - Understand the problem type and key elements
        analysis = await self.generate(
            instruction="Identify the problem type (e.g., rate, distribution, comparison), known quantities, unknowns, and required operations."
        )

        # Step 2: Extract structured data from the problem text
        extracted_data = await self.generate(
            instruction="Extract all numerical values, units, relationships, and constraints from the problem in a structured format like 'key: value' pairs.",
            context=analysis
        )

        # Step 3: Generate multiple solution strategies using parallel exploration
        strategy1 = self.generate(
            instruction="Propose a step-by-step plan to solve this using basic arithmetic operations only.",
            context=extracted_data
        )
        strategy2 = self.generate(
            instruction="Propose an alternative approach that might involve setting up equations or ratios.",
            context=extracted_data
        )
        strategy3 = self.generate(
            instruction="Propose a method that focuses on unit tracking and dimensional consistency throughout the calculation.",
            context=extracted_data
        )

        # Execute strategies in parallel
        strategies = await asyncio.gather(strategy1, strategy2, strategy3)

        # Step 4: Ensemble the best solution based on logical coherence and completeness
        final_solution = await self.ensemble(
            instruction="Choose the most complete and logically consistent solution among the three approaches.",
            contexts_to_ensemble=strategies
        )

        # Step 5: Refine the solution through iterative revision
        revised_solution = await self.revise(
            instruction="Review the solution for missing steps, incorrect order of operations, or unit errors. Correct them if needed.",
            context_to_revise=final_solution
        )

        # Step 6: Final verification by generating inverse problem
        inverse_check = await self.generate(
            instruction="Create a simple inverse problem: given the answer, reconstruct what the original question could have been. If it matches the input, the solution is likely correct.",
            context=revised_solution
        )

        # Step 7: Return the final, verified solution
        return revised_solution