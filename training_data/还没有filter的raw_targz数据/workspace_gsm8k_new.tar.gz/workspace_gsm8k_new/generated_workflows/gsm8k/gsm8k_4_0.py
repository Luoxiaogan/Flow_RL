# Workflow ID: gsm8k_4_0
# Benchmark: gsm8k
# Data Indices: [56, 225]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial Analysis — Understand structure and identify knowns/unknowns
        analysis = await self.generate(
            instruction="Analyze the problem to identify all given quantities, unknowns, and relationships between them."
        )

        # Step 2: Extract Key Quantities — Clean structured data from analysis
        extracted = await self.generate(
            instruction="Extract all numerical values and their associated units or roles (e.g., 'length', 'rate', 'total') from the analysis.",
            context=analysis
        )

        # Step 3: Generate Multiple Solution Paths — Parallel exploration of different interpretations
        task1 = self.generate(
            instruction="Propose one possible approach to solve this using step-by-step arithmetic reasoning.",
            context=extracted
        )
        task2 = self.generate(
            instruction="Propose an alternative solution path, perhaps focusing on unit conversion or rate-based modeling.",
            context=extracted
        )
        task3 = self.generate(
            instruction="Generate a third approach that explicitly models the problem as a system of equations or proportional reasoning.",
            context=extracted
        )
        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble Final Answer — Synthesize best solution from multiple paths
        final_answer = await self.ensemble(
            instruction="Evaluate the three proposed solutions and select the most consistent, accurate, and logically sound answer based on the original problem constraints.",
            contexts_to_ensemble=solutions
        )

        # Step 5: Verify Consistency — Use bidirectional verification if needed
        verification = await self.generate(
            instruction="Now, reframe the problem as an inverse question: if the final answer is correct, what must be true? Check whether this aligns with the initial setup.",
            context=final_answer
        )

        # Step 6: Final Refinement — Revise based on verification insight
        final_solution = await self.revise(
            instruction="Revise the solution to ensure it matches both the problem statement and the verification check. If there's inconsistency, fix it now.",
            context_to_revise=final_answer
        )

        return final_solution