# Workflow ID: gsm8k_84_0
# Benchmark: gsm8k
# Data Indices: [34, 16]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Extract key numerical values and entities from the problem
        extraction = await self.generate(
            instruction="Extract all numerical values, quantities, and key entities (people, objects, units) mentioned in the problem."
        )

        # Step 2: Analyze the structure — determine if it's sequential, proportional, or involves distribution
        analysis = await self.generate(
            instruction="Based on the extracted information, identify the type of math problem (e.g., division, rate, ratio, distribution). Also, note what needs to be calculated.",
            context=extraction
        )

        # Step 3: Generate multiple solution paths in parallel — one for each possible interpretation
        task1 = self.generate(
            instruction="First, solve step-by-step using basic arithmetic operations only, assuming no hidden steps.",
            context=analysis
        )
        task2 = self.generate(
            instruction="Now, assume there may be hidden intermediate steps (like unit conversions or partial distributions), and solve accordingly.",
            context=analysis
        )
        task3 = self.generate(
            instruction="Consider the possibility that the problem requires reverse-engineering (solve backwards from the final state).",
            context=analysis
        )

        solutions = await asyncio.gather(task1, task2, task3)

        # Step 4: Ensemble the three candidate solutions to select the most plausible one
        final_answer = await self.ensemble(
            instruction="Choose the most consistent and logically sound solution based on the three approaches above. If there's disagreement, pick the one that best fits the problem's context and avoids impossible results (e.g., negative counts).",
            contexts_to_ensemble=solutions
        )

        # Step 5: Revise once more to ensure clarity, correctness, and proper unit handling
        refined_answer = await self.revise(
            instruction="Review the final answer for logical consistency, correct arithmetic, and appropriate units. If any issue found, fix it.",
            context_to_revise=final_answer
        )

        return refined_answer