# Workflow ID: gsm8k_123_0
# Benchmark: gsm8k
# Data Indices: [152, 121]

class Workflow:
    def __init__(
        self,
        config,
        problem
    ) -> None:
        # --- DO NOT MODIFY THIS SECTION ---
        self.config = config
        self.problem_text = problem # Assumes problem is a pre-processed string
        self.llm = create(config)

        # All available operators are initialized here for your use.
        self.generate = operator.Generate(self.llm, self.problem_text)
        self.revise = operator.Revise(self.llm, self.problem_text)
        self.summarize = operator.Summarize(self.llm, self.problem_text)
        self.ensemble = operator.Ensemble(self.llm, self.problem_text)

    async def run_workflow(self):
        """
        This is where you implement the core problem-solving logic.
        You can use any of the operators initialized above.
        """
        import asyncio

        # Step 1: Initial analysis to identify knowns, unknowns, and relationships
        analysis = await self.generate(
            instruction="Identify all given quantities, unknowns, and mathematical relationships in the problem. List them clearly."
        )

        # Step 2: Extract structured facts from analysis for precise reasoning
        extracted_facts = await self.generate(
            instruction="Extract only numerical values and their associated units or roles (e.g., 'total apples', 'apples per mini pie').",
            context=analysis
        )

        # Step 3: Generate multiple solution paths — one for each major interpretation or operation type
        path1 = self.generate(
            instruction="Solve using sequential arithmetic steps based on the extracted facts.",
            context=extracted_facts
        )
        path2 = self.generate(
            instruction="Reformulate the problem as a proportion or unit rate calculation if applicable.",
            context=extracted_facts
        )
        path3 = self.generate(
            instruction="Model this as a distribution or remainder problem if relevant.",
            context=extracted_facts
        )

        # Step 4: Parallel exploration with ensemble to select best candidate
        candidates = [path1, path2, path3]
        final_solution = await self.ensemble(
            instruction="Evaluate the three proposed solutions. Choose the one that best matches the problem's structure and constraints.",
            contexts_to_ensemble=candidates
        )

        # Step 5: Optional refinement loop for high confidence in answer
        # If the solution seems ambiguous or lacks clarity, revise it with error-checking prompts
        revised_solution = await self.revise(
            instruction="Review the solution for logical consistency, unit correctness, and whether it answers the exact question asked. Fix any errors.",
            context_to_revise=final_solution
        )

        return revised_solution